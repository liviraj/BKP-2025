package com.histo.digitalsignatureservice.model.response;

public class DownloadResponse {
	private String url;

	public DownloadResponse() {
		super();
	}

	public DownloadResponse(String url) {
		super();
		this.url = url;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	
}
