package com.histo.digitalsignatureservice.model.request;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class UploadDocument {
    private String email;
    private String role;
    private String agreementName;
	private boolean passwordRequired;
	private String pdfPassword;
    private boolean signRequired;
}

