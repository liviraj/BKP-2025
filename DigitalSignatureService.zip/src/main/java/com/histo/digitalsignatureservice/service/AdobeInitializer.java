package com.histo.digitalsignatureservice.service;

import com.google.gson.Gson;
import com.histo.digitalsignatureservice.configuration.PropertyConfiguration;
import com.histo.digitalsignatureservice.adoberesmodel.TokenModel;
import com.histo.digitalsignatureservice.connection.ConnectionURLParams;
import okhttp3.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class AdobeInitializer {
    private static final Logger LOGGER = LogManager.getLogger(AdobeInitializer.class);
    private PropertyConfiguration propertyConfiguration;

    public AdobeInitializer(PropertyConfiguration propertyConfiguration) {
        super();
        this.propertyConfiguration = propertyConfiguration;
    }

    public Response getAccessToken() {
        try {
            String url = new ConnectionURLParams().getURLAccessToken(propertyConfiguration.getApiAccessPoint());
            OkHttpClient client = new OkHttpClient();
            String tokenBody = "client_id=" + propertyConfiguration.getClientId() + "&" + "client_secret=" + propertyConfiguration.getClientSecret() + "&"
                    + "grant_type=refresh_token" + "&" + "refresh_token=" + propertyConfiguration.getRefreshToken();
            MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
            RequestBody body = RequestBody.create(tokenBody, mediaType);
            Request request = new Request.Builder().url(url).method("POST", body)
                    .addHeader("Accept", "application/json").addHeader("Content-Type", "application/x-www-form-urlencoded")
                    .build();

            Response response = client.newCall(request).execute();
            return response;

        } catch (Exception exception) {
            LOGGER.error("getAccessToken() mehod Error: {}", exception);
        }

        return null;
    }
}
