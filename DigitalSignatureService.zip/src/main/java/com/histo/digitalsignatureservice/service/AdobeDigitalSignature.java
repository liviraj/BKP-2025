package com.histo.digitalsignatureservice.service;

import com.google.gson.Gson;
import com.histo.digitalsignatureservice.adobereqmodel.*;
import com.histo.digitalsignatureservice.adoberesmodel.*;
import com.histo.digitalsignatureservice.configuration.PropertyConfiguration;
import com.histo.digitalsignatureservice.connection.ConnectionURLParams;
import com.histo.digitalsignatureservice.filter.ResponseFilter;
import com.histo.digitalsignatureservice.model.request.UploadDocument;
import com.histo.digitalsignatureservice.model.response.DownloadResponse;
import com.histo.digitalsignatureservice.model.response.ErrorResponse;
import com.histo.digitalsignatureservice.model.response.UploadResponse;
import okhttp3.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Service
public class AdobeDigitalSignature {
    private static final Logger LOGGER = LogManager.getLogger(AdobeDigitalSignature.class);
    private final PropertyConfiguration propertyConfiguration;
    private final AdobeInitializer adobeInitializer;
    private MappingJacksonValue mappingJacksonValue;
    private final String eventType = "ACTION_COMPLETED";
    private final String eventTypeHosted = "ACTION_COMPLETED_HOSTED";

    public AdobeDigitalSignature(PropertyConfiguration propertyConfiguration, AdobeInitializer adobeInitializer) {
        this.propertyConfiguration = propertyConfiguration;
        this.adobeInitializer = adobeInitializer;
    }

    /*
    1. First call the adobe service to get the access token
    2. Call the transient enpoint to upload the document
    3. Call the agreement service to get the agreement id
    4. Call the signingurl to get the url and send to caller
    TODO: for every api call handle error code returned by adobe api. Should handle non 200 response.
     */
    public synchronized ResponseEntity<Object> uploadDocument(MultipartFile file, UploadDocument uploadDocument) throws IOException, JSONException, InterruptedException {
        try {
            RequestBody requestBody;
            Request request;
            Response response;
            String jsonString;

            MappingJacksonValue mappingJacksonValue = null;
            response = adobeInitializer.getAccessToken();

            if (response.code() != 200 && response.code() != 201) {
                ErrorResponse errorResponse = new ErrorResponse(response.code(), "Exception in getAccessToken method : Message :" + response.message());
                mappingJacksonValue = ResponseFilter.responseErrorFilter(errorResponse, new String[]{"status", "uploadResponse"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.valueOf(response.code()));
            }

            jsonString = response.body().string();
            TokenModel tokenModel = new Gson().fromJson(jsonString, TokenModel.class);
            ConnectionURLParams connectionURLParams = new ConnectionURLParams();

            String url = connectionURLParams.getURLuploadDocument(propertyConfiguration.getApiAccessPoint());

            OkHttpClient client = new OkHttpClient.Builder().connectTimeout(60, TimeUnit.SECONDS)
                    .readTimeout(60, TimeUnit.SECONDS)
                    .writeTimeout(60, TimeUnit.SECONDS)
                    .build();
            //Call the transient document service
            requestBody = new MultipartBody.Builder().setType(MultipartBody.FORM)
                    .addFormDataPart("File", file.getOriginalFilename(), RequestBody.create(file.getBytes(), MediaType.parse("application/pdf")))
                    .build();

            request = new Request.Builder().url(url).addHeader("Content-Type", "multipart/form-data")
                    .addHeader("Authorization", "Bearer " + tokenModel.getAccess_token())
                    .addHeader("Accept", "application/json, text/javascript, */*")
                    .post(requestBody).build();
            response = client.newCall(request).execute();


            if (response.code() != 200 && response.code() != 201) {
                ErrorResponse errorResponse = new ErrorResponse(response.code(), "Exception in getURLuploadDocument method : Message :" + response.message());
                mappingJacksonValue = ResponseFilter.responseErrorFilter(errorResponse, new String[]{"status", "uploadResponse"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.valueOf(response.code()));
            }


            jsonString = response.body().string();
            TransientDocumentResponse transientDocumentResponse = new Gson().fromJson(jsonString, TransientDocumentResponse.class);
            //Call the Agreement service
            AgreementRequest agreementRequest = constructAgreementRequest(transientDocumentResponse.getTransientDocumentId(), uploadDocument);
            String json = new Gson().toJson(agreementRequest);
            requestBody = RequestBody.create(json, MediaType.parse("application/json"));
            request = new Request.Builder().url(new ConnectionURLParams().getURLAgreementDocument(propertyConfiguration.getApiAccessPoint()))
                    .method("POST", requestBody).addHeader("Content-Type", "application/json")
                    .addHeader("Authorization", "Bearer " + tokenModel.getAccess_token())
                    .addHeader("Accept", "application/json")
                    .build();
            response = client.newCall(request).execute();

            if (response.code() != 200 && response.code() != 201) {
                ErrorResponse errorResponse = new ErrorResponse(response.code(), "Exception in getURLAgreementDocument method : Message :" + response.message());
                mappingJacksonValue = ResponseFilter.responseErrorFilter(errorResponse, new String[]{"status", "uploadResponse"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.valueOf(response.code()));
            }

            jsonString = response.body().string();
            AggrementResponse aggrementResponse = new Gson().fromJson(jsonString, AggrementResponse.class);
            //Call the signingurl
            wait(6000);
            request = new Request.Builder().url(new ConnectionURLParams().getURLSigningUrls(propertyConfiguration.getApiAccessPoint(), aggrementResponse.getId()))
                    .method("GET", null)
                    .addHeader("Authorization", "Bearer " + tokenModel.getAccess_token())
                    .addHeader("Accept", "application/json")
                    .build();
            response = client.newCall(request).execute();

            if (response.code() != 200 && response.code() != 201) {
                ErrorResponse errorResponse = new ErrorResponse(response.code(), "Exception in getURLSigningUrls method : Message :" + response.message());
                mappingJacksonValue = ResponseFilter.responseErrorFilter(errorResponse, new String[]{"status", "uploadResponse"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.valueOf(response.code()));
            }

            jsonString = response.body().string();
            RootSigninUrl rootSigninUrl = new Gson().fromJson(jsonString, RootSigninUrl.class);
            UploadResponse uploadResponse = new UploadResponse(true, transientDocumentResponse, aggrementResponse, rootSigninUrl);
            mappingJacksonValue = ResponseFilter.responseUploadFilter(uploadResponse, new String[]{"status", "uploadResponse"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error("Error uploadDocument() - {}", e);
            return new ResponseEntity<>("Something Went Wrong", HttpStatus.CONFLICT);
        }
    }

    public synchronized ResponseEntity<Object> downloadDocument(String agreementId) throws IOException, JSONException {
        try {
            RequestBody requestBody;
            Request request;
            Response response;
            String jsonString;
            OkHttpClient client = new OkHttpClient();
            response = adobeInitializer.getAccessToken();
            jsonString = response.body().string();
            TokenModel tokenModel = new Gson().fromJson(jsonString, TokenModel.class);
//TODO: first call https://api.na4.adobesign.com:443/api/rest/v6/agreements/CBJCHBCAABAAsKJmYUPnIfMxGrEPgN11bhqp7_PTL9Ny/events
            //Call events api to check signature completed or not. event type should be "ACTION_COMPLETED_HOSTED"
            request = new Request.Builder().url(new ConnectionURLParams().getURLEvents(propertyConfiguration.getApiAccessPoint(), agreementId))
                    .method("GET", null)
                    .addHeader("Authorization", "Bearer " + tokenModel.getAccess_token())
                    .addHeader("Accept", "*/*")
                    .build();
            response = client.newCall(request).execute();

            if (response.code() != 200 && response.code() != 201) {
                ErrorResponse errorResponse = new ErrorResponse(response.code(), "Exception in getting url : Message :" + response.message());
                mappingJacksonValue = ResponseFilter.responseErrorFilter(errorResponse, new String[]{"status", "downloadResponse"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.valueOf(response.code()));
            }

            jsonString = response.body().string();
            Events events = new Gson().fromJson(jsonString, Events.class);
            boolean isSigned = false;
            for (Event event : events.getEvents()) {
                if (event.getType().equals(eventType) || event.getType().equals(eventTypeHosted)) {
                    isSigned = true;
                    break;
                }
            }
            if (isSigned == false) {
                ErrorResponse errorResponse = new ErrorResponse(HttpStatus.CONFLICT.value(), "The document is not signed yet. Please try to sign agian and try");
                mappingJacksonValue = ResponseFilter.responseDownloadErrorFilter(errorResponse, new String[]{"status", "downloadResponse"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
            }
            request = new Request.Builder().url(new ConnectionURLParams().getURLDocument(propertyConfiguration.getApiAccessPoint(), agreementId))
                    .method("GET", null)
                    .addHeader("Authorization", "Bearer " + tokenModel.getAccess_token())
                    .addHeader("Accept", "*/*")
                    .build();
            response = client.newCall(request).execute();
            jsonString = response.body().string();
            JSONObject jsonObject = new JSONObject(jsonString);
            DownloadResponse downloadResponse = new DownloadResponse(jsonObject.getString("url"));
            mappingJacksonValue = ResponseFilter.responseDownloadURLFilter(downloadResponse, new String[]{"status", "downloadResponse"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            LOGGER.error("Error downloadDocument() - {}", e);
            return null;
        }
    }

    public String getDocument() throws IOException, JSONException {
        OkHttpClient client = new OkHttpClient();
        Request request;
        Response response;
        String jsonString;
        request = new Request.Builder().url("https://api.na4.adobesign.com/api/rest/v6/agreements/CBJCHBCAABAA1Movi8JuEuRFNa5mmMz42pXEboJ6FOcN/combinedDocument/url")
                .method("GET", null)
                .addHeader("Authorization", "Bearer " + "3AAABLblqZhA4Qzq1CGIQtgg5FZJN2rT35NSor25GU_n78DEiLlZtYM6ehHWWC2FUkwQXYZ-2HBZAtXuHfUuYdiVtZGQuryVM")
                .addHeader("Accept", "*/*")
                .build();
        response = client.newCall(request).execute();

        jsonString = response.body().string();
        JSONObject jsonObject = new JSONObject(jsonString);
        return jsonObject.getString("url");
    }

    private AgreementRequest constructAgreementRequest(String transientDocumentId, UploadDocument uploadDocument) {
        List<FileInfo> fileInfos = new ArrayList<>();
        FileInfo fileInfo = new FileInfo(transientDocumentId);
        fileInfos.add(fileInfo);
        List<MemberInfo> memberInfos = new ArrayList<>();
        MemberInfo memberInfo = new MemberInfo(uploadDocument.getEmail());
        memberInfos.add(memberInfo);
        List<ParticipantSetsInfo> participantSetsInfos = new ArrayList<>();
        ParticipantSetsInfo participantSetsInfo = new ParticipantSetsInfo(memberInfos, 1, uploadDocument.getRole());
        participantSetsInfos.add(participantSetsInfo);
        ExternalId externalId = new ExternalId("NA2Account_2");

        AgreementRequest agreementRequest;
        if (uploadDocument.isPasswordRequired()) {
            ContentProtectionPreference contentProtectionPreference = new ContentProtectionPreference();
            SecurityOption securityOption = new SecurityOption(uploadDocument.getPdfPassword(), contentProtectionPreference);
            agreementRequest = new AgreementRequest(fileInfos, uploadDocument.getAgreementName(), "REGULAR_SEND", participantSetsInfos, "ESIGN", externalId, "IN_PROCESS", securityOption);
        } else {
            agreementRequest = new AgreementRequest(fileInfos, uploadDocument.getAgreementName(), "REGULAR_SEND", participantSetsInfos, "ESIGN", externalId, "IN_PROCESS");
        }
        return agreementRequest;
    }

}


