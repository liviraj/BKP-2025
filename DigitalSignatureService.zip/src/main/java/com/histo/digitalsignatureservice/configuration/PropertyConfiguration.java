package com.histo.digitalsignatureservice.configuration;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:application.properties")
public class PropertyConfiguration {
    @Value("${adobe.code}")
    private String adobeCode;
    @Value("${api_access_point}")
    private String apiAccessPoint;
    @Value("${refresh_token}")
    private String refreshToken;
    @Value("${client_id}")
    private String clientId;
    @Value("${client_secret}")
    private String clientSecret;
	public String getAdobeCode() {
		return adobeCode;
	}
	public void setAdobeCode(String adobeCode) {
		this.adobeCode = adobeCode;
	}
	public String getApiAccessPoint() {
		return apiAccessPoint;
	}
	public void setApiAccessPoint(String apiAccessPoint) {
		this.apiAccessPoint = apiAccessPoint;
	}
	public String getRefreshToken() {
		return refreshToken;
	}
	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getClientSecret() {
		return clientSecret;
	}
	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}
    
    
}
