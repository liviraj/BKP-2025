package com.histo.digitalsignatureservice;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@OpenAPIDefinition(
        servers = {
                @Server(url = "https://javawebag01.histogenetics.com:8765/DigitalSignature", description = "Micro Service PROD API Gateway server"),
                @Server(url = "http://javawebag01:8400/DigitalSignature", description = "Micro Service UAT server"),
                @Server(url = "http://localhost:8400", description = "Local Server"),
                @Server(url = "http://localhost:8765", description = "Local Server"),
                @Server(url = "http://localhost:8765/DigitalSignature", description = "Micro Service dev API Gateway server"),
                @Server(url = "http://localhost:8400/DigitalSignature", description = "Micro Service dev server"),
                @Server(url = "https://webapiuat.histogenetics.com:8765/DigitalSignature", description = "Micro Service UAT Gateway server"),
                @Server(url = "http://webapiuat:8400/DigitalSignature", description = "Micro Service UAT Native server"),
        }
)
@SpringBootApplication
public class DigitalSignatureServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(DigitalSignatureServiceApplication.class, args);
    }

}
