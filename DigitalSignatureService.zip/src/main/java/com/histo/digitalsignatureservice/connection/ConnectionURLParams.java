package com.histo.digitalsignatureservice.connection;

public class ConnectionURLParams {
    public String getURLAccessToken(String baseURL) {
        return baseURL + "oauth/v2/refresh";
    }

    public String getURLuploadDocument(String baseURL) {
        return baseURL + "/api/rest/v6/transientDocuments";
    }

    public String getURLAgreementDocument(String baseURL) {
        return baseURL + "/api/rest/v6/agreements";
    }

    public String getURLSigningUrls(String baseURL, String agreementid) {
        return baseURL + "/api/rest/v6/agreements/" + agreementid + "/signingUrls";
    }

    public String getURLAgreementStatus(String baseURL, String agreementid) {
        return baseURL + "/api/rest/v6/agreements/" + agreementid;
    }

    public String getURLDocumentId(String baseURL, String agreementid) {
        return baseURL + "/api/rest/v6/agreements/" + agreementid + "/documents";
    }

    public String getURLDocument(String baseURL, String agreementid) {
        return baseURL + "/api/rest/v6/agreements/" + agreementid + "/combinedDocument/url";
    }
    public String getURLEvents(String baseURL, String agreementid) {
        return baseURL + "/api/rest/v6/agreements/" + agreementid + "/events";
    }

    public static String getAdobeCodeUrl(String clientId) {
        return "https://secure.na3.adobesign.com/public/oauth/v2?redirect_uri=https://www.google.com&response_type=code&client_id="
                + clientId +
                "&scope=user_login:self+agreement_write:account+agreement_read:account";
    }

    public static String getAdobeRefreshTokenUrl() {
        return "https://secure.na3.adobesign.com/oauth/v2/token";
    }
}
