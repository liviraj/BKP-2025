package com.histo.digitalsignatureservice.adoberesmodel;


import com.fasterxml.jackson.annotation.JsonAutoDetect;
import lombok.Getter;

import java.util.ArrayList;

@Getter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)

public class SigningUrlSetInfo {
    private ArrayList<SigningUrl> signingUrls;

	public ArrayList<SigningUrl> getSigningUrls() {
		return signingUrls;
	}

	public void setSigningUrls(ArrayList<SigningUrl> signingUrls) {
		this.signingUrls = signingUrls;
	}

   
    
    
}
