package com.histo.digitalsignatureservice.adoberesmodel;

import java.util.Date;

public class Event {
	private String id;
    private String type;
    private String actingUserEmail;
    private String actingUserName;
    private Date date;
    private String description;
    private String participantEmail;
    private String participantId;
    private String participantRole;
    private String versionId;
    private String device;
	public Event() {
		super();
	}
	public Event(String id, String type, String actingUserEmail, String actingUserName, Date date, String description,
			String participantEmail, String participantId, String participantRole, String versionId, String device) {
		super();
		this.id = id;
		this.type = type;
		this.actingUserEmail = actingUserEmail;
		this.actingUserName = actingUserName;
		this.date = date;
		this.description = description;
		this.participantEmail = participantEmail;
		this.participantId = participantId;
		this.participantRole = participantRole;
		this.versionId = versionId;
		this.device = device;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getActingUserEmail() {
		return actingUserEmail;
	}
	public void setActingUserEmail(String actingUserEmail) {
		this.actingUserEmail = actingUserEmail;
	}
	public String getActingUserName() {
		return actingUserName;
	}
	public void setActingUserName(String actingUserName) {
		this.actingUserName = actingUserName;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getParticipantEmail() {
		return participantEmail;
	}
	public void setParticipantEmail(String participantEmail) {
		this.participantEmail = participantEmail;
	}
	public String getParticipantId() {
		return participantId;
	}
	public void setParticipantId(String participantId) {
		this.participantId = participantId;
	}
	public String getParticipantRole() {
		return participantRole;
	}
	public void setParticipantRole(String participantRole) {
		this.participantRole = participantRole;
	}
	public String getVersionId() {
		return versionId;
	}
	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}
	public String getDevice() {
		return device;
	}
	public void setDevice(String device) {
		this.device = device;
	}
    
    
}
