package com.histo.digitalsignatureservice.adoberesmodel;

import java.util.ArrayList;

public class Events {
	private ArrayList<Event> events;

	public Events() {
		super();
	}

	public Events(ArrayList<Event> events) {
		super();
		this.events = events;
	}

	public ArrayList<Event> getEvents() {
		return events;
	}

	public void setEvents(ArrayList<Event> events) {
		this.events = events;
	}
	
	
}
