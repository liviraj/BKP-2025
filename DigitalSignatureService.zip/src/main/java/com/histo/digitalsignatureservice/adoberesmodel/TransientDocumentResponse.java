package com.histo.digitalsignatureservice.adoberesmodel;




public class TransientDocumentResponse {
    private String transientDocumentId;

    public void setTransientDocumentId(String transientDocumentId) {
        this.transientDocumentId = transientDocumentId;
    }

	public String getTransientDocumentId() {
		return transientDocumentId;
	}
    
    
}
