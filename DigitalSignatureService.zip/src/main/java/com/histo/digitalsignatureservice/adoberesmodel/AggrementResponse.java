package com.histo.digitalsignatureservice.adoberesmodel;




public class AggrementResponse {
    private String id;

    public void setId(String id) {
        this.id = id;
    }

	public String getId() {
		return id;
	}
    
	
}
