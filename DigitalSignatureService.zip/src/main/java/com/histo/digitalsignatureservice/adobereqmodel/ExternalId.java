package com.histo.digitalsignatureservice.adobereqmodel;



public class ExternalId {
    private String id;

    public ExternalId(String id) {
        this.id = id;
    }

    public void setId(String id) {
        this.id = id;
    }

	public String getId() {
		return id;
	}
    
}
