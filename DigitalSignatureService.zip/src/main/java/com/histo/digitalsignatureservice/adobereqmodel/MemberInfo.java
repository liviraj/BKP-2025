package com.histo.digitalsignatureservice.adobereqmodel;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class MemberInfo {
    private String email;

}
