package com.histo.digitalsignatureservice.adobereqmodel;



public class FileInfo {
    private String transientDocumentId;

    public FileInfo(String transientDocumentId) {
        this.transientDocumentId = transientDocumentId;
    }

    public void setTransientDocumentId(String transientDocumentId) {
        this.transientDocumentId = transientDocumentId;
    }

	public String getTransientDocumentId() {
		return transientDocumentId;
	}
    
    
}
