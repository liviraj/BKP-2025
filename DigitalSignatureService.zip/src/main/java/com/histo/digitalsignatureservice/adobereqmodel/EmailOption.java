package com.histo.digitalsignatureservice.adobereqmodel;



public class EmailOption {
    private SendOptions sendOptions;
    public EmailOption() {
        sendOptions = new SendOptions();
    }
	public SendOptions getSendOptions() {
		return sendOptions;
	}
	public void setSendOptions(SendOptions sendOptions) {
		this.sendOptions = sendOptions;
	}
    
}
