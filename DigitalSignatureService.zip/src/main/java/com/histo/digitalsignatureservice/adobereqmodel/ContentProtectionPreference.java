package com.histo.digitalsignatureservice.adobereqmodel;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class ContentProtectionPreference {
    private String external = "Enable Content Protection";
    private String internal = "";
}
