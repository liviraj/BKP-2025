package com.histo.digitalsignatureservice.adobereqmodel;

 

import java.util.ArrayList;
import java.util.List;


public class ParticipantSetsInfo {

    private List<MemberInfo> memberInfos;
    private int order;
    private String role;

    public ParticipantSetsInfo(List<MemberInfo> memberInfos, int order, String role) {
        this.memberInfos = memberInfos;
        this.order = order;
        this.role = role;
    }

    public void setMemberInfos(List<MemberInfo> memberInfos) {
        this.memberInfos = memberInfos;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public void setRole(String role) {
        this.role = role;
    }

	public List<MemberInfo> getMemberInfos() {
		return memberInfos;
	}

	public int getOrder() {
		return order;
	}

	public String getRole() {
		return role;
	}
    
    
}
