package com.histo.backupstatusviewer.service.impl;

import com.histo.backupstatusviewer.configuration.NextGenSeqDbCon;
import com.histo.backupstatusviewer.dto.*;
import com.histo.backupstatusviewer.entity.histosdb.PacBioJob;
import com.histo.backupstatusviewer.entity.pacbioanalysis.Job;
import com.histo.backupstatusviewer.repository.histosdb.PacBioJobDetailRepository;
import com.histo.backupstatusviewer.repository.histosdb.PacBioJobRepository;
import com.histo.backupstatusviewer.repository.pacbioanalysis.JobRepository;
import com.histo.backupstatusviewer.service.IlluminaPacbioBackupStatusService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class IlluminaPacbioBackupStatusServiceImpl implements IlluminaPacbioBackupStatusService {
    private static final Logger LOGGER = LogManager.getLogger(IlluminaPacbioBackupStatusServiceImpl.class);
    private final PacBioJobRepository pacBioJobRepository;
    private final PacBioJobDetailRepository pacBioJobDetailRepository;
    private final JobRepository jobRepository;

    public IlluminaPacbioBackupStatusServiceImpl(PacBioJobRepository pacBioJobRepository, PacBioJobDetailRepository pacBioJobDetailRepository, JobRepository jobRepository) {
        this.pacBioJobRepository = pacBioJobRepository;
        this.pacBioJobDetailRepository = pacBioJobDetailRepository;
        this.jobRepository = jobRepository;
    }

    @Override
    public ResponseEntity<Object> filterIlluminaPacbioBackupStatus(IlluminaPacbioFilterValue filterValue) {
        try {
            Connection con = NextGenSeqDbCon.getConnection();
            JdbcTemplate jdbcTemplate = new JdbcTemplate(new SingleConnectionDataSource(con, false));

            List<IlluminaPacbioBackupStatusDTO> data = jdbcTemplate.query("Exec FilterIlluminaPacbioBackupStatus ?,?,?,?"
                    , BeanPropertyRowMapper.newInstance(IlluminaPacbioBackupStatusDTO.class)
                    , filterValue.getFromDate()
                    , filterValue.getToDate()
                    , filterValue.getMachineType().getValue()
                    , filterValue.getMachineName().getValue());

            if ((filterValue.getMachineType() == MachineType.ALL && (filterValue.getMachineName() == MachineName.PACBIO || filterValue.getMachineName() == MachineName.ALL))
                    || filterValue.getMachineType() == MachineType.PACBIO) {

                String pacbioBackupQuery = "SELECT * FROM PacbioDataSecondaryBackupInformation WHERE BackupCompletionDate BETWEEN ? AND ? ORDER BY BackupCompletionDate DESC";
                List<PacbioDataSecondaryBackupInformationDTO> pacbioDatas = jdbcTemplate.query(pacbioBackupQuery
                        , BeanPropertyRowMapper.newInstance(PacbioDataSecondaryBackupInformationDTO.class)
                        , filterValue.getFromDate()
                        , filterValue.getToDate());

                if (!pacbioDatas.isEmpty()) {
                    for (PacbioDataSecondaryBackupInformationDTO pacbioData : pacbioDatas) {
                        List<Job> jobsList = jobRepository.findByJobId(pacbioData.getJobId().replaceFirst("0",""));
                        if (jobsList != null && !jobsList.isEmpty()) {
                            for (Job job : jobsList) {
                                PacBioJob pacbioJob = pacBioJobRepository.findByJobName(job.getJobName());
                                if (pacbioJob == null) {
                                    LOGGER.error("Not found Job in PacbioJob table. Job Name: {}", job.getJobName());
                                    continue;
                                }
                                long sampleCount = pacBioJobDetailRepository.countByJobId(pacbioJob.getJobId());
                                IlluminaPacbioBackupStatusDTO illuminaPacbioBackupStatusDTO = new IlluminaPacbioBackupStatusDTO();

                                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                                String experimentDate = dateFormat.format(pacbioJob.getCreatedOn());

                                String backupCompletionDate = dateFormat.format(pacbioData.getBackupCompletionDate());

                                illuminaPacbioBackupStatusDTO.setExperimentDate(experimentDate);
                                illuminaPacbioBackupStatusDTO.setExperimentId(pacbioJob.getJobId().intValue());
                                illuminaPacbioBackupStatusDTO.setExperimentName(job.getJobName());
                                illuminaPacbioBackupStatusDTO.setTotalSamples((int) sampleCount);
                                illuminaPacbioBackupStatusDTO.setMachineId(pacbioJob.getMachineId() == null ? 0 : pacbioJob.getMachineId().intValue());
                                illuminaPacbioBackupStatusDTO.setMachineType(MachineType.PACBIO.getValue());
                                illuminaPacbioBackupStatusDTO.setMachineName(MachineName.PACBIO.getValue());
                                illuminaPacbioBackupStatusDTO.setSecondaryBackupSamplesCount(0);
                                illuminaPacbioBackupStatusDTO.setBackupCompletionDate(backupCompletionDate);

                                data.add(illuminaPacbioBackupStatusDTO);
                            }
                        }
                    }

                    /*List<PacBioJob> pacbioJobs = pacBioJobRepository.findByCreatedOnBetweenAndQcJobFalseOrderByCreatedOnDesc(filterValue.getFromDate(), filterValue.getToDate());
                    for (PacBioJob pacbioJob : pacbioJobs) {
                        long sampleCount = pacBioJobDetailRepository.countByJobId(pacbioJob.getJobId());
                        IlluminaPacbioBackupStatusDTO illuminaPacbioBackupStatusDTO = new IlluminaPacbioBackupStatusDTO();

                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                        String experimentDate = dateFormat.format(pacbioJob.getCreatedOn());

                        illuminaPacbioBackupStatusDTO.setExperimentDate(experimentDate);
                        illuminaPacbioBackupStatusDTO.setExperimentId(pacbioJob.getJobId().intValue());
                        illuminaPacbioBackupStatusDTO.setExperimentName(pacbioJob.getJobName());
                        illuminaPacbioBackupStatusDTO.setTotalSamples((int) sampleCount);
                        illuminaPacbioBackupStatusDTO.setMachineId(pacbioJob.getMachineId() == null ? 0 : pacbioJob.getMachineId().intValue());
                        illuminaPacbioBackupStatusDTO.setMachineType(MachineType.PACBIO.getValue());
                        illuminaPacbioBackupStatusDTO.setMachineName(MachineName.PACBIO.getValue());
                        illuminaPacbioBackupStatusDTO.setSecondaryBackupSamplesCount(0);

                        data.add(illuminaPacbioBackupStatusDTO);
                    }*/
                }
            }
            // Sort the list based on the date property
            Collections.sort(data, Comparator.comparing(IlluminaPacbioBackupStatusDTO::getBackupCompletionDate).reversed());
            return new ResponseEntity<>(data, HttpStatus.OK);
        } catch (Exception e) {
            return catchException(e, "filterIlluminaPacbioBackupStatus()");
        }
    }

    @Override
    public ResponseEntity<Object> getFilterValues() {
        try {
            List<IlluminaPacbioFilters> filterValues = new ArrayList<>();
            IlluminaPacbioFilters allFilterValue = new IlluminaPacbioFilters();
            allFilterValue.setMachineType(MachineType.ALL);
            allFilterValue.setMachineNames(Arrays.asList(
                    MachineName.ALL
                    , MachineName.MISEQ
                    , MachineName.NOVASEQ
                    , MachineName.PACBIO
            ));
            IlluminaPacbioFilters illuminaFilterValue = new IlluminaPacbioFilters();
            illuminaFilterValue.setMachineType(MachineType.ILLUMINA);
            illuminaFilterValue.setMachineNames(Arrays.asList(
                    MachineName.ALL
                    , MachineName.MISEQ
                    , MachineName.NOVASEQ
            ));

            IlluminaPacbioFilters pacbioFilterValue = new IlluminaPacbioFilters();
            pacbioFilterValue.setMachineType(MachineType.PACBIO);
            pacbioFilterValue.setMachineNames(Arrays.asList(
                    MachineName.PACBIO
            ));

            filterValues.addAll(Arrays.asList(allFilterValue, illuminaFilterValue, pacbioFilterValue));
            return new ResponseEntity<>(filterValues, HttpStatus.OK);
        } catch (Exception e) {
            return catchException(e, "getFilterValues()");
        }
    }

    private ResponseEntity<Object> catchException(Exception e, String methodName) {
        LOGGER.error("{} error {}", methodName, e);
        return new ResponseEntity<>("Error", HttpStatus.CONFLICT);
    }
}
