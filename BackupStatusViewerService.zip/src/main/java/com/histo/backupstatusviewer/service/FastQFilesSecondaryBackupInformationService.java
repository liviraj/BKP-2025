package com.histo.backupstatusviewer.service;

import com.histo.backupstatusviewer.dto.FastQQueryParams;
import org.springframework.http.ResponseEntity;

public interface FastQFilesSecondaryBackupInformationService {
    public ResponseEntity<Object> getFastQFilesSecondaryBackupInformation(FastQQueryParams queryParams);
}
