package com.histo.backupstatusviewer.service.impl;


import com.histo.backupstatusviewer.configuration.HistoAdminDbCon;
import com.histo.backupstatusviewer.configuration.PropertyConfig;
import com.histo.backupstatusviewer.dto.*;
import com.histo.backupstatusviewer.service.DbStatusViewerService;
import com.histo.backupstatusviewer.util.Utility;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.util.*;

@Service
public class DbStatusViewerServiceImpl implements DbStatusViewerService {
    private static final Logger LOGGER = LogManager.getLogger(DbStatusViewerServiceImpl.class);

    @Autowired
    private PropertyConfig propertyConfig;

    @Override
    public void checkIsBackupCopiedInSecondaryLocation() {
        try {
            Connection con = HistoAdminDbCon.getConnection();
            JdbcTemplate jdbcTemplate = new JdbcTemplate(new SingleConnectionDataSource(con, false));

            String sql = "select * from DBBackupStatus where SecondaryBackupStatus <> 'success' and PrimaryBackupStatus = 'success' and date between DATEADD(DAY, -7, GETDATE()) and GETDATE();";
            List<DBStatusViewerMasterDTO> dbStatusList = jdbcTemplate.query(sql
                    , BeanPropertyRowMapper.newInstance(DBStatusViewerMasterDTO.class));
            if (dbStatusList.isEmpty()) {
                return;
            }
            InputInfoParam inputInfoParam = new InputInfoParam(propertyConfig);
            for (DBStatusViewerMasterDTO dbStatus : dbStatusList) {
                String histoNas1ServerName = "histonas1";
                String histoNas1BkServerName = "histonas1bk";

                if (!dbStatus.getBackupFileName().contains(propertyConfig.getSmbDomainName())) {
                    if (dbStatus.getBackupFileName().contains(histoNas1BkServerName)) {
                        dbStatus.setBackupFileName(dbStatus.getBackupFileName().replace(histoNas1BkServerName, propertyConfig.getHistoNas1BkServer()));
                    } else {
                        dbStatus.setBackupFileName(dbStatus.getBackupFileName().replace(histoNas1ServerName, propertyConfig.getDbStatusViewerSmbSourceServer()));
                    }
                }

                String basePath = "";
                if (dbStatus.getBackupFileName().contains(histoNas1BkServerName)) {
                    basePath = inputInfoParam.getHistoNas1BkShare().getSmbPath().toUncPath();
                } else {
                    basePath = inputInfoParam.getSourceShare().getSmbPath().toUncPath();
                }

                String primaryLocation = dbStatus.getBackupFileName().replace(basePath, "");
                String secondaryLocation = dbStatus.getBackupFileName().replace(basePath, "");
                primaryLocation = primaryLocation.replace("\\", "/");
                secondaryLocation = secondaryLocation.replace("\\", "/");
                if (primaryLocation.charAt(0) == '/') {
                    primaryLocation = primaryLocation.replaceFirst("/", "");
                }
                if (secondaryLocation.charAt(0) == '/') {
                    secondaryLocation = secondaryLocation.replaceFirst("/", "");
                }

                boolean isSecondaryLocFileExist = inputInfoParam.getDestinationShare().fileExists(secondaryLocation);
                boolean isPrimaryLocFileExist = inputInfoParam.getSourceShare().fileExists(primaryLocation);

                if (!isSecondaryLocFileExist || !isPrimaryLocFileExist) {
                    String sqlStatusUpdate = "UPDATE DBBackupStatus set SecondaryBackupStatus = 'Failure', APIRunDateTime=? where DBBackupScheduleID = ?;";
                    int updateCount = jdbcTemplate.update(sqlStatusUpdate
                            , new Date()
                            , dbStatus.getDbBackupScheduleId());
                    continue;
                }
                long smbPrimaryFileSize = 0;
                if (dbStatus.getBackupFileName().contains(histoNas1BkServerName)) {
                    smbPrimaryFileSize = Utility.getSMBFileSize(inputInfoParam.getHistoNas1BkShare(), primaryLocation);
                } else {
                    smbPrimaryFileSize = Utility.getSMBFileSize(inputInfoParam.getSourceShare(), primaryLocation);
                }
                long smbSecondaryFileSize = Utility.getSMBFileSize(inputInfoParam.getDestinationShare(), secondaryLocation);

                if (smbPrimaryFileSize == smbSecondaryFileSize) {
                    String sqlStatusUpdate = "UPDATE DBBackupStatus set SecondaryBackupStatus = 'Success', APIRunDateTime=? where DBBackupScheduleID = ?;";
                    int updateCount = jdbcTemplate.update(sqlStatusUpdate
                            , new Date()
                            , dbStatus.getDbBackupScheduleId());
                    continue;
                } else {
                    String sqlStatusUpdate = "UPDATE DBBackupStatus set SecondaryBackupStatus = 'In Progress', APIRunDateTime=? where DBBackupScheduleID = ?;";
                    int updateCount = jdbcTemplate.update(sqlStatusUpdate
                            , new Date()
                            , dbStatus.getDbBackupScheduleId());
                    continue;
                }
            }

        } catch (Exception e) {
            catchException(e, "checkIsBackupCopiedInSecondaryLocation()");
        }
    }

    @Override
    public ResponseEntity<Object> filterDbBackupStatusViewer(DbBackupStatusViewerQueryParams queryParams) {
        try {
            Connection con = HistoAdminDbCon.getConnection();
            JdbcTemplate jdbcTemplate = new JdbcTemplate(new SingleConnectionDataSource(con, false));

            if (jdbcTemplate != null && con != null) {
                LOGGER.info("DB connection established. Con details: {}", con.getCatalog());
            }
            String query = "Exec DatabaseBackupStatusViewer ?,?,?,?,?,?,?";
            List<DbBackupStatusViewerDTO> data = jdbcTemplate.query(query
                    , BeanPropertyRowMapper.newInstance(DbBackupStatusViewerDTO.class)
                    , queryParams.getServerType()
                    , queryParams.getServerName()
                    , queryParams.getDatabaseName()
                    , queryParams.getTypeOfBackup()
                    , queryParams.getFromDate()
                    , queryParams.getToDate()
                    , queryParams.getSecondaryBackupStatus()
            );

            for (DbBackupStatusViewerDTO viewData : data) {
                data.get(data.indexOf(viewData)).setScheduledDate(viewData.getDate().toString() + " " + viewData.getTime().toString() + ".000");
                // Check if milliseconds part has only one digit
                if (StringUtils.isNotBlank(viewData.getApiRunDateTime()) && viewData.getApiRunDateTime().matches(".*\\.\\d{2}$")) {
                    // Add a zero to the milliseconds part
                    data.get(data.indexOf(viewData)).setApiRunDateTime(viewData.getApiRunDateTime().concat("0"));
                }
                if (StringUtils.isBlank(viewData.getApiRunDateTime())) {
                    data.get(data.indexOf(viewData)).setApiRunDateTime("");
                }
            }

            return new ResponseEntity<>(data, HttpStatus.OK);
        } catch (Exception e) {
            return catchException(e, "filterDbBackupStatusViewer()");
        }
    }

    @Override
    public ResponseEntity<Object> getDbBackupStatusFilters() {
        try {
            List<String> serverTypes = Arrays.asList("All", "Production", "Non-Production");
            List<DBBackupDataBase> databaseNames = new ArrayList<>();

            Connection con = HistoAdminDbCon.getConnection();
            JdbcTemplate jdbcTemplate = new JdbcTemplate(new SingleConnectionDataSource(con, false));

            String backupSql = "select distinct Backuptype from DbBackupStatus;";
            List<String> typeOfBackups = jdbcTemplate.query(backupSql
                    , (resultSet, rowNum) -> resultSet.getString(1));
            typeOfBackups.add(0, "All");

            String serverSql = "select distinct DBServerName from DbBackupStatus;";
            List<String> serverNames = jdbcTemplate.query(serverSql
                    , (resultSet, rowNum) -> resultSet.getString(1));

            for (String serverName : serverNames) {
                String dBsSql = "select distinct DatabaseName from DbBackupStatus where DBServerName = '" + serverName + "';";
                List<String> dbs = jdbcTemplate.query(dBsSql
                        , (resultSet, rowNum) -> resultSet.getString(1));
                Collections.sort(dbs, String.CASE_INSENSITIVE_ORDER);
                dbs.add(0, "All");
                dbs.add(1, "All Important Databases");

                DBBackupDataBase dataBase = new DBBackupDataBase();
                dataBase.setServerName(serverName);
                dataBase.setDataBaseNames(dbs);

                databaseNames.add(dataBase);
            }
            serverNames.add(0, "All");

            List<String> secondaryBackupStatusList = Arrays.asList("All", "Failure", "In Progress", "Success");
            DbBackupStatusFilterDTO data = new DbBackupStatusFilterDTO();
            data.setServerTypes(serverTypes);
            data.setServerNames(serverNames);
            data.setDatabaseNames(databaseNames);
            data.setTypeOfBackups(typeOfBackups);
            data.setSecondaryBackupStatusList(secondaryBackupStatusList);

            return new ResponseEntity<>(data, HttpStatus.OK);
        } catch (Exception e) {
            return catchException(e, "getDbBackupStatusFilters()");
        }
    }

    private ResponseEntity<Object> catchException(Exception e, String methodName) {
        LOGGER.error("{} error {}", methodName, e);
        return new ResponseEntity<>("Error", HttpStatus.CONFLICT);
    }
}
