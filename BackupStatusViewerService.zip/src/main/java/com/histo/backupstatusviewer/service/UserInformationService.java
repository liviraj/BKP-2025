package com.histo.backupstatusviewer.service;

import com.histo.backupstatusviewer.dto.LoginDTO;
import com.histo.backupstatusviewer.dto.UserInfoDTO;
import com.histo.backupstatusviewer.entity.webmilhv.T_User;

import java.util.Optional;


public interface UserInformationService {
	public Optional<T_User> findByLoginName(String LoginName);
	
	public UserInfoDTO userLogin(LoginDTO login);
	public String userLoginOff(int sessionID);
	public UserInfoDTO findUserByEmail(String email);
}
