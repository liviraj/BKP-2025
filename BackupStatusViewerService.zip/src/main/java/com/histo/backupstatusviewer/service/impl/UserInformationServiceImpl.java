package com.histo.backupstatusviewer.service.impl;

import com.histo.backupstatusviewer.dto.LoginDTO;
import com.histo.backupstatusviewer.dto.UserInfoDTO;
import com.histo.backupstatusviewer.entity.histosdb.UserInformation;
import com.histo.backupstatusviewer.entity.webmilhv.TLoginLog;
import com.histo.backupstatusviewer.entity.webmilhv.T_User;
import com.histo.backupstatusviewer.repository.histosdb.UserInfoRepository;
import com.histo.backupstatusviewer.repository.webmilhv.LoginLogRepository;
import com.histo.backupstatusviewer.repository.webmilhv.UserInformationRepository;
import com.histo.backupstatusviewer.service.UserInfoService;
import com.histo.backupstatusviewer.service.UserInformationService;
import com.histo.backupstatusviewer.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.Optional;

@Service
public class UserInformationServiceImpl implements UserInformationService {

	@Autowired
	UserInformationRepository tUserInformationRepository;

	@Autowired
	LoginLogRepository loginLogRepository;

	@Autowired
	UserInfoService service;

	@Autowired
	UserInfoRepository userInformationRepo;

	@Override
	public Optional<T_User> findByLoginName(String LoginName) {
		return tUserInformationRepository.findByLoginName(LoginName);
	}

	@Override
	public UserInfoDTO userLogin(LoginDTO login) {

		UserInfoDTO userInfo = null;
		Optional<T_User> user = tUserInformationRepository.findByLoginName(login.getUsername());

		if (user.isPresent()) {
			String decodePassword = Utility.Decode(user.get().getPassword());
			if(decodePassword.equals(login.getPassword())) {
				TLoginLog loginLog = new TLoginLog(0, user.get().getUserId(), new Timestamp(System.currentTimeMillis()),
						null, "Blot", "", "", "", 0);
	
				TLoginLog logSave = loginLogRepository.save(loginLog);
	
				if (logSave != null && logSave.getLoginID() != null) {
					userInfo = new UserInfoDTO(user.get().getFirstName(), user.get().getLastName(), user.get().getUserId(),
							logSave.getLoginID());
				}
			}
		}
		return userInfo;
	}

	@Override
	public String userLoginOff(int sessionID) {
			Optional<TLoginLog> loginLog = loginLogRepository.findByLoginID(sessionID);
			if(loginLog.isPresent()) {
				Timestamp timestamp = new Timestamp(System.currentTimeMillis());
				loginLog.get().setLogoutTime(timestamp);
				loginLogRepository.save(loginLog.get());
				
			}
			return "Logged off successfully";
	}

	@Override
	public UserInfoDTO findUserByEmail(String email) {
		Optional<UserInformation>user=service.findUserByEmail(email);
		UserInfoDTO userInfo=null;
		if (user.isPresent()) {
				TLoginLog loginLog = new TLoginLog(0, user.get().getId(), new Timestamp(System.currentTimeMillis()),
						null, "Blot", "", "", "", 0);
				TLoginLog logSave = loginLogRepository.save(loginLog);
				if(logSave != null && logSave.getLoginID() != null) {
					userInfo = new UserInfoDTO(user.get().getFirstName(), user.get().getLastName(), user.get().getId(),
							logSave.getLoginID());
				}
		}
		return userInfo;
	}
}
