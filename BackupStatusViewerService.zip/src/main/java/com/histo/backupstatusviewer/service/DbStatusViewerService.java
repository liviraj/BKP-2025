package com.histo.backupstatusviewer.service;

import com.histo.backupstatusviewer.dto.DbBackupStatusViewerQueryParams;
import org.springframework.http.ResponseEntity;

public interface DbStatusViewerService {
    public void checkIsBackupCopiedInSecondaryLocation();
    public ResponseEntity<Object> filterDbBackupStatusViewer(DbBackupStatusViewerQueryParams queryParams);
    public ResponseEntity<Object> getDbBackupStatusFilters();
}
