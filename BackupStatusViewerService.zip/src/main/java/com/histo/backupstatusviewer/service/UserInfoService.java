package com.histo.backupstatusviewer.service;

import java.util.Optional;

public interface UserInfoService {
	public Optional<com.histo.backupstatusviewer.entity.histosdb.UserInformation> findUserByEmail(String email);
}
