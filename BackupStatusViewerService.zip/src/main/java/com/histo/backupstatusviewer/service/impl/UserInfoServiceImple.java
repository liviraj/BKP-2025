package com.histo.backupstatusviewer.service.impl;

import com.histo.backupstatusviewer.entity.histosdb.UserInformation;
import com.histo.backupstatusviewer.repository.histosdb.UserInfoRepository;
import com.histo.backupstatusviewer.service.UserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@Transactional("histoTransactionManager")
public class UserInfoServiceImple implements UserInfoService {

	@Autowired
	UserInfoRepository userInformationRepo;
	
	@Override
	public Optional<UserInformation> findUserByEmail(String email) {

		Optional<UserInformation> userInfo = userInformationRepo.findByEmailAddress(email);
		return userInfo;
	}

}
