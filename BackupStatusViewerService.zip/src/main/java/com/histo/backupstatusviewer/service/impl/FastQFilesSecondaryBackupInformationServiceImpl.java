package com.histo.backupstatusviewer.service.impl;

import com.histo.backupstatusviewer.configuration.NextGenSeqDbCon;
import com.histo.backupstatusviewer.dto.FastQMeachineType;
import com.histo.backupstatusviewer.dto.FastQQueryParams;
import com.histo.backupstatusviewer.dto.MiSeqSecondaryBackupInformationDTO;
import com.histo.backupstatusviewer.dto.PacbioSecondaryBackupInformationDTO;
import com.histo.backupstatusviewer.service.FastQFilesSecondaryBackupInformationService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.util.List;

@Service
public class FastQFilesSecondaryBackupInformationServiceImpl implements FastQFilesSecondaryBackupInformationService {
    private static final Logger LOGGER = LogManager.getLogger(FastQFilesSecondaryBackupInformationServiceImpl.class);
    @Override
    public ResponseEntity<Object> getFastQFilesSecondaryBackupInformation(FastQQueryParams queryParams) {
        try {
            Connection con = NextGenSeqDbCon.getConnection();
            JdbcTemplate jdbcTemplate = new JdbcTemplate(new SingleConnectionDataSource(con, false));

            if (queryParams.getFastQMeachineType() == FastQMeachineType.MISEQ) {
                List<MiSeqSecondaryBackupInformationDTO> data= jdbcTemplate.query(
                        "EXEC GetFastQFilesSecondaryBackupInformation ?,?,?"
                        , BeanPropertyRowMapper.newInstance(MiSeqSecondaryBackupInformationDTO.class)
                        , queryParams.getFastQMeachineType().MISEQ.value
                        , queryParams.getFromDate()
                        , queryParams.getToDate()
                );
                return new ResponseEntity<>(data, HttpStatus.OK);
            } else {
                List<PacbioSecondaryBackupInformationDTO> data= jdbcTemplate.query(
                        "EXEC GetFastQFilesSecondaryBackupInformation ?,?,?"
                        , BeanPropertyRowMapper.newInstance(PacbioSecondaryBackupInformationDTO.class)
                        , queryParams.getFastQMeachineType().PACBIO.value
                        , queryParams.getFromDate()
                        , queryParams.getToDate()
                );
                return new ResponseEntity<>(data, HttpStatus.OK);
            }
        }catch (Exception e) {
            return catchException(e, "getFastQFilesSecondaryBackupInformation()");
        }
    }

    private ResponseEntity<Object> catchException(Exception e, String methodName) {
        LOGGER.error("{} error {}", e);
        return new ResponseEntity<>("Error", HttpStatus.CONFLICT);
    }
}
