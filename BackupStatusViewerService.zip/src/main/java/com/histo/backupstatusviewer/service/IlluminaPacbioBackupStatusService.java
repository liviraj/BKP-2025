package com.histo.backupstatusviewer.service;

import com.histo.backupstatusviewer.dto.IlluminaPacbioFilterValue;
import org.springframework.http.ResponseEntity;

public interface IlluminaPacbioBackupStatusService {
    public ResponseEntity<Object> filterIlluminaPacbioBackupStatus(IlluminaPacbioFilterValue filterValue);
    public ResponseEntity<Object> getFilterValues();
}
