package com.histo.backupstatusviewer.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PropertyConfig {
    @Value("${smb.domain.name}")
    private String smbDomainName;

    @Value("${db-status-viewer.smb.source.server}")
    private String dbStatusViewerSmbSourceServer;
    @Value("${db-status-viewer.smb.source.share}")
    private String dbStatusViewerSmbSourceShare;
    @Value("${db-status-viewer.smb.source.username}")
    private String dbStatusViewerSmbSourceUsername;
    @Value("${db-status-viewer.smb.source.password}")
    private String dbStatusViewerSmbSourcePassword;

    @Value("${db-status-viewer.smb.destination.server}")
    private String dbStatusViewerSmbDestServer;
    @Value("${db-status-viewer.smb.destination.share}")
    private String dbStatusViewerSmbDestSharer;
    @Value("${db-status-viewer.smb.destination.username}")
    private String dbStatusViewerSmbSDestUsername;
    @Value("${db-status-viewer.smb.destination.password}")
    private String dbStatusViewerSmbSDestPassword;

    @Value("${db-status-viewer.smb.histonas1bk.server}")
    private String histoNas1BkServer;
    @Value("${db-status-viewer.smb.histonas1bk.share}")
    private String histoNas1BkShare;
    @Value("${db-status-viewer.smb.histonas1bk.username}")
    private String histoNas1BkUsername;
    @Value("${db-status-viewer.smb.histonas1bk.password}")
    private String histoNas1BkPassword;

    public String getSmbDomainName() {
        return smbDomainName;
    }

    public void setSmbDomainName(String smbDomainName) {
        this.smbDomainName = smbDomainName;
    }

    public String getDbStatusViewerSmbSourceServer() {
        return dbStatusViewerSmbSourceServer;
    }

    public void setDbStatusViewerSmbSourceServer(String dbStatusViewerSmbSourceServer) {
        this.dbStatusViewerSmbSourceServer = dbStatusViewerSmbSourceServer;
    }

    public String getDbStatusViewerSmbSourceShare() {
        return dbStatusViewerSmbSourceShare;
    }

    public void setDbStatusViewerSmbSourceShare(String dbStatusViewerSmbSourceShare) {
        this.dbStatusViewerSmbSourceShare = dbStatusViewerSmbSourceShare;
    }

    public String getDbStatusViewerSmbSourceUsername() {
        return dbStatusViewerSmbSourceUsername;
    }

    public void setDbStatusViewerSmbSourceUsername(String dbStatusViewerSmbSourceUsername) {
        this.dbStatusViewerSmbSourceUsername = dbStatusViewerSmbSourceUsername;
    }

    public String getDbStatusViewerSmbSourcePassword() {
        return dbStatusViewerSmbSourcePassword;
    }

    public void setDbStatusViewerSmbSourcePassword(String dbStatusViewerSmbSourcePassword) {
        this.dbStatusViewerSmbSourcePassword = dbStatusViewerSmbSourcePassword;
    }

    public String getDbStatusViewerSmbDestServer() {
        return dbStatusViewerSmbDestServer;
    }

    public void setDbStatusViewerSmbDestServer(String dbStatusViewerSmbDestServer) {
        this.dbStatusViewerSmbDestServer = dbStatusViewerSmbDestServer;
    }

    public String getDbStatusViewerSmbDestSharer() {
        return dbStatusViewerSmbDestSharer;
    }

    public void setDbStatusViewerSmbDestSharer(String dbStatusViewerSmbDestSharer) {
        this.dbStatusViewerSmbDestSharer = dbStatusViewerSmbDestSharer;
    }

    public String getDbStatusViewerSmbSDestUsername() {
        return dbStatusViewerSmbSDestUsername;
    }

    public void setDbStatusViewerSmbSDestUsername(String dbStatusViewerSmbSDestUsername) {
        this.dbStatusViewerSmbSDestUsername = dbStatusViewerSmbSDestUsername;
    }

    public String getDbStatusViewerSmbSDestPassword() {
        return dbStatusViewerSmbSDestPassword;
    }

    public void setDbStatusViewerSmbSDestPassword(String dbStatusViewerSmbSDestPassword) {
        this.dbStatusViewerSmbSDestPassword = dbStatusViewerSmbSDestPassword;
    }

    public String getHistoNas1BkServer() {
        return histoNas1BkServer;
    }

    public void setHistoNas1BkServer(String histoNas1BkServer) {
        this.histoNas1BkServer = histoNas1BkServer;
    }

    public String getHistoNas1BkShare() {
        return histoNas1BkShare;
    }

    public void setHistoNas1BkShare(String histoNas1BkShare) {
        this.histoNas1BkShare = histoNas1BkShare;
    }

    public String getHistoNas1BkUsername() {
        return histoNas1BkUsername;
    }

    public void setHistoNas1BkUsername(String histoNas1BkUsername) {
        this.histoNas1BkUsername = histoNas1BkUsername;
    }

    public String getHistoNas1BkPassword() {
        return histoNas1BkPassword;
    }

    public void setHistoNas1BkPassword(String histoNas1BkPassword) {
        this.histoNas1BkPassword = histoNas1BkPassword;
    }

    @Override
    public String toString() {
        return "PropertyConfig{" +
                "smbDomainName='" + smbDomainName + '\'' +
                ", dbStatusViewerSmbSourceServer='" + dbStatusViewerSmbSourceServer + '\'' +
                ", dbStatusViewerSmbSourceShare='" + dbStatusViewerSmbSourceShare + '\'' +
                ", dbStatusViewerSmbSourceUsername='" + dbStatusViewerSmbSourceUsername + '\'' +
                ", dbStatusViewerSmbSourcePassword='" + dbStatusViewerSmbSourcePassword + '\'' +
                ", dbStatusViewerSmbDestServer='" + dbStatusViewerSmbDestServer + '\'' +
                ", dbStatusViewerSmbDestSharer='" + dbStatusViewerSmbDestSharer + '\'' +
                ", dbStatusViewerSmbSDestUsername='" + dbStatusViewerSmbSDestUsername + '\'' +
                ", dbStatusViewerSmbSDestPassword='" + dbStatusViewerSmbSDestPassword + '\'' +
                ", histoNas1BkServer='" + histoNas1BkServer + '\'' +
                ", histoNas1BkShare='" + histoNas1BkShare + '\'' +
                ", histoNas1BkUsername='" + histoNas1BkUsername + '\'' +
                ", histoNas1BkPassword='" + histoNas1BkPassword + '\'' +
                '}';
    }
}
