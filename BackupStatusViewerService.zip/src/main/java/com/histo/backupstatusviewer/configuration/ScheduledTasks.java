package com.histo.backupstatusviewer.configuration;

import com.histo.backupstatusviewer.controller.DbStatusViewerController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Component
public class ScheduledTasks {
    @Autowired
    DbStatusViewerController dbStatusViewerController;

    private static final Logger logger = LoggerFactory.getLogger(ScheduledTasks.class);

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

    // @Scheduled(cron = "* * * ? * *") // every 15 minutes 0 */15 * ? * * // every one second * * * ? * *
    // @Scheduled(cron = "0 0 23 * * ?") // every day 11:00 pm the scheduler will trigger
    public void scheduleSecondaryLocationSyncTaskWithCronExpression() {
        logger.info("Cron Task :: Execution Time Start - {}", dateTimeFormatter.format(LocalDateTime.now()));
        dbStatusViewerController.updateDbSecondaryStatus();
        logger.info("Cron Task :: Execution Time End - {}", dateTimeFormatter.format(LocalDateTime.now()));
    }
}
