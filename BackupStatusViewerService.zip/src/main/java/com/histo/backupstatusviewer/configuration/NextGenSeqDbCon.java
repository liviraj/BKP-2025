package com.histo.backupstatusviewer.configuration;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

@Configuration
public class NextGenSeqDbCon {

	private static Connection sqlcon = null;
	public static String url;
	public static String Uname;
	public static String Pswd;

	@Value("${app.datasource.next_gen_seq.url}")
	public void setNextGenSeqURL(String nextGenSeqURL) {
		NextGenSeqDbCon.url = nextGenSeqURL;
	}

	@Value("${app.datasource.next_gen_seq.username}")
	public void setNextGenSeqUsername(String nextGenSeqUsername) {
		NextGenSeqDbCon.Uname = nextGenSeqUsername;
	}

	@Value("${app.datasource.next_gen_seq.password}")
	public void setNextGenSeqPassword(String nextGenSeqPassword) {
		NextGenSeqDbCon.Pswd = nextGenSeqPassword;
	}

	@PostConstruct
	private static Connection getSqlConnection() {
		try {
			DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
			sqlcon = DriverManager.getConnection(url, Uname, Pswd);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sqlcon;
	}

	public static synchronized Connection getConnection() {
		try {
			if (sqlcon == null || sqlcon.isClosed())
				getSqlConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sqlcon;

	}

}
