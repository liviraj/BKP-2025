package com.histo.backupstatusviewer.configuration;

import jakarta.persistence.EntityManagerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
    entityManagerFactoryRef = "histoEntityManagerFactory",
    transactionManagerRef = "histoTransactionManager",
    basePackages = {
        "com.histo.backupstatusviewer.repository.histosdb"
    }
)
public class HistosDbConfig {

    @Bean(name = "histoDataSource")
    @ConfigurationProperties(prefix = "app.datasource")
    public DataSource histoDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "histoEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean
    entityManagerFactory(
        EntityManagerFactoryBuilder builder,
        @Qualifier("histoDataSource") DataSource dataSource) {
        return builder.dataSource(dataSource).packages("com.histo.backupstatusviewer.entity.histosdb").persistenceUnit("HistoSDB").build();
    }

    @Bean(name = "histoTransactionManager")
    public PlatformTransactionManager histoTransactionManager(
        @Qualifier("histoEntityManagerFactory") EntityManagerFactory histoEntityManagerFactory ) {
        return new JpaTransactionManager(histoEntityManagerFactory);
    }
}