package com.histo.backupstatusviewer.configuration;


import jakarta.persistence.EntityManagerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
    entityManagerFactoryRef = "webmilHVEntityManagerFactory",
    transactionManagerRef = "webmilHVTransactionManager",
    basePackages = {
        "com.histo.backupstatusviewer.repository.webmilhv"
    }
)
public class WebmilHVconfig {

    @Primary
    @Bean(name = "webmilHVDataSource")
    @ConfigurationProperties(prefix = "spring.datasource")
    public DataSource webmilHVDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Primary
    @Bean(name = "webmilHVEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean
    entityManagerFactory(
        EntityManagerFactoryBuilder builder,
        @Qualifier("webmilHVDataSource") DataSource dataSource) {
        return builder.dataSource(dataSource).packages("com.histo.backupstatusviewer.entity.webmilhv").persistenceUnit("webmilHV").build();
    }

    @Primary
    @Bean(name = "webmilHVTransactionManager")
    public PlatformTransactionManager webmilHVTransactionManager(
        @Qualifier("webmilHVEntityManagerFactory") EntityManagerFactory webmilHVEntityManagerFactory ) {
        return new JpaTransactionManager(webmilHVEntityManagerFactory);
    }
}
