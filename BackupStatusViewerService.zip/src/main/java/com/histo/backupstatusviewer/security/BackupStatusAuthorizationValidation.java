package com.histo.backupstatusviewer.security;

import com.histo.backupstatusviewer.configuration.HistoAdminDbCon;
import com.histo.backupstatusviewer.dto.DBBackupStatusViewers;
import com.histo.backupstatusviewer.util.HistoTyperConstants;
import com.microsoft.graph.authentication.IAuthenticationProvider;
import com.microsoft.graph.core.ClientException;
import com.microsoft.graph.requests.GraphServiceClient;
import com.nimbusds.jwt.JWT;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.JWTParser;
import okhttp3.Request;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.util.Date;
import java.util.concurrent.CompletableFuture;

@Component
public class BackupStatusAuthorizationValidation {

    private static final Logger logger = LogManager.getLogger(BackupStatusAuthorizationValidation.class.getName());

    public ResponseEntity<Object> isAuthorize(String token) {

        try {
            if (StringUtils.isNotBlank(token)) {
                String emailId = "";
                try {
                    IAuthenticationProvider authProvider = requestUrl -> {
                        CompletableFuture<String> future = new CompletableFuture<>();
                        future.complete(token);
                        return future;
                    };

                    GraphServiceClient<Request> graphClient = GraphServiceClient.builder()
                            .authenticationProvider(authProvider).buildClient();

                    emailId = graphClient.me().buildRequest().get().userPrincipalName;
                } catch (ClientException e) {
                    JWT jwt = JWTParser.parse(token);
                    JWTClaimsSet claimsSet = jwt.getJWTClaimsSet();
                    if (isTokenExpire(claimsSet.getExpirationTime())) {
                        emailId = "";
                    } else {
                        emailId = (String) claimsSet.getClaim(HistoTyperConstants.EMAIL_CLAIM_NAME);
                    }
                }
                if (StringUtils.isNotBlank(emailId)) {
                    Connection con = HistoAdminDbCon.getConnection();
                    JdbcTemplate jdbcTemplate = new JdbcTemplate(new SingleConnectionDataSource(con, false));
                    String sql = "select sv.autoId, sv.emailAddress from DBBackupStatusViewers sv where sv.emailAddress = ?;";
                    DBBackupStatusViewers backupStatusViewers = jdbcTemplate.queryForObject(sql,
                            BeanPropertyRowMapper.newInstance(DBBackupStatusViewers.class), emailId);
                    if (backupStatusViewers != null) {
                        return new ResponseEntity<>("User Found", HttpStatus.OK);
                    } else {
                        return new ResponseEntity<>("User Not Found", HttpStatus.CONFLICT);
                    }
                } else {
                    return new ResponseEntity<>("User Not Found", HttpStatus.CONFLICT);
                }
            } else {
                return new ResponseEntity<>("Token Not Valid", HttpStatus.UNAUTHORIZED);
            }

        } catch (Exception e) {
            logger.error("Exception message: {}", e);
            return new ResponseEntity<>("Token Not Valid", HttpStatus.UNAUTHORIZED);

        }
    }

    private boolean isTokenExpire(Date expiryDate) {
        // Extract the expiration time claim
        return expiryDate != null && expiryDate.before(new Date());
    }
}
