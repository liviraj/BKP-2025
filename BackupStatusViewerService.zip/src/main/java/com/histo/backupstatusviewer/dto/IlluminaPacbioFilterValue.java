package com.histo.backupstatusviewer.dto;


import lombok.*;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class IlluminaPacbioFilterValue {
    private Date fromDate;
    private Date toDate;
    private MachineType machineType;
    private MachineName machineName;
}
