package com.histo.backupstatusviewer.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Getter
@Setter
@ToString
public class PacbioDataSecondaryBackupInformationDTO {
    private Long autoId;
    private String jobId;
    private String primaryExperimentLocation;
    private String secondaryExperimentLocation;
    private Date backupCompletionDate;
}
