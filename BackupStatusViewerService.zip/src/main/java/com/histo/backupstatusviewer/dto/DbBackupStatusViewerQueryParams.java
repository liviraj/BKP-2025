package com.histo.backupstatusviewer.dto;

import lombok.*;

import java.util.Date;

@NoArgsConstructor
public class DbBackupStatusViewerQueryParams {
    private String serverType;
    private String serverName;
    private String databaseName;
    private String typeOfBackup;
    private Date fromDate;
    private Date toDate;
    private String secondaryBackupStatus;

    public DbBackupStatusViewerQueryParams(String serverType, String serverName, String databaseName, String typeOfBackup, Date fromDate, Date toDate, String secondaryBackupStatus) {
        this.serverType = serverType;
        this.serverName = serverName;
        this.databaseName = databaseName;
        this.typeOfBackup = typeOfBackup;
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.secondaryBackupStatus = secondaryBackupStatus;
    }

    public String getServerType() {
        return serverType;
    }

    public void setServerType(String serverType) {
        this.serverType = serverType;
    }

    public String getServerName() {
        return serverName;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public void setDatabaseName(String databaseName) {
        this.databaseName = databaseName;
    }

    public String getTypeOfBackup() {
        return typeOfBackup;
    }

    public void setTypeOfBackup(String typeOfBackup) {
        this.typeOfBackup = typeOfBackup;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    public String getSecondaryBackupStatus() {
        return secondaryBackupStatus;
    }

    public void setSecondaryBackupStatus(String secondaryBackupStatus) {
        this.secondaryBackupStatus = secondaryBackupStatus;
    }

    @Override
    public String toString() {
        return "DbBackupStatusViewerQueryParams{" +
                "serverType='" + serverType + '\'' +
                ", serverName='" + serverName + '\'' +
                ", databaseName='" + databaseName + '\'' +
                ", typeOfBackup='" + typeOfBackup + '\'' +
                ", fromDate=" + fromDate +
                ", toDate=" + toDate +
                ", secondaryBackupStatus='" + secondaryBackupStatus + '\'' +
                '}';
    }
}
