package com.histo.backupstatusviewer.dto;

import lombok.NoArgsConstructor;

import java.sql.Date;
import java.sql.Time;

@NoArgsConstructor
public class DBStatusViewerMasterDTO {
    private Integer dbBackupScheduleId;
    private String dbServerName;
    private String databaseName;
    private Date date;
    private Time time;
    private String backupType;
    private String primaryBackupStatus;
    private String backupFileName;
    private String secondaryBackupStatus;

    public Integer getDbBackupScheduleId() {
        return dbBackupScheduleId;
    }

    public void setDbBackupScheduleId(Integer dbBackupScheduleId) {
        this.dbBackupScheduleId = dbBackupScheduleId;
    }

    public String getDbServerName() {
        return dbServerName;
    }

    public void setDbServerName(String dbServerName) {
        this.dbServerName = dbServerName;
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public void setDatabaseName(String databaseName) {
        this.databaseName = databaseName;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Time getTime() {
        return time;
    }

    public void setTime(Time time) {
        this.time = time;
    }

    public String getBackupType() {
        return backupType;
    }

    public void setBackupType(String backupType) {
        this.backupType = backupType;
    }

    public String getPrimaryBackupStatus() {
        return primaryBackupStatus;
    }

    public void setPrimaryBackupStatus(String primaryBackupStatus) {
        this.primaryBackupStatus = primaryBackupStatus;
    }

    public String getBackupFileName() {
        return backupFileName;
    }

    public void setBackupFileName(String backupFileName) {
        this.backupFileName = backupFileName;
    }

    public String getSecondaryBackupStatus() {
        return secondaryBackupStatus;
    }

    public void setSecondaryBackupStatus(String secondaryBackupStatus) {
        this.secondaryBackupStatus = secondaryBackupStatus;
    }

    @Override
    public String toString() {
        return "DBStatusViewerMasterDTO{" +
                "dbBackupScheduleId=" + dbBackupScheduleId +
                ", dbServerName='" + dbServerName + '\'' +
                ", databaseName='" + databaseName + '\'' +
                ", date=" + date +
                ", time=" + time +
                ", backupType='" + backupType + '\'' +
                ", primaryBackupStatus='" + primaryBackupStatus + '\'' +
                ", backupFileName='" + backupFileName + '\'' +
                ", secondaryBackupStatus='" + secondaryBackupStatus + '\'' +
                '}';
    }
}
