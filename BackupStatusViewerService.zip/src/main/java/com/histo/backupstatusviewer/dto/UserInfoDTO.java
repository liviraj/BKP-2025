package com.histo.backupstatusviewer.dto;

public class UserInfoDTO {
	private String firstName;
	private String lastName;
	private Long userId;
	private Integer loginID;
	public UserInfoDTO() {
		super();
	}
	
	public UserInfoDTO(String firstName, String lastName, Long userId, Integer loginID) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.userId = userId;
		this.loginID = loginID;
	}

	public UserInfoDTO(String firstName, String lastName, Integer userId, Integer loginID) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.userId = (long)userId;
		this.loginID = loginID;
	}

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Integer getLoginID() {
		return loginID;
	}
	public void setLoginID(Integer loginID) {
		this.loginID = loginID;
	}
	@Override
	public String toString() {
		return "UserInfoDTO [firstName=" + firstName + ", lastName=" + lastName + ", userId=" + userId + ", loginID="
				+ loginID + "]";
	}
	
}
