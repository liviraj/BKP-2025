package com.histo.backupstatusviewer.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class SecondaryLocationCheckInput {
    private int dbBackupScheduleId;
    private String primaryLocation;
    private String secondaryLocation;
}
