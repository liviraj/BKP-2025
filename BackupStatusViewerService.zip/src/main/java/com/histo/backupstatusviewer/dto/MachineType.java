package com.histo.backupstatusviewer.dto;

public enum MachineType {
    ALL("All"),ILLUMINA("Illumina"), PACBIO("Pacbio");

    private String value;

    MachineType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
