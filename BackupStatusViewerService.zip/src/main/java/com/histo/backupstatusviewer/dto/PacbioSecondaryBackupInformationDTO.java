package com.histo.backupstatusviewer.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class PacbioSecondaryBackupInformationDTO {
    private String machine;
    private String jobName;
    private String dateOfBackup;
    private boolean backupStatus;
    private String secondaryBackupLocation;
    private String secondaryBackupLocationTemp;
}
