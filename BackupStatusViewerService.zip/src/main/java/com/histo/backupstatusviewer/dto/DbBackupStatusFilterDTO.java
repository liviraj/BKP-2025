package com.histo.backupstatusviewer.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class DbBackupStatusFilterDTO {
    private List<String> serverTypes;
    private List<String> serverNames;
    private List<DBBackupDataBase> databaseNames;
    private List<String> typeOfBackups;
    private List<String> secondaryBackupStatusList;
}
