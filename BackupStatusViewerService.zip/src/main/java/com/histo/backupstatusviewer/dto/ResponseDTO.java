package com.histo.backupstatusviewer.dto;

import java.util.Date;

public class ResponseDTO {
	private boolean status;
	private Date timestamp;
	private String message;
	private String description;
	public ResponseDTO() {
		super();
	}
	public ResponseDTO(boolean status, Date timestamp, String message, String description) {
		super();
		this.status = status;
		this.timestamp = timestamp;
		this.message = message;
		this.description = description;
	}
	public Date getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "ResponseDTO [status=" + status + ", timestamp=" + timestamp + ", message=" + message + ", description="
				+ description + "]";
	}
}
