package com.histo.backupstatusviewer.dto;

public enum FastQMeachineType {
    MISEQ("MiSeq"), PACBIO("Pacbio");

    public final String value;
    FastQMeachineType(String value) {
        this.value = value;
    }
}
