package com.histo.backupstatusviewer.dto;

import lombok.*;

import java.util.Date;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class FastQQueryParams {
    private FastQMeachineType fastQMeachineType;
    private Date fromDate;
    private Date toDate;

    public FastQQueryParams(FastQMeachineType fastQMeachineType, Date fromDate, Date toDate) {
        this.fastQMeachineType = fastQMeachineType;
        this.fromDate = fromDate;
        this.toDate = toDate;
    }
}
