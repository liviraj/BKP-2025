package com.histo.backupstatusviewer.dto;

public enum MachineName {
    ALL("All"),MISEQ("Miseq"), NOVASEQ("Novaseq"), PACBIO("Pacbio");

    private String value;

    MachineName(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
