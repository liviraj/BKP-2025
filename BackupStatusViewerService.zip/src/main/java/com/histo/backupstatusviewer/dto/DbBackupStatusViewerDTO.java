package com.histo.backupstatusviewer.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.sql.Date;
import java.sql.Time;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class DbBackupStatusViewerDTO {
    private int dbBackupScheduleId;
    private String serverType;
    private String dbServerName;
    private boolean dbStatus;
    private String databaseName;
    private Date date;
    private Time time;
    private String backupType;
    private String primaryBackupStatus;
    private String backupFileName;
    private String secondaryBackupStatus;
    private Integer serverId;
    private Integer databaseId;
    private String scheduledDate;
    private String apiRunDateTime;
}
