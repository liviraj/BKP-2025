package com.histo.backupstatusviewer.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class MiSeqSecondaryBackupInformationDTO {
    private String machine;
    private String experimentName;
    private String dateOfBackup;
    private boolean backupStatus;
    private String secondaryBackupLocation;
    private String secondaryBackupLocationTemp;
}
