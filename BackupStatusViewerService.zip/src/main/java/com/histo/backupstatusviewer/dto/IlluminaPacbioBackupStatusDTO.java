package com.histo.backupstatusviewer.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class IlluminaPacbioBackupStatusDTO {
    private Integer experimentId;
    private Integer machineId;
    private String experimentName;
    private String experimentDate;
    private Integer totalSamples = 0;
    private Integer secondaryBackupSamplesCount = 0;
    private String machineName;
    private String machineType;
    private String backupCompletionDate;
}
