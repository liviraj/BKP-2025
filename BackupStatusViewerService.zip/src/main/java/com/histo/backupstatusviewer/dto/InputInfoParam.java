package com.histo.backupstatusviewer.dto;

import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import com.histo.backupstatusviewer.configuration.PropertyConfig;

import java.io.IOException;

public class InputInfoParam {
    private DiskShare sourceShare;
    private DiskShare destinationShare;
    private DiskShare histoNas1BkShare;

    public InputInfoParam() {
    }

    public InputInfoParam(PropertyConfig propertyConfig) {
        SMBClient clientSource = new SMBClient();
        SMBClient clientDestination = new SMBClient();
        SMBClient histoNas1BkClient = new SMBClient();
        try {
            Connection connectionSource = clientSource.connect(propertyConfig.getDbStatusViewerSmbSourceServer());
            AuthenticationContext authContextSource = new AuthenticationContext(propertyConfig.getDbStatusViewerSmbSourceUsername()
                    , propertyConfig.getDbStatusViewerSmbSourcePassword().toCharArray(), propertyConfig.getSmbDomainName());
            Session sessionSource = connectionSource.authenticate(authContextSource);
            this.sourceShare = (DiskShare) sessionSource.connectShare(propertyConfig.getDbStatusViewerSmbSourceShare());

            Connection connectionDestination = clientDestination.connect(propertyConfig.getDbStatusViewerSmbDestServer());
            AuthenticationContext authContextDestination = new AuthenticationContext(propertyConfig.getDbStatusViewerSmbSDestUsername()
                    , propertyConfig.getDbStatusViewerSmbSDestPassword().toCharArray(), propertyConfig.getSmbDomainName());
            Session sessionDes = connectionDestination.authenticate(authContextDestination);
            this.destinationShare = (DiskShare) sessionDes.connectShare(propertyConfig.getDbStatusViewerSmbDestSharer());

            Connection histoNas1BkCon = histoNas1BkClient.connect(propertyConfig.getHistoNas1BkServer());
            AuthenticationContext histoNas1BkAuthContext = new AuthenticationContext(propertyConfig.getHistoNas1BkUsername()
                    , propertyConfig.getHistoNas1BkPassword().toCharArray(), propertyConfig.getSmbDomainName());
            Session histoNas1BkSession = histoNas1BkCon.authenticate(histoNas1BkAuthContext);
            this.histoNas1BkShare = (DiskShare) histoNas1BkSession.connectShare(propertyConfig.getHistoNas1BkShare());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public DiskShare getSourceShare() {
        return sourceShare;
    }

    public void setSourceShare(DiskShare sourceShare) {
        this.sourceShare = sourceShare;
    }

    public DiskShare getDestinationShare() {
        return destinationShare;
    }

    public void setDestinationShare(DiskShare destinationShare) {
        this.destinationShare = destinationShare;
    }

    public DiskShare getHistoNas1BkShare() {
        return histoNas1BkShare;
    }

    public void setHistoNas1BkShare(DiskShare histoNas1BkShare) {
        this.histoNas1BkShare = histoNas1BkShare;
    }

    @Override
    public String toString() {
        return "InputInfoParam{" +
                "sourceShare=" + sourceShare +
                ", destinationShare=" + destinationShare +
                ", histoNas1BkShare=" + histoNas1BkShare +
                '}';
    }
}
