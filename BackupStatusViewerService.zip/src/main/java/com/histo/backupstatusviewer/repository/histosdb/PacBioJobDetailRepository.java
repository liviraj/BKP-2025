package com.histo.backupstatusviewer.repository.histosdb;

import com.histo.backupstatusviewer.entity.histosdb.PacBioJobDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PacBioJobDetailRepository extends JpaRepository<PacBioJobDetail, Long> {
    public long countByJobId(Long jobId);

}