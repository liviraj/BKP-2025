package com.histo.backupstatusviewer.repository.histosdb;

import com.histo.backupstatusviewer.entity.histosdb.PacBioJob;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;
import java.util.List;

public interface PacBioJobRepository extends JpaRepository<PacBioJob, Long> {
    List<PacBioJob> findByCreatedOnBetweenAndQcJobFalseOrderByCreatedOnDesc(Date createdOnStart, Date createdOnEnd);
    PacBioJob findByJobName(String jobName);
}