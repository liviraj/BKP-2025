package com.histo.backupstatusviewer.repository.webmilhv;

import com.histo.backupstatusviewer.entity.webmilhv.TLoginLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface LoginLogRepository extends JpaRepository<TLoginLog, Integer>{
	public Optional<TLoginLog> findByLoginID(int loginID);

}
