package com.histo.backupstatusviewer.repository.pacbioanalysis;


import com.histo.backupstatusviewer.entity.pacbioanalysis.Job;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface JobRepository extends JpaRepository<Job, String> {
    List<Job> findByJobId(String jobId);
}