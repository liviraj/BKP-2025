package com.histo.backupstatusviewer.repository.webmilhv;

import com.histo.backupstatusviewer.entity.webmilhv.T_User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserInformationRepository extends JpaRepository<T_User, Long>{
	public Optional<T_User> findByLoginName(String loginName);
	public Optional<T_User> findByLoginNameAndPassword(String loginName, String password);
	public Optional<T_User> findByEMail(String email);
}
