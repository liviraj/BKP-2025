package com.histo.backupstatusviewer.repository.histosdb;

import com.histo.backupstatusviewer.entity.histosdb.UserInformation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserInfoRepository extends JpaRepository<UserInformation,Integer> {
	public Optional<UserInformation> findByEmailAddress(String email);
}
