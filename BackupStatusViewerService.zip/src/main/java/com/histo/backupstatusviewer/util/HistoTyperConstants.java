package com.histo.backupstatusviewer.util;

public class HistoTyperConstants {
    public static final String EMAIL_CLAIM_NAME = "unique_name";
    public static final String HISTOSQLCL19 = "HISTOSQLCL19";
}
