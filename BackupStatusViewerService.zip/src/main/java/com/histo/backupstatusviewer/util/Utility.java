package com.histo.backupstatusviewer.util;

import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.mssmb2.SMBApiException;
import com.hierynomus.smbj.share.DiskShare;
import com.hierynomus.smbj.share.File;

import java.util.EnumSet;

public class Utility {
	public static String Decode(String strEncPassword)
	{
		String[] strArray = new String[38];
		int intCounter = 0;
		int intCharCounter = 0;
		int intRnd = 0;
		int intHalfVal = 0;

		String strOrgChar = null;
		String strOrgString = null;
		String strGenChar = null;
		int intPosition = 0;
		int intNewPosition = 0;

		strArray[0] = "+";
		strArray[1] = "A";
		strArray[2] = "B";
		strArray[3] = "C";
		strArray[4] = "D";
		strArray[5] = "E";
		strArray[6] = "F";
		strArray[7] = "G";
		strArray[8] = "H";
		strArray[9] = "I";
		strArray[10] = "J";
		strArray[11] = "K";
		strArray[12] = "L";
		strArray[13] = "M";
		strArray[14] = "N";
		strArray[15] = "O";
		strArray[16] = "P";
		strArray[17] = "Q";
		strArray[18] = "R";
		strArray[19] = "S";
		strArray[20] = "T";
		strArray[21] = "U";
		strArray[22] = "V";
		strArray[23] = "W";
		strArray[24] = "X";
		strArray[25] = "Y";
		strArray[26] = "Z";
		strArray[27] = "0";
		strArray[28] = "1";
		strArray[29] = "2";
		strArray[30] = "3";
		strArray[31] = "4";
		strArray[32] = "5";
		strArray[33] = "6";
		strArray[34] = "7";
		strArray[35] = "8";
		strArray[36] = "9";

		intRnd = Integer.parseInt(strEncPassword.toString().substring(0, 1));
		intHalfVal = (int) Math.round(intRnd / 2.0);

		strOrgString = "";

		for (intCounter = 2; intCounter <= 15; intCounter++)
		{
			strGenChar = strEncPassword.toString().substring(intCounter - 1, intCounter - 1 + 1);
			for (intCharCounter = 0; intCharCounter <= 36; intCharCounter++)
			{
				if (strArray[intCharCounter].equals(strGenChar))
				{
					break;
				}
			}
			intPosition = intCharCounter;
			intNewPosition = intPosition - (intRnd * intHalfVal) - intCounter + 1;
			if (intNewPosition < 0)
			{
				intNewPosition = intNewPosition + 37;
			}
			strOrgChar = strArray[intNewPosition];
			if (strOrgChar.equals("+"))
			{
				strOrgChar = "";
			}
			strOrgString = strOrgString + strOrgChar;
		}
		return strOrgString;
	}

	public static long getSMBFileSize(DiskShare share, String directoryPath) throws SMBApiException {
		long totalSize = 0;
		directoryPath = directoryPath.replace(share.getSmbPath().toUncPath(), "");
		directoryPath = directoryPath.replace("\\", "/");

		if (share.fileExists(directoryPath)) {
			File file = share.openFile(directoryPath, EnumSet.of(
							AccessMask.GENERIC_READ.GENERIC_READ)
					, null
					, SMB2ShareAccess.ALL
					, SMB2CreateDisposition.FILE_OPEN.FILE_OPEN
					, null);
			totalSize += file.getFileInformation().getStandardInformation().getEndOfFile();
			return totalSize;
		}

		for (FileIdBothDirectoryInformation fileInfo : share.list(directoryPath)) {
			String fileName = fileInfo.getFileName();
			if (fileName.equals(".") || fileName.equals("..")) {
				continue;
			}

			String filePath = directoryPath + "/" + fileName;
			if (!fileInfo.getFileName().contains(".")) {
				totalSize += getSMBFileSize(share, filePath);
			} else {
				File file = share.openFile(filePath, EnumSet.of(
								AccessMask.GENERIC_READ.GENERIC_READ)
						, null
						, SMB2ShareAccess.ALL
						, SMB2CreateDisposition.FILE_OPEN.FILE_OPEN
						, null);
				totalSize += file.getFileInformation().getStandardInformation().getEndOfFile();
				file.closeSilently();
			}
		}
		return totalSize;
	}
}
