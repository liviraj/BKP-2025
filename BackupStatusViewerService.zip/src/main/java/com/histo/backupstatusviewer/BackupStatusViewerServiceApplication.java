package com.histo.backupstatusviewer;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
@OpenAPIDefinition(
		servers = {
				@Server(url = "https://webapiuat.histogenetics.com:8765/BackupStatusViewer", description = "UAT Server API Gateway"),
				@Server(url = "http://localhost:8765/BackupStatusViewer", description = "local Server"),
				@Server(url = "http://localhost:8550/BackupStatusViewer", description = "local Native Server"),
				@Server(url = "https://javawebag01.histogenetics.com:8765/BackupStatusViewer", description = "PROD Server API Gateway")
		}
)
public class BackupStatusViewerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackupStatusViewerServiceApplication.class, args);
	}

}
