package com.histo.backupstatusviewer.controller;

import com.histo.backupstatusviewer.dto.DbBackupStatusViewerQueryParams;
import com.histo.backupstatusviewer.security.BackupStatusAuthorizationValidation;
import com.histo.backupstatusviewer.service.DbStatusViewerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@RestController
public class DbStatusViewerController {
    private final DbStatusViewerService dbStatusViewerService;
    private final BackupStatusAuthorizationValidation backupStatusAuthorizationValidation;

    public DbStatusViewerController(DbStatusViewerService dbStatusViewerService, BackupStatusAuthorizationValidation backupStatusAuthorizationValidation) {
        this.dbStatusViewerService = dbStatusViewerService;
        this.backupStatusAuthorizationValidation = backupStatusAuthorizationValidation;
    }

    // @GetMapping("/dbSecondaryStatusUpdate")
    public void updateDbSecondaryStatus() {
        dbStatusViewerService.checkIsBackupCopiedInSecondaryLocation();
    }

    @GetMapping("/dbStatusViewer/login")
    public ResponseEntity<Object> loginDbStatusViewer(@RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = backupStatusAuthorizationValidation.isAuthorize(token);
        return responseEntity;
    }

    @GetMapping("/dbStatusViewer/filterValues")
    public ResponseEntity<Object> getDbBackupStatusFilters(@RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = backupStatusAuthorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return dbStatusViewerService.getDbBackupStatusFilters();
        }
        return responseEntity;
    }

    @GetMapping("/dbStatusViewer/filter")
    public ResponseEntity<Object> filterDbBackupStatusViewer(@RequestHeader("Authorization") String token,
                                                             @RequestParam(value = "serverType") String serverType
            , @RequestParam(value = "serverName") String serverName
            , @RequestParam(value = "databaseName") String databaseName
            , @RequestParam(value = "typeOfBackup") String typeOfBackup
            , @RequestParam(value = "fromDate") Date fromDate
            , @RequestParam(value = "toDate") Date toDate
            , @RequestParam(value = "secondaryBackupStatus") String secondaryBackupStatus) {
        DbBackupStatusViewerQueryParams queryParams = new DbBackupStatusViewerQueryParams(
                serverType
                , serverName
                , databaseName
                , typeOfBackup
                , fromDate
                , toDate
                , secondaryBackupStatus
        );

        ResponseEntity<Object> responseEntity = backupStatusAuthorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return dbStatusViewerService.filterDbBackupStatusViewer(queryParams);
        }
        return responseEntity;
    }
}
