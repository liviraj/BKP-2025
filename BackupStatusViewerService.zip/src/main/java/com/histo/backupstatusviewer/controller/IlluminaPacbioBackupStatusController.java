package com.histo.backupstatusviewer.controller;

import com.azure.core.annotation.QueryParam;
import com.histo.backupstatusviewer.dto.IlluminaPacbioFilterValue;
import com.histo.backupstatusviewer.security.BackupStatusAuthorizationValidation;
import com.histo.backupstatusviewer.service.IlluminaPacbioBackupStatusService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class IlluminaPacbioBackupStatusController {

    private final IlluminaPacbioBackupStatusService illuminaPacbioBackupStatusService;
    private final BackupStatusAuthorizationValidation backupStatusAuthorizationValidation;

    public IlluminaPacbioBackupStatusController(IlluminaPacbioBackupStatusService illuminaPacbioBackupStatusService, BackupStatusAuthorizationValidation backupStatusAuthorizationValidation) {
        this.illuminaPacbioBackupStatusService = illuminaPacbioBackupStatusService;
        this.backupStatusAuthorizationValidation = backupStatusAuthorizationValidation;
    }
    
    @GetMapping("illuminaPacbioBackupStatus/filter")
    public ResponseEntity<Object> filterIlluminaPacbioBackupStatus(@RequestHeader("Authorization") String token
            , @QueryParam(value = "input") IlluminaPacbioFilterValue filterValue) {
        ResponseEntity<Object> responseEntity = backupStatusAuthorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return illuminaPacbioBackupStatusService.filterIlluminaPacbioBackupStatus(filterValue);
        }
        return responseEntity;
    }

    @GetMapping("illuminaPacbioBackupStatus/filterValues")
    public ResponseEntity<Object> getFilterValues(@RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = backupStatusAuthorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return illuminaPacbioBackupStatusService.getFilterValues();
        }
        return responseEntity;
    }
}
