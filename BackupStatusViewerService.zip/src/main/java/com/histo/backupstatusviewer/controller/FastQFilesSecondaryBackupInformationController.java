package com.histo.backupstatusviewer.controller;

import com.histo.backupstatusviewer.dto.FastQMeachineType;
import com.histo.backupstatusviewer.dto.FastQQueryParams;
import com.histo.backupstatusviewer.service.FastQFilesSecondaryBackupInformationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@RestController

public class FastQFilesSecondaryBackupInformationController {

    private final FastQFilesSecondaryBackupInformationService fastQFilesSecondaryBackupInformationService;

    public FastQFilesSecondaryBackupInformationController(FastQFilesSecondaryBackupInformationService fastQFilesSecondaryBackupInformationService) {
        this.fastQFilesSecondaryBackupInformationService = fastQFilesSecondaryBackupInformationService;
    }

    @GetMapping("/fastQFilesSecondaryBackupInformation")
    public ResponseEntity<Object> getFastQFilesSecondaryBackupInformation(@RequestParam(value = "mechineType") FastQMeachineType machineType
            , @RequestParam(value = "fromDate") Date fromDate
            , @RequestParam(value = "toDate") Date toDate) {
        FastQQueryParams queryParams = new FastQQueryParams(machineType, fromDate, toDate);
        return fastQFilesSecondaryBackupInformationService.getFastQFilesSecondaryBackupInformation(queryParams);
    }
}
