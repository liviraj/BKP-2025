package com.histo.backupstatusviewer.controller;

import com.histo.backupstatusviewer.dto.LoginDTO;
import com.histo.backupstatusviewer.dto.ResponseDTO;
import com.histo.backupstatusviewer.dto.UserInfoDTO;
import com.histo.backupstatusviewer.service.UserInformationService;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

@RestController
@RequestMapping(value = "/user")
public class UserInformationController {

	@Autowired
	UserInformationService userInformationService;

	@GetMapping("/logoff/{loginID}")
	public ResponseEntity<Object> getUserInfo(@PathVariable int loginID) {
		String message = userInformationService.userLoginOff(loginID);
		return new ResponseEntity<>(message, HttpStatus.OK);

	}
	
	@PostMapping("/login")
	public ResponseEntity<Object> login(@RequestBody LoginDTO login) {
		UserInfoDTO userInfo = userInformationService.userLogin(login);
		
		if (ObjectUtils.isEmpty(userInfo)) {
			return new ResponseEntity<>(new ResponseDTO(false, new Date(), "Login failed", "Invalid Credentials"), HttpStatus.UNAUTHORIZED);
		}
			
		return new ResponseEntity<>(userInfo, HttpStatus.OK);
	}
	@GetMapping("/userInfo/{email}")
	public ResponseEntity<Object> getUserByEmail(@PathVariable String email){
		UserInfoDTO userInfo = userInformationService.findUserByEmail(email);
		if (ObjectUtils.isEmpty(userInfo)) {
			return new ResponseEntity<>(new ResponseDTO(false, new Date(), "User not found", "Enter a valid email"), HttpStatus.CONFLICT);
		}
		return new ResponseEntity<>(userInfo, HttpStatus.OK);
	}
}
