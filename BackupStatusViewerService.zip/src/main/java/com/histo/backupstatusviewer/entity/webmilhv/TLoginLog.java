package com.histo.backupstatusviewer.entity.webmilhv;

import jakarta.persistence.*;

import java.sql.Timestamp;

@Entity
@Table(name = "t_loginlog")
public class TLoginLog {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "LoginID")
	private Integer loginID;
	
	@Column(name = "UserID")
	private Integer UserID;
	
	@Column(name = "LoginTime")
	private Timestamp loginTime;
	
	@Column(name = "LogoutTime")
	private Timestamp logoutTime;
	
	@Column(name = "Blot")
	private String blot;
	
	@Column(name = "locus")
	private String locus;
	
	@Column(name = "SearchType")
	private String SearchType;
	
	@Column(name = "whichdb")
	private String whichdb;
	
	@Column(name = "BlotLocusKitID")
	private Integer blotLocusKitID;

	public TLoginLog() {
		super();
	}

	public TLoginLog(Integer loginID, Integer userID, Timestamp loginTime, Timestamp logoutTime, String blot,
			String locus, String searchType, String whichdb, Integer blotLocusKitID) {
		super();
		this.loginID = loginID;
		UserID = userID;
		this.loginTime = loginTime;
		this.logoutTime = logoutTime;
		this.blot = blot;
		this.locus = locus;
		SearchType = searchType;
		this.whichdb = whichdb;
		this.blotLocusKitID = blotLocusKitID;
	}


	public Integer getLoginID() {
		return loginID;
	}

	public void setLoginID(Integer loginID) {
		this.loginID = loginID;
	}

	public Integer getUserID() {
		return UserID;
	}

	public void setUserID(Integer userID) {
		UserID = userID;
	}

	public Timestamp getLoginTime() {
		return loginTime;
	}

	public void setLoginTime(Timestamp loginTime) {
		this.loginTime = loginTime;
	}

	public Timestamp getLogoutTime() {
		return logoutTime;
	}

	public void setLogoutTime(Timestamp logoutTime) {
		this.logoutTime = logoutTime;
	}

	public String getBlot() {
		return blot;
	}

	public void setBlot(String blot) {
		this.blot = blot;
	}

	public String getLocus() {
		return locus;
	}

	public void setLocus(String locus) {
		this.locus = locus;
	}

	public String getSearchType() {
		return SearchType;
	}

	public void setSearchType(String searchType) {
		SearchType = searchType;
	}

	public String getWhichdb() {
		return whichdb;
	}

	public void setWhichdb(String whichdb) {
		this.whichdb = whichdb;
	}

	public Integer getBlotLocusKitID() {
		return blotLocusKitID;
	}

	public void setBlotLocusKitID(Integer blotLocusKitID) {
		this.blotLocusKitID = blotLocusKitID;
	}

	@Override
	public String toString() {
		return "TLoginLog [loginID=" + loginID + ", UserID=" + UserID + ", loginTime=" + loginTime + ", logoutTime="
				+ logoutTime + ", blot=" + blot + ", locus=" + locus + ", SearchType=" + SearchType + ", whichdb="
				+ whichdb + ", blotLocusKitID=" + blotLocusKitID + "]";
	}
}
