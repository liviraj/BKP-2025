package com.histo.backupstatusviewer.entity.pacbioanalysis;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "Jobs")
@Getter
@Setter
@NoArgsConstructor
public class Job {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "JobResultID", nullable = false)
    private Long jobResultId;

    @Column(name = "JobID", length = 20, nullable = false)
    private String jobId;

    @Column(name = "JobName", length = 200, nullable = false)
    private String jobName;

    @Column(name = "MachineID", length = 20, nullable = false)
    private String machineId;

    @Column(name = "NumSamples", nullable = false)
    private int numSamples;

    @Column(name = "AlleleSetVersion")
    private Integer alleleSetVersion;

    @Column(name = "TimeStamp", nullable = false)
    private LocalDateTime timestamp;

    @Column(name = "Active", nullable = false)
    private boolean active;

    @Column(name = "BlastSearchVersionID")
    private Integer blastSearchVersionId;

    @Column(name = "SecondaryAnalysisVersionID", columnDefinition = "int default 0")
    private Integer secondaryAnalysisVersionId = 0;

    @Column(name = "SecondaryAnalysisProtocolID", columnDefinition = "int default 0")
    private Integer secondaryAnalysisProtocolId = 0;

    @Column(name = "Processed", columnDefinition = "bit default 0")
    private Boolean processed = false;

    @Column(name = "JobTypeID")
    private Integer jobTypeId;
}

