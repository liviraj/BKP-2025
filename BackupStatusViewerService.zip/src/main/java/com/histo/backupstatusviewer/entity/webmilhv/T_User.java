package com.histo.backupstatusviewer.entity.webmilhv;

import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name = "T_User")
public class T_User implements Serializable {
	@Column(name = "UserId")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer UserId;
	@Column(name = "LoginName")
	private String loginName;
	@Column(name = "Password")
	private String password;
	@Column(name = "LastName")
	private String LastName;
	@Column(name = "FirstName")
	private String FirstName;
	@Column(name = "MiddleName")
	private String MiddleName;
	@Column(name = "JobTitle")
	private String JobTitle;
	@Column(name = "JobFunction")
	private String JobFunction;
	@Column(name = "HomePhone")
	private String HomePhone;
	@Column(name = "WorkPhone")
	private String WorkPhone;
	@Column(name = "Extn")
	private String Extn;
	@Column(name = "Pager")
	private String Pager;
	@Column(name = "EMail")
	private String EMail;
	@Column(name = "ClientCode")
	private int ClientCode;
	@Column(name = "Status")
	private String Status;
	@Column(name = "Blot")
	private String Blot;
	@Column(name = "Locus")
	private String Locus;
	@Column(name = "SignUpDate")
	private String SignUpDate;
	@Column(name = "roleid")
	private Integer roleid;
	@Column(name = "PermissionType", length = 1)
	private char PermissionType;
	@Column(name = "MobilePhone")
	private String MobilePhone;
	@Column(name = "whichdb")
	private String whichdb;
	@Column(name = "BlotLocusKitID")
	private String BlotLocusKitID;

	public T_User() {
		super();
	}

	public Integer getUserId() {
		return UserId;
	}

	public void setUserId(Integer userId) {
		UserId = userId;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getMiddleName() {
		return MiddleName;
	}

	public void setMiddleName(String middleName) {
		MiddleName = middleName;
	}

	public String getJobTitle() {
		return JobTitle;
	}

	public void setJobTitle(String jobTitle) {
		JobTitle = jobTitle;
	}

	public String getJobFunction() {
		return JobFunction;
	}

	public void setJobFunction(String jobFunction) {
		JobFunction = jobFunction;
	}

	public String getHomePhone() {
		return HomePhone;
	}

	public void setHomePhone(String homePhone) {
		HomePhone = homePhone;
	}

	public String getWorkPhone() {
		return WorkPhone;
	}

	public void setWorkPhone(String workPhone) {
		WorkPhone = workPhone;
	}

	public String getExtn() {
		return Extn;
	}

	public void setExtn(String extn) {
		Extn = extn;
	}

	public String getPager() {
		return Pager;
	}

	public void setPager(String pager) {
		Pager = pager;
	}

	public String getEMail() {
		return EMail;
	}

	public void setEMail(String eMail) {
		EMail = eMail;
	}

	public int getClientCode() {
		return ClientCode;
	}

	public void setClientCode(int clientCode) {
		ClientCode = clientCode;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getBlot() {
		return Blot;
	}

	public void setBlot(String blot) {
		Blot = blot;
	}

	public String getLocus() {
		return Locus;
	}

	public void setLocus(String locus) {
		Locus = locus;
	}

	public String getSignUpDate() {
		return SignUpDate;
	}

	public void setSignUpDate(String signUpDate) {
		SignUpDate = signUpDate;
	}

	public int getRoleid() {
		return roleid;
	}

	public void setRoleid(int roleid) {
		this.roleid = roleid;
	}

	public char getPermissionType() {
		return PermissionType;
	}

	public void setPermissionType(Character permissionType) {
		PermissionType = permissionType;
	}

	public String getMobilePhone() {
		return MobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		MobilePhone = mobilePhone;
	}

	public String getWhichdb() {
		return whichdb;
	}

	public void setWhichdb(String whichdb) {
		this.whichdb = whichdb;
	}

	public String getBlotLocusKitID() {
		return BlotLocusKitID;
	}

	public void setBlotLocusKitID(String blotLocusKitID) {
		BlotLocusKitID = blotLocusKitID;
	}

}
