package com.histo.backupstatusviewer.entity.histosdb;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Entity
@Table(name = "PacBioJobDetails")
@Getter
@Setter
@ToString
public class PacBioJobDetail {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "JobDetailID", nullable = false)
    private Long jobDetailId;
    @Column(name = "JobID")
    private Long jobId;
    @Column(name = "ExperimentDetailID")
    private Long experimentDetailId;
    @Column(name = "RequestID")
    private Long requestId;
    @Column(name = "SampleID")
    private Long sampleId;
    @Column(name = "SampleBarcodeID")
    private Integer sampleBarcodeId;
    @Column(name = "ExperimentID")
    private Long experimentId;
    @Column(name = "positionIndex")
    private String positionIndex;
    @Column(name = "LastModifiedOn")
    private Date lastModifiedOn;
    @Column(name = "LastModifiedRowCount")
    private Integer LastModifiedRowCount;
    @Column(name = "SecondaryAnalysisProtocolTypeID")
    private Integer secondaryAnalysisProtocolTypeId;
}
