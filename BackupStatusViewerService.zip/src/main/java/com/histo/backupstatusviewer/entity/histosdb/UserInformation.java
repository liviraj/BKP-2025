package com.histo.backupstatusviewer.entity.histosdb;

import jakarta.persistence.*;

import java.time.Instant;
import java.util.Date;

@Entity
public class UserInformation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "UserID", nullable = false)
    private Integer id;

    @Column(name = "LoginName", length = 100)
    private String loginName;

    @Column(name = "Password", length = 50)
    private String password;

    @Column(name = "SpecialPassword", length = 50)
    private String specialPassword;


    @Column(name = "Initial", length = 50)
    private String initial;

    @Column(name = "FirstName", length = 100)
    private String firstName;


    @Column(name = "MiddleName", length = 100)
    private String middleName;


    @Column(name = "LastName", length = 100)
    private String lastName;

    @Column(name = "DateOfBirth")
    private Instant dateOfBirth;


    @Column(name = "JobTitle", length = 100)
    private String jobTitle;

    @Column(name = "DepartmentID")
    private Integer departmentID;


    @Column(name = "HomePhone", length = 20)
    private String homePhone;


    @Column(name = "OfficePhone", length = 20)
    private String officePhone;


    @Column(name = "MobilePhone", length = 20)
    private String mobilePhone;


    @Column(name = "Extension", length = 20)
    private String extension;


    @Column(name = "EmailAddress", length = 100)
    private String emailAddress;

    @Column(name = "LocationID")
    private Integer locationID;


    @Column(name = "RecordStatus", length = 10)
    private String recordStatus;

    @Column(name = "LastModifiedBy")
    private Integer lastModifiedBy;

    @Column(name = "LastModifiedOn")
    private Instant lastModifiedOn;

    @Column(name = "LastModifiedRowCount")
    private Integer lastModifiedRowCount;

    @Column(name = "OldUserID")
    private Integer oldUserID;

    @Column(name = "TaskUser")
    private Character taskUser;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "LastEditDate")
    private Date lastEditDate;

    @Column(name = "CreationDate")
    private Instant creationDate;

    @Column(name = "IsAllowed")
    private Boolean isAllowed;

    @Column(name = "EmployeeCode", length = 50)
    private String employeeCode;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSpecialPassword() {
        return specialPassword;
    }

    public void setSpecialPassword(String specialPassword) {
        this.specialPassword = specialPassword;
    }

    public String getInitial() {
        return initial;
    }

    public void setInitial(String initial) {
        this.initial = initial;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Instant getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Instant dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public Integer getDepartmentID() {
        return departmentID;
    }

    public void setDepartmentID(Integer departmentID) {
        this.departmentID = departmentID;
    }

    public String getHomePhone() {
        return homePhone;
    }

    public void setHomePhone(String homePhone) {
        this.homePhone = homePhone;
    }

    public String getOfficePhone() {
        return officePhone;
    }

    public void setOfficePhone(String officePhone) {
        this.officePhone = officePhone;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public Integer getLocationID() {
        return locationID;
    }

    public void setLocationID(Integer locationID) {
        this.locationID = locationID;
    }

    public String getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(String recordStatus) {
        this.recordStatus = recordStatus;
    }

    public Integer getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(Integer lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Instant getLastModifiedOn() {
        return lastModifiedOn;
    }

    public void setLastModifiedOn(Instant lastModifiedOn) {
        this.lastModifiedOn = lastModifiedOn;
    }

    public Integer getLastModifiedRowCount() {
        return lastModifiedRowCount;
    }

    public void setLastModifiedRowCount(Integer lastModifiedRowCount) {
        this.lastModifiedRowCount = lastModifiedRowCount;
    }

    public Integer getOldUserID() {
        return oldUserID;
    }

    public void setOldUserID(Integer oldUserID) {
        this.oldUserID = oldUserID;
    }

    public Character getTaskUser() {
        return taskUser;
    }

    public void setTaskUser(Character taskUser) {
        this.taskUser = taskUser;
    }

    public Date getLastEditDate() {
        return lastEditDate;
    }

    public void setLastEditDate(Date lastEditDate) {
        this.lastEditDate = lastEditDate;
    }

    public Instant getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Instant creationDate) {
        this.creationDate = creationDate;
    }

    public Boolean getIsAllowed() {
        return isAllowed;
    }

    public void setIsAllowed(Boolean isAllowed) {
        this.isAllowed = isAllowed;
    }

    public String getEmployeeCode() {
        return employeeCode;
    }

    public void setEmployeeCode(String employeeCode) {
        this.employeeCode = employeeCode;
    }

}