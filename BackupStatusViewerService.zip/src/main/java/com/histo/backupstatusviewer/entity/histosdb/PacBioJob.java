package com.histo.backupstatusviewer.entity.histosdb;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Entity
@Table(name = "PacBioJobs")
@Getter
@Setter
@ToString
public class PacBioJob {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "JobID", nullable = false)
    private Long jobId;
    @Column(name = "JoBName")
    private String jobName;
    @Column(name = "GeneTypeID")
    private Integer geneTypeId;
    @Column(name = "CreatedBy")
    private Integer createdBy;
    @Column(name = "CreatedOn")
    private Date createdOn;
    @Column(name = "ConfirmationStatus")
    private Character confirmationStatus;
    @Column(name = "ConfirmedBy")
    private Integer confirmedBy;
    @Column(name = "ConfirmedOn")
    private Date confirmedOn;
    @Column(name = "IsBioScriptCreated")
    private Character isBioScriptCreated;
    @Column(name = "LastModifiedBy")
    private Integer lastModifiedBy;
    @Column(name = "LastModifiedOn")
    private Date lastModifiedOn;
    @Column(name = "RecordStatus")
    private Character recordStatus;
    @Column(name = "PoolingType")
    private String poolingType;
    @Column(name = "ExonRange")
    private String exonRange;
    @Column(name = "VersionID")
    private Integer versionId;
    @Column(name = "JobTypeID")
    private Integer jobTypeId;
    @Column(name = "LibraryProcessStatus")
    private Boolean libraryProcessStatus;
    @Column(name = "SMRTCellLotNumber")
    private Float smrtCellLotNumber;
    @Column(name = "MachineID")
    private Float machineId;
    @Column(name = "MachineName")
    private String machineName;
    @Column(name = "IsQCJob")
    private Boolean qcJob;
    @Column(name = "ExperimentTypeID")
    private Integer experimentTypeId;
}
