package com.histo.backupstatusviewer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackupStatusViewerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
