package com.histo.md5checksum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Md5ChecksumApplicationTests {

	@Test
	void contextLoads() {
	}

}
