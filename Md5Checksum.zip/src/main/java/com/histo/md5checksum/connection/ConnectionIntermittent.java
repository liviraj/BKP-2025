package com.histo.md5checksum.connection;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.histo.md5checksum.model.GridIonLocalTransferStatus;
import com.histo.md5checksum.model.LocalTransferStatus;
import com.histo.md5checksum.model.ProgramType;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import javax.net.ssl.SSLException;
import java.util.Map;

@Component("connectionIntermittent")
public class ConnectionIntermittent {
    private static Logger LOGGER = LogManager.getLogger(ConnectionIntermittent.class.getName());
    @Autowired
    private ConnectionUrlProvider connectionUrlProvider;

    private WebClient getWebClient() {
        SslContext sslContext = null;
        try {
            sslContext = SslContextBuilder
                    .forClient()
                    .trustManager(InsecureTrustManagerFactory.INSTANCE)
                    .build();
        } catch (SSLException e) {
            throw new RuntimeException(e);
        }
        SslContext finalSslContext = sslContext;
        HttpClient httpClient = HttpClient.create().secure(t -> t.sslContext(finalSslContext));
        WebClient webClient = WebClient.builder().clientConnector(new ReactorClientHttpConnector(httpClient)).build();
        return webClient;
    }
    
    public String callSaveWGSMD5ChecksumDetails(Integer wgsRunId, Map<String, String> md5ChecksumDetails) {
        LOGGER.info("callSaveWGSMD5ChecksumDetails() Request Info. URL:{}, Method: {}", connectionUrlProvider.saveWGSMD5ChecksumDetailsUrl(wgsRunId), HttpMethod.POST);
        String responseMsg = getWebClient()
                .post()
                .uri(connectionUrlProvider.saveWGSMD5ChecksumDetailsUrl(wgsRunId))
                .bodyValue(md5ChecksumDetails)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return responseMsg;
    }

    public String callSaveGridIonMD5ChecksumDetails(Integer gridIonRunId, Map<String, String> md5ChecksumDetails) {
        LOGGER.info("callSaveGridIonMD5ChecksumDetails() Request Info. URL:{}, Method: {}", connectionUrlProvider.saveGridIonMD5ChecksumDetailsUrl(gridIonRunId), HttpMethod.POST);
        String responseMsg = getWebClient()
                .post()
                .uri(connectionUrlProvider.saveGridIonMD5ChecksumDetailsUrl(gridIonRunId))
                .bodyValue(md5ChecksumDetails)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return responseMsg;
    }
    public ResponseEntity<String> callExecuteFileUploader(Integer statusViewerId, ProgramType programType) {
        String url = "";
        if (programType != null && programType == ProgramType.GRIDION) {
            // url = connectionUrlProvider.executeGridIonFileUploaderUrl(statusViewerId);
        } else {
            // url = connectionUrlProvider.executeFileUploaderUrl(statusViewerId);
        }
        LOGGER.info("allExecuteFileUploader() Request Info. URL:{}, Method: {}", url, HttpMethod.GET);
        ResponseEntity<String> response = getWebClient()
                .get()
                .uri(url)
                .retrieve()
                .toEntity(String.class)
                .block();
        return response;
    }

    public ResponseEntity<String> callUpdateLocalTransferStatus(LocalTransferStatus localTransferStatus) throws JsonProcessingException {
        LOGGER.info("callUpdateLocalTransferStatus() Request Info. URL:{}, Method: {}", connectionUrlProvider.updateLocalTransferStatusUrl(), HttpMethod.POST);
        String jsonValue = new ObjectMapper().writeValueAsString(localTransferStatus);
        ResponseEntity<String> responseMsg = getWebClient()
                .put()
                .uri(connectionUrlProvider.updateLocalTransferStatusUrl())
                .bodyValue(localTransferStatus)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .toEntity(String.class)
                .block();
        return responseMsg;
    }

    public ResponseEntity<String> callUpdateGridIonLTSUrl(GridIonLocalTransferStatus localTransferStatus) throws JsonProcessingException {
        LOGGER.info("callUpdateGridIonLTSUrl() Request Info. URL:{}, Method: {}", connectionUrlProvider.updateGridIonLTSUrl(), HttpMethod.PUT);
        String jsonValue = new ObjectMapper().writeValueAsString(localTransferStatus);
        ResponseEntity<String> responseMsg = getWebClient()
                .put()
                .uri(connectionUrlProvider.updateGridIonLTSUrl())
                .bodyValue(localTransferStatus)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .toEntity(String.class)
                .block();
        return responseMsg;
    }
}
