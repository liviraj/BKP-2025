package com.histo.md5checksum.connection;

import com.histo.md5checksum.config.PropertyConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("connectionUrlProvider")
public class ConnectionUrlProvider {
    @Autowired
    private PropertyConfig propertyConfig;

    public String saveWGSMD5ChecksumDetailsUrl(Integer wgsRunId) {
        return propertyConfig.getPacbioBaseUrl() + "/wgs/md5Checksum/details/" + wgsRunId;
    }

    public String executeFileUploaderUrl(Integer wgsStatusViewerId) {
        return propertyConfig.getPacbioBaseUrl() + "/wgs/executeFileUploader/" + wgsStatusViewerId;
    }

    public String updateLocalTransferStatusUrl() {
        return propertyConfig.getPacbioBaseUrl() + "/wgs/updateLocalTransferStatus";
    }

    public String updateGridIonLTSUrl() {
        return propertyConfig.getGridIonBaseUrl() + "/gridIonRun/updateLocalTransferStatus";
    }

    public String saveGridIonMD5ChecksumDetailsUrl(Integer gridIonRunId) {
        return propertyConfig.getGridIonBaseUrl() + "/gridIonRun/md5Checksum/details/" + gridIonRunId;
    }

    public String executeGridIonFileUploaderUrl(Integer gridIonStatusViewerId) {
        return propertyConfig.getGridIonBaseUrl() + "/gridIonRun/executeFileUploader/" + gridIonStatusViewerId;
    }
}
