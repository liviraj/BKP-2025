package com.histo.md5checksum.config;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:application.properties")
@Getter
@Setter
@ToString
public class PropertyConfig {
    @Value("${smb.domain.name}")
    private String smbDomainName;
    @Value("${pacbio.web.service.base-url}")
    private String pacbioBaseUrl;
    @Value("${gridion.web.service.base-url}")
    private String gridIonBaseUrl;
}
