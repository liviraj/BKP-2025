package com.histo.md5checksum;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.histo.md5checksum.model.InputArgs;
import com.histo.md5checksum.service.Md5ChecksumService;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

@Component("md5ChecksumProcessor")
public class Md5ChecksumProcessor {
    public static Logger LOGGER = LogManager.getLogger(Md5ChecksumProcessor.class.getName());

    @Autowired
    private Md5ChecksumService md5ChecksumService;

    public void doMd5ChecksumProcess(String args[]) {
        /*
        MD5Checksum test arguments
          {"checksumFilePath":"Test%2FPacbioFileDataOrganizer%2FSyngenta+Crop+Protection+LLC%2Fruns%2FPool_HIL5323A44-3_CUR5338A14-3_OLI4978A1_A2-2%2Fccs_data%2F","smbServerName":"histonas2.histogenetics.com","smbShareName":"Volume1Backup","smbUsername":"cloudsync","smbPassword":"H1st0.Cloud","wgsRunId":1111,"wgsStatusViewerId":1141}
        */

        try {
            if (StringUtils.isAllEmpty(args)) {
                LOGGER.debug("Missing arguments. Argument List:" + Arrays.toString(args));
                return;
            }

            String argsString = Arrays.toString(args);
            LOGGER.info("Md5Checksum Arguments: {}", argsString);
            argsString = argsString.replaceAll("[\\{\\}\\[\\]]", "");
            args = argsString.split(",");
            LOGGER.info("args all: {}", Arrays.toString(args));

            InputArgs inputArgs = new InputArgs();
            setValuesFromArgsArray(inputArgs, args);

            LOGGER.info("Mapped InputArgs: {}", inputArgs);

            String decodeChecksumDir = URLDecoder.decode(inputArgs.getChecksumFilePath(), StandardCharsets.UTF_8.name());
            inputArgs.setChecksumFilePath(decodeChecksumDir);
            inputArgs.setChecksumFilePath(inputArgs.getChecksumFilePath().replace("\\", "/"));

            md5ChecksumService.doMd5Checksum(inputArgs); // Md5Checksum action calling
        } catch (Exception e) {
            LOGGER.error("Exception doMd5ChecksumProcess() : {}", e);
        }
    }

    public static void setValuesFromArgsArray(Object obj, String[] args) {
        Class<?> clazz = obj.getClass();
        for (String arg : args) {
            String[] keyValue = arg.split(":");
            if (keyValue.length == 2) {
                String key = keyValue[0].trim().replace("\"","");
                String value = keyValue[1].trim().replace("\"","");
                try {
                    Field field = clazz.getDeclaredField(key);
                    field.setAccessible(true);
                    setFieldValue(field, obj, value, key);
                } catch (NoSuchFieldException | IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private static void setFieldValue(Field field, Object obj, String value, String key) throws IllegalAccessException {
        if (field.getType().equals(Integer.class) || key.equals("gridIonRunId") || key.equals("gridIonStatusViewerId") || key.equals("userId")
    || key.equals("wgsRunId") || key.equals("wgsStatusViewerId")) {
            field.set(obj, Integer.valueOf(value) );
        } else if (field.getType().equals(String.class)) {
            field.set(obj, value);
        } else if (field.getType().equals(Boolean.class)) {
            field.set(obj, Boolean.valueOf(value));
        } else if (field.getType().equals(Double.class)) {
            field.set(obj, Double.valueOf(value));
        }
    }
}
