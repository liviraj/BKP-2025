package com.histo.md5checksum;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Md5ChecksumApplication implements CommandLineRunner {
	@Autowired
	private Md5ChecksumProcessor md5ChecksumProcess;
	public static void main(String[] args) {
		SpringApplication app = new SpringApplication(Md5ChecksumApplication.class);
		app.setWebApplicationType(WebApplicationType.NONE);
		app.run(args);
	}

	@Override
	public void run(String... args) throws Exception {
		md5ChecksumProcess.doMd5ChecksumProcess(args);
		return;
	}
}
