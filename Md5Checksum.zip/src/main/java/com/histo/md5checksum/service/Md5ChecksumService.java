package com.histo.md5checksum.service;

import com.histo.md5checksum.model.InputArgs;

public interface Md5ChecksumService {
    public void doMd5Checksum(InputArgs inputArgs);
}
