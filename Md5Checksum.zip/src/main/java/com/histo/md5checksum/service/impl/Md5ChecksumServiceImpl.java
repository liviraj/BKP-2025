package com.histo.md5checksum.service.impl;

import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.common.SmbPath;
import com.hierynomus.smbj.share.DiskShare;
import com.hierynomus.smbj.share.File;
import com.histo.md5checksum.config.PropertyConfig;
import com.histo.md5checksum.connection.ConnectionIntermittent;
import com.histo.md5checksum.model.*;
import com.histo.md5checksum.service.Md5ChecksumService;
import com.histo.md5checksum.util.Md5ChecksumUtil;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class Md5ChecksumServiceImpl implements Md5ChecksumService {
    public static final Logger LOGGER = LogManager.getLogger(Md5ChecksumServiceImpl.class.getName());

    private final PropertyConfig propertyConfig;
    private final ConnectionIntermittent connectionIntermittent;
    private File smbFile = null;

    private Map<String, String> md5ChecksumAndFileMaster = new LinkedHashMap<>();

    public Md5ChecksumServiceImpl(PropertyConfig propertyConfig, ConnectionIntermittent connectionIntermittent) {
        this.propertyConfig = propertyConfig;
        this.connectionIntermittent = connectionIntermittent;
    }

    @Override
    public void doMd5Checksum(InputArgs inputArgs) {
        try {
            InputInfoParam inputInfoParam = new InputInfoParam(inputArgs, propertyConfig);
            SmbPath smbPath = inputInfoParam.getDiskShare().getSmbPath();
            String basePath = smbPath.toUncPath().replace(".histogenetics.com", "");
            if (inputArgs.getChecksumFilePath().contains(basePath.replace("\\", "/"))) {
                inputArgs.setChecksumFilePath(
                        inputArgs.getChecksumFilePath()
                                .replace(basePath.replace("\\", "/"), "")
                );
            }
            if (inputArgs.getChecksumFilePath().startsWith("/")) {
                inputArgs.setChecksumFilePath(inputArgs.getChecksumFilePath().replaceFirst("/", ""));
            }

            String parentWindowsPath = smbPath.toUncPath().concat("\\").concat(inputArgs.getChecksumFilePath().replace("/", "\\"));

            if (inputArgs.getChecksumFilePath().contains(smbPath.toUncPath())) {
                inputArgs.setChecksumFilePath(inputArgs.getChecksumFilePath().replaceFirst(smbPath.toUncPath().concat("/"), ""));
            }

            if (!inputInfoParam.getDiskShare().folderExists(inputArgs.getChecksumFilePath().replace("\\", "/"))) {
                LOGGER.error("Given file path is not exist. Filepath: {}", parentWindowsPath);
                return;
            }

            LOGGER.info("MD5Checksum calculation started...");
            long startProcess = System.currentTimeMillis(); // start time
            // Calculate the checksum
            List<FileIdBothDirectoryInformation> fileList;
            fileList = inputInfoParam.getDiskShare().list(inputArgs.getChecksumFilePath() + "/");
            fileList = fileList.stream()
                    .filter(file -> !file.getFileName().equals(".") && !file.getFileName().equals(".."))
                    .filter(file -> !file.getFileName().toLowerCase().contains("checksum"))
                    .collect(Collectors.toList());
            List<FileIdBothDirectoryInformation> filterFolders = fileList.stream().filter(fileIdBothDirectoryInformation ->
                            inputInfoParam.getDiskShare().folderExists(
                                    inputArgs.getChecksumFilePath().concat(fileIdBothDirectoryInformation.getFileName())
                            )
                    ).collect(Collectors.toList());
            // calculate checksum sample folder one by one
            for (FileIdBothDirectoryInformation directoryInformation : fileList) {
                String concatPathAndSamplePath = "";
                boolean isFileExists = inputInfoParam.getDiskShare().fileExists(inputArgs.getChecksumFilePath().concat(directoryInformation.getFileName()));
                if (isFileExists) {
                    concatPathAndSamplePath = inputArgs.getChecksumFilePath().concat("/");
                } else {
                    concatPathAndSamplePath = inputArgs.getChecksumFilePath().concat(directoryInformation.getFileName()).concat("/");
                }

                String checksumFileName = concatPathAndSamplePath
                        .concat("md5checksum.txt");

                boolean isCheckSumFileExist = inputInfoParam.getDiskShare().fileExists(checksumFileName);
                if (isCheckSumFileExist) {
                    String md5CheckSumExistPath = smbPath.toUncPath().concat("\\").concat(checksumFileName);
                    LOGGER.error("Checksum file already exist. File path: {}", md5CheckSumExistPath.replace("/", "\\"));
                    continue;
                }
                smbFileToChecksum(inputInfoParam.getDiskShare(), concatPathAndSamplePath);
                if (filterFolders.size() == 0) {
                    break;
                }
            }

            long endProcess = System.currentTimeMillis();

            LOGGER.info("MD5Checksum calculation completed.");
            LOGGER.info("Total MD5Checksum calculation time: {}", Md5ChecksumUtil.getDurationBreakdown(endProcess - startProcess));

            if (inputArgs.getProgramType() != null && inputArgs.getProgramType().equals(String.valueOf(ProgramType.GRIDION))) {
                GridIonLocalTransferStatus localTransferStatus = new GridIonLocalTransferStatus();
                localTransferStatus.setGridIonStatusViewerId(inputArgs.getGridIonStatusViewerId());
                localTransferStatus.setSourcePath(parentWindowsPath.replace("/","\\"));
                localTransferStatus.setStatus(StatusMasterEnum.COMPLETED.getStatusId());

                // call update local transfer status api
                ResponseEntity<String> ltsResponse = connectionIntermittent.callUpdateGridIonLTSUrl(localTransferStatus);
                LOGGER.info("GridIon LTS update API cal response: {}", ltsResponse);

                // save MD5checksum details in DB using pacbio web call
                String response = connectionIntermittent.callSaveGridIonMD5ChecksumDetails(inputArgs.getGridIonRunId(), md5ChecksumAndFileMaster);
                LOGGER.info("MD5 save web call response: {}", response);
                
            } else {
                LocalTransferStatus localTransferStatus = new LocalTransferStatus();
                if (!parentWindowsPath.contains("ccs_data")) {
                    parentWindowsPath = parentWindowsPath.concat(parentWindowsPath.endsWith("\\") ? "ccs_data/":"/ccs_data/");
                }
                localTransferStatus.setSourcePath(parentWindowsPath.replace("/","\\"));
                localTransferStatus.setStatus(StatusMasterEnum.COMPLETED.getStatusId());
                localTransferStatus.setWgsStatusViewerId(inputArgs.getWgsStatusViewerId());

                // call update local transfer status api
                ResponseEntity<String> ltsUpdataResponse = connectionIntermittent.callUpdateLocalTransferStatus(localTransferStatus);
                LOGGER.info("LTS update API cal response: {}", ltsUpdataResponse);
                // save md5checksum details in DB using pacbio web call
                String response = connectionIntermittent.callSaveWGSMD5ChecksumDetails(inputArgs.getWgsRunId(), md5ChecksumAndFileMaster);
                LOGGER.info("MD5 save web call response: {}", response);
            }
            return;
        } catch (Exception e) {
            LOGGER.error("Exception in doMd5Checksum(): {}", e);
        }
    }

    private void smbFileToChecksum(DiskShare diskShare, String filePath) throws IOException {
        Map<String, String> md5ChecksumAndFile = new LinkedHashMap<>();
        SmbPath smbPath = diskShare.getSmbPath();
        String parentWindowsPath = smbPath.toUncPath();

        filePath = filePath.replace(diskShare.getSmbPath().toUncPath(), "");
        filePath = filePath.replace("\\", "/");
        if (!filePath.endsWith("/")) {
            filePath = filePath + "/";
        }

        List<FileIdBothDirectoryInformation> fileList;
        fileList = diskShare.list(filePath + "/");
        fileList = fileList.stream()
                .filter(file -> !file.getFileName().equals(".") && !file.getFileName().equals(".."))
                .filter(file -> !file.getFileName().toLowerCase().contains("checksum"))
                .collect(Collectors.toList());

        String finalFilePath = filePath;
        boolean containsFiles = fileList.stream()
                .anyMatch(fileInfo -> diskShare.fileExists(finalFilePath.concat("/").concat(fileInfo.getFileName())));

        boolean containsFolders = fileList.stream()
                .anyMatch(fileInfo -> !diskShare.fileExists(finalFilePath.concat("/").concat(fileInfo.getFileName())));

        if (containsFiles && containsFolders) {
            Collections.reverse(fileList);
        }

        if (containsFiles && !containsFolders) {
            String checksumFileNmeMaster = filePath.concat("/")
                    .concat("md5checksum.txt");
            diskShare.fileExists(checksumFileNmeMaster);
            if(!diskShare.fileExists(checksumFileNmeMaster)) {
                smbFile = createSmbFile(diskShare, checksumFileNmeMaster);
            }
        }
        md5ChecksumAndFile.put("Filename", "        Checksum                                ");
        for (FileIdBothDirectoryInformation fileInfo : fileList) {
            String fileName = fileInfo.getFileName();
            String secondaryFilePath = filePath + fileName;
            boolean isFileExist = diskShare.fileExists(secondaryFilePath);
            if (!isFileExist) {
                md5ChecksumAndFile.clear();
                // It is a directory
                String checksumFileName = filePath.concat("/")
                        .concat(fileName)
                        .concat("/")
                        .concat("md5checksum.txt");

                boolean isCheckSumFileExist = diskShare.fileExists(checksumFileName);
                if (isCheckSumFileExist) {
                    String md5CheckSumExistPath = smbPath.toUncPath().concat("\\").concat(checksumFileName);
                    LOGGER.error("Checksum file already exist. File path: {}", md5CheckSumExistPath.replace("/", "\\"));
                    continue;
                }
                List<FileIdBothDirectoryInformation> innerFileList = diskShare.list(secondaryFilePath);
                innerFileList = innerFileList.stream()
                        .filter(file -> !file.getFileName().equals(".") && !file.getFileName().equals(".."))
                        .filter(file -> !file.getFileName().toLowerCase().contains("checksum"))
                        .collect(Collectors.toList());
                boolean onlyContainsFolders = innerFileList.stream()
                        .anyMatch(innerFileInfo -> !diskShare.fileExists(secondaryFilePath.concat("/").concat(innerFileInfo.getFileName())));
                if (!onlyContainsFolders) {
                    smbFile = createSmbFile(diskShare, checksumFileName);
                }
                smbFileToChecksum(diskShare, secondaryFilePath);
            } else {
                // It is a file
                // Get the input stream for the  file
                try (File source = diskShare.openFile(secondaryFilePath, EnumSet.of(AccessMask.GENERIC_READ),
                        null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null)) {
                    InputStream inputStream = new BufferedInputStream(source.getInputStream());
                    String md5Checksum = calculateFileMd5Checksum(inputStream);
                    String fullPath = parentWindowsPath.concat("\\").concat(secondaryFilePath);
                    fullPath = fullPath.replace("/", "\\");
                    md5ChecksumAndFile.put(fileName, md5Checksum);
                    md5ChecksumAndFileMaster.put(fullPath, md5Checksum);
                } catch (Exception e) {
                    LOGGER.error("smbFileToChecksum() method: {}",e);
                }
            }
        }
        if (!md5ChecksumAndFile.isEmpty() && smbFile != null) {
            writeCheckSumDetailsInFile(md5ChecksumAndFile, smbFile);
        }

        md5ChecksumAndFile.clear();
    }

    private void writeCheckSumDetailsInFile(Map<String, String> md5ChecksumAndFile, File smbFile) throws IOException {

        try (OutputStream outputStream = smbFile.getOutputStream()) {
            for (Map.Entry<String, String> entry : md5ChecksumAndFile.entrySet()) {
                String filepathWithChecksum = entry.getValue().concat("\t")
                        .concat(entry.getKey())
                        .concat("\n");
                byte[] mdfChecksumBytes = filepathWithChecksum.getBytes(StandardCharsets.UTF_8);
                outputStream.write(mdfChecksumBytes);
            }
        }
    }

    private String calculateFileMd5Checksum(InputStream inputStream) throws IOException {
        return DigestUtils.md5Hex(inputStream);
    }

    private File createSmbFile(DiskShare diskShare, String file) {
        File smbFileCreate = diskShare.openFile(file, EnumSet.of(AccessMask.GENERIC_WRITE)
                , null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_CREATE, null);
        return smbFileCreate;
    }
}
