package com.histo.md5checksum.model;

import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import com.histo.md5checksum.config.PropertyConfig;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.IOException;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class InputInfoParam {
    private DiskShare diskShare;

    public InputInfoParam(InputArgs input, PropertyConfig propertyConfig) {
        SMBClient clientSource = new SMBClient();
        try {
            Connection connectionSource = clientSource.connect(input.getSmbServerName());
            AuthenticationContext authContextSource = new AuthenticationContext(input.getSmbUsername(), input.getSmbPassword().toCharArray(), propertyConfig.getSmbDomainName());
            Session sessionSource = connectionSource.authenticate(authContextSource);
            this.diskShare = (DiskShare) sessionSource.connectShare(input.getSmbShareName());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
