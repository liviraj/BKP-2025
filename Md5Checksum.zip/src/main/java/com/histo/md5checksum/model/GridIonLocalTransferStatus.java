package com.histo.md5checksum.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class GridIonLocalTransferStatus {
	private int gridIonStatusViewerId;
	private int status;
	private String sourcePath;
	private int uploadTypeId;
	private String failureReason;
}
