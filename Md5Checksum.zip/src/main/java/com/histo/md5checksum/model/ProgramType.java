package com.histo.md5checksum.model;

public enum ProgramType {
    WGS,GRIDION
}
