package com.histo.md5checksum.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class InputArgs {
    private String checksumFilePath;
    private String smbServerName;
    private String smbShareName;
    private String smbUsername;
    private String smbPassword;
    private Integer wgsRunId;
    private Integer wgsStatusViewerId;
    private Integer gridIonRunId;
    private Integer gridIonStatusViewerId;
    private String programType;
}
