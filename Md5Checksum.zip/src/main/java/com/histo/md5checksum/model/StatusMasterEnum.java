package com.histo.md5checksum.model;

public enum StatusMasterEnum {
    NOT_STARTED(1),
    IN_PROGRESS(2),
    COMPLETED(3),
    FAILED(4),
    NOT_APPLICABLE(5);

    private int statusId;

    StatusMasterEnum(int statusId) {
        this.statusId = statusId;
    }

    public int getStatusId() {
        return statusId;
    }
}
