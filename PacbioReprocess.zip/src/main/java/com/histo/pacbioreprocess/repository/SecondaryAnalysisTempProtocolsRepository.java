package com.histo.pacbioreprocess.repository;

import com.histo.pacbioreprocess.entity.SecondaryAnalysisTempProtocols;
import org.springframework.data.jpa.repository.JpaRepository;
public interface SecondaryAnalysisTempProtocolsRepository extends JpaRepository<SecondaryAnalysisTempProtocols, Integer> {
    SecondaryAnalysisTempProtocols findByTempProtocolName(String tempProtocolName);
}
