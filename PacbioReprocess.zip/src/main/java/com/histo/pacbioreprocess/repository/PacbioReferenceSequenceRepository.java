package com.histo.pacbioreprocess.repository;

import com.histo.pacbioreprocess.entity.PacbioReferenceSequence;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PacbioReferenceSequenceRepository extends JpaRepository<PacbioReferenceSequence, Integer> {
    boolean existsByHash(String hash);
}