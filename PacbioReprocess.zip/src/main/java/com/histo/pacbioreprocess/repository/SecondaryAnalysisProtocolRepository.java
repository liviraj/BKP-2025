package com.histo.pacbioreprocess.repository;

import com.histo.pacbioreprocess.entity.SecondaryAnalysisProtocol;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SecondaryAnalysisProtocolRepository extends JpaRepository<SecondaryAnalysisProtocol, Integer> {
    SecondaryAnalysisProtocol findByProtocolName(String protocolName);
}
