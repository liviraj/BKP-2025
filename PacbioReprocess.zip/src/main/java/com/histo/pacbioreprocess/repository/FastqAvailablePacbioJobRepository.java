package com.histo.pacbioreprocess.repository;

import com.histo.pacbioreprocess.entity.FastqAvailablePacbioJob;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface FastqAvailablePacbioJobRepository extends JpaRepository<FastqAvailablePacbioJob, Long> {
    Optional<FastqAvailablePacbioJob> findByJobId(String jobId);
}