package com.histo.pacbioreprocess.service;

public interface MissedAlleleSetsNewLogicService {
    public String missedAlleleSetFill(String missedAlleleSet, String protocolName, String alleleSetId);
}
