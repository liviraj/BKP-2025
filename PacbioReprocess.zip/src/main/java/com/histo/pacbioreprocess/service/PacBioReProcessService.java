package com.histo.pacbioreprocess.service;

import com.histo.pacbioreprocess.model.*;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PacBioReProcessService {

    public ResponseEntity<List<ReProcessOutput>> addReprocess(List<PacReProcessInput> pacReProcessInputs);

    public ResponseEntity<String> updateStatus(ShellScriptStatusInput input);

    public ResponseEntity<List<ReProcessOutput>> alleleValidation(List<PacReProcessInput> input);

    public ResponseEntity<List<RequestedJobs>> getRequestedJobs();

    public ResponseEntity<ReprocessNAJob> getReprocessNAJobs();

    public ResponseEntity<Object> updateReprocessStatus(ReprocessNAUpdateJob reprocessNAUpdateJob);
}
