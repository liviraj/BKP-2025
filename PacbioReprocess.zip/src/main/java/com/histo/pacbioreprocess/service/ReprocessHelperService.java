package com.histo.pacbioreprocess.service;

import com.histo.pacbioreprocess.model.PacReProcessInput;
import com.histo.pacbioreprocess.model.SequenceDetail;

import java.util.Map;

public interface ReprocessHelperService {
    public Map<String, SequenceDetail> constructSequenceForPacbioDropout(PacReProcessInput pacReProcessInput);
    public Map<String, String> constructSequenceForNewAlleleConfirmInPacbio(PacReProcessInput pacReProcessInput);
}
