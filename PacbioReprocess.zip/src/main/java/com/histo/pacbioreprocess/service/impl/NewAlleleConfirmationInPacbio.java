package com.histo.pacbioreprocess.service.impl;

import com.hierynomus.msfscc.fileinformation.FileStandardInformation;
import com.hierynomus.smbj.share.File;
import com.histo.pacbioreprocess.config.PropertyConfig;
import com.histo.pacbioreprocess.config.ReprocessDiskShareConfig;
import com.histo.pacbioreprocess.entity.PacbioReferenceSequence;
import com.histo.pacbioreprocess.entity.SecondaryAnalysisProtocol;
import com.histo.pacbioreprocess.entity.SecondaryAnalysisTempProtocols;
import com.histo.pacbioreprocess.model.PacReProcessInput;
import com.histo.pacbioreprocess.repository.PacbioReferenceSequenceRepository;
import com.histo.pacbioreprocess.repository.SecondaryAnalysisProtocolRepository;
import com.histo.pacbioreprocess.repository.SecondaryAnalysisTempProtocolsRepository;
import com.histo.pacbioreprocess.service.ReprocessHelperService;
import com.histo.pacbioreprocess.service.ReprocessService;
import com.histo.pacbioreprocess.util.HashingUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.*;

import static com.hierynomus.msdtyp.AccessMask.FILE_APPEND_DATA;
import static com.hierynomus.mssmb2.SMB2CreateDisposition.FILE_OPEN;
import static com.hierynomus.mssmb2.SMB2ShareAccess.ALL;

@Service("newAlleleConfirmationInPacbio")
public class NewAlleleConfirmationInPacbio implements ReprocessService {
    private static final Logger LOGGER = LogManager.getLogger(NewAlleleConfirmationInPacbio.class);

    private final PacbioReferenceSequenceRepository pacbioReferenceSequenceRepository;
    private final ReprocessHelperService reprocessHelperService;
    private final PropertyConfig propertyConfig;
    private final SecondaryAnalysisProtocolRepository secondaryAnalysisProtocolRepository;
    private final SecondaryAnalysisTempProtocolsRepository secondaryAnalysisTempProtocolsRepository;

    public NewAlleleConfirmationInPacbio(PacbioReferenceSequenceRepository pacbioReferenceSequenceRepository
            , ReprocessHelperService reprocessHelperService
            , PropertyConfig propertyConfig, SecondaryAnalysisProtocolRepository secondaryAnalysisProtocolRepository, SecondaryAnalysisTempProtocolsRepository secondaryAnalysisTempProtocolsRepository) {
        this.pacbioReferenceSequenceRepository = pacbioReferenceSequenceRepository;
        this.reprocessHelperService = reprocessHelperService;
        this.propertyConfig = propertyConfig;
        this.secondaryAnalysisProtocolRepository = secondaryAnalysisProtocolRepository;
        this.secondaryAnalysisTempProtocolsRepository = secondaryAnalysisTempProtocolsRepository;
    }

    @Override
    public ResponseEntity<Object> doReProcess(PacReProcessInput pacReProcessInput) {
        File protocolFile = null;
        ReprocessDiskShareConfig diskShareConfig = null;
        try {

            String hashSequence = HashingUtils.hashValue(pacReProcessInput.getRawSequence());
            boolean isSequenceExist = pacbioReferenceSequenceRepository.existsByHash(hashSequence);
            if (isSequenceExist) {
                return ResponseEntity.ok("Reprocess Completed");
            }

            List<String> refUrlSplit = Arrays.stream(propertyConfig.getReprocessReferenceUrl().replace("\\", "/").split("/"))
                    .filter(path -> !path.equalsIgnoreCase("")).toList();
            diskShareConfig = new ReprocessDiskShareConfig(propertyConfig.getReprocessServerUsername()
                    , propertyConfig.getReprocessServerPassword()
                    , propertyConfig.getReprocessServerDomain()
                    , refUrlSplit.get(0), refUrlSplit.get(1));

            String referenceTempProtocolLocation = propertyConfig.getReprocessReferenceUrl()
                    .replace("//", "").replace(refUrlSplit.get(0) + "/", "")
                    .replace(refUrlSplit.get(1) + "/", "");

            referenceTempProtocolLocation = referenceTempProtocolLocation + propertyConfig.getTempReferenceFilePath();

            SecondaryAnalysisProtocol protocolDetail = secondaryAnalysisProtocolRepository.findByProtocolName(pacReProcessInput.getProtocolName());
            if (protocolDetail == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Given protocol not found");
            }
            Optional<SecondaryAnalysisTempProtocols> tempProtocol = secondaryAnalysisTempProtocolsRepository.findById(protocolDetail.getSecondaryAnalysisTempProtocolId());
            if (tempProtocol.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Temp protocol not found");
            }

            referenceTempProtocolLocation = referenceTempProtocolLocation
                    .concat(tempProtocol.get().getTempProtocolName()).concat(".fasta");

            boolean isReferenceProtocolFileExist = diskShareConfig.getDiskShare().fileExists(referenceTempProtocolLocation);
            if (!isReferenceProtocolFileExist) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Protocol file not found");
            }
            Map<String, String> seqNameAndSeqMap = reprocessHelperService.constructSequenceForNewAlleleConfirmInPacbio(pacReProcessInput);

            protocolFile = diskShareConfig.getDiskShare().openFile(referenceTempProtocolLocation
                    , EnumSet.of(FILE_APPEND_DATA)
                    , null
                    , ALL
                    , FILE_OPEN
                    , null);

            FileStandardInformation fsi = protocolFile.getFileInformation(FileStandardInformation.class);
            long fileSize = fsi.getEndOfFile();

            for (Map.Entry<String, String> seqNameAndSeqEntry : seqNameAndSeqMap.entrySet()) {
                PacbioReferenceSequence pacbioReferenceSequence = new PacbioReferenceSequence();
                pacbioReferenceSequence.setHash(hashSequence);
                pacbioReferenceSequence.setSequenceName(seqNameAndSeqEntry.getKey());
                pacbioReferenceSequence.setSequence(pacReProcessInput.getRawSequence());
                pacbioReferenceSequence.setAddedOn(new Date());
                pacbioReferenceSequence.setAlleleSetVersion(pacReProcessInput.getAlleleSetVersion());
                pacbioReferenceSequence.setSecondaryAnalysisTempProtocolId(tempProtocol.get().getSecondaryAnalysisTempProtocolId());

                pacbioReferenceSequenceRepository.save(pacbioReferenceSequence);
                synchronized (protocolFile) {
                    String appendData = seqNameAndSeqEntry.getKey() + "\n" + seqNameAndSeqEntry.getValue() + "\n";
                    protocolFile.write(appendData.getBytes(StandardCharsets.UTF_8), fileSize);
                    protocolFile.flush();
                }
                fsi = protocolFile.getFileInformation(FileStandardInformation.class);
                fileSize = fsi.getEndOfFile();
            }
            return ResponseEntity.ok("Reprocess Completed");
        } catch (Exception e) {
            LOGGER.error("doReProcess() Exception: {}", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        } finally {
            try {
                if (protocolFile != null) {
                    protocolFile.close();
                }
                if (diskShareConfig != null) {
                    diskShareConfig.close();
                }
            } catch (Exception e) {
                LOGGER.error("doReProcess() Exception: {}", e);
            }
        }
    }
}
