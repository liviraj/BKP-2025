package com.histo.pacbioreprocess.service;

import com.histo.pacbioreprocess.model.PacReProcessInput;
import org.springframework.http.ResponseEntity;

public interface ReprocessService {
    public ResponseEntity<Object> doReProcess(PacReProcessInput pacReProcessInput);
}
