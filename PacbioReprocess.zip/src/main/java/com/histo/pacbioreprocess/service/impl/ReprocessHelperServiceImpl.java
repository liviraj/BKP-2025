package com.histo.pacbioreprocess.service.impl;

import com.histo.pacbioreprocess.config.SqlConnectionSetup;
import com.histo.pacbioreprocess.model.*;
import com.histo.pacbioreprocess.service.ReprocessHelperService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ReprocessHelperServiceImpl implements ReprocessHelperService {
    private static final Logger LOGGER = LogManager.getLogger(ReprocessHelperServiceImpl.class.getName());
    private Field[] hlaGenomeDataModelFields = HLAGenomeData.class.getDeclaredFields();

    @Override
    public Map<String, SequenceDetail> constructSequenceForPacbioDropout(PacReProcessInput pacReProcessInput) {
        Map<String, SequenceDetail> newSequenceConstruct = new LinkedHashMap<>();
        try {
            // Step 1: Retrieve allele segment sequences for all gene details
            List<HLAGenomeRawData> alleleSegSeqs = pacReProcessInput.getGeneDetails().stream()
                    .flatMap(geneDetail -> getSegmentSequenceByAllele(geneDetail.getAllele(),
                            Integer.parseInt(pacReProcessInput.getAlleleSetVersion())).stream())
                    .distinct()
                    .toList();

            // Step 2: Fetch gene names with regions map and group allele data by allele name
            Map<String, List<String>> geneNameWithRegionsMap = getAllGeneNamWithRegions(pacReProcessInput.getGenName());
            Map<String, List<HLAGenomeData>> alleleDataByAlleleWiseMap = getGenomeDataGroupByAllele(alleleSegSeqs);

            // Step 3: Retrieve and process primer sequences
            PrimerSequenceFromSP primerDataByGeneName = getPrimerSequence(pacReProcessInput);

            // Step 4: Construct sequences for each allele data group
            for (Map.Entry<String, List<HLAGenomeData>> seqSeqMap : alleleDataByAlleleWiseMap.entrySet()) {
                List<String> geneFields = geneNameWithRegionsMap.get(pacReProcessInput.getGenName());
                for (HLAGenomeData alleleDataForKeyGene : seqSeqMap.getValue()) {
                    String rawGenomeSequence = extractRawGenomeSequence(alleleDataForKeyGene, geneFields);
                    if (primerDataByGeneName != null) {
                        constructAndAddSequence(seqSeqMap.getKey(), rawGenomeSequence, primerDataByGeneName, newSequenceConstruct);
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("Error constructing sequence for Pacbio dropout: ", e);
        }
        return newSequenceConstruct;
    }

    // Helper method to retrieve primer sequence based on input
    private PrimerSequenceFromSP getPrimerSequence(PacReProcessInput pacReProcessInput) {
        List<PrimerSequenceFromSP> primerSequenceList = getPrimerSequenceFromSP(
                pacReProcessInput.getProtocolName(),
                pacReProcessInput.getGenName(),
                pacReProcessInput.getPrimerName()
        );
        String primerName = pacReProcessInput.getPrimerName().trim();
        return primerSequenceList.stream()
                .filter(primer -> primer.getPrimerName().trim().equalsIgnoreCase(primerName))
                .findFirst()
                .orElse(null);
    }

    // Helper method to extract raw genome sequence
    private String extractRawGenomeSequence(HLAGenomeData alleleDataForKeyGene, List<String> geneFields) {
        return Arrays.stream(hlaGenomeDataModelFields)
                .filter(field -> geneFields.contains(field.getName()))
                .map(field -> {
                    try {
                        field.setAccessible(true);
                        return field.get(alleleDataForKeyGene) != null ? field.get(alleleDataForKeyGene).toString() : "";
                    } catch (IllegalAccessException e) {
                        LOGGER.warn("Unable to access field: " + field.getName(), e);
                        return "";
                    }
                })
                .collect(Collectors.joining());
    }

    // Helper method to construct sequence and add to the result map
    private void constructAndAddSequence(String alleleName, String rawGenomeSequence, PrimerSequenceFromSP primerData, Map<String, SequenceDetail> result) {
        String alleleNameReplaced = alleleName.replaceAll("[*:]", "_");
        String fPrimer = primerData.getFwdPrimerSequence();
        String rPrimer = primerData.getRevPrimerSequence();
        String trimmedSequence = rawGenomeSequence.replace(fPrimer, "").replace(rPrimer, "");

        String forwardAdapter = primerData.getFrdAdapterSequence();
        String reverseAdapter = primerData.getRevAdapterSequence();
        String newSequence = forwardAdapter + fPrimer + trimmedSequence + rPrimer + reverseAdapter;
        newSequence = newSequence.replace(".", "");

        String formattedAlleleName = String.format(">HLA_%s_%s_%s_%d_bp",
                primerData.getPrimerName(),
                primerData.getPrimerName(),
                alleleNameReplaced,
                newSequence.length());

        SequenceDetail sequenceDetail = new SequenceDetail();
        sequenceDetail.setConstructedSeq(newSequence);
        sequenceDetail.setRawSequence(rawGenomeSequence);
        result.put(formattedAlleleName, sequenceDetail);
    }

    @Override
    public Map<String, String> constructSequenceForNewAlleleConfirmInPacbio(PacReProcessInput pacReProcessInput) {
        Map<String, String> seqNameAndSeqMap = new LinkedHashMap<>();

        try {
            List<PrimerSequenceFromSP> primerSequenceList = getPrimerSequenceFromSP(pacReProcessInput.getProtocolName(), pacReProcessInput.getGenName()
                    , pacReProcessInput.getPrimerName());

            if (primerSequenceList.isEmpty()) {
                LOGGER.warn("No primer sequences found for protocol: " + pacReProcessInput.getProtocolName() + ", gene: " + pacReProcessInput.getGenName());
                return seqNameAndSeqMap;
            }

            HashMap<String, List<PrimerSequenceFromSP>> geneMap = separatePrimersByGeneName(primerSequenceList);
            List<PrimerSequenceFromSP> primerSequencesForGene = geneMap.get(pacReProcessInput.getGenName());

            if (primerSequencesForGene == null || primerSequencesForGene.isEmpty()) {
                LOGGER.warn("No primer sequences found for gene: " + pacReProcessInput.getGenName());
                return seqNameAndSeqMap;
            }

            PrimerSequenceFromSP primerSeq = primerSequencesForGene.get(0);

            String alleleNameAfterReplaced = pacReProcessInput.getAlleles().replaceAll("[*_:]", "_");
            String constructedSequence = primerSeq.getFrdAdapterSequence()
                    .concat(pacReProcessInput.getRawSequence())
                    .concat(primerSeq.getRevAdapterSequence());

            String constructedSequenceName = String.format(">HLA_%s_%s_%s_%d_bp",
                    primerSeq.getPrimerName(),
                    primerSeq.getPrimerName(),
                    alleleNameAfterReplaced,
                    constructedSequence.length());

            seqNameAndSeqMap.put(constructedSequenceName, constructedSequence);

        } catch (Exception e) {
            LOGGER.error("Error in constructing sequence: ", e);
        }

        return seqNameAndSeqMap;
    }

    private List<HLAGenomeRawData> getSegmentSequenceByAllele(String allele, Integer alleleSet) {
        LOGGER.info("Executing GetSegmentSequenceByAllele SP...");
        List<HLAGenomeRawData> alleleSegSeqs = new ArrayList<>();
        String sql = "EXEC ProbeMapAllelesHistoS.dbo.GetSegmentSequenceByAllele ?, ?";
        try (Connection connection = SqlConnectionSetup.getConnection();
             CallableStatement cstmt = connection.prepareCall(sql)) {

            cstmt.setString(1, allele);
            cstmt.setInt(2, alleleSet);

            try (ResultSet rs = cstmt.executeQuery()) {
                while (rs.next()) {
                    HLAGenomeRawData alleleSegSeq = new HLAGenomeRawData();
                    alleleSegSeq.setAlleleName(rs.getString("AlleleName"));
                    alleleSegSeq.setAlleleSequence(rs.getString("AlleleSequence") != null ? rs.getString("AlleleSequence") : "");
                    alleleSegSeq.setGeneName(rs.getString("Name"));
                    alleleSegSeq.setGenomeSegmentName(rs.getString("GenomeSegmentName"));
                    alleleSegSeqs.add(alleleSegSeq);
                }
            }

            LOGGER.info("Stored procedure executed successfully.");

        } catch (SQLException e) {
            LOGGER.error("SQL error while executing GetSegmentSequenceByAllele SP: ", e);
        } catch (Exception e) {
            LOGGER.error("Unexpected error while executing GetSegmentSequenceByAllele SP: ", e);
        }
        return alleleSegSeqs;
    }

    private Map<String, List<HLAGenomeData>> getGenomeDataGroupByAllele(List<HLAGenomeRawData> listGenome)
            throws NoSuchFieldException, IllegalAccessException {

        Map<String, List<HLAGenomeData>> genomDataAlleleWise = new LinkedHashMap<>();
        HLAGenomeData genomeData = null;
        String previouseAlleleName = "";
        boolean removeFirstGenome = false;

        for (int indexCount = 0; indexCount < listGenome.size(); indexCount++) {
            HLAGenomeRawData alleleData = listGenome.get(indexCount);
            String alleleName = alleleData.getAlleleName();
            List<HLAGenomeData> geneDataList = genomDataAlleleWise.computeIfAbsent(alleleName, k -> new ArrayList<>());

            // Check if genomeData needs to be added to geneDataList
            if (genomeData != null) {
                geneDataList.add(genomeData); // Add current genomeData to the list

                // Remove the first genome data if required
                if (removeFirstGenome && !geneDataList.isEmpty()) {
                    geneDataList.remove(0);
                }
            }

            // Initialize a new HLAGenomeData if necessary
            if (genomeData == null || !alleleData.getAlleleName().equals(previouseAlleleName)) {
                genomeData = new HLAGenomeData();
                genomeData.setAlleleName(alleleData.getAlleleName());
            }

            setFieldValue(genomeData, alleleData.getGenomeSegmentName(), alleleData.getAlleleSequence());

            if (indexCount == listGenome.size() - 1) {
                geneDataList.add(genomeData);
            }

            previouseAlleleName = alleleData.getAlleleName();
            removeFirstGenome = genomDataAlleleWise.containsKey(alleleName);
        }

        return genomDataAlleleWise;
    }

    private void setFieldValue(HLAGenomeData hLAGenomeData, String genomeSegName, String alleleSequence)
            throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException {
        switch (genomeSegName) {
            case "5UTR":
                hLAGenomeData.setUTR5(alleleSequence);
                break;
            case "3UTR":
                hLAGenomeData.setUTR3(alleleSequence);
                break;
            default:
                Field field = HLAGenomeData.class.getDeclaredField(genomeSegName);
                field.setAccessible(true);
                field.set(hLAGenomeData, alleleSequence);
                break;
        }
    }

    private LinkedHashMap<String, List<String>> getAllGeneNamWithRegions(String genes) {
        LOGGER.info("Executing getAllGeneNamWithRegions stored procedure...");
        LinkedHashMap<String, List<String>> geneWithRegionMap = new LinkedHashMap<>();

        // Split gene string into a Set for faster lookup
        Set<String> geneSet = Arrays.stream(genes.split(","))
                .map(String::trim)
                .collect(Collectors.toSet());

        // Use try-with-resources to ensure the statement and result set are closed properly
        try (Connection connection = SqlConnectionSetup.getConnection();
             CallableStatement cstmt = connection.prepareCall("EXEC ProbeMapAllelesHistoS.dbo.getAllGeneNameWithRegions");
             ResultSet rs = cstmt.executeQuery()) {

            LOGGER.info("Stored procedure executed successfully.");

            // Loop through the result set and process gene names and regions
            while (rs.next()) {
                String geneName = rs.getString("geneName");

                if (geneSet.contains(geneName)) {
                    String[] regions = rs.getString("region").split(",");

                    // Fetch or create the list of regions for the gene
                    for (String region : regions) {
                        geneWithRegionMap.computeIfAbsent(geneName, k -> new ArrayList<>()).add(region);
                    }
                }
            }
        } catch (SQLException e) {
            LOGGER.error("Error executing stored procedure: {}", e.getMessage(), e);
        }

        LOGGER.info("Completed getAllGeneNamWithRegions.");
        return geneWithRegionMap;
    }

    private List<PrimerSequenceFromSP> getPrimerSequenceFromSP(String protoColName, String gene, String primerName) {
        List<PrimerSequenceFromSP> primerList = new ArrayList<>();
        String priemrSP = "exec usp_GetAnalysisPrimerInfoByProtocolNameGenePrimerName '" + protoColName + "'" + ",'" + gene + "'" + ",'" + primerName + "'";

        // Use try-with-resources to ensure the statement and result set are closed properly
        try (Connection con = SqlConnectionSetup.getConnection();
             CallableStatement cstmt = con.prepareCall(priemrSP)) {
            LOGGER.info("Executing usp_GetAnalysisPrimerInfoForProtocolName '" + protoColName + "'");

            // Executing the CallableStatement
            ResultSet rs1 = cstmt.executeQuery();
            LOGGER.info("Done.");
            while (rs1.next()) {
                PrimerSequenceFromSP primerSequenceFromSP = new PrimerSequenceFromSP();
                primerSequenceFromSP.setPrimerName(rs1.getString("PrimerName").trim());
                primerSequenceFromSP.setPrimerSequence(rs1.getString("PrimerSequence").trim());
                primerSequenceFromSP.setGeneName(rs1.getString("GeneName").trim());
                primerSequenceFromSP.setFrdAdapterSequence(rs1.getString("FrdAdapterSequence").trim());
                primerSequenceFromSP.setRevAdapterSequence(rs1.getString("RevAdapterSequence").trim());
                primerSequenceFromSP.setFwdPrimerSequence(rs1.getString("FwdPrimerSequence").trim());
                primerSequenceFromSP.setRevPrimerSequence(rs1.getString("RevPrimerSequence").trim());
                primerList.add(primerSequenceFromSP);
            }
        } catch (Exception e) {
            LOGGER.info("Error :" + e.getMessage());
        }
        return primerList;
    }

    private HashMap<String, List<PrimerSequenceFromSP>> separatePrimersByGeneName(
            List<PrimerSequenceFromSP> primerSequenceList) {
        HashMap<String, List<PrimerSequenceFromSP>> geneMap = new HashMap<>();
        List<PrimerSequenceFromSP> primerKeyForMapList = null;
        for (PrimerSequenceFromSP primerData : primerSequenceList) {
            String primerGene = primerData.getGeneName();
            if (geneMap.containsKey(primerGene)) {
                List<PrimerSequenceFromSP> getData = geneMap.get(primerGene);
                getData.add(primerData);
                geneMap.put(primerGene, getData);
            } else {
                primerKeyForMapList = new ArrayList<>();
                primerKeyForMapList.add(primerData);
                geneMap.put(primerGene, primerKeyForMapList);
            }
        }
        return geneMap;
    }
}
