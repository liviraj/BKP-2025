package com.histo.pacbioreprocess.service.impl;

import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.mssmb2.SMBApiException;
import com.hierynomus.smbj.share.DiskShare;
import com.hierynomus.smbj.share.File;
import com.histo.pacbioreprocess.config.ProbeMapAllelesHistoSSqlConnectionSetup;
import com.histo.pacbioreprocess.config.PropertyConfig;
import com.histo.pacbioreprocess.config.ReprocessDiskShareConfig;
import com.histo.pacbioreprocess.config.SqlConnectionSetup;
import com.histo.pacbioreprocess.entity.FastqAvailablePacbioJob;
import com.histo.pacbioreprocess.model.*;
import com.histo.pacbioreprocess.repository.FastqAvailablePacbioJobRepository;
import com.histo.pacbioreprocess.service.MissedAlleleSetsNewLogicService;
import com.histo.pacbioreprocess.service.PacBioReProcessService;
import com.histo.pacbioreprocess.service.ReprocessService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Service
// @Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class PacBioReprocessServiceImp implements PacBioReProcessService {
    private static final Logger LOGGER = LogManager.getLogger(PacBioReprocessServiceImp.class.getName());

    private final MissedAlleleSetsNewLogicService missedAlleleSetsNewLogicService;
    private final ReprocessService newAlleleDropOutInPacbio;
    private final ReprocessService newAlleleConfirmationInPacbio;
    private final ExecutorService executorService = Executors.newCachedThreadPool();
    private final PropertyConfig propertyConfig;
    private final FastqAvailablePacbioJobRepository fastqAvailablePacbioJobRepository;

    public PacBioReprocessServiceImp(MissedAlleleSetsNewLogicService missedAlleleSetsNewLogicService
            , @Qualifier("newAlleleDropOutInPacbio") ReprocessService newAlleleDropOutInPacbio
            , @Qualifier("newAlleleConfirmationInPacbio") ReprocessService newAlleleConfirmationInPacbio, PropertyConfig propertyConfig, FastqAvailablePacbioJobRepository fastqAvailablePacbioJobRepository) {
        this.missedAlleleSetsNewLogicService = missedAlleleSetsNewLogicService;
        this.newAlleleDropOutInPacbio = newAlleleDropOutInPacbio;
        this.newAlleleConfirmationInPacbio = newAlleleConfirmationInPacbio;
        this.propertyConfig = propertyConfig;
        this.fastqAvailablePacbioJobRepository = fastqAvailablePacbioJobRepository;
    }

    @Override
    public ResponseEntity<List<ReProcessOutput>> addReprocess(List<PacReProcessInput> pacReProcessInputs) {
        List<ReProcessOutput> listOfOutPuts = new ArrayList<>();
        try {
            for (PacReProcessInput inputFromList : pacReProcessInputs) {
                ReProcessOutput reProcessOutput = processReProcessInput(inputFromList);
                listOfOutPuts.add(reProcessOutput);
            }
            return new ResponseEntity<>(listOfOutPuts, HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error("Exception in addReprocess(): {}", e.getMessage(), e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private ReProcessOutput processReProcessInput(PacReProcessInput inputFromList) throws IOException {
        String newJobSuffix = "";
        String program = null;
        boolean isEnabledMissedAlleleLogic = false;
        String copyJobSPResult = null;

        switch (inputFromList.getReProcessType()) {
            case AlleleConfirmation -> {
                newJobSuffix = "_ReProcess_IGV";
                program = ProgramList.IGV.getValue();
                isEnabledMissedAlleleLogic = true;
            }
            case TypingDiscrepancy -> {
                newJobSuffix = "_ReProcess_SA";
                program = ProgramList.SECONDARY.getValue();
                isEnabledMissedAlleleLogic = true;
            }
            case GO -> {
                newJobSuffix = "_ReProcess_GOL";
                program = ProgramList.GAP_GO_ISSUE.getValue();
            }
            case NEW_ALLELE_DROPOUT_IN_PACBIO -> {
                newJobSuffix = "_ReProcess_Dropout_NA";
                program = ProgramList.NEW_ALLELE_DROPOUT_IN_PACBIO.getValue();
            }
            case NEW_ALLELE_CONFIRMATION_IN_PACBIO -> {
                newJobSuffix = "_ReProcess_NA";
                program = ProgramList.NEW_ALLELE_CONFIRMATION_IN_PACBIO.getValue();
            }
            case REPROCESS_WITH_SPECIFIC_ALLELE_SET -> {
                newJobSuffix = "_Reprocess_CA";
                program = ProgramList.REPROCESS_WITH_SPECIFIC_ALLELE_SET.getValue();
                if (!newJobSuffix.isEmpty()) {
                    inputFromList.setNewJobName(inputFromList.getOldJobName() + newJobSuffix);
                }
                copyJobSPResult = copyPacBioJobAndAttachMultipleBlotsForReanalysis(inputFromList);
            }
            default -> LOGGER.warn("Unknown ReProcessType: {}", inputFromList.getReProcessType());
        }
        if (!newJobSuffix.isEmpty()) {
            inputFromList.setNewJobName(inputFromList.getOldJobName() + newJobSuffix);
        }

        ReprocessInsertRes insertResponse = new ReprocessInsertRes();
        insertResponse.setResult("Failed");

        if (!"Job Copied Successfully".equals(copyJobSPResult)) {
            return createReProcessOutput(inputFromList, program, insertResponse);
        }

        inputFromList.setStatus(Status.Initiated); // set status as initialed for copy jobs to temp folder
        insertResponse = insertStatusRequest(inputFromList);
        // String insertResponse = "Job Initiated";
        LOGGER.info("Insert Status: {}", insertResponse);

        if (insertResponse.getReProcessRequestId() != 0 && "Job Initiated".equals(insertResponse.getResult())) {

            // copy job primary location to temp folder
            boolean isJobCopiedToTempFolder = copyJobsToTempFolder(inputFromList);

            if (isJobCopiedToTempFolder) {
                boolean isStatusUpdated = updatePacbioReprocessStatusOnly(insertResponse.getReProcessRequestId(), Status.Requested);
                if (isStatusUpdated) {
                    handleReProcessLogic(inputFromList, insertResponse, isEnabledMissedAlleleLogic);
                }
            }
        }

        return createReProcessOutput(inputFromList, program, insertResponse);
    }

    private String copyPacBioJobAndAttachMultipleBlotsForReanalysis(PacReProcessInput inputFromList) {
        CallableStatement cstmt = null;
        ResultSet rs1 = null;
        String returnVale = "No Updates";
        Connection con = null;
        try {
            con = SqlConnectionSetup.getConnection();
            String query = "exec CopyPacBioJobandAttachMultipleBlotsForReanalysis ?, ?, ?, ?, ?, ?";
            cstmt = con.prepareCall(query);
            cstmt.setString(1, inputFromList.getOldJobName());
            cstmt.setString(2, inputFromList.getNewJobName());
            cstmt.setInt(3, inputFromList.getUserId());
            cstmt.setString(4, "Repeat");
            cstmt.setString(5, inputFromList.getBlotName() + "AS_NA");
            cstmt.setString(6, inputFromList.getBlotName());

            rs1 = cstmt.executeQuery();
            while (rs1.next()) {
                returnVale = rs1.getString("result");
            }
        } catch (SQLException e) {
            LOGGER.error(e.getMessage());
            return returnVale;
        } finally {
            try {
                if (rs1 != null) {
                    rs1.close();
                }
                if (cstmt != null) {
                    cstmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (Exception e) {
                LOGGER.error("Error :" + e.getMessage());
            }
        }
        return returnVale;
    }
    private boolean copyJobsToTempFolder(PacReProcessInput inputFromList) throws IOException {
        String tempFolderPath = propertyConfig.getReprocessTempFolderCopyPath();
        String primaryJobsPath = propertyConfig.getReprocessPrimaryJobsPath();

        List<String> tempPathSplit = splitAndFilterPath(tempFolderPath);
        List<String> primaryJobsPathSplit = splitAndFilterPath(primaryJobsPath);

        ReprocessDiskShareConfig tempDiskShareConfig = new ReprocessDiskShareConfig(
                propertyConfig.getReprocessServerUsername(),
                propertyConfig.getReprocessServerPassword(),
                propertyConfig.getReprocessServerDomain(),
                tempPathSplit.get(0), tempPathSplit.get(1)
        );

        ReprocessDiskShareConfig primaryDiskShareConfig = new ReprocessDiskShareConfig(
                propertyConfig.getReprocessServerUsername(),
                propertyConfig.getReprocessServerPassword(),
                propertyConfig.getReprocessServerDomain(),
                primaryJobsPathSplit.get(0), primaryJobsPathSplit.get(1)
        );

        String tempSMBPath = tempFolderPath.replace("//", "")
                .replace(tempPathSplit.get(0) + "/", "")
                .replace(tempPathSplit.get(1) + "/", "");
        String primaryJobsSMBPath = primaryJobsPath.replace("//", "")
                .replace(primaryJobsPathSplit.get(0) + "/", "")
                .replace(primaryJobsPathSplit.get(1) + "/", "");

        boolean isTempFolderPathExist = tempDiskShareConfig.getDiskShare().folderExists(tempSMBPath);
        if (!isTempFolderPathExist) {
            LOGGER.debug("The temp reprocess path not exist. Temp path: {}" + tempFolderPath.replace("/", "\\"));
            return false;
        }

        String jobFolderName = inputFromList.getJobId();
        if (!jobFolderName.startsWith("0")) {
            jobFolderName = "0" + jobFolderName;
        }
        primaryJobsSMBPath = primaryJobsSMBPath + jobFolderName + "/";


        boolean isJobExistInPrimaryLocation = primaryDiskShareConfig.getDiskShare().folderExists(primaryJobsSMBPath);
        // if job not existing getting path from table - T_FastqAvailablePacbioJobs
        if (!isJobExistInPrimaryLocation) {

            Optional<FastqAvailablePacbioJob> fastqAvailablePacbioJob = fastqAvailablePacbioJobRepository.findByJobId(inputFromList.getJobId());
            if (fastqAvailablePacbioJob.isEmpty()) {
                LOGGER.debug("The reprocess job not exist in T_FastqAvailablePacbioJobs table. JobId: {}", inputFromList.getJobId());
                return false;
            }
            String primaryJobLocation = fastqAvailablePacbioJob.get().getLocation().replace("\\", "/");
            if (!primaryJobLocation.endsWith("/")) {
                primaryJobLocation += "/";
            }

            List<String> primaryPathSplit = splitAndFilterPath(primaryJobLocation);

            primaryDiskShareConfig.close();

            primaryDiskShareConfig = new ReprocessDiskShareConfig(
                    propertyConfig.getReprocessServerUsername(),
                    propertyConfig.getReprocessServerPassword(),
                    propertyConfig.getReprocessServerDomain(),
                    primaryPathSplit.get(0), primaryPathSplit.get(1)
            );

            primaryJobsSMBPath = primaryJobLocation.replace("//", "")
                    .replace(primaryPathSplit.get(0) + "/", "")
                    .replace(primaryPathSplit.get(1) + "/", "");

            jobFolderName = primaryPathSplit.get(primaryPathSplit.size() - 1);
        }

        boolean isPrimaryFolderPathExist = primaryDiskShareConfig.getDiskShare().folderExists(primaryJobsSMBPath);
        if (!isPrimaryFolderPathExist) {
            String primaryJobLocation = primaryDiskShareConfig.getDiskShare().getSmbPath().toUncPath();
            primaryJobLocation = primaryJobLocation + "\\" + primaryJobsSMBPath;
            LOGGER.error("The primary reprocess job path not exist. Temp path: {}" + primaryJobLocation.replace("/", "\\"));
            return false;
        }

        tempSMBPath = tempSMBPath + jobFolderName;
        if (!tempSMBPath.equals("/")) {
            tempSMBPath += "/";
        }
        if (tempDiskShareConfig.getDiskShare().folderExists(tempSMBPath)) {
            return true;
        }
        // copy job folder primary location to temp location
        doSmbFileCopy(primaryJobsSMBPath, tempSMBPath, primaryDiskShareConfig.getDiskShare(), tempDiskShareConfig.getDiskShare());

        long tempJobFolderSize = getSMBFileOrFolderSize(tempDiskShareConfig.getDiskShare(), tempSMBPath);
        long primaryJobFolderSize = getSMBFileOrFolderSize(primaryDiskShareConfig.getDiskShare(), primaryJobsSMBPath);

        // closing temp and primary share after job copy to temp path
        tempDiskShareConfig.close();
        primaryDiskShareConfig.close();

        return tempJobFolderSize == primaryJobFolderSize;
    }

    private boolean updatePacbioReprocessStatusOnly(long id, Status status) {
        String statusQuery = "SELECT ProcessStatusCode FROM PacbioReprocessMasterStatus WHERE ProcessStatus = ?;";
        String updateQuery = "UPDATE PacbioReprocessRequest SET Status = ? WHERE ID = ?;";

        try (Connection con = SqlConnectionSetup.getConnection()) {

            // Step 1: Get the ProcessStatusCode
            int statusCode;
            try (PreparedStatement statusStmt = con.prepareStatement(statusQuery)) {
                statusStmt.setString(1, status.toString());
                try (ResultSet rs = statusStmt.executeQuery()) {
                    if (rs.next()) {
                        statusCode = rs.getInt("ProcessStatusCode");
                    } else {
                        LOGGER.warn("Status '{}' not found in PacbioReprocessMasterStatus table", status);
                        return false; // Status not found
                    }
                }
            }

            // Step 2: Update the PacbioReprocessRequest table with the retrieved status code
            try (PreparedStatement updateStmt = con.prepareStatement(updateQuery)) {
                updateStmt.setInt(1, statusCode);
                updateStmt.setLong(2, id);
                int affectedRows = updateStmt.executeUpdate();
                return affectedRows > 0;
            }

        } catch (SQLException e) {
            LOGGER.error("Error updating Pacbio reprocess status", e);
        }

        return false;
    }

    private void doSmbFileCopy(String sourcePath, String destinationPath, DiskShare sourceShare, DiskShare destinationShare) throws IOException {
        sourcePath = sourcePath.replace(sourceShare.getSmbPath().toUncPath(), "");
        destinationPath = destinationPath.replace(destinationShare.getSmbPath().toUncPath(), "");
        sourcePath = sourcePath.replace("\\", "/");
        destinationPath = destinationPath.replace("\\", "/");

        if (!destinationShare.folderExists(destinationPath)) {
            destinationShare.mkdir(destinationPath);
        }
        boolean isDirectory = sourceShare.getFileInformation(sourcePath).getStandardInformation().isDirectory();
        if (isDirectory) {
            List<FileIdBothDirectoryInformation> fileList = sourceShare.list(sourcePath + "/");
            fileList.removeIf(file -> file.getFileName().equals(".") || file.getFileName().equals(".."));
            for (FileIdBothDirectoryInformation fileInfo : fileList) {
                String fileName = fileInfo.getFileName();
                if (fileName.equals(".") || fileName.equals("..")) {
                    continue;
                }

                String sourceFilePath;
                String destinationFilePath;
                if (sourceShare.fileExists(sourcePath.concat("/").concat(fileName))) {
                    sourceFilePath = sourcePath + "/" + fileName;
                    destinationFilePath = destinationPath + "/" + fileName;
                } else {
                    sourceFilePath = sourcePath + "/" + fileName + "/";
                    destinationFilePath = destinationPath + "/" + fileName + "/";
                    fileName += "/"; // Adding '/' in directory
                }


                //if (fileName.endsWith("/") || fileName.endsWith("\\")) {
                if (sourceShare.folderExists(sourceFilePath)) {
                    // It is a directory
                    String[] desNestedDirectory = destinationFilePath.split("/");
                    String currentDirectory = "";
                    for (String directory : desNestedDirectory) {
                        currentDirectory += directory + "/";
                        if (!destinationShare.folderExists(currentDirectory)) {
                            destinationShare.mkdir(currentDirectory);
                        }
                    }
                    // destinationShare.mkdir(destinationFilePath);
                    doSmbFileCopy(sourceFilePath, destinationFilePath, sourceShare, destinationShare);
                } else {
                    // It is a file
                    try (InputStream inputStream = sourceShare.openFile(sourceFilePath, EnumSet.of(AccessMask.GENERIC_READ)
                            , null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null).getInputStream();
                         OutputStream outputStream = destinationShare.openFile(destinationFilePath, EnumSet.of(AccessMask.GENERIC_WRITE)
                                 , null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_CREATE, null).getOutputStream()) {
                        byte[] buffer = new byte[4096];
                        int bytesRead;
                        while ((bytesRead = inputStream.read(buffer)) != -1) {
                            outputStream.write(buffer, 0, bytesRead);
                        }
                    }
                }
            }
        } else {
            // It is a file
            try (InputStream inputStream = sourceShare.openFile(sourcePath, EnumSet.of(AccessMask.GENERIC_READ)
                    , null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null).getInputStream();
                 OutputStream outputStream = destinationShare.openFile(destinationPath, EnumSet.of(AccessMask.GENERIC_WRITE)
                         , null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_CREATE, null).getOutputStream()) {
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                }
            }
        }
    }

    private long getSMBFileOrFolderSize(DiskShare share, String directoryPath) throws SMBApiException {
        long totalSize = 0;
        directoryPath = directoryPath.replace(share.getSmbPath().toUncPath(), "");
        directoryPath = directoryPath.replace("\\", "/");
        boolean isDirectory = share.getFileInformation(directoryPath).getStandardInformation().isDirectory();
        if (!isDirectory) {
            File file = share.openFile(directoryPath, EnumSet.of(
                            AccessMask.GENERIC_READ)
                    , null
                    , SMB2ShareAccess.ALL
                    , SMB2CreateDisposition.FILE_OPEN
                    , null);
            totalSize += file.getFileInformation().getStandardInformation().getEndOfFile();
            file.closeSilently();
            return totalSize;
        }
        for (FileIdBothDirectoryInformation fileInfo : share.list(directoryPath)) {
            String fileName = fileInfo.getFileName();
            if (fileName.equals(".") || fileName.equals("..")) {
                continue;
            }

            String filePath = directoryPath + "/" + fileName;
            if (share.folderExists(filePath)) {
                totalSize += getSMBFileOrFolderSize(share, filePath);
            } else {
                File file = share.openFile(filePath, EnumSet.of(
                                AccessMask.GENERIC_READ)
                        , null
                        , SMB2ShareAccess.ALL
                        , SMB2CreateDisposition.FILE_OPEN
                        , null);
                totalSize += file.getFileInformation().getStandardInformation().getEndOfFile();
                file.closeSilently();
            }
        }
        return totalSize;
    }

    private List<String> splitAndFilterPath(String path) {
        return Arrays.stream(path.replace("\\", "/").split("/"))
                .filter(p -> !p.isEmpty()).toList();
    }

    private void handleReProcessLogic(PacReProcessInput inputFromList, ReprocessInsertRes insertResponse, boolean isEnabledMissedAlleleLogic) {
        if ("Job Initiated".equals(insertResponse.getResult())) {
            if (isEnabledMissedAlleleLogic) {
                missedAlleleSetLogic(inputFromList);
            } else {
                switch (inputFromList.getReProcessType()) {
                    case NEW_ALLELE_DROPOUT_IN_PACBIO -> newAlleleDropOutInPacbio.doReProcess(inputFromList);
                    case NEW_ALLELE_CONFIRMATION_IN_PACBIO -> newAlleleConfirmationInPacbio.doReProcess(inputFromList);
                    default -> LOGGER.warn("Unknown ReProcessType: {}", inputFromList.getReProcessType());
                }
            }
        }
    }

    private ReProcessOutput createReProcessOutput(PacReProcessInput inputFromList, String program, ReprocessInsertRes insertResponse) {
        ReProcessOutput reProcessOutput = new ReProcessOutput();
        reProcessOutput.setResponse(insertResponse.getResult());
        reProcessOutput.setJobName(inputFromList.getNewJobName());
        reProcessOutput.setProgram(program);
        reProcessOutput.setJobId(inputFromList.getJobId());
        reProcessOutput.setClientSampleId(inputFromList.getClientSampleId());
        reProcessOutput.setGeneName(inputFromList.getGenName());
        reProcessOutput.setAllelesAlreadyInProgress(inputFromList.getAlleles());
        return reProcessOutput;
    }

    private void missedAlleleSetLogic(PacReProcessInput inputFromList) {
        if (!inputFromList.getAlleles().isEmpty()) {
            try {
                updateMissedAlleleStatus(inputFromList, "InProgress");
                String status;
                if (inputFromList.getReProcessType() == ReProcessType.REPROCESS_WITH_SPECIFIC_ALLELE_SET) {
                    status = missedAlleleSetsNewLogicService.missedAlleleSetFill(inputFromList.getAlleles(),
                            inputFromList.getProtocolName(), inputFromList.getAlleleSetTobeProcessed());
                } else {
                    status = missedAlleleSetsNewLogicService.missedAlleleSetFill(inputFromList.getAlleles(),
                            inputFromList.getProtocolName(), inputFromList.getAlleleSetVersion());
                }
                updateMissedAlleleStatus(inputFromList, status);
            } catch (Exception e) {
                LOGGER.error("Error ;" + e.getMessage());
            }
        } else {
            updateMissedAlleleStatus(inputFromList, "Alleleset is empty to process");
            LOGGER.info("Allele-set is empty to process");
        }
    }

    @Override
    public ResponseEntity<String> updateStatus(ShellScriptStatusInput input) {
        try {
            String tableupdatedStatus = "";
            // Thread.sleep(60 * 1000L);
            if (input.getMessage() == null) {
                input.setMessage("");
            }
            tableupdatedStatus = updateReprocessStatusWithRetry(input);
            return new ResponseEntity<>(tableupdatedStatus, HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error("Exception updateStatus(): {}", e);
            Thread.currentThread().interrupt();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    @Override
    public ResponseEntity<List<ReProcessOutput>> alleleValidation(List<PacReProcessInput> input) {
        List<ReProcessOutput> listOfOutPuts = new ArrayList<>();
        try {
            for (PacReProcessInput inputFromList : input) {
                ReProcessOutput reProcessOutput = new ReProcessOutput();
                String missedAlleleASString = inputFromList.getAlleles();
                ArrayList<String> notValidAlleles = getAlleleNotPresentInDB(missedAlleleASString,
                        Integer.parseInt(inputFromList.getAlleleSetVersion()));
                reProcessOutput.setAlleleNotPresentInDB(String.join(",", notValidAlleles));
                List<String> items = new LinkedList<>(Arrays.asList(inputFromList.getAlleles().split("\\s*,\\s*")));
                for (String allele : notValidAlleles) {
                    items.remove(allele);
                }
                inputFromList.setAlleles(String.join(",", items));
                reProcessOutput.setAllelePresentInDB(inputFromList.getAlleles());
                reProcessOutput.setJobId(inputFromList.getJobId());
                reProcessOutput.setClientSampleId(inputFromList.getClientSampleId());
                reProcessOutput.setGeneName(inputFromList.getGenName());
                listOfOutPuts.add(reProcessOutput);
            }
            return new ResponseEntity<>(listOfOutPuts, HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error("Exception alleleValidation(): {}", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(listOfOutPuts);
        }
    }

    private String updateReprocessStatusWithRetry(ShellScriptStatusInput shellScriptStatusUpdate) throws SQLException {
        if (shellScriptStatusUpdate.getStatus() == 3) {
            executorService.submit(() -> {
                int maxRetries = 50;
                int retryCount = 0;
                int waitBetweenRetriesMillis = 30000;
                String result;

                while (retryCount < maxRetries) {
                    try {
                        result = updateReprocessStatus(shellScriptStatusUpdate);

                        if ("Success".equalsIgnoreCase(result) &&
                                isJobProcessed(shellScriptStatusUpdate.getNewJobName())) {
                            LOGGER.info("Job processed successfully after " + (retryCount + 1) + " attempt(s)");
                            return;
                        }

                        retryCount++;
                        LOGGER.warn("Retrying... Attempt " + retryCount + " - Job not yet processed.");
                        Thread.sleep(waitBetweenRetriesMillis);
                    } catch (Exception e) {
                        LOGGER.error("Exception during retry processing", e);
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
                LOGGER.error("Failed after " + maxRetries + " retries for job: " + shellScriptStatusUpdate.getNewJobName());
            });

            return "Success";
        } else {
            return updateReprocessStatus(shellScriptStatusUpdate);
        }
    }

    private boolean isJobProcessed(String jobName) {
        String query = "SELECT Processed FROM PACBIO_ANALYSIS.dbo.jobs WHERE JobName = ?";
        try (Connection con = SqlConnectionSetup.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {

            stmt.setString(1, jobName);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("Processed") == 1;
                }
            }
        } catch (SQLException e) {
            LOGGER.error("Error checking job processed status", e);
        }
        return false;
    }

    private String updateReprocessStatus(ShellScriptStatusInput shellScriptStatusUpdate) throws SQLException {
        Connection con = null;
        CallableStatement cstmt = null;
        String returnVale = "";
        try {
            con = SqlConnectionSetup.getConnection();
            String query = "exec Reprocess_UpdateJobStatus ?, ?, ?";
            cstmt = con.prepareCall(query);
            cstmt.setInt(1, shellScriptStatusUpdate.getAutoID());
            cstmt.setInt(2, shellScriptStatusUpdate.getStatus());
            cstmt.setString(3, shellScriptStatusUpdate.getNewJobName());
            LOGGER.info("Autoid = " + shellScriptStatusUpdate.getAutoID() + "status = " + shellScriptStatusUpdate.getStatus() + "new job name = " + shellScriptStatusUpdate.getNewJobName());
            ResultSet rs1 = cstmt.executeQuery();
            while (rs1.next()) {
                returnVale = rs1.getString("Result");
            }
            if (shellScriptStatusUpdate.getStatus() == 3 && isJobProcessed(shellScriptStatusUpdate.getNewJobName())) {
                sendEmailReprocessCompleted(shellScriptStatusUpdate.getAutoID(), shellScriptStatusUpdate.getStatus());
            }
            return returnVale;

        } catch (Exception e) {
            return "Failure";
        } finally {
            if (con != null) {
                con.close();
            }
        }
    }

    private String sendEmailReprocessCompleted(int autoID, int status) throws SQLException {
        CallableStatement cstmt;
        String returnVale = "";
        try (Connection con = SqlConnectionSetup.getConnection()) {
            cstmt = con.prepareCall(
                    "exec SCH_REPROCESSAUTOMATION ?, ?");
            cstmt.setInt(1, autoID);
            cstmt.setInt(2, status);
            ResultSet rs1 = cstmt.executeQuery();
            while (rs1.next()) {
                returnVale = rs1.getString("result");
            }
        } catch (SQLException e) {
            LOGGER.error(e.getMessage());
        }
        return returnVale;
    }

    private ReprocessInsertRes insertStatusRequest(PacReProcessInput pacReProcessInput) {
        CallableStatement cstmt = null;
        ResultSet rs1 = null;
        String returnVale = "No Updates";
        Connection con = null;
        ReprocessInsertRes res = new ReprocessInsertRes();
        try {
            con = SqlConnectionSetup.getConnection();
            String query = "exec InsertReprocessAPIRequestData ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?";
            cstmt = con.prepareCall(query);
            cstmt.setInt(1, pacReProcessInput.getSampleId());
            cstmt.setString(2, pacReProcessInput.getJobId());
            cstmt.setString(3, pacReProcessInput.getBarCodeId());
            cstmt.setString(4, pacReProcessInput.getProtocolName());
            cstmt.setString(5, pacReProcessInput.getOldJobName());
            cstmt.setString(6, pacReProcessInput.getNewJobName());
            cstmt.setInt(7, pacReProcessInput.getReProcessType().ordinal());
            cstmt.setString(8, pacReProcessInput.getGenName());
            cstmt.setString(9, pacReProcessInput.getRemarks());
            cstmt.setString(10, pacReProcessInput.getClientSampleId());
            cstmt.setString(11, pacReProcessInput.getStatus().toString());
            cstmt.setInt(12, pacReProcessInput.getUserId());
            cstmt.setString(13, pacReProcessInput.getAlleleSetVersion());
            cstmt.setString(14, pacReProcessInput.getAlleles());
            cstmt.setString(15, pacReProcessInput.getAlleleSetTobeProcessed());
            rs1 = cstmt.executeQuery();
            while (rs1.next()) {
                res.setResult(rs1.getString("result"));
                res.setReProcessRequestId(rs1.getLong("reProcessRequestId"));
            }
        } catch (SQLException e) {
            LOGGER.error(e.getMessage());
            res.setResult(e.getMessage());
            return res;
        } finally {
            try {
                if (rs1 != null) {
                    rs1.close();
                }
                if (cstmt != null) {
                    cstmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (Exception e) {
                LOGGER.error("Error :" + e.getMessage());
            }
        }
        return res;
    }

    @Override
    public ResponseEntity<List<RequestedJobs>> getRequestedJobs() {
        List<RequestedJobs> jobList = new ArrayList<>();
        Connection con = null;
        try {
            con = SqlConnectionSetup.getConnection();
            CallableStatement cstmt = con.prepareCall("exec getPacBioRequestedJobsList;");
            // Executing the CallableStatement
            ResultSet rs1 = cstmt.executeQuery();
            while (rs1.next()) {
                RequestedJobs jobs = new RequestedJobs();
                jobs.setAutoID(rs1.getInt(("autoID")));
                jobs.setBarcodeId(rs1.getString("barcodeId") + "--" + rs1.getString("barcodeId"));
                jobs.setJobId(rs1.getString("jobId"));
                jobs.setOriginalJobName(rs1.getString("originalJobName"));
                jobs.setNewJobName(rs1.getString("newJobName"));
                jobs.setProtocolName(rs1.getString("protocolName"));
                jobs.setAlleleSetVersion(rs1.getString("AlleleSetVersion"));
                jobs.setReProcessRequestType(rs1.getInt("ReProcessRequestType"));
                jobs.setClientSampleID(rs1.getString("ClientSampleID"));
                jobs.setCurrentAlleleSetVersion(rs1.getString("currentAlleleSetVersion"));
                jobs.setJobType(rs1.getString("jobType"));
                jobs.setSampleId(rs1.getInt("sampleId"));
                jobs.setMasterAlleleSetVersion(rs1.getString("masterAlleleSetVersion"));
                jobs.setSpecificAlleleSet(rs1.getString("specificAlleleSet"));
                jobList.add(jobs);
            }
            return ResponseEntity.status(HttpStatus.OK).body(jobList);
        } catch (Exception e) {
            LOGGER.error("Exception alleleValidation(): {}", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(jobList);
        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) {
                    LOGGER.error("Error :" + e.getMessage());
                }
            }
        }
    }

    @Override
    public ResponseEntity<ReprocessNAJob> getReprocessNAJobs() {
        ReprocessNAJob reprocessNAJob = new ReprocessNAJob();
        Connection con = null;
        try {
            con = SqlConnectionSetup.getConnection();
            CallableStatement cstmt = con.prepareCall("exec GetPendingPacbioReprocessExperimentDetails;");
            ResultSet rs1 = cstmt.executeQuery();
            while (rs1.next()) {
                reprocessNAJob.setId(rs1.getLong("NASVAExperimentID"));
                reprocessNAJob.setActualJobName(rs1.getString("ActualJobName"));
                reprocessNAJob.setNewJobName(rs1.getString("NewJobName"));
                reprocessNAJob.setJobID(rs1.getString("JobID"));
                reprocessNAJob.setAlleleSetID(rs1.getInt("AllelesetID"));
                reprocessNAJob.setAlleleSetVersion(rs1.getInt("AllelesetVersion"));
            }

        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(reprocessNAJob);
        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) {
                    LOGGER.error("Error :" + e.getMessage());
                }
            }
        }
        return ResponseEntity.status(HttpStatus.OK).body(reprocessNAJob);
    }

    @Override
    public ResponseEntity<Object> updateReprocessStatus(ReprocessNAUpdateJob reprocessNAUpdateJob) {
        Connection con = null;
        CallableStatement cstmt = null;
        try {
            con = SqlConnectionSetup.getConnection();
            String query = "exec updateNewAlleleSetValidationAutomationExperiments ?, ?";
            cstmt = con.prepareCall(query);
            cstmt.setLong(1, reprocessNAUpdateJob.getId());
            cstmt.setInt(2, reprocessNAUpdateJob.getPbProcessStatus());
            cstmt.executeQuery();
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) {
                    LOGGER.error("Error :" + e.getMessage());
                }
            }
        }
        return new ResponseEntity<>("Success", HttpStatus.OK);
    }

    private String updateMissedAlleleStatus(PacReProcessInput pacReProcessInput, String status) {
        CallableStatement cstmt = null;
        Connection con = null;
        try {
            con = SqlConnectionSetup.getConnection();
            String query = "exec Reprocess_UpdateMissedAlleleStatus ?, ?, ?, ?";
            cstmt = con.prepareCall(query);
            cstmt.setInt(1, pacReProcessInput.getSampleId());
            cstmt.setString(2, pacReProcessInput.getBarCodeId());
            cstmt.setString(3, pacReProcessInput.getJobId());
            cstmt.setString(4, status);
            ResultSet rs1 = cstmt.executeQuery();

        } catch (Exception e) {
            LOGGER.info("Error :" + e.getMessage());
            return "failure";
        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException se2) {
                LOGGER.error("updateMissedAlleleStatus() Error:{}", se2);
            }
        }
        return "Success";
    }


    private ArrayList<String> getAlleleNotPresentInDB(String missedAlleleSets, int version) {
        ArrayList<String> returnNotAddedAllele = new ArrayList<>();
        CallableStatement cstmt = null;
        Connection con = null;
        try {
            con = ProbeMapAllelesHistoSSqlConnectionSetup.getConnection();
            String query = "exec ReprocessGetAlleleNotAddedInDB ?, ?";
            cstmt = con.prepareCall(query);
            cstmt.setString(1, missedAlleleSets);
            cstmt.setInt(2, version);
            ResultSet rs1 = cstmt.executeQuery();
            while (rs1.next()) {
                returnNotAddedAllele.add(rs1.getString("AlleleNotPresent"));
            }
        } catch (Exception e) {
            LOGGER.info("Error :" + e.getMessage());
        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException se2) {
                LOGGER.error("getAlleleNotPresentInDB() Error:{}", se2);
            }
        }
        return returnNotAddedAllele;
    }
}
