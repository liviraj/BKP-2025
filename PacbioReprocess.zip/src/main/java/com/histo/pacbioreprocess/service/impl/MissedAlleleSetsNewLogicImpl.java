package com.histo.pacbioreprocess.service.impl;

import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.FileAttributes;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2CreateOptions;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import com.hierynomus.smbj.share.File;
import com.histo.pacbioreprocess.config.PropertyConfig;
import com.histo.pacbioreprocess.config.ReprocessDiskShareConfig;
import com.histo.pacbioreprocess.model.RefSeqValidation;
import com.histo.pacbioreprocess.service.MissedAlleleSetsNewLogicService;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.hierynomus.msdtyp.AccessMask.*;
import static com.hierynomus.mssmb2.SMB2CreateDisposition.*;
import static com.hierynomus.mssmb2.SMB2ShareAccess.ALL;

@Service
public class MissedAlleleSetsNewLogicImpl implements MissedAlleleSetsNewLogicService {
    private static final Logger LOGGER = LogManager.getLogger(MissedAlleleSetsNewLogicImpl.class);
    private final PropertyConfig propertyConfig;

    public MissedAlleleSetsNewLogicImpl(PropertyConfig propertyConfig) {
        this.propertyConfig = propertyConfig;
    }

    @Override
    public synchronized String missedAlleleSetFill(String missedAlleleSet, String protocolName, String alleleSetId) {
        try {
            List<String> urlSplit = splitAndFilterPath(propertyConfig.getReprocessReferenceUrl());
            List<String> protocolUrlSplit = splitAndFilterPath(propertyConfig.getReprocessServerProtocolUrl());

            ReprocessDiskShareConfig diskShareConfig = new ReprocessDiskShareConfig(
                    propertyConfig.getReprocessServerUsername(),
                    propertyConfig.getReprocessServerPassword(),
                    propertyConfig.getReprocessServerDomain(),
                    urlSplit.get(0), urlSplit.get(1)
            );

            String dbPathFile = extractDBPathFile(protocolName, diskShareConfig, protocolUrlSplit);
            if (dbPathFile.isEmpty()) {
                return logAndReturnError(missedAlleleSet, "DBPATH file not found");
            }

            // String allReferenceFastaFileLocation = buildPath(propertyConfig.getReprocessReferenceUrl(), urlSplit, alleleSetId);
            String allReferenceFastaFileLocation = buildPath(propertyConfig.getReprocessReferenceUrl(), urlSplit, "");
            String tempFolderForOriginalReferenceFile = buildPath(propertyConfig.getReprocessReferenceUrl(), urlSplit, propertyConfig.getTempReferenceFilePath());

            // String dbFileRefFile = buildPath(propertyConfig.getReprocessReferenceUrl(), urlSplit, "");
            if (!isFileExist(diskShareConfig, allReferenceFastaFileLocation + dbPathFile + ".fasta")) {
                return logAndReturnError(missedAlleleSet, "DBPATH file not found in " + allReferenceFastaFileLocation);
            }

            copyFileToTempFolder(diskShareConfig, allReferenceFastaFileLocation, tempFolderForOriginalReferenceFile, dbPathFile);

            // Map<String, String> alleleSetFromTempFile = readAlleleSetsFromFile(diskShareConfig, tempFolderForOriginalReferenceFile + dbPathFile + ".fasta");

            Map<String, String> matchedAlleleSetFromMasterFile = findMatchingAlleles(
                    diskShareConfig, alleleSetId, protocolName, missedAlleleSet, protocolUrlSplit
            );

            if (matchedAlleleSetFromMasterFile.isEmpty()) {
                return logAndReturnError(missedAlleleSet, "Alleles not matched in MasterReferenceFile");
            }

            // alleleSetFromTempFile.putAll(matchedAlleleSetFromMasterFile);

            writeAlleleSetsToFile(diskShareConfig, tempFolderForOriginalReferenceFile, dbPathFile, matchedAlleleSetFromMasterFile);

            deleteFastaFaiFileIfExist(diskShareConfig, tempFolderForOriginalReferenceFile + dbPathFile + ".fasta");

            LOGGER.info(missedAlleleSet + " appending the missed alleles Completed");

            return "Success";

        } catch (Exception e) {
            LOGGER.error("Error: " + e.getMessage());
            return "Failure: " + e.getMessage();
        }
    }

    private List<String> splitAndFilterPath(String path) {
        return Arrays.stream(path.replace("\\", "/").split("/"))
                .filter(p -> !p.isEmpty()).toList();
    }

    private String extractDBPathFile(String protocolName, ReprocessDiskShareConfig diskShareConfig, List<String> protocolUrlSplit) {
        String findDBPathFromReferenceFile = buildPath(propertyConfig.getReprocessServerProtocolUrl(), protocolUrlSplit, "setting/protocolParameter/");
        try (File findDBPathFile = diskShareConfig.getDiskShare().openFile(findDBPathFromReferenceFile + protocolName + ".txt",
                EnumSet.of(GENERIC_READ), null, ALL, FILE_OPEN, null);
             Scanner reader = new Scanner(new InputStreamReader(findDBPathFile.getInputStream()))) {

            while (reader.hasNextLine()) {
                String line = reader.nextLine();
                if (line.startsWith("DBPATH")) {
                    return line.split("/")[4].split("\\.")[0];
                }
            }
        }
        return "";
    }

    private String buildPath(String pathUrl, List<String> urlSplit, String pathToAdd) {
        return pathUrl.replace("//", "")
                .replace(urlSplit.get(0) + "/", "")
                .replace(urlSplit.get(1) + "/", "")
                .concat(pathToAdd).concat("/");
    }

    private void copyFileToTempFolder(ReprocessDiskShareConfig diskShareConfig, String srcLocation, String destLocation, String dbPathFile) throws IOException {
        if (!diskShareConfig.getDiskShare().folderExists(destLocation)) {
            createSmbFolder(destLocation, diskShareConfig.getDiskShare());
        }

        if (!diskShareConfig.getDiskShare().fileExists(destLocation + dbPathFile + ".fasta")) {
            try (File srcFile = diskShareConfig.getDiskShare().openFile(srcLocation + dbPathFile + ".fasta",
                    EnumSet.of(GENERIC_READ), null, ALL, FILE_OPEN, null);
                 InputStream inputStream = new BufferedInputStream(srcFile.getInputStream());
                 File destFile = diskShareConfig.getDiskShare().openFile(destLocation + dbPathFile + ".fasta",
                         EnumSet.of(GENERIC_READ), null, ALL, FILE_CREATE, null);
                 OutputStream outputStream = new BufferedOutputStream(destFile.getOutputStream())) {

                byte[] buffer = new byte[32768];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                }
            }
        }
    }

    private Map<String, String> readAlleleSetsFromFile(ReprocessDiskShareConfig diskShareConfig, String filePath) {
        Map<String, String> alleleSetFromFile = new LinkedHashMap<>();
        try (File tempFile = diskShareConfig.getDiskShare().openFile(filePath, EnumSet.of(GENERIC_READ),
                null, ALL, FILE_OPEN, null);
             Scanner reader = new Scanner(new InputStreamReader(tempFile.getInputStream()))) {

            while (reader.hasNextLine()) {
                String key = reader.nextLine();
                if (reader.hasNextLine()) {
                    String value = reader.nextLine();
                    alleleSetFromFile.put(key, value);
                }
            }
        }
        return alleleSetFromFile;
    }

    private Map<String, String> findMatchingAlleles(ReprocessDiskShareConfig diskShareConfig, String alleleSetId,
                                                    String protocolName, String missedAlleleSet, List<String> protocolUrlSplit) {

        List<String> multipleAlleleSets = new ArrayList<>(Arrays.asList(missedAlleleSet.replaceAll("[*:]", "_").split(",")));
        Map<String, String> matchedAlleleSetFromMasterFile = new LinkedHashMap<>();
        String alleleSetProtocolName = alleleSetId.concat("/").concat(protocolName).concat(".fasta");
        String saReferenceProtocolLocation = buildPath(propertyConfig.getReprocessReferenceUrl(), protocolUrlSplit, alleleSetProtocolName);

        if (saReferenceProtocolLocation.contains(".fasta") && saReferenceProtocolLocation.endsWith("/")) {
            saReferenceProtocolLocation = StringUtils.removeEnd(saReferenceProtocolLocation, "/");
        }

        try (File masterRefFastaFile = diskShareConfig.getDiskShare().openFile(saReferenceProtocolLocation,
                EnumSet.of(GENERIC_READ), null, ALL, FILE_OPEN, null);
             Scanner reader = new Scanner(new InputStreamReader(masterRefFastaFile.getInputStream()))) {

            while (reader.hasNextLine() && !multipleAlleleSets.isEmpty()) {
                String line = reader.nextLine();
                if (!line.isEmpty() && findAlleleSetPresentOrNot(line, multipleAlleleSets)) {
                    matchedAlleleSetFromMasterFile.put(line, reader.nextLine());
                } else {
                    reader.nextLine(); // Skip sequence line
                }
            }
        }
        return matchedAlleleSetFromMasterFile;
    }

    private void writeAlleleSetsToFile(ReprocessDiskShareConfig diskShareConfig, String folderPath, String dbPathFile, Map<String, String> alleleSetFromTempFile) throws IOException {
        for (Map.Entry<String, String> entry : alleleSetFromTempFile.entrySet()) {
            RefSeqValidation refSeqValidation = isSequenceExistInRefFile(diskShareConfig, folderPath + dbPathFile + ".fasta", entry.getValue(), entry.getKey());
            String sequenceId = entry.getKey();
            if (refSeqValidation.isSequenceIdExist() && !refSeqValidation.isSequenceExist()) {
                sequenceId = sequenceId + "_" + DateTimeFormatter.ofPattern("yyyyMMddHHmmss")
                        .withZone(ZoneOffset.UTC)
                        .format(Instant.now());
            }
            if (!refSeqValidation.isSequenceExist()) {
                try (File tempFile = diskShareConfig.getDiskShare().openFile(
                        folderPath + dbPathFile + ".fasta",
                        EnumSet.of(GENERIC_WRITE, FILE_APPEND_DATA, GENERIC_READ),
                        EnumSet.of(FileAttributes.FILE_ATTRIBUTE_NORMAL), // fileAttributes,
                        EnumSet.of(SMB2ShareAccess.FILE_SHARE_WRITE, SMB2ShareAccess.FILE_SHARE_READ),
                        FILE_OPEN, // createDisposition
                        EnumSet.noneOf(SMB2CreateOptions.class)); // createOptions
                     OutputStream smbFos = new BufferedOutputStream(tempFile.getOutputStream(true))) { // true = append

                    long fileSize = tempFile.getFileInformation().getStandardInformation().getEndOfFile();

                    byte[] line1 = (sequenceId + "\n").getBytes(StandardCharsets.UTF_8);
                    tempFile.write(line1, fileSize, 0, line1.length);
                    fileSize += line1.length;

                    byte[] line2 = (entry.getValue() + "\n").getBytes(StandardCharsets.UTF_8);
                    tempFile.write(line2, fileSize, 0, line2.length);
                }
            }
        }
    }

    private RefSeqValidation isSequenceExistInRefFile(ReprocessDiskShareConfig diskShareConfig, String refFilePath,
                                             String sequence, String sequenceId) {
        RefSeqValidation refSeqValidation = new RefSeqValidation();
        try (File masterRefFastaFile = diskShareConfig.getDiskShare().openFile(refFilePath,
                EnumSet.of(GENERIC_READ), null, ALL, FILE_OPEN, null);
             Scanner reader = new Scanner(new InputStreamReader(masterRefFastaFile.getInputStream()))) {

            while (reader.hasNextLine() && StringUtils.isNotBlank(sequence)) {
                String refSeqId = "";
                String refSeq = "";
                if (reader.hasNextLine()) {
                    refSeqId = reader.nextLine(); // get seq id
                }
                if (reader.hasNextLine()) {
                    refSeq = reader.nextLine(); // get seq
                }
                if (StringUtils.isNotBlank(refSeq) && refSeq.equals(sequence)) {
                    refSeqValidation.setSequenceExist(true);
                    return refSeqValidation;
                } else if (StringUtils.isNotBlank(refSeq) && StringUtils.isNotBlank(refSeqId)
                        && refSeqId.equals(sequenceId) && !refSeq.equals(sequence)) {
                        refSeqValidation.setSequenceExist(false);
                        refSeqValidation.setSequenceIdExist(true);
                        return refSeqValidation;
                }
            }
        }
        return refSeqValidation;
    }

    private void deleteFastaFaiFileIfExist(ReprocessDiskShareConfig diskShareConfig, String filePath) throws IOException {
        String faiFilePath = filePath + ".fai";

        if (diskShareConfig.getDiskShare().fileExists(faiFilePath)) {
            try {
                diskShareConfig.getDiskShare().rm(faiFilePath);
                // deleteSmbFile(propertyConfig, faiFilePath, splitAndFilterPath(filePath).get(0), splitAndFilterPath(filePath).get(1));
                LOGGER.info("Successfully deleted the .fai file: " + faiFilePath);
            } catch (Exception e) {
                LOGGER.error("Failed to delete the .fai file: " + faiFilePath, e);
                throw e;  // rethrow the exception if you need to handle it further up the call stack
            }
        }
    }


    private boolean isFileExist(ReprocessDiskShareConfig diskShareConfig, String filePath) {
        return diskShareConfig.getDiskShare().fileExists(filePath);
    }

    private String logAndReturnError(String missedAlleleSet, String errorMessage) {
        LOGGER.error(missedAlleleSet + " " + errorMessage);
        return errorMessage;
    }


    private void deleteSmbFile(PropertyConfig propertyConfig, String deleteFilePath, String server, String share) throws IOException {
        DiskShare diskShare;
        SMBClient clientSource = new SMBClient();
        Connection connectionSource = clientSource.connect(server);
        AuthenticationContext authContextSource = new AuthenticationContext(propertyConfig.getReprocessServerUsername()
                , propertyConfig.getReprocessServerPassword().toCharArray()
                , propertyConfig.getReprocessServerDomain());
        Session sessionSource = connectionSource.authenticate(authContextSource);
        diskShare = (DiskShare) sessionSource.connectShare(share);

        diskShare.rm(deleteFilePath);

        sessionSource.close();
        diskShare.close();
        clientSource.close();
        connectionSource.close(true);
    }

    private void createSmbFolder(String folderPath, DiskShare diskShare) {
        List<String> folderSplit = Arrays.stream(folderPath.replace("\\", "/").split("/"))
                .filter(path -> !path.equalsIgnoreCase("")).toList();
        String sharePath = "";
        for (String path : folderSplit) {
            sharePath = sharePath.concat(path).concat("/");
            boolean isDestPathExist = diskShare.folderExists(sharePath);
            if (!isDestPathExist) {
                diskShare.mkdir(sharePath);
            }
        }
    }

    private boolean findAlleleSetPresentOrNot(String line, List<String> sets) {
        Iterator<String> iterator = sets.iterator();
        while (iterator.hasNext()) {
            String set = iterator.next();
            if (line.contains(set)) {
                iterator.remove();
                return true;
            }
        }
        return false;
    }

}
