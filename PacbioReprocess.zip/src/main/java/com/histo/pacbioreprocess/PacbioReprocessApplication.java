package com.histo.pacbioreprocess;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
@OpenAPIDefinition(
		servers = {
				@Server(url = "https://webapiuat.histogenetics.com:8765/Reprocess", description = "UAT Server API Gateway"),
				@Server(url = "https://webapiuat:8700/Reprocess", description = "UAT Server native"),
				@Server(url = "http://localhost:8765/Reprocess", description = "local Server"),
				@Server(url = "http://localhost:8700/Reprocess", description = "local Native Server"),
				@Server(url = "https://javawebag01.histogenetics.com:8765/Reprocess", description = "PROD Server API Gateway"),
				@Server(url = "https://javawebag01:8700/Reprocess", description = "PROD Server Native")
		}
)
public class PacbioReprocessApplication {

	public static void main(String[] args) {
		SpringApplication.run(PacbioReprocessApplication.class, args);
	}

}
