package com.histo.pacbioreprocess.controller;

import com.histo.pacbioreprocess.model.*;
import com.histo.pacbioreprocess.service.PacBioReProcessService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@RestController
@RequestMapping("/pacReprocess/")
public class PacReProcessController {
    private static final Logger logger = LogManager.getLogger(PacReProcessController.class);
    private final PacBioReProcessService pacBioReProcessService;

    public PacReProcessController(PacBioReProcessService pacBioReProcessService) {
        this.pacBioReProcessService = pacBioReProcessService;
    }

    @PostMapping("/addReprocess")
    public ResponseEntity<List<ReProcessOutput>> addReprocess(@RequestBody List<PacReProcessInput> pacReProcessInputs) {
        logger.info("called API /addReprocess ");
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.submit(() -> {
            try {
                logger.info("Background processing started for /addReprocess");
                ResponseEntity<List<ReProcessOutput>> reprocessResponse = pacBioReProcessService.addReprocess(pacReProcessInputs);

                // Optionally log or notify success
                logger.info("Background processing completed for /addReprocess. Status code: {}", reprocessResponse.getStatusCode());
            } catch (Exception e) {
                logger.error("Error during background processing", e);
            }
        });

        return createReProcessOutput(pacReProcessInputs);
    }


    private ResponseEntity<List<ReProcessOutput>> createReProcessOutput(List<PacReProcessInput> pacReProcessInputs) {
        List<ReProcessOutput> reProcessOutputs = new ArrayList<>();
        for (PacReProcessInput pacReProcessInput : pacReProcessInputs) {
            String program = "";
            switch (pacReProcessInput.getReProcessType()) {
                case AlleleConfirmation -> program = ProgramList.IGV.getValue();
                case TypingDiscrepancy -> program = ProgramList.SECONDARY.getValue();
                case GO -> program = ProgramList.GAP_GO_ISSUE.getValue();
                case NEW_ALLELE_DROPOUT_IN_PACBIO -> program = ProgramList.NEW_ALLELE_DROPOUT_IN_PACBIO.getValue();
                case NEW_ALLELE_CONFIRMATION_IN_PACBIO -> program = ProgramList.NEW_ALLELE_CONFIRMATION_IN_PACBIO.getValue();
                case REPROCESS_WITH_SPECIFIC_ALLELE_SET -> program = ProgramList.REPROCESS_WITH_SPECIFIC_ALLELE_SET.getValue();
                default -> logger.warn("Unknown ReProcessType: {}", pacReProcessInput.getReProcessType());
            }

            ReProcessOutput reProcessOutput = new ReProcessOutput();
            reProcessOutput.setResponse("Requested");
            reProcessOutput.setJobName(pacReProcessInput.getNewJobName());
            reProcessOutput.setProgram(program);
            reProcessOutput.setJobId(pacReProcessInput.getJobId());
            reProcessOutput.setClientSampleId(pacReProcessInput.getClientSampleId());
            reProcessOutput.setGeneName(pacReProcessInput.getGenName());
            reProcessOutput.setAllelesAlreadyInProgress(pacReProcessInput.getAlleles());

            reProcessOutputs.add(reProcessOutput);
        }

        return ResponseEntity.status(HttpStatus.OK).body(reProcessOutputs);
    }

    @PutMapping("/reprocessStatus")
    public ResponseEntity<String> updateReprocessStatus(@RequestBody ShellScriptStatusInput input) {
        logger.info("called API /updateReprocessStatus ");
        ResponseEntity<String> response = pacBioReProcessService.updateStatus(input);
        logger.info("called API /updateReprocessStatus completed");
        return response;
    }


    @PostMapping("/alleleValidation")
    public ResponseEntity<List<ReProcessOutput>> alleleValidation(@RequestBody List<PacReProcessInput> input) {
        logger.info("called API /alleleValidation ");
        ResponseEntity<List<ReProcessOutput>> response = pacBioReProcessService.alleleValidation(input);
        logger.info("called API /alleleValidation Completed ");
        return response;
    }

    @GetMapping(path = {"/get/requestedJobs"}, produces = "application/json")
    public ResponseEntity<List<RequestedJobs>> getRequestedJobList() {
        logger.info("called API /get/requestedJobs ");
        ResponseEntity<List<RequestedJobs>> response = pacBioReProcessService.getRequestedJobs();
        logger.info("called API /get/requestedJobs Completed");
        return response;
    }

    @GetMapping(path = {"/getReprocessNAJobs"}, produces = "application/json")
    public ResponseEntity<ReprocessNAJob> getReprocessNAJobs() {
        logger.info("called API /getReprocessNAJobs");
        ResponseEntity<ReprocessNAJob> response = pacBioReProcessService.getReprocessNAJobs();
        logger.info("called API /getReprocessNAJobs Completed");
        return response;
    }

    @PutMapping("reprocessNAStatus")
    public ResponseEntity<Object> updateReprocessNAStatus(@RequestBody ReprocessNAUpdateJob reprocessNAUpdateJob) {
        logger.info("called API /reprocessNAStatus");
        return pacBioReProcessService.updateReprocessStatus(reprocessNAUpdateJob);
    }

}
