package com.histo.pacbioreprocess.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Entity
@Table(name = "PacbioReferenceSequences")
@NoArgsConstructor
@Getter
@Setter
@ToString
public class PacbioReferenceSequence {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ReferenceSequenceID")
    private Integer referenceSequenceId;

    @Column(name = "Hash", length = 200)
    private String hash;

    @Column(name = "SequenceName", length = 250)
    private String sequenceName;

    @Column(name = "Sequence", columnDefinition = "varchar(max)")
    private String sequence;

    @Column(name = "AllelesetVersion", length = 50)
    private String alleleSetVersion;

    @Column(name = "AddedOn", columnDefinition = "datetime")
    @Temporal(TemporalType.TIMESTAMP)
    private Date addedOn;

    @Column(name = "SecondaryAnalysisTempProtocolId")
    private Integer secondaryAnalysisTempProtocolId;
}
