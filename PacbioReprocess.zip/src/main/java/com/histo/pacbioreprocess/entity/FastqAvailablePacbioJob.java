package com.histo.pacbioreprocess.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;

@Entity
@Table(name = "T_FastqAvailablePacbioJobs")
@Getter
@Setter
@ToString
public class FastqAvailablePacbioJob {

    @Id
    @Column(name = "AutoID", nullable = false)
    private Long autoId;

    @Column(name = "JobID", length = 10)
    private String jobId;

    @Column(name = "FileServerID")
    private Integer fileServerId;

    @Column(name = "FileShareID")
    private Integer fileShareId;

    @Column(name = "Location", length = 100)
    private String location;

    @Column(name = "Year")
    private Integer year;

    @Column(name = "Month")
    private Integer month;

    @Column(name = "FileSize")
    private Double fileSize;

    @Column(name = "FileMissing?")
    private String fileMissing;

    @Column(name = "Timestamp", nullable = false)
    private LocalDateTime timestamp;
}

