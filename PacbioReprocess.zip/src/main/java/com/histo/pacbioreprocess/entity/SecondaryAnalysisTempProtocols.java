package com.histo.pacbioreprocess.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Entity
@Table(name = "SecondaryAnalysisTempProtocols")
@Getter
@Setter
@ToString
public class SecondaryAnalysisTempProtocols implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SecondaryAnalysisTempProtocolId")
    private int secondaryAnalysisTempProtocolId;

    @Column(name = "TempProtocolName", length = 255)
    private String tempProtocolName;
}
