package com.histo.pacbioreprocess.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "SecondaryAnalysisProtocols")
@Getter
@Setter
@ToString
public class SecondaryAnalysisProtocol {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SecondaryAnalysisProtocolID")
    private int secondaryAnalysisProtocolId;

    @Column(name = "ProtocolName")
    private String protocolName;

    @Column(name = "SecondaryAnalysisTempProtocolId")
    private Integer secondaryAnalysisTempProtocolId;
}
