package com.histo.pacbioreprocess.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RequestedJobs {
	private int autoID;
	private String jobId;
	private String originalJobName;
	private String newJobName;
	private String barcodeId;
	private String protocolName;
	private int reProcessRequestType;
	private String alleleSetVersion;
	private String clientSampleID;
    private String currentAlleleSetVersion;
    private String jobType;
    private int sampleId;
	private String masterAlleleSetVersion;
	private String specificAlleleSet;
}
