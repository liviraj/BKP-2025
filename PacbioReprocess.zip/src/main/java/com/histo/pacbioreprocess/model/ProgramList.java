package com.histo.pacbioreprocess.model;

public enum ProgramList {
	IGV("IGV"),
	SECONDARY("SECONDARYANALYSIS"),
	GAP_GO_ISSUE("GAP/GO Issue"),
	NEW_ALLELE_DROPOUT_IN_PACBIO("New Allele Dropout In Pacbio"),
	NEW_ALLELE_CONFIRMATION_IN_PACBIO("New Allele Confirmation In Pacbio"),
	REPROCESS_WITH_SPECIFIC_ALLELE_SET("Reprocess with specific allele set");

	private String value;
	
	public String getValue() {
		return value;
	}
	ProgramList(String value) {
		this.value = value;
	}

}
