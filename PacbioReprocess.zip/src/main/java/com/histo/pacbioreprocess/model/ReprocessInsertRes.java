package com.histo.pacbioreprocess.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ReprocessInsertRes {
    private String result;
    private long reProcessRequestId;
}
