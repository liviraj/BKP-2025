package com.histo.pacbioreprocess.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class PacReProcessInput {
    private String jobId;
    private String barCodeId;
    private String protocolName;
    private String oldJobName;
    private String newJobName;
    private ReProcessType reProcessType;
    private int sampleId;
    private String genName;
    private Integer userId;
    private String remarks;
    private String clientSampleId;
    private Status status;
    private String alleleSetVersion;
    private String masterAlleleSetVersion;
    private String alleles;
    private String rawSequence;
    private String primerName;
    private List<GeneDetail> geneDetails;
    private String alleleSetTobeProcessed;
    private String blotName;
}