package com.histo.pacbioreprocess.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ReprocessNAJob {
    private long id;
    private String newJobName;
    private String actualJobName;
    private int alleleSetID;
    private int alleleSetVersion;
    private String jobID;
}
