package com.histo.pacbioreprocess.model;

public enum ReProcessType {
    AutoType,
    AlleleConfirmation, //IGV
    TypingDiscrepancy, //Secondary Analysis
    GO, //Gap/Overlap
    NEW_ALLELE_DROPOUT_IN_PACBIO,
    NEW_ALLELE_CONFIRMATION_IN_PACBIO,
    REPROCESS_WITH_SPECIFIC_ALLELE_SET
}
