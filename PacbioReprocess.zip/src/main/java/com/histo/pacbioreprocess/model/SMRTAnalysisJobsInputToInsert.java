package com.histo.pacbioreprocess.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SMRTAnalysisJobsInputToInsert {
	private String jobName;
	private String dateCreated;
	private String applicationState;
	private String analysisApplication;
	private String filePath;
}
