package com.histo.pacbioreprocess.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class ErrorResponse {
    private boolean status;
    private int statusCode;
    private String message;
    private long timestamp;
}
