package com.histo.pacbioreprocess.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PrimerSequenceFromSP {
	private String primerName;
	private String primerSequence;
	private String geneName;
	private String frdAdapterSequence;
	private String revAdapterSequence;
	private String fwdPrimerSequence;	
	private String revPrimerSequence;
}
