package com.histo.pacbioreprocess.model;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode
public class HLAGenomeRawData {
	private String geneName;
	private String genomeSegmentName;
	private String alleleName;
	private String alleleSequence;
}

