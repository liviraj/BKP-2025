package com.histo.pacbioreprocess.model;

import java.util.ArrayList;
import java.util.List;

public class PacBioReprocessMultipleInput {
	
	List<PacReProcessInput> reProcessInputs = new ArrayList<>();

	public List<PacReProcessInput> getReProcessInputs() {
		return reProcessInputs;
	}

	public void setReProcessInputs(List<PacReProcessInput> reProcessInputs) {
		this.reProcessInputs = reProcessInputs;
	}

}
