package com.histo.pacbioreprocess.model;

public enum Status {
    Requested,
    InProgress,
    Completed,
    Error,
    Initiated
}