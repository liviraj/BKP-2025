package com.histo.pacbioreprocess.model;

import lombok.*;

@Getter
@Setter
@ToString
@EqualsAndHashCode
public class AlleleSegSeq {
    private String geneName;
    private String genomeSegmentName;
    private String alleleName;
    private String segmentSequence;
}
