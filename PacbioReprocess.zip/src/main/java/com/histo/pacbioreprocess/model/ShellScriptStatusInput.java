package com.histo.pacbioreprocess.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ShellScriptStatusInput {
	private int autoID;
	private String newJobName;
	private int status;
	private String message;
}
