package com.histo.pacbioreprocess.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class ReProcessOutput {
	private String program;
	private String jobName;
	private String jobId;
	private String clientSampleId;
	private String geneName;
	private String response;
	private String alleleNotPresentInDB;
	private String allelePresentInDB;
	private String allelesAlreadyInProgress;
}
