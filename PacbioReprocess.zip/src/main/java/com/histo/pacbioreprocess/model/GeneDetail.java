package com.histo.pacbioreprocess.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class GeneDetail {
    private String segment;
    private String sequence;
    private String allele;
}