package com.histo.pacbioreprocess.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RefSeqValidation {
    private boolean sequenceExist;
    private boolean sequenceIdExist;
}
