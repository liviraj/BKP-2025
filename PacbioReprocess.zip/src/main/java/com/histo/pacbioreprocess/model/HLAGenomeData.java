package com.histo.pacbioreprocess.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class HLAGenomeData {
	private String geneName;
	private String alleleName;
	private String alleleSequence;
	private String UTR5;
	private String E1;
	private String I1;
	private String E2;
	private String I2;
	private String E3;
	private String I3;
	private String E4;
	private String I4;
	private String E5;
	private String I5;
	private String E6;
	private String I6;
	private String E7;
	private String I7;
	private String E8;
	private String I8;
	private String UTR3;
}
