package com.histo.pacbioreprocess.model;

import lombok.ToString;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@ToString
public class GeneNameWithAllRegion {
	private String geneName;
	private String region;
	private List<String> regionList = new ArrayList<>();
	
	public String getGeneName() {
		return geneName;
	}
	public void setGeneName(String geneName) {
		this.geneName = geneName;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public List<String> getRegionList() {
		String replace5and3UTRFormat = this.region.replace("5UTR", "UTR5").replace("3UTR", "UTR3");
		 List<String> list =Arrays.asList(replace5and3UTRFormat.split(","));
		this.regionList = list;
		return regionList;
	}
	
}
