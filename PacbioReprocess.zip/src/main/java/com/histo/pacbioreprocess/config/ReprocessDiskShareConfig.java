package com.histo.pacbioreprocess.config;

import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;

public class ReprocessDiskShareConfig {
    private static final Logger LOGGER = LogManager.getLogger(ReprocessDiskShareConfig.class.getName());

    private DiskShare diskShare;
    private SMBClient client;
    private Connection connection;
    private Session session;

    public ReprocessDiskShareConfig(String username, String password, String domain,  String sourceServer, String sourceShare
    ) {
        try {

            client = new SMBClient();
            connection = client.connect(sourceServer);
            AuthenticationContext authContextSource = new AuthenticationContext(username
                    , password.toCharArray()
                    , domain);
            session = connection.authenticate(authContextSource);
            this.diskShare = (DiskShare) session.connectShare(sourceShare);

        } catch (IOException e) {
            LOGGER.error(e);
        }
    }

    public DiskShare getDiskShare() {
        return diskShare;
    }

    public void setDiskShare(DiskShare diskShare) {
        this.diskShare = diskShare;
    }

    @Override
    public String toString() {
        return "DiskShareConfig{" +
                "sourceDiskShare=" + diskShare +
                '}';
    }

    public void close() throws IOException {
        if (diskShare != null) {
            diskShare.close();
        }
        if (session != null) {
            session.close();
        }
        if (connection != null) {
            connection.close();
        }
        if (client != null) {
            client.close();
        }
    }
}
