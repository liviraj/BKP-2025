package com.histo.pacbioreprocess.config;

import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.smbj.share.DiskShare;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Service
public class ReprocessTempJobDelScheduler {
    private static final Logger LOGGER = LoggerFactory.getLogger(ReprocessTempJobDelScheduler.class);
    private final PropertyConfig propertyConfig;

    public ReprocessTempJobDelScheduler(PropertyConfig propertyConfig) {
        this.propertyConfig = propertyConfig;
    }

    @Scheduled(cron = "0 0 0 * * ?") // Runs at 00:00 every day
   //@Scheduled(cron = "*/1 * * * * ?") // run at every second
    public void cleanupOldTempJobFolders() {
        String tempJobPath = propertyConfig.getReprocessTempFolderCopyPath().replace("\\", "/");
        if (!tempJobPath.endsWith("/")) {
            tempJobPath += "/";
        }

        List<String> tempPathSplit = splitAndFilterPath(tempJobPath);

        ReprocessDiskShareConfig tempDiskShareConfig = new ReprocessDiskShareConfig(
                propertyConfig.getReprocessServerUsername(),
                propertyConfig.getReprocessServerPassword(),
                propertyConfig.getReprocessServerDomain(),
                tempPathSplit.get(0), tempPathSplit.get(1)
        );

        String tempSMBPath = tempJobPath.replace("//", "")
                .replace(tempPathSplit.get(0) + "/", "")
                .replace(tempPathSplit.get(1) + "/", "");

        boolean isTempFolderPathExist = tempDiskShareConfig.getDiskShare().folderExists(tempSMBPath);
        if (!isTempFolderPathExist) {
            LOGGER.debug("The temp reprocess path not exist. Temp path: {}" + tempJobPath.replace("/", "\\"));
        }

        List<FileIdBothDirectoryInformation> tempJobsFolderList = tempDiskShareConfig.getDiskShare().list(tempSMBPath);
        for (FileIdBothDirectoryInformation jobFolderInfo : tempJobsFolderList) {
            if (jobFolderInfo.getFileName().equals(".") || jobFolderInfo.getFileName().equals("..")) {
                continue;
            }
            String actualJobPath = tempSMBPath + jobFolderInfo.getFileName() + "/";

            Date jobCreationTime = tempDiskShareConfig.getDiskShare().getFileInformation(actualJobPath)
                    .getBasicInformation().getCreationTime().toDate();
            boolean isFolderOlderForDelete = isFolderOlderForDelete(jobCreationTime);

            if (!isFolderOlderForDelete) {
                continue;
            }

            // Delete the job
            deleteSmbFolder(tempDiskShareConfig.getDiskShare(), actualJobPath);

            String jobSharePath = propertyConfig.getReprocessTempFolderCopyPath().concat(jobFolderInfo.getFileName()).replace("/", "\\");
            LOGGER.info("Job delete at : {}. Job Location: {}", LocalDateTime.now(), jobSharePath);
        }
    }

    public void deleteSmbFolder(DiskShare diskShare, String deletePath) {
        diskShare.rmdir(deletePath, true);
    }

    private boolean isFolderOlderForDelete(Date creationDate) {
        Instant created = creationDate.toInstant();
        Instant now = Instant.now();

        long diffDays = Duration.between(created, now).toDays();
        return diffDays >= propertyConfig.getTempJobDeleteDays();
    }

    private List<String> splitAndFilterPath(String path) {
        return Arrays.stream(path.replace("\\", "/").split("/"))
                .filter(p -> !p.isEmpty()).toList();
    }
}
