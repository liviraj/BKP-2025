package com.histo.pacbioreprocess.config;

import com.microsoft.sqlserver.jdbc.SQLServerDriver;
import jakarta.annotation.PostConstruct;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

@Configuration
@PropertySource("classpath:application.properties")
public class SqlConnectionSetup {
	private static final Logger LOGGER = LogManager.getLogger(SqlConnectionSetup.class.getName());

	@Value("${app.datasource.histos.url}")
	public String histoServerURL;
	@Value("${app.datasource.histos.username}")
	public String histoServerUsername;
	@Value("${app.datasource.histos.password}")
	public String histoServerPassword;
	
	public static String url;
	public static String Uname;
	public static String Pswd;
	
	
	@Value("${app.datasource.histos.url}")
	public void setHistoServerURL(String histoServerURL) {
		SqlConnectionSetup.url = histoServerURL;
	}
	@Value("${app.datasource.histos.username}")
	public void setHistoServerUsername(String histoServerUsername) {
		SqlConnectionSetup.Uname = histoServerUsername;
	}
	@Value("${app.datasource.histos.password}")
	public void setHistoServerPassword(String histoServerPassword) {
		SqlConnectionSetup.Pswd = histoServerPassword;
	}

	private static Connection sqlcon = null;
	
	@PostConstruct
	private static Connection getSqlConnection() {
		try {
			DriverManager.registerDriver(new SQLServerDriver());
			sqlcon = DriverManager.getConnection(url, Uname, Pswd);
		} catch (SQLException e) {
			LOGGER.error(e);
		}
		return sqlcon;
	}
	
	public static synchronized Connection getConnection() {
		try {
			if(sqlcon == null || sqlcon.isClosed()) 
				getSqlConnection();
			}
			catch (Exception e) {
				LOGGER.error(e);
			}
		return sqlcon;
		
	}
	
	@Bean
    public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
        return new PropertySourcesPlaceholderConfigurer();
    }
}
