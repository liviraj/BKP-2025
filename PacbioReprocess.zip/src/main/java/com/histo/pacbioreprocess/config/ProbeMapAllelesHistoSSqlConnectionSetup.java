package com.histo.pacbioreprocess.config;

import com.microsoft.sqlserver.jdbc.SQLServerDriver;
import jakarta.annotation.PostConstruct;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

@Configuration
@PropertySource("classpath:application.properties")
public class ProbeMapAllelesHistoSSqlConnectionSetup {
	private static final Logger LOGGER = LogManager.getLogger(ProbeMapAllelesHistoSSqlConnectionSetup.class.getName());

	@Value("${app.datasource.probeMapAllelesHistoS.url}") 
	public String reProcessServerURL;
	@Value("${app.datasource.probeMapAllelesHistoS.username}")
	public String reProcessServerUsername;
	@Value("${app.datasource.probeMapAllelesHistoS.password}")
	public String reProcessServerPassword;
	
	public static String url = null;
	public static String Uname = null;
	public static String Pswd = null;

	
	@Value("${app.datasource.probeMapAllelesHistoS.url}")
	public void setReProcessServerURL(String reProcessServerURL) {
		ProbeMapAllelesHistoSSqlConnectionSetup.url = reProcessServerURL;
	}
	@Value("${app.datasource.probeMapAllelesHistoS.username}")
	public void setReProcessServerUsername(String reProcessServerUsername) {
		ProbeMapAllelesHistoSSqlConnectionSetup.Uname = reProcessServerUsername;
	}
	@Value("${app.datasource.probeMapAllelesHistoS.password}")
	public void setReProcessServerPassword(String reProcessServerPassword) {
		ProbeMapAllelesHistoSSqlConnectionSetup.Pswd = reProcessServerPassword;
	}

	private static Connection sqlcon = null;
	
	@PostConstruct
	private static Connection getSqlConnection() {
		try {
			DriverManager.registerDriver(new SQLServerDriver());
			sqlcon = DriverManager.getConnection(url, Uname, Pswd);
		} catch (SQLException e) {
			LOGGER.error(e);
		}
		return sqlcon;
	}
	
	public static synchronized Connection getConnection() {
		try {
			if(sqlcon == null || sqlcon.isClosed()) 
				getSqlConnection();
			}
			catch (Exception e) {
				LOGGER.error(e);
			}
		return sqlcon;
	}
	
}
