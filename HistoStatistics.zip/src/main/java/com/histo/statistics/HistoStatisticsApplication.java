package com.histo.statistics;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@OpenAPIDefinition(
		servers = {
				@Server(url = "https://webapiuat.histogenetics.com:8765/Statistics", description = "UAT Server API Gateway"),
				@Server(url = "https://webapiuat:8220/Statistics", description = "UAT Server native"),
				@Server(url = "http://localhost:8765/Statistics", description = "local Server"),
				@Server(url = "http://localhost:8220/Statistics", description = "local Native Server"),
				@Server(url = "https://javawebag01.histogenetics.com:8765/Statistics", description = "PROD Server API Gateway"),
				@Server(url = "https://javawebag01:8220/Statistics", description = "PROD Server Native"),
				@Server(url = "http://10.201.100.32:8765/Statistics", description = "Local IP API Gateway Server Native"),
				@Server(url = "http://10.201.100.32:8220/Statistics", description = "Local IP Server Native")
		}
)
public class HistoStatisticsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HistoStatisticsApplication.class, args);
	}

}
