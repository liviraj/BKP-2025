package com.histo.statistics.controller;

import com.histo.statistics.model.HLASampleInput;
import com.histo.statistics.model.SalesInput;
import com.histo.statistics.security.AuthorizationValidation;
import com.histo.statistics.service.StatisticsService;
import jakarta.ws.rs.QueryParam;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StatisticsController {

    private final StatisticsService statisticsService;
    private final AuthorizationValidation auth;


    public StatisticsController(StatisticsService statisticsService, AuthorizationValidation auth) {
        super();
        this.statisticsService = statisticsService;
        this.auth = auth;
    }

    @GetMapping("/clientInformation")
    public ResponseEntity<Object> getAllClients(@RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = auth.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return statisticsService.findAllClients();
        }
        return responseEntity;
    }

    @GetMapping("/clientProjectInfo")
    public ResponseEntity<Object> getAllClientsProject(@RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = auth.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return statisticsService.findAllClientsProject();
        }
        return responseEntity;
    }

    @GetMapping("/geneInformation")
    public ResponseEntity<Object> getNonHLAGeneInfo(@RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = auth.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return statisticsService.findGeneDetails();
        }
        return responseEntity;
    }

    @GetMapping("/salesSummary")
    public ResponseEntity<Object> getSalesSummary(@RequestHeader("Authorization") String token, @QueryParam(value = "input") SalesInput input) {
        ResponseEntity<Object> responseEntity = auth.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return statisticsService.findSalesSummary(input);
        }
        return responseEntity;
    }

    @GetMapping("/hLASample")
    public ResponseEntity<Object> getHLASampleCount(@RequestHeader("Authorization") String token, @QueryParam(value = "input") HLASampleInput input) {
        ResponseEntity<Object> responseEntity = auth.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return statisticsService.findHLASampleCount(input);
        }
        return responseEntity;
    }

}
