package com.histo.statistics.security;

import com.histo.statistics.exception.ExceptionBean;
import com.histo.statistics.model.*;

import com.microsoft.graph.authentication.IAuthenticationProvider;
import com.microsoft.graph.requests.GraphServiceClient;
import okhttp3.Request;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.concurrent.CompletableFuture;

@Component
public class AuthorizationValidation {

    private static final Logger logger = LogManager.getLogger(AuthorizationValidation.class.getName());
    private static final String STATUS = "status";

    private final JdbcTemplate jdbcTemplate;
    StatisticsResponseModel response;

    MappingJacksonValue mappingJacksonValue;

    public AuthorizationValidation(JdbcTemplate jdbcTemplate) {
        super();
        this.jdbcTemplate = jdbcTemplate;
        response = new StatisticsResponseModel();
    }

    public ResponseEntity<Object> isAuthorize(String token) {

        try {
            if (StringUtils.isNotBlank(token)) {
                String emailId = "";
                IAuthenticationProvider authProvider = requestUrl -> {
                    CompletableFuture<String> future = new CompletableFuture<>();
                    future.complete(token);
                    return future;
                };

                GraphServiceClient<Request> graphClient = GraphServiceClient.builder()
                        .authenticationProvider(authProvider).buildClient();

                emailId = graphClient.me().buildRequest().get().userPrincipalName;

                if (emailId != null) {

                    UserInfo userInformation = jdbcTemplate.queryForObject ("exec GetStatisticsUserInfo ?", BeanPropertyRowMapper.newInstance (UserInfo.class), emailId);

                    if (userInformation != null) {
                        response.setStatus(true);
                        response.setInformation(new ExceptionBean (new Date(), "Valid", "Token valid"));
                        mappingJacksonValue = FilterUtil.statisticsResponseFilter(response,
                                new String[]{"information", STATUS});
                        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
                    } else {
                        response.setStatus(false);
                        response.setInformation(new ExceptionBean(new Date(), "UNAUTHORIZED", "User not found"));
                        mappingJacksonValue = FilterUtil.statisticsResponseFilter(response, new String[]{"information", STATUS});
                        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.UNAUTHORIZED);
                    }
                } else {
                    response.setStatus(false);
                    response.setInformation(new ExceptionBean(new Date(), "UNAUTHORIZED", "User not found"));
                    mappingJacksonValue = FilterUtil.statisticsResponseFilter(response, new String[]{"information", STATUS});
                    return new ResponseEntity<>(mappingJacksonValue, HttpStatus.UNAUTHORIZED);
                }
            } else {
                response.setStatus(false);
                response.setInformation(
                        new ExceptionBean(new Date(), "Token not valid", "Token is empty or not provided"));
                mappingJacksonValue = FilterUtil.statisticsResponseFilter (response, new String[]{"information", STATUS});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.UNAUTHORIZED);
            }

        } catch (Exception e) {
            logger.error("Exception message: {}",e);
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "Token not valid", "Token is expired or Invalid"));
            mappingJacksonValue = FilterUtil.statisticsResponseFilter(response, new String[]{"information", STATUS, "exception"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.UNAUTHORIZED);
        }
    }
}
