package com.histo.statistics.service.impl;

import com.histo.statistics.exception.ExceptionBean;
import com.histo.statistics.model.*;
import com.histo.statistics.service.StatisticsService;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Service
public class StatisticsServiceImpl implements StatisticsService {
    private static final Logger LOGGER = LogManager.getLogger(StatisticsServiceImpl.class);
    private final JdbcTemplate jdbcTemplate;
    private static final String STATUS = "status";
    MappingJacksonValue mappingJacksonValue;

    StatisticsResponseModel response;

    public StatisticsServiceImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
        this.response = new StatisticsResponseModel ();
    }


    @Override
    public ResponseEntity<Object> findAllClients() {
        try {
            List<ClientInfo> clientList = jdbcTemplate.query("exec GetAllClients;", BeanPropertyRowMapper.newInstance(ClientInfo.class));
            clientList.add (0,new ClientInfo (0,"All"));
            response.setStatus(true);
            response.setClientInfo(clientList);
            mappingJacksonValue = FilterUtil.statisticsResponseFilter(response, new String[] { STATUS, "clientInfo" });
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch(Exception e) {
            return catchException(e,"Error","Failed to fetch clients details",HttpStatus.CONFLICT);
        }
    }

    @Override
    public ResponseEntity<Object> findAllClientsProject() {
        try {
            List<ClientProjectInfo> clientList = jdbcTemplate.query("exec GetAllClientProjects;", BeanPropertyRowMapper.newInstance(ClientProjectInfo.class));
            response.setStatus(true);
            response.setClientProjectInfo(clientList);
            mappingJacksonValue = FilterUtil.statisticsResponseFilter(response, new String[] { STATUS, "clientProjectInfo" });
            return new ResponseEntity<>(mappingJacksonValue,HttpStatus.OK);
        } catch(Exception e) {
            return catchException(e,"Error","Failed to fetch client Projects",HttpStatus.CONFLICT);
        }
    }

    @Override
    public ResponseEntity<Object> findGeneDetails() {
        try {
            List<NonHLAGeneInfo> clientList = jdbcTemplate.query("exec getAllGeneGroups;", BeanPropertyRowMapper.newInstance(NonHLAGeneInfo.class));
            response.setStatus(true);
            response.setNonHLAGeneInfo(clientList);
            mappingJacksonValue = FilterUtil.statisticsResponseFilter(response, new String[] { STATUS, "nonHLAGeneInfo" });
            return new ResponseEntity<>(mappingJacksonValue,HttpStatus.OK);
        } catch(Exception e) {
            return catchException(e,"Error","Failed to fetch GeneDetails",HttpStatus.CONFLICT);
        }
    }

    @Override
    public ResponseEntity<Object> findSalesSummary(SalesInput input) {
        try {
            if(input.getClients()==null) {
                input.setClients("");
            }
            if(input.getMonths()==null) {
                input.setMonths("");
            }
            if(input.getYears()==null) {
                input.setYears("");
            }
            if((TypeEnum.SALES_COMPARE.getValue()).equals(input.getType())) {
                List<SalesComparison> comparisonList = jdbcTemplate.query("exec GetSalesSummary ?,?,?,?,?,?,?,?;",
                        BeanPropertyRowMapper.newInstance(SalesComparison.class),
                        input.getClients(),
                        input.getYears(),
                        input.getMonths(),
                        input.getFromDate(),
                        input.getToDate(),
                        input.getType(),
                        input.getSummaryColumn(),
                        "A"
                );

                response.setStatus(true);
                response.setComparison(comparisonList);
                mappingJacksonValue = FilterUtil.statisticsResponseFilter(response, new String[] { STATUS, "comparison" });
                return new ResponseEntity<>(mappingJacksonValue,HttpStatus.OK);
            } else if((TypeEnum.INVOICE_SUMMARY.getValue()).equals(input.getType())) {
                List<InvoiceSummary> summary = jdbcTemplate.query("exec GetSalesSummary ?,?,?,?,?,?,?,?;",
                        BeanPropertyRowMapper.newInstance(InvoiceSummary.class),

                        input.getClients(),
                        input.getYears(),
                        input.getMonths(),
                        input.getFromDate(),
                        input.getToDate(),
                        input.getType(),
                        input.getSummaryColumn(),
                        input.getPaymentStatus()
                );

                response.setStatus(true);
                response.setInvoiceSummary(summary);
                mappingJacksonValue = FilterUtil.statisticsResponseFilter(response,
                        new String[] { STATUS, "invoiceSummary" });
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            } else if( (TypeEnum.SALES_OVERVIEW.getValue()).equals(input.getType())) {
                List<SalesOverview> overviewList = jdbcTemplate.query("exec GetSalesSummary ?,?,?,?,?,?,?,?;",
                        BeanPropertyRowMapper.newInstance(SalesOverview.class),
                        input.getClients(),
                        input.getYears(),
                        input.getMonths(),
                        input.getFromDate(),
                        input.getToDate(),
                        input.getType(),
                        input.getSummaryColumn(),
                        "A"
                );

                if(ObjectUtils.isEmpty (overviewList) || overviewList.size () == 1){

                    response.setStatus(true);
                    response.setOverview(overviewList);
                    mappingJacksonValue = FilterUtil.statisticsResponseFilter(response, new String[] { STATUS, "overview" });
                    return new ResponseEntity<>(mappingJacksonValue,HttpStatus.OK);
                }

                SalesOverview salesAmount = overviewList.stream ().filter (data -> data.getClientId () == -1).findFirst ().get ();
                overviewList.stream ().forEachOrdered (data ->  {
                    BigDecimal salesAmountPercentage = data.calculatePercentage (data.getSalesAmount (), salesAmount.getSalesAmount ());
                    BigDecimal receivedAmountPercentage = data.calculatePercentage(data.getReceivedAmount (), salesAmount.getReceivedAmount ());
                    BigDecimal toBeReceivedAmountPercentage = data.calculatePercentage(data.getToBeReceivedAmount (), salesAmount.getToBeReceivedAmount ());
                    data.setSalesAmountPercentage (salesAmountPercentage);
                    data.setReceivedAmountPercentage (receivedAmountPercentage);
                    data.setToBeReceivedAmountPercentage (toBeReceivedAmountPercentage);

                });

                response.setStatus(true);
                response.setOverview(overviewList);
                mappingJacksonValue = FilterUtil.statisticsResponseFilter(response, new String[] { STATUS, "overview" });
                return new ResponseEntity<>(mappingJacksonValue,HttpStatus.OK);
            }
            else
            {
                return catchException(null,"Data not found", "Incorrect type or type may be empty",HttpStatus.CONFLICT);
            }
        } catch(Exception e) {
            return catchException(e,"Data not found","Incorrect value for SalesInput",HttpStatus.CONFLICT);
        }
    }

    @Override
    public ResponseEntity<Object> findHLASampleCount(HLASampleInput hlaSampleInput){
        try {
            if(hlaSampleInput.getClients()==null) {
                hlaSampleInput.setClients("");
            }
            if(hlaSampleInput.getMonths()==null) {
                hlaSampleInput.setMonths("");
            }
            if(hlaSampleInput.getYears()==null) {
                hlaSampleInput.setYears("");
            }
            List<HLASampleCount> sample= jdbcTemplate.query("exec GetHLASampleCount ?,?,?,?,?,?;",
                    BeanPropertyRowMapper.newInstance(HLASampleCount.class),
                    hlaSampleInput.getClients(),
                    hlaSampleInput.getYears(),
                    hlaSampleInput.getMonths(),
                    hlaSampleInput.getFromDate(),
                    hlaSampleInput.getToDate(),
                    hlaSampleInput.getGeneGroup()
            );

            response.setStatus(true);
            response.setHlaSampleCount(sample);
            mappingJacksonValue = FilterUtil.statisticsResponseFilter(response, new String[] { STATUS, "hlaSampleCount" });
            return new ResponseEntity<>(mappingJacksonValue,HttpStatus.OK);

        }catch(Exception e) {
            return catchException(e,"Data not found","Check the input values",HttpStatus.CONFLICT);
        }
    }

    private ResponseEntity<Object> catchException(Exception e,String message,String description,HttpStatus httpStatus) {
        LOGGER.error("Error :  {}", e);
        response.setStatus(false);
        response.setInformation(new ExceptionBean (new Date (), message, description));
        mappingJacksonValue = FilterUtil.statisticsResponseFilter(response, new String[] { "information", STATUS });
        return new ResponseEntity<>(mappingJacksonValue, httpStatus);
    }
}
