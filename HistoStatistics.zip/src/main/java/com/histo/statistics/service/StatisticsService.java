package com.histo.statistics.service;

import com.histo.statistics.model.HLASampleInput;
import com.histo.statistics.model.SalesInput;
import org.springframework.http.ResponseEntity;

public interface StatisticsService {
    public ResponseEntity<Object> findAllClients();
    public ResponseEntity<Object> findSalesSummary(SalesInput input);
    public ResponseEntity<Object> findAllClientsProject();
    public ResponseEntity<Object> findGeneDetails();
    public ResponseEntity<Object> findHLASampleCount(HLASampleInput hlaSampleInput);
}
