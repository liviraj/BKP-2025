package com.histo.statistics.model;

import java.util.Date;

public class HLASampleInput {
    private String clients;
    private String years;
    private String months;
    private Date fromDate;
    private Date toDate;
    private String geneGroups;

    public HLASampleInput(String clients, String years, String months, Date fromDate, Date toDate, String geneGroups) {
        this.clients = clients;
        this.years = years;
        this.months = months;
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.geneGroups = geneGroups;
    }
    public HLASampleInput() {
        super();
    }
    public String getClients() {
        return clients;
    }
    public void setClients(String clients) {
        this.clients = clients;
    }
    public String getYears() {
        return years;
    }
    public void setYears(String years) {
        this.years = years;
    }
    public String getMonths() {
        return months;
    }
    public void setMonths(String months) {
        this.months = months;
    }
    public Date getFromDate() {
        return fromDate;
    }
    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }
    public Date getToDate() {
        return toDate;
    }
    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }
    public String getGeneGroup() {
        return geneGroups;
    }
    public void setGeneGroup(String geneGroups) {
        this.geneGroups = geneGroups;
    }
}
