package com.histo.statistics.model;

public class NonHLAGeneInfo {

	private int geneGroupID;
	private String geneGroupName;
	public int getGeneGroupID() {
		return geneGroupID;
	}
	public void setGeneGroupID(int geneGroupID) {
		this.geneGroupID = geneGroupID;
	}
	public String getGeneGroupName() {
		return geneGroupName;
	}
	public void setGeneGroupName(String geneGroupName) {
		this.geneGroupName = geneGroupName;
	}
	@Override
	public String toString() {
		return "NonHLAGeneInfo [GeneGroupID=" + geneGroupID + ", GeneGroupName=" + geneGroupName + "]";
	}
}
