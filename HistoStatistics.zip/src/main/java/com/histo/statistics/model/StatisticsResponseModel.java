package com.histo.statistics.model;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.histo.statistics.exception.ExceptionBean;

import java.util.List;

@JsonFilter("StatisticsResponseModel")
public class StatisticsResponseModel {
    private boolean status;
    private List<ClientInfo> clientInfo;
    private List<ClientProjectInfo> clientProjectInfo;
    private List<NonHLAGeneInfo> nonHLAGeneInfo;
    private List<SalesComparison> comparison;
    private List<SalesOverview> overview;
    private List<HLASampleCount> hlaSampleCount;
    private List<InvoiceSummary> invoiceSummary;

	private UserInfo userInformation;
	private Object data;

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public List<InvoiceSummary> getInvoiceSummary() {
		return invoiceSummary;
	}

	public void setInvoiceSummary(List<InvoiceSummary> invoiceSummary) {
		this.invoiceSummary = invoiceSummary;
	}

	public List<HLASampleCount> getHlaSampleCount() {
		return hlaSampleCount;
	}

	public void setHlaSampleCount(List<HLASampleCount> hlaSampleCount) {
		this.hlaSampleCount = hlaSampleCount;
	}

	public List<SalesOverview> getOverview() {
		return overview;
	}

	public void setOverview(List<SalesOverview> overview) {
		this.overview = overview;
	}

	public List<NonHLAGeneInfo> getNonHLAGeneInfo() {
		return nonHLAGeneInfo;
	}

	public void setNonHLAGeneInfo(List<NonHLAGeneInfo> nonHLAGeneInfo) {
		this.nonHLAGeneInfo = nonHLAGeneInfo;
	}

	public List<ClientProjectInfo> getClientProjectInfo() {
		return clientProjectInfo;
	}

	public void setClientProjectInfo(List<ClientProjectInfo> clientProjectInfo) {
		this.clientProjectInfo = clientProjectInfo;
	}

	public List<SalesComparison> getComparison() {
		return comparison;
	}

	public void setComparison(List<SalesComparison> comparison) {
		this.comparison = comparison;
	}

	public List<ClientInfo> getClientInfo() {
		return clientInfo;
	}

	public void setClientInfo(List<ClientInfo> clientInfo) {
		this.clientInfo = clientInfo;
	}

	private ExceptionBean information;

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public ExceptionBean getInformation() {
        return information;
    }

    public void setInformation(ExceptionBean information) {
        this.information = information;
    }

	public UserInfo getUserInformation() {
		return userInformation;
	}

	public void setUserInformation(UserInfo userInformation) {
		this.userInformation = userInformation;
	}
}
