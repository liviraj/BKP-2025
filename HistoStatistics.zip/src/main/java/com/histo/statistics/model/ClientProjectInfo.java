package com.histo.statistics.model;

public class ClientProjectInfo {
	
	private String clientProjectCode;
	private String clientProjectName;
	
	@Override
	public String toString() {
		return "ClientProjectInfo [ClientProjectCode=" + clientProjectCode + ", ClientProjectName=" + clientProjectName
				+ "]";
	}
	public String getClientProjectCode() {
		return clientProjectCode;
	}
	public void setClientProjectCode(String clientProjectCode) {
		this.clientProjectCode = clientProjectCode;
	}
	public String getClientProjectName() {
		return clientProjectName;
	}
	public void setClientProjectName(String clientProjectName) {
		this.clientProjectName = clientProjectName;
	}
	
	

}
