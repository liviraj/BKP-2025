package com.histo.statistics.model;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.math.BigDecimal;

public class SalesComparison {
	
	private int rowId;
	private String salesMonthName;
	private int salesYear;
	private String salesMonth;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "#.00")
	private BigDecimal salesAmount;
	private String salesWeek;
	public SalesComparison() {
		super();
	}

	public SalesComparison(int rowId, String salesMonthName, int salesYear, String salesMonth, BigDecimal salesAmount, String salesWeek) {
		this.rowId = rowId;
		this.salesMonthName = salesMonthName;
		this.salesYear = salesYear;
		this.salesMonth = salesMonth;
		this.salesAmount = salesAmount;
		this.salesWeek = salesWeek;
	}

	public int getRowId() {
		return rowId;
	}
	public void setRowId(int rowId) {
		this.rowId = rowId;
	}
	public String getSalesMonthName() {
		return salesMonthName;
	}
	public void setSalesMonthName(String salesMonthName) {
		this.salesMonthName = salesMonthName;
	}
	public int getSalesYear() {
		return salesYear;
	}
	public void setSalesYear(int salesYear) {
		this.salesYear = salesYear;
	}
	public String getSalesMonth() {
		return salesMonth;
	}
	public void setSalesMonth(String salesMonth) {
		this.salesMonth = salesMonth;
	}
	public BigDecimal getSalesAmount() {
		return salesAmount;
	}
	public void setSalesAmount(BigDecimal salesAmount) {
		this.salesAmount = salesAmount;
	}
	public String getSalesWeek() {
		return salesWeek;
	}
	public void setSalesWeek(String salesWeek) {
		this.salesWeek = salesWeek;
	}
	@Override
	public String toString() {
		return "SalesComparison [rowId=" + rowId + ", salesMonthName=" + salesMonthName + ", salesYear=" + salesYear
				+ ", salesMonth=" + salesMonth + ", salesAmount=" + salesAmount + ", salesWeek=" + salesWeek + "]";
	}
	
}
