package com.histo.statistics.model;

public class ClientInfo {
private int clientId;
private String clientName;

	public ClientInfo(int clientId, String clientName) {
		this.clientId = clientId;
		this.clientName = clientName;
	}

	public ClientInfo() {
	}

	public int getClientId() {
	return clientId;
}
public void setClientId(int clientId) {
	this.clientId = clientId;
}
public String getClientName() {
	return clientName;
}
public void setClientName(String clientName) {
	this.clientName = clientName;
}
@Override
public String toString() {
	return "ClientInfo [clientId=" + clientId + ", clientName=" + clientName + "]";
}

}
