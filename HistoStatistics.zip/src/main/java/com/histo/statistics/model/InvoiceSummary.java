package com.histo.statistics.model;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.math.BigDecimal;

public class InvoiceSummary {
	private int rowId ;
	private int clientId ;
	private String clientName ;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "#.00")
	private BigDecimal salesAmount ;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "#.00")
	private BigDecimal receivedAmount ;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "#.00")
	private BigDecimal toBeReceivedAmount ;
	private int clientProjectId ;
	private int invoiceNumber ;
	private String invoiceDate ;
	private String clientProject ;
	private String paymentStatus ;
	
	@Override
	public String toString() {
		return "InvoiceSummary [rowId=" + rowId + ", clientId=" + clientId + ", clientName=" + clientName
				+ ", salesAmount=" + salesAmount + ", receivedAmount=" + receivedAmount + ", toBeReceivedAmount="
				+ toBeReceivedAmount + ", =" + clientProjectId + ", invoiceNumber=" + invoiceNumber
				+ ", invoiceDate=" + invoiceDate + ", clientProject=" + clientProject + ", paymentStatus="
				+ paymentStatus + "]";
	}
	public int getrowId() {
		return rowId;
	}
	public void setrowId(int rowId) {
		this.rowId = rowId;
	}
	public int getclientId() {
		return clientId;
	}
	public void setclientId(int clientId) {
		this.clientId = clientId;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public BigDecimal getSalesAmount() {
		return salesAmount;
	}
	public void setSalesAmount(BigDecimal salesAmount) {
		this.salesAmount = salesAmount;
	}
	public BigDecimal getReceivedAmount() {
		return receivedAmount;
	}
	public void setReceivedAmount(BigDecimal receivedAmount) {
		this.receivedAmount = receivedAmount;
	}
	public BigDecimal getToBeReceivedAmount() {
		return toBeReceivedAmount;
	}
	public void setToBeReceivedAmount(BigDecimal toBeReceivedAmount) {
		this.toBeReceivedAmount = toBeReceivedAmount;
	}
	public int getclientProjectId() {
		return clientProjectId;
	}
	public void setclientProjectId(int clientProjectId) {
		this.clientProjectId = clientProjectId;
	}
	public int getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(int invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public String getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public String getClientProject() {
		return clientProject;
	}
	public void setClientProject(String clientProject) {
		this.clientProject = clientProject;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	
	
}
