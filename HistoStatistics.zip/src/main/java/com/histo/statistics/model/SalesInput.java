package com.histo.statistics.model;

import java.util.Date;

public class SalesInput {

    private String clients;
    private String years;
    private String months;
    private String fromDate;
    private String toDate;
    private String type;
    private int summaryColumn;
    private String paymentStatus;

    public SalesInput() {
        super();
    }

    public String getClients() {
        return clients;
    }

    public void setClients(String clients) {
        this.clients = clients;
    }

    public String getYears() {
        return years;
    }

    public void setYears(String years) {
        this.years = years;
    }

    public String getMonths() {
        return months;
    }

    public void setMonths(String months) {
        this.months = months;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getSummaryColumn() {
        return summaryColumn;
    }

    public void setSummaryColumn(int summaryColumn) {
        this.summaryColumn = summaryColumn;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public SalesInput(String clients, String years, String months, String fromDate, String toDate, String type,
                      int summaryColumn, String paymentStatus) {
        super();
        this.clients = clients;
        this.years = years;
        this.months = months;
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.type = type;
        this.summaryColumn = summaryColumn;
        this.paymentStatus = paymentStatus;
    }

}
