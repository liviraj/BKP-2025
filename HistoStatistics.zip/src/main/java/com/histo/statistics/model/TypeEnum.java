package com.histo.statistics.model;

public enum TypeEnum {

	SALES_OVERVIEW("SalesOverview"),
	SALES_COMPARE("SalesCompare"),
	INVOICE_SUMMARY("InvoiceSummary");

	private String value;
	
	public String getValue() {
		return value;
	}

	TypeEnum(String value) {
		this.value = value;
	}
}
