package com.histo.statistics.model;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class HLASampleCount {

	private int rowId;
	private int sampleYear;
	private String sampleMonth;
	private String sampleMonthName;
	private int sampleCount;
	private String sampleWeek;
	private long hlaCount;
	private long nonHLACount;

	private double hlaCountPercentage;
	private double nonHlaCountPercentage;


	@Override
	public String toString() {
		return "HLASampleCount [rowID=" + rowId + ", sampleYear=" + sampleYear + ", sampleMonth=" + sampleMonth
				+ ", sampleMonthName=" + sampleMonthName + ", sampleCount=" + sampleCount + ", sampleWeek=" + sampleWeek
				+ ", hlaCount=" + hlaCount + ", nonHLACount=" + nonHLACount + "]";
	}

	public double getHlaCountPercentage() {
		return hlaCountPercentage;
	}

	public void setHlaCountPercentage(double hlaCountPercentage) {
		this.hlaCountPercentage = hlaCountPercentage;
	}

	public double getNonHlaCountPercentage() {
		return nonHlaCountPercentage;
	}

	public void setNonHlaCountPercentage(double nonHlaCountPercentage) {
		this.nonHlaCountPercentage = nonHlaCountPercentage;
	}

	public int getRowID() {
		return rowId;
	}

	public void setRowID(int rowID) {
		this.rowId = rowID;
	}

	public int getSampleYear() {
		return sampleYear;
	}

	public void setSampleYear(int sampleYear) {
		this.sampleYear = sampleYear;
	}

	public String getSampleMonth() {
		return sampleMonth;
	}

	public void setSampleMonth(String sampleMonth) {
		this.sampleMonth = sampleMonth;
	}

	public String getSampleMonthName() {
		return sampleMonthName;
	}

	public void setSampleMonthName(String sampleMonthName) {
		this.sampleMonthName = sampleMonthName;
	}

	public int getSampleCount() {
		return sampleCount;
	}

	public void setSampleCount(int sampleCount) {
		this.sampleCount = sampleCount;
	}

	public String getSampleWeek() {
		return sampleWeek;
	}

	public void setSampleWeek(String sampleWeek) {
		this.sampleWeek = sampleWeek;
	}

	public long getHlaCount() {
		return hlaCount;
	}

	public void setHlaCount(long hlaCount) {
		this.hlaCount = hlaCount;
	}

	public long getNonHLACount() {
		return nonHLACount;
	}

	public void setNonHLACount(long nonHLACount) {
		this.nonHLACount = nonHLACount;
	}


	// Method to calculate percentage
	public double calculatePercentage(long count, long totalCount) {
		if (totalCount == 0) {
			return 0.0; // Avoid division by zero
		}

		double result = (double) count/totalCount;

		BigDecimal bd = new BigDecimal(result * 100);
		bd = bd.setScale(2, RoundingMode.HALF_UP); // Rounds to two decimal places

		return bd.doubleValue ();
	}

}
