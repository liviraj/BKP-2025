package com.histo.statistics.model;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class SalesOverview {
	
	private int rowId;
	private int sortId;
	private int clientId;
	private String clientName;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "#.00")
	private BigDecimal salesAmount;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "#.00")
	private BigDecimal receivedAmount;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "#.00")
	private BigDecimal toBeReceivedAmount;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "#.00")
	private BigDecimal salesAmountPercentage;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "#.00")
	private BigDecimal receivedAmountPercentage;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "#.00")
	private BigDecimal toBeReceivedAmountPercentage;
	
	public SalesOverview() {
		super();
	}
	public int getRowId() {
		return rowId;
	}

	public void setRowId(int rowId) {
		this.rowId = rowId;
	}
	public int getSortId() {
		return sortId;
	}

	public void setSortId(int sortId) {
		this.sortId = sortId;
	}

	public int getClientId() {
		return clientId;
	}

	public void setClientId(int clientId) {
		this.clientId = clientId;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public BigDecimal getSalesAmount() {
		return salesAmount;
	}

	public void setSalesAmount(BigDecimal salesAmount) {
		this.salesAmount = salesAmount;
	}

	public BigDecimal getReceivedAmount() {
		return receivedAmount;
	}

	public void setReceivedAmount(BigDecimal receivedAmount) {
		this.receivedAmount = receivedAmount;
	}

	public BigDecimal getToBeReceivedAmount() {
		return toBeReceivedAmount;
	}

	public void setToBeReceivedAmount(BigDecimal toBeReceivedAmount) {
		this.toBeReceivedAmount = toBeReceivedAmount;
	}

	public BigDecimal getSalesAmountPercentage() {
		return salesAmountPercentage;
	}

	public void setSalesAmountPercentage(BigDecimal salesAmountPercentage) {
		this.salesAmountPercentage = salesAmountPercentage;
	}

	public BigDecimal getReceivedAmountPercentage() {
		return receivedAmountPercentage;
	}

	public void setReceivedAmountPercentage(BigDecimal receivedAmountPercentage) {
		this.receivedAmountPercentage = receivedAmountPercentage;
	}

	public BigDecimal getToBeReceivedAmountPercentage() {
		return toBeReceivedAmountPercentage;
	}

	public void setToBeReceivedAmountPercentage(BigDecimal toBeReceivedAmountPercentage) {
		this.toBeReceivedAmountPercentage = toBeReceivedAmountPercentage;
	}

	@Override
	public String toString() {
		return "SalesOverview [rowId=" + rowId + ", sortId=" + sortId + ", clientId=" + clientId + ", clientName="
				+ clientName + ", salesAmount=" + salesAmount + ", receivedAmount=" + receivedAmount
				+ ", toBeReceivedAmount=" + toBeReceivedAmount + "]";
	}

	// Method to calculate percentage
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "#.00")
	public BigDecimal calculatePercentage(BigDecimal count, BigDecimal totalCount) {

		if (totalCount.compareTo(BigDecimal.ZERO) <= 0) {
			return new BigDecimal (0.00);
		}

		BigDecimal result = count.divide(totalCount, 4, RoundingMode.HALF_UP);

		// Multiply by 100 to get the percentage and round to 2 decimal places
		BigDecimal percentage = result.multiply(BigDecimal.valueOf(100)).setScale(2, RoundingMode.HALF_UP);

		// Return the result as BigDecimal
		return percentage;
	}


}
