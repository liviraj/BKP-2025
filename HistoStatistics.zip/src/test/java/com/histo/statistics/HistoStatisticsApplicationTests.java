package com.histo.statistics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HistoStatisticsApplicationTests {

	@Test
	void contextLoads() {
	}

}
