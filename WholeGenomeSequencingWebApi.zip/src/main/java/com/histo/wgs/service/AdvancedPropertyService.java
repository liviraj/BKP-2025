package com.histo.wgs.service;

import com.histo.wgs.model.DemuxCCSStatusUpdateModel;
import org.springframework.http.ResponseEntity;

public interface AdvancedPropertyService {
    public ResponseEntity<Object> findDataTypeByWorkFlowTypeID(Integer workFlowTypeID);
    public ResponseEntity<Object> findAnalysisApplicationByDataTypeIDAndWorkFlowTypeID(Integer dataTypeID, Integer workFlowTypeID);
    public ResponseEntity<Object> findAllWorkFlowTypes();
    public ResponseEntity<Object> findDefaultPropertiesByAnalysisApplicationID(int analysisApplicationID);
    public ResponseEntity<Object> findAdvancedPropertiesByWgsRunId(Integer wgsRunId);
    public ResponseEntity<Object> findDropDownsByAnalysisApplicationID(Integer analysisApplicationID);
    public ResponseEntity<Object> findAssociatedInputByAnalysisApplicationID(Integer analysisApplicationID);
    public ResponseEntity<Object> findAdvancedPropertiesByWgsStatusViewerId(Integer wgsStatusViewerId);
    public ResponseEntity<Object> findAdvancedPropertiesForDemuxCCSRun(Integer wgsStatusViewerId);
    public ResponseEntity<Object> getDemuxCCSStatusByWgsStatusViewerId(Integer wgsStatusViewerId);
    public ResponseEntity<Object> updateDemuxCCSStatusByWgsStatusViewerId(Integer wgsStatusViewerId, DemuxCCSStatusUpdateModel statusUpdate);
}
