package com.histo.wgs.service.impl;

import com.histo.wgs.config.PropertyConfiguration;
import com.histo.wgs.entity.*;
import com.histo.wgs.entity.WGSRunMaster;
import com.histo.wgs.entity.WGSStatusViewer;
import com.histo.wgs.exception.ExceptionBean;
import com.histo.wgs.model.*;
import com.histo.wgs.repository.*;
import com.histo.wgs.service.AdvancedPropertyService;
import com.histo.wgs.util.FilterUtil;
import com.histo.wgs.util.WGSConstants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class AdvancedPropertyServiceImpl implements AdvancedPropertyService {

    private static final Logger logger = LogManager.getLogger(AdvancedPropertyServiceImpl.class.getName());
    private static final String STATUS = "status";
    private static final String DROP_DWON = "dropdown";
    private final PropertyConfiguration propertyConfiguration;
    private WGSAdvancedPropertyResModel response;

    private MappingJacksonValue mappingJacksonValue;

    private final WGSDataTypeMasterRepository wGSDataTypeMasterRepository;

    private WGSAnalysisApplicationMasterRepository wgsAnalysisApplicationMasterRepository;

    private WGSWorkFlowTypeRepository wgsWorkFlowTypeRepository;

    private WGSDefaultAdvancedPropertyRepository wGSDefaultAdvancedPropertyRepository;

    private WgsDefaultAdvancedPropertyDropdownRepository wgsDefaultAdvancedPropertyDropdownRepository;

    private WGSRunMasterRepository wgsRunMasterRepository;

    private WGSAdvancedPropertyRepository wgsAdvancedPropertyRepository;

    private WgsAssociatedInputRepository wgsAssociatedInputRepository;

    private WgsAssociatedInputsMasterRepository wgsAssociatedInputsMasterRepository;

    private WgsBarcodeSampleSetRepository wgsBarcodeSampleSetRepository;

    private WGSStatusViewerRepository wgsStatusViewerRepository;

    public AdvancedPropertyServiceImpl(PropertyConfiguration propertyConfiguration, WGSDataTypeMasterRepository wGSDataTypeMasterRepository, WGSAnalysisApplicationMasterRepository wgsAnalysisApplicationMasterRepository
            , WGSWorkFlowTypeRepository wgsWorkFlowTypeRepository
            , WGSDefaultAdvancedPropertyRepository wGSDefaultAdvancedPropertyRepository
            , WgsDefaultAdvancedPropertyDropdownRepository wgsDefaultAdvancedPropertyDropdownRepository
            , WGSAdvancedPropertyRepository wgsAdvancedPropertyRepository
            , WGSRunMasterRepository wgsRunMasterRepository
            , WgsAssociatedInputRepository wgsAssociatedInputRepository
            , WgsAssociatedInputsMasterRepository wgsAssociatedInputsMasterRepository
            , WgsBarcodeSampleSetRepository wgsBarcodeSampleSetRepository
            , WGSStatusViewerRepository wgsStatusViewerRepository) {
        this.propertyConfiguration = propertyConfiguration;
        response = new WGSAdvancedPropertyResModel();
        this.wGSDataTypeMasterRepository = wGSDataTypeMasterRepository;
        this.wgsAnalysisApplicationMasterRepository = wgsAnalysisApplicationMasterRepository;
        this.wgsWorkFlowTypeRepository = wgsWorkFlowTypeRepository;
        this.wGSDefaultAdvancedPropertyRepository = wGSDefaultAdvancedPropertyRepository;
        this.wgsDefaultAdvancedPropertyDropdownRepository = wgsDefaultAdvancedPropertyDropdownRepository;
        this.wgsRunMasterRepository = wgsRunMasterRepository;
        this.wgsAdvancedPropertyRepository = wgsAdvancedPropertyRepository;
        this.wgsAssociatedInputRepository = wgsAssociatedInputRepository;
        this.wgsAssociatedInputsMasterRepository = wgsAssociatedInputsMasterRepository;
        this.wgsBarcodeSampleSetRepository = wgsBarcodeSampleSetRepository;
        this.wgsStatusViewerRepository = wgsStatusViewerRepository;
    }

    @Override
    public ResponseEntity<Object> findDataTypeByWorkFlowTypeID(Integer workFlowTypeID) {
        List<WGSDataTypeMaster> wgsDataTypeMasters = wGSDataTypeMasterRepository.findByWorkFlowTypeID(workFlowTypeID);
        response.setStatus(true);
        response.setWgsDataTypeMasters(wgsDataTypeMasters);
        mappingJacksonValue = FilterUtil.advancePropResFilter(response, new String[]{STATUS, "wgsDataTypeMasters"});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Object> findAnalysisApplicationByDataTypeIDAndWorkFlowTypeID(Integer dataTypeID, Integer workFlowTypeID) {
        if (dataTypeID == null || dataTypeID == 0) {
            dataTypeID = -1;
        }
        List<WGSAnalysisApplicationMaster> byDataTypeIDAndWorkFlowTypeID = wgsAnalysisApplicationMasterRepository.findByDataTypeIDAndWorkFlowTypeID(dataTypeID, workFlowTypeID);
        response.setStatus(true);
        response.setAnalysisApplicationMasterList(byDataTypeIDAndWorkFlowTypeID);
        mappingJacksonValue = FilterUtil.advancePropResFilter(response, new String[]{STATUS, "analysisApplicationMasterList"});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Object> findDefaultPropertiesByAnalysisApplicationID(int analysisApplicationID) {
        Optional<WGSAnalysisApplicationMaster> analysisApplicationMaster = wgsAnalysisApplicationMasterRepository.findById(analysisApplicationID);
        if (!analysisApplicationMaster.isPresent()) {
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "Failed to fetch data.", "Invalid analysis application"));
            mappingJacksonValue = FilterUtil.advancePropResFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
        List<WGSDefaultAdvancedProperty> byAnalysisApplicationID = wGSDefaultAdvancedPropertyRepository.findByAnalysisApplication(analysisApplicationMaster.get());
        List<WGSDefaultAdvancedPropertyDto> wgsDefaultAdvancedProperties = new ArrayList<WGSDefaultAdvancedPropertyDto>();
        List<WgsDefaultAdvancedPropertyDropdown> dropdowns = new ArrayList<WgsDefaultAdvancedPropertyDropdown>();
        if (byAnalysisApplicationID.size() > 0) {
            for (WGSDefaultAdvancedProperty advancedProperty : byAnalysisApplicationID) {
                WGSDefaultAdvancedPropertyDto advancedPropertyDto = new WGSDefaultAdvancedPropertyDto();
                advancedPropertyDto.setDefaultAdvancedPropertyID(advancedProperty.getId());
                advancedPropertyDto.setPropertyLabel(advancedProperty.getPropertyLabel());
                advancedPropertyDto.setPropertyValue(advancedProperty.getPropertyValue());
                advancedPropertyDto.setType(advancedProperty.getType());
                advancedPropertyDto.setDefaultValue(advancedProperty.getDefaultValue());
                advancedPropertyDto.setWorkFlowTypeID(advancedProperty.getWorkFlowTypeID());
                advancedPropertyDto.setDataTypeID(advancedProperty.getDataTypeID());
                advancedPropertyDto.setAnalysisApplicationID(advancedProperty.getAnalysisApplication().getId());
                if (advancedProperty.getType().contains("dropdown")) {
                    dropdowns = wgsDefaultAdvancedPropertyDropdownRepository.findByAnalysisApplicationID(analysisApplicationMaster.get());
                    advancedPropertyDto.setDropdowns(dropdowns);
                }
                wgsDefaultAdvancedProperties.add(advancedPropertyDto);
            }
        }
        response.setStatus(true);
        response.setWgsDefaultAdvancedProperties(wgsDefaultAdvancedProperties);
        mappingJacksonValue = FilterUtil.advancePropResFilter(response, new String[]{STATUS, "wgsDefaultAdvancedProperties"});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Object> findAllWorkFlowTypes() {
        List<WGSWorkFlowType> workFlowTypes = wgsWorkFlowTypeRepository.findAll();
        response.setStatus(true);
        response.setWorkFlowTypes(workFlowTypes);
        mappingJacksonValue = FilterUtil.advancePropResFilter(response, new String[]{STATUS, "workFlowTypes"});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Object> findAdvancedPropertiesByWgsRunId(Integer wgsRunId) {
        try {
            WGSAdvancedPropertyViewDTO wgsAdvancedPropertyDTO = null;
            Optional<WGSRunMaster> wgsRunMasterById = wgsRunMasterRepository.findById(wgsRunId);
            if (wgsRunMasterById.get().getIsOnBoard()) {
                response.setStatus(true);
                response.setAdvancedPropertiesDTO(null);
                mappingJacksonValue = FilterUtil.advancePropResFilter(response, new String[]{STATUS, "advancedPropertiesDTO"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }
            if (!wgsRunMasterById.isPresent()) {
                return responseFalseValidation("Invalid WGSRunID", HttpStatus.NOT_FOUND);
            }
            Optional<WGSAnalysisApplicationMaster> ccsAnalysisApplication = wgsAnalysisApplicationMasterRepository
                    .findByAnalysisApplicationValue(WGSConstants.CCS_APP_VALUE);
            Optional<WGSAnalysisApplicationMaster> demuxAnalysisApplication = wgsAnalysisApplicationMasterRepository
                    .findByAnalysisApplicationValue(WGSConstants.DEMULTIPLEX_BARCODES_APP_VALUE);
            List<WGSAdvancedProperty> wgsAdvancedProperties = wgsAdvancedPropertyRepository.findByWgsRunID(wgsRunMasterById.get());
            boolean isDemultiplexApp = wgsAdvancedProperties.stream().anyMatch(property ->
                    property.getAnalysisApplicationID().getAnalysisApplicationValue().equals(
                            WGSConstants.DEMULTIPLEX_BARCODES_APP_VALUE
                    ));

            if (wgsAdvancedProperties.size() > 0) {
                wgsAdvancedPropertyDTO = new WGSAdvancedPropertyViewDTO();
                List<AdvancedProperty> advancedPropertyList = new ArrayList<AdvancedProperty>();
                wgsAdvancedPropertyDTO.setwGSRunID(wgsRunId);
                wgsAdvancedPropertyDTO.setDataTypeID(isDemultiplexApp ?
                        wgsAdvancedProperties.stream().filter(property -> property.getAnalysisApplicationID().getAnalysisApplicationValue()
                                .equals(WGSConstants.DEMULTIPLEX_BARCODES_APP_VALUE)).findFirst().get().getDataTypeID()
                        : wgsAdvancedProperties.get(0).getDataTypeID()
                );

                wgsAdvancedPropertyDTO.setAnalysisApplicationID(
                        isDemultiplexApp ? demuxAnalysisApplication.get().getId() : wgsAdvancedProperties.get(0).getAnalysisApplicationID().getId());
                wgsAdvancedPropertyDTO.setWorkFlowTypeID(wgsAdvancedProperties.get(0).getWorkFlowTypeID().getId());

                for (WGSAdvancedProperty property : wgsAdvancedProperties) {
                    AdvancedProperty advancedProperty = new AdvancedProperty();
                    advancedProperty.setAdvancedPropertyId(property.getId());
                    advancedProperty.setDefaultAdvancedPropertyID(property.getDefaultAdvancedPropertyID().getId());
                    advancedProperty.setType(property.getDefaultAdvancedPropertyID().getType());
                    advancedProperty.setDropdownID(property.getDropdownID());
                    advancedProperty.setPropertyLabel(property.getDefaultAdvancedPropertyID().getPropertyLabel());
                    advancedProperty.setValue(property.getValue());
                    if (advancedProperty.getType().contains("dropdown")) {
                        advancedProperty.setDropdowns(wgsDefaultAdvancedPropertyDropdownRepository.findByAnalysisApplicationID(
                                wgsAdvancedProperties.get(wgsAdvancedProperties.indexOf(property)).getAnalysisApplicationID()));
                    }
                    advancedProperty.setPropertyValue(property.getDefaultAdvancedPropertyID().getPropertyValue());
                    advancedProperty.setAnalysisApplicationId(
                            wgsAdvancedProperties.get(wgsAdvancedProperties.indexOf(property)).getAnalysisApplicationID().getId()
                    );
                    advancedPropertyList.add(advancedProperty);
                }
                wgsAdvancedPropertyDTO.setAdvancedProperties(advancedPropertyList);
            }

            List<WGSWorkFlowType> workFlowTypes = wgsWorkFlowTypeRepository.findAll();
            List<WGSWorkFlowTypeDto> workFlowTypesDtos = new ArrayList<WGSWorkFlowTypeDto>();
            for (WGSWorkFlowType workFlowType : workFlowTypes) {
                WGSWorkFlowTypeDto wgsWorkFlowTypeDto = new WGSWorkFlowTypeDto();
                wgsWorkFlowTypeDto.setId(workFlowType.getId());
                wgsWorkFlowTypeDto.setWorkFlowTypeName(workFlowType.getWorkFlowTypeName());
                workFlowTypesDtos.add(wgsWorkFlowTypeDto);
            }
            List<WGSAnalysisApplicationMaster> analysisApplicationMasters = wgsAnalysisApplicationMasterRepository.findByDataTypeIDAndWorkFlowTypeID(
                    wgsAdvancedPropertyDTO.getDataTypeID(), wgsAdvancedPropertyDTO.getWorkFlowTypeID());
            List<WGSAnalysisApplicationMasterDto> analysisApplicationMastersDto = new ArrayList<WGSAnalysisApplicationMasterDto>();

            for (WGSAnalysisApplicationMaster analysisApplication : analysisApplicationMasters) {
                WGSAnalysisApplicationMasterDto analysisApplicationMasterDto = new WGSAnalysisApplicationMasterDto();
                analysisApplicationMasterDto.setId(analysisApplication.getId());
                analysisApplicationMasterDto.setAnalysisApplicationDisplayName(analysisApplication.getAnalysisApplicationDisplayName());
                analysisApplicationMasterDto.setAnalysisApplicationValue(analysisApplication.getAnalysisApplicationValue());
                analysisApplicationMastersDto.add(analysisApplicationMasterDto);
            }

            List<WGSDataTypeMaster> wgsDataTypeMasters = new ArrayList<WGSDataTypeMaster>();
            if (wgsAdvancedPropertyDTO.getWorkFlowTypeID() == 3) {
                wgsDataTypeMasters = wGSDataTypeMasterRepository.findAll();
            }
            List<WgsAssociatedInput> associatedInputs;
            if (isDemultiplexApp) {
                List<WGSAnalysisApplicationMaster> wgsAnalysisApplicationMasters = Arrays.asList(
                        ccsAnalysisApplication.get()
                        , demuxAnalysisApplication.get());
                associatedInputs = wgsAssociatedInputRepository.findByAnalysisApplicationIDIn(wgsAnalysisApplicationMasters);
            } else {
                associatedInputs = wgsAssociatedInputRepository.findByAnalysisApplicationID(wgsAdvancedProperties.get(0).getAnalysisApplicationID());
            }

            List<WgsAssociatedInputsMaster> associatedInputsMasters = wgsAssociatedInputsMasterRepository.findByWgsRunId(wgsRunMasterById.get());

            if (associatedInputsMasters.size() > 0) {
                List<WgsAssociatedInputsMasterDTO> associatedInputsMasterDTOS = new ArrayList<WgsAssociatedInputsMasterDTO>();
                for (WgsAssociatedInputsMaster associatedInputsMaster : associatedInputsMasters) {
                    WgsAssociatedInputsMasterDTO associatedInputsMasterDTO = new WgsAssociatedInputsMasterDTO();
                    WgsAssociatedInput associatedInput = associatedInputs.stream().filter(input -> input.getId() == associatedInputsMaster.getAssociatedInput().getId()).findAny().orElse(null);
                    if (associatedInput.getPropertyValue().equals(WGSConstants.OUTPUT_DATA_SET_PROPERTY_VALUE)) { // skip output data set property for Demultiplexing Application
                        continue;
                    }
                    associatedInputsMasterDTO.setId(associatedInputsMaster.getId());
                    associatedInputsMasterDTO.setValue(associatedInputsMaster.getValue());
                    associatedInputsMasterDTO.setAssociatedInputId(associatedInputsMaster.getAssociatedInput().getId());
                    associatedInputsMasterDTO.setPropertyLabel(associatedInput.getPropertyLabel());
                    associatedInputsMasterDTO.setPropertyValue(associatedInput.getPropertyValue());
                    associatedInputsMasterDTO.setType(associatedInput.getType());
                    associatedInputsMasterDTO.setDefaultValue(associatedInput.getDefaultValue());
                    associatedInputsMasterDTO.setUuid(associatedInputsMaster.getUuid());
                    associatedInputsMasterDTO.setAnalysisApplicationId(
                            associatedInputsMasters.get(associatedInputsMasters.indexOf(associatedInputsMaster)).getAnalysisApplicationID().getId()
                    );
                    associatedInputsMasterDTOS.add(associatedInputsMasterDTO);
                }
                wgsAdvancedPropertyDTO.setAssociatedInputsMasters(associatedInputsMasterDTOS);
            }

            List<WgsBarcodeSampleSet> wgsBarcodeSampleSets = wgsBarcodeSampleSetRepository.findByWgsRunId(wgsRunMasterById.get());
            if (wgsBarcodeSampleSets != null && wgsBarcodeSampleSets.size() > 0) {
                List<WgsBarcodeSampleSetDTO> barcodeSampleSets = new ArrayList<WgsBarcodeSampleSetDTO>();
                for (WgsBarcodeSampleSet wgsBarcodeSampleSet : wgsBarcodeSampleSets) {
                    WgsBarcodeSampleSetDTO barcodeSampleSet = new WgsBarcodeSampleSetDTO();
                    barcodeSampleSet.setBarcode(wgsBarcodeSampleSet.getBarcode());
                    barcodeSampleSet.setBioSample(wgsBarcodeSampleSet.getBioSample());
                    barcodeSampleSets.add(barcodeSampleSet);
                }
                wgsAdvancedPropertyDTO.setBarcodeSampleSetList(barcodeSampleSets);
            }
            wgsAdvancedPropertyDTO.setWorkFlowTypes(workFlowTypesDtos);
            wgsAdvancedPropertyDTO.setWgsAnalysisApplicationMasters(analysisApplicationMastersDto);
            wgsAdvancedPropertyDTO.setWgsDataTypeMasters(wgsDataTypeMasters);

            response.setStatus(true);
            response.setAdvancedPropertiesDTO(wgsAdvancedPropertyDTO);
            mappingJacksonValue = FilterUtil.advancePropResFilter(response, new String[]{STATUS, "advancedPropertiesDTO"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException(e);
        }
    }

    @Override
    public ResponseEntity<Object> findDropDownsByAnalysisApplicationID(Integer analysisApplicationID) {
        try {
            Optional<WGSAnalysisApplicationMaster> analysisApplicationMaster = wgsAnalysisApplicationMasterRepository.findById(analysisApplicationID);
            if (!analysisApplicationMaster.isPresent()) {
                return responseFalseValidation("Invalid AnalysisApplicationID", HttpStatus.NOT_FOUND);
            }

            List<WgsDefaultAdvancedPropertyDropdown> defaultAdvancedPropertyDropdowns = wgsDefaultAdvancedPropertyDropdownRepository.findByAnalysisApplicationID(analysisApplicationMaster.get());
            response.setStatus(true);
            response.setDefaultAdvancedPropertyDropdowns(defaultAdvancedPropertyDropdowns);
            mappingJacksonValue = FilterUtil.advancePropResFilter(response, new String[]{STATUS, "defaultAdvancedPropertyDropdowns"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException(e);
        }
    }

    @Override
    public ResponseEntity<Object> findAssociatedInputByAnalysisApplicationID(Integer analysisApplicationID) {
        try {
            Optional<WGSAnalysisApplicationMaster> wgsAnalysisApplicationMaster = wgsAnalysisApplicationMasterRepository.findById(analysisApplicationID);
            if (!wgsAnalysisApplicationMaster.isPresent()) {
                return responseFalseValidation("Invalid AnalysisApplicationID", HttpStatus.NOT_FOUND);
            }
            List<WgsAssociatedInput> associatedInputs = wgsAssociatedInputRepository.findByAnalysisApplicationID(wgsAnalysisApplicationMaster.get());
            // Remove Demultiplexed Output Data Set Name for Demultiplex Barcodes
            if (wgsAnalysisApplicationMaster.get().getAnalysisApplicationValue().equals(WGSConstants.DEMULTIPLEX_BARCODES_APP_VALUE)) {
                associatedInputs.removeIf(input -> input.getPropertyValue().equals(WGSConstants.OUTPUT_DATA_SET_PROPERTY_VALUE));
            }
            response.setStatus(true);
            response.setAssociatedInputs(associatedInputs);
            mappingJacksonValue = FilterUtil.advancePropResFilter(response, new String[]{STATUS, "associatedInputs"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException(e);
        }
    }

    @Override
    public ResponseEntity<Object> findAdvancedPropertiesByWgsStatusViewerId(Integer wgsStatusViewerId) {
        try {
            Optional<WGSStatusViewer> wgsStatusViewer = wgsStatusViewerRepository.findById(wgsStatusViewerId);
            if (!wgsStatusViewer.isPresent()) {
                return responseFalseValidation("Invalid WGSStatusViewerId", HttpStatus.NOT_FOUND);
            }
            SmrtWgsAdvancedProperty smrtWgsAdvancedProperty = null;
            List<WGSAdvancedProperty> wgsAdvancedProperties = wgsAdvancedPropertyRepository.findByWgsRunID(wgsStatusViewer.get().getWGSRunID());
            List<WGSAdvancedProperty> demuxAdvancedProperty = wgsAdvancedProperties.stream().filter(wgsAdvancedProperty ->
                    wgsAdvancedProperty.getAnalysisApplicationID().getAnalysisApplicationValue().equals(WGSConstants.DEMUX_APP_VALUE)
            ).collect(Collectors.toList());
            List<WGSAdvancedProperty> ccsAdvancedProperty = wgsAdvancedProperties.stream().filter(wgsAdvancedProperty ->
                    wgsAdvancedProperty.getAnalysisApplicationID().getAnalysisApplicationValue().equals(WGSConstants.CCS_APP_VALUE)
            ).collect(Collectors.toList());
            if (demuxAdvancedProperty.size() > 0 && ccsAdvancedProperty.size() > 0) {
                wgsAdvancedProperties = wgsAdvancedPropertyRepository.findByWgsRunIDAndAnalysisApplicationID(
                        wgsStatusViewer.get().getWGSRunID()
                        , demuxAdvancedProperty.get(0).getAnalysisApplicationID()
                );
            }
            if (wgsAdvancedProperties.size() > 0) {
                smrtWgsAdvancedProperty = new SmrtWgsAdvancedProperty();
                List<AdvancedProperty> advancedPropertyList = new ArrayList<AdvancedProperty>();
                for (WGSAdvancedProperty property : wgsAdvancedProperties) {
                    AdvancedProperty advancedProperty = new AdvancedProperty();
                    advancedProperty.setAdvancedPropertyId(property.getId());
                    advancedProperty.setDefaultAdvancedPropertyID(property.getDefaultAdvancedPropertyID().getId());
                    advancedProperty.setType(property.getDefaultAdvancedPropertyID().getType());
                    advancedProperty.setDropdownID(property.getDropdownID());
                    advancedProperty.setPropertyLabel(property.getDefaultAdvancedPropertyID().getPropertyLabel());
                    advancedProperty.setValue(property.getValue());
                    if (advancedProperty.getType().contains("dropdown")) {
                        advancedProperty.setDropdowns(wgsDefaultAdvancedPropertyDropdownRepository.findByAnalysisApplicationID(wgsAdvancedProperties.get(0).getAnalysisApplicationID()));
                    }
                    advancedProperty.setPropertyValue(property.getDefaultAdvancedPropertyID().getPropertyValue());

                    advancedPropertyList.add(advancedProperty);
                }
                smrtWgsAdvancedProperty.setAdvancedProperties(advancedPropertyList);
            }

            WGSWorkFlowType workFlowType = wgsWorkFlowTypeRepository.findById(wgsAdvancedProperties.get(0).getWorkFlowTypeID().getId()).get();
            WGSWorkFlowTypeDto wgsWorkFlowTypeDto = new WGSWorkFlowTypeDto();
            if (workFlowType != null) {
                wgsWorkFlowTypeDto.setId(workFlowType.getId());
                wgsWorkFlowTypeDto.setWorkFlowTypeName(workFlowType.getWorkFlowTypeName());
            }
            WGSAnalysisApplicationMaster analysisApplicationMaster = wgsAnalysisApplicationMasterRepository.findById(wgsAdvancedProperties.get(0).getAnalysisApplicationID().getId()).get();
            WGSAnalysisApplicationMasterDto analysisApplicationMasterDto = new WGSAnalysisApplicationMasterDto();
            if (analysisApplicationMaster != null) {
                analysisApplicationMasterDto.setId(analysisApplicationMaster.getId());
                analysisApplicationMasterDto.setAnalysisApplicationDisplayName(analysisApplicationMaster.getAnalysisApplicationDisplayName());
                analysisApplicationMasterDto.setAnalysisApplicationValue(analysisApplicationMaster.getAnalysisApplicationValue());
            }
            WGSDataTypeMaster wgsDataTypeMaster = null;
            if (wgsAdvancedProperties.get(0).getWorkFlowTypeID().getId() == 3) {
                wgsDataTypeMaster = wGSDataTypeMasterRepository.findById(wgsAdvancedProperties.get(0).getDataTypeID()).get();
            } else {
                wgsDataTypeMaster = wGSDataTypeMasterRepository.findByDataTypeValue(DataTypeEnum.ccsreads.toString()).get();
            }
            List<WgsAssociatedInput> associatedInputs;
            List<WgsAssociatedInputsMaster> associatedInputsMasters;
            if (demuxAdvancedProperty.size() > 0 && ccsAdvancedProperty.size() > 0) {
                associatedInputs = wgsAssociatedInputRepository.findByAnalysisApplicationID(demuxAdvancedProperty.get(0).getAnalysisApplicationID());
                associatedInputsMasters = wgsAssociatedInputsMasterRepository.findByWgsRunIdAndAnalysisApplicationID(wgsStatusViewer.get().getWGSRunID()
                        , demuxAdvancedProperty.get(0).getAnalysisApplicationID());
            } else {
                associatedInputs = wgsAssociatedInputRepository.findByAnalysisApplicationID(wgsAdvancedProperties.get(0).getAnalysisApplicationID());
                associatedInputsMasters = wgsAssociatedInputsMasterRepository.findByWgsRunId(wgsStatusViewer.get().getWGSRunID());
            }


            if (associatedInputsMasters.size() > 0) {
                List<WgsAssociatedInputsMasterDTO> associatedInputsMasterDTOS = new ArrayList<WgsAssociatedInputsMasterDTO>();
                for (WgsAssociatedInputsMaster associatedInputsMaster : associatedInputsMasters) {
                    WgsAssociatedInputsMasterDTO associatedInputsMasterDTO = new WgsAssociatedInputsMasterDTO();
                    WgsAssociatedInput associatedInput = associatedInputs.stream().filter(input -> input.getId() == associatedInputsMaster.getAssociatedInput().getId()).findAny().orElse(null);
                    associatedInputsMasterDTO.setId(associatedInputsMaster.getId());
                    associatedInputsMasterDTO.setValue(associatedInputsMaster.getValue());
                    associatedInputsMasterDTO.setAssociatedInputId(associatedInputsMaster.getAssociatedInput().getId());
                    associatedInputsMasterDTO.setPropertyLabel(associatedInput.getPropertyLabel());
                    associatedInputsMasterDTO.setPropertyValue(associatedInput.getPropertyValue());
                    associatedInputsMasterDTO.setType(associatedInput.getType());
                    associatedInputsMasterDTO.setDefaultValue(associatedInput.getDefaultValue());
                    associatedInputsMasterDTO.setUuid(associatedInputsMaster.getUuid());
                    associatedInputsMasterDTOS.add(associatedInputsMasterDTO);
                }
                smrtWgsAdvancedProperty.setAssociatedInputsMasters(associatedInputsMasterDTOS);
            }

            List<WgsBarcodeSampleSet> wgsBarcodeSampleSets = wgsBarcodeSampleSetRepository.findByWgsRunId(wgsStatusViewer.get().getWGSRunID());
            if (wgsBarcodeSampleSets != null && wgsBarcodeSampleSets.size() > 0) {
                List<WgsBarcodeSampleSetDTO> barcodeSampleSets = new ArrayList<WgsBarcodeSampleSetDTO>();
                for (WgsBarcodeSampleSet wgsBarcodeSampleSet : wgsBarcodeSampleSets) {
                    WgsBarcodeSampleSetDTO barcodeSampleSet = new WgsBarcodeSampleSetDTO();
                    barcodeSampleSet.setBarcode(wgsBarcodeSampleSet.getBarcode());
                    barcodeSampleSet.setBioSample(wgsBarcodeSampleSet.getBioSample());
                    barcodeSampleSets.add(barcodeSampleSet);
                }
                smrtWgsAdvancedProperty.setBarcodeSampleSetList(barcodeSampleSets);
            }
            smrtWgsAdvancedProperty.setDataSetName(wgsStatusViewer.get().getWGSRunID().getDataSetName());
            smrtWgsAdvancedProperty.setFilePath(wgsStatusViewer.get().getWGSRunID().getFilePath());
            smrtWgsAdvancedProperty.setWorkFlowType(wgsWorkFlowTypeDto);
            smrtWgsAdvancedProperty.setWgsAnalysisApplicationMaster(analysisApplicationMasterDto);
            smrtWgsAdvancedProperty.setWgsDataTypeMaster(wgsDataTypeMaster);

            response.setStatus(true);
            response.setSmrtWgsAdvancedProperty(smrtWgsAdvancedProperty);
            mappingJacksonValue = FilterUtil.advancePropResFilter(response, new String[]{STATUS, "smrtWgsAdvancedProperty"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException(e);
        }
    }

    @Override
    public ResponseEntity<Object> findAdvancedPropertiesForDemuxCCSRun(Integer wgsStatusViewerId) {
        try {
            Optional<WGSStatusViewer> wgsStatusViewer = wgsStatusViewerRepository.findById(wgsStatusViewerId);
            if (!wgsStatusViewer.isPresent()) {
                return responseFalseValidation("Invalid WGSStatusViewerId", HttpStatus.NOT_FOUND);
            }
            SmrtWgsAdvancedProperty smrtWgsAdvancedProperty = null;
            Optional<WGSAnalysisApplicationMaster> analysisApplication = wgsAnalysisApplicationMasterRepository.findByAnalysisApplicationValue(WGSConstants.CCS_APP_VALUE);
            List<WGSAdvancedProperty> wgsAdvancedProperties = wgsAdvancedPropertyRepository.findByWgsRunIDAndAnalysisApplicationID(wgsStatusViewer.get().getWGSRunID()
                    , analysisApplication.get());
            if (wgsAdvancedProperties.size() > 0) {
                smrtWgsAdvancedProperty = new SmrtWgsAdvancedProperty();
                List<AdvancedProperty> advancedPropertyList = new ArrayList<AdvancedProperty>();
                for (WGSAdvancedProperty property : wgsAdvancedProperties) {
                    AdvancedProperty advancedProperty = new AdvancedProperty();
                    advancedProperty.setAdvancedPropertyId(property.getId());
                    advancedProperty.setDefaultAdvancedPropertyID(property.getDefaultAdvancedPropertyID().getId());
                    advancedProperty.setType(property.getDefaultAdvancedPropertyID().getType());
                    advancedProperty.setDropdownID(property.getDropdownID());
                    advancedProperty.setPropertyLabel(property.getDefaultAdvancedPropertyID().getPropertyLabel());
                    advancedProperty.setValue(property.getValue());
                    if (advancedProperty.getType().contains("dropdown")) {
                        advancedProperty.setDropdowns(wgsDefaultAdvancedPropertyDropdownRepository.findByAnalysisApplicationID(wgsAdvancedProperties.get(0).getAnalysisApplicationID()));
                    }
                    advancedProperty.setPropertyValue(property.getDefaultAdvancedPropertyID().getPropertyValue());

                    advancedPropertyList.add(advancedProperty);
                }
                smrtWgsAdvancedProperty.setAdvancedProperties(advancedPropertyList);
            }

            WGSWorkFlowType workFlowType = wgsWorkFlowTypeRepository.findById(wgsAdvancedProperties.get(0).getWorkFlowTypeID().getId()).get();
            WGSWorkFlowTypeDto wgsWorkFlowTypeDto = new WGSWorkFlowTypeDto();
            wgsWorkFlowTypeDto.setId(workFlowType.getId());
            wgsWorkFlowTypeDto.setWorkFlowTypeName(workFlowType.getWorkFlowTypeName());

            WGSAnalysisApplicationMasterDto analysisApplicationMasterDto = new WGSAnalysisApplicationMasterDto();
            if (analysisApplication != null) {
                analysisApplicationMasterDto.setId(analysisApplication.get().getId());
                analysisApplicationMasterDto.setAnalysisApplicationDisplayName(analysisApplication.get().getAnalysisApplicationDisplayName());
                analysisApplicationMasterDto.setAnalysisApplicationValue(analysisApplication.get().getAnalysisApplicationValue());
            }
            WGSDataTypeMaster wgsDataTypeMaster = wGSDataTypeMasterRepository.findByDataTypeValue(DataTypeEnum.subreads.toString()).get();

            List<WgsAssociatedInput> associatedInputs = wgsAssociatedInputRepository.findByAnalysisApplicationID(wgsAdvancedProperties.get(0).getAnalysisApplicationID());
            List<WgsAssociatedInputsMaster> associatedInputsMasters = wgsAssociatedInputsMasterRepository.findByWgsRunIdAndAnalysisApplicationID(
                    wgsStatusViewer.get().getWGSRunID()
                    , wgsAdvancedProperties.get(0).getAnalysisApplicationID()
            );

            if (associatedInputsMasters.size() > 0) {
                List<WgsAssociatedInputsMasterDTO> associatedInputsMasterDTOS = new ArrayList<WgsAssociatedInputsMasterDTO>();
                for (WgsAssociatedInputsMaster associatedInputsMaster : associatedInputsMasters) {
                    WgsAssociatedInputsMasterDTO associatedInputsMasterDTO = new WgsAssociatedInputsMasterDTO();
                    WgsAssociatedInput associatedInput = associatedInputs.stream().filter(input -> input.getId() == associatedInputsMaster.getAssociatedInput().getId()).findAny().orElse(null);
                    associatedInputsMasterDTO.setId(associatedInputsMaster.getId());
                    associatedInputsMasterDTO.setValue(associatedInputsMaster.getValue());
                    associatedInputsMasterDTO.setAssociatedInputId(associatedInputsMaster.getAssociatedInput().getId());
                    associatedInputsMasterDTO.setPropertyLabel(associatedInput.getPropertyLabel());
                    associatedInputsMasterDTO.setPropertyValue(associatedInput.getPropertyValue());
                    associatedInputsMasterDTO.setType(associatedInput.getType());
                    associatedInputsMasterDTO.setDefaultValue(associatedInput.getDefaultValue());
                    associatedInputsMasterDTO.setUuid(associatedInputsMaster.getUuid());
                    associatedInputsMasterDTOS.add(associatedInputsMasterDTO);
                }
                smrtWgsAdvancedProperty.setAssociatedInputsMasters(associatedInputsMasterDTOS);
            }

            smrtWgsAdvancedProperty.setDataSetName(wgsStatusViewer.get().getWGSRunID().getDataSetName());
            smrtWgsAdvancedProperty.setFilePath(wgsStatusViewer.get().getWGSRunID().getFilePath());
            smrtWgsAdvancedProperty.setWorkFlowType(wgsWorkFlowTypeDto);
            smrtWgsAdvancedProperty.setWgsAnalysisApplicationMaster(analysisApplicationMasterDto);
            smrtWgsAdvancedProperty.setWgsDataTypeMaster(wgsDataTypeMaster);

            response.setStatus(true);
            response.setSmrtWgsAdvancedProperty(smrtWgsAdvancedProperty);
            mappingJacksonValue = FilterUtil.advancePropResFilter(response, new String[]{STATUS, "smrtWgsAdvancedProperty"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException(e);
        }
    }

    @Override
    public ResponseEntity<Object> getDemuxCCSStatusByWgsStatusViewerId(Integer wgsStatusViewerId) {
        try {
            Optional<WGSStatusViewer> wgsStatusViewer = wgsStatusViewerRepository.findById(wgsStatusViewerId);
            if (!wgsStatusViewer.isPresent()) {
                return responseFalseValidation("Invalid WGSStatusViewerID", HttpStatus.NOT_FOUND);
            }
            DemuxCCSStatus demuxCCSStatus = new DemuxCCSStatus();
            demuxCCSStatus.setDemuxStatus(wgsStatusViewer.get().getDemultiplexStatus());
            demuxCCSStatus.setCcsStatus(wgsStatusViewer.get().getCcsStatus());

            response.setStatus(true);
            response.setDemuxCCSStatus(demuxCCSStatus);
            mappingJacksonValue = FilterUtil.advancePropResFilter(response, new String[]{STATUS, "demuxCCSStatus"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException(e);
        }
    }

    @Override
    public ResponseEntity<Object> updateDemuxCCSStatusByWgsStatusViewerId(Integer wgsStatusViewerId, DemuxCCSStatusUpdateModel statusUpdate) {
        try {
            Optional<WGSStatusViewer> wgsStatusViewer = wgsStatusViewerRepository.findById(wgsStatusViewerId);
            if (!wgsStatusViewer.isPresent()) {
                return responseFalseValidation("WgsStatusViewer not found", HttpStatus.NOT_FOUND);
            }
            if (statusUpdate.getSmrtRunEnum() == SMRTRunEnum.CCS) {
                wgsStatusViewer.get().setCcsStatus(statusUpdate.getRunStatus());
            } else if (statusUpdate.getSmrtRunEnum() == SMRTRunEnum.DEMULTIPLEX) {
                wgsStatusViewer.get().setDemultiplexStatus(statusUpdate.getRunStatus());
            }

            wgsStatusViewerRepository.save(wgsStatusViewer.get());

            response.setStatus(true);
            response.setResponseMsg("Updated Successfully");
            mappingJacksonValue = FilterUtil.advancePropResFilter(response, new String[]{STATUS, "responseMsg"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException(e);
        }
    }

    private ResponseEntity<Object> responseFalseValidation(String description, HttpStatus httpStatus) {
        response.setStatus(false);
        response.setInformation(new ExceptionBean(new Date(), "Operation  Failed", description));
        mappingJacksonValue = FilterUtil.advancePropResFilter(response, new String[]{STATUS, "information"});
        return new ResponseEntity<>(mappingJacksonValue, httpStatus);
    }

    private ResponseEntity<Object> catchException(Exception e) {
        logger.error("Error : {}", e);
        response.setStatus(false);
        response.setInformation(new ExceptionBean(new Date(), "Error", "Something went wrong. Please try again."));
        mappingJacksonValue = FilterUtil.advancePropResFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }

}
