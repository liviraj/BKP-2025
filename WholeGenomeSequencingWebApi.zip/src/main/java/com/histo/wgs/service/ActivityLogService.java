package com.histo.wgs.service;

import com.histo.wgs.model.ActivityLogReq;
import org.springframework.http.ResponseEntity;

public interface ActivityLogService {
    public ResponseEntity<String> insertESignActivityLog(ActivityLogReq logReq);
}
