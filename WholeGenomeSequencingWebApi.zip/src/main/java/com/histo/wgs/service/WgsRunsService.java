package com.histo.wgs.service;

import com.histo.wgs.model.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface WgsRunsService {
	public ResponseEntity<Object> findAllWgsRuns(WgsRunFilterDto wgsRunFilter);
	public ResponseEntity<Object> createWgsRuns(List<WGSRunCreateDto> wgsRunCreateDtos);
	public ResponseEntity<Object> updateWgsRuns(List<WGSRunUpdateDto> wgsRunUpdateDto);
	public ResponseEntity<Object> wgsRunFindAllClients();
	public ResponseEntity<Object> wgsRunFindAllClientProjects();
	public ResponseEntity<Object> wgsRunFindAllClientProjectsOnlyRunCreated();
	public ResponseEntity<Object> findAllRunComments(int WGSRunId, int WGSStatusViewerID);
	public ResponseEntity<Object> saveRunComments(WgsRunCommands wgsRunCommands);
	public ResponseEntity<Object> deleteRunCommandsById(int CommentsId);
	public ResponseEntity<Object> findAllRunLogs(int wGSStatusViewerID,int wgsRunId);
	public ResponseEntity<Object> validateWgsRunPinNo(WgsRunPinNo wgsRunPinNo);
	public ResponseEntity<Object> findAllreportAttributesByClientProjectIDNGeneGroupID(int clientProjectID,int subClientID,int geneGroupID);
    public ResponseEntity<Object> runValidate(WGSRunCreateDto wgsRunCreateDto);
	public ResponseEntity<Object> demultiplexingFileValidation(DemultiplexingFile demultiplexingFile);
	public ResponseEntity<Object> reportToClientEmailInfo(WGSClientReportMasterDTO wgsClientReportMaster);
	public ResponseEntity<Object> reportToClientSendEmail(WGSEmailDetailsDTO emailDetails);

	public ResponseEntity<Object> downloadFileByPath(String filePath);
	public ResponseEntity<Object> reportToClientUploadFile(MultipartFile multipartFile,String uploadPath);
	public ResponseEntity<Object> updateSMRTRunPath(String path, Integer wgsStatusViewerId);
	public ResponseEntity<Object> validateWgsSamples(ValidateSamplesDetailDTO validateSamplesDetail);
	public ResponseEntity<Object> getPooledSamplesBySampleId(String sample);
}
	
	

	