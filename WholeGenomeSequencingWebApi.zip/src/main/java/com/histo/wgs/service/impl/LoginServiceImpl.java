package com.histo.wgs.service.impl;

import com.histo.wgs.model.UserInformationDTO;
import com.histo.wgs.model.WGSResModel;
import com.histo.wgs.exception.ExceptionBean;
import com.histo.wgs.model.LoginModel;
import com.histo.wgs.service.LoginService;
import com.histo.wgs.util.FilterUtil;
import com.histo.wgs.util.WGSConstants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class LoginServiceImpl implements LoginService {

	private static final Logger LOGGER = LogManager.getLogger(LoginServiceImpl.class.getName());
	private static final String STATUS = "status";

	WGSResModel response;

	MappingJacksonValue mappingJacksonValue;
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public LoginServiceImpl() {
		super();
		response = new WGSResModel();
	}

	@Override
	public ResponseEntity<Object> azureSsoLogin(LoginModel loginModel) {
		UserInformationDTO userInformation = null;
		try {
			String sqlUserInfo = "select UI.LoginName, UI.UserID, UI.FirstName, UI.LastName, UI.EmailAddress from UserInformation UI where UI.EmailAddress = ?";
			userInformation = jdbcTemplate.queryForObject(sqlUserInfo,
					BeanPropertyRowMapper.newInstance(UserInformationDTO.class), loginModel.getEmailId());

			String sql = "SELECT a.FormID FROM Actions a WHERE ActionType = '"+ WGSConstants.PREPARE_WGS_ACTION_TYPE+"'";
			Integer formId = jdbcTemplate.queryForObject(sql, Integer.class);
			if (formId > 0) {
				userInformation.setFormId(formId);
			}
			if (userInformation != null) {
				response.setStatus(true);
				response.setUserInformation(userInformation);
				mappingJacksonValue = FilterUtil.responseFilter(response, new String[] { STATUS, "userInformation" });
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
			} else {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(new Date(), "Data Not Found", "User not found"));
				mappingJacksonValue = FilterUtil.responseFilter(response, new String[] { "information", STATUS });
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.UNAUTHORIZED);
			}

		} catch (Exception e) {
			LOGGER.error("Error :%s", e.getMessage());
			if(userInformation == null) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(new Date(), "Data Not Found", "User not found"));
				mappingJacksonValue = FilterUtil.responseFilter(response, new String[] { "information", STATUS });
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.UNAUTHORIZED);
			}
			response.setStatus(false);
			response.setInformation(new ExceptionBean(new Date(), "Error", "Unable to login. Please contact the administrator."));
			mappingJacksonValue = FilterUtil.responseFilter(response, new String[] { "information", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
		}
	}
}
