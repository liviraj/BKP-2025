package com.histo.wgs.service.impl;

import com.histo.wgs.model.*;
import com.histo.wgs.service.FileDataOrganizerService;
import com.histo.wgs.util.FilterUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class FileDataOrganizerServiceImpl implements FileDataOrganizerService {
    private static final Logger LOGGER = LogManager.getLogger(FileDataOrganizerServiceImpl.class.getName());
    private static final String STATUS = "status";
    @Autowired
    JdbcTemplate histoSJdbcTemplate;

    FileDataOrganizerResponseModel response;

    MappingJacksonValue mappingJacksonValue;

    public FileDataOrganizerServiceImpl() {
        super();
        response = new FileDataOrganizerResponseModel();
    }

    @Override
    public ResponseEntity<Object> updateRawDataTransferStatus(RawDataTransferModel rawDataTransfer) {
        try {
            String query = "update WGSStatusViewer set LocalTransferID=? where WGSStatusViewerID=?;";
            histoSJdbcTemplate.update(query
                    , new Object[]{
                            rawDataTransfer.getStatus()
                            , rawDataTransfer.getWgsStatusViewerId()
                    }
            );
            return successResponse("Success");
        } catch (Exception e) {
            return catchException(e, "updateRawDataTransferStatus()", "Failed", "Failed to update", HttpStatus.CONFLICT);
        }
    }

    private ResponseEntity<Object> catchException(Exception e, String methodName, String message, String discription, HttpStatus httpStatus) {
        LOGGER.error("{} Error: {}", methodName, e);
        response.setStatus(false);
        response.setInformation(new InfoModel(new Date(), message, discription));
        mappingJacksonValue = FilterUtil.responseFilterForFileDataOrganizer(response, new String[]{STATUS, "information"});
        return new ResponseEntity<>(mappingJacksonValue, httpStatus);
    }

    private ResponseEntity<Object> successResponse(Object responseData) {
        response.setStatus(true);
        response.setData(responseData);
        mappingJacksonValue = FilterUtil.responseFilterForFileDataOrganizer(response, new String[]{STATUS, "data"});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }
}
