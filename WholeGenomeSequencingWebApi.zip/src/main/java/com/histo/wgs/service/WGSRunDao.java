package com.histo.wgs.service;

import com.histo.wgs.model.WGSResModel;
import com.histo.wgs.model.*;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;

public interface WGSRunDao {
   // public List<WGSRunMaster> returnWGSRunDetailsData();
   // public WGSRunDetailsShellScriptList returnWGSRunDetailsDataToShellScript();
    public String updateWGSRunStatusFromSMRTPortal(List<WGSRunStatusUpdateFromSMRT> wGSRunStatusUpdateFromSMRT);
    public void wgsRunForceRestartSMRT(WGSRunStatusUpdateFromSMRT wgsRunForceRestartSMRT);
    public String updateWGSRunStatusFromShellScript(WGSRunStatusUpdateShellScript dataFromShellScript);
    public WGSRoot rerunWGSRunData(String programType);
    public void validateAccessToken(Map<String, String> attributesData,int wgsStatusViewerId);
    public String updateWGSGlobusTransferStatus(WgsClientTransferStatus statusData);
    public void callFileMover(int wgsStatusViewerId, Map<String, String> attributesData);
    // public void uploadPDFFileToDestinationPath(int wgsStatusviewerId,HashMap<String, String> attributesData);
    public Map<String , String> getAttributesValues(int wgsStatusViewerId);
    public boolean updateLocalTransferStatus(LocalTransferIdStatus status);
//    public void callLocalTransferStatusAndFileUploader(LocalTransferIdStatus statusData, HashMap<String, String> attributesData);
    public String wgsFileTransferStatusMail(WGSFileTransferStatusMailInput input);
    public String sendMailForFileSizeFailed(WGSFileSizeFromSMRT input);
    public Integer getWGSRunTypeForWGSStatusViewerId(int wgsStatusViewerId);


    // WGS Automation
    public List<WGSResModel> listOfCloudJobs();
    public WGSResModel wGSStatusViewerDetailsByRunName(String wGSRunName);
    public String updateWGSCloudRunDetails(CloudRunDetail runDetail);
    public void wgsAutomationRun(SMRTInputArgs inputArgs);
    public String wGSUpdateCloudFileTransferStatus(CloudFileTransferStatus status);
    public String updateWGSCloudFileRunStatusFromShellScript(WGSUpdateCloudFileTransferStatusShellScript dataFromShellScript);
    public String wgsFileTransferStatusMail(int wgsStausViewerID, String type, int result, String path);
    public ResponseEntity<Object> insertLogDetail(LogDetailModel logDetail);

    public ResponseEntity<Object> saveMd5ChecksumDetails(Map<String,String> checksumDetails, Integer wgsRunId);
    public ResponseEntity<Object> executeMd5Checksum(LocalTransferIdStatus statusData);

    public void updateLTSDetails(LocalTransferIdStatus data);
    public String insertWGSLogInfo(int wgsRunID, int wgStatusViewerID, String log, String programName);

    List<WGSRestartLocalCopyProcessInput> getListOfRestartRunForLocalCopyProcess();

    public WGSRestartLocalCopyProcessInput getFailedRunInputForLocalCopy(int wgsStatusViewerId);
    public void localCopyProcess(String sourcePath, String destPath, int wgsRunId, int wgsStatusViewerId,
                                 boolean isDS03);
    public String getRestartProgramNameByProgramId(int programId);

    ResponseEntity deleteWgsRSData(LocalTransferIdStatus localTransferData);
}
