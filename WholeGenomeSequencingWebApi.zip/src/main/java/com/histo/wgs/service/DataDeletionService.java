package com.histo.wgs.service;


import com.histo.wgs.model.DataDeletionModel;

public interface DataDeletionService {
    void deleteData(DataDeletionModel dataDeletionModel);
}
