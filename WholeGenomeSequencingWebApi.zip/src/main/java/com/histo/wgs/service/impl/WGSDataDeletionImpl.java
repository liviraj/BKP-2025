package com.histo.wgs.service.impl;

import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.fileinformation.FileAllInformation;
import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.common.SmbPath;
import com.hierynomus.smbj.share.DiskShare;
import com.hierynomus.smbj.share.File;
import com.histo.wgs.config.DiskShareConfig;
import com.histo.wgs.config.PropertyConfiguration;
import com.histo.wgs.model.DataDeletionModel;
import com.histo.wgs.service.DataDeletionService;
import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Service
public class WGSDataDeletionImpl implements DataDeletionService {
    private static WGSDataDeletionImpl instance;
    private static final Logger logger = LoggerFactory.getLogger(WGSDataDeletionImpl.class);
    private final PropertyConfiguration propertyConfig;

    public WGSDataDeletionImpl(PropertyConfiguration propertyConfig) {
        this.propertyConfig = propertyConfig;
    }


    @Override
    public void deleteData(DataDeletionModel dataDeletionModel) {
        logger.info("Starting WGS data deletion...");
        DiskShare sourceDiskShare = new DiskShareConfig(dataDeletionModel.getSourceSMBUsername()
                , dataDeletionModel.getSourceSMBPassword()
                , propertyConfig.getDeletionSmbDomain()
                , dataDeletionModel.getSourceSMBServerName()
                , dataDeletionModel.getSourceSMBShareName()).getDiskShare();

        DiskShare destDiskShare = new DiskShareConfig(dataDeletionModel.getDesSmbUsername()
                , dataDeletionModel.getDesSmbPassword()
                , propertyConfig.getDeletionSmbDomain()
                , dataDeletionModel.getDesSmbServerName()
                , dataDeletionModel.getDesSmbShareName()).getDiskShare();

        if (sourceDiskShare == null || destDiskShare == null) {
            logger.error("Source share or destination share connection is null");
            return;
        }

        SmbPath sourceSmbPath = sourceDiskShare.getSmbPath();
        String sourceParentPath = sourceSmbPath.toUncPath().concat("\\").concat(dataDeletionModel.getSourcePath());
        sourceParentPath = sourceParentPath.replace("/", "\\");

        if (!dataDeletionModel.getSourcePath().endsWith("/")) {
            dataDeletionModel.setSourcePath(dataDeletionModel.getSourcePath().concat("/"));
        }

        boolean isSourceFolderExist = sourceDiskShare.folderExists(dataDeletionModel.getSourcePath().replace("\\", "/"));
        if (!isSourceFolderExist) {
            logger.error("Failed: Invalid Source Folder -> {}", sourceParentPath);
            return;
        }

        FileAllInformation sourceFileInformation = sourceDiskShare.getFileInformation(dataDeletionModel.getSourcePath().replace("\\", "/"));
        boolean isSourceDirectory = sourceFileInformation.getStandardInformation().isDirectory();
        if (!isSourceDirectory) {
            logger.info("Failed: Its a file not a directory : {}", sourceParentPath);
            return;
        }

        // Remove file in main directory
        List<FileIdBothDirectoryInformation> sourceDirectoryInformationList = sourceDiskShare.list(dataDeletionModel.getSourcePath());
        sourceDirectoryInformationList.removeIf(directoryInformation -> directoryInformation.getFileName().equals(".") || directoryInformation.getFileName().equals(".."));
        sourceDirectoryInformationList.removeIf(file -> sourceDiskShare
                .fileExists(dataDeletionModel.getSourcePath()
                        .concat(file.getFileName())));

        List<List<String>> sourceFileList = new ArrayList<>();
        for (FileIdBothDirectoryInformation directoryInfo : sourceDirectoryInformationList) {
            String sourcePath = dataDeletionModel.getSourcePath().concat(directoryInfo.getFileName()).concat("/");

            // copy file/folder source to destination
            List<String> fullSourceFileList = getFullSourceFileList(sourcePath, sourceDiskShare);
            sourceFileList.add(fullSourceFileList);
        }

        for (List<String> sourceFilePaths : sourceFileList) {
            String[] sourcePathSplit = sourceFilePaths.get(0).split("/");
            String sampleFolderName = sourcePathSplit[sourcePathSplit.length - 2];
            String desChecksumFilePath = dataDeletionModel.getDesPath().concat(sampleFolderName).concat("/").concat("md5checksum.txt");
            Map<String, String> fileAndChecksumList = new HashMap<>();
            try (File file = destDiskShare.openFile(desChecksumFilePath, EnumSet.of(AccessMask.GENERIC_READ),
                    null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null);
                 BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.contains("Filename") || line.contains("Checksum")) {
                        continue;
                    }
                    fileAndChecksumList.put(line.split("\t")[1], line.split("\t")[0]);
                }
            } catch (IOException e) {
                logger.error("Error reading file content from {}", desChecksumFilePath, e);
            }
            for (String sourceFilePath : sourceFilePaths) {
                try (File source = sourceDiskShare.openFile(sourceFilePath, EnumSet.of(AccessMask.GENERIC_READ),
                        null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null)) {
                    InputStream inputStream = new BufferedInputStream(source.getInputStream());
                    String sourceMd5Checksum = calculateMd5Checksum(inputStream);

                    String[] splitSource = sourceFilePath.split("/");
                    String desMd5Checksum = fileAndChecksumList.get(splitSource[splitSource.length - 1]);
                    // Delete file if source and destination checksums are same
                    if (sourceMd5Checksum.equals(desMd5Checksum)) {
                        deleteFile(sourceFilePath, sourceDiskShare);
                    }
                } catch (Exception e) {
                    logger.error("smbFileToChecksum() method: {}", e);
                }
            }
        }

        boolean isAllSampleFolderEmpty = false;
        for (List<String> sourceFilePaths : sourceFileList) {
            String[] sourcePathSplit = sourceFilePaths.get(0).split("/");
            String sampleFolderName = sourcePathSplit[sourcePathSplit.length - 2];
            String sourceMainPath = dataDeletionModel.getSourcePath().concat(sampleFolderName).concat("/");

            isAllSampleFolderEmpty = isFolderEmpty(sourceDiskShare, sourceMainPath);
            if (!isAllSampleFolderEmpty) {
                break;
            }
        }

        if (isAllSampleFolderEmpty) {
            deleteFolder(sourceDiskShare, dataDeletionModel.getSourcePath());
        }
        logger.info("WGS data deletion completed successfully.");
    }

    private boolean isFolderEmpty(DiskShare diskShare, String folderPath) {
        try {
            List<FileIdBothDirectoryInformation> fileList = diskShare.list(folderPath);
            return fileList.stream()
                    .filter(file -> !file.getFileName().equals(".") && !file.getFileName().equals(".."))
                    .count() == 0;
        } catch (Exception e) {
            logger.error("Error checking if folder is empty: {}", folderPath, e);
        }
        return false;
    }

    private String calculateMd5Checksum(InputStream inputStream) throws IOException {
        return DigestUtils.md5Hex(inputStream);
    }

    private void deleteFile(String filePath, DiskShare diskShare) {
        try {
            if (diskShare.fileExists(filePath)) {
                diskShare.rm(filePath);
                logger.info("File deleted successfully: {}", filePath);
            } else {
                logger.warn("File not found: {}", filePath);
            }
        } catch (Exception e) {
            logger.error("Error deleting file: {}", filePath, e);
        }
    }

    public void deleteFolder(DiskShare diskShare, String folderPath) {
        try {
            if (diskShare.folderExists(folderPath)) {
                diskShare.rmdir(folderPath, true); // true to delete recursively
                logger.info("Folder deleted successfully: {}", folderPath);
            } else {
                logger.warn("Folder does not exist: {}", folderPath);
            }
        } catch (Exception e) {
            logger.error("Error deleting folder: {}", folderPath, e);
        }
    }

    private List<String> getFullSourceFileList(String sourcePath, DiskShare sourceShare) {
        List<String> sourceFileList = new ArrayList<>();
        sourcePath = formatPath(sourcePath, sourceShare);

        if (sourceShare.getFileInformation(sourcePath).getStandardInformation().isDirectory()) {
            List<FileIdBothDirectoryInformation> fileList = sourceShare.list(sourcePath + "/");
            fileList.removeIf(file -> file.getFileName().equals(".") || file.getFileName().equals(".."));

            for (FileIdBothDirectoryInformation fileInfo : fileList) {
                String fileName = fileInfo.getFileName();
                if (fileName.equals(".") || fileName.equals("..")) {
                    continue;
                }

                String sourceFilePath;
                if (sourceShare.fileExists(sourcePath.concat(fileName))) {
                    sourceFilePath = sourcePath + fileName;
                } else {
                    sourceFilePath = sourcePath + fileName + "/";
                    fileName += "/"; // Adding '/' in directory
                }


                if (fileName.endsWith("/") || fileName.endsWith("\\")) {
                    // It is a directory
                    getFullSourceFileList(sourceFilePath, sourceShare);
                } else {
                    // It is a file
                    sourceFileList.add(sourceFilePath);
                }
            }
        } else {
            // It is a file
            sourceFileList.add(sourcePath);
        }
        return sourceFileList;
    }

    private String formatPath(String path, DiskShare share) {
        return path.replace(share.getSmbPath().toUncPath(), "").replace("\\", "/");
    }
}