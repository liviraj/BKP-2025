package com.histo.wgs.service.impl;

import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.share.DiskShare;
import com.histo.wgs.config.DiskShareConfig;
import com.histo.wgs.config.PropertyConfiguration;
import com.histo.wgs.entity.WGSRunMaster;
import com.histo.wgs.entity.WGSStatusViewer;
import com.histo.wgs.entity.*;
import com.histo.wgs.exception.ExceptionBean;
import com.histo.wgs.model.*;
import com.histo.wgs.repository.*;
import com.histo.wgs.service.WgsRunsService;
import com.histo.wgs.util.FilterUtil;
import com.histo.wgs.util.WGSConstants;
import com.histo.wgs.util.WGSUtil;
import jakarta.transaction.Transactional;
import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbException;
import jcifs.smb.SmbFile;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.math.BigInteger;
import java.net.MalformedURLException;
import java.sql.ResultSet;
import java.util.*;
import java.util.stream.Collectors;

import static com.histo.wgs.model.BarCodeTypeEnum.ASYMMETRIC;
import static com.histo.wgs.model.BarCodeTypeEnum.SYMMETRIC;

@Service
@Transactional
public class WgsRunsServiceImpl implements WgsRunsService {

    private static final Logger LOGGER = LogManager.getLogger(WgsRunsServiceImpl.class);
    private static final String STATUS = "status";
    private static final String DROP_DWON = "dropdown";
    private static Integer WGS_REPORT_TO_CLIENT_UNIQUE_ID;
    private static Integer USER_ID;
    private static List<WGSClientReportDTO> WGS_CLIENT_REPORTS;

    WGSResModel response;

    MappingJacksonValue mappingJacksonValue;

    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    public JdbcTemplate jdbcTemplate;
    @Autowired
    private PropertyConfiguration propertyConfiguration;
    @Autowired
    private WGSDataTypeMasterRepository wGSDataTypeMasterRepository;
    @Autowired
    private WGSAnalysisApplicationMasterRepository wgsAnalysisApplicationMasterRepository;
    @Autowired
    private WGSWorkFlowTypeRepository wgsWorkFlowTypeRepository;
    @Autowired
    private WGSDefaultAdvancedPropertyRepository wGSDefaultAdvancedPropertyRepository;
    @Autowired
    private WgsDefaultAdvancedPropertyDropdownRepository wgsDefaultAdvancedPropertyDropdownRepository;
    @Autowired
    private WGSRunMasterRepository wgsRunMasterRepository;
    @Autowired
    private WGSAdvancedPropertyRepository wgsAdvancedPropertyRepository;
    @Autowired
    private WgsAssociatedInputRepository wgsAssociatedInputRepository;
    @Autowired
    private WgsAssociatedInputsMasterRepository wgsAssociatedInputsMasterRepository;
    @Autowired
    private WgsBarcodeSampleSetRepository wgsBarcodeSampleSetRepository;
    @Autowired
    private WGSStatusViewerRepository wgsStatusViewerRepository;
    @Autowired
    private SamplesRepository samplesRepository;
    @Autowired
    private PooledSubSampleRepository pooledSubSampleRepository;
    @Autowired
    private WgsRunDetailRepository wgsRunDetailRepository;
    @Autowired
    private WGSEmailConfigRepository wgsEmailConfigRepository;

    public WgsRunsServiceImpl() {
        super();
        response = new WGSResModel();
    }

    @Override
    public ResponseEntity<Object> findAllWgsRuns(WgsRunFilterDto wgsRunFilter) {
        try {
            List<WgsRunsViewDto> wgsRunsList = jdbcTemplate.query("exec GetWholeGenomeSequence ?,?,?,?,?,?,?,?,?,?,?,?;", BeanPropertyRowMapper.newInstance(WgsRunsViewDto.class), new Object[]{wgsRunFilter.getClientProjectId(), "R", "E", "", false, wgsRunFilter.getStartDate(), wgsRunFilter.getEndDate(), wgsRunFilter.getRunStatusId(), wgsRunFilter.getTransferStatusId(), wgsRunFilter.getAnalysisStatusId(), wgsRunFilter.getLocalTransferId(), ""});
            if (wgsRunsList.size() > 0) {
                wgsRunsList.forEach(wgsRun -> {
                    if (StringUtils.isNotBlank(wgsRun.getFileName())) {
                        String[] split = wgsRun.getFileName().split("\\\\");
                        wgsRun.setFileName(split[split.length - 1]);
                    }

                    if (wgsRun.getClientTransferCompletedTime().toString().contains("1900-01-01")) {
                        wgsRun.setClientTransferCompletedTime(null);
                    }
                    if (wgsRun.getLocalTransferCompletedTime().toString().contains(("1900-01-01"))) {
                        wgsRun.setLocalTransferCompletedTime(null);
                    }

                    // pooled samples fetch
                    if (wgsRun.isIsPooledSample()) {
                        List<WgsSampleId> wgsSampleIds = new ArrayList<>();
                        String[] splitSamples = wgsRun.getSampleID().split(",");
                        for (String splitSample : splitSamples) {
                            Samples sample = samplesRepository.findByClientSampleId(splitSample);
                            if (sample == null) {
                                continue;
                            }
                            List<PooledSubSample> pooledSamples = pooledSubSampleRepository.findBySampleId(sample.getSampleId());
                            if (pooledSamples.size() == 0) {
                                continue;
                            }
                            WgsSampleId wgsSampleId = new WgsSampleId();
                            wgsSampleId.setPooledSample(true);
                            wgsSampleId.setSampleId(splitSample);
                            String[] sampleStrings = pooledSamples.stream().map(PooledSubSample::getSubSampleId).collect(Collectors.toList()).toArray(new String[0]);
                            wgsSampleId.setPooledSamples(sampleStrings);
                            wgsSampleIds.add(wgsSampleId);
                        }
                        wgsRun.setWgsSampleIds(wgsSampleIds);
                    }
                });

                response.setStatus(true);
                response.setWgsRunsList(wgsRunsList);
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "wgsRunsList"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            } else {
                response.setStatus(false);
                response.setInformation(new ExceptionBean(new Date(), "Data Not Found", "Wgs run not Found"));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"information", STATUS});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }
        } catch (Exception e) {
            LOGGER.error("findAllWgsRuns() Error :  {}", e);
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "Error", "Could not fetch run information."));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"information", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
        }
    }

    @Override
    public ResponseEntity<Object> createWgsRuns(List<WGSRunCreateDto> wgsRunCreateDtos) {
        ResponseEntity<Object> createRunResponse = null;
        try {
            for (WGSRunCreateDto wgsRunCreateDto : wgsRunCreateDtos) {
                createRunResponse = createSingleWgsRun(wgsRunCreateDto);
                if (!createRunResponse.getStatusCode().is2xxSuccessful()) {
                    return createRunResponse;
                }
            }
            return createRunResponse;
        } catch (Exception e) {
            return catchException("createWgsRuns()", e, "Run Creation Failed", "Could not create run. Please try again.");
        }
    }

    private ResponseEntity<Object> createSingleWgsRun(WGSRunCreateDto wgsRunCreateDto) {
        if (wgsRunCreateDto.getCCSQualityFilter() == 20 || wgsRunCreateDto.getCCSQualityFilter() == 20.0) {
            wgsRunCreateDto.setCCSQualityFilter((float) 0.99);
        }
        if (wgsRunCreateDto.isDemultiplexingRequired() && !wgsRunCreateDto.isOnBoard()) {
            Optional<WGSAnalysisApplicationMaster> demuxAnalysisApp = wgsAnalysisApplicationMasterRepository.findByAnalysisApplicationValue(
                    WGSConstants.DEMULTIPLEX_BARCODES_APP_VALUE);
            Optional<WgsAssociatedInputsMasterDTO> associateInput = wgsRunCreateDto.getAdvancedPropertiesRoot()
                    .stream().filter(property -> property.getAnalysisApplicationID() == demuxAnalysisApp.get().getId())
                    .findFirst().get()
                    .getAssociatedInputs().stream().filter(
                            input
                                    -> input.getPropertyValue().equalsIgnoreCase("lima_symmetric_barcodes"))
                    .findFirst();
            if (associateInput.isPresent()) {
                if (associateInput.get().getValue().equalsIgnoreCase("1") || associateInput.get().getValue().equalsIgnoreCase("yes")) {
                    wgsRunCreateDto.setBarcodeType(SYMMETRIC.getValue());
                } else {
                    wgsRunCreateDto.setBarcodeType(ASYMMETRIC.getValue());
                }
            }
        }
        Integer wgsRunId = jdbcTemplate.queryForObject("exec InsertWholeGenomeSequence_ForJava ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?;"
                , Integer.class, wgsRunCreateDto.getSampleId()
                , wgsRunCreateDto.getRunName()
                , "C"
                , wgsRunCreateDto.getClientProjectID()
                , 0
                , wgsRunCreateDto.isOnBoard()
                , wgsRunCreateDto.isNeedHifi()
                , wgsRunCreateDto.getCCSQualityFilter()
                , wgsRunCreateDto.getNumberofPasses()
                , wgsRunCreateDto.isDemultiplexingRequired()
                , wgsRunCreateDto.getFilename()
                , wgsRunCreateDto.getBarcodeType()
                , wgsRunCreateDto.getQualityFilter()
                , wgsRunCreateDto.getSourceFilepathWithFilename()
                , wgsRunCreateDto.getCreatedBy()
                , wgsRunCreateDto.getDataRequirementId());
        if (wgsRunId > 0) {
            if (wgsRunCreateDto.isPooledSample()) {
                WgsRunDetail runDetails = wgsRunDetailRepository.findByWgsRunId(wgsRunId);
                runDetails.setPooledSample(true);
                wgsRunDetailRepository.save(runDetails);
            }
            if (!wgsRunCreateDto.isOnBoard()) { // advanced property is not applicable for isObBoard is true
                ResponseEntity<Object> advancedPropertyRes = saveAdvancedProperties(wgsRunCreateDto.getAdvancedPropertiesRoot(), wgsRunId);
                if (!advancedPropertyRes.getStatusCode().is2xxSuccessful()) {
                    return advancedPropertyRes;
                }
            }

            String dbResponse = jdbcTemplate.queryForObject("exec WGSRunCreationMail ?;", String.class, wgsRunId);

            response.setStatus(true);
            response.setResMessage("Submitted Successfully");
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "resMessage"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } else {
            LOGGER.debug("Run create failed. Run Details:" + wgsRunCreateDto.toString());
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "Run creation Failed", "Could not create WGS run"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"information", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
        }
    }

    private ResponseEntity<Object> saveAdvancedProperties(List<WGSAdvancedPropertyDTO> advancedProperties, Integer wgsRunId) {
        try {
            for (WGSAdvancedPropertyDTO advancedProperty : advancedProperties) {
                Optional<WGSRunMaster> wgsRunMaster = wgsRunMasterRepository.findById(wgsRunId);
                Optional<WGSWorkFlowType> workFlowType = wgsWorkFlowTypeRepository.findById(advancedProperty.getWorkFlowTypeID());
                Optional<WGSAnalysisApplicationMaster> analysisApplicationMaster = wgsAnalysisApplicationMasterRepository.findById(advancedProperty.getAnalysisApplicationID());
                if (!wgsRunMaster.isPresent()) {
                    return responseFalseValidation("Invalid WGSRunID");
                } else if (!workFlowType.isPresent()) {
                    return responseFalseValidation("Invalid WorkFlowTypeID");
                } else if (!analysisApplicationMaster.isPresent()) {
                    return responseFalseValidation("Invalid AnalysisApplicationID");
                }

                if (advancedProperty.getDataTypeID() == null || advancedProperty.getDataTypeID() == 0) {
                    advancedProperty.setDataTypeID(-1);
                } else {
                    Optional<WGSDataTypeMaster> dataTypeMaster = wGSDataTypeMasterRepository.findById(advancedProperty.getDataTypeID());
                    if (!dataTypeMaster.isPresent()) {
                        return responseFalseValidation("Invalid DataTypeID");
                    }
                }

                for (AdvancedProperty property : advancedProperty.getAdvancedProperties()) {
                    Optional<WGSDefaultAdvancedProperty> defaultAdvancedProperty = wGSDefaultAdvancedPropertyRepository.findById(property.getDefaultAdvancedPropertyID());
                    if (!defaultAdvancedProperty.isPresent()) {
                        return responseFalseValidation("Invalid DefaultAdvancedPropertyID");
                    }
                    if (property.getType().equals("string")) {
                        property.setValue(StringUtils.isBlank(property.getValue()) ? "" : property.getValue());
                    }
                    WGSAdvancedProperty wgsAdvancedProperty = new WGSAdvancedProperty();
                    wgsAdvancedProperty.setWgsRunID(wgsRunMaster.get());
                    wgsAdvancedProperty.setWorkFlowTypeID(workFlowType.get());
                    wgsAdvancedProperty.setDataTypeID(advancedProperty.getDataTypeID());
                    wgsAdvancedProperty.setAnalysisApplicationID(analysisApplicationMaster.get());
                    wgsAdvancedProperty.setValue(property.getValue());
                    wgsAdvancedProperty.setDefaultAdvancedPropertyID(defaultAdvancedProperty.get());
                    if (defaultAdvancedProperty.get().getType().equals(DROP_DWON)) {
                        wgsAdvancedProperty.setDropdownID(property.getDropdownID());
                    } else {
                        wgsAdvancedProperty.setDropdownID(0);
                    }

                    WGSAdvancedProperty saveAdvancedProperty = wgsAdvancedPropertyRepository.save(wgsAdvancedProperty);
                }
                if (advancedProperty.getAssociatedInputs() != null && advancedProperty.getAssociatedInputs().size() > 0) {
                    for (WgsAssociatedInputsMasterDTO associatedInput : advancedProperty.getAssociatedInputs()) {
                        Optional<WgsAssociatedInput> wgsAssociatedInput = wgsAssociatedInputRepository.findById(associatedInput.getAssociatedInputId());
                        WgsAssociatedInputsMaster associatedInputsMaster = new WgsAssociatedInputsMaster();
                        associatedInputsMaster.setAssociatedInput(wgsAssociatedInput.get());
                        associatedInputsMaster.setWgsRunId(wgsRunMaster.get());
                        associatedInputsMaster.setValue(associatedInput.getValue());
                        associatedInputsMaster.setUuid(associatedInput.getUuid());
                        associatedInputsMaster.setAnalysisApplicationID(analysisApplicationMaster.get());
                        wgsAssociatedInputsMasterRepository.save(associatedInputsMaster);
                    }
                }

                if (advancedProperty.getBarcodeSampleSets() != null && advancedProperty.getBarcodeSampleSets().size() > 0) {
                    for (WgsBarcodeSampleSetDTO barcodeSampleSetDTO : advancedProperty.getBarcodeSampleSets()) {
                        WgsBarcodeSampleSet wgsBarcodeSampleSet = new WgsBarcodeSampleSet();
                        wgsBarcodeSampleSet.setBarcode(barcodeSampleSetDTO.getBarcode());
                        wgsBarcodeSampleSet.setBioSample(barcodeSampleSetDTO.getBioSample());
                        wgsBarcodeSampleSet.setWgsRunId(wgsRunMaster.get());
                        wgsBarcodeSampleSetRepository.save(wgsBarcodeSampleSet);
                    }
                }
            }
            response.setStatus(true);
            response.setInformation(new ExceptionBean(new Date(), "Created successfully", "Advanced property data created successfully"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException("saveAdvancedProperties()", e, "Creation Failed", "Failed to create advanced properties");
        }
    }

    private void smbFileCopy(String source, String destination, NtlmPasswordAuthentication auth) throws MalformedURLException, SmbException {
        SmbFile smbDir = new SmbFile(source, auth);
        SmbFile smbDest = new SmbFile(destination, auth);
        if (smbDir.canRead() && smbDir.canWrite()) {
            smbDest.createNewFile();
            smbDir.copyTo(smbDest);
        } else {
            throw new RuntimeException("Permission denied.");
        }
    }

    private void smbDeleteFile(String filePth, NtlmPasswordAuthentication auth) throws MalformedURLException, SmbException {
        SmbFile smbFile = new SmbFile(filePth, auth);
        smbFile.delete();
    }

    private NtlmPasswordAuthentication getSmbAuth(String domain, String username, String password) {
        NtlmPasswordAuthentication auth = null;
        try {
            auth = new NtlmPasswordAuthentication(domain, username, password);
        } catch (Exception e) {
            LOGGER.error("WgsRunsServiceImpl.getSmbAuth(). Error: {}", e);
        }
        return auth;
    }

    @Override
    public ResponseEntity<Object> updateWgsRuns(List<WGSRunUpdateDto> wgsRunUpdateDtos) {
        ResponseEntity<Object> updateRespone = null;
        try {
            for (WGSRunUpdateDto wgsRunUpdateDto : wgsRunUpdateDtos) {
                if (wgsRunUpdateDto.getWgsRunID() > 0) { // update wgs run
                    updateRespone = updateSingleWgsRuns(wgsRunUpdateDto);
                    if (!updateRespone.getStatusCode().is2xxSuccessful()) {
                        return updateRespone;
                    }
                } else { // create wgs run
                    WGSRunCreateDto wgsRunCreateDto = new WGSRunCreateDto();
                    wgsRunCreateDto.setCreatedBy(wgsRunUpdateDto.getCreatedBy());
                    wgsRunCreateDto.setRunName(wgsRunUpdateDto.getRunName());
                    wgsRunCreateDto.setFilename(wgsRunUpdateDto.getFilename());
                    wgsRunCreateDto.setCCSQualityFilter(wgsRunUpdateDto.getCCSQualityFilter());
                    wgsRunCreateDto.setSourceFilepathWithFilename(wgsRunUpdateDto.getSourceFilepathWithFilename());
                    wgsRunCreateDto.setBarcodeType(wgsRunUpdateDto.getBarcodeType());
                    wgsRunCreateDto.setClientProjectID(wgsRunUpdateDto.getClientProjectID());
                    wgsRunCreateDto.setDataRequirementId(wgsRunUpdateDto.getDataRequirementId());
                    wgsRunCreateDto.setDemultiplexingRequired(wgsRunUpdateDto.isDemultiplexingRequired());
                    wgsRunCreateDto.setNeedHifi(wgsRunUpdateDto.isNeedHifi());
                    wgsRunCreateDto.setNumberofPasses(wgsRunUpdateDto.getNumberofPasses());
                    wgsRunCreateDto.setOnBoard(wgsRunUpdateDto.isOnBoard());
                    wgsRunCreateDto.setOverWrite(wgsRunUpdateDto.isOverWrite());
                    wgsRunCreateDto.setQualityFilter(wgsRunUpdateDto.getQualityFilter());
                    wgsRunCreateDto.setSampleId(wgsRunUpdateDto.getSampleId());
                    wgsRunCreateDto.setAdvancedPropertiesRoot(wgsRunUpdateDto.getAdvancedPropertiesRoot());

                    updateRespone = createSingleWgsRun(wgsRunCreateDto);
                    if (!updateRespone.getStatusCode().is2xxSuccessful()) {
                        return updateRespone;
                    }
                }
            }
            return updateRespone;
        } catch (Exception e) {
            return catchException("updateWgsRuns()", e, "Run Update Failed", "Could not update run. Please try again.");
        }
    }

    private ResponseEntity<Object> updateSingleWgsRuns(WGSRunUpdateDto wgsRunUpdateDto) {
        if (wgsRunUpdateDto.getCCSQualityFilter() == 20 || wgsRunUpdateDto.getCCSQualityFilter() == 20.0) {
            wgsRunUpdateDto.setCCSQualityFilter((float) 0.99);
        }

        if (wgsRunUpdateDto.isDemultiplexingRequired() && !wgsRunUpdateDto.isOnBoard()) { // advanced property is not applicable for isObBoard is true
            Optional<WGSAnalysisApplicationMaster> demuxAnalysisApp = wgsAnalysisApplicationMasterRepository.findByAnalysisApplicationValue(
                    WGSConstants.DEMULTIPLEX_BARCODES_APP_VALUE);

            /*Optional<WgsAssociatedInputsMasterDTO> associateInput = wgsRunUpdateDto.getAdvancedProperties().getAssociatedInputs().stream().filter(
                            input
                                    -> input.getPropertyValue().equalsIgnoreCase("lima_symmetric_barcodes"))
                    .findFirst();*/
            Optional<WgsAssociatedInputsMasterDTO> associateInput = wgsRunUpdateDto.getAdvancedPropertiesRoot()
                    .stream().filter(property -> property.getAnalysisApplicationID() == demuxAnalysisApp.get().getId())
                    .findFirst().get()
                    .getAssociatedInputs().stream().filter(
                            input
                                    -> input.getPropertyValue().equalsIgnoreCase("lima_symmetric_barcodes"))
                    .findFirst();
            if (associateInput.isPresent()) {
                if (associateInput.get().getValue().equalsIgnoreCase("1") || associateInput.get().getValue().equalsIgnoreCase("yes")) {
                    wgsRunUpdateDto.setBarcodeType(SYMMETRIC.getValue());
                } else {
                    wgsRunUpdateDto.setBarcodeType(ASYMMETRIC.getValue());
                }
            }
        }

        String message = jdbcTemplate.queryForObject("exec UpdateWholeGenomeSequence_ForJava ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?;"
                , String.class
                , wgsRunUpdateDto.getSampleId(), wgsRunUpdateDto.getWgsRunID(), wgsRunUpdateDto.getRunName()
                , "E", wgsRunUpdateDto.getClientProjectID(), 0, wgsRunUpdateDto.isOnBoard()
                , wgsRunUpdateDto.isNeedHifi(), wgsRunUpdateDto.getCCSQualityFilter()
                , wgsRunUpdateDto.getNumberofPasses(), wgsRunUpdateDto.isDemultiplexingRequired()
                , wgsRunUpdateDto.getFilename(), wgsRunUpdateDto.getBarcodeType(), wgsRunUpdateDto.getQualityFilter()
                , wgsRunUpdateDto.getSourceFilepathWithFilename(), wgsRunUpdateDto.getCreatedBy(), wgsRunUpdateDto.getDataRequirementId());

        // Update is Sample pooled sample or not
        WgsRunDetail runDetails = wgsRunDetailRepository.findByWgsRunId(wgsRunUpdateDto.getWgsRunID());
        runDetails.setPooledSample(wgsRunUpdateDto.isPooledSample());
        wgsRunDetailRepository.save(runDetails);

        if (StringUtils.isNotBlank(message) && message.equals("Updated Successfully")) {
            if (wgsRunUpdateDto.isOnBoard()) {
                Optional<WGSRunMaster> wgsRunById = wgsRunMasterRepository.findById(wgsRunUpdateDto.getWgsRunID());
                // Delete advance property, associated input and Barcodes if exists for on-board is true
                List<WGSAdvancedProperty> advancePropertyByWgsRunID = wgsAdvancedPropertyRepository.findByWgsRunID(wgsRunById.get());
                List<WgsAssociatedInputsMaster> associatedInputsByWgsRunId = wgsAssociatedInputsMasterRepository.findByWgsRunId(wgsRunById.get());
                List<WgsBarcodeSampleSet> barcodeSetByWgsRunId = wgsBarcodeSampleSetRepository.findByWgsRunId(wgsRunById.get());
                if (advancePropertyByWgsRunID.size() > 0) {
                    wgsAdvancedPropertyRepository.deleteByWgsRunID(wgsRunById.get());
                }
                if (associatedInputsByWgsRunId.size() > 0) {
                    wgsAssociatedInputsMasterRepository.deleteByWgsRunId(wgsRunById.get());
                }
                if (barcodeSetByWgsRunId.size() > 0) {
                    wgsBarcodeSampleSetRepository.deleteByWgsRunId(wgsRunById.get());
                }
            } else { // update is not applicable for on-board is false
                ResponseEntity<Object> updateAdvancedPropertiesRes = updateAdvancedProperties(wgsRunUpdateDto.getAdvancedPropertiesRoot(), wgsRunUpdateDto.getWgsRunID());
                if (!updateAdvancedPropertiesRes.getStatusCode().is2xxSuccessful()) {
                    return updateAdvancedPropertiesRes;
                }
            }
            response.setStatus(true);
            response.setInformation(new ExceptionBean(new Date(), message, "Wgs run update successfully"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } else {
            LOGGER.debug("Run update failed. Run Id:" + wgsRunUpdateDto.getWgsRunID());
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "Update Failed", "Wgs run not Found"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"information", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
    }

    private ResponseEntity<Object> updateAdvancedProperties(List<WGSAdvancedPropertyDTO> advancedPropertyDTOList, Integer wgsRunId) {
        try {
            for (WGSAdvancedPropertyDTO advancedPropertyDTO : advancedPropertyDTOList) {
                Optional<WGSAnalysisApplicationMaster> analysisApplication = wgsAnalysisApplicationMasterRepository.findById(advancedPropertyDTO.getAnalysisApplicationID());
                Optional<WGSAdvancedProperty> advancedProperty = wgsAdvancedPropertyRepository.findById(advancedPropertyDTO.getAdvancedProperties().get(0).getAdvancedPropertyId());
                Optional<WGSRunMaster> wgsRunById = wgsRunMasterRepository.findById(wgsRunId);
                if (!wgsRunById.isPresent()) {
                    return responseFalseValidation("Invalid WGSRunID");
                }
                // Checking have to update or create the advanced properties
                if (advancedProperty.isPresent() && analysisApplication.get().getId() == advancedProperty.get().getAnalysisApplicationID().getId()) {
                    for (AdvancedProperty property : advancedPropertyDTO.getAdvancedProperties()) {
                        Optional<WGSDefaultAdvancedProperty> defaultAdvancedProperty = wGSDefaultAdvancedPropertyRepository.findById(property.getDefaultAdvancedPropertyID());
                        if (!defaultAdvancedProperty.isPresent()) {
                            return responseFalseValidation("Invalid DefaultAdvancedPropertyID");
                        }
                        Optional<WGSAdvancedProperty> wgsAdvancedProperty = wgsAdvancedPropertyRepository.findById(property.getAdvancedPropertyId());
                        if (wgsAdvancedProperty.isPresent()) {
                            wgsAdvancedProperty.get().setValue(property.getValue());
                            if (defaultAdvancedProperty.get().getType().equals(DROP_DWON)) {
                                wgsAdvancedProperty.get().setDropdownID(property.getDropdownID());
                            } else {
                                wgsAdvancedProperty.get().setDropdownID(0);
                            }
                            WGSAdvancedProperty saveAdvancedProperty = wgsAdvancedPropertyRepository.save(wgsAdvancedProperty.get());
                        } else {
                            return responseFalseValidation("Invalid AdvancedPropertyID: " + property.getAdvancedPropertyId());
                        }
                    }
                    if (advancedPropertyDTO.getAssociatedInputs() != null && advancedPropertyDTO.getAssociatedInputs().size() > 0) {
                        for (WgsAssociatedInputsMasterDTO associatedInput : advancedPropertyDTO.getAssociatedInputs()) {
                            Optional<WgsAssociatedInputsMaster> wgsAssociatedInputsMaster = wgsAssociatedInputsMasterRepository.findById(associatedInput.getId());
                            if (!wgsAssociatedInputsMaster.isPresent()) {
                                return responseFalseValidation("Invalid AdvancedPropertyMasterId: " + associatedInput.getId());
                            }
                            wgsAssociatedInputsMaster.get().setValue(associatedInput.getValue());
                            wgsAssociatedInputsMaster.get().setUuid(associatedInput.getUuid());
                            wgsAssociatedInputsMasterRepository.save(wgsAssociatedInputsMaster.get());
                        }
                    }
                    if (advancedPropertyDTO.getBarcodeSampleSets() != null && advancedPropertyDTO.getBarcodeSampleSets().size() > 0) {
                        wgsBarcodeSampleSetRepository.deleteByWgsRunId(wgsRunById.get());
                        for (WgsBarcodeSampleSetDTO barcodeSampleSetDTO : advancedPropertyDTO.getBarcodeSampleSets()) {
                            WgsBarcodeSampleSet barcodeSampleSet = new WgsBarcodeSampleSet();
                            barcodeSampleSet.setBarcode(barcodeSampleSetDTO.getBarcode());
                            barcodeSampleSet.setBioSample(barcodeSampleSetDTO.getBioSample());
                            barcodeSampleSet.setWgsRunId(wgsRunById.get());
                            wgsBarcodeSampleSetRepository.save(barcodeSampleSet);
                        }
                    }
                } else {
                    // Before create new deleting existing property (advance property, associated input and Barcodes )
                    wgsAdvancedPropertyRepository.deleteByWgsRunID(wgsRunById.get());
                    wgsAssociatedInputsMasterRepository.deleteByWgsRunId(wgsRunById.get());
                    wgsBarcodeSampleSetRepository.deleteByWgsRunId(wgsRunById.get());
                    List<WGSAdvancedPropertyDTO> wgsAdvancedPropertyDTOS = Arrays.asList(advancedPropertyDTO);
                    return saveAdvancedProperties(wgsAdvancedPropertyDTOS, wgsRunId);
                }
            }
        } catch (Exception e) {
            return catchException("updateAdvancedProperties()", e, "Update Failed", "Failed to update advanced properties");
        }
        response.setStatus(true);
        response.setInformation(new ExceptionBean(new Date(), "Updated successfully", "Advanced property data updated successfully"));
        mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Object> wgsRunFindAllClients() {
        List<WgsRunClients> wgsRunClientList = jdbcTemplate.query("exec GetClientNameList;", BeanPropertyRowMapper.newInstance(WgsRunClients.class));
        if (!CollectionUtils.isEmpty(wgsRunClientList)) {
            response.setStatus(true);
            response.setWgsRunClientList(wgsRunClientList);
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "wgsRunClientList"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } else {
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "Data Not Found", "Client not Found"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
    }

    @Override
    public ResponseEntity<Object> wgsRunFindAllClientProjects() {
        List<WgsRunClientProjects> wgsRunClientProjectList = jdbcTemplate.query("exec GetAllClientProjects;", BeanPropertyRowMapper.newInstance(WgsRunClientProjects.class));

        return getObjectResponseEntity(wgsRunClientProjectList);
    }

    @Override
    public ResponseEntity<Object> wgsRunFindAllClientProjectsOnlyRunCreated() {
        String sql = "select distinct CP.ClientProjectID,CP.ClientProjectCode,CP.ClientProjectName from ClientProjects CP, WGSRunMaster RM where CP.ClientProjectID = RM.ClientProjectId;";
        List<WgsRunClientProjects> wgsRunClientProjectList = jdbcTemplate.query(sql, BeanPropertyRowMapper.newInstance(WgsRunClientProjects.class));

        return getObjectResponseEntity(wgsRunClientProjectList);
    }

    @NotNull
    private ResponseEntity<Object> getObjectResponseEntity(List<WgsRunClientProjects> wgsRunClientProjectList) {
        if (!CollectionUtils.isEmpty(wgsRunClientProjectList)) {

            response.setStatus(true);
            response.setWgsRunClientProjectList(wgsRunClientProjectList);
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "wgsRunClientProjectList"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } else {
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "Project Data Not Found", "ClientProject not Found"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"information", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
    }

    @Override
    public ResponseEntity<Object> findAllRunComments(int wGSRunId, int WGSStatusViewerID) {

        try {

            List<WgsRunCommands> wgsRunCommentsList = jdbcTemplate.query("exec GetRunComments ?,?;", new Object[]{wGSRunId, WGSStatusViewerID}, BeanPropertyRowMapper.newInstance(WgsRunCommands.class));
            if (!CollectionUtils.isEmpty(wgsRunCommentsList)) {

                response.setStatus(true);
                response.setWgsRunCommentsList(wgsRunCommentsList);
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "wgsRunCommentsList"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            } else {
                response.setStatus(false);
                response.setInformation(new ExceptionBean(new Date(), "RunComment Not Found", "Comments not Found"));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"information", STATUS});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }
        } catch (Exception e) {
            LOGGER.error("updateWgsRuns() method Error : {}", e);
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "Error", "Failed to get comments."));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"information", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
        }

    }

    @Override
    public ResponseEntity<Object> saveRunComments(WgsRunCommands wgsRunCommands) {
        String message = jdbcTemplate.queryForObject("exec InsertRunComments ?,?,?,?", String.class, new Object[]{wgsRunCommands.getwGSRunId(), wgsRunCommands.getComments(), wgsRunCommands.getCreatedBy(), wgsRunCommands.getwGSStatusViewerID()});
        if (StringUtils.isNotBlank(message)) {

            response.setStatus(true);
            response.setInformation(new ExceptionBean(new Date(), "Saved Successfully", "Wgs run Comments Saved successfully"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } else {
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "Unable to Save", "Wgs run comment not Found"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
    }

    @Override
    public ResponseEntity<Object> deleteRunCommandsById(int commentsId) {
        String message = jdbcTemplate.queryForObject("exec DeleteRunComments  ?", String.class, new Object[]{commentsId});
        if (StringUtils.isNotBlank(message) && message.equals("Deleted Successfully")) {
            response.setStatus(true);
            response.setInformation(new ExceptionBean(new Date(), "Deleted Successfully", "Wgs run Comment deleted successfully"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } else {
            LOGGER.debug("deleteRunCommandsById() info. Not found run comment. Comments Id:" + commentsId);
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "Unable to delete", "Wgs run comment not Found"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"information", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }

    }

    @Override
    public ResponseEntity<Object> findAllRunLogs(int wGSStatusViewerID, int wgsRunId) {
        try {

            List<WgsRunLogs> wgsRunLogsList = jdbcTemplate.query("exec GetWGSRunLog ?,? ;", BeanPropertyRowMapper.newInstance(WgsRunLogs.class), new Object[]{wGSStatusViewerID, wgsRunId});

            if (!CollectionUtils.isEmpty(wgsRunLogsList)) {
                response.setStatus(true);
                response.setWgsRunLogsList(wgsRunLogsList);
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "wgsRunLogsList"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            } else {
                response.setStatus(false);
                response.setInformation(new ExceptionBean(new Date(), "RunComment Not Found", "Comments not Found"));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"information", STATUS});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }
        } catch (Exception e) {
            LOGGER.error("findAllRunLogs() Error :  {}", e);
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "Error", "Failed to found logs"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"information", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
        }

    }

    @Override
    public ResponseEntity<Object> validateWgsRunPinNo(WgsRunPinNo wgsRunPinNo) {

        try {
            List<WgsRunPinNoInfo> wgsRunPinNoInfoList = jdbcTemplate.query("exec ValidateUserActionandGetUserInfoByIPin ?,?; "
                    , BeanPropertyRowMapper.newInstance(WgsRunPinNoInfo.class), new Object[]{wgsRunPinNo.getiPIN(), wgsRunPinNo.getFormID()});
            if (!CollectionUtils.isEmpty(wgsRunPinNoInfoList) && wgsRunPinNoInfoList.get(0).getUserID() > 0) {
                response.setStatus(true);
                response.setData(wgsRunPinNoInfoList.get(0));
                response.setInformation(new ExceptionBean(new Date(), "Valid Pin", "VALID IPIN! "));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information", "data"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            } else {
                String responseMsg = jdbcTemplate.queryForObject("exec ValidateUserActionandGetUserInfoByIPin ?,?; "
                        , String.class, new Object[]{wgsRunPinNo.getiPIN(), wgsRunPinNo.getFormID()});
                response.setStatus(false);
                response.setInformation(new ExceptionBean(new Date(), "Not Valid", responseMsg));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }
        } catch (Exception e) {
            LOGGER.error("validateWgsRunPinNo() Error :  {}", e);
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "Error", "Failed to validate PIN!"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"information", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
        }

    }

    public ResponseEntity<Object> findAllreportAttributesByClientProjectIDNGeneGroupID(int clientProjectID, int subClientID, int geneGroupID) {
        try {
            List<WgsReportAttributesByClient> wgsReportAttributesByClientList = jdbcTemplate.query("exec GetReportAttributesByClientProjectIDNGeneGroupID ?,?,?; ", BeanPropertyRowMapper.newInstance(WgsReportAttributesByClient.class), new Object[]{clientProjectID, subClientID, geneGroupID});
            LOGGER.info("GetReportAttributesByClientProjectIDNGeneGroupID is completed");
            if (!CollectionUtils.isEmpty(wgsReportAttributesByClientList)) {
                response.setStatus(true);
                response.setWgsReportAttributesByClientList(wgsReportAttributesByClientList);
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "wgsReportAttributesByClientList"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            } else {
                response.setStatus(false);
                response.setInformation(new ExceptionBean(new Date(), " Report Not Found", "Client Report not Found"));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"information", STATUS});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }
        } catch (Exception e) {
            LOGGER.error("findAllreportAttributesByClientProjectIDNGeneGroupID() Error :  {}", e);
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "Error", "Failed to get data."));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"information", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);

        }
    }

    @Override
    public ResponseEntity<Object> runValidate(WGSRunCreateDto wgsRunCreateDto) {
        try {
            if (findWgsRunByRunName(wgsRunCreateDto.getRunName()).isPresent()) {
                response.setStatus(false);
                response.setInformation(new ExceptionBean(new Date(), "RunName already present", "Run creation failed"));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }

            response.setStatus(true);
            response.setInformation(new ExceptionBean(new Date(), "Valid run", "Run validated successfully"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error("WgsRunsServiceImpl.runValidate(). Error:  {}", e);
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "Invalid Run", "Invalid Run. Please contact administrator"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
        }
    }

    @Override
    public ResponseEntity<Object> demultiplexingFileValidation(DemultiplexingFile demultiplexingFile) {
        String smbFullFilename = propertyConfiguration.getWgsDemuxSmbSourceUrl() + demultiplexingFile.getFileName();
        String destination = propertyConfiguration.getWgsDemuxSmbDestinationUrl() + demultiplexingFile.getFileName();
        try {

            boolean isFileExistsSource = isSmbFileOrFolderExists(smbFullFilename, getSmbAuth(propertyConfiguration.getWgsDemuxSmbDomain(), propertyConfiguration.getWgsDemuxSmbUsername(), propertyConfiguration.getWgsDemuxSmbPassword()));
            if (!isFileExistsSource) {
                LOGGER.debug("Demultiplexing file not exist in source path: " + smbFullFilename);
                response.setStatus(false);
                response.setInformation(new ExceptionBean(new Date(), smbFullFilename, "File doesn't exists in source path."));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }

            boolean isDestinationFileExists = isSmbFileOrFolderExists(destination, getSmbAuth(propertyConfiguration.getWgsDemuxSmbDomain(), propertyConfiguration.getWgsDemuxSmbUsername(), propertyConfiguration.getWgsDemuxSmbPassword()));
            if (isDestinationFileExists && !demultiplexingFile.isOverWrite()) {
                response.setStatus(false);
                response.setInformation(new ExceptionBean(new Date(), "Invalid Data", "File Already Exists, please select overwrite option to overwrite."));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }
            response.setStatus(true);
            response.setInformation(new ExceptionBean(new Date(), "Validation Successful", "Demultiplexing file validated successfully."));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error("WgsRunServiceImpl.demultiplexingFileValidation(DemultiplexingFile demultiplexingFile). Error:  {}", e);
            LOGGER.info("WgsRunServiceImpl.demultiplexingFileValidation(DemultiplexingFile demultiplexingFile). Source Path: " + smbFullFilename + ", Destination Path: " + destination);
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "Invalid share file/folder access", "Sorry! You are not authorized to add file. Please contact administrator"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
        }
    }

    @Override
    public ResponseEntity<Object> reportToClientEmailInfo(WGSClientReportMasterDTO wgsClientReportMaster) {
        try {
            boolean isAllClientProjectsMatch = wgsClientReportMaster.getWgsClientReports().stream().map(WGSClientReportDTO::getClientProjectId).distinct().count() == 1;

            if (!isAllClientProjectsMatch) {
                response.setStatus(false);
                response.setInformation(new ExceptionBean(new Date(), "Failed to generate report", "Mixed Client Projects are not allowed to be Reported"));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }

            List<String> pathSplit = Arrays.stream(propertyConfiguration.getWgsReportSmbSourceUrl().split("/"))
                    .filter(path -> !path.equalsIgnoreCase(""))
                    .collect(Collectors.toList());

            DiskShareConfig diskShareConfig = new DiskShareConfig(propertyConfiguration.getWgsReportSmbUsername()
                    , propertyConfiguration.getWgsReportSmbPassword()
                    , propertyConfiguration.getWgsReportSmbDomain()
                    , pathSplit.get(0), pathSplit.get(1));

            String smbPath = propertyConfiguration.getWgsReportSmbSourceUrl().replace("//", "").replace(pathSplit.get(0) + "/", "")
                    .replace(pathSplit.get(1) + "/", "");
            boolean isFolderExists = diskShareConfig.getDiskShare().folderExists(smbPath);
            if (!isFolderExists) {
                LOGGER.info("reportToClientEmailInfo() info. File/Folder Permission Issue.Report SMB URL: " + propertyConfiguration.getWgsReportSmbSourceUrl());
                response.setStatus(false);
                response.setInformation(new ExceptionBean(new Date(), "File/Folder Permission Issue", "Sorry! You are not authorized to generate reports. Please contact administrator"));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }
            diskShareConfig.close();

            String fromAddressSql = "SELECT AV.AttributeValue FROM AttributeDetails AV, Attributes A WHERE A.AttributeID = AV.AttributeID AND A.AttributeName = ?";
            String reportFromAddress = jdbcTemplate.queryForObject(fromAddressSql, String.class, propertyConfiguration.getWgsReportUsernameProp());

            String emailInfoSql = "SELECT GeneGroupID FROM GeneGroups WHERE GeneGroupName = ?";
            Integer geneGroupId = jdbcTemplate.queryForObject(emailInfoSql, Integer.class, WGSConstants.GENE_GROUP_NAME);

            WGSReportAttributesDTO wgsReportAttribute = jdbcTemplate.queryForObject("exec GetReportAttributesByClientProjectIDNGeneGroupID ?,?,?;"
                    , BeanPropertyRowMapper.newInstance(WGSReportAttributesDTO.class)
                    , new Object[]{wgsClientReportMaster.getWgsClientReports().get(0).getClientProjectId(), 0, geneGroupId});

            List<List<WgsReportDataDTO>> wgsClientReportsGroup = new ArrayList<>();
            for (WGSClientReportDTO clientReport : wgsClientReportMaster.getWgsClientReports()) {
                List<WgsReportDataDTO> wgsReportDatas = jdbcTemplate.query("exec GetWgsdetailsForReporting ?,?,?;",
                        BeanPropertyRowMapper.newInstance(WgsReportDataDTO.class),
                        new Object[]{clientReport.getWgsStatusViewerId(), wgsReportAttribute.getReportFormatSubType(), clientReport.getClientProjectId()});
                Optional<WGSRunMaster> wgsRunMaster = wgsRunMasterRepository.findById(clientReport.getWgsRunId());
                wgsReportDatas.forEach(data -> data.setWgsRunMaster(wgsRunMaster.get()));


                // Pooled Samples Report functionality
                List<WgsReportDataDTO> pooledSampleReportData = new ArrayList<>();
                for (WgsReportDataDTO wgsReportData : wgsReportDatas) {
                    WgsRunDetail bySampleIdAndWgsRunId = wgsRunDetailRepository.findBySampleIdAndWgsRunId(wgsReportData.getSampleId(), clientReport.getWgsRunId());
                    if (!bySampleIdAndWgsRunId.isPooledSample()) {
                        continue;
                    }
                    Samples byClientSampleId = samplesRepository.findByClientSampleId(wgsReportData.getSampleId());
                    List<PooledSubSample> pooledSamples = pooledSubSampleRepository.findBySampleId(byClientSampleId.getSampleId());

                    for (PooledSubSample pooledSample : pooledSamples) {
                        WgsReportDataDTO pooledSampleReportDataDTO = new WgsReportDataDTO();
                        pooledSampleReportDataDTO.setSubmittedName(pooledSample.getSubSampleId());
                        pooledSampleReportDataDTO.setSampleId(pooledSample.getSubSampleId());
                        pooledSampleReportDataDTO.setOutputFilePath(wgsReportData.getOutputFilePath());
                        pooledSampleReportDataDTO.setSourcePath(wgsReportData.getSourcePath());
                        pooledSampleReportDataDTO.setWgsRunMaster(wgsReportData.getWgsRunMaster());
                        pooledSampleReportDataDTO.setReportFolderSize(wgsReportData.getReportFolderSize());
                        pooledSampleReportDataDTO.setNoOfCycles(wgsReportData.getNoOfCycles());
                        pooledSampleReportDataDTO.setDataSource(wgsReportData.getDataSource());
                        pooledSampleReportDataDTO.setIndexSeq(wgsReportData.getIndexSeq());
                        pooledSampleReportDataDTO.setLane(wgsReportData.getLane());
                        pooledSampleReportDataDTO.setProject(wgsReportData.getProject());
                        pooledSampleReportDataDTO.setRun(wgsReportData.getRun());
                        pooledSampleReportDataDTO.setRunType(wgsReportData.getRunType());
                        pooledSampleReportDataDTO.setTechnology(wgsReportData.getTechnology());
                        pooledSampleReportDataDTO.setType(wgsReportData.getType());
                        pooledSampleReportDataDTO.setVendorId(wgsReportData.getVendorId());

                        pooledSampleReportData.add(pooledSampleReportDataDTO);
                    }
                }

                if (pooledSampleReportData.size() > 0) {
                    wgsClientReportsGroup.add(pooledSampleReportData);
                } else {
                    wgsClientReportsGroup.add(wgsReportDatas);
                }
            }

            List<WgsReportDataDTO> reportDataFinal = new ArrayList<>();
            wgsClientReportsGroup.forEach(reportDataFinal::addAll);

            List<String> rawRuns = reportDataFinal.stream().filter(data ->
                            data.getType().equalsIgnoreCase("raw"))
                    .map(WgsReportDataDTO::getRun).distinct()
                    .collect(Collectors.toList());
            List<WgsReportDataDTO> differentRawRuns = new ArrayList<>();
            for (String rawRun : rawRuns) {
                differentRawRuns.add(
                        reportDataFinal.stream().filter(data -> data.getRun().equalsIgnoreCase(rawRun)).findFirst().get()
                );
            }

            List<WgsReportDataDTO> reportDataFinalMaster = reportDataFinal.stream().filter(data ->
                            !data.getType().equalsIgnoreCase("raw"))
                    .collect(Collectors.toList());
            reportDataFinalMaster.addAll(differentRawRuns);

            // checking the run/sample is demultiplex. if yes append sample name in  path to find size
            for (WgsReportDataDTO reportData : reportDataFinalMaster) {
                Optional<WGSAnalysisApplicationMaster> demuxAnalysisApplication = wgsAnalysisApplicationMasterRepository.findByAnalysisApplicationValue(WGSConstants.DEMUX_APP_VALUE);
                List<WGSAdvancedProperty> demuxAdvancedProperties = wgsAdvancedPropertyRepository.findByWgsRunIDAndAnalysisApplicationID(reportData.getWgsRunMaster(), demuxAnalysisApplication.get());
                if ((reportData.getWgsRunMaster().getIsDemultiplexingRequired() || demuxAdvancedProperties.size() > 0) && !reportData.getType().equalsIgnoreCase("raw")) {
                    reportDataFinalMaster.get(reportDataFinalMaster.indexOf(reportData)).setSourcePath(
                            reportData.getSourcePath()
                                    .concat(reportData.getSampleId())
                                    .concat("\\")
                    );
                }
                if (reportData.getType().equalsIgnoreCase("raw")) {
                    String rawOutputFilePath = reportData.getOutputFilePath().replace(reportData.getSampleId(), "");
                    reportDataFinalMaster.get(reportDataFinalMaster.indexOf(reportData)).setOutputFilePath(rawOutputFilePath);
                    reportDataFinalMaster.get(reportDataFinalMaster.indexOf(reportData)).setSampleId("N/A");
                    reportDataFinalMaster.get(reportDataFinalMaster.indexOf(reportData)).setSubmittedName("N/A");
                }
            }
            String fileNameForGetUniqeId = WGSConstants.REPORT_TO_CLIENT_BASE_FILE_NAME + WGSUtil.getCurrentDate() + "__" + reportDataFinalMaster.get(0).getProject();

            Integer uniqueId = insertUpdateClientReportLog(wgsClientReportMaster, wgsReportAttribute, fileNameForGetUniqeId);

            WGS_REPORT_TO_CLIENT_UNIQUE_ID = uniqueId;
            USER_ID = wgsClientReportMaster.getUserId();
            WGS_CLIENT_REPORTS = wgsClientReportMaster.getWgsClientReports();

            StringBuilder fileName = new StringBuilder().append(WGSConstants.REPORT_TO_CLIENT_BASE_FILE_NAME)
                    .append(WGSUtil.getCurrentDate()).append("__")
                    .append(uniqueId.toString()).append("_").append(reportDataFinalMaster.get(0).getProject()).append(".xlsx");
            StringBuilder filePath = new StringBuilder().append(propertyConfiguration.getWgsReportSmbSourceUrl())
                    .append(WGSUtil.getCurrentYear().toString()).append("/")
                    .append(WGSConstants.REPORT_TO_CLIENT_WGS_REPORTS).append("/")
                    .append(reportDataFinalMaster.get(0).getProject()).append("/").append(WGSUtil.getCurrentDate()).append("/");

            List<String> transferModes = new ArrayList<>();
            wgsClientReportMaster.getWgsClientReports().forEach(wgsRun -> {
                String transferMode = getTransferMode(wgsRun.getWgsStatusViewerId());
                transferModes.add(transferMode);
            });

            WGSAttachment attachment = new WGSAttachment(fileName.toString(), filePath.toString());
            EmailInfo emailInfo = new EmailInfo();
            emailInfo.setMailTitle(WGSConstants.REPORT_TO_CLIENT_MAIL_TITLE);
            emailInfo.setFrom(reportFromAddress);
            emailInfo.setTo(wgsReportAttribute.getReportTo().split(";"));
            emailInfo.setCc(wgsReportAttribute.getReportCC().split(";"));
            emailInfo.setBcc(new String[]{});
            emailInfo.setSubject(WGSConstants.REPORT_TO_CLIENT_MAIL_SUBJECT);
            emailInfo.setAttachments(wgsXlsReportGenerate(reportDataFinalMaster, attachment));
            emailInfo.setMessage(WGSConstants.REPORT_TO_CLIENT_MAIL_BODY);

            response.setStatus(true);
            response.setEmailInfo(emailInfo);
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "emailInfo"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error("WgsRunServiceImpl.reportToClientEmailInfo(WGSClientReportMasterDTO wgsClientReportMaster). Error:  {}", e);
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "Mail failed to send", "Sorry! Mail failed to send. Please contact administrator"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
        }
    }

    // find the wgs transfer mode  by wgsStatusViewerId
    private String getTransferMode(Integer wgsStatusViewerId) {
        String wgsTransferMode = jdbcTemplate.query("exec WGS_GetClientProjectAttributes ?;"
                , (ResultSet rs) -> {
                    HashMap<String, String> results = new HashMap<>();
                    while (rs.next()) {
                        results.put(rs.getString("AttributeName"), rs.getString("AttributeValue"));
                    }
                    return StringUtils.isNotEmpty(results.get("WGSDataTransferType")) ? results.get("WGSDataTransferType").toLowerCase() : "";
                }, wgsStatusViewerId);
        return wgsTransferMode;
    }

    private List<WGSEmailConfig> getEmailConfig(List<String> transferModes) {
        List<WGSEmailConfig> emailConfigs = wgsEmailConfigRepository.findAll();
        if (transferModes.isEmpty()) {
            return emailConfigs;
        }

        List<String> uniqueTransferModes = transferModes.stream()
                .distinct()
                .collect(Collectors.toList());

        if (uniqueTransferModes.size() > 1) {
            return emailConfigs;
        }

        emailConfigs.stream()
                .forEach(mode -> {
                    if (mode.getModeOfTransfer().equalsIgnoreCase(uniqueTransferModes.get(0))) {
                        emailConfigs.get(emailConfigs.indexOf(mode)).setDefault(true);
                    }
                });

        return emailConfigs;
    }

    private String updateWGSReportingStatus(String wgsStatusViewerId, int userId, BigInteger uniqueId) {
        String reportUpdateResult = jdbcTemplate.queryForObject("exec UpdateWGSReportingStatus ?,?,?;"
                , String.class
                , new Object[]{wgsStatusViewerId, userId, uniqueId});
        return reportUpdateResult;
    }

    @Override
    public ResponseEntity<Object> reportToClientSendEmail(WGSEmailDetailsDTO details) {
        String msgBody = details.getMsgBody() + "\n\n" + "Histo Reference ID: " + WGS_REPORT_TO_CLIENT_UNIQUE_ID + "-" + WGSUtil.getCurrentDate();

        try {
            List<String> pathSplit = Arrays.stream(details.getAttachmentsSourcePath().split("/"))
                    .filter(path -> !path.equalsIgnoreCase(""))
                    .collect(Collectors.toList());

            DiskShareConfig diskShareConfig = new DiskShareConfig(propertyConfiguration.getWgsReportSmbUsername()
                    , propertyConfiguration.getWgsReportSmbPassword()
                    , propertyConfiguration.getWgsReportSmbDomain()
                    , pathSplit.get(0), pathSplit.get(1));

            String smbPath = details.getAttachmentsSourcePath().replace("//", "").replace(pathSplit.get(0) + "/", "")
                    .replace(pathSplit.get(1) + "/", "");
            boolean isFolderExists = diskShareConfig.getDiskShare().folderExists(smbPath);

            if (!isFolderExists) {
                LOGGER.info("reportToClientSendEmail() info. Current user not have file permission. File path:" + details.getAttachmentsSourcePath());
                response.setStatus(false);
                response.setInformation(new ExceptionBean(new Date(), "File/Folder Permission Issue", "Sorry! You are not authorized to generate reports. Please contact administrator"));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }

            Thread.sleep(3000);
            diskShareConfig.close();

            StringBuilder file = new StringBuilder().append(details.getAttachmentsSourcePath());
            List<String> pathSplitFolder = Arrays.stream(file.toString().split("/"))
                    .filter(path -> !path.equalsIgnoreCase(""))
                    .collect(Collectors.toList());

            DiskShareConfig diskShareConfigFile = new DiskShareConfig(propertyConfiguration.getWgsReportSmbUsername()
                    , propertyConfiguration.getWgsReportSmbPassword()
                    , propertyConfiguration.getWgsReportSmbDomain()
                    , pathSplitFolder.get(0), pathSplitFolder.get(1));

            Map<String, byte[]> reportFiles = new HashMap<>();
            Map<String, InputStream> reportFilesInput = new HashMap<>();
            InputStream inputStream = null;
            Integer filesCount = 0;
            ResponseEntity<String> emailResponse = null;
            for (String fileName : details.getFileNames()) {
                file.append(fileName);
                List<String> pathSplitFile = Arrays.stream(file.toString().split("/"))
                        .filter(path -> !path.equalsIgnoreCase(""))
                        .collect(Collectors.toList());

                String smbPathFile = file.toString().replace("//", "").replace(pathSplitFile.get(0) + "/", "")
                        .replace(pathSplitFile.get(1) + "/", "");
                boolean isFileExistsFile = diskShareConfigFile.getDiskShare().fileExists(smbPathFile);

                if (!isFileExistsFile) {
                    LOGGER.info("reportToClientSendEmail() info. Report attachment file not exist. File path:" + file.toString());
                    response.setStatus(false);
                    response.setInformation(new ExceptionBean(new Date(), "Given file not exist", "File not exist. File name:" + fileName));
                    mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                    return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
                }
                 inputStream = diskShareConfigFile.getDiskShare().openFile(
                        smbPathFile,
                        EnumSet.of(AccessMask.GENERIC_READ),
                        null,
                        SMB2ShareAccess.ALL,
                        SMB2CreateDisposition.FILE_OPEN,
                        null
                ).getInputStream();
                reportFilesInput.put(fileName, inputStream);
                filesCount++;
                if (details.getFileNames().length == filesCount) {
                    emailResponse =   sendEmailViaPacbio(details.getTo(), Optional.of(details.getCc()), Optional.of(details.getBcc())
                            , details.getSubject(), msgBody, reportFilesInput);
                }
                // mimeMessageHelper.addAttachment(fileName, new ByteArrayResource(IOUtils.toByteArray(inputStream)));
                reportFiles.put(fileName, new ByteArrayResource(IOUtils.toByteArray(inputStream)).getByteArray());
            }

            // javaMailSender.send(mimeMessage);
            Thread.sleep(3000);
            inputStream.close();
            diskShareConfigFile.close();
            for (WGSClientReportDTO wgsClientReport : WGS_CLIENT_REPORTS) {
                updateWGSReportingStatus(wgsClientReport.getWgsStatusViewerId().toString(), USER_ID, BigInteger.valueOf(WGS_REPORT_TO_CLIENT_UNIQUE_ID)); // update email status
            }

            // Log the email data and file in DB
            insertReportMailLog(details, USER_ID, WGS_REPORT_TO_CLIENT_UNIQUE_ID, reportFiles);
            if (emailResponse.getStatusCode() == HttpStatus.OK) {
                response.setStatus(true);
                response.setInformation(new ExceptionBean(new Date(), "E-Mail Send", "E-Mail sent Successfully"));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }else {
                response.setStatus(false);
                response.setInformation(new ExceptionBean(new Date(), "Failed", "Error while sending E-Mail!!!"));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                return new ResponseEntity<>(mappingJacksonValue, emailResponse.getStatusCode());
            }

        } catch (Exception e) {
            return catchException("reportToClientSendEmail()", e, "Failed", "Error while sending E-Mail!!!");
        }
    }

    private ResponseEntity<String> sendEmailViaPacbio(String[] to, Optional<String[]> cc, Optional<String[]> bcc, String subject, String emailBody
            ,  Map<String, InputStream> reportFilesInput) throws IOException {
        String url = propertyConfiguration.getPacbioBaseUrl().concat("/REPORT/sendEmail/attachment");

        // Create the multipart request body
        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();

        List<File> tempFiles = new ArrayList<>();
        // Add files to the request body
        for (Map.Entry<String, InputStream> reportFile : reportFilesInput.entrySet()) {
            Resource  fileResource = new ByteArrayResource (reportFile.getValue().readAllBytes()) {
                @Override
                public String getFilename() {
                    return reportFile.getKey();
                }
            };
//            String fileName = reportFile.getKey().substring(0, reportFile.getKey().indexOf("."));
//            File file = convertInputStreamToFile(reportFile.getValue(), fileName , ".xlsx");
//            FileSystemResource fileResource = new FileSystemResource(file);
//            tempFiles.add(file);
            body.add("files", fileResource);
        }

        // Add other parameters
        body.add("to", String.join(",", to));
        body.add("cc", cc.map(strings -> String.join(",", strings)).orElse(""));
        body.add("bcc", bcc.map(strings -> String.join(",", strings)).orElse(""));
        body.add("subject", subject);
        body.add("body", emailBody); // Add the email body here

        // Set up headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);

        // Create the request entity
        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);

        // Make the request
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class);

        tempFiles.forEach(tempFile -> {
            if (tempFile.exists()) {
                tempFile.delete();
            }
        });
        return response;
    }

    public static File convertInputStreamToFile(InputStream inputStream, String prefix, String suffix) throws IOException {
        // Create a temporary file
        File tempFile = new File(prefix+suffix);
        tempFile.createNewFile();

        // Write the InputStream to the temporary file
        try (OutputStream outputStream = new FileOutputStream(tempFile)) {
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        }
        return tempFile;
    }
    private void insertReportMailLog(WGSEmailDetailsDTO emailDetails, Integer userId, Integer reportUniqueId, Map<String, byte[]> reportFiles) {

        String mailLogSpQuery = "EXEC InsertUpdateReportMailLog_WGS ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?";
        String spResult = jdbcTemplate.queryForObject(mailLogSpQuery
                , String.class
                , new Object[]{
                        Long.valueOf(reportUniqueId)
                        , WGSConstants.REPORT_TO_CLIENT_MAIL_TITLE
                        , emailDetails.getSubject()
                        , String.join(",", emailDetails.getTo())
                        , String.join(",", emailDetails.getCc())
                        , String.join(",", emailDetails.getBcc())
                        , emailDetails.getMsgBody()
                        , ""
                        , ""
                        , "EMAIL"
                        , userId
                }
        );

        if (spResult.equalsIgnoreCase("Success") && !reportFiles.isEmpty()) {
            String fileLogSqlSp = "EXEC InsertClientReportFileLog_WGS ?, ?, ?, ?;";
            for (Map.Entry<String, byte[]> fileEntrySet : reportFiles.entrySet()) {
                String fileLogSpResult = jdbcTemplate.queryForObject(fileLogSqlSp
                        , String.class
                        , new Object[]{fileEntrySet.getKey(), fileEntrySet.getValue(), reportUniqueId, WGSConstants.GENE_GROUP_NAME}
                );
            }
        }
    }

    @Override
    public ResponseEntity<Object> downloadFileByPath(String encodeFilePath) {
        byte[] data;
        String filePath = WGSUtil.decode(encodeFilePath);
        try {
            List<String> pathSplit = Arrays.stream(filePath.split("/"))
                    .filter(path -> !path.equalsIgnoreCase(""))
                    .collect(Collectors.toList());

            DiskShareConfig diskShareConfig = new DiskShareConfig(propertyConfiguration.getWgsReportSmbUsername()
                    , propertyConfiguration.getWgsReportSmbPassword()
                    , propertyConfiguration.getWgsReportSmbDomain()
                    , pathSplit.get(0), pathSplit.get(1));

            String smbPath = filePath.replace("//", "").replace(pathSplit.get(0) + "/", "")
                    .replace(pathSplit.get(1) + "/", "");
            boolean isFolderExists = diskShareConfig.getDiskShare().fileExists(smbPath);
            if (!isFolderExists) {
                LOGGER.info("downloadFileByPath() info. Download path:" + filePath);
                response.setStatus(false);
                response.setInformation(new ExceptionBean(new Date(), "File Permission Issue", "Sorry! You are not authorized to download. Please contact administrator"));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }

            try (DiskShare diskShare = diskShareConfig.getDiskShare();
                 InputStream inputStream = diskShare.openFile(
                         smbPath,
                         EnumSet.of(AccessMask.GENERIC_READ),
                         null,
                         SMB2ShareAccess.ALL,
                         SMB2CreateDisposition.FILE_OPEN,
                         null
                 ).getInputStream()) {
                data = IOUtils.toByteArray(inputStream);
            }
        } catch (IOException e) {
            LOGGER.error("downloadFileByPath() error.Failed to download file. Message:  {}", e);
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "File related issue.", "File conversion failed. Please contact administrator"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
        }

        String[] filename = filePath.split("/");
        WGSReportFile wgsReportFile = new WGSReportFile();
        wgsReportFile.setFilename(filename[filename.length - 1]);
        wgsReportFile.setData(data);

        response.setStatus(true);
        response.setWgsReportFile(wgsReportFile);
        mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "wgsReportFile"});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Object> reportToClientUploadFile(MultipartFile multipartFile, String encodeUploadPath) {
        String uploadPath = WGSUtil.decode(encodeUploadPath);
        if (multipartFile.isEmpty()) {
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "File Upload Failed", "Does not contain any file"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }

        List<String> pathSplit = Arrays.stream(uploadPath.split("/"))
                .filter(path -> !path.equalsIgnoreCase(""))
                .collect(Collectors.toList());

        DiskShareConfig diskShareConfig = new DiskShareConfig(
                propertyConfiguration.getWgsReportSmbUsername()
                , propertyConfiguration.getWgsReportSmbPassword()
                , propertyConfiguration.getWgsReportSmbDomain()
                , pathSplit.get(0), pathSplit.get(1)
        );

        String smbPath = uploadPath.replace("//", "").replace(pathSplit.get(0) + "/", "")
                .replace(pathSplit.get(1) + "/", "");
        boolean isFolderExists = diskShareConfig.getDiskShare().folderExists(smbPath);
        if (!isFolderExists) {
            LOGGER.info("reportToClientUploadFile() info.Directory or file does not exist. Path: " + uploadPath);
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "File Permission Issue", "Sorry! You are not authorized to upload file. Please contact administrator"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }

        try (OutputStream outputStream = diskShareConfig.getDiskShare().openFile(smbPath.concat(multipartFile.getOriginalFilename())
                , EnumSet.of(AccessMask.GENERIC_WRITE)
                , null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OVERWRITE_IF, null).getOutputStream()) {
            outputStream.write(multipartFile.getBytes());
        } catch (IOException e) {
            LOGGER.error("reportToClientUploadFile() error. Failed to upload file. Message:  {}", e);
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "File Upload Failed", "Something went wrong while uploading the file"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
        }

        response.setStatus(true);
        response.setInformation(new ExceptionBean(new Date(), "File Upload Successfully", "File uploaded destination path"));
        mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Object> updateSMRTRunPath(String path, Integer wgsStatusViewerId) {
        try {
            Optional<WGSStatusViewer> wgsStatusViewer = wgsStatusViewerRepository.findById(wgsStatusViewerId);
            if (!wgsStatusViewer.isPresent()) {
                return responseFalseValidation("Run Not Found");
            }
            wgsStatusViewer.get().getWGSRunID().setFilePath(path);
            WGSRunMaster saveWgs = wgsRunMasterRepository.save(wgsStatusViewer.get().getWGSRunID());
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception e) {
            return catchException("updateSMRTRunPathByWgsRunId()", e, "Error", "Path update failed");
        }
    }

    @Override
    public ResponseEntity<Object> validateWgsSamples(ValidateSamplesDetailDTO validateSamplesDetail) {
        try {
            String joinSamples = String.join(",", validateSamplesDetail.getSamples());

            List<ValidateSampleDTO> inValidSamples = jdbcTemplate.query("exec ValidateWGSSample ?,?; "
                    , BeanPropertyRowMapper.newInstance(ValidateSampleDTO.class)
                    , new Object[]{joinSamples, validateSamplesDetail.getClientProjectId()});
            if (inValidSamples.isEmpty()) {
                if (validateSamplesDetail.isPooledSample()) {
                    Samples sample = samplesRepository.findByClientSampleId(validateSamplesDetail.getSamples()[0]);
                    if (sample == null) {
                        response.setStatus(false);
                        response.setInformation(new ExceptionBean(new Date(), "Validation Failed"
                                , "Given sample id not found. Sample id: "+validateSamplesDetail.getSamples()[0]));
                        mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.NOT_FOUND);
                    }
                    // Validation for pooled samples
                    List<PooledSubSample> existingBySubSampleId = pooledSubSampleRepository.findExistingBySubSampleIdInAndSampleId(Arrays.asList(validateSamplesDetail.getPooledSamples()), sample.getSampleId());
                    if (existingBySubSampleId.size() > 0) {
                        List<String> missingPooledSamples = pooledSubSampleRepository.findNonExistingBySubSampleIdIn(Arrays.asList(validateSamplesDetail.getPooledSamples()), sample.getSampleId());

                        if (missingPooledSamples.size() > 0) {
                            response.setMissingPooledSamples(missingPooledSamples);
                            response.setStatus(false);
                            response.setInformation(new ExceptionBean(new Date(), "Validation Failed", "Few pooled samples are missing"));
                            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information", "missingPooledSamples"});
                            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.NOT_FOUND);
                        }
                        response.setStatus(true);
                        response.setInformation(new ExceptionBean(new Date(), "Validation Success", "Given samples are valid"));
                        mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
                    }
                }
                response.setStatus(true);
                response.setInformation(new ExceptionBean(new Date(), "Validation Success", "Given samples are valid"));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            } else {
                response.setStatus(false);
                response.setInformation(new ExceptionBean(new Date(), "Validation Failed", "Given samples are not valid"));
                response.setInValidSamples(inValidSamples);
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information", "inValidSamples"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
            }
        } catch (Exception e) {
            return catchException("validateWgsSamples()", e, "Error", "Sample validation failed");
        }
    }

    @Override
    public ResponseEntity<Object> getPooledSamplesBySampleId(String sampleId) {
        try {
            Samples sample = samplesRepository.findByClientSampleId(sampleId);
            if (sample == null) {
                return responseFalseValidation("Given sample is not found");
            }
            List<PooledSubSample> pooledSamples = pooledSubSampleRepository.findBySampleId(sample.getSampleId());
            List<String> pooledSamplesString = pooledSamples.stream().map(PooledSubSample::getSubSampleId).collect(Collectors.toList());
            if (pooledSamplesString.size() == 0) {
                response.setStatus(false);
                response.setInformation(new ExceptionBean(new Date(), "Not Found", "Pooled samples are not found for given sample id"));
                response.setPooledSamplesString(pooledSamplesString);
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information", "pooledSamplesString"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }
            response.setStatus(true);
            response.setPooledSamplesString(pooledSamplesString);
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "pooledSamplesString"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException("getPooledSamplesBySample()", e, "Error", "Sample validation failed");
        }
    }

    public EmailAttributeDetails getMailAttributeDetails(JdbcTemplate jdbcTemplate, PropertyConfiguration propertyConfiguration) {
        EmailAttributeDetails emailAttributeDetails = new EmailAttributeDetails();
        List<AttributeDetails> allAttributesByCategory = getAllAttributesByCategory(jdbcTemplate, propertyConfiguration, WGSConstants.GENERAL);

        emailAttributeDetails.setSMTPUserName(allAttributesByCategory.stream().filter(attribute -> attribute.getAttributeName().equals(WGSConstants.SMTP_USER_NAME)).findFirst().get().getAttributeValue());

        emailAttributeDetails.setSMTPPassword(allAttributesByCategory.stream().filter(attribute -> attribute.getAttributeName().equals(WGSConstants.SMTP_PASSWORD)).findFirst().get().getAttributeValue());

        return emailAttributeDetails;
    }

    private List<AttributeDetails> getAllAttributesByCategory(JdbcTemplate jdbcTemplate, PropertyConfiguration propertyConfiguration, String category) {
        List<AttributeDetails> attributeDetails = jdbcTemplate.query("EXEC GetAllAttributesByCategory ?;", BeanPropertyRowMapper.newInstance(AttributeDetails.class), category);

        return attributeDetails;
    }

    private List<WGSAttachment> wgsXlsReportGenerate(List<WgsReportDataDTO> reportDataFinal, WGSAttachment attachment) {
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("WgsReport");

        XSSFFont headerFont = workbook.createFont();
        headerFont.setFontHeightInPoints((short) 10);
        headerFont.setFontName("Calibri");
        headerFont.setBold(true);

        String reportHeaders[] = {"Project", "SampleID", "Submitted Name", "Data Source", "Technology", "Run", "Type", "Lane", "# of Cycles", "Run Type", "Index Seq", "Vendor ID", "Output file path", "Reports Folder Size (GB)"};
        int rowNum = 0;
        int colNumHeader = 0;
        Row rowHeader = sheet.createRow(rowNum++);

        XSSFCellStyle headerStyle = workbook.createCellStyle(); // header text style property
        headerStyle.setAlignment(HorizontalAlignment.CENTER);
        headerStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        headerStyle.setFillForegroundColor(IndexedColors.TAN.index);
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerStyle.setFont(headerFont);
        headerStyle.setBorderBottom(BorderStyle.THIN);
        headerStyle.setBorderTop(BorderStyle.THIN);
        headerStyle.setBorderRight(BorderStyle.THIN);
        headerStyle.setBorderLeft(BorderStyle.THIN);

        for (String header : reportHeaders) {
            Cell cell = rowHeader.createCell(colNumHeader++);
            rowHeader.setHeight((short) 800);
            cell.setCellValue((String) header);
            cell.setCellStyle(headerStyle);
        }

        XSSFFont bodyFont = workbook.createFont();
        bodyFont.setFontHeightInPoints((short) 12);
        bodyFont.setFontName("Calibri");
        bodyFont.setBold(false);

        XSSFCellStyle bodyStyle = workbook.createCellStyle(); // body data style property
        bodyStyle.setFont(bodyFont);
        bodyStyle.setBorderBottom(BorderStyle.THIN);
        bodyStyle.setBorderTop(BorderStyle.THIN);
        bodyStyle.setBorderRight(BorderStyle.THIN);
        bodyStyle.setBorderLeft(BorderStyle.THIN);

        for (WgsReportDataDTO reportData : reportDataFinal) { // data set loop functionality
            Row row = sheet.createRow(rowNum++);
            int colNum = 0;
            Cell cellProject = row.createCell(colNum++);
            cellProject.setCellValue((String) reportData.getProject());
            cellProject.setCellStyle(bodyStyle);

            Cell cellSampleId = row.createCell(colNum++);
            cellSampleId.setCellValue((String) reportData.getSampleId());
            cellSampleId.setCellStyle(bodyStyle);

            Cell cellSubmittedName = row.createCell(colNum++);
            cellSubmittedName.setCellValue((String) reportData.getSubmittedName());
            cellSubmittedName.setCellStyle(bodyStyle);

            Cell cellDataSource = row.createCell(colNum++);
            cellDataSource.setCellValue((String) reportData.getDataSource());
            cellDataSource.setCellStyle(bodyStyle);

            Cell cellTechnology = row.createCell(colNum++);
            cellTechnology.setCellValue((String) reportData.getTechnology());
            cellTechnology.setCellStyle(bodyStyle);

            Cell cellRun = row.createCell(colNum++);
            cellRun.setCellValue((String) reportData.getRun());
            cellRun.setCellStyle(bodyStyle);

            Cell cellType = row.createCell(colNum++);
            cellType.setCellValue((String) reportData.getType());
            cellType.setCellStyle(bodyStyle);

            Cell cellLane = row.createCell(colNum++);
            cellLane.setCellValue((String) reportData.getLane());
            cellLane.setCellStyle(bodyStyle);

            if (StringUtils.isBlank(reportData.getNoOfCycles())) {
                reportData.setNoOfCycles("N/A");
            }
            Cell cellNoOfCycles = row.createCell(colNum++);
            cellNoOfCycles.setCellValue((String) reportData.getNoOfCycles());
            cellNoOfCycles.setCellStyle(bodyStyle);

            Cell cellRunType = row.createCell(colNum++);
            cellRunType.setCellValue((String) reportData.getRunType());
            cellRunType.setCellStyle(bodyStyle);

            Cell cellIndexSeq = row.createCell(colNum++);
            cellIndexSeq.setCellValue((String) reportData.getIndexSeq());
            cellIndexSeq.setCellStyle(bodyStyle);

            Cell cellVendorId = row.createCell(colNum++);
            cellVendorId.setCellValue((String) reportData.getVendorId());
            cellVendorId.setCellStyle(bodyStyle);

            Cell cellOutputFilePath = row.createCell(colNum++);
            // output path append for pooled sample
           WgsRunDetail bySampleIdAndWgsRunId = wgsRunDetailRepository.findByWgsRunIdAndIsPooledSample(reportData.getWgsRunMaster().getId(),true);
            String outputFilePath = null;
            if (bySampleIdAndWgsRunId != null && bySampleIdAndWgsRunId.isPooledSample()) {
                String indexKeyWord = "ccs_data/";
                int lastIndex = reportData.getOutputFilePath().indexOf(indexKeyWord);
                if (lastIndex != -1) {
                    lastIndex += indexKeyWord.length();
                    outputFilePath = reportData.getOutputFilePath().substring(0, lastIndex) + reportData.getSampleId();
                }
            } else {
                outputFilePath = reportData.getOutputFilePath();
            }
            cellOutputFilePath.setCellValue((String) outputFilePath);
            cellOutputFilePath.setCellStyle(bodyStyle);

            Cell cellReportFolderSize = row.createCell(colNum++);
            try {
                if (propertyConfiguration.getWgsReportSmbSourceUrl().contains("smb")) {
                    propertyConfiguration.setWgsReportSmbSourceUrl(propertyConfiguration.getWgsReportSmbSourceUrl().replace("smb:", ""));
                }
                String pathString = reportData.getSourcePath().replaceFirst("/", "").replace("\\", "/");
                if (!pathString.endsWith("/")) {
                    pathString += "/";
                }

                List<String> pathSplit = Arrays.stream(pathString.split("/"))
                        .filter(path -> !path.equalsIgnoreCase(""))
                        .collect(Collectors.toList());

                DiskShareConfig diskShareConfig = new DiskShareConfig(propertyConfiguration.getSmb2Username()
                        , propertyConfiguration.getSmb2Password()
                        , propertyConfiguration.getWgsReportSmbDomain()
                        , pathSplit.get(0), pathSplit.get(1));

                String smbPath = pathString.replace("//", "").replace(pathSplit.get(0) + "/", "")
                        .replace(pathSplit.get(1) + "/", "");

                cellReportFolderSize.setCellValue(
                        WGSUtil.findShareDirectorySizeInGB(smbPath, diskShareConfig));
                diskShareConfig.close();
            } catch (IOException e) {
                LOGGER.error("wgsXlsReportGenerate() Error:{}", e);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            cellReportFolderSize.setCellStyle(bodyStyle);
        }
        for (int i = 0; i < reportHeaders.length; i++) {
            sheet.autoSizeColumn(i);
        }
        List<String> pathSplit = Arrays.stream(attachment.getFilePath().split("/"))
                .filter(path -> !path.equalsIgnoreCase(""))
                .collect(Collectors.toList());

        try {
            DiskShareConfig diskShareConfig = new DiskShareConfig(propertyConfiguration.getWgsReportSmbUsername()
                    , propertyConfiguration.getWgsReportSmbPassword()
                    , propertyConfiguration.getWgsReportSmbDomain()
                    , pathSplit.get(0), pathSplit.get(1));
            String smbPath = attachment.getFilePath().replace("//", "").replace(pathSplit.get(0) + "/", "")
                    .replace(pathSplit.get(1) + "/", "");
            boolean isFolderExists = diskShareConfig.getDiskShare().folderExists(smbPath);
            if (!isFolderExists) {
                String[] desNestedDirectory = smbPath.split("/");
                String currentDirectory = "";
                for (String directory : desNestedDirectory) {
                    currentDirectory += directory + "/";
                    if (!diskShareConfig.getDiskShare().folderExists(currentDirectory)) {
                        diskShareConfig.getDiskShare().mkdir(currentDirectory);
                    }
                }
            }

            try (OutputStream outputStream = diskShareConfig.getDiskShare().openFile(smbPath.concat("/").concat(attachment.getFileName())
                    , EnumSet.of(AccessMask.GENERIC_WRITE)
                    , null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_CREATE, null).getOutputStream()) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                workbook.write(bos);
                outputStream.write(bos.toByteArray());
                workbook.close();

            }
            diskShareConfig.close();
        } catch (Exception e) {
            LOGGER.debug("Attachment creation failed: Message:  {}", e);
        }
        List<WGSAttachment> attachments = new ArrayList<WGSAttachment>();
        attachment.setFilePath(attachment.getFilePath() + attachment.getFileName());
        attachments.add(attachment);
        return attachments;
    }

    private Integer insertUpdateClientReportLog(WGSClientReportMasterDTO wgsClientReportMaster, WGSReportAttributesDTO wgsReportAttribute, String fileName) {
        Integer uniqueId = jdbcTemplate.queryForObject("EXEC InsertUpdateClientReportLog ?,?,?,?,?,?,?,?,?,?;"
                , Integer.class
                , new Object[]{wgsReportAttribute.getClientProjectId(), WGSConstants.GENE_GROUP_NAME, wgsReportAttribute.getReportFormatSubTypeId()
                        , "", fileName, wgsClientReportMaster.getUserId(), WGSConstants.REPORT_TO_CLIENT_MAIL_COUNT, "", "N", BigInteger.valueOf(0)});
        return uniqueId;
    }

    private Optional<WgsRunsViewDto> findWgsRunByRunName(String runName) {
        String sql = " SELECT * FROM WGSRunMaster WHERE RunName = ?; ";
        return jdbcTemplate.query(sql, BeanPropertyRowMapper.newInstance(WgsRunsViewDto.class), runName).stream().findFirst();
    }

    private boolean isSmbFileOrFolderExists(String path, NtlmPasswordAuthentication auth) {
        boolean isExists = false;

        try {
            if (new SmbFile(path, auth).exists()) {
                isExists = true;
            }
        } catch (SmbException e) {
            try {
                if (new SmbFile(path, getSmbAuth(propertyConfiguration.getWgsDemuxSmbDomain(), propertyConfiguration.getWgsDemuxSmbUsername(), propertyConfiguration.getWgsDemuxSmbPassword())).exists()) {
                    return isExists = true;
                }
            } catch (SmbException ex) {
                LOGGER.error("SMB issue :  {}", e);
                throw new RuntimeException(e);
            } catch (MalformedURLException ex) {
                LOGGER.error("SMB issue :  {}", e);
                throw new RuntimeException(e);
            }
            LOGGER.error("SMB issue :  {}", e);
            throw new RuntimeException(e);
        } catch (MalformedURLException e) {
            LOGGER.error("SMB issue :  {}", e);
            throw new RuntimeException(e);
        }

        return isExists;
    }

    private ResponseEntity<Object> responseFalseValidation(String description) {
        response.setStatus(false);
        response.setInformation(new ExceptionBean(new Date(), "Operation  Failed", description));
        mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.BAD_REQUEST);
    }

    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
        LOGGER.error(methodName + " Error : {}", e);
        response.setStatus(false);
        response.setInformation(new ExceptionBean(new Date(), message, description));
        mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }

}
