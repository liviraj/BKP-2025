package com.histo.wgs.service;

import org.springframework.http.ResponseEntity;

public interface RemoteSMRTService {
    public ResponseEntity<Object> findAllReferenceGenomeSet();
    public ResponseEntity<Object> findReferenceGenomeDefaultValueByAnalysisApplicationId(Integer ApplicationID);
    public ResponseEntity<Object> findAllBarCodeSet();
    public ResponseEntity<Object> getBarCodeRecordNamesByUuid(String uuid);
}
