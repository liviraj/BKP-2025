package com.histo.wgs.service;

import com.histo.wgs.model.PacBioDataModel;
import com.histo.wgs.model.RawDataTransferModel;
import com.histo.wgs.model.WgsErrorLogModel;
import org.springframework.http.ResponseEntity;

public interface FileDataOrganizerService {
    public ResponseEntity<Object> updateRawDataTransferStatus(RawDataTransferModel rawDataTransfer);
}
