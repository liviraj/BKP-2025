package com.histo.wgs.service;

import com.histo.wgs.model.LoginModel;
import org.springframework.http.ResponseEntity;

public interface LoginService {
	public ResponseEntity<Object> azureSsoLogin( LoginModel loginModel);
}
