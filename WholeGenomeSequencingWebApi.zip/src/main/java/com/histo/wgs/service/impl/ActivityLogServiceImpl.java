package com.histo.wgs.service.impl;

import com.histo.wgs.entity.ESignActivityLog;
import com.histo.wgs.model.ActivityLogReq;
import com.histo.wgs.repository.ESignActivityLogRepository;
import com.histo.wgs.service.ActivityLogService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class ActivityLogServiceImpl implements ActivityLogService {
    private static final Logger LOGGER = LogManager.getLogger(ActivityLogServiceImpl.class);

    public final ESignActivityLogRepository eSignActivityLogRepository;

    public ActivityLogServiceImpl(ESignActivityLogRepository eSignActivityLogRepository) {
        this.eSignActivityLogRepository = eSignActivityLogRepository;
    }

    @Override
    public ResponseEntity<String> insertESignActivityLog(ActivityLogReq logReq) {
        try {
            ESignActivityLog eSignActivityLog = new ESignActivityLog();
            eSignActivityLog.setRemarks(logReq.getRemarks());
            eSignActivityLog.setApplicationId(logReq.getApplicationId());
            eSignActivityLog.setFileName(logReq.getFileName());
            eSignActivityLog.setStatus(logReq.getStatus());
            eSignActivityLog.setSampleId(logReq.getSampleId());
            eSignActivityLog.setLoginUserId(logReq.getLoginUserId());
            eSignActivityLog.setRequestDate(new Date());
            eSignActivityLog.setAgreementId(logReq.getAgreementId());

            eSignActivityLogRepository.save(eSignActivityLog);

            return new ResponseEntity<>("ESign event log saved successfully", HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error("insertESignActivityLog() error: {}", e);
        }
        return null;
    }
}
