package com.histo.wgs.service.impl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.histo.wgs.config.PropertyConfiguration;
import com.histo.wgs.config.smrt.ConnectionURLParams;
import com.histo.wgs.config.smrt.PacBioMachine;
import com.histo.wgs.entity.WGSAnalysisApplicationMaster;
import com.histo.wgs.exception.ExceptionBean;
import com.histo.wgs.model.*;
import com.histo.wgs.repository.WGSAnalysisApplicationMasterRepository;
import com.histo.wgs.service.RemoteSMRTService;
import com.histo.wgs.util.FilterUtil;
import okhttp3.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.stereotype.Service;

import javax.net.ssl.*;
import java.io.IOException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class RemoteSMRTServiceImpl implements RemoteSMRTService {
    private static final Logger LOGGER = LogManager.getLogger(RemoteSMRTServiceImpl.class);
    private static final String STATUS = "status";
    private final PropertyConfiguration propertyConfiguration;
    public static String AUTH_TOKEN = null;
    public static String SMRT_CLOUD_TOKEN_BODY = null;

    private WGSAdvancedPropertyResModel advancedPropertyResModel;
    private MappingJacksonValue mappingJacksonValue;
    private TokenResModel tokenResModel;

    private WGSAnalysisApplicationMasterRepository wgsAnalysisApplicationMasterRepository;

    public RemoteSMRTServiceImpl(PropertyConfiguration propertyConfiguration
            , WGSAnalysisApplicationMasterRepository wgsAnalysisApplicationMasterRepository) {
        this.propertyConfiguration = propertyConfiguration;
        advancedPropertyResModel = new WGSAdvancedPropertyResModel();
        this.wgsAnalysisApplicationMasterRepository = wgsAnalysisApplicationMasterRepository;
        AUTH_TOKEN = propertyConfiguration.getSmrtAuthToken();
        SMRT_CLOUD_TOKEN_BODY = propertyConfiguration.getSmrtCloudTokenBody();
    }

    private static TokenResModel getRemoteSMRTToken(PacBioMachine machine) {
        try {
            Response response = getTokenAPI(SMRT_CLOUD_TOKEN_BODY, AUTH_TOKEN, machine);
            if (response == null || response.code() != 200) {
                LOGGER.debug(response);
                return null;
            }
            String jsonString = response.body().string();
            return new Gson().fromJson(jsonString, TokenResModel.class);

        } catch (Exception e) {
            LOGGER.error(e);
        }
        return null;

    }

    private static Response getTokenAPI(String tokenBody, String authToken, PacBioMachine machine) {

        OkHttpClient client = getUnsafeOkHttpClient();

        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
        RequestBody body = RequestBody.create(tokenBody, mediaType);
        Request request = new Request.Builder().url(new ConnectionURLParams().getTokenURL(machine)).method("POST", body)
                .addHeader("Accept", "application/json").addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("Authorization", authToken).build();

        try {
            Response response = client.newCall(request).execute();
            return response;
        } catch (IOException e) {
            LOGGER.error(e);
        }
        return null;
    }

    private static OkHttpClient getUnsafeOkHttpClient() {
        try {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
                @Override
                public void checkClientTrusted(X509Certificate[] chain, String authType)
                        throws CertificateException {
                }

                @Override
                public void checkServerTrusted(X509Certificate[] chain, String authType)
                        throws CertificateException {
                }

                @Override
                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }
            }};

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            return new OkHttpClient.Builder().sslSocketFactory(sslSocketFactory, (X509TrustManager) trustAllCerts[0])
                    .hostnameVerifier(new HostnameVerifier() {
                        @Override
                        public boolean verify(String hostname, SSLSession session) {
                            return true;
                        }
                    }).build();

        } catch (Exception e) {
            LOGGER.error(e);
            throw new RuntimeException(e);
        }
    }

    @Override
    public ResponseEntity<Object> findAllReferenceGenomeSet() {
        tokenResModel = getRemoteSMRTToken(PacBioMachine.RemoteSMRTPortal);
        OkHttpClient client = getUnsafeOkHttpClient();
        Request request = new Request.Builder().url(new ConnectionURLParams().findAllReferenceGenomeSetUrl())
                .method("GET", null).addHeader("Authorization", tokenResModel.getToken_type() + " " + tokenResModel.getAccess_token()).build();
        try {
            Response response = client.newCall(request).execute();
            if (response == null || (response.code() != 200 && response.code() != 201)) {
                LOGGER.debug(response);
                return null;
            }
            List<ReferenceGenomeSet> referenceGenomeSets = new GsonBuilder().setDateFormat("yyyy-mm-dd'T'HH:mm:ss.SSSZ").create().fromJson(response.body().string(), new TypeToken<ArrayList<ReferenceGenomeSet>>() {
            }.getType());

            if (referenceGenomeSets.size() > 0) {
                advancedPropertyResModel.setStatus(true);
                advancedPropertyResModel.setReferenceGenomeSets(referenceGenomeSets);
                mappingJacksonValue = FilterUtil.advancePropResFilter(advancedPropertyResModel, new String[]{"referenceGenomeSets", STATUS});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }
        } catch (Exception e) {
            return catchException(e);
        }
        return null;
    }

    @Override
    public ResponseEntity<Object> findReferenceGenomeDefaultValueByAnalysisApplicationId(Integer applicationID) {
        try{

            Optional<WGSAnalysisApplicationMaster> analysisApplicationMaster = wgsAnalysisApplicationMasterRepository.findById(applicationID);
            if (!analysisApplicationMaster.isPresent()) {
                return responseFalseValidation("Invalid WGSRunID");
            }
            tokenResModel = getRemoteSMRTToken(PacBioMachine.RemoteSMRTPortal);
            String uuid = findUuidByAnalyisApplicationValue(analysisApplicationMaster.get().getAnalysisApplicationValue());


            OkHttpClient client = getUnsafeOkHttpClient();
            Request request = new Request.Builder().url(new ConnectionURLParams().getReferenceGenomeDefaultValueUrl(uuid))
                    .method("GET", null).addHeader("Authorization", tokenResModel.getToken_type() + " " + tokenResModel.getAccess_token()).build();

            Response response = client.newCall(request).execute();
            if (response == null || (response.code() != 200 && response.code() != 201)) {
                LOGGER.debug(response);
                return null;
            }

            ReferenceGenomeSet referenceGenomeSet = new GsonBuilder().setDateFormat("yyyy-mm-dd'T'HH:mm:ss.SSSZ").create().fromJson(response.body().string()
                    , new TypeToken<ReferenceGenomeSet>() {
            }.getType());
            if (referenceGenomeSet != null ) {
                advancedPropertyResModel.setStatus(true);
                advancedPropertyResModel.setReferenceGenomeSet(referenceGenomeSet);
                mappingJacksonValue = FilterUtil.advancePropResFilter(advancedPropertyResModel, new String[]{"referenceGenomeSet", STATUS});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }
        }catch (Exception e) {
            return catchException(e);
        }
        return null;
    }

    @Override
    public ResponseEntity<Object> findAllBarCodeSet() {
        try{
            tokenResModel = getRemoteSMRTToken(PacBioMachine.RemoteSMRTPortal);
            OkHttpClient client = getUnsafeOkHttpClient();
            Request request = new Request.Builder().url(new ConnectionURLParams().findAllBarCodeSetUrl())
                    .method("GET", null).addHeader("Authorization", tokenResModel.getToken_type() + " " + tokenResModel.getAccess_token()).build();
            Response response = client.newCall(request).execute();
            if (response == null || (response.code() != 200 && response.code() != 201)) {
                LOGGER.debug(response);
                return null;
            }

            List<BarCodeSet> barCodeSets = new GsonBuilder().setDateFormat("yyyy-mm-dd'T'HH:mm:ss.SSSZ").create().fromJson(response.body().string()
                    , new TypeToken<ArrayList<BarCodeSet>>() {
            }.getType());

            if (barCodeSets != null ) {
                advancedPropertyResModel.setStatus(true);
                advancedPropertyResModel.setBarCodeSets(barCodeSets);
                mappingJacksonValue = FilterUtil.advancePropResFilter(advancedPropertyResModel, new String[]{"barCodeSets", STATUS});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }

        } catch (Exception e) {
            return catchException(e);
        }
        return null;
    }

    @Override
    public ResponseEntity<Object> getBarCodeRecordNamesByUuid(String uuid) {
        try {
            tokenResModel = getRemoteSMRTToken(PacBioMachine.RemoteSMRTPortal);
            OkHttpClient client = getUnsafeOkHttpClient();
            Request request = new Request.Builder().url(new ConnectionURLParams().getBarCodeRecordNamesByUuidUrl(uuid))
                    .method("GET", null).addHeader("Authorization", tokenResModel.getToken_type() + " " + tokenResModel.getAccess_token()).build();
            Response response = client.newCall(request).execute();
            if (response == null || (response.code() != 200 && response.code() != 201)) {
                LOGGER.debug(response);
                return null;
            }

            List<String> barCodeRecordNames = new GsonBuilder().setDateFormat("yyyy-mm-dd'T'HH:mm:ss.SSSZ").create().fromJson(response.body().string()
                    , new TypeToken<ArrayList<String>>() {
                    }.getType());

            if (barCodeRecordNames != null ) {
                advancedPropertyResModel.setStatus(true);
                advancedPropertyResModel.setBarCodeRecordNames(barCodeRecordNames);
                mappingJacksonValue = FilterUtil.advancePropResFilter(advancedPropertyResModel, new String[]{"barCodeRecordNames", STATUS});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }
        } catch (Exception e) {
            return catchException(e);
        }
        return null;
    }

    private String findUuidByAnalyisApplicationValue(String value) {
        List<PipelineTemplateViewRule> pipelineTemplateViewRule = getPipelineTemplateViewRule();
        List<PipelineTemplateViewRule> collectPipelineTemplateViewRules = pipelineTemplateViewRule.stream().filter(viewRule -> viewRule.getId().equals(value)).collect(Collectors.toList());
        String uuid = collectPipelineTemplateViewRules.get(0).getEntryPoints().get(0).getUuid();
        return uuid;
    }

    private List<PipelineTemplateViewRule> getPipelineTemplateViewRule() {
        tokenResModel = getRemoteSMRTToken(PacBioMachine.RemoteSMRTPortal);
        List<PipelineTemplateViewRule> pipelineTemplateViewRules = null;
        OkHttpClient client = getUnsafeOkHttpClient();
        Request request = new Request.Builder().url(new ConnectionURLParams().getPipelineTemplateUrl())
                .method("GET", null).addHeader("Authorization", tokenResModel.getToken_type() + " " + tokenResModel.getAccess_token()).build();
        try{
            Response response = client.newCall(request).execute();
            if (response == null || (response.code() != 200 && response.code() != 201)) {
                LOGGER.debug(response);
                return null;
            }
            pipelineTemplateViewRules = new GsonBuilder().setDateFormat("yyyy-mm-dd'T'HH:mm:ss.SSSZ").create().fromJson(response.body().string()
                    , new TypeToken<List<PipelineTemplateViewRule>>() {
            }.getType());
        } catch (Exception e) {
            LOGGER.error("Error : {}", e);
        }
        return pipelineTemplateViewRules;
    }



    private ResponseEntity<Object> catchException(Exception e) {
        LOGGER.error("Error : {}", e);
        advancedPropertyResModel.setStatus(false);
        advancedPropertyResModel.setInformation(new ExceptionBean(new Date(), "Error", "Something went wrong. Please try again."));
        mappingJacksonValue = FilterUtil.advancePropResFilter(advancedPropertyResModel, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }

    private ResponseEntity<Object> responseFalseValidation(String description) {
        advancedPropertyResModel.setStatus(false);
        advancedPropertyResModel.setInformation(new ExceptionBean(new Date(), "Operation  Failed", description));
        mappingJacksonValue = FilterUtil.advancePropResFilter(advancedPropertyResModel, new String[]{STATUS, "information"});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }
}
