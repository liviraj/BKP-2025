package com.histo.wgs.service.impl;

import com.google.gson.Gson;
import com.histo.wgs.config.PropertyConfiguration;
import com.histo.wgs.exception.InternalServerException;
import com.histo.wgs.model.*;
import com.histo.wgs.repository.WGSStatusViewerRepository;
import com.histo.wgs.service.DataDeletionService;
import com.histo.wgs.service.WGSRunDao;
import com.histo.wgs.util.WGSUtil;
import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.*;

@Service
@Scope(value = "prototype", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class WGSRunProcessImp implements WGSRunDao {
    private static final Logger logger = LogManager.getLogger(WGSRunProcessImp.class.getName());
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private Environment env;
    @Autowired
    private PropertyConfiguration propertyConfiguration;
    @Autowired
    private WGSStatusViewerRepository wgsStatusViewerRepository;
    @Autowired
    private DataDeletionService dataDeletionService;

    @Override
    public String updateWGSRunStatusFromSMRTPortal(List<WGSRunStatusUpdateFromSMRT> wGSRunStatusUpdateFromSMRT) {
        try {
            for (WGSRunStatusUpdateFromSMRT data : wGSRunStatusUpdateFromSMRT) {
                String startDate = null;
                String endDate = null;
                if (StringUtils.isNotBlank(data.getStartedAt())) {
                    startDate = WGSUtil.convertSDateEDTToNormal(data.getStartedAt());
                }
                if (StringUtils.isNotBlank(data.getCompletedAt())) {
                    endDate = WGSUtil.convertSDateEDTToNormal(data.getCompletedAt());
                }
                jdbcTemplate.update("exec WGSUpdateRunStatusFromSMRTPortal" + " ?,?,?,?,?,?,?,?;",
                        data.getWGSRunID(), data.getWGSStatusViewerID(), data.getRunStatusID(),
                        data.getRawDataPath(), data.getWGSStaticsPDFPath(), data.getInstrumentName()
                        , startDate, endDate);
            }

            for (WGSRunStatusUpdateFromSMRT data : wGSRunStatusUpdateFromSMRT) {
                WGSRunDataToLocalPathCopy getData = returnWGSRunDetailsToCopySourcePath(data.getWGSStatusViewerID(),
                        "rawdata");
                if (getData.getAnalysisStatusID() == 5 && data.getRunStatusID() == 3) { // LocalTransfer should happen only if rawdata(5) and Status is completed(3)
                    if (getData.getRunName() != null || getData.getRawDataPath() != null) {
                        WGSRunDataToLocalPathCopy rawSourcePathDetails = getRawSourcePathOrganized(
                                getData.getRawDataPath(), "rawdata");
                        ExecutorService executor = Executors.newSingleThreadExecutor();
                        executor.submit(() -> {
                            String destPath = getData.getRunName() + "/raw_data/";
                            localCopyProcess(rawSourcePathDetails.getRawSourcePath(), destPath, data.getWGSRunID(),
                                    data.getWGSStatusViewerID(), false);
                        });

                    } else {
                        logger.info("RaDatapath is null from SMRTportal");
                    }
                }

            }
        } catch (Exception e) {
            logger.error("Error :" + e.getMessage());
            insertWGSLogInfo(wGSRunStatusUpdateFromSMRT.get(0).getWGSRunID(),
                    wGSRunStatusUpdateFromSMRT.get(0).getWGSStatusViewerID(), e.getMessage(),
                    "PacbioMiscellaneousWebService");
            throw new InternalServerException("Failure :" + e.getMessage());
        }

        return "Success";
    }

    @Override
    public void wgsRunForceRestartSMRT(WGSRunStatusUpdateFromSMRT data) {
        String result = null;
        try {
            logger.info("wgsRunForceRestartSMRT in progress...");
            result = jdbcTemplate.queryForObject("exec WGSUpdateForceRestartSMRT" + " ?,?,?;"
                    , String.class
                    , data.getWGSStatusViewerID(), data.getRunStatusID(), data.getUserID()
            );
            logger.info("wgsRunForceRestartSMRT Completed...");
            insertWGSLogInfo(0,
                    data.getWGSStatusViewerID(), "RunStatus Force Restart :" + result, "PacbioMiscellaneousWebService");
        } catch (Exception e) {
            logger.error("Error :" + e.getMessage());
            e.getMessage();
        }
    }

    public WGSRunDataToLocalPathCopy getRawSourcePathOrganized(String sourceDataPath, String dataType) {
        WGSRunDataToLocalPathCopy data = new WGSRunDataToLocalPathCopy();
        String[] splitedPath = sourceDataPath.split("/");
        StringBuilder sourcePath = new StringBuilder();
        String pathAppend = "";
        for (int i = 0; i < splitedPath.length; i++) {
            String value = splitedPath[i];
            if (value.contains("shared"))
                pathAppend = "//histonas2/pbvol1/";
            else if (value.contains(".xml")) {
                data.setBaseFolder(splitedPath[i - 1]);
                pathAppend = "";
            } else if (!value.isEmpty())
                pathAppend = splitedPath[i] + "/";
            sourcePath.append(pathAppend);
        }
        if (dataType.equals("rawdata"))
            data.setRawSourcePath(sourcePath.toString());
        else
            data.setAnalysisDataPath(sourcePath.toString());

        return data;
    }

    @Override
    public String updateWGSRunStatusFromShellScript(WGSRunStatusUpdateShellScript dataFromSMRT) {
        try {
            jdbcTemplate.update("exec WGSUpdateRunStatusFromShellScript ?,?,?,?;",
                    dataFromSMRT.getWGSRunID(), dataFromSMRT.getWGSStatusViewerID(),
                    dataFromSMRT.getAnalysisStatusID(), dataFromSMRT.getAnalysisDataPath());
            if (dataFromSMRT.getAnalysisStatusID() == 3) {

                WGSRunDataToLocalPathCopy getData = returnWGSRunDetailsToCopySourcePath(
                        dataFromSMRT.getWGSStatusViewerID(), "ccs");
                if (getData.getRunName() != null || getData.getAnalysisDataPath() != null) {
                    ExecutorService executor = Executors.newSingleThreadExecutor();
                    executor.submit(() -> {
                        String destPath = getData.getRunName() + "/ccs_data/";
                        ScheduledExecutorService scheduledExecutorService = Executors.newScheduledThreadPool(5);
                        ScheduledFuture<?> scheduledFuture = scheduledExecutorService.schedule(() -> localCopyProcess(dataFromSMRT.getAnalysisDataPath().replace("\\", "/"), destPath,
                                        dataFromSMRT.getWGSRunID(), dataFromSMRT.getWGSStatusViewerID(), true), 20, // 20 seconds to wait
                                TimeUnit.SECONDS);
                        scheduledExecutorService.shutdown();
                    });
                    executor.shutdown();

                } else {
                    logger.info("LocalTransfer is not started due to AnalysisStatusID is " + dataFromSMRT.getAnalysisStatusID());
                }
            }

        } catch (Exception e) {
            logger.error(e.getMessage());
            insertWGSLogInfo(dataFromSMRT.getWGSRunID(), dataFromSMRT.getWGSStatusViewerID(), e.getMessage(),
                    "PacbioMiscellaneousWebService");
            throw new InternalServerException("Failure :" + e.getMessage());
        }
        return "Success";
    }

    @Override
    public String updateWGSCloudFileRunStatusFromShellScript(WGSUpdateCloudFileTransferStatusShellScript dataFromSMRT) {
        try {
            jdbcTemplate.update("update WGSStatusViewer set AnalysisDataPath=?,CloudFileTransfer=(select StatusID from WGSStatusMaster where Status=?) where WGSStatusViewerID=?",
                    dataFromSMRT.getAnalysisDataPath(), dataFromSMRT.getCloudFileTransfer(), dataFromSMRT.getWGSStatusViewerID());
            if (dataFromSMRT.getCloudFileTransfer().equals("Completed")) {

                WGSRunDataToLocalPathCopy getData = returnWGSRunDetailsToCopySourcePath(
                        dataFromSMRT.getWGSStatusViewerID(), "ccs");
                if (getData.getRunName() != null || getData.getAnalysisDataPath() != null) {
                    ExecutorService executor = Executors.newSingleThreadExecutor();
                    executor.submit(() -> {
                        String destPath = getData.getRunName() + "/ccs_data/";
                        ScheduledExecutorService scheduledExecutorService = Executors.newScheduledThreadPool(5);
                        ScheduledFuture<?> scheduledFuture = scheduledExecutorService.schedule(() -> localCopyProcess(dataFromSMRT.getAnalysisDataPath().replace("\\", "/"), destPath,
                                        dataFromSMRT.getWGSRunID(), dataFromSMRT.getWGSStatusViewerID(), true), 20, // 20 seconds to wait
                                TimeUnit.SECONDS);
                        scheduledExecutorService.shutdown();
                    });
                    executor.shutdown();
                }
            }

        } catch (Exception e) {
            logger.error(e.getMessage());
            insertWGSLogInfo(dataFromSMRT.getWGSRunID(), dataFromSMRT.getWGSStatusViewerID(), e.getMessage(),
                    "PacbioMiscellaneousWebService");
            throw new InternalServerException("Failure :" + e.getMessage());
        }
        return "Success";

    }

    private WGSRunDataToLocalPathCopy returnWGSRunDetailsToCopySourcePath(int wgsStatusViewerId, String dataType) {
        WGSRunDataToLocalPathCopy wgsRunDetails;
        try {
            wgsRunDetails = jdbcTemplate.queryForObject("exec WGSReturnJobsToCopyLocalPath ?,?;"
                    , BeanPropertyRowMapper.newInstance(WGSRunDataToLocalPathCopy.class)
                    , wgsStatusViewerId, dataType
            );
        } catch (Exception e) {
            logger.info("Error :" + e.getMessage());
            throw new InternalServerException(e.getMessage());
        }

        return wgsRunDetails;
    }

    @Override
    public WGSRoot rerunWGSRunData(String programType) {
        logger.info("/getWGSRunData in progress..");
        WGSRoot wgsRoot = new WGSRoot();
        List<WGSRunMaster> wgsRunMasterListRoot = new ArrayList<>();
        List<WGSRunMaster> wgsRunMasterList;
        String queryForCCS = "";
        try {
            if (programType.contains("smrt")) {
                wgsRunMasterList = jdbcTemplate.query("exec WGSReturnRunDetailsToSMRTPortal;",
                        BeanPropertyRowMapper.newInstance(WGSRunMaster.class));
            } else {
                wgsRunMasterList = jdbcTemplate.query("exec WGSReturnRunDetailsToShellScript;",
                        BeanPropertyRowMapper.newInstance(WGSRunMaster.class));
                queryForCCS = " and AnalysisStatusID=1";
            }

            for (WGSRunMaster runMasterData : wgsRunMasterList) {
                List<WGSRunDetail> wGSRunDetails = jdbcTemplate.query("select * from WGSRunDetails where WGSRunID = ?;",
                        BeanPropertyRowMapper.newInstance(WGSRunDetail.class), runMasterData.getWGSRunID());
                List<WGSStatusViewer> wGSStatusViewer = jdbcTemplate.query(
                        " select * from WGSStatusViewer where WGSRunID = ? and LocalTransferID not in(2,3) "
                                + queryForCCS + ";",
                        BeanPropertyRowMapper.newInstance(WGSStatusViewer.class), runMasterData.getWGSRunID());
                runMasterData.setwGSRunDetails(wGSRunDetails);
                runMasterData.setwGSStatusViewer(wGSStatusViewer);
                wgsRunMasterListRoot.add(runMasterData);
            }
            wgsRoot.setWGSRunMaster(wgsRunMasterListRoot);
            wgsRoot.setWGSStatusMaster(jdbcTemplate.query("select * from WGSStatusMaster;",
                    BeanPropertyRowMapper.newInstance(WGSStatusMaster.class)));
            wgsRoot.setWGSSizeConstraints(jdbcTemplate.query("select * from WGSSizeConstraints;",
                    BeanPropertyRowMapper.newInstance(WGSSizeConstraints.class)));
        } catch (Exception e) {
            logger.error("Error :" + e.getMessage());
            insertWGSLogInfo(-1, -1, e.getMessage(), "PacbioMiscellaneousWebService");
            throw new InternalServerException(e.getMessage());
        }

        return wgsRoot;
    }

    @Override
    public void validateAccessToken(Map<String, String> attributesData, int wgsStatusViewerId) {
        try {

            if (attributesData.get("CredentialJson") == null || attributesData.get("CredentialJson").isEmpty()) {
                tokenIdFromGlobus(attributesData, wgsStatusViewerId);
            } else {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Instant instant = Instant
                        .ofEpochSecond(Integer.parseInt(attributesData.get("GlobusAuthTokenExpiryTime")));
                Date convertedDate = Date.from(instant);
                LocalDate startDate = LocalDate.now();
                if (startDate.isAfter(LocalDate.parse(sdf.format(convertedDate)).minusDays(2))
                        || Integer.parseInt(attributesData.get("GlobusAuthTokenExpiryTime")) == 0) {
                    tokenIdFromGlobus(attributesData, wgsStatusViewerId);
                }
            }

        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

    @Override
    public void callFileMover(int wgsStatusViewerId, Map<String, String> attributesData) {
        try {
            if (attributesData.get("WGSDataTransferType").equals("GLOBUS")) {
                validateAccessToken(attributesData, wgsStatusViewerId);
            }
            if ((attributesData.containsKey("WGSStatisticsRequired")
                    && attributesData.get("WGSStatisticsRequired").equals("Y"))) {
                uploadPDFFileToDestinationPath(wgsStatusViewerId);
            }

            Gson gson = new Gson();
            FileUploaderArgs args = new FileUploaderArgs();
            String subFolderCCSorRAW = "";
            RunData runData = jdbcTemplate.queryForObject(
                    """
                            select wgsR.RunName, wgsS.sourcePath
                            from WGSRunMaster wgsR
                            join WGSStatusViewer wgsS on wgsR.WGSRunID = wgsS.WGSRunID
                            where WGSStatusViewerID = ?;
                            """,
                    new BeanPropertyRowMapper<>(RunData.class), wgsStatusViewerId);
            assert runData != null;
            if (runData.getSourcePath().contains("ccs_data")) {
                subFolderCCSorRAW = "/ccs_data";
            } else {
                subFolderCCSorRAW = "/raw_data";
            }

            if (attributesData.get("WGSDataTransferType").equals("GLOBUS")
                    || attributesData.get("WGSDataTransferType").equals("SFTP")) {
                File fileUploaderJarPath = new File(env.getProperty("WGSAutomation.FileUploaderJarPath"));
                if (fileUploaderJarPath.exists()) {
                    logger.error("File uploader jar not present in the location :"
                            + env.getProperty("WGSAutomation.FileUploaderJarPath"));
                    insertWGSLogInfo(0, wgsStatusViewerId,
                            "File uploader jar not presentin the location :"
                                    + env.getProperty("WGSAutomation.FileUploaderJarPath"),
                            "PacbioMiscellaneousWebService");
                    return;
                }
                logger.info("File uploader is starting Type : " + attributesData.get("WGSDataTransferType"));
                String command = "";

                if (attributesData.get("WGSDataTransferType").equals("GLOBUS")) {
                    String wgsDataSourcePath = env.getProperty("wgs.automation.data-source-path").replace("?", attributesData.get("ClientName"));
                    /*if (wgsDataSourcePath.contains(" ")) {
                        wgsDataSourcePath = "\"" + wgsDataSourcePath + "\"";
                    }*/

                    args.setUploadType(UploadType.GLOBUS);
                    args.setUsername(attributesData.get("WGSClientUserName"));
                    args.setPassword(attributesData.get("WGSClientPassword"));
                    args.setFolder(true);
                    args.setoAuth(attributesData.get("CredentialJson"));
                    args.setSourceEndPoint(attributesData.get("WGSGlobusSourceEndPoint"));
                    args.setDestinationEndPoint(attributesData.get("WGSGlobusDestinationEndPoint"));
                    args.setSourceParentPath(URLEncoder.encode(wgsDataSourcePath, StandardCharsets.UTF_8));
                    args.setDestinationParentPath(attributesData.get("WGSDataDestinationPath"));
                    args.setRunName(runData.getRunName() + subFolderCCSorRAW);
                    args.setWgsStatusViewerID(wgsStatusViewerId);
                } else if (attributesData.get("WGSDataTransferType").equals("SFTP")) {
                    args.setUploadType(UploadType.SFTP);
                    args.setUsername(env.getProperty("wgs.automation.source.username"));
                    args.setPassword(env.getProperty("wgs.automation.source.password"));
                    args.setFolder(true);
                    args.setSftpClientDomain(attributesData.get("WGSClientDomainURL"));
                    args.setSftpUserName(attributesData.get("WGSClientUserName"));
                    args.setSftpPassword(attributesData.get("WGSClientPassword"));
                    args.setSourceParentPath(URLEncoder.encode(runData.getSourcePath(), StandardCharsets.UTF_8));
                    args.setDestinationParentPath(URLEncoder.encode(attributesData.get("WGSDataDestinationPath"), StandardCharsets.UTF_8));
                    args.setRunName(URLEncoder.encode(runData.getRunName() + subFolderCCSorRAW, StandardCharsets.UTF_8));
                    args.setWgsStatusViewerID(wgsStatusViewerId);
                }
                String argsJsonString = gson.toJson(args);

                command = "java -jar " + env.getProperty("WGSAutomation.FileUploaderJarPath")//attributesData.get("FileUploaderJarPath")
                        + " " + argsJsonString;
                logger.info("File uploader command is " + command);
                Process proc = Runtime.getRuntime().exec(command);
                // https://stackoverflow.com/questions/5483830/process-waitfor-never-returns
                BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream()));
                String line;
                logger.info("Process Status :");
                while ((line = reader.readLine()) != null) {
                    logger.info(line);
                }
                proc.waitFor();
                reader.close();
            } else {
                logger.error("Not applicable for file transfer program.");
            }
        } catch (Exception e) {
            Thread.currentThread().interrupt();
            logger.error("Error :" + e.getMessage());
            insertWGSLogInfo(0, wgsStatusViewerId, e.getMessage(), "PacbioMiscellaneousWebService");
        }
    }

    public void uploadPDFFileToDestinationPath(int wgsStatusViewerId) {
        WGSStaticsPDFPathData dataObj = new WGSStaticsPDFPathData();
        try {
            dataObj = jdbcTemplate.queryForObject("exec WGSStaticsPDFPathbyWGSStatusViewerID ?;",
                    new BeanPropertyRowMapper<>(WGSStaticsPDFPathData.class), wgsStatusViewerId);

        } catch (Exception e) {
            logger.info("Error :" + e.getMessage());
            dataObj.setDestinationPath("");
            dataObj.setWgsStaticsPDFPath("");
        }
        try {
            assert dataObj != null;
            if (dataObj.getDestinationPath() == null || dataObj.getDestinationPath().isEmpty()) {
                logger.error("Error : Destination path is null or empty for WGSStausViewerId" + wgsStatusViewerId);
            } else {
                if (dataObj.getWgsStaticsPDFPath() == null || dataObj.getWgsStaticsPDFPath().isEmpty()) {
                    logger.error("Error : WgsStaticsPDFPath is null or empty");

                } else {
                    dataObj.setDestinationPath(dataObj.getDestinationPath().replace("\\", "/"));// .replaceAll("ccs_data/|raw_data/",""));
                    if (dataObj.getWgsStaticsPDFPath().contains("\\")) {
                        dataObj.setWgsStaticsPDFPath(dataObj.getWgsStaticsPDFPath().replace("\\", "/"));
                    }
                    copyPDFFile(dataObj);
                }
            }
        } catch (Exception e) {
            logger.info("Error :" + e.getMessage());
            insertWGSLogInfo(0, wgsStatusViewerId, e.getMessage(), "PacbioMiscellaneousWebService");

        }

    }

    public void copyPDFFile(WGSStaticsPDFPathData wgsStaticsPDFPathData) {
        try {
            String pdfPath = wgsStaticsPDFPathData.getWgsStaticsPDFPath();
            if (!pdfPath.isEmpty()) {
                if (pdfPath.endsWith(".pdf") || pdfPath.endsWith(".PDF")) {
                    NtlmPasswordAuthentication sourceAuth = new NtlmPasswordAuthentication(null,
                            env.getProperty("wgs.automation.source.username"),
                            env.getProperty("wgs.automation.source.password"));
                    NtlmPasswordAuthentication destAuth = new NtlmPasswordAuthentication(null,
                            env.getProperty("WGSAutomation.DestUserName"),
                            env.getProperty("WGSAutomation.DestPassword"));
                    SmbFile pdfSourcePath = new SmbFile("smb:" + pdfPath, sourceAuth);
                    if (pdfSourcePath.exists()) {
                        SmbFile destFolder = new SmbFile("smb:" + wgsStaticsPDFPathData.getDestinationPath(), destAuth);
                        SmbFile destPDFPath = new SmbFile(destFolder + "PDF/");
                        if (!destPDFPath.exists()) {
                            destPDFPath.mkdir();
                        }
                        SmbFile destPDFFile = new SmbFile(destPDFPath + pdfSourcePath.getName());
                        if (!destPDFFile.exists()) {
                            destPDFFile.createNewFile();
                            pdfSourcePath.copyTo(destPDFFile);
                        } else {
                            if (getFileOrFolderSize(pdfSourcePath) != getFileOrFolderSize(destPDFFile)) {
                                pdfSourcePath.copyTo(destPDFFile);
                            }
                        }
                    } else {
                        logger.error("Error : Source PDF path not exists.");
                    }

                } else {
                    logger.error("Error : File is not PDF.");
                }
            }
        } catch (Exception e) {
            logger.error("Error :" + e.getMessage());
        }

    }

    public static long getFileOrFolderSize(SmbFile sourceFile) {
        long length = 0;
        try {
            if (sourceFile.isFile())
                return sourceFile.length();
            for (SmbFile file : sourceFile.listFiles()) {

                if (file.isFile())
                    length += file.length();
                else
                    length += getFileOrFolderSize(file);
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return length;
    }

    public AuthDetails getAuthDetailsFromDB(int uploadType) {
        AuthDetails dataObj = new AuthDetails();
        try {
            dataObj = jdbcTemplate.queryForObject("select * from WGSCredentialInfo where uploadtypeID=?"
                    , BeanPropertyRowMapper.newInstance(AuthDetails.class)
                    , uploadType
            );

        } catch (Exception e) {
            logger.info("Error :" + e.getMessage());
        }

        return dataObj;
    }

    public void tokenIdFromGlobus(Map<String, String> attributesData, int wgsStatusViewerId) {
        try {
            String userNamePassword = attributesData.get("WGSClientUserName") + ":"
                    + attributesData.get("WGSClientPassword");
            Process proc = Runtime.getRuntime()
                    .exec("curl --user " + userNamePassword + " " + attributesData.get("WGSClientDomainURL") + "");
            proc.waitFor();
            // Then retreive the process output
            InputStream in = proc.getInputStream();
            byte[] b = new byte[in.available()];
            in.read(b, 0, b.length);
            String jsonString = new String(b);
            logger.info(jsonString);
            JSONObject jsonObj = new JSONObject(jsonString);
            if (jsonObj.has("token_id")) {
                int expiry = jsonObj.getInt("expiry");
                jdbcTemplate.update("exec WGSupdateGlobusAccesstokenDetailsIfExpired ?,?,? ",
                        wgsStatusViewerId, jsonString, expiry);
                // Get the attributes
                //  attributesData = getAttributesValues(wgsStatusViewerId);

            } else {
                logger.info("not found");
            }

        } catch (Exception e) {
            logger.error("Error :" + e.getMessage());
            Thread.currentThread().interrupt();
        }

    }

    @Override
    public String updateWGSGlobusTransferStatus(WgsClientTransferStatus statusData) {
        try {
            logger.info("wgsClientTransferStatus update started");
            jdbcTemplate.update("exec WGSUpdateGlobusTransferStatus ?,?,?", statusData.getStatus(),
                    statusData.getDestinationUplodPath(), statusData.getWGSStatusViewerID());
        } catch (Exception e) {
            logger.error("Error :" + e.getMessage());
            return "updates failure :" + e.getMessage();
        }
        logger.info("wgsClientTransferStatus update completed");
        return "Success";
    }

    @Override
    public void localCopyProcess(String sourcePath, String destPath, int wgsRunID, int wgsStatusViewerID,
                                 boolean isDS03) {
        try {
            Map<String, String> attributesData = getAttributesValues(wgsStatusViewerID);
            Gson gson = new Gson();
            String command = null;
            Path filePath = Paths.get(propertyConfiguration.getPacbioFileDataOrganizerJarPath());
            boolean isJarFileExist = Files.exists(filePath);
            if (!isJarFileExist) {
                if (sourcePath.contains("/shared")) {
                    WGSRunDataToLocalPathCopy data = getRawSourcePathOrganized(sourcePath,
                            isDS03 ? "ccsdata" : "rawdata");
                    sourcePath = data.getRawSourcePath();
                }
                // this check for restart the localcopy process from scheduler
                String destPath2 = destPath.replace("\\", "/");
                logger.info("destPath " + destPath);
                logger.info("destPath2 " + destPath2);
                String localDestinationPath = propertyConfiguration.getWgsAutomationLocalDestinationPath().replace("?",
                        attributesData.get("ClientName"));
                if (!localDestinationPath.endsWith("/")) {
                    localDestinationPath += "/";
                }
                logger.info("LocalDestinationPath " + localDestinationPath);
                String restartLocalPathWithoutQuotes = localDestinationPath;

                if (destPath2.contains(restartLocalPathWithoutQuotes)) { // attributesData.get("WGSLocalDestinationPath")
                    destPath = destPath2.replace(restartLocalPathWithoutQuotes, "");
                }
                logger.info("destPath " + destPath);
                localDestinationPath = localDestinationPath + destPath;

                // Split server name and share name in source path;
                sourcePath = sourcePath.replace("\\", "/");
                List<String> sourceSplit = new ArrayList<>(Arrays.stream(sourcePath.split("/"))
                        .filter(path -> !path.equalsIgnoreCase("")).toList());
                sourcePath = sourcePath.replace("//", "").replace(sourceSplit.get(0) + "/", "").replace(sourceSplit.get(1) + "/", "");

                if (!sourceSplit.get(0).endsWith("." + propertyConfiguration.getDeletionSmbDomain())) {
                    sourceSplit.set(0, sourceSplit.get(0) + "." + propertyConfiguration.getDeletionSmbDomain());
                }
                // Split server name and share name in destination path;
                localDestinationPath = localDestinationPath.replace("\\", "/");
                List<String> destinationSplit = Arrays.stream(localDestinationPath.split("/"))
                        .filter(path -> !path.equalsIgnoreCase("")).toList();
                localDestinationPath = localDestinationPath.replace("//", "").replace(destinationSplit.get(0) + "/", "").replace(destinationSplit.get(1) + "/", "");

                FileDataOrganizerArgs inputArgs = new FileDataOrganizerArgs();
                inputArgs.setSourceServer(sourceSplit.get(0));
                inputArgs.setSourceShare(sourceSplit.get(1));
                inputArgs.setDestinationServer(destinationSplit.get(0));
                inputArgs.setDestinationShare(destinationSplit.get(1));
                inputArgs.setSourceDirectory(sourcePath);
                String encodedURL = URLEncoder.encode(localDestinationPath, StandardCharsets.UTF_8.name());
                inputArgs.setDestinationDirectory(encodedURL);
                inputArgs.setDestinationUsername(env.getProperty("wgs.automation.destination.username"));
                inputArgs.setDestinationPassword(env.getProperty("wgs.automation.destination.password"));
                inputArgs.setCopyDataNumberOfDaysBack(365);
                inputArgs.setStatusViewerId(wgsStatusViewerID);
                inputArgs.setActionType(String.valueOf(ActionType.COPY));
                inputArgs.setFileSizeInMB(10);
                if (isDS03) {
                    inputArgs.setSourceUsername(env.getProperty("wgs.automation.source.username"));
                    inputArgs.setSourcePassword(env.getProperty("wgs.automation.source.password"));
                } else {
                    inputArgs.setSourceUsername(env.getProperty("wgs.automation.destination.username"));
                    inputArgs.setSourcePassword(env.getProperty("wgs.automation.destination.password"));
                }

                String argsJsonString = gson.toJson(inputArgs);
                command = "java -jar " + env.getProperty("WGSAutomation.PacBioFileDataJarPath") + " " + argsJsonString;
                logger.info("Pacbio file data organizer path " + command);
                Process proc = Runtime.getRuntime().exec(command);
                proc.waitFor();
                // Then retreive the process output
                InputStream in = proc.getInputStream();
                InputStream err = proc.getErrorStream();

                byte[] b = new byte[in.available()];
                in.read(b, 0, b.length);
                logger.info(new String(b));
                byte[] c = new byte[err.available()];
                err.read(c, 0, c.length);
                logger.info(new String(c));
            } else {
                logger.error("PacBioFileDataOrganizer Jar Missing or Path is wrong");
                insertWGSLogInfo(wgsRunID, wgsStatusViewerID, "PacBioFileDataOrganizer Jar Missing",
                        "PacbioMiscellaneousWebService");
            }
        } catch (Exception e) {
            Thread.currentThread().interrupt();
            logger.error("Error :" + e.getMessage());
            insertWGSLogInfo(wgsRunID, wgsStatusViewerID, e.getMessage(), "PacbioMiscellaneousWebService");
        }
    }

    @Override
    public String insertWGSLogInfo(int wgsRunID, int wgStatusViewerID, String log, String programName) {
        try {
            jdbcTemplate.update("exec WGSInsertErrorLog ?,?,?,?",
                    wgsRunID, wgStatusViewerID, log, programName);
        } catch (Exception e) {
            logger.error("Error :" + e.getMessage());
            return "Failure:" + e.getMessage();
        }
        return "Success";
    }

    @Override
    public List<WGSRestartLocalCopyProcessInput> getListOfRestartRunForLocalCopyProcess() {
        List<WGSRestartLocalCopyProcessInput> wgsRestartLocalCopyProcessInput = new ArrayList<>();
        try {
            wgsRestartLocalCopyProcessInput = jdbcTemplate.query("exec WGSGetFailedRunDetails ?;"
                    , new BeanPropertyRowMapper<>(WGSRestartLocalCopyProcessInput.class));
        } catch (Exception e) {
            logger.error("Error :" + e.getMessage());
        }
        return wgsRestartLocalCopyProcessInput;
    }

    @Override
    public WGSRestartLocalCopyProcessInput getFailedRunInputForLocalCopy(int wgsStatusViewerId) {
        WGSRestartLocalCopyProcessInput wgsRestartLocalCopyProcessInput = new WGSRestartLocalCopyProcessInput();
        try {
            wgsRestartLocalCopyProcessInput = jdbcTemplate.queryForObject("exec WGSGetFailedRunDetails ?;"
                    , new BeanPropertyRowMapper<>(WGSRestartLocalCopyProcessInput.class)
                    , wgsStatusViewerId);
        } catch (Exception e) {
            logger.error("Error :" + e.getMessage());
        }
        return wgsRestartLocalCopyProcessInput;
    }

    @Override
    public Map<String, String> getAttributesValues(int wgsStatusViewerId) {
        logger.info("fetching attribute values");
        HashMap<String, String> data = jdbcTemplate.query("exec WGS_GetClientProjectAttributes ?;"
                , (ResultSet rs) -> {
                    HashMap<String, String> results = new HashMap<>();
                    while (rs.next()) {
                        results.put(rs.getString("AttributeName"), rs.getString("AttributeValue"));
                    }
                    return results;
                }, wgsStatusViewerId);
        assert data != null;
        if (data.containsKey("CredentialJson") && (data.get("CredentialJson") != null)) {
            String[] splitCredJson = data.get("CredentialJson").split("\"access_token\":\"");
            String[] splitCredToPassFileUploader = splitCredJson[1].split(",");
            data.put("CredentialJson", splitCredToPassFileUploader[0].replace("\"", ""));

        }
        logger.info("fetching attribute values Completed");
        return data;
    }

    @Override
    public boolean updateLocalTransferStatus(LocalTransferIdStatus statusData) {
        logger.info("LocalTransferStatusId update");
        try {
            jdbcTemplate.update("exec WGSUpdateLocalTransferStatus ?,?,?", statusData.getStatus(),
                    statusData.getSourcePath(), statusData.getWgsStatusViewerId());
            logger.info("LocalTransferStatusId update completed");
        } catch (Exception e) {
            logger.error("Error :" + e.getMessage());
            return false;
        }
        return true;
    }

    @Override
    public String getRestartProgramNameByProgramId(int programId) {
        logger.info("getRestrtProgramNameByProgramId in progress");
        String programName = "";
        try {
            programName = jdbcTemplate.queryForObject(
                    "select WGSProgramName from WGSProgramMaster where WGSProgramID=?;"
                    , String.class
                    , programId);
            logger.info("getRestrtProgramNameByProgramId in progress completed");
        } catch (Exception e) {
            logger.error("Error :" + e.getMessage());
            return programName;
        }
        return programName;
    }

    @Override
    public ResponseEntity deleteWgsRSData(LocalTransferIdStatus localTransferData) {
        try {
            if (localTransferData.getStatus() == 3) {
                Optional<com.histo.wgs.entity.WGSStatusViewer> statusViewer = wgsStatusViewerRepository.findById(localTransferData.getWgsStatusViewerId());
                if (statusViewer.isPresent()) {
                    // Split server name and share name in source path;
                    String desPath = statusViewer.get().getSourcePath().replace("\\", "/");
                    if (!desPath.endsWith("/")) {
                        desPath = desPath.concat("/");
                    }
                    List<String> desPathSplit = Arrays.stream(desPath.split("/"))
                            .filter(path -> !path.equalsIgnoreCase("")).toList();
                    desPath = desPath.replace("//", "").replace(desPathSplit.get(0) + "/", "").replace(desPathSplit.get(1) + "/", "");

                    String sourcePath = statusViewer.get().getAnalysisDataPath().replace("\\", "/");
                    if (!sourcePath.endsWith("/")) {
                        sourcePath = sourcePath.concat("/");
                    }
                    List<String> sourcePathSplit = Arrays.stream(sourcePath.split("/"))
                            .filter(path -> !path.equalsIgnoreCase("")).toList();
                    sourcePath = sourcePath.replace("//", "").replace(sourcePathSplit.get(0) + "/", "").replace(sourcePathSplit.get(1) + "/", "");

                    DataDeletionModel dataDeletionModel = new DataDeletionModel();
                    dataDeletionModel.setDesPath(desPath);
                    dataDeletionModel.setDesSmbServerName(desPathSplit.get(0));
                    dataDeletionModel.setDesSmbShareName(desPathSplit.get(1));
                    dataDeletionModel.setDesSmbUsername(propertyConfiguration.getWgsAutomationDestUsername());
                    dataDeletionModel.setDesSmbPassword(propertyConfiguration.getWgsAutomationDestPassword());
                    dataDeletionModel.setWgsRunId(statusViewer.get().getWGSRunID().getId());
                    dataDeletionModel.setWgsStatusViewerId(statusViewer.get().getWGSStatusViewerID());

                    dataDeletionModel.setSourcePath(sourcePath);
                    dataDeletionModel.setSourceSMBServerName(sourcePathSplit.get(0));
                    dataDeletionModel.setSourceSMBShareName(sourcePathSplit.get(1));
                    dataDeletionModel.setSourceSMBUsername(propertyConfiguration.getWgsAutomationDestUsername());
                    dataDeletionModel.setSourceSMBPassword(propertyConfiguration.getWgsAutomationDestPassword());

                    dataDeletionService.deleteData(dataDeletionModel);
                }

            }
            return new ResponseEntity<>("RS data deleted successfully.", HttpStatus.CONFLICT);
        } catch (Exception e) {
            return catchException(e, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public String wgsFileTransferStatusMail(int wgsStausViewerID, String type, int result, String path) {
        logger.info("WGSFileTransferStatusMail in progress");
        String mailResult = "";
        try {
            mailResult = jdbcTemplate.queryForObject("WGSFileTransferStatusMail ?,?,?,?;"
                    , String.class
                    , wgsStausViewerID, type, result, path);
            logger.info("WGSFileTransferStatusMail in progress completed");
        } catch (Exception e) {
            logger.error("Error :" + e.getMessage());
            return e.getMessage();
        }
        return mailResult;
    }


    @Override
    public String sendMailForFileSizeFailed(WGSFileSizeFromSMRT input) {
        logger.info("mail format in progress");
        WGSFileSizeFromSMRT fileSizeFromDb = null;
        try {
            fileSizeFromDb = jdbcTemplate.queryForObject("exec WGSFileSizeByRunName ?;"
                    , new BeanPropertyRowMapper<>(WGSFileSizeFromSMRT.class)
                    , input.wgsStatusViewerID);
        } catch (Exception e) {
            logger.error("Error : RunName " + input.runName + " not found");
            return "Error : RunName " + input.runName + " not found";
        }

        StringBuilder buf = new StringBuilder();
        buf.append("<html>" + "<body> <br>" +
//		           "<p> Run "+input.runName+" is failed due to file size not met the criteria</p> <br>"+
                "<table border=\"1\">" + "<tr>" + "<th>         </th>" + "<th>TotalBase</th>"
                + "<th>HifiReadLength</th>" + "<th>LongestSubreads</th>" + "<th>HifiYield</th>" + "</tr>");
        buf.append("<tr><td>").append("ExpectedFileSize").append("</td><td>").append(Objects.requireNonNull(fileSizeFromDb).getTotalBase())
                .append("</td><td>").append(fileSizeFromDb.getHifiReadLength()).append("</td><td>")
                .append(fileSizeFromDb.getLongestSubreads()).append("</td><td>").append(fileSizeFromDb.getHifiYield())
                .append("</td></tr>").append("<tr><td>").append("ActualFileSize").append("</td><td>")
                .append(input.getTotalBase()).append("</td><td>").append(input.getHifiReadLength()).append("</td><td>")
                .append(input.getLongestSubreads()).append("</td><td>").append(input.getHifiYield())
                .append("</td></tr> <br>");

        buf.append("</table>" + "</body>" + "</html>");
        String html = buf.toString();
        try {
            logger.info("mail sending...");
            jdbcTemplate.queryForObject("exec WGSSendMailFileSizeMismatch ?,?;"
                    , String.class
                    , html, input.wgsStatusViewerID
            );
            logger.info("mail sent.");
        } catch (Exception e) {
            logger.error("Error :" + e.getMessage());
            return "Failed :" + e.getMessage();
        }
        return "Success";
    }

    // WGS automation
    @Override
    public List<WGSResModel> listOfCloudJobs() {
        List<WGSResModel> resModels;
        try {
            resModels = jdbcTemplate.query("exec WGSStatusViewerDetailsForClouldSMRT 'cloudJobs';",
                    BeanPropertyRowMapper.newInstance(WGSResModel.class));
        } catch (Exception e) {
            logger.info("Error :" + e.getMessage());
            throw new InternalServerException(e.getMessage());
        }

        return resModels;
    }

    @Override
    public WGSResModel wGSStatusViewerDetailsByRunName(String wGSRunName) {
        WGSResModel resModel;
        try {
            resModel = jdbcTemplate.queryForObject("exec WGSStatusViewerDetailsForClouldSMRT 'runName',?;"
                    , BeanPropertyRowMapper.newInstance(WGSResModel.class)
                    , wGSRunName);
        } catch (Exception e) {
            logger.info("Error :" + e.getMessage());
            throw new InternalServerException(e.getMessage());
        }

        return resModel;

    }

    @Override
    public String updateWGSCloudRunDetails(CloudRunDetail runDetail) {
        String response;
        try {
            response = jdbcTemplate.queryForObject("exec WGSUpdateCloudRunStatus  ?,?,?"
                    , String.class
                    , runDetail.getCloudRunStatus(), runDetail.getCloudCCSPath(), runDetail.getSMRTPortalViewerId());
        } catch (Exception e) {
            logger.info("Error :" + e.getMessage());
            throw new InternalServerException(e.getMessage());
        }

        return response;
    }

    @Override
    public void wgsAutomationRun(SMRTInputArgs inputArgs) {
        try {
            Gson gson = new Gson();
            String jsonString = gson.toJson(inputArgs);
            if (inputArgs != null) {

                String command = "java -cp " + env.getProperty("WGSAutomation.SMRTPortalViewerJarPath")
                        + " com.histo.SMRTPortalViewer.RemoteApp " + jsonString;

                Process proc = Runtime.getRuntime().exec(command);

                // https://stackoverflow.com/questions/5483830/process-waitfor-never-returns
                BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream()));
                String line;
                logger.info("Process Status :");
                while ((line = reader.readLine()) != null) {
                    logger.info(line);
                }
                proc.waitFor();
            }
        } catch (Exception e) {
            logger.info("Error :" + e.getMessage());
            Thread.currentThread().interrupt();
        }
    }

    @Override
    public String wGSUpdateCloudFileTransferStatus(CloudFileTransferStatus status) {
        String response;
        try {
            response = jdbcTemplate.queryForObject("exec WGSUpdateCloudFileTransferStatus  ?,?"
                    , String.class
                    , status.getWGSStatusViewerID(), status.getCloudFileTransferStatus());
        } catch (Exception e) {
            logger.info("Error :" + e.getMessage());
            throw new InternalServerException(e.getMessage());
        }

        return response;
    }

    @Override
    public String wgsFileTransferStatusMail(WGSFileTransferStatusMailInput input) {
        logger.info("WGSFileTransferStatusMail in progress");
        String result = "";
        try {
            result = jdbcTemplate.queryForObject("WGSFileTransferStatusMail ?,?;"
                    , String.class
                    , input.getWgsStatusViewerId(), input.getStatusContent());
            logger.info("WGSFileTransferStatusMail in progress completed");
        } catch (Exception e) {
            logger.error("Error :" + e.getMessage());
            return result;
        }
        return result;
    }

    @Override
    public Integer getWGSRunTypeForWGSStatusViewerId(int wgsStatusViewerId) {
        logger.info("WGSRunType DB process in progress");
        Integer runTypeId = 0;
        try {
            runTypeId = jdbcTemplate.queryForObject("exec WGS_GetRunTypeRAWorCCS ?;",
                    Integer.class, wgsStatusViewerId);


            logger.info("WGSRunType DB process completed");
        } catch (Exception e) {
            logger.error("Error :" + e.getMessage());
        }
        return runTypeId;
    }

    @Override
    public ResponseEntity<Object> insertLogDetail(LogDetailModel logDetail) {
        try {
            String sql = "INSERT INTO LogDetail (ActionType,SourceLocation,DestinationLocation,DeleteLocation,Status,Program) VALUES (?,?,?,?,?,?);";
            jdbcTemplate.update(sql
                    , logDetail.getActionType()
                    , logDetail.getSourceLocation()
                    , logDetail.getDestinationLocation()
                    , logDetail.getDeleteLocation()
                    , logDetail.getStatus()
                    , logDetail.getProgram()
            );
            return new ResponseEntity<>("Success", HttpStatus.OK);
        } catch (Exception e) {
            return catchException(e, HttpStatus.CONFLICT);
        }
    }

    @Override
    public ResponseEntity<Object> saveMd5ChecksumDetails(Map<String, String> checksumDetails, Integer wgsRunId) {
        try {
            String sqlWgsRunMaster = "SELECT  * FROM WGSRunMaster WHERE WGSRunId = ?";
            List<WGSRunMaster> wgsRunMaster = jdbcTemplate.query(sqlWgsRunMaster, new BeanPropertyRowMapper<>(WGSRunMaster.class), wgsRunId);
            if (wgsRunMaster.isEmpty()) {
                return new ResponseEntity<>("WGSRunId not found", HttpStatus.CONFLICT);
            }
            String sql = "INSERT INTO WGSMD5Checksum (WGSRunId, Filename, MD5ChecksumValue) VALUES (?,?,?);";
            List<Map.Entry<String, String>> checksumList = new ArrayList<>(checksumDetails.entrySet());
            jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement preparedStatement, int i) throws SQLException {
                    Map.Entry<String, String> entry = checksumList.get(i);
                    preparedStatement.setInt(1, wgsRunId);
                    preparedStatement.setString(2, entry.getKey());
                    preparedStatement.setString(3, entry.getValue());
                }

                @Override
                public int getBatchSize() {
                    return checksumList.size();
                }
            });
            return new ResponseEntity<>("Saved Successfully", HttpStatus.OK);
        } catch (Exception e) {
            return catchException(e, HttpStatus.CONFLICT);
        }
    }

    @Override
    public ResponseEntity<Object> executeMd5Checksum(LocalTransferIdStatus statusData) {
        try {
            // update source path
            statusData.setStatus(WgsStatusMasterEnum.IN_PROGRESS.getStatusId());
            updateLTSDetails(statusData);

            String sqlGetWgRunId = "SELECT  * FROM WGSStatusViewer WHERE WgsStatusViewerId = ?";
            List<WGSStatusViewer> wgsRunIds = jdbcTemplate.query(
                    sqlGetWgRunId
                    , new BeanPropertyRowMapper<>(WGSStatusViewer.class)
                    , statusData.getWgsStatusViewerId());
            if (wgsRunIds.isEmpty()) {
                return new ResponseEntity<>("WGSRunId not found", HttpStatus.CONFLICT);
            }
            Integer wgsRunId = wgsRunIds.get(0).getWGSRunID();

            String sqlWgsStatusViwer = "SELECT  * FROM WGSStatusViewer WHERE WgsStatusViewerId = ?";
            List<WGSStatusViewer> wgsStatusViewers = jdbcTemplate.query(sqlWgsStatusViwer
                    , new BeanPropertyRowMapper<>(WGSStatusViewer.class), statusData.getWgsStatusViewerId());
            if (wgsStatusViewers.isEmpty()) {
                return new ResponseEntity<>("WGSRunId not found", HttpStatus.CONFLICT);
            }
            WGSStatusViewer wgsStatusViewer = wgsStatusViewers.get(0);
            if (StringUtils.isBlank(wgsStatusViewer.getSourcePath())) {
                logger.info("Source-path is empty. To process. To process MD5Checksum source path should not be null/empty. StatusViewerId={}"
                        , wgsStatusViewer.getWGSStatusViewerID());
                return new ResponseEntity<>("Source-path is empty. To process. To process MD5Checksum source path should not be null/empty", HttpStatus.CONFLICT);
            }

            // Split server name and share name in source path;
            String checkSumPath = wgsStatusViewer.getSourcePath().replace("\\", "/");
            List<String> checkSumSplit = Arrays.stream(checkSumPath.split("/"))
                    .filter(path -> !path.equalsIgnoreCase("")).toList();
            checkSumPath = checkSumPath.replace("//", "").replace(checkSumSplit.get(0) + "/", "").replace(checkSumSplit.get(1) + "/", "");


            MD5ChecksumInputArgs inputArgs = new MD5ChecksumInputArgs();
            inputArgs.setChecksumFilePath(URLEncoder.encode(checkSumPath, StandardCharsets.UTF_8));
            inputArgs.setWgsRunId(wgsRunId);
            inputArgs.setSmbServerName(checkSumSplit.get(0));
            inputArgs.setSmbShareName(checkSumSplit.get(1));
            inputArgs.setSmbUsername(propertyConfiguration.getWgsAutomationDestUsername());
            inputArgs.setSmbPassword(propertyConfiguration.getWgsAutomationDestPassword());
            inputArgs.setWgsStatusViewerId(statusData.getWgsStatusViewerId());

            String inputArgsJson = new Gson().toJson(inputArgs);

            String command = "java -jar " + propertyConfiguration.getMd5ChecksumJarPath() + " " + inputArgsJson;
            logger.info("MD5Checksum jar execute command -> {}", command);

            Process proc = Runtime.getRuntime().exec(command);

            // https://stackoverflow.com/questions/5483830/process-waitfor-never-returns
            BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            String line;
            logger.info("Process Status :");
            while ((line = reader.readLine()) != null) {
                logger.info(line);
            }
            proc.waitFor();
            return new ResponseEntity<>("MD5Checksum process done successfully", HttpStatus.OK);
        } catch (Exception e) {
            Thread.currentThread().interrupt();
            return catchException(e, HttpStatus.CONFLICT);
        }
    }

    private ResponseEntity<Object> catchException(Exception e, HttpStatus httpStatus) {
        logger.error("Error : {}", e);
        return new ResponseEntity<>("Error", httpStatus);
    }

    @Override
    public void updateLTSDetails(LocalTransferIdStatus data) {
        String updateSql = "update WgsStatusViewer set SourcePath=?, LocalTransferID=? where WGSStatusViewerID=?;";
        jdbcTemplate.update(updateSql
                , data.getSourcePath()
                , data.getStatus()
                , data.getWgsStatusViewerId()
        );
    }
}
