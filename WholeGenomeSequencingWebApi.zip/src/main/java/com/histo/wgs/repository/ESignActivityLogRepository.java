package com.histo.wgs.repository;

import com.histo.wgs.entity.ESignActivityLog;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ESignActivityLogRepository extends JpaRepository<ESignActivityLog, Long> {
}