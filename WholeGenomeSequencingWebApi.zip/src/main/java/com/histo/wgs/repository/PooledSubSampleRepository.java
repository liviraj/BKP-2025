package com.histo.wgs.repository;

import com.histo.wgs.entity.PooledSubSample;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.stream.Collectors;

public interface PooledSubSampleRepository extends JpaRepository<PooledSubSample, Integer> {
    PooledSubSample findBySubSampleId(String subSampleId);
    List<PooledSubSample> findBySampleId(Long sampleId);
    @Query("SELECT p FROM PooledSubSample p WHERE p.subSampleId IN :subSampleIds AND p.sampleId = :sampleId")
    List<PooledSubSample> findExistingBySubSampleIdInAndSampleId(
            @Param("subSampleIds") List<String> subSampleIds,
            @Param("sampleId") Long sampleId
    );


    default List<String> findNonExistingBySubSampleIdIn(List<String> subSampleIds, Long sampleId) {
        List<PooledSubSample> existingSubSampleIds = findExistingBySubSampleIdInAndSampleId(subSampleIds, sampleId);

        List<String> nonExistingSubSampleIds = findBySampleId(existingSubSampleIds.get(0).getSampleId())
                .stream()
                .map(PooledSubSample::getSubSampleId).collect(Collectors.toList());
        nonExistingSubSampleIds.removeAll(existingSubSampleIds.stream().map(PooledSubSample::getSubSampleId).collect(Collectors.toList()));
        return nonExistingSubSampleIds;
    }

}