package com.histo.wgs.repository;

import com.histo.wgs.entity.WGSAnalysisApplicationMaster;
import com.histo.wgs.entity.WGSRunMaster;
import com.histo.wgs.entity.WgsAssociatedInput;
import com.histo.wgs.entity.WgsAssociatedInputsMaster;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface WgsAssociatedInputsMasterRepository extends JpaRepository<WgsAssociatedInputsMaster, Integer> {
    public List<WgsAssociatedInputsMaster> findByWgsRunId(WGSRunMaster wgsRunId);
    public Optional<WgsAssociatedInputsMaster> findByWgsRunIdAndAssociatedInput(WGSRunMaster wgsRunId, WgsAssociatedInput associatedInput);
    public long deleteByWgsRunId(WGSRunMaster wgsRunId);
    List<WgsAssociatedInputsMaster> findByWgsRunIdAndAnalysisApplicationID(WGSRunMaster wgsRunId, WGSAnalysisApplicationMaster analysisApplicationID);

}