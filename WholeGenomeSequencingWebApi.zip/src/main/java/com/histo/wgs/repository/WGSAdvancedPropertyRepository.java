package com.histo.wgs.repository;

import com.histo.wgs.entity.WGSAdvancedProperty;
import com.histo.wgs.entity.WGSAnalysisApplicationMaster;
import com.histo.wgs.entity.WGSRunMaster;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WGSAdvancedPropertyRepository extends JpaRepository<WGSAdvancedProperty, Integer> {
    public List<WGSAdvancedProperty> findByWgsRunID(WGSRunMaster wgsRunID);
    public long deleteByWgsRunID(WGSRunMaster wgsRunID);
    public List<WGSAdvancedProperty> findByWgsRunIDAndAnalysisApplicationID(WGSRunMaster wgsRunID, WGSAnalysisApplicationMaster analysisApplicationID);



}