package com.histo.wgs.repository;

import com.histo.wgs.entity.WGSRunMaster;
import com.histo.wgs.entity.WgsBarcodeSampleSet;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WgsBarcodeSampleSetRepository extends JpaRepository<WgsBarcodeSampleSet, Integer> {
    public long deleteByWgsRunId(WGSRunMaster wgsRunId);
    public List<WgsBarcodeSampleSet> findByWgsRunId(WGSRunMaster wgsRunId);
}