package com.histo.wgs.repository;

import com.histo.wgs.entity.WGSAnalysisApplicationMaster;
import com.histo.wgs.entity.WGSDefaultAdvancedProperty;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WGSDefaultAdvancedPropertyRepository extends JpaRepository<WGSDefaultAdvancedProperty, Integer> {
    public  List<WGSDefaultAdvancedProperty> findByAnalysisApplication(WGSAnalysisApplicationMaster analysisApplication);


}