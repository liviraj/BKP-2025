package com.histo.wgs.repository;

import com.histo.wgs.entity.WGSRunMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WGSRunMasterRepository extends JpaRepository<WGSRunMaster, Integer> {
}