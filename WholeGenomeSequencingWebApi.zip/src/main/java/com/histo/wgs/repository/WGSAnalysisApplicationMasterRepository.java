package com.histo.wgs.repository;

import com.histo.wgs.entity.WGSAnalysisApplicationMaster;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface WGSAnalysisApplicationMasterRepository extends JpaRepository<WGSAnalysisApplicationMaster, Integer> {
    List<WGSAnalysisApplicationMaster> findByDataTypeIDAndWorkFlowTypeID(Integer dataTypeID, Integer workFlowTypeID);
    Optional<WGSAnalysisApplicationMaster> findByAnalysisApplicationValue(String analysisApplicationValue);
}