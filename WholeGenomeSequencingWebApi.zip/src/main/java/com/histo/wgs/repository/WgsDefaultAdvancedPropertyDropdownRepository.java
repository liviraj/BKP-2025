package com.histo.wgs.repository;

import com.histo.wgs.entity.WGSAnalysisApplicationMaster;
import com.histo.wgs.entity.WgsDefaultAdvancedPropertyDropdown;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WgsDefaultAdvancedPropertyDropdownRepository extends JpaRepository<WgsDefaultAdvancedPropertyDropdown, Integer> {
    public List<WgsDefaultAdvancedPropertyDropdown> findByAnalysisApplicationID(WGSAnalysisApplicationMaster analysisApplication);

}