package com.histo.wgs.repository;

import com.histo.wgs.entity.WGSWorkFlowType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WGSWorkFlowTypeRepository extends JpaRepository<WGSWorkFlowType, Integer> {
}