package com.histo.wgs.repository;

import com.histo.wgs.entity.WGSDataTypeMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface WGSDataTypeMasterRepository extends JpaRepository<WGSDataTypeMaster, Integer> {
    public Optional<WGSDataTypeMaster> findByDataTypeValue(String dataTypeValue);
    public List<WGSDataTypeMaster> findByWorkFlowTypeID(Integer workFlowTypeID);


}