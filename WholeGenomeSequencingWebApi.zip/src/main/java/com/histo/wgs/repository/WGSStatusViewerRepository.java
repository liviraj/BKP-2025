package com.histo.wgs.repository;

import com.histo.wgs.entity.WGSStatusViewer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WGSStatusViewerRepository extends JpaRepository<WGSStatusViewer, Integer> {
}