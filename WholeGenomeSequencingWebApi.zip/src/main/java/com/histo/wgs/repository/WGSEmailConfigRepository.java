package com.histo.wgs.repository;

import com.histo.wgs.entity.WGSEmailConfig;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WGSEmailConfigRepository extends JpaRepository<WGSEmailConfig, Integer> {
}