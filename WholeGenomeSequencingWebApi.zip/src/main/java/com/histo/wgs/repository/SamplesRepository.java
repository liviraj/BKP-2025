package com.histo.wgs.repository;

import com.histo.wgs.entity.Samples;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SamplesRepository extends JpaRepository<Samples, Long> {
    Samples findByClientSampleId(String clientSampleId);

}