package com.histo.wgs.repository;

import com.histo.wgs.entity.WgsRunDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WgsRunDetailRepository extends JpaRepository<WgsRunDetail, Integer> {
    WgsRunDetail findBySampleIdAndWgsRunId(String sampleId, Integer wgsRunId);
    WgsRunDetail findByWgsRunId(Integer wgsRunId);
    WgsRunDetail findByWgsRunIdAndIsPooledSample(Integer wgsRunId, boolean isPooledSample);


}