package com.histo.wgs.repository;

import com.histo.wgs.entity.WGSAnalysisApplicationMaster;
import com.histo.wgs.entity.WgsAssociatedInput;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface WgsAssociatedInputRepository extends JpaRepository<WgsAssociatedInput, Integer> {
    public List<WgsAssociatedInput> findByAnalysisApplicationID(WGSAnalysisApplicationMaster analysisApplicationID);
    public Optional<WgsAssociatedInput> findByPropertyValue(String propertyValue);
    public List<WgsAssociatedInput> findByAnalysisApplicationIDIn(Collection<WGSAnalysisApplicationMaster> analysisApplicationIDS);

}