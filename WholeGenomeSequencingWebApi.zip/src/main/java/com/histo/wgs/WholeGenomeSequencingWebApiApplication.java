package com.histo.wgs;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
@OpenAPIDefinition(
		servers = {
				@Server(url = "https://webapiuat.histogenetics.com:8765/WholeGenomeSequencing", description = "UAT Server API Gateway"),
				@Server(url = "https://webapiuat:8500/WholeGenomeSequencing", description = "UAT Server native"),
				@Server(url = "http://localhost:8765/WholeGenomeSequencing", description = "local Server"),
				@Server(url = "http://localhost:8500/WholeGenomeSequencing", description = "local Native Server"),
				@Server(url = "https://javawebag01.histogenetics.com:8765/WholeGenomeSequencing", description = "PROD Server API Gateway"),
				@Server(url = "https://javawebag01:8500/WholeGenomeSequencing", description = "PROD Server Native")
		}
)

public class WholeGenomeSequencingWebApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(WholeGenomeSequencingWebApiApplication.class, args);
	}

}
