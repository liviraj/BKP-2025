package com.histo.wgs.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@NoArgsConstructor
@ToString
public class WGSAnalysisApplicationMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "AnalysisApplicationID", nullable = false)
    private Integer id;

    @Size(max = 100)
    @NotNull
    @Column(name = "AnalysisApplicationDisplayName", nullable = false, length = 100)
    private String analysisApplicationDisplayName;

    @Size(max = 100)
    @NotNull
    @Column(name = "AnalysisApplicationValue", nullable = false, length = 100)
    private String analysisApplicationValue;

    @Column(name = "DataTypeID")
    private Integer dataTypeID;

    @Column(name = "WorkFlowTypeID")
    private Integer workFlowTypeID;
}