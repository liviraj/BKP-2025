package com.histo.wgs.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.Instant;

@Entity
@Getter
@Setter
@NoArgsConstructor
@ToString
public class WGSStatusViewer {
    @Id
    @Column(name = "WGSStatusViewerID", nullable = false)
    private Integer wGSStatusViewerID;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "WGSRunID", nullable = false)
    private WGSRunMaster wGSRunID;

    @Column(name = "RunStatusID")
    private Integer runStatusID;

    @Column(name = "AnalysisStatusID")
    private Integer analysisStatusID;

    @Column(name = "TransferStatusID")
    private Integer transferStatusID;

    @Column(name = "DestinationUploadPath", length = 2048)
    private String destinationUploadPath;

    @Column(name = "RawDataPath", length = 2048)
    private String rawDataPath;

    @Column(name = "LocalTransferID")
    private Integer localTransferID;

    @Column(name = "SourcePath", length = 2048)
    private String sourcePath;

    @Column(name = "AnalysisDataPath", length = 1024)
    private String analysisDataPath;

    @Column(name = "LocalTransferCompletedTime")
    private Instant localTransferCompletedTime;

    @Column(name = "ClientTransferCompletedTime")
    private Instant clientTransferCompletedTime;

    @Column(name = "WGSStaticsPDFPath", length = 1024)
    private String wGSStaticsPDFPath;

    @Column(name = "CloudRunStatus", nullable = false)
    private Integer cloudRunStatus;

    @Column(name = "CloudFileTransfer", nullable = false)
    private Integer cloudFileTransfer;

    @Column(name = "CloudCCSPath", length = 5000)
    private String cloudCCSPath;

    @Column(name = "Reportedstatus", nullable = false)
    private Boolean reportedstatus = false;

    @Column(name = "DemultiplexStatus")
    private Short demultiplexStatus;

    @Column(name = "CCSStatus")
    private Short ccsStatus;
}