package com.histo.wgs.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@NoArgsConstructor
@ToString
public class WGSDefaultAdvancedProperty {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DefaultAdvancedPropertyID", nullable = false)
    private Integer id;

    @Size(max = 100)
    @Column(name = "DefaultValue", length = 100)
    private String defaultValue;

    @Size(max = 100)
    @Column(name = "Type", length = 100)
    private String type;

    @NotNull
    @Column(name = "WorkFlowTypeID", nullable = false)
    private Integer workFlowTypeID;

    @NotNull
    @Column(name = "DataTypeID", nullable = false)
    private Integer dataTypeID;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "AnalysisApplicationID")
    private WGSAnalysisApplicationMaster analysisApplication;

    @MapsId
    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "DefaultAdvancedPropertyID", nullable = false)
    private WGSDefaultAdvancedProperty wGSDefaultAdvancedProperty;

    @Size(max = 255)
    @NotNull
    @Column(name = "PropertyLabel", nullable = false)
    private String propertyLabel;

    @Size(max = 100)
    @Column(name = "PropertyValue", length = 100)
    private String propertyValue;
}