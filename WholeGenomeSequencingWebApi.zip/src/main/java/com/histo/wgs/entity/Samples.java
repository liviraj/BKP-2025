package com.histo.wgs.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Samples {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SampleID", nullable = false)
    private Long sampleId;

    @NotNull
    @Column(name = "ClientProjectId", nullable = false)
    private Integer clientProjectId;

    @NotNull
    @Column(name = "ClientID", nullable = false)
    private Integer clientId;

    @NotNull
    @Column(name = "ClientSampleID", nullable = false)
    private String clientSampleId;
}