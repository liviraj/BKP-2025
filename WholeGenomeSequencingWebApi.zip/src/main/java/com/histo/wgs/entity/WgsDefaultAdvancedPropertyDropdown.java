package com.histo.wgs.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@NoArgsConstructor
@ToString
public class WgsDefaultAdvancedPropertyDropdown {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DropdownID", nullable = false)
    private Integer id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = true)
    @JoinColumn(name = "AnalysisApplicationID", nullable = false)
    private WGSAnalysisApplicationMaster analysisApplicationID;

    @Size(max = 100)
    @NotNull
    @Column(name = "DropdownName", nullable = false, length = 100)
    private String dropdownName;

    @Size(max = 100)
    @Column(name = "DropdownValue", length = 100)
    private String dropdownValue;
}