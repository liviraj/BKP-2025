package com.histo.wgs.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Entity
@Table(name = "WGSRunDetails")
@NoArgsConstructor
@Getter
@Setter
@ToString
public class WgsRunDetail {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "WGSDetailId")
    private Integer wgsDetailId;

    @Column(name = "WGSRunID")
    private Integer wgsRunId;

    @Column(name = "SampleID", length = 100)
    private String sampleId;

    @Column(name = "IsPooledSample")
    private boolean isPooledSample;
}
