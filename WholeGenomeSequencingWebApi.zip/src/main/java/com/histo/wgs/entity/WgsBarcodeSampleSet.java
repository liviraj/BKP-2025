package com.histo.wgs.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@NoArgsConstructor
@ToString
public class WgsBarcodeSampleSet {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "BarcodeSampleSetID", nullable = false)
    private Integer id;

    @Size(max = 255)
    @NotNull
    @Column(name = "Barcode", nullable = false)
    private String barcode;

    @Size(max = 255)
    @NotNull
    @Column(name = "BioSample", nullable = false)
    private String bioSample;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "WGSRunID", nullable = false)
    private WGSRunMaster wgsRunId;
}