package com.histo.wgs.entity;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@NoArgsConstructor
@ToString
public class WGSAdvancedProperty {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "AdvancedPropertyID", nullable = false)
    private Integer id;

    @Size(max = 100)
    @Column(name = "\"Value\"", length = 100)
    private String value;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "WGSRunID", nullable = false)
    private WGSRunMaster wgsRunID;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "WorkFlowTypeID", nullable = false)
    private WGSWorkFlowType workFlowTypeID;

    @NotNull
    @Column(name = "DataTypeID", nullable = false)
    private Integer dataTypeID;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "AnalysisApplicationID", nullable = false)
    private WGSAnalysisApplicationMaster analysisApplicationID;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "DefaultAdvancedPropertyID", nullable = false)
    private WGSDefaultAdvancedProperty  defaultAdvancedPropertyID;

    @NotNull
    @Column(name = "DropdownID", nullable = false)
    private Integer dropdownID;
}