package com.histo.wgs.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "PooledSubSamples")
@NoArgsConstructor
@Getter
@Setter
@ToString
public class PooledSubSample {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PooledSubSamplesID", nullable = false)
    private Integer pooledSubSamplesId;

    @NotNull
    @Column(name = "SampleID", nullable = false)
    private Long sampleId;

    @NotNull
    @Column(name = "SubSampleID", nullable = false, length = 250)
    private String subSampleId;
}