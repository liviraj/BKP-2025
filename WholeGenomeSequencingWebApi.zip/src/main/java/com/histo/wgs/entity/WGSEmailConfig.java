package com.histo.wgs.entity;


import jakarta.persistence.*;

@Entity
public class WGSEmailConfig {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EmailConfigId", nullable = false)
    private Integer emailConfigId;

    @Column(name = "ModeOfTransfer", length = 50)
    private String modeOfTransfer;

    @Column(name = "emailContent", length = 5000)
    private String emailContent;

    @Transient
    private boolean isDefault;

    public WGSEmailConfig() {
    }

    public Integer getEmailConfigId() {
        return emailConfigId;
    }

    public void setEmailConfigId(Integer emailConfigId) {
        this.emailConfigId = emailConfigId;
    }

    public String getModeOfTransfer() {
        return modeOfTransfer;
    }

    public void setModeOfTransfer(String modeOfTransfer) {
        this.modeOfTransfer = modeOfTransfer;
    }

    public String getEmailContent() {
        return emailContent;
    }

    public void setEmailContent(String emailContent) {
        this.emailContent = emailContent;
    }

    public boolean isDefault() {
        return isDefault;
    }

    public void setDefault(boolean aDefault) {
        isDefault = aDefault;
    }

    @Override
    public String toString() {
        return "WGSEmailConfig{" +
                "emailConfigId=" + emailConfigId +
                ", modeOfTransfer='" + modeOfTransfer + '\'' +
                ", emailContent='" + emailContent + '\'' +
                ", isDefault=" + isDefault +
                '}';
    }
}
