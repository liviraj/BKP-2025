package com.histo.wgs.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Getter
@Setter
@NoArgsConstructor
@ToString
public class WGSRunMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "WGSRunID", nullable = false)
    private Integer id;

    @NotNull
    @Column(name = "ClientProjectId", nullable = false)
    private Integer clientProjectId;

    @Size(max = 100)
    @NotNull
    @Column(name = "RunName", nullable = false, length = 100)
    private String runName;

    @NotNull
    @Column(name = "IsOnBoard", nullable = false)
    private Boolean isOnBoard = false;

    @NotNull
    @Column(name = "DataRequirementID", nullable = false)
    private Integer dataRequirementID;

    @NotNull
    @Column(name = "NeedHifi", nullable = false)
    private Boolean needHifi = false;

    @Column(name = "CCSQualityFilter", precision = 10, scale = 5)
    private BigDecimal cCSQualityFilter;

    @Size(max = 100)
    @Column(name = "Filename", length = 100)
    private String filename;

    @Size(max = 20)
    @Column(name = "BarcodeType", length = 20)
    private String barcodeType;

    @Column(name = "BarcodeQualityFilter", precision = 10, scale = 5)
    private BigDecimal barcodeQualityFilter;

    @NotNull
    @Column(name = "CreatedBy", nullable = false)
    private Integer createdBy;

    @NotNull
    @Column(name = "CreatedOn", nullable = false)
    private Instant createdOn;

    @Column(name = "NumberofPasses")
    private Integer numberofPasses;

    @Column(name = "IsDemultiplexingRequired")
    private Boolean isDemultiplexingRequired;

    @Column(name = "LastModifiedBy")
    private Integer lastModifiedBy;

    @Column(name = "LastModifiedDate")
    private Instant lastModifiedDate;

    @Column(name = "ModifiedCount")
    private Integer modifiedCount;

    @Lob
    @Column(name = "SourceFilepath")
    private String sourceFilepath;

    @Column(name = "IsInActive")
    private Boolean isInActive;

    @Column(name = "RelatedWGSRunId")
    private Integer relatedWGSRunId;

    @Size(max = 50)
    @Column(name = "InstrumentName", length = 50)
    private String instrumentName;

    @Size(max = 255)
    @Column(name = "DataSetName")
    private String dataSetName;

    @Size(max = 255)
    @Column(name = "FilePath")
    private String filePath;
}