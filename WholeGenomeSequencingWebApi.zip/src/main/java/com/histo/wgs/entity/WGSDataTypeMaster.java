package com.histo.wgs.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@NoArgsConstructor
@ToString
public class WGSDataTypeMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DataTypeID", nullable = false)
    private Integer id;

    @Size(max = 100)
    @NotNull
    @Column(name = "DataTypeDisplayName", nullable = false, length = 100)
    private String dataTypeDisplayName;

    @Size(max = 100)
    @NotNull
    @Column(name = "DataTypeValue", nullable = false, length = 100)
    private String dataTypeValue;

    @Column(name = "WorkFlowTypeID")
    private Integer workFlowTypeID;
}