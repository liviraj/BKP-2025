package com.histo.wgs.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@NoArgsConstructor
@ToString
public class WgsAssociatedInputsMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "AssociatedInputMasterId", nullable = false)
    private Integer id;

    @Size(max = 255)
    @NotNull
    @Column(name = "\"Value\"", nullable = false)
    private String value;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "WGSRunID", nullable = false)
    private WGSRunMaster wgsRunId;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "AnalysisApplicationID", nullable = false)
    private WGSAnalysisApplicationMaster analysisApplicationID;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "AssociatedInputId", nullable = false)
    private WgsAssociatedInput associatedInput;

    @Size(max = 100)
    @Column(name = "UUID", length = 100)
    private String uuid;
}