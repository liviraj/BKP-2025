package com.histo.wgs.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "WgsAssociatedInputs")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class WgsAssociatedInput {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "AssociatedInputId", nullable = false)
    private Integer id;

    @Size(max = 100)
    @NotNull
    @Column(name = "PropertyLabel", nullable = false, length = 100)
    private String propertyLabel;

    @Size(max = 100)
    @NotNull
    @Column(name = "PropertyValue", nullable = false, length = 100)
    private String propertyValue;

    @Size(max = 100)
    @Column(name = "DefaultValue", length = 100)
    private String defaultValue;

    @Size(max = 100)
    @NotNull
    @Column(name = "Type", nullable = false, length = 100)
    private String type;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "AnalysisApplicationID", nullable = false)
    private WGSAnalysisApplicationMaster analysisApplicationID;
}