package com.histo.wgs.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@NoArgsConstructor
@ToString
public class WGSWorkFlowType {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "WorkFlowTypeID", nullable = false)
    private Integer id;

    @Size(max = 255)
    @Column(name = "WorkFlowTypeName")
    private String workFlowTypeName;
}