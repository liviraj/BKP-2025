package com.histo.wgs.exception;

public class InternalServerException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	public InternalServerException(String Exception) {
		super(Exception);
	}

}
