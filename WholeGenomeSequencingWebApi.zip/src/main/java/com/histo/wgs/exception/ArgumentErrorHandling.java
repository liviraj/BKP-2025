package com.histo.wgs.exception;

import com.histo.wgs.model.WGSResModel;
import com.histo.wgs.util.FilterUtil;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.Date;

import static reactor.netty.Metrics.STATUS;

@ControllerAdvice
class ArgumentErrorHandling {
  private MappingJacksonValue mappingJacksonValue;

  @ExceptionHandler(ConstraintViolationException.class)
  ResponseEntity<Object> onConstraintValidationException(ConstraintViolationException e) {
    WGSResModel response = new WGSResModel();
    ValidationErrorResponse error = new ValidationErrorResponse();
    for (ConstraintViolation violation : e.getConstraintViolations()) {
      error.getViolations().add(new Violation(violation.getPropertyPath().toString(), violation.getMessage()));
    }
    response.setStatus(false);
    response.setInformation(new ExceptionBean(new Date(),"Bad Request", "Request input is wrong. Please check."));
    mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
    return new ResponseEntity<>(mappingJacksonValue, HttpStatus.BAD_REQUEST);
  }

  @ExceptionHandler(MethodArgumentNotValidException.class)
  ResponseEntity<Object> onMethodArgumentNotValidException(MethodArgumentNotValidException e) {
    WGSResModel response = new WGSResModel();
    ValidationErrorResponse error = new ValidationErrorResponse();
    for (FieldError fieldError : e.getBindingResult().getFieldErrors()) {
      error.getViolations().add(new Violation(fieldError.getField(), fieldError.getDefaultMessage()));
    }
    response.setStatus(false);
    response.setInformation(new ExceptionBean(new Date(),"Bad Request", "Request input is wrong. Please check."));
    mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
    return new ResponseEntity<>(mappingJacksonValue, HttpStatus.BAD_REQUEST);
  }

}
