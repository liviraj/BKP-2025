package com.histo.wgs.security;

import com.histo.wgs.model.UserInformationDTO;
import com.histo.wgs.model.WGSResModel;
import com.histo.wgs.exception.ExceptionBean;
import com.histo.wgs.util.FilterUtil;
import com.histo.wgs.util.WGSConstants;
import com.microsoft.graph.authentication.IAuthenticationProvider;
import com.microsoft.graph.core.ClientException;
import com.microsoft.graph.requests.GraphServiceClient;
import com.nimbusds.jwt.JWT;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.JWTParser;
import okhttp3.Request;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.concurrent.CompletableFuture;

@Component("authorizationValidation")
public class AuthorizationValidation {

    private static final Logger logger = LogManager.getLogger(AuthorizationValidation.class.getName());
    private static final String STATUS = "status";

    WGSResModel response;

    MappingJacksonValue mappingJacksonValue;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public AuthorizationValidation() {
        super();
        response = new WGSResModel();
    }

    public ResponseEntity<Object> isAuthorize(String token) {

        try {
            if (StringUtils.isNotBlank(token)) {
                String emailId = "";
                try {
                    IAuthenticationProvider authProvider = requestUrl -> {
                        CompletableFuture<String> future = new CompletableFuture<>();
                        future.complete(token);
                        return future;
                    };

                    GraphServiceClient<Request> graphClient = GraphServiceClient.builder()
                            .authenticationProvider(authProvider).buildClient();

                    emailId = graphClient.me().buildRequest().get().userPrincipalName;
                } catch (ClientException e) {
                    JWT jwt = JWTParser.parse(token);
                    JWTClaimsSet claimsSet = jwt.getJWTClaimsSet();
                    if (isTokenExpire(claimsSet.getExpirationTime())) {
                        emailId = "";
                    } else {
                        emailId = (String) claimsSet.getClaim(WGSConstants.EMAIL_CLAIM_NAME);
                    }
                }
                if (StringUtils.isNotBlank(emailId)) {
//                    Connection con = SqlConnectionSetup.getConnection();
//                    JdbcTemplate jdbcTemplate = new JdbcTemplate(new SingleConnectionDataSource(con, false));
                    String sql = "select UI.LoginName, UI.UserID, UI.FirstName, UI.LastName, UI.EmailAddress from UserInformation UI where UI.EmailAddress = ?";
                    UserInformationDTO userInformation = jdbcTemplate.queryForObject(sql,
                            BeanPropertyRowMapper.newInstance(UserInformationDTO.class), emailId);

                    if (userInformation != null) {
                        response.setStatus(true);
                        response.setInformation(new ExceptionBean(new Date(), "Valid", "Token valid"));
                        mappingJacksonValue = FilterUtil.responseFilter(response,
                                new String[]{"information", STATUS});
                        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
                    } else {
                        response.setStatus(false);
                        response.setInformation(new ExceptionBean(new Date(), "Not Valid", "User not found"));
                        mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"information", STATUS});
                        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
                    }

                } else {
                    response.setStatus(false);
                    response.setInformation(new ExceptionBean(new Date(), "Not Valid", "User not found"));
                    mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"information", STATUS});
                    return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
                }
            } else {
                response.setStatus(false);
                response.setInformation(
                        new ExceptionBean(new Date(), "Token not valid", "Token is empty or not provided"));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"information", STATUS});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.UNAUTHORIZED);
            }

        } catch (Exception e) {
            logger.error("Exception message: {}", e);
            response.setStatus(false);
            response.setInformation(new ExceptionBean(new Date(), "Token not valid", "Token is expired or Invalid"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"information", STATUS, "exception"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.UNAUTHORIZED);

        }
    }

    private boolean isTokenExpire(Date expiryDate) {
        // Extract the expiration time claim
        return expiryDate != null && expiryDate.before(new Date());
    }
}
