package com.histo.wgs.config.smrt;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;


public class ConfigurationSetup {
    private static final Logger LOGGER = LogManager.getLogger(ConfigurationSetup.class);
    public String pacBioRemoteBaseURL;

    private static ConfigurationSetup configurationSetup = null;

    public static synchronized  ConfigurationSetup getInstance() {
        if (configurationSetup == null) {
            configurationSetup = new ConfigurationSetup();
            try {
                Properties prop = new Properties();
                InputStream input = ConfigurationSetup.class.getClassLoader().getResourceAsStream("application.properties");
                prop.load(input);
                configurationSetup.pacBioRemoteBaseURL = prop.getProperty("app.remote.pacbio.remote.base.url");
            } catch (IOException ex) {
                LOGGER.error(ex);
            }
        }
        return configurationSetup;
    }

}
