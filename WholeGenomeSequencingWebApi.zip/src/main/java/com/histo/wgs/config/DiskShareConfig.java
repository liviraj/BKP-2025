package com.histo.wgs.config;

import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.SmbConfig;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class DiskShareConfig {
    private static final Logger LOGGER = LogManager.getLogger(DiskShareConfig.class);
    private DiskShare diskShare;
    private SMBClient client;
    private Connection connection;
    private Session session;

    public DiskShareConfig(String username, String password, String domain, String sourceServer, String sourceShare
    ) {
        try {
            SmbConfig smbConfig = SmbConfig.builder().withReadTimeout(1, TimeUnit.MINUTES)
                    .withTimeout(1, TimeUnit.MINUTES)
                    .withWriteTimeout(1, TimeUnit.MINUTES)
                    .withTransactTimeout(1, TimeUnit.MINUTES)
                    .build();
            client = new SMBClient(smbConfig);
            connection = client.connect(sourceServer);
            AuthenticationContext authContextSource = new AuthenticationContext(username
                    , password.toCharArray()
                    , domain);
            session = connection.authenticate(authContextSource);
            this.diskShare = (DiskShare) session.connectShare(sourceShare);
        } catch (IOException e) {
            LOGGER.error(e);
        }
    }

    public DiskShare getDiskShare() {
        return diskShare;
    }

    public void setDiskShare(DiskShare diskShare) {
        this.diskShare = diskShare;
    }

    @Override
    public String toString() {
        return "DiskShareConfig{" +
                "sourceDiskShare=" + diskShare +
                '}';
    }

    public void close() throws Exception {
        if (diskShare != null) {
            diskShare.close();
        }
        if (session != null) {
            session.close();
        }
        if (connection != null) {
            connection.close();
        }
        if (client != null) {
            client.close();
        }
    }
}
