package com.histo.wgs.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI openAPI() {
        return new OpenAPI().addSecurityItem(new SecurityRequirement().addList("Authentication"))
                .components(new Components().addSecuritySchemes("Authentication", createCustomApiKeyScheme()))
                .info(new Info().title("WholeGenomeSequencing REST API")
                        .description("Whole Genome Sequencing API Services")
                        .version("1.0.0").contact(new Contact().name("Histogenetics").email("histosupport@histogenetics.com"))
                        .license(new License().name("© 2024 HistoGenetics LLC")
                                .url("https://www.histogenetics.com")));
    }

    private SecurityScheme createCustomApiKeyScheme() {
        return new SecurityScheme()
                .type(SecurityScheme.Type.APIKEY)
                .in(SecurityScheme.In.HEADER)
                .name("Authorization");
    }
}