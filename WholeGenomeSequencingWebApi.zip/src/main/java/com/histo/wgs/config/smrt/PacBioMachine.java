package com.histo.wgs.config.smrt;

public enum PacBioMachine {
    MachineOne, MachineTwo, RemoteSMRTPortal
}
