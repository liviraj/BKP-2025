package com.histo.wgs.config.smrt;

public class ConnectionURLParams {
	// Pacbio URL Details
	private static final  String SMRT_PORTAL_BASE_URL = "/SMRTLink/1.0.0/smrt-link";
	private static final String TOKEN_URL = "/token";
	private ConfigurationSetup configurationSetup;

	public ConnectionURLParams() {
		if (configurationSetup == null) {
			configurationSetup = ConfigurationSetup.getInstance();
		}
	}

	public String getTokenURL(PacBioMachine machine) {
		if (machine == PacBioMachine.RemoteSMRTPortal) {
			return configurationSetup.pacBioRemoteBaseURL + TOKEN_URL;
		}
		return null;
	}

	// SMRT portal URLS
	public String getPipelineTemplateUrl() {
		return configurationSetup.pacBioRemoteBaseURL + SMRT_PORTAL_BASE_URL + "/pipeline-template-view-rules";
	}

	public String getBarCodeRecordNamesByUuidUrl(String uuid) {
		return configurationSetup.pacBioRemoteBaseURL + SMRT_PORTAL_BASE_URL + "/datasets/barcodes/" + uuid
				+ "/record-names";
	}

	public String getReferenceGenomeDefaultValueUrl(String uuid) {
		return configurationSetup.pacBioRemoteBaseURL + SMRT_PORTAL_BASE_URL + "/datasets/" + uuid;
	}

	public String findAllReferenceGenomeSetUrl() {
		return configurationSetup.pacBioRemoteBaseURL + SMRT_PORTAL_BASE_URL + "/datasets/references?parentUuid=null&limit=2000&marker=0";
	}

	public String findAllBarCodeSetUrl() {
		return configurationSetup.pacBioRemoteBaseURL + SMRT_PORTAL_BASE_URL + "/datasets/barcodes?parentUuid=null&limit=2000&marker=0";
	}
}
