package com.histo.wgs.config;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:application.properties")
@NoArgsConstructor
@Getter
@Setter
@ToString
public class PropertyConfiguration {

    @Value("${wgs.filename}")
    private String wgsFilename;
    @Value("${wgs.source.filepath}")
    private String wgsSourceFilePath;
    @Value("${wgs.demux.smb.source.url}")
    private String wgsDemuxSmbSourceUrl;
    @Value("${wgs.demux.smb.destination.url}")
    private String wgsDemuxSmbDestinationUrl;
    @Value("${wgs.demux.smb.username}")
    private String wgsDemuxSmbUsername;
    @Value("${wgs.demux.smb.password}")
    private String wgsDemuxSmbPassword;
    @Value("${wgs.demux.smb.domain}")
    private String wgsDemuxSmbDomain;
    @Value("${wgs.report.smb.url}")
    private String wgsReportSmbSourceUrl;
    @Value("${wgs.report.smb.username}")
    private String wgsReportSmbUsername;
    @Value("${wgs.report.smb.password}")
    private String wgsReportSmbPassword;
    @Value("${wgs.report.smb.domain}")
    private String wgsReportSmbDomain;
    @Value("${spring.mail.host}")
    private String mailHost;
    @Value("${spring.mail.port}")
    private Integer mailPort;
    @Value("${wgs.report.email.property.username}")
    private String wgsReportUsernameProp;
    @Value("${wgs.report.email.property.password}")
    private String wgsReportPasswordProp;
    @Value("${wgs.automation.destination.username}")
    private String wgsAutomationDestUsername;
    @Value("${wgs.automation.destination.password}")
    private String wgsAutomationDestPassword;
    @Value("${wgs.md5checksum.jar.path}")
    private String md5ChecksumJarPath;
    @Value("${app.remote.pacbio.remote.base.url}")
    private String pacBioRemoteBaseURL;
    @Value("${wgs.smb2.username}")
    private String smb2Username;
    @Value("${wgs.smb2.password}")
    private String smb2Password;
    @Value("${wgs.automation.local-destination-path}")
    private String wgsAutomationLocalDestinationPath;
    @Value ("${WGSAutomation.PacBioFileDataJarPath}")
    private String pacbioFileDataOrganizerJarPath;
    @Value("${base.url.pacbio}")
    private String pacbioBaseUrl;
    @Value("${smrt.auth-token}")
    private String smrtAuthToken;
    @Value("${smrt.cloud-token-body}")
    private String smrtCloudTokenBody;
    @Value("${wgs.automation.deletion.smb.domain}")
    private String deletionSmbDomain;
}
