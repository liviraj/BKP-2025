package com.histo.wgs.config;

import com.histo.wgs.model.EmailAttributeDetails;
import com.histo.wgs.service.impl.WgsRunsServiceImpl;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import java.util.Properties;

// @Configuration
public class EmailPropConfiguration {

    private PropertyConfiguration propertyConfiguration;

    private JdbcTemplate jdbcTemplate;

    @Bean
    @Qualifier("javaMailSender")
    public JavaMailSender getJavaMailSender(PropertyConfiguration propertyConfiguration, JdbcTemplate jdbcTemplate) {
        WgsRunsServiceImpl runsService = new WgsRunsServiceImpl();
        EmailAttributeDetails mailAttributeDetails = runsService.getMailAttributeDetails(jdbcTemplate, propertyConfiguration);

        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        mailSender.setHost(propertyConfiguration.getMailHost());
        mailSender.setPort(propertyConfiguration.getMailPort());
        mailSender.setUsername(mailAttributeDetails.getSMTPUserName());
        mailSender.setPassword(mailAttributeDetails.getSMTPPassword());
        Properties props = mailSender.getJavaMailProperties();
        // props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.debug", "true");

        return mailSender;
    }
}
