package com.histo.wgs.model;

public class FileDataOrganizerArgs {
	private String sourceServer;
	private String sourceShare;
	private String destinationServer;
	private String destinationShare;
	private String sourceDirectory;
	private String destinationDirectory;
	private String sourceUsername;
	private String sourcePassword;
	private String destinationUsername;
	private String destinationPassword;
	private int copyDataNumberOfDaysBack = 365;
	private int statusViewerId = 0;
	private int fileSizeInMB;
	private String pdfPath;
	private String actionType;

	public String getSourceServer() {
		return sourceServer;
	}

	public void setSourceServer(String sourceServer) {
		this.sourceServer = sourceServer;
	}

	public String getSourceShare() {
		return sourceShare;
	}

	public void setSourceShare(String sourceShare) {
		this.sourceShare = sourceShare;
	}

	public String getDestinationServer() {
		return destinationServer;
	}

	public void setDestinationServer(String destinationServer) {
		this.destinationServer = destinationServer;
	}

	public String getDestinationShare() {
		return destinationShare;
	}

	public void setDestinationShare(String destinationShare) {
		this.destinationShare = destinationShare;
	}

	public String getSourceDirectory() {
		return sourceDirectory;
	}
	public void setSourceDirectory(String sourceDirectory) {
		this.sourceDirectory = sourceDirectory;
	}
	public String getDestinationDirectory() {
		return destinationDirectory;
	}
	public void setDestinationDirectory(String destinationDirectory) {
		this.destinationDirectory = destinationDirectory;
	}
	public String getSourceUsername() {
		return sourceUsername;
	}
	public void setSourceUsername(String sourceUsername) {
		this.sourceUsername = sourceUsername;
	}
	public String getSourcePassword() {
		return sourcePassword;
	}
	public void setSourcePassword(String sourcePassword) {
		this.sourcePassword = sourcePassword;
	}
	public String getDestinationUsername() {
		return destinationUsername;
	}
	public void setDestinationUsername(String destinationUsername) {
		this.destinationUsername = destinationUsername;
	}
	public String getDestinationPassword() {
		return destinationPassword;
	}
	public void setDestinationPassword(String destinationPassword) {
		this.destinationPassword = destinationPassword;
	}
	public int getCopyDataNumberOfDaysBack() {
		return copyDataNumberOfDaysBack;
	}
	public void setCopyDataNumberOfDaysBack(int copyDataNumberOfDaysBack) {
		this.copyDataNumberOfDaysBack = copyDataNumberOfDaysBack;
	}
	public int getStatusViewerId() {
		return statusViewerId;
	}
	public void setStatusViewerId(int statusViewerId) {
		this.statusViewerId = statusViewerId;
	}
	public int getFileSizeInMB() {
		return fileSizeInMB;
	}
	public void setFileSizeInMB(int fileSizeInMB) {
		this.fileSizeInMB = fileSizeInMB;
	}
	public String getPdfPath() {
		return pdfPath;
	}
	public void setPdfPath(String pDFPath) {
		pdfPath = pDFPath;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	@Override
	public String toString() {
		return "FileDataOrganizerArgs{" +
				"sourceServer='" + sourceServer + '\'' +
				", sourceShare='" + sourceShare + '\'' +
				", destinationServer='" + destinationServer + '\'' +
				", destinationShare='" + destinationShare + '\'' +
				", sourceDirectory='" + sourceDirectory + '\'' +
				", destinationDirectory='" + destinationDirectory + '\'' +
				", sourceUserName='" + sourceUsername + '\'' +
				", sourcePassword='" + sourcePassword + '\'' +
				", destUserName='" + destinationUsername + '\'' +
				", destPassword='" + destinationPassword + '\'' +
				", copyDataNumberOfDaysBack=" + copyDataNumberOfDaysBack +
				", statusViewerId=" + statusViewerId +
				", fileSizeInMB=" + fileSizeInMB +
				", PDFPath='" + pdfPath + '\'' +
				", actionType='" + actionType + '\'' +
				'}';
	}
}
