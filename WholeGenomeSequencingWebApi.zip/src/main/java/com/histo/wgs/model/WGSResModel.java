package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.histo.wgs.exception.ExceptionBean;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@JsonFilter("WGSViewResModel")
@NoArgsConstructor
@Getter
@Setter
@ToString
public class WGSResModel {
    private boolean status;
    private ExceptionBean information;
    private List<WgsRunsViewDto> wgsRunsList;
    private String resMessage;
    private List<WgsRunClients> wgsRunClientList;
    private List<WgsRunClientProjects> wgsRunClientProjectList;
    private List<WgsRunCommands> wgsRunCommentsList;
    private List<WgsRunLogs> wgsRunLogsList;
    private List<WgsRunPinNoInfo> wgsRunPinNoInfoList;
    private List<WgsReportAttributesByClient> wgsReportAttributesByClientList;
    private LoginModel loginModel;
    private UserInformationDTO userInformation;
    private Integer wgsRunId;
    private EmailInfo emailInfo;
    private WGSReportFile wgsReportFile;
    private List<ValidateSampleDTO> inValidSamples;
    private List<SampleDetail> sampleDetails;
    List<String> missingPooledSamples;
    boolean pooledSample = false;
    List<String> pooledSamplesString;
    private Object data;
}