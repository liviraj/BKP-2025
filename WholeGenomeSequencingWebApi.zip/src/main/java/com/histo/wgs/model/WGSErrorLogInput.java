package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class WGSErrorLogInput {
	private int WGSRunID;
	private int WGSStatusViewerID;
	private String LogInfo;
	private String ProgramName;
	public int getWGSRunID() {
		return WGSRunID;
	}
	@JsonProperty("WGSRunID")
	public void setWGSRunID(int wGSRunID) {
		WGSRunID = wGSRunID;
	}
	public int getWGSStatusViewerID() {
		return WGSStatusViewerID;
	}
	@JsonProperty("WGSStatusViewerID")
	public void setWGSStatusViewerID(int wGSStatusViewerID) {
		WGSStatusViewerID = wGSStatusViewerID;
	}
	public String getLogInfo() {
		return LogInfo;
	}
	@JsonProperty("LogInfo")
	public void setLogInfo(String logInfo) {
		LogInfo = logInfo;
	}
	public String getProgramName() {
		return ProgramName;
	}
	@JsonProperty("ProgramName")
	public void setProgramName(String programName) {
		ProgramName = programName;
	}
}
