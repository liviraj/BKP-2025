package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class AttributeDetails {
    @JsonProperty("AttributeName")
    private String attributeName;

    @JsonProperty("AttributeID")
    private Integer attributeId;

    @JsonProperty("AttributeDetailID")
    private Integer attributeDetailId;

    @JsonProperty("AttributeValue")
    private String attributeValue;

    @JsonProperty("Category")
    private String category;

    @JsonProperty("DisplayName")
    private String displayName;
}
