package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

@JsonPropertyOrder({"WGSRunMaster","WGSStatusMaster"})
public class WGSRoot {

	private List<WGSRunMaster> WGSRunMaster;
	private List<WGSStatusMaster> WGSStatusMaster;
	private List<WGSSizeConstraints> WGSSizeConstraints;
	
	@JsonProperty("WGSRunMaster")
	public List<WGSRunMaster> getWGSRunMaster() {
		return WGSRunMaster;
	}
	public void setWGSRunMaster(List<WGSRunMaster> WGSRunMaster) {
		this.WGSRunMaster = WGSRunMaster;
	}
	@JsonProperty("WGSStatusMaster")
	public List<WGSStatusMaster> getWGSStatusMaster() {
		return WGSStatusMaster;
	}
	public void setWGSStatusMaster(List<WGSStatusMaster> WGSStatusMaster) {
		this.WGSStatusMaster = WGSStatusMaster;
	}
	@JsonProperty("WGSSizeConstraints")
	public List<WGSSizeConstraints> getWGSSizeConstraints() {
		return WGSSizeConstraints;
	}
	public void setWGSSizeConstraints(List<WGSSizeConstraints> wGSSizeConstraints) {
		WGSSizeConstraints = wGSSizeConstraints;
	}

	
}
