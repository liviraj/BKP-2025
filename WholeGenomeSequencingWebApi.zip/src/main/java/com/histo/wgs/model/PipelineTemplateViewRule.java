package com.histo.wgs.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class PipelineTemplateViewRule {
	public String id;
	public String name;
	public String description;
	public ArrayList<TaskOption> taskOptions;
	public ArrayList<EntryPoint> entryPoints;
	public boolean allowParentDatasets;
	public boolean allowChildDatasets;
}
