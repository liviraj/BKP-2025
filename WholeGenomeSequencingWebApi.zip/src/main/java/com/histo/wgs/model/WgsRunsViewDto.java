package com.histo.wgs.model;

import java.util.List;

/**
 * @author ArockiajayarajM
 */
public class WgsRunsViewDto {
	private Integer RelatedWGSRunId = 0;
	private Integer WGSRunID;
	private String RestartParam;
	private String DestinationUploadPath;
	private Integer EmailStatus;
	private String RestartRunFailedParam;
	private String Comments;
	private Integer WGSStatusViewerID;
	private String CombinedStatusViewerID;
	private String CombinedFailedtransferProgramId;
	private Integer ClientProjectID;
	private String ClientProjectCode;
	private String RunName;
	private String Isonboard;
	private String DataRequirement;
	private String NeedHifi;
	private String IsDemultiplexingRequired;
	private Float SCCSQualityFilter;
	private String FileName;
	private String SourceFilepath;
	private String BarcodeType;
	private Float SBarcodeQualityFilter;
	private Integer CreatedBy;
	private String SCreatedBy;
	private String CreatedOn;
	private Integer RunStatusId;
	private Integer TransferStatusId;
	private Integer AnalysisStatusId;
	private Integer LocalTransferID;
	private String RunStatus;
	private String TransferStatus;
	private String AnalysisStatus;
	private String LocalTransferStatus;
	private Integer NumberofPasses;
	private String SampleID;
	private List<WgsSampleId> wgsSampleIds;
	private Integer LastModifiedBy;
	private String SLastModifiedBy;
	private String LastModifiedDate;
	private Integer ModifiedCount;
	private String LocalTransferCompletedTime;
	private String ClientTransferCompletedTime;
	private Integer OrginalDatarequirementID;
	private String OrginalDatarequirement;
	private String ReceivedDate;
	private String TATDate;
	private String EmailDate;
	private boolean isPooledSample;

	public WgsRunsViewDto() {
		super();
	}

	public boolean isIsPooledSample() {
		return isPooledSample;
	}

	public void setIsPooledSample(boolean pooledSample) {
		isPooledSample = pooledSample;
	}

	public Integer getRelatedWGSRunId() {
		return RelatedWGSRunId;
	}

	public void setRelatedWGSRunId(Integer relatedWGSRunId) {
		RelatedWGSRunId = relatedWGSRunId;
	}

	public Integer getWGSRunID() {
		return WGSRunID;
	}

	public void setWGSRunID(Integer wGSRunID) {
		WGSRunID = wGSRunID;
	}

	public String getRestartParam() {
		return RestartParam;
	}

	public void setRestartParam(String restartParam) {
		RestartParam = restartParam;
	}

	public String getDestinationUploadPath() {
		return DestinationUploadPath;
	}

	public void setDestinationUploadPath(String destinationUploadPath) {
		DestinationUploadPath = destinationUploadPath;
	}

	public Integer getEmailStatus() {
		return EmailStatus;
	}

	public void setEmailStatus(Integer emailStatus) {
		EmailStatus = emailStatus;
	}

	public String getRestartRunFailedParam() {
		return RestartRunFailedParam;
	}

	public void setRestartRunFailedParam(String restartRunFailedParam) {
		RestartRunFailedParam = restartRunFailedParam;
	}

	public String getComments() {
		return Comments;
	}

	public void setComments(String comments) {
		Comments = comments;
	}

	public Integer getWGSStatusViewerID() {
		return WGSStatusViewerID;
	}

	public void setWGSStatusViewerID(Integer wGSStatusViewerID) {
		WGSStatusViewerID = wGSStatusViewerID;
	}

	public String getCombinedStatusViewerID() {
		return CombinedStatusViewerID;
	}

	public void setCombinedStatusViewerID(String combinedStatusViewerID) {
		CombinedStatusViewerID = combinedStatusViewerID;
	}

	public String getCombinedFailedtransferProgramId() {
		return CombinedFailedtransferProgramId;
	}

	public void setCombinedFailedtransferProgramId(String combinedFailedtransferProgramId) {
		CombinedFailedtransferProgramId = combinedFailedtransferProgramId;
	}

	public Integer getClientProjectID() {
		return ClientProjectID;
	}

	public void setClientProjectID(Integer clientProjectID) {
		ClientProjectID = clientProjectID;
	}

	public String getClientProjectCode() {
		return ClientProjectCode;
	}

	public void setClientProjectCode(String clientProjectCode) {
		ClientProjectCode = clientProjectCode;
	}

	public String getRunName() {
		return RunName;
	}

	public void setRunName(String runName) {
		RunName = runName;
	}

	public String getDataRequirement() {
		return DataRequirement;
	}

	public void setDataRequirement(String dataRequirement) {
		DataRequirement = dataRequirement;
	}

	public String getIsonboard() {
		return Isonboard;
	}

	public void setIsonboard(String isonboard) {
		Isonboard = isonboard;
	}

	public String getNeedHifi() {
		return NeedHifi;
	}

	public void setNeedHifi(String needHifi) {
		NeedHifi = needHifi;
	}

	public String getIsDemultiplexingRequired() {
		return IsDemultiplexingRequired;
	}

	public void setIsDemultiplexingRequired(String isDemultiplexingRequired) {
		IsDemultiplexingRequired = isDemultiplexingRequired;
	}

	public Float getSCCSQualityFilter() {
		return SCCSQualityFilter;
	}

	public void setSCCSQualityFilter(Float sCCSQualityFilter) {
		SCCSQualityFilter = sCCSQualityFilter;
	}

	public String getFileName() {
		return FileName;
	}

	public void setFileName(String fileName) {
		FileName = fileName;
	}

	public String getSourceFilepath() {
		return SourceFilepath;
	}

	public void setSourceFilepath(String sourceFilepath) {
		SourceFilepath = sourceFilepath;
	}

	public String getBarcodeType() {
		return BarcodeType;
	}

	public void setBarcodeType(String barcodeType) {
		BarcodeType = barcodeType;
	}

	public Float getSBarcodeQualityFilter() {
		return SBarcodeQualityFilter;
	}

	public void setSBarcodeQualityFilter(Float sBarcodeQualityFilter) {
		SBarcodeQualityFilter = sBarcodeQualityFilter;
	}

	public Integer getCreatedBy() {
		return CreatedBy;
	}

	public void setCreatedBy(Integer createdBy) {
		CreatedBy = createdBy;
	}

	public String getSCreatedBy() {
		return SCreatedBy;
	}

	public void setSCreatedBy(String sCreatedBy) {
		SCreatedBy = sCreatedBy;
	}

	public String getCreatedOn() {
		return CreatedOn;
	}

	public void setCreatedOn(String createdOn) {
		CreatedOn = createdOn;
	}

	public Integer getRunStatusId() {
		return RunStatusId;
	}

	public void setRunStatusId(Integer runStatusId) {
		RunStatusId = runStatusId;
	}

	public Integer getTransferStatusId() {
		return TransferStatusId;
	}

	public void setTransferStatusId(Integer transferStatusId) {
		TransferStatusId = transferStatusId;
	}

	public Integer getAnalysisStatusId() {
		return AnalysisStatusId;
	}

	public void setAnalysisStatusId(Integer analysisStatusId) {
		AnalysisStatusId = analysisStatusId;
	}

	public Integer getLocalTransferID() {
		return LocalTransferID;
	}

	public void setLocalTransferID(Integer localTransferID) {
		LocalTransferID = localTransferID;
	}

	public String getRunStatus() {
		return RunStatus;
	}

	public void setRunStatus(String runStatus) {
		RunStatus = runStatus;
	}

	public String getTransferStatus() {
		return TransferStatus;
	}

	public void setTransferStatus(String transferStatus) {
		TransferStatus = transferStatus;
	}

	public String getAnalysisStatus() {
		return AnalysisStatus;
	}

	public void setAnalysisStatus(String analysisStatus) {
		AnalysisStatus = analysisStatus;
	}

	public String getLocalTransferStatus() {
		return LocalTransferStatus;
	}

	public void setLocalTransferStatus(String localTransferStatus) {
		LocalTransferStatus = localTransferStatus;
	}

	public Integer getNumberofPasses() {
		return NumberofPasses;
	}

	public void setNumberofPasses(Integer numberofPasses) {
		NumberofPasses = numberofPasses;
	}

	public String getSampleID() {
		return SampleID;
	}

	public void setSampleID(String sampleID) {
		SampleID = sampleID;
	}

	public List<WgsSampleId> getWgsSampleIds() {
		return wgsSampleIds;
	}

	public void setWgsSampleIds(List<WgsSampleId> wgsSampleIds) {
		this.wgsSampleIds = wgsSampleIds;
	}

	public Integer getLastModifiedBy() {
		return LastModifiedBy;
	}

	public void setLastModifiedBy(Integer lastModifiedBy) {
		LastModifiedBy = lastModifiedBy;
	}

	public String getSLastModifiedBy() {
		return SLastModifiedBy;
	}

	public void setSLastModifiedBy(String sLastModifiedBy) {
		SLastModifiedBy = sLastModifiedBy;
	}

	public String getLastModifiedDate() {
		return LastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		LastModifiedDate = lastModifiedDate;
	}

	public Integer getModifiedCount() {
		return ModifiedCount;
	}

	public void setModifiedCount(Integer modifiedCount) {
		ModifiedCount = modifiedCount;
	}

	public String getLocalTransferCompletedTime() {
		return LocalTransferCompletedTime;
	}

	public void setLocalTransferCompletedTime(String localTransferCompletedTime) {
		LocalTransferCompletedTime = localTransferCompletedTime;
	}

	public String getClientTransferCompletedTime() {
		return ClientTransferCompletedTime;
	}

	public void setClientTransferCompletedTime(String clientTransferCompletedTime) {
		ClientTransferCompletedTime = clientTransferCompletedTime;
	}

	public Integer getOrginalDatarequirementID() {
		return OrginalDatarequirementID;
	}

	public void setOrginalDatarequirementID(Integer orginalDatarequirementID) {
		OrginalDatarequirementID = orginalDatarequirementID;
	}

	public String getOrginalDatarequirement() {
		return OrginalDatarequirement;
	}

	public void setOrginalDatarequirement(String orginalDatarequirement) {
		OrginalDatarequirement = orginalDatarequirement;
	}

	public String getReceivedDate() {
		return ReceivedDate;
	}

	public void setReceivedDate(String receivedDate) {
		ReceivedDate = receivedDate;
	}

	public String getTATDate() {
		return TATDate;
	}

	public void setTATDate(String tATDate) {
		TATDate = tATDate;
	}

	public String getEmailDate() {
		return EmailDate;
	}

	public void setEmailDate(String emailDate) {
		EmailDate = emailDate;
	}

	@Override
	public String toString() {
		return "WgsRunsViewDto [RelatedWGSRunId=" + RelatedWGSRunId + ", WGSRunID=" + WGSRunID + ", RestartParam="
				+ RestartParam + ", DestinationUploadPath=" + DestinationUploadPath + ", EmailStatus=" + EmailStatus
				+ ", RestartRunFailedParam=" + RestartRunFailedParam + ", Comments=" + Comments + ", WGSStatusViewerID="
				+ WGSStatusViewerID + ", CombinedStatusViewerID=" + CombinedStatusViewerID
				+ ", CombinedFailedtransferProgramId=" + CombinedFailedtransferProgramId + ", ClientProjectID="
				+ ClientProjectID + ", ClientProjectCode=" + ClientProjectCode + ", RunName=" + RunName + ", Isonboard="
				+ Isonboard + ", DataRequirement=" + DataRequirement + ", NeedHifi=" + NeedHifi
				+ ", IsDemultiplexingRequired=" + IsDemultiplexingRequired + ", SCCSQualityFilter=" + SCCSQualityFilter
				+ ", FileName=" + FileName + ", SourceFilepath=" + SourceFilepath + ", BarcodeType=" + BarcodeType
				+ ", SBarcodeQualityFilter=" + SBarcodeQualityFilter + ", CreatedBy=" + CreatedBy + ", SCreatedBy="
				+ SCreatedBy + ", CreatedOn=" + CreatedOn + ", RunStatusId=" + RunStatusId + ", TransferStatusId="
				+ TransferStatusId + ", AnalysisStatusId=" + AnalysisStatusId + ", LocalTransferID=" + LocalTransferID
				+ ", RunStatus=" + RunStatus + ", TransferStatus=" + TransferStatus + ", AnalysisStatus="
				+ AnalysisStatus + ", LocalTransferStatus=" + LocalTransferStatus + ", NumberofPasses=" + NumberofPasses
				+ ", SampleID=" + SampleID + ", LastModifiedBy=" + LastModifiedBy + ", SLastModifiedBy="
				+ SLastModifiedBy + ", LastModifiedDate=" + LastModifiedDate + ", ModifiedCount=" + ModifiedCount
				+ ", LocalTransferCompletedTime=" + LocalTransferCompletedTime + ", ClientTransferCompletedTime="
				+ ClientTransferCompletedTime + ", OrginalDatarequirementID=" + OrginalDatarequirementID
				+ ", OrginalDatarequirement=" + OrginalDatarequirement + ", ReceivedDate=" + ReceivedDate + ", TATDate="
				+ TATDate + ", EmailDate=" + EmailDate + "]";
	}

}