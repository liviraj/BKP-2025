
package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class WGSAdvancedPropertyDTO {
    @JsonProperty("AdvancedProperties")
    private List<AdvancedProperty> advancedProperties;
    @JsonProperty("AnalysisApplicationID")
    private Integer analysisApplicationID;
    @JsonProperty("DataTypeID")
    private Integer dataTypeID;
    @JsonProperty("WorkFlowTypeID")
    private Integer workFlowTypeID;
    @JsonProperty("WGSAssociatedInputs")
    private List<WgsAssociatedInputsMasterDTO> associatedInputs;
    private List<WgsBarcodeSampleSetDTO> barcodeSampleSets;
}
