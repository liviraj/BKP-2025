package com.histo.wgs.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class MD5ChecksumInputArgs {
    private String checksumFilePath;
    private String smbServerName;
    private String smbShareName;
    private String smbUsername;
    private String smbPassword;
    private Integer wgsRunId;
    private Integer wgsStatusViewerId;
}
