package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonFilter;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@JsonFilter("FileDataOrganizerResponseModel")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class FileDataOrganizerResponseModel {
    private boolean status;
    private InfoModel information;
    private String responseMsg;
    private Object data;
}
