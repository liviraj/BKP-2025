package com.histo.wgs.model;

public class FileUploaderArgs {
    public UploadType uploadType;
    public String username;
    public String password;
    public boolean isFolder;
    public String oAuth;
    public String sourceEndPoint;
    public String destinationEndPoint;
    public String sourceParentPath;
    public String destinationParentPath;
    public String runName;
    public int wgsStatusViewerID;
    public String sftpUserName;
    public String sftpPassword;
    public String sftpClientDomain;

    public UploadType getUploadType() {
        return uploadType;
    }

    public void setUploadType(UploadType uploadType) {
        this.uploadType = uploadType;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isFolder() {
        return isFolder;
    }

    public void setFolder(boolean isFolder) {
        this.isFolder = isFolder;
    }

    public String getoAuth() {
        return oAuth;
    }

    public void setoAuth(String oAuth) {
        this.oAuth = oAuth;
    }

    public String getSourceEndPoint() {
        return sourceEndPoint;
    }

    public void setSourceEndPoint(String sourceEndPoint) {
        this.sourceEndPoint = sourceEndPoint;
    }

    public String getDestinationEndPoint() {
        return destinationEndPoint;
    }

    public void setDestinationEndPoint(String destinationEndPoint) {
        this.destinationEndPoint = destinationEndPoint;
    }

    public String getSourceParentPath() {
        return sourceParentPath;
    }

    public void setSourceParentPath(String sourceParentPath) {
        this.sourceParentPath = sourceParentPath;
    }

    public String getDestinationParentPath() {
        return destinationParentPath;
    }

    public void setDestinationParentPath(String destinationParentPath) {
        this.destinationParentPath = destinationParentPath;
    }

    public String getRunName() {
        return runName;
    }

    public void setRunName(String runName) {
        this.runName = runName;
    }

    public int getWgsStatusViewerID() {
        return wgsStatusViewerID;
    }

    public void setWgsStatusViewerID(int wgsStatusViewerID) {
        this.wgsStatusViewerID = wgsStatusViewerID;
    }

    public String getSftpUserName() {
        return sftpUserName;
    }

    public void setSftpUserName(String sFTPUsertName) {
        sftpUserName = sFTPUsertName;
    }

    public String getSftpPassword() {
        return sftpPassword;
    }

    public void setSftpPassword(String sFTPPassword) {
        sftpPassword = sFTPPassword;
    }

    public String getSftpClientDomain() {
        return sftpClientDomain;
    }

    public void setSftpClientDomain(String sFTPClientDomain) {
        sftpClientDomain = sFTPClientDomain;
    }

}
