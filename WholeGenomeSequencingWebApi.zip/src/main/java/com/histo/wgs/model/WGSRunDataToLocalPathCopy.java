package com.histo.wgs.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class WGSRunDataToLocalPathCopy {
	
	private int wgsStatusViewerID;
	private String rawSourcePath;
	private String ccsSourcePath;
	private String RunName;
	private String RawDataPath;
	private String baseFolder;
	private String AnalysisDataPath;
	private int AnalysisStatusID;
}
