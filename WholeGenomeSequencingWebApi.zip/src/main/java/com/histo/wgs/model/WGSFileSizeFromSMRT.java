package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class WGSFileSizeFromSMRT {
	@JsonProperty("WGSStatusViewerID")
	public int wgsStatusViewerID;
	@JsonProperty("RunName")
	public String runName;
	@JsonProperty("TotalBase")
	public Object totalBase;
	@JsonProperty("HifiReadLength")
	public Object hifiReadLength;
	@JsonProperty("LongestSubreads")
	public Object longestSubreads;
	@JsonProperty("HifiYield")
	public Object hifiYield;
	@JsonProperty("MinPredictedAccuracy")
	public Object minPredictedAccuracy;
	
	public int getWgsStatusViewerID() {
		return wgsStatusViewerID;
	}
	public void setWgsStatusViewerID(int wgsStatusViewerID) {
		this.wgsStatusViewerID = wgsStatusViewerID;
	}
	public String getRunName() {
		return runName;
	}
	public void setRunName(String runName) {
		this.runName = runName;
	}
	public Object getTotalBase() {
		if(totalBase == null) {
			return "--";
		}
		return totalBase;
	}
	public void setTotalBase(Object totalBase) {
		if(totalBase == null) {
			this.totalBase = "--";
		}
		else {
		this.totalBase = totalBase;
		}
	}
	public Object getHifiReadLength() {
		if(hifiReadLength == null) {
			return "--";
		}
		return hifiReadLength;
	}
	public void setHifiReadLength(Object hifiReadLength) {
		if(hifiReadLength == null) {
			this.hifiReadLength = "--";
		}
		else {
		this.hifiReadLength = hifiReadLength;
		}
	}
	public Object getLongestSubreads() {
		if(longestSubreads == null) {
			return "--";
		}
		return longestSubreads;
	}
	public void setLongestSubreads(Object longestSubreads) {
		if(longestSubreads == null) {
			this.longestSubreads = "--";
		}
		else {
		this.longestSubreads = longestSubreads;
		}
	}
	public Object getHifiYield() {
		if(hifiYield == null) {
			return "--";
		}
		return hifiYield;
	}
	public void setHifiYield(Object hifiYield) {
		if(hifiYield == null) {
			this.hifiYield = "--";
		}
		else {
		this.hifiYield = hifiYield;
		}
	}
	public Object getMinPredictedAccuracy() {
		if(minPredictedAccuracy == null) {
			return "--";
		}
		return minPredictedAccuracy;
	}
	public void setMinPredictedAccuracy(Object minPredictedAccuracy) {
		if(minPredictedAccuracy == null) {
			this.minPredictedAccuracy = "--";
		}
		else {
		this.minPredictedAccuracy = minPredictedAccuracy;
		}
	}
	
}
