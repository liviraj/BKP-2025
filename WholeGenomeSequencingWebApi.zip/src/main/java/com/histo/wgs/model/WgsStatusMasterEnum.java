package com.histo.wgs.model;

public enum WgsStatusMasterEnum {
    NOT_STARTED(1),
    IN_PROGRESS(2),
    COMPLETED(3),
    FAILED(4),
    NOT_APPLICABLE(5);

    private int statusId;

    WgsStatusMasterEnum(int statusId) {
        this.statusId = statusId;
    }

    public int getStatusId() {
        return statusId;
    }
}
