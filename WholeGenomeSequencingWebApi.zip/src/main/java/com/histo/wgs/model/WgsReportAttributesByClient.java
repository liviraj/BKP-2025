package com.histo.wgs.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class WgsReportAttributesByClient {
	private String ReportTo;
	private String ReportCC;
	private String ReportPassword;
	private String MailSubject;
	private int ClientProjectID;
	private int ReportFormatSubTypeID;
	private String ReportFormatSubType;
	private String ShareFileEmailAddress;
	private String ShareFileFolderID;
	private String IsMultipleShareFileLinkRequired;
	private String MailTransmission;
	private String FTPPath;
	private String FTPUserName;
	private String FTPPassword;
	private String FTPType;
	private String FTPSSHHostKey;
	private String IsFTPAttachmentRequired;
	private String IsCompressionRequired;
}
