package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.histo.wgs.entity.WgsDefaultAdvancedPropertyDropdown;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class WGSDefaultAdvancedPropertyDto implements Serializable {
    @JsonProperty("DefaultAdvancedPropertyID")
    private Integer defaultAdvancedPropertyID;
    private String defaultValue;
    private String type;
    private Integer workFlowTypeID;
    private Integer dataTypeID;
    private Integer analysisApplicationID;
    private String propertyLabel;
    private String propertyValue;
    private List<WgsDefaultAdvancedPropertyDropdown> dropdowns;
}