package com.histo.wgs.model;

import jakarta.validation.constraints.Size;

import java.io.Serializable;

public class WGSWorkFlowTypeDto implements Serializable {
    private  Integer id;
    @Size(max = 255)
    private  String workFlowTypeName;

    public WGSWorkFlowTypeDto() {
        super();
    }

    public WGSWorkFlowTypeDto(Integer id, String workFlowTypeName) {
        this.id = id;
        this.workFlowTypeName = workFlowTypeName;
    }

    public Integer getId() {
        return id;
    }

    public String getWorkFlowTypeName() {
        return workFlowTypeName;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setWorkFlowTypeName(String workFlowTypeName) {
        this.workFlowTypeName = workFlowTypeName;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "(" +
                "id = " + id + ", " +
                "workFlowTypeName = " + workFlowTypeName + ")";
    }
}