package com.histo.wgs.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class BarCodeSet{
	private int numResources;
	private String importedAt;
	private String comments;
	private int numRecords;
	private int totalLength;
	private boolean isActive;
	private String uuid;
	private String version;
	private String tags;
	private String path;
	private int jobId;
	private String createdAt;
	private String createdBy;
	private String name;
	private int numChildren;
	private int id;
	private String datasetType;
	private int projectId;
	private String updatedAt;
	private String md5;
}
