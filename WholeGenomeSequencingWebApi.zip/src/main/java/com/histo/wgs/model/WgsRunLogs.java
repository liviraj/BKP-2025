package com.histo.wgs.model;

public class WgsRunLogs {

	private int ActionNo;
	private String ActionDate;
	private String ActionById;
	private String ActionBy;
	private String Action;
	private String programName;

	public WgsRunLogs() {
		super();

	}

	public WgsRunLogs(int actionNo, String actionDate, String actionById, String actionBy, String action,
                      String programName) {
		super();
		ActionNo = actionNo;
		ActionDate = actionDate;
		ActionById = actionById;
		ActionBy = actionBy;
		Action = action;
		this.programName = programName;
	}

	public int getActionNo() {
		return ActionNo;
	}

	public void setActionNo(int actionNo) {
		ActionNo = actionNo;
	}

	public String getActionDate() {
		return ActionDate;
	}

	public void setActionDate(String actionDate) {
		ActionDate = actionDate;
	}

	public String getActionById() {
		return ActionById;
	}

	public void setActionById(String actionById) {
		ActionById = actionById;
	}

	public String getActionBy() {
		return ActionBy;
	}

	public void setActionBy(String actionBy) {
		ActionBy = actionBy;
	}

	public String getAction() {
		return Action;
	}

	public void setAction(String action) {
		Action = action;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	@Override
	public String toString() {
		return "WgsRunLogs [ActionNo=" + ActionNo + ", ActionDate=" + ActionDate + ", ActionById=" + ActionById
				+ ", ActionBy=" + ActionBy + ", Action=" + Action + ", programName=" + programName + "]";
	}
	

	

	
}
