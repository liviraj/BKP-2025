package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

public class WGSRunDetailsShellScriptList {
	private List<WGSRunMaster> WGSRun = new ArrayList<WGSRunMaster>();
	@JsonProperty("WGSRun")
	public List<WGSRunMaster> getWGSRun() {
		return WGSRun;
	}

	public void setWGSRun(List<WGSRunMaster> wGSRun) {
		WGSRun = wGSRun;
	}
	

}
