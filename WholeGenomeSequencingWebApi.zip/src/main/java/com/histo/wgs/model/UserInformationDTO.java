package com.histo.wgs.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class UserInformationDTO {
    private String loginName;
    private int userId;
    private String firstName;
    private String lastName;
    private String emailAddress;
    private Integer formId;
}
