package com.histo.wgs.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class CloudRunDetail {
	private String cloudRunStatus;
	private String cloudCCSPath;
	private int sMRTPortalViewerId;
}
