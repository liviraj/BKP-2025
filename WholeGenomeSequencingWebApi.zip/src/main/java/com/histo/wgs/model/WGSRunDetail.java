package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class WGSRunDetail {
    public int WGSDetailId;
    public int WGSRunID;
    public String SampleID;
    
    @JsonProperty("WGSDetailId") 
	public int getWGSDetailId() {
		return WGSDetailId;
	}
	public void setWGSDetailId(int wGSDetailId) {
		WGSDetailId = wGSDetailId;
	}
	@JsonProperty("WGSRunID") 
	public int getWGSRunID() {
		return WGSRunID;
	}
	public void setWGSRunID(int wGSRunID) {
		WGSRunID = wGSRunID;
	}
	@JsonProperty("SampleID") 
	public String getSampleID() {
		return SampleID;
	}
	public void setSampleID(String sampleID) {
		SampleID = sampleID;
	}
	
}
