package com.histo.wgs.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ActivityLogReq {
    private Integer applicationId;
    private String agreementId;
    private String fileName;
    private Long sampleId;
    private String status;
    private String remarks;
    private Long loginUserId;
}
