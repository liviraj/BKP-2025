package com.histo.wgs.model;

public enum ActionType {
    COPY, MOVE, DELETE;
}
