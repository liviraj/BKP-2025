package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class WgsClientTransferStatus {
	private int WGSStatusViewerID;
	private int Status;
	private String DestinationUplodPath;
	
	public int getWGSStatusViewerID() {
		return WGSStatusViewerID;
	}
	@JsonProperty("WGSStatusViewerID")
	public void setWGSStatusViewerID(int wGSStatusViewerID) {
		WGSStatusViewerID = wGSStatusViewerID;
	}
	public int getStatus() {
		return Status;
	}
	@JsonProperty("Status")
	public void setStatus(int status) {
		Status = status;
	}
	public String getDestinationUplodPath() {
		return DestinationUplodPath;
	}
	@JsonProperty("DestinationUplodPath")
	public void setDestinationUplodPath(String destinationUplodPath) {
		DestinationUplodPath = destinationUplodPath;
	}
	
}
