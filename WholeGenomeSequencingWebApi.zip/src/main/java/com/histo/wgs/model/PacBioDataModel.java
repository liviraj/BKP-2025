package com.histo.wgs.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class PacBioDataModel {
    private String dataLocationOld;
    private String jobID;
    private String dataLocation;
    private Integer isVerified;
    private String failedReason;
}
