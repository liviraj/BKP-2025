package com.histo.wgs.model;

import io.swagger.annotations.ApiModelProperty;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

import java.util.Date;

public class WgsRunCommands {
	@Min(1)
	private int createdBy;
	
	@ApiModelProperty(hidden=true)
	private String commentsRunName;
	@ApiModelProperty(hidden=true)
	private int commentsId;
	@ApiModelProperty(hidden=true)
	private int wGSRunCommentsDetailId;
	
	@ApiModelProperty(hidden=true)
	private int wGSRunId;
	@NotBlank(message = "Comments is mandatory")
	private String comments;
	
	@ApiModelProperty(hidden=true)
	private String commentsFrom;
	@ApiModelProperty(hidden=true)
	private Date createdOn;
	@ApiModelProperty(hidden=true)
	private int commentsAutoId;
	@ApiModelProperty(hidden=true)
	private String commentsRunNameTest;
	@Min(1)
	private int wGSStatusViewerID;

	public WgsRunCommands() {
		super();
	}

	public WgsRunCommands(int createdBy, String commentsRunName, int commentsId, int wGSRunCommentsDetailId,
			int wGSRunId, String comments, String commentsFrom, Date createdOn, int commentsAutoId,
			String commentsRunNameTest, int wGSStatusViewerID) {
		super();
		this.createdBy = createdBy;
		this.commentsRunName = commentsRunName;
		this.commentsId = commentsId;
		this.wGSRunCommentsDetailId = wGSRunCommentsDetailId;
		this.wGSRunId = wGSRunId;
		this.comments = comments;
		this.commentsFrom = commentsFrom;
		this.createdOn = createdOn;
		this.commentsAutoId = commentsAutoId;
		this.commentsRunNameTest = commentsRunNameTest;
		this.wGSStatusViewerID = wGSStatusViewerID;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public String getCommentsRunName() {
		return commentsRunName;
	}

	public void setCommentsRunName(String commentsRunName) {
		this.commentsRunName = commentsRunName;
	}

	public int getCommentsId() {
		return commentsId;
	}

	public void setCommentsId(int commentsId) {
		this.commentsId = commentsId;
	}

	public int getwGSRunCommentsDetailId() {
		return wGSRunCommentsDetailId;
	}

	public void setwGSRunCommentsDetailId(int wGSRunCommentsDetailId) {
		this.wGSRunCommentsDetailId = wGSRunCommentsDetailId;
	}

	public int getwGSRunId() {
		return wGSRunId;
	}

	public void setwGSRunId(int wGSRunId) {
		this.wGSRunId = wGSRunId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getCommentsFrom() {
		return commentsFrom;
	}

	public void setCommentsFrom(String commentsFrom) {
		this.commentsFrom = commentsFrom;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public int getCommentsAutoId() {
		return commentsAutoId;
	}

	public void setCommentsAutoId(int commentsAutoId) {
		this.commentsAutoId = commentsAutoId;
	}

	public String getcommentsRunNameTest() {
		return  commentsRunNameTest;
	}

	public void setcommentsRunNameTest(String commentsRunNameTest) {
		this.commentsRunNameTest = commentsRunNameTest;
	}

	public int getwGSStatusViewerID() {
		return wGSStatusViewerID;
	}

	public void setwGSStatusViewerID(int wGSStatusViewerID) {
		this.wGSStatusViewerID = wGSStatusViewerID;
	}

	@Override
	public String toString() {
		return "WgsRunCommands [createdBy=" + createdBy + ", commentsRunName=" + commentsRunName + ", commentsId="
				+ commentsId + ", wGSRunCommentsDetailId=" + wGSRunCommentsDetailId + ", wGSRunId=" + wGSRunId
				+ ", comments=" + comments + ", commentsFrom=" + commentsFrom + ", createdOn=" + createdOn
				+ ", commentsAutoId=" + commentsAutoId + ", CommentsRunNameTest=" + commentsRunNameTest
				+ ", wGSStatusViewerID=" + wGSStatusViewerID + "]";
	}

	

}
