package com.histo.wgs.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class TaskOption {
	public String id;
	public boolean hidden;
	public boolean advanced;
	public boolean required;
	public int min;
	public int max;
	public String templateLink;
}
