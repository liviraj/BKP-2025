package com.histo.wgs.model;

import lombok.*;

@NoArgsConstructor
@Getter
@Setter
@AllArgsConstructor
@ToString
public class LogDetailModel {
    private Integer logDetailId;
    private String actionType;
    private String sourceLocation;
    private String destinationLocation;
    private String deleteLocation;
    private String status;
    private String program;
}
