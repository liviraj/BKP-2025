package com.histo.wgs.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class SampleDetail {
    private String sampleName;
    private List<PooledSample> pooledSamples;
    private boolean isPooledSample;
    private Long sampleId;
}
