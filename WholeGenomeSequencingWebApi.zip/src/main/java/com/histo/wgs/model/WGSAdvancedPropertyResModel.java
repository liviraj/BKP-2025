package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.histo.wgs.entity.*;
import com.histo.wgs.exception.ExceptionBean;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@JsonFilter("WGSAdvancedPropertyResModel")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class WGSAdvancedPropertyResModel {
    private boolean status;
    private ExceptionBean information;
    private List<WGSDataTypeMaster> wgsDataTypeMasters;
    private List<WGSAnalysisApplicationMaster> analysisApplicationMasterList;
    private List<Object> defaultAdvanceProperties;
    private List<WGSWorkFlowType> workFlowTypes;
    private List<WGSDefaultAdvancedPropertyDto> wgsDefaultAdvancedProperties;
    private List<WGSAdvancedProperty> wgsAdvancedProperties;
    private WGSAdvancedPropertyViewDTO advancedPropertiesDTO;
    private List<WgsDefaultAdvancedPropertyDropdown> defaultAdvancedPropertyDropdowns;
    private List<ReferenceGenomeSet> referenceGenomeSets;
    private List<WgsAssociatedInput> associatedInputs;
    private ReferenceGenomeSet referenceGenomeSet;
    private List<BarCodeSet> barCodeSets;
    private List<String> barCodeRecordNames;
    private String responseMsg;
    private SmrtWgsAdvancedProperty smrtWgsAdvancedProperty;
    private DemuxCCSStatus demuxCCSStatus;
}
