package com.histo.wgs.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class WgsRunClientProjects {
    private int ClientProjectID;
    private String ClientProjectName;
    private String ClientProjectCode;

    public WgsRunClientProjects(int clientProjectID, String clientProjectName) {
        super();
        ClientProjectID = clientProjectID;
        ClientProjectName = clientProjectName;
    }
}
