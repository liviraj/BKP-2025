package com.histo.wgs.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class CloudFileTransferStatus {
	private int wGSStatusViewerID;
	private String cloudFileTransferStatus;
	private String analysisDataPath;
}
