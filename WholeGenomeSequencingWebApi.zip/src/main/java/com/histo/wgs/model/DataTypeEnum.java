package com.histo.wgs.model;

public enum DataTypeEnum {
    subreads,
    ccsreads
}
