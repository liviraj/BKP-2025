package com.histo.wgs.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ReferenceGenomeSet {
    private Integer id;
    private String name;
    private String organism;
    private Integer numRecords;
    private long totalLength;
}
