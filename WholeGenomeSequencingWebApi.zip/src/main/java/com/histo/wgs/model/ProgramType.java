package com.histo.wgs.model;

public enum ProgramType {
    WGS,GRIDION
}
