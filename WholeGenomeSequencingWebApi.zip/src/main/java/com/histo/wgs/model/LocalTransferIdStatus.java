package com.histo.wgs.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class LocalTransferIdStatus {
	private int wgsStatusViewerId;
	private int status;
	private String sourcePath;
	private int uploadTypeId;
	private String failureReason;
}
