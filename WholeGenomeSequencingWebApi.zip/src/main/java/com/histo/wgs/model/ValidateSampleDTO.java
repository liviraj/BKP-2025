package com.histo.wgs.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ValidateSampleDTO {
    private Integer id;
    private String wgsSampleId;
    private boolean isValid;
}
