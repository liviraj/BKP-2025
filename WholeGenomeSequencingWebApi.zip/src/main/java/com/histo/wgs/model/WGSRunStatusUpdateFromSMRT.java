package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class WGSRunStatusUpdateFromSMRT {
	private int WGSRunID;
	private int WGSStatusViewerID;
	private int RunStatusID;
	private String RawDataPath;
	private String AnalysisDataPath;
	private String SampleID;
	private String WGSStaticsPDFPath;
	private String InstrumentName;
	private int UserID;
	private String startedAt;
	private String completedAt;

	public String getStartedAt() {
		return startedAt;
	}

	public void setStartedAt(String startedAt) {
		this.startedAt = startedAt;
	}

	public String getCompletedAt() {
		return completedAt;
	}

	public void setCompletedAt(String completedAt) {
		this.completedAt = completedAt;
	}

	@JsonProperty("InstrumentName")
	public String getInstrumentName() {
		return InstrumentName;
	}
	public void setInstrumentName(String instrumentName) {
		InstrumentName = instrumentName;
	}
	@JsonProperty("WGSRunID")
	public int getWGSRunID() {
		return WGSRunID;
	}
	public void setWGSRunID(int wGSRunID) {
		WGSRunID = wGSRunID;
	}
	@JsonProperty("WGSStatusViewerID")
	public int getWGSStatusViewerID() {
		return WGSStatusViewerID;
	}
	public void setWGSStatusViewerID(int wGSStatusViewerID) {
		WGSStatusViewerID = wGSStatusViewerID;
	}
	@JsonProperty("RunStatusID")
	public int getRunStatusID() {
		return RunStatusID;
	}
	public void setRunStatusID(int runStatusID) {
		RunStatusID = runStatusID;
	}
	@JsonProperty("RawDataPath")
	public String getRawDataPath() {
		return RawDataPath;
	}
	public void setRawDataPath(String rawDataPath) {
		RawDataPath = rawDataPath;
	}
	@JsonProperty("AnalysisDataPath")
	public String getAnalysisDataPath() {
		return AnalysisDataPath;
	}
	public void setAnalysisDataPath(String analysisDataPath) {
		AnalysisDataPath = analysisDataPath;
	}
	@JsonProperty("SampleID")
	public String getSampleID() {
		return SampleID;
	}
	public void setSampleID(String sampleID) {
		SampleID = sampleID;
	}
	@JsonProperty("WGSStaticsPDFPath")
	public String getWGSStaticsPDFPath() {
		return WGSStaticsPDFPath;
	}
	public void setWGSStaticsPDFPath(String wGSStaticsPDFPath) {
		WGSStaticsPDFPath = wGSStaticsPDFPath;
	}
	@JsonProperty("UserID")
	public int getUserID() {
		return UserID;
	}
	public void setUserID(int userID) {
		UserID = userID;
	}
	

}
