package com.histo.wgs.model;

public enum SMRTRunEnum {
    DEMULTIPLEX, CCS;
}
