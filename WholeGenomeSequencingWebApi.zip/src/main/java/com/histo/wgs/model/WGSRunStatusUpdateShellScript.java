package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class WGSRunStatusUpdateShellScript {
	private int WGSRunID;
	private int WGSStatusViewerID;
	private int AnalysisStatusID;
	private String AnalysisDataPath;
	private String SampleID;
	
	@JsonProperty("WGSRunID")
	public int getWGSRunID() {
		return WGSRunID;
	}
	public void setWGSRunID(int wGSRunID) {
		WGSRunID = wGSRunID;
	}
	@JsonProperty("WGSStatusViewerID")
	public int getWGSStatusViewerID() {
		return WGSStatusViewerID;
	}
	public void setWGSStatusViewerID(int wGSStatusViewerID) {
		WGSStatusViewerID = wGSStatusViewerID;
	}
	@JsonProperty("AnalysisStatusID")
	public int getAnalysisStatusID() {
		return AnalysisStatusID;
	}
	public void setAnalysisStatusID(int analysisStatusID) {
		AnalysisStatusID = analysisStatusID;
	}
	@JsonProperty("AnalysisDataPath")
	public String getAnalysisDataPath() {
		return AnalysisDataPath;
	}
	public void setAnalysisDataPath(String analysisDataPath) {
		AnalysisDataPath = analysisDataPath;
	}
	@JsonProperty("SampleID")
	public String getSampleID() {
		return SampleID;
	}
	public void setSampleID(String sampleID) {
		SampleID = sampleID;
	}
	
}
