package com.histo.wgs.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class SMRTInputArgs {
	public String filePath;
    public String dataType;
    public String dataSetName;
    public String analysisApplicationName;
    public String ccsMinPassesValue;
    public String ccsMinPredictedAccuracy;
    public String barCodeSetName;
    public String wgsStatusViewerID;
}
