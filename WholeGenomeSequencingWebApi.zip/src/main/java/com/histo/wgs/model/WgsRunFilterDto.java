/**
 * 
 */
package com.histo.wgs.model;

/**
 * @author ArockiajayarajM
 *
 */
public class WgsRunFilterDto {

	private Integer clientProjectId = 0;
	private String startDate;
	private String endDate;
	private Integer runStatusId = 0;
	private Integer transferStatusId = 0;
	private Integer analysisStatusId = 0;
	private Integer localTransferId = 0;

	public WgsRunFilterDto() {
		super();
	}

	public WgsRunFilterDto(Integer clientProjectId, String startDate, String endDate, Integer runStatusId,
                           Integer transferStatusId, Integer analysisStatusId, Integer localTransferId) {
		super();
		this.clientProjectId = clientProjectId;
		this.startDate = startDate;
		this.endDate = endDate;
		this.runStatusId = runStatusId;
		this.transferStatusId = transferStatusId;
		this.analysisStatusId = analysisStatusId;
		this.localTransferId = localTransferId;
	}

	public Integer getClientProjectId() {
		return clientProjectId;
	}

	public void setClientProjectId(Integer clientProjectId) {
		this.clientProjectId = clientProjectId;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public Integer getRunStatusId() {
		return runStatusId;
	}

	public void setRunStatusId(Integer runStatusId) {
		this.runStatusId = runStatusId;
	}

	public Integer getTransferStatusId() {
		return transferStatusId;
	}

	public void setTransferStatusId(Integer transferStatusId) {
		this.transferStatusId = transferStatusId;
	}

	public Integer getAnalysisStatusId() {
		return analysisStatusId;
	}

	public void setAnalysisStatusId(Integer analysisStatusId) {
		this.analysisStatusId = analysisStatusId;
	}

	public Integer getLocalTransferId() {
		return localTransferId;
	}

	public void setLocalTransferId(Integer localTransferId) {
		this.localTransferId = localTransferId;
	}

	@Override
	public String toString() {
		return "WgsRunFilterDto [clientProjectId=" + clientProjectId + ", startDate=" + startDate + ", endDate="
				+ endDate + ", runStatusId=" + runStatusId + ", transferStatusId=" + transferStatusId
				+ ", analysisStatusId=" + analysisStatusId + ", localTransferId=" + localTransferId + "]";
	}

}
