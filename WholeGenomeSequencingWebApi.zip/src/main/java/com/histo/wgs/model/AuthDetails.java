package com.histo.wgs.model;

import org.apache.commons.codec.binary.Base64;

public class AuthDetails {
	private String userid;
	private String password;
	private String AccessToken;
	private int ExpiryTime;
	private String HistoEndPoint;
	private String ClientEndPoint;
	private String SourceParentPath;
	private String DestinationParentPath;
	private String CredentialJson;
	private boolean isAuthTokenExpired=false;

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		if (password != null) {
			this.password = new String(new Base64().decode(password.getBytes()));
		} else {
			this.password = password;
		}
	}

	public String getAccessToken() {
		return AccessToken;
	}

	public void setAccessToken(String accessToken) {
		AccessToken = accessToken;
	}

	public int getExpiryTime() {
		return ExpiryTime;
	}

	public void setExpiryTime(int expiryTime) {
		ExpiryTime = expiryTime;
	}

	public String getHistoEndPoint() {
		return HistoEndPoint;
	}

	public void setHistoEndPoint(String histoEndPoint) {
		HistoEndPoint = histoEndPoint;
	}

	public String getClientEndPoint() {
		return ClientEndPoint;
	}

	public void setClientEndPoint(String clientEndPoint) {
		ClientEndPoint = clientEndPoint;
	}

	public String getSourceParentPath() {
		return SourceParentPath;
	}

	public void setSourceParentPath(String sourceParentPath) {
		SourceParentPath = sourceParentPath;
	}

	public String getDestinationParentPath() {
		return DestinationParentPath;
	}

	public void setDestinationParentPath(String destinationParentPath) {
		DestinationParentPath = destinationParentPath;
	}

	public String getCredentialJson() {
		return CredentialJson;
	}

	public void setCredentialJson(String credentialJson) {
		String[] splitCredJson = credentialJson.split("\"access_token\":\"");
		String[] splitCredToPassFileUploader = splitCredJson[1].split(",");
		CredentialJson = splitCredToPassFileUploader[0].replace("\"", "");
	}

	public boolean isAuthTokenExpired() {
		return isAuthTokenExpired;
	}

	public void setIsAuthTokenExpired(boolean isAuthTokenExpired) {
		this.isAuthTokenExpired = isAuthTokenExpired;
	}

}
