package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class WGSRestartLocalCopyProcessInput {
	private int wgsRunId;
	private int wgsStatusViewerID;
	private String runName;
	private String localTransferStatus;
	private String transferStatus;
	private String sourcePath;
	private String destinationPath;
	private int programNameId;
	private String programName;
	@JsonProperty("UserID")
	private int UserID;
}
