package com.histo.wgs.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@ToString
@AllArgsConstructor
public class LoginModel {
	private String emailId;
}
