package com.histo.wgs.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class DataDeletionModel {
    private String desPath;
    private String desSmbServerName;
    private String desSmbShareName;
    private String desSmbUsername;
    private String desSmbPassword;
    private Integer wgsRunId;
    private Integer wgsStatusViewerId;
    private String sourcePath;
    private String sourceSMBServerName;
    private String sourceSMBShareName;
    private String sourceSMBUsername;
    private String sourceSMBPassword;
}
