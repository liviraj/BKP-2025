package com.histo.wgs.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class DemuxCCSStatusUpdateModel {
    private SMRTRunEnum smrtRunEnum;
    private Short runStatus;
}
