package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class WGSStatusViewer {
    public int WGSStatusViewerID;
    public int WGSRunID;
    public int RunStatusID;
    public int AnalysisStatusID;
    public int TransferStatusID;
    public String DestinationUploadPath;
    public String RawDataPath;
    public int LocalTransferID;
    public String SourcePath;
    public String AnalysisDataPath;
    
    @JsonProperty("WGSStatusViewerID") 
	public int getWGSStatusViewerID() {
		return WGSStatusViewerID;
	}
	public void setWGSStatusViewerID(int WGSStatusViewerID) {
		this.WGSStatusViewerID = WGSStatusViewerID;
	}
	@JsonProperty("WGSRunID") 
	public int getWGSRunID() {
		return WGSRunID;
	}
	public void setWGSRunID(int wGSRunID) {
		WGSRunID = wGSRunID;
	}
	@JsonProperty("RunStatusID")
	public int getRunStatusID() {
		return RunStatusID;
	}
	public void setRunStatusID(int runStatusID) {
		RunStatusID = runStatusID;
	}
	@JsonProperty("AnalysisStatusID") 
	public int getAnalysisStatusID() {
		return AnalysisStatusID;
	}
	public void setAnalysisStatusID(int analysisStatusID) {
		AnalysisStatusID = analysisStatusID;
	}
	@JsonProperty("TransferStatusID") 
	public int getTransferStatusID() {
		return TransferStatusID;
	}
	public void setTransferStatusID(int transferStatusID) {
		TransferStatusID = transferStatusID;
	}
	@JsonProperty("DestinationUploadPath")
	public String getDestinationUploadPath() {
		return DestinationUploadPath;
	}
	public void setDestinationUploadPath(String destinationUploadPath) {
		DestinationUploadPath = destinationUploadPath;
	}
	
	@JsonProperty("LocalTransferID")
	public int getLocalTransferID() {
		return LocalTransferID;
	}
	public void setLocalTransferID(int localTransferID) {
		LocalTransferID = localTransferID;
	}
	@JsonProperty("RawDataPath")
	public String getRawDataPath() {
		return RawDataPath;
	}
	public void setRawDataPath(String rawDataPath) {
		RawDataPath = rawDataPath;
	}
	@JsonProperty("SourcePath")
	public String getSourcePath() {
		return SourcePath;
	}
	public void setSourcePath(String sourcePath) {
		SourcePath = sourcePath;
	}
	@JsonProperty("AnalysisDataPath")
	public String getAnalysisDataPath() {
		return AnalysisDataPath;
	}
	public void setAnalysisDataPath(String analysisDataPath) {
		AnalysisDataPath = analysisDataPath;
	}

}
