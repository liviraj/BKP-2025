package com.histo.wgs.model;

public enum BarCodeTypeEnum {
    SYMMETRIC("Symmetric"),
    ASYMMETRIC("Asymmetric");
    public String value;

    BarCodeTypeEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
