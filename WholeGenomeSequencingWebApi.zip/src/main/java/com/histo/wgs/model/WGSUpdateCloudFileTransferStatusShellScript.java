package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class WGSUpdateCloudFileTransferStatusShellScript {
	private int WGSRunID;
	private int WGSStatusViewerID;
	private String CloudFileTransfer;
	private String AnalysisDataPath;
	
	@JsonProperty("WGSRunID")
	public int getWGSRunID() {
		return WGSRunID;
	}
	public void setWGSRunID(int wGSRunID) {
		WGSRunID = wGSRunID;
	}
	@JsonProperty("WGSStatusViewerID")
	public int getWGSStatusViewerID() {
		return WGSStatusViewerID;
	}
	public void setWGSStatusViewerID(int wGSStatusViewerID) {
		WGSStatusViewerID = wGSStatusViewerID;
	}
	@JsonProperty("CloudFileTransfer")
	public String getCloudFileTransfer() {
		return CloudFileTransfer;
	}
	public void setCloudFileTransfer(String cloudFileTransfer) {
		CloudFileTransfer = cloudFileTransfer;
	}
	@JsonProperty("AnalysisDataPath")
	public String getAnalysisDataPath() {
		return AnalysisDataPath;
	}
	public void setAnalysisDataPath(String analysisDataPath) {
		AnalysisDataPath = analysisDataPath;
	}
	

}
