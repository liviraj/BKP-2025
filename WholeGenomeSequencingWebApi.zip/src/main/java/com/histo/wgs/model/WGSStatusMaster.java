package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class WGSStatusMaster {
    public int StatusID;
    public String Status;
    
    @JsonProperty("StatusID") 
	public int getStatusID() {
		return StatusID;
	}
	public void setStatusID(int statusID) {
		StatusID = statusID;
	}
	@JsonProperty("Status")
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
    
}
