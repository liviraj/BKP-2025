package com.histo.wgs.model;


import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

public class WgsRunPinNo
{
	@NotBlank(message = "IPIN is mandatory")
	private String iPIN;
	@Min(1)
	private int formID;
	public WgsRunPinNo() {
		super();
		}
	public WgsRunPinNo(String iPIN, int formID) {
		super();
		this.iPIN = iPIN;
		this.formID = formID;
	}
	public String getiPIN() {
		return iPIN;
	}
	public void setiPIN(String iPIN) {
		this.iPIN = iPIN;
	}
	public int getFormID() {
		return formID;
	}
	public void setFormID(int formID) {
		this.formID = formID;
	}
	@Override
	public String toString() {
		return "WgsRunPinNo [iPIN=" + iPIN + ", formID=" + formID + "]";
	}
	
	
	

}
