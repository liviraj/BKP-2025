package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class WgsAssociatedInputsMasterDTO {
    @JsonProperty("associatedInputMasterId")
    private Integer id;
    private String value;
    private Integer associatedInputId;
    private String propertyLabel;
    private String propertyValue;
    private String defaultValue;
    private String type;
    private String uuid;
    private Integer analysisApplicationId;
}
