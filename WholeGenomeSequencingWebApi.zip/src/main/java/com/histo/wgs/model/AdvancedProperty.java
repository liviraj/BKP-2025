
package com.histo.wgs.model;

import com.histo.wgs.entity.WgsDefaultAdvancedPropertyDropdown;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class AdvancedProperty {
    private Integer advancedPropertyId;
    private Integer defaultAdvancedPropertyID;
    private Integer dropdownID;
    private String value;
    private String type;
    private String propertyLabel;
    private String propertyValue;
    private List<WgsDefaultAdvancedPropertyDropdown> dropdowns;
    private Integer analysisApplicationId;
}
