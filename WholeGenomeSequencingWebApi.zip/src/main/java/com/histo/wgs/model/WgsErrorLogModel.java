package com.histo.wgs.model;

import com.azure.core.annotation.Get;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class WgsErrorLogModel {
    private int wgsRunId;
    private int wgsStatusViewerId;
    private String logInfo;
    private String programName;
}
