package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.List;

public class WGSRunUpdateDto {
    @NotBlank(message = "SampleID is mandatory")
    private String sampleId;
    @Min(1)
    private int wgsRunID;
    @NotBlank(message = "RunName is mandatory")
    private String runName;
    @Min(1)
    private int clientProjectID;
    @NotNull(message = "Isonboard is mandatory")
    private boolean isOnBoard;
    @NotNull(message = "NeedHifi is mandatory")
    private boolean needHifi;
    @NotNull(message = "CCSQualityFilter is mandatory")
    private float CCSQualityFilter;
    private int numberofPasses;
    @NotNull(message = "IsDemultiplexingRequired is mandatory")
    private boolean isDemultiplexingRequired;
    private String filename;
    private String barcodeType;
    private float qualityFilter;
    private String sourceFilepathWithFilename;
    @Min(1)
    private int createdBy;
    @Min(1)
    @Max(3)
    private int dataRequirementId;
    private boolean isOverWrite;
    private List<WGSAdvancedPropertyDTO> advancedPropertiesRoot;
    private boolean pooledSample;

    public WGSRunUpdateDto() {
        super();
    }

    public boolean isPooledSample() {
        return pooledSample;
    }

    public void setPooledSample(boolean pooledSample) {
        this.pooledSample = pooledSample;
    }
    public List<WGSAdvancedPropertyDTO> getAdvancedPropertiesRoot() {
        return advancedPropertiesRoot;
    }

    public void setAdvancedPropertiesRoot(List<WGSAdvancedPropertyDTO> advancedPropertiesRoot) {
        this.advancedPropertiesRoot = advancedPropertiesRoot;
    }

    public boolean isOverWrite() {
        return isOverWrite;
    }

    public void setOverWrite(boolean overWrite) {
        isOverWrite = overWrite;
    }

    public int getWgsRunID() {
        return wgsRunID;
    }

    public void setWgsRunID(int wgsRunID) {
        this.wgsRunID = wgsRunID;
    }

    public String getSampleId() {
        return sampleId;
    }

    public void setSampleId(String sampleId) {
        this.sampleId = sampleId;
    }

    public String getRunName() {
        return runName;
    }

    public void setRunName(String runName) {
        this.runName = runName;
    }

    public int getClientProjectID() {
        return clientProjectID;
    }

    public void setClientProjectID(int clientProjectID) {
        this.clientProjectID = clientProjectID;
    }

    @JsonProperty("isOnBoard")
    public boolean isOnBoard() {
        return isOnBoard;
    }

    public void setOnBoard(boolean isOnBoard) {
        this.isOnBoard = isOnBoard;
    }

    public boolean isNeedHifi() {
        return needHifi;
    }

    public void setNeedHifi(boolean needHifi) {
        this.needHifi = needHifi;
    }

    public float getCCSQualityFilter() {
        return CCSQualityFilter;
    }

    public void setCCSQualityFilter(float CCSQualityFilter) {
        this.CCSQualityFilter = CCSQualityFilter;
    }

    public int getNumberofPasses() {
        return numberofPasses;
    }

    public void setNumberofPasses(int numberofPasses) {
        this.numberofPasses = numberofPasses;
    }

    @JsonProperty("isDemultiplexingRequired")
    public boolean isDemultiplexingRequired() {
        return isDemultiplexingRequired;
    }

    public void setDemultiplexingRequired(boolean isDemultiplexingRequired) {
        this.isDemultiplexingRequired = isDemultiplexingRequired;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getBarcodeType() {
        return barcodeType;
    }

    public void setBarcodeType(String barcodeType) {
        this.barcodeType = barcodeType;
    }

    public float getQualityFilter() {
        return qualityFilter;
    }

    public void setQualityFilter(float qualityFilter) {
        this.qualityFilter = qualityFilter;
    }

    public String getSourceFilepathWithFilename() {
        return sourceFilepathWithFilename;
    }

    public void setSourceFilepathWithFilename(String sourceFilepathWithFilename) {
        this.sourceFilepathWithFilename = sourceFilepathWithFilename;
    }

    public int getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }

    public int getDataRequirementId() {
        return dataRequirementId;
    }

    public void setDataRequirementId(int dataRequirementId) {
        this.dataRequirementId = dataRequirementId;
    }

    @Override
    public String toString() {
        return "WGSRunUpdateDto{" +
                "sampleId='" + sampleId + '\'' +
                ", wgsRunID=" + wgsRunID +
                ", runName='" + runName + '\'' +
                ", clientProjectID=" + clientProjectID +
                ", isOnBoard=" + isOnBoard +
                ", needHifi=" + needHifi +
                ", CCSQualityFilter=" + CCSQualityFilter +
                ", numberofPasses=" + numberofPasses +
                ", isDemultiplexingRequired=" + isDemultiplexingRequired +
                ", filename='" + filename + '\'' +
                ", barcodeType='" + barcodeType + '\'' +
                ", qualityFilter=" + qualityFilter +
                ", sourceFilepathWithFilename='" + sourceFilepathWithFilename + '\'' +
                ", createdBy=" + createdBy +
                ", dataRequirementId=" + dataRequirementId +
                ", isOverWrite=" + isOverWrite +
                ", advancedPropertiesRoot=" + advancedPropertiesRoot +
                ", pooledSample=" + pooledSample +
                '}';
    }
}
