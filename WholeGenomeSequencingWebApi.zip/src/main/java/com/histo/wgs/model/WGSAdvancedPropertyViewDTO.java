
package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.histo.wgs.entity.WGSDataTypeMaster;

import java.util.List;

public class WGSAdvancedPropertyViewDTO {
    @JsonProperty("AdvancedProperties")
    private List<AdvancedProperty> advancedProperties;
    @JsonProperty("AnalysisApplicationID")
    private Integer analysisApplicationID;
    @JsonProperty("DataTypeID")
    private Integer dataTypeID;
    @JsonProperty("WGSRunID")
    private Integer wGSRunID;
    @JsonProperty("WorkFlowTypeID")
    private Integer workFlowTypeID;
    private List<WGSWorkFlowTypeDto> workFlowTypes;
    private List<WGSDataTypeMaster> wgsDataTypeMasters;
    private List<WGSAnalysisApplicationMasterDto> wgsAnalysisApplicationMasters;
    private List<WgsAssociatedInputsMasterDTO> associatedInputsMasters;
    private List<WGSDefaultAdvancedPropertyDto> defaultAdvancedProperties;
    private List<WgsBarcodeSampleSetDTO> barcodeSampleSetList;

    public WGSAdvancedPropertyViewDTO() {
    }

    public List<WgsBarcodeSampleSetDTO> getBarcodeSampleSetList() {
        return barcodeSampleSetList;
    }

    public void setBarcodeSampleSetList(List<WgsBarcodeSampleSetDTO> barcodeSampleSetList) {
        this.barcodeSampleSetList = barcodeSampleSetList;
    }

    public List<WGSDefaultAdvancedPropertyDto> getDefaultAdvancedProperties() {
        return defaultAdvancedProperties;
    }

    public void setDefaultAdvancedProperties(List<WGSDefaultAdvancedPropertyDto> defaultAdvancedProperties) {
        this.defaultAdvancedProperties = defaultAdvancedProperties;
    }

    public List<WGSWorkFlowTypeDto> getWorkFlowTypes() {
        return workFlowTypes;
    }

    public void setWorkFlowTypes(List<WGSWorkFlowTypeDto> workFlowTypes) {
        this.workFlowTypes = workFlowTypes;
    }

    public List<WGSDataTypeMaster> getWgsDataTypeMasters() {
        return wgsDataTypeMasters;
    }

    public void setWgsDataTypeMasters(List<WGSDataTypeMaster> wgsDataTypeMasters) {
        this.wgsDataTypeMasters = wgsDataTypeMasters;
    }

    public List<WGSAnalysisApplicationMasterDto> getWgsAnalysisApplicationMasters() {
        return wgsAnalysisApplicationMasters;
    }

    public void setWgsAnalysisApplicationMasters(List<WGSAnalysisApplicationMasterDto> wgsAnalysisApplicationMasters) {
        this.wgsAnalysisApplicationMasters = wgsAnalysisApplicationMasters;
    }

    public List<AdvancedProperty> getAdvancedProperties() {
        return advancedProperties;
    }

    public void setAdvancedProperties(List<AdvancedProperty> advancedProperties) {
        this.advancedProperties = advancedProperties;
    }

    public Integer getAnalysisApplicationID() {
        return analysisApplicationID;
    }

    public void setAnalysisApplicationID(Integer analysisApplicationID) {
        this.analysisApplicationID = analysisApplicationID;
    }

    public Integer getDataTypeID() {
        return dataTypeID;
    }

    public void setDataTypeID(Integer dataTypeID) {
        this.dataTypeID = dataTypeID;
    }

    public Integer getwGSRunID() {
        return wGSRunID;
    }

    public void setwGSRunID(Integer wGSRunID) {
        this.wGSRunID = wGSRunID;
    }

    public Integer getWorkFlowTypeID() {
        return workFlowTypeID;
    }

    public void setWorkFlowTypeID(Integer workFlowTypeID) {
        this.workFlowTypeID = workFlowTypeID;
    }

    public List<WgsAssociatedInputsMasterDTO> getAssociatedInputsMasters() {
        return associatedInputsMasters;
    }

    public void setAssociatedInputsMasters(List<WgsAssociatedInputsMasterDTO> associatedInputsMasters) {
        this.associatedInputsMasters = associatedInputsMasters;
    }

    @Override
    public String toString() {
        return "WGSAdvancedPropertyViewDTO{" +
                "advancedProperties=" + advancedProperties +
                ", analysisApplicationID=" + analysisApplicationID +
                ", dataTypeID=" + dataTypeID +
                ", wGSRunID=" + wGSRunID +
                ", workFlowTypeID=" + workFlowTypeID +
                ", workFlowTypes=" + workFlowTypes +
                ", wgsDataTypeMasters=" + wgsDataTypeMasters +
                ", wgsAnalysisApplicationMasters=" + wgsAnalysisApplicationMasters +
                ", associatedInputsMasters=" + associatedInputsMasters +
                ", defaultAdvancedProperties=" + defaultAdvancedProperties +
                ", barcodeSampleSetList=" + barcodeSampleSetList +
                '}';
    }
}
