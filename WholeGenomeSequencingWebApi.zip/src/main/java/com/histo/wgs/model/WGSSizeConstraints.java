package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class WGSSizeConstraints {
	private int ClientProjectId;
	private int HifiYield;
	private int HifiReadLength;
	private int TotalBase;
	private int LongestSubreads;
	private int MinPredictedAccuracy;
	
	@JsonProperty("ClientProjectId")
	public int getClientProjectId() {
		return ClientProjectId;
	}
	public void setClientProjectId(int clientProjectId) {
		ClientProjectId = clientProjectId;
	}
	@JsonProperty("HifiYield")
	public int getHifiYield() {
		return HifiYield;
	}
	public void setHifiYield(int hifiYield) {
		HifiYield = hifiYield;
	}
	@JsonProperty("HifiReadLength")
	public int getHifiReadLength() {
		return HifiReadLength;
	}
	public void setHifiReadLength(int hifiReadLength) {
		HifiReadLength = hifiReadLength;
	}
	@JsonProperty("TotalBase")
	public int getTotalBase() {
		return TotalBase;
	}
	public void setTotalBase(int totalBase) {
		TotalBase = totalBase;
	}
	@JsonProperty("LongestSubreads")
	public int getLongestSubreads() {
		return LongestSubreads;
	}
	public void setLongestSubreads(int longestSubreads) {
		LongestSubreads = longestSubreads;
	}
	@JsonProperty("MinPredictedAccuracy")
	public int getMinPredictedAccuracy() {
		return MinPredictedAccuracy;
	}
	public void setMinPredictedAccuracy(int minPredictedAccuracy) {
		MinPredictedAccuracy = minPredictedAccuracy;
	}
	
}
