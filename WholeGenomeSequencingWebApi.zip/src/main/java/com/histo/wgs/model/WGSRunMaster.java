package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.nio.file.Paths;
import java.util.List;

@JsonPropertyOrder({"WGSRunID","ClientProjectId","RunName","IsOnBoard","DataRequirementID","NeedHifi","CCSQualityFilter","Filename",
	"BarcodeType","BarcodeQualityFilter","NumberofPasses","IsDemultiplexingRequired","WGSRunDetails","WGSStatusViewer"})
public class WGSRunMaster {
	private int WGSRunID;
	private int ClientProjectId;
	private String RunName;
	private int IsOnBoard;
	private int DataRequirementID;
	private int NeedHifi;
	private String CCSQualityFilter;
	private int NumberofPasses;
	private int IsDemultiplexingRequired;
	private String Filename;
	private String BarcodeType;
	private String BarcodeQualityFilter;
    public List<WGSRunDetail> wGSRunDetails;
    public List<WGSStatusViewer> wGSStatusViewer;
	private String InstrumentName;

	public String getInstrumentName() {
		return InstrumentName;
	}

	public void setInstrumentName(String instrumentName) {
		InstrumentName = instrumentName;
	}
	
	@JsonProperty("WGSRunID")
	public int getWGSRunID() {
		return WGSRunID;
	}
	public void setWGSRunID(int wGSRunID) {
		WGSRunID = wGSRunID;
	}
	@JsonProperty("ClientProjectId")
	public int getClientProjectId() {
		return ClientProjectId;
	}
	public void setClientProjectId(int clientProjectId) {
		ClientProjectId = clientProjectId;
	}
	@JsonProperty("RunName")
	public String getRunName() {
		return RunName;
	}
	public void setRunName(String runName) {
		RunName = runName;
	}
	@JsonProperty("IsOnBoard")
	public int getIsOnBoard() {
		return IsOnBoard;
	}
	public void setIsOnBoard(int isOnBoard) {
		IsOnBoard = isOnBoard;
	}
	@JsonProperty("DataRequirementID")
	public int getDataRequirementID() {
		return DataRequirementID;
	}
	public void setDataRequirementID(int dataRequirementID) {
		DataRequirementID = dataRequirementID;
	}
	@JsonProperty("NeedHifi")
	public int getNeedHifi() {
		return NeedHifi;
	}
	public void setNeedHifi(int needHifi) {
		NeedHifi = needHifi;
	}
	@JsonProperty("CCSQualityFilter")
	public String getCCSQualityFilter() {
		return CCSQualityFilter;
	}
	public void setCCSQualityFilter(String cCSQualityFilter) {
		CCSQualityFilter = cCSQualityFilter;
	}
	@JsonProperty("NumberofPasses")
	public int getNumberofPasses() {
		return NumberofPasses;
	}
	public void setNumberofPasses(int numberofPasses) {
		NumberofPasses = numberofPasses;
	}
	@JsonProperty("IsDemultiplexingRequired")
	public int getIsDemultiplexingRequired() {
		return IsDemultiplexingRequired;
	}
	public void setIsDemultiplexingRequired(int isDemultiplexingRequired) {
		IsDemultiplexingRequired = isDemultiplexingRequired;
	}
	@JsonProperty("Filename")
	public String getFilename() {
		if(this.Filename != null && !this.Filename.isEmpty())
			return Paths.get(this.Filename).getFileName().toString(); //return file name instead of path
		return Filename;
	}
	public void setFilename(String filename) {
		Filename = filename;
	}
	@JsonProperty("BarcodeType")
	public String getBarcodeType() {
		return BarcodeType;
	}
	public void setBarcodeType(String barcodeType) {
		BarcodeType = barcodeType;
	}
	@JsonProperty("BarcodeQualityFilter")
	public String getBarcodeQualityFilter() {
		return BarcodeQualityFilter;
	}
	public void setBarcodeQualityFilter(String barcodeQualityFilter) {
		BarcodeQualityFilter = barcodeQualityFilter;
	}
	@JsonProperty("WGSRunDetails") 
	public List<WGSRunDetail> getwGSRunDetails() {
		return wGSRunDetails;
	}
	public void setwGSRunDetails(List<WGSRunDetail> wGSRunDetails) {
		this.wGSRunDetails = wGSRunDetails;
	}
	@JsonProperty("WGSStatusViewer") 
	public List<WGSStatusViewer> getwGSStatusViewer() {
		return wGSStatusViewer;
	}
	public void setwGSStatusViewer(List<WGSStatusViewer> wGSStatusViewer) {
		this.wGSStatusViewer = wGSStatusViewer;
	}
	
}
