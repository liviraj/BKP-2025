package com.histo.wgs.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@ToString
@AllArgsConstructor
public class WGSEmailDetailsDTO {
    private String to[];
    private String cc[];
    private String bcc[];
    private String msgBody;
    private String subject;
    private String attachmentsSourcePath;
    private String fileNames[];
}
