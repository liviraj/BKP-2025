package com.histo.wgs.model;

public class WgsRunPinNoInfo
{
	private int userID;
	private String firstName;
	private String lastName;
	private String loginName;
	private String emailAddress;

	public WgsRunPinNoInfo() {
		super();

	}

	public WgsRunPinNoInfo(int userID, String firstName, String lastName, String loginName, String emailAddress) {
		super();
		this.userID = userID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.loginName = loginName;
		this.emailAddress = emailAddress;
	}

	
	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	@Override
	public String toString() 
	{
		return "WgsRunPinnoinfo [userID=" + userID + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", loginName=" + loginName + ", emailAddress=" + emailAddress + "]";
	}

	

}
