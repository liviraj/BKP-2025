package com.histo.wgs.model;

public class WGSStaticsPDFPathData {
	private String destinationPath;
	private String wgsStaticsPDFPath;
	
	public String getDestinationPath() {
		return destinationPath;
	}
	public void setDestinationPath(String destinationPath) {
		this.destinationPath = destinationPath;
	}
	public String getWgsStaticsPDFPath() {
		return wgsStaticsPDFPath;
	}
	public void setWgsStaticsPDFPath(String wgsStaticsPDFPath) {
		this.wgsStaticsPDFPath = wgsStaticsPDFPath;
	}
	
}
