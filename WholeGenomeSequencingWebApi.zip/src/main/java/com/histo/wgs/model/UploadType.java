package com.histo.wgs.model;

public enum UploadType {
	GLOBUS,
	SFTP,
	FTP
}
