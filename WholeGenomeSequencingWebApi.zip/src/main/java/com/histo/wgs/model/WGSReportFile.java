package com.histo.wgs.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class WGSReportFile {
    private String filename;
    private byte[] data;
}
