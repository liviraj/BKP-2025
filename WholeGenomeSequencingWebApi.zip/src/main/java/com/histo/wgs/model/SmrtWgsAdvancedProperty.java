package com.histo.wgs.model;

import com.histo.wgs.entity.WGSDataTypeMaster;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class SmrtWgsAdvancedProperty {
    private String dataSetName;
    private String filePath;
    private List<AdvancedProperty> advancedProperties;
    private WGSWorkFlowTypeDto workFlowType;
    private WGSDataTypeMaster wgsDataTypeMaster;
    private WGSAnalysisApplicationMasterDto wgsAnalysisApplicationMaster;
    private List<WgsAssociatedInputsMasterDTO> associatedInputsMasters;
    private List<WgsBarcodeSampleSetDTO> barcodeSampleSetList;
}
