package com.histo.wgs.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class WGSAnalysisApplicationMasterDto implements Serializable {
    private Integer id;
    @Size(max = 100)
    @NotNull
    private String analysisApplicationDisplayName;
    @Size(max = 100)
    @NotNull
    private  String analysisApplicationValue;
}