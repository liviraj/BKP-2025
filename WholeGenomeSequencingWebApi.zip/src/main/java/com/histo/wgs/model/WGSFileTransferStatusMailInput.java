package com.histo.wgs.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class WGSFileTransferStatusMailInput {
	private int wgsStatusViewerId;
	private String statusContent;
}
