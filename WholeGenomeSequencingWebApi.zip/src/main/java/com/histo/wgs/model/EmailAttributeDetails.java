package com.histo.wgs.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class EmailAttributeDetails {
    @JsonProperty("SMTPUserName")
    private String SMTPUserName;

    @JsonProperty("SMTPPassword")
    private String SMTPPassword;

    @JsonProperty("SMTPMailHost")
    private String SMTPMailHost;

    @JsonProperty("SMTPPort")
    private Integer SMTPPort;
}
