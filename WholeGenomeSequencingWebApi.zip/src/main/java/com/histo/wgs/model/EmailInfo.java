package com.histo.wgs.model;

import com.histo.wgs.entity.WGSEmailConfig;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.Arrays;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class EmailInfo {
    private String mailTitle;
    private String from;
    private String to[];
    private String cc[];
    private String bcc[];
    private String subject;
    private List<WGSAttachment> attachments;
    private String message;
    private List<WGSEmailConfig> wgsEmailConfigs;
}
