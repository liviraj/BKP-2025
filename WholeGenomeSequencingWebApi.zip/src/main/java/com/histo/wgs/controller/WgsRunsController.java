package com.histo.wgs.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.histo.wgs.model.*;
import com.histo.wgs.security.AuthorizationValidation;
import com.histo.wgs.service.WGSRunDao;
import com.histo.wgs.service.WgsRunsService;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import jakarta.validation.Valid;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@RestController
@RequestMapping("/wgsRuns")
public class WgsRunsController {

    private static final Logger logger = LogManager.getLogger(WgsRunsController.class);
    private final WgsRunsService wgsRunsService;
    private WGSRunDao wgsImp;
    private final AuthorizationValidation authorizationValidation;

    public WgsRunsController(WgsRunsService wgsRunsService, WGSRunDao wgsImp, AuthorizationValidation authorizationValidation) {

        this.wgsRunsService = wgsRunsService;
        this.wgsImp = wgsImp;
        this.authorizationValidation = authorizationValidation;
    }

    @GetMapping("")
    public ResponseEntity<Object> findAllWgsRuns(@RequestParam Map<Object, Object> wgsRunFilterParams,
                                                 @RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return wgsRunsService
                    .findAllWgsRuns(new ObjectMapper().convertValue(wgsRunFilterParams, WgsRunFilterDto.class));
        } else {
            return responseEntity;
        }
    }

    @PostMapping("")
    public ResponseEntity<Object> createWgsRun(@Valid @RequestBody List<WGSRunCreateDto> wgsRunCreateDtos,
                                               @RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return wgsRunsService.createWgsRuns(wgsRunCreateDtos);
        } else {
            return responseEntity;
        }
    }

    @PutMapping("")
    public ResponseEntity<Object> updateWgsRun(@Valid @RequestBody List<WGSRunUpdateDto> wgsRunUpdateDtos,
                                               @RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return wgsRunsService.updateWgsRuns(wgsRunUpdateDtos);
        } else {
            return responseEntity;
        }
    }

    @PostMapping("/validation")
    public ResponseEntity<Object> runValidate(@Valid @RequestBody WGSRunCreateDto wgsRunCreateDto, @RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return wgsRunsService.runValidate(wgsRunCreateDto);
        } else {
            return responseEntity;
        }
    }

    @GetMapping("/clients")
    public ResponseEntity<Object> findAllClients(@RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return wgsRunsService.wgsRunFindAllClients();
        } else {
            return responseEntity;
        }
    }

    @GetMapping("/clientProjects")
    public ResponseEntity<Object> findAllClientProjects(@RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return wgsRunsService.wgsRunFindAllClientProjects();
        } else {
            return responseEntity;
        }
    }

    @GetMapping("/clientProjects/runCreated")
    public ResponseEntity<Object> findAllClientProjectsOnlyRunCreated(@RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return wgsRunsService.wgsRunFindAllClientProjectsOnlyRunCreated();
        } else {
            return responseEntity;
        }
    }

    @GetMapping("/{wGSRunId}/runComments/{wGSStatusViewerID}")
    public ResponseEntity<Object> findAllRunComments(@PathVariable("wGSRunId") int wGSRunId,
                                                     @PathVariable("wGSStatusViewerID") int wGSStatusViewerID, @RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return wgsRunsService.findAllRunComments(wGSRunId, wGSStatusViewerID);
        } else {
            return responseEntity;
        }

    }

    @PostMapping("/{wGSRunId}/runComments")
    public ResponseEntity<Object> saveRunComments(@Valid @RequestBody WgsRunCommands wgsRunCommands,
                                                  @PathVariable int wGSRunId, @RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            wgsRunCommands.setwGSRunId(wGSRunId);
            return wgsRunsService.saveRunComments(wgsRunCommands);
        } else {
            return responseEntity;
        }
    }

    @DeleteMapping("/runComments/{commentsId}")
    public ResponseEntity<Object> deleteRunCommandsById(@PathVariable int commentsId,
                                                        @RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return wgsRunsService.deleteRunCommandsById(commentsId);
        } else {
            return responseEntity;
        }
    }

    @GetMapping("/{wgsRunId}/runLogs/{wGSStatusViewerID}")
    public ResponseEntity<Object> findAllRunLogs(@PathVariable("wgsRunId") int wgsRunId,
                                                 @PathVariable("wGSStatusViewerID") int wGSStatusViewerID, @RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return wgsRunsService.findAllRunLogs(wGSStatusViewerID, wgsRunId);
        } else {
            return responseEntity;
        }
    }

    @PostMapping("/validateIPin")
    public ResponseEntity<Object> validateWgsRunPinNo(@Valid @RequestBody WgsRunPinNo wgsRunPinNo,
                                                      @RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return wgsRunsService.validateWgsRunPinNo(wgsRunPinNo);
        } else {
            return responseEntity;
        }
    }

    @GetMapping("/reportByClient")
    public ResponseEntity<Object> findAllreportAttributesByClientProjectIDNGeneGroupID(
            @RequestParam int clientProjectID, @RequestParam int subClientID, @RequestParam int geneGroupID,
            @RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return wgsRunsService.findAllreportAttributesByClientProjectIDNGeneGroupID(clientProjectID, subClientID,
                    geneGroupID);
        } else {
            return responseEntity;
        }

    }

    @PostMapping("demultiplexingFile/vaildation")
    public ResponseEntity<Object> demultiplexingFileVaildation(@RequestHeader("Authorization") String token, @RequestBody DemultiplexingFile file) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return wgsRunsService.demultiplexingFileValidation(file);
        }
        return responseEntity;
    }

    @PostMapping("/reportToClient/emailInfo")
    public ResponseEntity<Object> reportToClientEmailInfo(@RequestBody WGSClientReportMasterDTO wgsClientReportMaster, @RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return wgsRunsService.reportToClientEmailInfo(wgsClientReportMaster);
        }
        return responseEntity;
    }

    @PostMapping("/reportToClient/sendEmail")
    public ResponseEntity<Object> reportToClientSendEmail(@RequestBody WGSEmailDetailsDTO emailDetails, @RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return wgsRunsService.reportToClientSendEmail(emailDetails);
        }
        return responseEntity;
    }

    @GetMapping("/reportToClient/downloadFile")
    public ResponseEntity<Object> downloadFileBypath(@RequestParam("path") String path, @RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return wgsRunsService.downloadFileByPath(path);
        }
        return responseEntity;
    }

    @PostMapping("/reportToClient/uploadFile")
    public ResponseEntity<Object> reportToClientUploadFile(@RequestParam("file") MultipartFile file, @RequestHeader("Authorization") String token, @RequestParam("uploadPath") String uploadPath) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return wgsRunsService.reportToClientUploadFile(file, uploadPath);
        }
        return responseEntity;
    }

    @PostMapping("/validateSamples")
    public ResponseEntity<Object> validateWgsSamples(@RequestHeader("Authorization") String token, @RequestBody ValidateSamplesDetailDTO validateSamplesDetail) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return wgsRunsService.validateWgsSamples(validateSamplesDetail);
        }
        return responseEntity;
    }

    @ApiResponses(value = {@ApiResponse(code = 200, message = "Success", response = String.class)})
    @PostMapping(path = {"/wgsRestartRunWeb"}, consumes = "application/json", produces = "text/plain")
    public ResponseEntity<Object> wgsRestartRunFailedData(
            @RequestBody List<WGSRestartLocalCopyProcessInput> inputFromHisto, @RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            logger.info("called API /wgsRestartRunFailedData");
            ExecutorService executor = Executors.newSingleThreadExecutor();
            executor.submit(() -> {
                try {
                    for (WGSRestartLocalCopyProcessInput input : inputFromHisto) {
                        input.setProgramName(wgsImp.getRestartProgramNameByProgramId(input.getProgramNameId()));
                        if (input.getProgramName().contains("FileUploader")) {
                            logger.info("Restart run FileUploader started");
                            Map<String, String> attributesData = wgsImp
                                    .getAttributesValues(input.getWgsStatusViewerID());
                            wgsImp.callFileMover(input.getWgsStatusViewerID(), attributesData);
                        } else if (input.getProgramName().contains("PacBioFileData")) {
                            logger.info("Restart run PacBioFileDataOrganizer started");
                            WGSRestartLocalCopyProcessInput data = wgsImp
                                    .getFailedRunInputForLocalCopy(input.getWgsStatusViewerID());
                            wgsImp.localCopyProcess(data.getSourcePath(), data.getDestinationPath(), data.getWgsRunId(),
                                    data.getWgsStatusViewerID(), data.getDestinationPath().contains("ccs_data"));
                        } else {
                            logger.error("Error : No valid program to call restart(" + input.getProgramName() + ")");
                        }
                    }
                } catch (Exception e) {
                    logger.error("Error : {}", e);
                    return new ResponseEntity<>("CONFLICT", HttpStatus.CONFLICT);
                }
                logger.info("/wgsRestartRunFailedData completed");
                return new ResponseEntity<>("Restart in progress", HttpStatus.OK);
            });
            return new ResponseEntity<>("Restart in progress", HttpStatus.OK);
        } else {
            return responseEntity;
        }
    }

    @ApiResponses(value = {@ApiResponse(code = 200, message = "Success", response = String.class)})
    @PostMapping(path = {"/SMRTforceRestartWeb"}, consumes = "application/json", produces = "text/plain")
    public ResponseEntity<Object> wgsSMRTforceRestart(
            @RequestBody List<WGSRunStatusUpdateFromSMRT> wGSRunStatusUpdateFromSMRT, @RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            logger.info("called API /wgsSMRTforceRestart");
            for (WGSRunStatusUpdateFromSMRT objData : wGSRunStatusUpdateFromSMRT) {
                wgsImp.wgsRunForceRestartSMRT(objData);
            }
            logger.info("/wgsSMRTforceRestart completed");
            return new ResponseEntity<>("Updated Successfully", HttpStatus.OK);
        } else {
            return responseEntity;
        }
    }

    @ApiResponses(value = {@ApiResponse(code = 200, message = "Success", response = String.class)})
    @PostMapping(path = {"/wGSCloudRunDetails"}, consumes = "application/json", produces = "text/plain")
    public ResponseEntity<Object> wGSCloudRunDetails(@RequestBody CloudRunDetail runDetail) {
        logger.info("called API /wGSCloudRunDetails");
        String response = wgsImp.updateWGSCloudRunDetails(runDetail);
        logger.info("/wGSCloudRunDetails completed");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping("/smrtPathUpdate/{wgsStatusViewerId}")
    public ResponseEntity<Object> smrtPathUpdate(@PathVariable Integer wgsStatusViewerId, @RequestBody String path) {
        return  wgsRunsService.updateSMRTRunPath(path, wgsStatusViewerId);
    }

    @GetMapping("/pooledSamplesBySampleId/{sampleId}")
    public ResponseEntity<Object> getPooledSamplesBySampleId(@RequestHeader("Authorization") String token, @PathVariable String sampleId) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return  wgsRunsService.getPooledSamplesBySampleId(sampleId);
        }
        return responseEntity;
    }
}
