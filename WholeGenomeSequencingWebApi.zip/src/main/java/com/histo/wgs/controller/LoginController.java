package com.histo.wgs.controller;

import com.histo.wgs.model.LoginModel;
import com.histo.wgs.security.AuthorizationValidation;
import com.histo.wgs.service.LoginService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/sso")
public class LoginController {

    private LoginService loginService;
    private final AuthorizationValidation authorizationValidation;

    public LoginController(LoginService loginService, AuthorizationValidation authorizationValidation) {
        this.loginService = loginService;
        this.authorizationValidation = authorizationValidation;
    }

    @PostMapping("/azure")
    public ResponseEntity<Object> azureSsoLogin(@RequestBody LoginModel loginModel, @RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return loginService.azureSsoLogin(loginModel);
        }
        return responseEntity;
    }
}
