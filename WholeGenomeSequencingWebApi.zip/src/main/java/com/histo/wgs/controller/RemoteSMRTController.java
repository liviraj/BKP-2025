package com.histo.wgs.controller;

import com.histo.wgs.security.AuthorizationValidation;
import com.histo.wgs.service.RemoteSMRTService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RemoteSMRTController {

    private RemoteSMRTService remoteSmrtService;
    private final AuthorizationValidation authorizationValidation;

    public RemoteSMRTController(RemoteSMRTService remoteSmrtService, AuthorizationValidation authorizationValidation) {
        this.remoteSmrtService = remoteSmrtService;
        this.authorizationValidation = authorizationValidation;
    }
    @GetMapping("/referenceGenomeSet")
    public ResponseEntity<Object> findAllReferenceGenomeSet(@RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return remoteSmrtService.findAllReferenceGenomeSet();
        }
        return responseEntity;
    }

    @GetMapping("/referenceGenomeSet/defaultValue/{analysisApplicationId}")
    public ResponseEntity<Object> findReferenceGenomeDefaultValueByUuid(@RequestHeader("Authorization") String token, @PathVariable Integer analysisApplicationId) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return remoteSmrtService.findReferenceGenomeDefaultValueByAnalysisApplicationId(analysisApplicationId);
        }
        return responseEntity;
    }
    @GetMapping("/barCodeSet")
    public ResponseEntity<Object> findAllBarCodeSet(@RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return remoteSmrtService.findAllBarCodeSet();
        }
        return responseEntity;
    }

    @GetMapping("/barCodeSet/{uuid}/recordNames")
    public ResponseEntity<Object> getBarCodeRecordNamesByUuid(@RequestHeader("Authorization") String token, @PathVariable String uuid) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return remoteSmrtService.getBarCodeRecordNamesByUuid(uuid);
        }
        return responseEntity;
    }
}
