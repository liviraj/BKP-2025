package com.histo.wgs.controller;

import com.histo.wgs.model.DemuxCCSStatusUpdateModel;
import com.histo.wgs.security.AuthorizationValidation;
import com.histo.wgs.service.AdvancedPropertyService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class AdvancedPropertyController {
    private AdvancedPropertyService advancedPropertyService;
    private final AuthorizationValidation authorizationValidation;

    public AdvancedPropertyController(AdvancedPropertyService advancedPropertyService, AuthorizationValidation authorizationValidation) {
        this.advancedPropertyService = advancedPropertyService;
        this.authorizationValidation = authorizationValidation;
    }

    @GetMapping("/dataTypes/{workFlowTypeID}")
    public ResponseEntity<Object> findDataTypeByWorkFlowTypeID(@PathVariable Integer workFlowTypeID, @RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return advancedPropertyService.findDataTypeByWorkFlowTypeID(workFlowTypeID);
        }
        return responseEntity;
    }

    @GetMapping("/analysisApplications/{dataTypeID}/{workFlowTypeID}")
    public ResponseEntity<Object> findAnalysisApplicationByDataTypeIDAndWorkFlowTypeID(@RequestHeader("Authorization") String token, @PathVariable("dataTypeID") Integer dataTypeID, @PathVariable("workFlowTypeID") Integer workFlowTypeID) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return advancedPropertyService.findAnalysisApplicationByDataTypeIDAndWorkFlowTypeID(dataTypeID, workFlowTypeID);
        }
        return responseEntity;
    }

    @GetMapping("/defaultAdvancedParams/{analysisApplicationID}")
    public ResponseEntity<Object> findByAnalysisApplicationID(@RequestHeader("Authorization") String token, @PathVariable int analysisApplicationID) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return advancedPropertyService.findDefaultPropertiesByAnalysisApplicationID(analysisApplicationID);
        }
        return responseEntity;

    }

    @GetMapping("/workFlowTypes")
    public ResponseEntity<Object> findAllWorkFlowTypes(@RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return advancedPropertyService.findAllWorkFlowTypes();
        }
        return responseEntity;

    }

    @GetMapping("/advancedProperty/{WGSRunID}")
    public ResponseEntity<Object> findAdvancedPropertiesByWgsRunId(@RequestHeader("Authorization") String token, @PathVariable("WGSRunID") Integer wgsRunId) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return advancedPropertyService.findAdvancedPropertiesByWgsRunId(wgsRunId);
        }
        return responseEntity;
    }

    @GetMapping("/advancedProperty/dropdowns/{analysisApplicationID}")
    public ResponseEntity<Object> findDropDownsByAnalysisApplicationID(@RequestHeader("Authorization") String token, @PathVariable Integer analysisApplicationID) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return advancedPropertyService.findDropDownsByAnalysisApplicationID(analysisApplicationID);
        }
        return responseEntity;
    }

    @GetMapping("/associatedInputs/{analysisApplicationID}")
    public ResponseEntity<Object> findAssociatedInputByAnalysisApplicationID(@RequestHeader("Authorization") String token, @PathVariable Integer analysisApplicationID) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return advancedPropertyService.findAssociatedInputByAnalysisApplicationID(analysisApplicationID);
        }
        return responseEntity;
    }

    @GetMapping("/advancedProperty/findByWgsStatusViewerId/{wgsStatusViewerId}")
    public ResponseEntity<Object> findAdvancedPropertiesByWgsStatusViewerId(@PathVariable("wgsStatusViewerId") Integer wgsStatusViewerId) {
        return advancedPropertyService.findAdvancedPropertiesByWgsStatusViewerId(wgsStatusViewerId);
    }

    @GetMapping("/advancedProperty/ccsApplication/{wgsStatusViewerId}")
    public ResponseEntity<Object> findAdvancedPropertiesForDemuxCCSRun(@PathVariable("wgsStatusViewerId") Integer wgsStatusViewerId) {
        return advancedPropertyService.findAdvancedPropertiesForDemuxCCSRun(wgsStatusViewerId);
    }

    @GetMapping("/wgs/demuxCCSStatus/{wgsStatusViewerId}")
    public ResponseEntity<Object> getDemuxCCSStatusByWgsStatusViewerId(@PathVariable("wgsStatusViewerId") Integer wgsStatusViewerId) {
        return advancedPropertyService.getDemuxCCSStatusByWgsStatusViewerId(wgsStatusViewerId);
    }

    @PutMapping("/wgs/demuxCCSStatus/{wgsStatusViewerId}")
    public ResponseEntity<Object> updateDemuxCCSStatusByWgsStatusViewerId(@PathVariable Integer wgsStatusViewerId, @RequestBody DemuxCCSStatusUpdateModel ccsStatusUpdate) {
        return advancedPropertyService.updateDemuxCCSStatusByWgsStatusViewerId(wgsStatusViewerId, ccsStatusUpdate);
    }
}
