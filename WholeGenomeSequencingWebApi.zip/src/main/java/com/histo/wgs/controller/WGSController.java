package com.histo.wgs.controller;


import com.histo.wgs.exception.ExceptionBean;
import com.histo.wgs.model.WGSResModel;
import com.histo.wgs.model.*;
import com.histo.wgs.service.FileDataOrganizerService;
import com.histo.wgs.service.WGSRunDao;
import com.histo.wgs.util.FilterUtil;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static com.histo.wgs.model.WgsStatusMasterEnum.COMPLETED;
import static com.histo.wgs.model.WgsStatusMasterEnum.IN_PROGRESS;

@RestController
@RequestMapping("/wgs")
public class WGSController {
    private static final Logger logger = LogManager.getLogger(WGSController.class);

    private final FileDataOrganizerService fileDataOrganizerService;
    private final WGSRunDao wgsRunDao;
    private WGSResModel response;
    private MappingJacksonValue mappingJacksonValue;

    public WGSController(FileDataOrganizerService fileDataOrganizerService, WGSRunDao wgsRunDao) {
        this.fileDataOrganizerService = fileDataOrganizerService;
        this.wgsRunDao = wgsRunDao;
        this.response = new WGSResModel();
    }

    @ApiResponses(value = {@ApiResponse(code = 200, message = "Success", response = WGSRoot.class)})
    @GetMapping(path = {"/WGSRunData/{programType}"}, produces = "application/json")
    public ResponseEntity<WGSRoot> getWGSRunDataGeneric(@PathVariable String programType) {
        logger.info("called API /getWGSRunData");
        WGSRoot runDataList = wgsRunDao.rerunWGSRunData(programType);
        logger.info("/getWGSRunData completed");
        return new ResponseEntity<>(runDataList, HttpStatus.OK);

    }

    @ApiResponses(value = {@ApiResponse(code = 200, message = "Success", response = String.class)})
    @PostMapping(path = {"/wgsRunStatus/smrt"}, consumes = "application/json", produces = "text/plain")
    public ResponseEntity<String> wgsUpdateStatusFromSMRT(
            @RequestBody List<WGSRunStatusUpdateFromSMRT> wGSRunStatusUpdateFromSMRT) {
        logger.info("called API /wgsRunStatus");
        String updatedStatus = wgsRunDao.updateWGSRunStatusFromSMRTPortal(wGSRunStatusUpdateFromSMRT);
        logger.info("/wgsRunStatus completed");
        return new ResponseEntity<>(updatedStatus, HttpStatus.OK);

    }

    @PostMapping(path = {"/wgsRunStatus/shellscript"}, consumes = "application/json", produces = "text/plain")
    public ResponseEntity<String> wgsUpdateStatusFromShellScript(
            @RequestBody WGSRunStatusUpdateShellScript wGSRunStatusUpdateFromSMRT) {
        logger.info("called API /wgsRunStatus/shellscript");
        String updatedStatus = wgsRunDao.updateWGSRunStatusFromShellScript(wGSRunStatusUpdateFromSMRT);
        logger.info("/wgsRunStatus/shellscript completed");
        return new ResponseEntity<>(updatedStatus, HttpStatus.OK);

    }

    @ApiResponses(value = {@ApiResponse(code = 200, message = "Success", response = String.class)})
    @PostMapping(path = {
            "/wgsCloudFileTransferStatus/shellscript"}, consumes = "application/json", produces = "text/plain")
    public ResponseEntity<String> wgsCloudFileTransferStatus(
            @RequestBody WGSUpdateCloudFileTransferStatusShellScript wGSCloudRunStatusUpdateFromSMRT) {
        logger.info("called API /wgsCloudFileTransferStatus/shellscript");
        String updatedStatus = wgsRunDao.updateWGSCloudFileRunStatusFromShellScript(wGSCloudRunStatusUpdateFromSMRT);
        logger.info("/wgsCloudFileTransferStatus/shellscript completed");
        return new ResponseEntity<>(updatedStatus, HttpStatus.OK);

    }

    @ApiResponses(value = {@ApiResponse(code = 200, message = "Success", response = String.class)})
    @PostMapping(path = {"/wgsLocalTransferStatus"}, consumes = "application/json", produces = "text/plain")
    public ResponseEntity<String> getWGSGlobusToken(@RequestBody LocalTransferIdStatus statusData) {
        logger.info("called API /wgsLocalTransferStatus");

        if (statusData.getStatus() == IN_PROGRESS.getStatusId()) {
            wgsRunDao.updateLTSDetails(statusData); // update In progress status for LTS
        }

        ExecutorService checksumExecutor = Executors.newSingleThreadExecutor();
        checksumExecutor.submit(() -> {
            if (statusData.getStatus() == COMPLETED.getStatusId()) {
                wgsRunDao.executeMd5Checksum(statusData);
            }
        });
        logger.info("/wgsLocalTransferStatus completed");
        return new ResponseEntity<>("Success", HttpStatus.OK);

    }

    @GetMapping("/executeFileUploader/{wgsStatusViewerId}")
    public ResponseEntity<Object> executeFileUploader(@PathVariable("wgsStatusViewerId") Integer wgsStatusViewerId) {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        logger.info("called API /executeFileUploader/{wgsStatusViewerId}");
        executor.submit(() -> {
            Map<String, String> attributesData = wgsRunDao.getAttributesValues(wgsStatusViewerId);
            wgsRunDao.callFileMover(wgsStatusViewerId, attributesData);
        });
        logger.info("/executeFileUploader/{wgsStatusViewerId} completed");
        response.setStatus(true);
        response.setInformation(new ExceptionBean(new Date(), "Success", "Client transfer started successfully"));
        mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"status", "information"});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @PostMapping(path = {"/wgsFileTransferStatusMail"}, consumes = "application/json", produces = "text/plain")
    public ResponseEntity<String> wgsFileTransferStatusMail(@RequestBody WGSFileTransferStatusMailInput statusData) {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        logger.info("called API /wgsFileTransferStatusMail");
        executor.submit(() -> {
            wgsRunDao.wgsFileTransferStatusMail(statusData);
        });
        logger.info("/wgsFileTransferStatusMail completed");
        return new ResponseEntity<>("Success", HttpStatus.OK);

    }


    @PostMapping(path = {"/wgsClientTransferStatus"}, consumes = "application/json", produces = "text/plain")
    public ResponseEntity<String> wgsGlobusTransferStatus(@RequestBody WgsClientTransferStatus statusData) {
        logger.info("called API /wgsClientTransferStatus");
        String transferStatus = wgsRunDao.updateWGSGlobusTransferStatus(statusData);
        if (statusData.getStatus() == 3 || statusData.getStatus() == 4) {
            wgsRunDao.wgsFileTransferStatusMail(statusData.getWGSStatusViewerID(), "Client Transfer", statusData.getStatus(), statusData.getDestinationUplodPath());
        }
        logger.info("/wgsClientTransferStatus completed");
        return new ResponseEntity<>(transferStatus, HttpStatus.OK);

    }

    @ApiResponses(value = {@ApiResponse(code = 200, message = "Success", response = String.class)})
    @PostMapping(path = {"/wgsLogInfo"}, consumes = "application/json", produces = "text/plain")
    public ResponseEntity<String> inertWGSLogInfo(@RequestBody WGSErrorLogInput errorData) {
        logger.info("called API /wgsErrorLog");
        String insertedStatus = wgsRunDao.insertWGSLogInfo(errorData.getWGSRunID(),
                errorData.getWGSStatusViewerID(), errorData.getLogInfo(), errorData.getProgramName());
        logger.info("/wgsErrorLog completed");
        return new ResponseEntity<>(insertedStatus, HttpStatus.OK);

    }

    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success", response = WGSRestartLocalCopyProcessInput.class, responseContainer = "List")})
    @GetMapping(path = {"/wgsRunFailedData"}, produces = "application/json")
    public ResponseEntity<List<WGSRestartLocalCopyProcessInput>> wgsRunFailedData() {
        logger.info("called API /wgsRunFailedData");
        List<WGSRestartLocalCopyProcessInput> dataList = wgsRunDao.getListOfRestartRunForLocalCopyProcess();
        logger.info("/wgsRunFailedData completed");
        return new ResponseEntity<>(dataList, HttpStatus.OK);

    }

    @ApiResponses(value = {@ApiResponse(code = 200, message = "Success", response = String.class)})
    @PostMapping(path = {"/wgsFileSizeMismatch"}, consumes = "application/json", produces = "text/plain")
    public ResponseEntity<String> wgsFileSizeMismatch(@RequestBody WGSFileSizeFromSMRT input) {
        logger.info("called API /wgsFileSizeMismatch");
        String mailSentStatus = wgsRunDao.sendMailForFileSizeFailed(input);
        logger.info("/wgsFileSizeMismatch completed");
        return new ResponseEntity<>(mailSentStatus, HttpStatus.OK);

    }

    @ApiResponses(value = {@ApiResponse(code = 200, message = "Success", response = String.class)})
    @GetMapping(path = {"/WGSRunType/{wgsStatusViewerId}"}, produces = "text/plain")
    public ResponseEntity<String> getWGSRunType(@PathVariable int wgsStatusViewerId) {
        logger.info("called API /WGSRunType");
        Integer runType = wgsRunDao.getWGSRunTypeForWGSStatusViewerId(wgsStatusViewerId);

        logger.info("/WGSRunType completed");
        return new ResponseEntity<>(Integer.toString(runType), HttpStatus.OK);

    }

    // WGS Automation API
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success", response = WGSResModel.class, responseContainer = "List")})
    @GetMapping(path = {"/listOfCloudJobs"}, produces = "application/json")
    public ResponseEntity<Object> getListOfCloudJobs() {
        logger.info("called API /listOfCloudJobs");
        List<WGSResModel> resModels = wgsRunDao.listOfCloudJobs();
        logger.info("/listOfCloudJobs completed");
        return new ResponseEntity<>(resModels, HttpStatus.OK);
    }

    // https://stackoverflow.com/questions/60319201/apiresponse-with-empty-response-body-spring-boot
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Success", response = WGSResModel.class),})
    @GetMapping(path = {"/wGSStatusViewerDetails/{wGSRunName}"}, produces = "application/json")
    public ResponseEntity<Object> getWGSStatusViewerDetailsByRunName(@PathVariable String wGSRunName) {
        logger.info("called API /wGSStatusViewerDetails");
        WGSResModel resModel = wgsRunDao.wGSStatusViewerDetailsByRunName(wGSRunName);
        logger.info("/wGSStatusViewerDetails completed");
        return new ResponseEntity<>(resModel, HttpStatus.OK);
    }

    @ApiResponses(value = {@ApiResponse(code = 200, message = "Success", response = String.class)})
    @PostMapping(path = {"/wGSCloudRunDetails"}, consumes = "application/json", produces = "text/plain")
    public ResponseEntity<Object> wGSCloudRunDetails(@RequestBody CloudRunDetail runDetail) {
        logger.info("called API /wGSCloudRunDetails");
        String response = wgsRunDao.updateWGSCloudRunDetails(runDetail);
        logger.info("/wGSCloudRunDetails completed");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @ApiResponses(value = {@ApiResponse(code = 200, message = "Success", response = String.class)})
    @PostMapping(path = {"/wGSCloudAutomationRun"}, consumes = "application/json", produces = "text/plain")
    public ResponseEntity<Object> wgsAutomationRun(@RequestBody SMRTInputArgs inputArgs) {
        logger.info("called API /wGSCloudAutomationRun");

        ExecutorService executor = Executors.newSingleThreadExecutor();

        logger.info("called API /wGSCloudAutomationRun");
        executor.submit(() -> {

            wgsRunDao.wgsAutomationRun(inputArgs);
            logger.info("/wGSCloudAutomationRun completed");
        });

        return new ResponseEntity<>("Job SUBMITTED", HttpStatus.OK);
    }

    @ApiResponses(value = {@ApiResponse(code = 200, message = "Success", response = String.class)})
    @PostMapping(path = {"/wGSUpdateCloudFileTransferStatus"}, consumes = "application/json", produces = "text/plain")
    public ResponseEntity<Object> wgsUpdateCloudFileTransferStatus(@RequestBody CloudFileTransferStatus status) {
        logger.info("called API /wGSUpdateCloudFileTransferStatus");
        String response = wgsRunDao.wGSUpdateCloudFileTransferStatus(status);
        logger.info("/wGSUpdateCloudFileTransferStatus completed");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping("/rawDataTransferStatus")
    public ResponseEntity<Object> updateRawDataTransferStatus(@RequestBody RawDataTransferModel rawDataTransfer) {
        return fileDataOrganizerService.updateRawDataTransferStatus(rawDataTransfer);
    }

    @PostMapping("/logDetail")
    public ResponseEntity<Object> insertLogDetail(@RequestBody LogDetailModel logDetail) {
        return wgsRunDao.insertLogDetail(logDetail);
    }

    @PostMapping("/md5Checksum/details/{wgsRunId}")
    public ResponseEntity<Object> saveWGSMD5ChecksumDetails(@PathVariable("wgsRunId") Integer wgsRunId, @RequestBody Map<String, String> md5ChecksumDetails) {
        return wgsRunDao.saveMd5ChecksumDetails(md5ChecksumDetails, wgsRunId);
    }

    @PutMapping("/updateLocalTransferStatus")
    public ResponseEntity<Object> updateLocalTransferStatus(@RequestBody LocalTransferIdStatus localTransferData) {
        Map<String, String> attributesData = wgsRunDao.getAttributesValues(localTransferData.getWgsStatusViewerId());
        if (localTransferData.getStatus() == 3) {
            wgsRunDao.deleteWgsRSData(localTransferData);
        }
        if (localTransferData.getStatus() == 3 || localTransferData.getStatus() == 4) {
            wgsRunDao.wgsFileTransferStatusMail(localTransferData.getWgsStatusViewerId(), "Local Transfer", localTransferData.getStatus(), localTransferData.getSourcePath());
        }
        if ((!attributesData.containsKey("WGSClientUserName") && !attributesData.containsKey("WGSClientPassword")) && localTransferData.getStatus() == 3) {
            //send mail for Not Applicable status
            wgsRunDao.wgsFileTransferStatusMail(localTransferData.getWgsStatusViewerId(), "ClientTransferNA", 0, "");
        }

        boolean updateLocalTransferStatus = wgsRunDao.updateLocalTransferStatus(localTransferData);
        if (!updateLocalTransferStatus) {
            return new ResponseEntity<>("Local Transfer Status Update Failed.", HttpStatus.CONFLICT);
        }
        return new ResponseEntity<>("Local Transfer Status Updated Successfully.", HttpStatus.OK);
    }
}
