package com.histo.wgs.controller;

import com.histo.wgs.model.ActivityLogReq;
import com.histo.wgs.service.ActivityLogService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ActivityLogController {

    private final ActivityLogService activityLogService;

    public ActivityLogController(ActivityLogService activityLogService) {
        this.activityLogService = activityLogService;
    }

    @PostMapping("/activityLog")
    public ResponseEntity<String> insertEsignActivityLog(@RequestBody ActivityLogReq logReq) {
        return activityLogService.insertESignActivityLog(logReq);
    }
}
