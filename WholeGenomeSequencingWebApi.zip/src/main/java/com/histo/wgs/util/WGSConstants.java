package com.histo.wgs.util;

public class WGSConstants {
    public static final String GENE_GROUP_NAME = "Whole Genome Sequencing";
    public static final String REPORT_TO_CLIENT_MAIL_TITLE = "Data ready for PacBio Sequencing - WGS-XLS";
    public static final String REPORT_TO_CLIENT_MAIL_SUBJECT = "Data ready for PacBio Sequencing";
    public static final String REPORT_TO_CLIENT_MAIL_BODY = "\n" +
            "Dear Sir/Madam,\n" +
            "\n" +
            "Please find the attached Report.\n" +
            "\n" +
            "Thanks,\n" +
            "Histogenetics\n" +
            "\n" +
            "\n" +
            "*****Please do not reply to this mail. This is an automated mail.****\n";
    public static final String REPORT_TO_CLIENT_BASE_FILE_NAME = "Histogenetics metadata File_";
    public static final Integer REPORT_TO_CLIENT_MAIL_COUNT = 1;

    public static final String REPORT_TO_CLIENT_WGS_REPORTS = "WGSReports";

    public static final String GENERAL = "General";

    //UAT
//    public static final String SMTP_USER_NAME = "SMTPUserName";
//    public static final String SMTP_PASSWORD = "SMTPPassword";
    // PROD
    public static final String SMTP_USER_NAME = "SMTPReportUserName";
    public static final String SMTP_PASSWORD = "SMTPReportPassword";

    public static final String PREPARE_WGS_ACTION_TYPE = "frmPrepareWGSRun";

    public static final String OUTPUT_DATA_SET_PROPERTY_VALUE = "new_dataset_name";
    public static final String DEMULTIPLEX_BARCODES_APP_VALUE = "cromwell.workflows.pb_demux_ccs";
    public static final String OUTPUT_DATA_SET_APPEND_VALUE = " (demuxed)";
    public static final String CCS_APP_VALUE = "cromwell.workflows.pb_ccs";
    public static final String DEMUX_APP_VALUE = "cromwell.workflows.pb_demux_ccs";
    public static final String EMAIL_CLAIM_NAME = "unique_name";
}
