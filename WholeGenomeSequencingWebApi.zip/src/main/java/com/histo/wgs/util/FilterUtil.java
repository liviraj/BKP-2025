package com.histo.wgs.util;

import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import com.histo.wgs.model.WGSAdvancedPropertyResModel;
import com.histo.wgs.model.WGSResModel;
import com.histo.wgs.model.FileDataOrganizerResponseModel;
import org.springframework.http.converter.json.MappingJacksonValue;

/**
 * @author ArockiajayarajM
 *
 */
public class FilterUtil {
	private FilterUtil() {
	}

	public static MappingJacksonValue responseFilter(WGSResModel response, String[] fields) {
		SimpleBeanPropertyFilter propertyFilter = SimpleBeanPropertyFilter.filterOutAllExcept(fields);
		FilterProvider filterProvider = new SimpleFilterProvider().addFilter("WGSViewResModel", propertyFilter);
		MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(response);
		mappingJacksonValue.setFilters(filterProvider);
		return mappingJacksonValue;
	}

	public static MappingJacksonValue advancePropResFilter(WGSAdvancedPropertyResModel response, String[] fields) {
		SimpleBeanPropertyFilter propertyFilter = SimpleBeanPropertyFilter.filterOutAllExcept(fields);
		FilterProvider filterProvider = new SimpleFilterProvider().addFilter("WGSAdvancedPropertyResModel", propertyFilter);
		MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(response);
		mappingJacksonValue.setFilters(filterProvider);
		return mappingJacksonValue;
	}

	public static MappingJacksonValue responseFilterForFileDataOrganizer(FileDataOrganizerResponseModel response, String[] fields) {
		SimpleBeanPropertyFilter propertyFilter = SimpleBeanPropertyFilter.filterOutAllExcept(fields);
		FilterProvider filterProvider = new SimpleFilterProvider().addFilter("FileDataOrganizerResponseModel", propertyFilter);
		MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(response);
		mappingJacksonValue.setFilters(filterProvider);
		return mappingJacksonValue;
	}
}
