package com.histo.wgs.util;

import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.share.DiskShare;
import com.hierynomus.smbj.share.File;
import com.histo.wgs.config.DiskShareConfig;
import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbException;
import jcifs.smb.SmbFile;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.EnumSet;
import java.util.stream.Stream;

public class WGSUtil {

    public static Integer getCurrentYear() {
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        return currentYear;
    }

    public static String getCurrentDate() {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        return dateFormat.format(date);
    }

    public static String findDirectorySizeInGB(String pathString) {
        long size = 0;
        long gb = 1024 * 1024 * 1024;
        String fileSize = "";
        Path path = Paths.get(pathString);

        try (Stream<Path> walk = Files.walk(path)) {
            size = walk
                    .filter(Files::isRegularFile)
                    .mapToLong(p -> {
                        try {
                            return Files.size(p);
                        } catch (IOException e) {
                            return 0L;
                        }
                    })
                    .sum();

        } catch (IOException e) {
            System.out.printf("IO errors %s", e);
        }
        fileSize = new DecimalFormat("#.##").format((float) size / gb);
        return fileSize;
    }

    public static String findShareDirectorySizeInGB(String pathString, DiskShareConfig diskShareConfig) throws MalformedURLException, SmbException {
        long size = 0;
        long gb = 1024 * 1024 * 1024;
        String fileSize = "";
        // SmbFile smbFile = new SmbFile(pathString, diskShareConfig);
        size = WGSUtil.smbFolderSize(diskShareConfig.getDiskShare(), pathString);
        fileSize = new DecimalFormat("#.##").format((float) size / gb);
        return fileSize;
    }

    public static String findShareDirectorySizeInMB(String pathString, DiskShareConfig diskShareConfig) throws MalformedURLException, SmbException {
        long size = 0;
        long mb = 1024 * 1024;
        String fileSize = "";
        // SmbFile smbFile = new SmbFile(pathString, diskShareConfig);
        size = WGSUtil.smbFolderSize(diskShareConfig.getDiskShare(), pathString);
        fileSize = new DecimalFormat("#.##").format((float) size / mb);
        return fileSize;
    }

    public static long smbFolderSize(DiskShare share, String directoryPath) {
        long totalSize = 0;
        directoryPath = directoryPath.replace(share.getSmbPath().toUncPath(), "");
        directoryPath = directoryPath.replace("\\", "/");
        boolean isDirectory = share.getFileInformation(directoryPath).getStandardInformation().isDirectory();
        if (!isDirectory) {
            File file = share.openFile(directoryPath, EnumSet.of(
                            AccessMask.GENERIC_READ)
                    , null
                    , SMB2ShareAccess.ALL
                    , SMB2CreateDisposition.FILE_OPEN
                    , null);
            totalSize += file.getFileInformation().getStandardInformation().getEndOfFile();
            file.closeSilently();
            return totalSize;
        }
        for (FileIdBothDirectoryInformation fileInfo : share.list(directoryPath)) {
            String fileName = fileInfo.getFileName();
            if (fileName.equals(".") || fileName.equals("..")) {
                continue;
            }

            String filePath = directoryPath + "/" + fileName;
            if (!fileInfo.getFileName().contains(".")) {
                totalSize += smbFolderSize(share, filePath);
            } else {
                File file = share.openFile(filePath, EnumSet.of(
                                AccessMask.GENERIC_READ)
                        , null
                        , SMB2ShareAccess.ALL
                        , SMB2CreateDisposition.FILE_OPEN
                        , null);
                totalSize += file.getFileInformation().getStandardInformation().getEndOfFile();
                file.closeSilently();
            }
        }
        return totalSize;
    }

    public static boolean isDirectoryOrFileExists(String pathString) {
        boolean exists = false;
        Path path = Paths.get(pathString);
        if (Files.exists(path)) {
            exists = true;
        }
        return exists;
    }

    public static String encodeValue(String value) {
        try {
            return URLEncoder.encode(value, StandardCharsets.UTF_8.toString());
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
    }

    public static String decode(String value) {
        try {
            return URLDecoder.decode(value, StandardCharsets.UTF_8.toString());
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
    }

    public static String convertSDateEDTToNormal(String dateToFormat) {
        SimpleDateFormat inputFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy");

        Date date = null;
        try {
            date = inputFormat.parse(dateToFormat);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

        String formattedDate = outputFormat.format(date);

        return formattedDate;
    }
}
