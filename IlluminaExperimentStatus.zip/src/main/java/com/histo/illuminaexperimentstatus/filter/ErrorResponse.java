package com.histo.illuminaexperimentstatus.filter;

import com.histo.illuminaexperimentstatus.model.IlluminaExperimentStatusResModel;
import com.histo.illuminaexperimentstatus.model.InfoModel;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;

import java.util.Date;

public class ErrorResponse {
    private static final String STATUS = "status";

    public static ResponseEntity<Object> errorIlluminaExperimentStatusResponse(Exception e, IlluminaExperimentStatusResModel response, Logger logger) {
        e.printStackTrace();
        logger.error("Error :%s", e.getMessage());
        response.setStatus(false);
        response.setInformation(new InfoModel(new Date(), "Error", "Internal Server Error"));
        MappingJacksonValue mappingJacksonValue = APIFilter.responseFilterForIlluminaExperimentStatus(response,
                new String[] { STATUS, "information" });
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
