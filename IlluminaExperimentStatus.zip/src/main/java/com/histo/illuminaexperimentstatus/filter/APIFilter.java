package com.histo.illuminaexperimentstatus.filter;

import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import com.histo.illuminaexperimentstatus.model.IlluminaExperimentStatusResModel;
import org.springframework.http.converter.json.MappingJacksonValue;

public class APIFilter {
    private APIFilter() {

    }
    public static MappingJacksonValue responseFilterForIlluminaExperimentStatus(IlluminaExperimentStatusResModel response, String[] fields) {
        SimpleBeanPropertyFilter propertyFilter = SimpleBeanPropertyFilter.filterOutAllExcept(fields);
        FilterProvider filterProvider = new SimpleFilterProvider().addFilter("IlluminaExperimentStatusResModel", propertyFilter);
        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(response);
        mappingJacksonValue.setFilters(filterProvider);
        return mappingJacksonValue;
    }
}
