package com.histo.illuminaexperimentstatus.model;

import lombok.*;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Setter @Getter
@ToString
public class InfoModel {
    private Date timestamp;
    private String message;
    private String description;
}
