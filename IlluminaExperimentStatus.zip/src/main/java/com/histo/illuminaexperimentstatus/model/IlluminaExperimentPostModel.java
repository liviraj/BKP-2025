package com.histo.illuminaexperimentstatus.model;

import lombok.*;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class IlluminaExperimentPostModel {
    private String illuminaExperimentGUID;
    private String illuminaWFStatus;
    private String nGSExperimentName;
    private String description;
}
