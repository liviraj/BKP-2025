package com.histo.illuminaexperimentstatus.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.sql.Date;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class IlluminaExperimentStatusLog {
    private Long logId;
    private Long autoID;
    private String illuminaExperimentGUID;
    private int illuminaWFStepID;
    private String illuminaWFStatus;
    private String nGSExperimentName;
    private Date insertedOn;
    private String description;
}
