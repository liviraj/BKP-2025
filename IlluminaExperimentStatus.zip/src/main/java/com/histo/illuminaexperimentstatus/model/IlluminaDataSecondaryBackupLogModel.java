package com.histo.illuminaexperimentstatus.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class IlluminaDataSecondaryBackupLogModel {
    private String illuminaExperimentName;
    private String primaryExperimentLocation;
    private String secondaryExperimentLocation;
    private String backupCompletionDate;
    private Integer sampleCount;
}
