package com.histo.illuminaexperimentstatus.service.impl;

import com.histo.illuminaexperimentstatus.model.IlluminaDataSecondaryBackupLogModel;
import com.histo.illuminaexperimentstatus.model.PacbioDataSecondaryBackupLogModel;
import com.histo.illuminaexperimentstatus.service.DataCopierLogService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Service
public class DataCopierLogServiceImpl implements DataCopierLogService {
    private static final Logger LOGGER = LogManager.getLogger(DataCopierLogServiceImpl.class.getName());
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public String insertIlluminaBackupLog(IlluminaDataSecondaryBackupLogModel backupLog) {
        try {
            int insertCount = jdbcTemplate.update("insert into IlluminaDataSecondaryBackupInformation(IlluminaExperimentName,PrimaryExperimentLocation,SecondaryExperimentLocation,BackupCompletionDate" +
                            ", SecondaryBackupSamplesCount) values(?,?,?,?,?);",
                    backupLog.getIlluminaExperimentName()
                    , backupLog.getPrimaryExperimentLocation()
                    , backupLog.getSecondaryExperimentLocation()
                    , convertStringToTimeStamp(backupLog.getBackupCompletionDate())
                    , backupLog.getSampleCount()
            );
            if (insertCount > 0) {
                return "Successfully inserted.";
            } else {
                LOGGER.error("Insertion Count: {}, request body: {}", insertCount, backupLog);
                return "Insertion failed.";
            }

        } catch (Exception e) {
            LOGGER.error("insertIlluminaBackupLog() Error: {}" + e);
            return "Insertion failed";
        }
    }

    @Override
    public String insertPacbioBackupLog(PacbioDataSecondaryBackupLogModel backupLog) {
        try {
            jdbcTemplate.update("insert into PacbioDataSecondaryBackupInformation(JobID,PrimaryExperimentLocation,SecondaryExperimentLocation,BackupCompletionDate) values(?,?,?,?);"
                    , backupLog.getJobId()
                    , backupLog.getPrimaryExperimentLocation()
                    , backupLog.getSecondaryExperimentLocation()
                    , convertStringToTimeStamp(backupLog.getBackupCompletionDate()));
            return "Successfully inserted.";
        } catch (Exception e) {
            LOGGER.error("insertPacbioBackupLog() Error: {}" + e);
            return "Insertion failed";
        }
    }

    private Timestamp convertStringToTimeStamp(String time) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
        Date parsedDate = dateFormat.parse(time);
        Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
        return timestamp;
    }
}
