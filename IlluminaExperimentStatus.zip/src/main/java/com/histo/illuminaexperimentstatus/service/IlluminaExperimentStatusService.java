package com.histo.illuminaexperimentstatus.service;

import com.histo.illuminaexperimentstatus.model.IlluminaExperimentPostModel;
import org.springframework.http.ResponseEntity;

public interface IlluminaExperimentStatusService {
    public ResponseEntity<Object> insertIlluminaExperimentStatus(IlluminaExperimentPostModel illuminaExperimentStatus);

    public ResponseEntity<Object> updateIlluminaExperimentStatus(IlluminaExperimentPostModel illuminaExperimentStatus);
}
