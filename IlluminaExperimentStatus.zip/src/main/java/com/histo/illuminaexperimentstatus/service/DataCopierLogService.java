package com.histo.illuminaexperimentstatus.service;

import com.histo.illuminaexperimentstatus.model.IlluminaDataSecondaryBackupLogModel;
import com.histo.illuminaexperimentstatus.model.PacbioDataSecondaryBackupLogModel;
import org.springframework.http.ResponseEntity;

public interface DataCopierLogService {
    public String insertIlluminaBackupLog(IlluminaDataSecondaryBackupLogModel backupLog);
    public String insertPacbioBackupLog(PacbioDataSecondaryBackupLogModel backupLog);
}
