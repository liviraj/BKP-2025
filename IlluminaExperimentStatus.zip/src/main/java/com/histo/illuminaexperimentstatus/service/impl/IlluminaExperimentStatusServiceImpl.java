package com.histo.illuminaexperimentstatus.service.impl;

import com.histo.illuminaexperimentstatus.model.IlluminaExperimentStatusLog;
import com.histo.illuminaexperimentstatus.filter.APIFilter;
import com.histo.illuminaexperimentstatus.filter.ErrorResponse;
import com.histo.illuminaexperimentstatus.model.IlluminaExperimentPostModel;
import com.histo.illuminaexperimentstatus.model.IlluminaExperimentStatusResModel;
import com.histo.illuminaexperimentstatus.model.InfoModel;
import com.histo.illuminaexperimentstatus.service.IlluminaExperimentStatusService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class IlluminaExperimentStatusServiceImpl implements IlluminaExperimentStatusService {
    private static final Logger logger = LogManager.getLogger(IlluminaExperimentStatusServiceImpl.class.getName());
    private static final String STATUS = "status";
    private IlluminaExperimentStatusResModel response;
    // Connection con = NextGenSeqSqlCon.getConnection();
    // JdbcTemplate jdbcTemplate = new JdbcTemplate(new SingleConnectionDataSource(con, false));
    @Autowired
    private JdbcTemplate jdbcTemplate;

    public IlluminaExperimentStatusServiceImpl() {
        super();
        response = new IlluminaExperimentStatusResModel();
    }

    @Override
    public ResponseEntity<Object> insertIlluminaExperimentStatus(IlluminaExperimentPostModel illuminaExperimentStatus) {
        try {
            int updateCount = 0;
            MappingJacksonValue mappingJacksonValue;
            List<IlluminaExperimentStatusLog> returnModel = jdbcTemplate.query("SELECT top 1 * FROM IlluminaExperimentStatus WHERE IlluminaExperimentGUID = ?",
                    BeanPropertyRowMapper.newInstance(IlluminaExperimentStatusLog.class),
                    illuminaExperimentStatus.getIlluminaExperimentGUID());
            Long illuminaWFStepID = jdbcTemplate.queryForObject("SELECT IlluminaWFStepID FROM  IlluminaWFSteps WHERE IlluminaWFStepName = 'BCL-2-FastQ Conversion'", Long.class);
            if (returnModel.size() > 0) {
                IlluminaExperimentStatusLog returnIlluminaExperimentStatus = returnModel.get(0);
                updateCount = jdbcTemplate.update("INSERT INTO IlluminaExperimentStatus_log(AutoID,IlluminaExperimentGUID,IlluminaWFStepID,IlluminaWFStatus,NGSExperimentName,InsertedOn,Description) " +
                                "VALUES (?,?,?,?,?,?,?)", returnIlluminaExperimentStatus.getAutoID(), returnIlluminaExperimentStatus.getIlluminaExperimentGUID(),
                        returnIlluminaExperimentStatus.getIlluminaWFStepID(), returnIlluminaExperimentStatus.getIlluminaWFStatus(),
                        returnIlluminaExperimentStatus.getNGSExperimentName(), returnIlluminaExperimentStatus.getInsertedOn(),
                        returnIlluminaExperimentStatus.getDescription());
                updateCount = jdbcTemplate.update("DELETE FROM IlluminaExperimentStatus WHERE IlluminaExperimentGUID = ?", illuminaExperimentStatus.getIlluminaExperimentGUID());

            }
            long millis = System.currentTimeMillis();
            java.util.Date date = new java.util.Date(millis);
            updateCount = jdbcTemplate.update("INSERT INTO IlluminaExperimentStatus(IlluminaExperimentGUID,IlluminaWFStepID,IlluminaWFStatus,NGSExperimentName,InsertedOn,Description)" +
                            "VALUES (?,?,?,?,?,?)", illuminaExperimentStatus.getIlluminaExperimentGUID(), illuminaWFStepID,
                    illuminaExperimentStatus.getIlluminaWFStatus(), illuminaExperimentStatus.getNGSExperimentName(),
                    date, illuminaExperimentStatus.getDescription());
            if (updateCount > 0) {
                response.setStatus(true);
                response.setData("Success");
                mappingJacksonValue = APIFilter.responseFilterForIlluminaExperimentStatus(response,
                        new String[]{STATUS, "data"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            } else {
                response.setStatus(false);
                response.setData("Failed to insert");
                response.setInformation(
                        new InfoModel(new Date(), "Data not found", "Illumina Experiment Status data not available"));
                mappingJacksonValue = APIFilter.responseFilterForIlluminaExperimentStatus(response,
                        new String[]{STATUS, "information"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
            }
        } catch (Exception ex) {
            return ErrorResponse.errorIlluminaExperimentStatusResponse(ex, response, logger);
        }
    }

    @Override
    public ResponseEntity<Object> updateIlluminaExperimentStatus(IlluminaExperimentPostModel illuminaExperimentStatus) {
        int updateCount = 0;
        MappingJacksonValue mappingJacksonValue;
        List<IlluminaExperimentStatusLog> returnModel = jdbcTemplate.query("SELECT top 1 * FROM IlluminaExperimentStatus WHERE IlluminaExperimentGUID = ?",
                BeanPropertyRowMapper.newInstance(IlluminaExperimentStatusLog.class),
                illuminaExperimentStatus.getIlluminaExperimentGUID());
        Long illuminaWFStepID = jdbcTemplate.queryForObject("SELECT IlluminaWFStepID FROM  IlluminaWFSteps WHERE IlluminaWFStepName = 'BCL-2-FastQ Conversion'", Long.class);
        if (returnModel.size() > 0) {
            IlluminaExperimentStatusLog returnIlluminaExperimentStatus = returnModel.get(0);
            updateCount = jdbcTemplate.update("INSERT INTO IlluminaExperimentStatus_log(AutoID,IlluminaExperimentGUID,IlluminaWFStepID,IlluminaWFStatus,NGSExperimentName,InsertedOn,Description) " +
                            "VALUES (?,?,?,?,?,?,?)", returnIlluminaExperimentStatus.getAutoID(), returnIlluminaExperimentStatus.getIlluminaExperimentGUID(),
                    returnIlluminaExperimentStatus.getIlluminaWFStepID(), returnIlluminaExperimentStatus.getIlluminaWFStatus(),
                    returnIlluminaExperimentStatus.getNGSExperimentName(), returnIlluminaExperimentStatus.getInsertedOn(),
                    returnIlluminaExperimentStatus.getDescription());
        }
        long millis = System.currentTimeMillis();
        java.util.Date date = new java.util.Date(millis);
        updateCount = jdbcTemplate.update("UPDATE IlluminaExperimentStatus SET IlluminaWFStatus=?,InsertedOn=?,Description=? WHERE IlluminaExperimentGUID = ?",
                illuminaExperimentStatus.getIlluminaWFStatus(), date,
                illuminaExperimentStatus.getDescription(), illuminaExperimentStatus.getIlluminaExperimentGUID());
        if (updateCount > 0) {
            response.setStatus(true);
            response.setData("Success");
            mappingJacksonValue = APIFilter.responseFilterForIlluminaExperimentStatus(response,
                    new String[]{STATUS, "data"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } else {
            response.setStatus(false);
            response.setData("Failed to update");
            response.setInformation(
                    new InfoModel(new Date(), "Data not found", "Illumina Experiment Status data not available"));
            mappingJacksonValue = APIFilter.responseFilterForIlluminaExperimentStatus(response,
                    new String[]{STATUS, "data","information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
        }
    }
}
