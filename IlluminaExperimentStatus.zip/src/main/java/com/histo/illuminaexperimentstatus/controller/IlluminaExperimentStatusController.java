package com.histo.illuminaexperimentstatus.controller;

import com.histo.illuminaexperimentstatus.model.IlluminaExperimentPostModel;
import com.histo.illuminaexperimentstatus.service.IlluminaExperimentStatusService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("illuminaExperimentStatus")
public class IlluminaExperimentStatusController {
    private final IlluminaExperimentStatusService illuminaExperimentStatusService;

    public IlluminaExperimentStatusController(IlluminaExperimentStatusService illuminaExperimentStatus) {
        this.illuminaExperimentStatusService = illuminaExperimentStatus;
    }

    @PostMapping
    public ResponseEntity<Object> insertIlluminaExperimentStatus(@RequestBody IlluminaExperimentPostModel illuminaExperimentStatus) {
        return illuminaExperimentStatusService.insertIlluminaExperimentStatus(illuminaExperimentStatus);
    }

    @PutMapping
    public ResponseEntity<Object> updateIlluminaExperimentStatus(@RequestBody IlluminaExperimentPostModel illuminaExperimentStatus) {
        return illuminaExperimentStatusService.updateIlluminaExperimentStatus(illuminaExperimentStatus);
    }
}
