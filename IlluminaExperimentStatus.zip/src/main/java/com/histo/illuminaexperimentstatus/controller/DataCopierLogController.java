package com.histo.illuminaexperimentstatus.controller;

import com.histo.illuminaexperimentstatus.model.IlluminaDataSecondaryBackupLogModel;
import com.histo.illuminaexperimentstatus.model.PacbioDataSecondaryBackupLogModel;
import com.histo.illuminaexperimentstatus.service.DataCopierLogService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DataCopierLogController {

    private final DataCopierLogService dataCopierService;

    public DataCopierLogController(DataCopierLogService dataCopierService) {
        this.dataCopierService = dataCopierService;
    }

    @PostMapping("/illumina/log")
    public String insertIlluminaBackupLog(@RequestBody IlluminaDataSecondaryBackupLogModel backupLog) {
        return dataCopierService.insertIlluminaBackupLog(backupLog);
    }

    @PostMapping("/pacbio/log")
    public String insertPacbioBackupLog(@RequestBody PacbioDataSecondaryBackupLogModel backupLog) {
        return dataCopierService.insertPacbioBackupLog(backupLog);
    }
}
