package com.histo.illuminaexperimentstatus;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
@OpenAPIDefinition(
        servers = {
                @Server(url = "https://javawebag01.histogenetics.com:8765/IlluminaExperiment", description = "UAT Server"),
                @Server(url = "https://10.10.4.8:8765/IlluminaExperiment", description = "UAT Server in IP"),
                @Server(url = "https://javawebag01.histogenetics.com:8000/IlluminaExperiment", description = "Native Server"),
                @Server(url = "https://10.10.4.8:8000/IlluminaExperiment", description = "Native Server in IP")
        }
)
public class IlluminaExperimentStatusApplication {

    public static void main(String[] args) {
        SpringApplication.run(IlluminaExperimentStatusApplication.class, args);
    }

}
