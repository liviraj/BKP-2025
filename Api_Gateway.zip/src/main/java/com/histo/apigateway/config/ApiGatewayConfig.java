package com.histo.apigateway.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApiGatewayConfig {
    @Autowired
    private PropertyConfig propertyConfig;

    @Bean
    public RouteLocator gatewayRouter(RouteLocatorBuilder builder) {

        return builder.routes()
                .route("IlluminaExperiment",p -> p.path("/IlluminaExperiment/**")
                        //.uri("lb://IlluminaExperimentStatus"))
                        .uri(propertyConfig.getIlluminaExperimentStatusMicroserviceUri()))
                .route("DataCopierMicroService", predicateSpec -> predicateSpec.path("/DataCopier/**")
                        // .uri("lb://DataCopierMicroService"))
                        .uri(propertyConfig.getDataCopierMicroServiceUri()))
                .route("DigitalSignatureMicroService", predicateSpec -> predicateSpec.path("/DigitalSignature/**")
                        .uri(propertyConfig.getDigitalSignatureUri()))
                .route("WholeGenomeSequencingWebApi", predicateSpec -> predicateSpec.path("/WholeGenomeSequencing/**")
                        .uri(propertyConfig.getWholeGenomeSequencingUri()))
                .route("GridIonMicroservice", predicateSpec -> predicateSpec.path("/GridIon/**")
                        .uri(propertyConfig.getGridIonUri()))
                .route("PacbioReprocess", predicateSpec -> predicateSpec.path("/Reprocess/**")
                        .uri(propertyConfig.getPacbioReprocessUri()))
                .route("KeyVaultService", predicateSpec -> predicateSpec.path("/VaultService/**")
                        .uri(propertyConfig.getVaultServiceUri()))
                .route("EmailService", predicateSpec -> predicateSpec.path("/EmailServices/**")
                        .uri(propertyConfig.getEmailServiceUri()))
                .route("PacbioAnalysisService", predicateSpec -> predicateSpec.path("/PacbioAnalysis/**")
                        .uri(propertyConfig.getPacbioAnalysisServiceUri()))
                .route("HistoStatistics", predicateSpec -> predicateSpec.path("/Statistics/**")
                        .uri(propertyConfig.getHistoStatisticsServiceUri()))
                .route("IDTOrderAutomationAPI", predicateSpec -> predicateSpec.path("/IDTOrdering/**")
                        .uri(propertyConfig.getIdtOrderingServiceUri()))
                .route("PacbioJobsService", predicateSpec -> predicateSpec.path("/PacbioJobs/**")
                        .uri(propertyConfig.getPacbioJobsServiceUri()))
                .route("ProblemAnalyserService", predicateSpec -> predicateSpec.path("/ProblemAnalyser/**")
                        .uri(propertyConfig.getProblemAnalyserServiceUri()))
                .route("IncidentReportManagementSystemService", predicateSpec -> predicateSpec.path("/IncidentReportManagementSystem/**")
                        .uri(propertyConfig.getIrmsServiceUri()))
                .route("DocumentControlSystemService", predicateSpec -> predicateSpec.path("/DocumentControlSystem/**")
                        .uri(propertyConfig.getDcsServiceUri()))
                .route("BackupStatusViewerService", predicateSpec -> predicateSpec.path("/BackupStatusViewer/**")
                        .uri(propertyConfig.getBackupStatusViewerServiceUri()))
                .build();
    }
}
