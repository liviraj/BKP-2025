package com.histo.apigateway.config;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;

@Configuration
@NoArgsConstructor
@Getter
@Setter
@ToString
@PropertySource("classpath:application.properties")
@Order(Ordered.HIGHEST_PRECEDENCE)
public class PropertyConfig {
	@Value("${microservice.illumina-experiment-service.uri}")
	private String illuminaExperimentStatusMicroserviceUri;
	@Value("${microservice.data-copier.uri}")
	private String dataCopierMicroServiceUri;
	@Value("${microservice.digital-signature.uri}")
	private String digitalSignatureUri;
	@Value("${microservice.whole-genome-sequencing}")
	private String wholeGenomeSequencingUri;
	@Value("${microservice.url.gridion}")
	private String gridIonUri;
	@Value("${microservice.url.pacbio-reprocess}")
	private String pacbioReprocessUri;
	@Value("${microservice.url.key-vault}")
	private String vaultServiceUri;
	@Value("${microservice.url.email-service}")
	private String emailServiceUri;
	@Value("${microservice.url.pacbio-analysis-service}")
	private String pacbioAnalysisServiceUri;
	@Value("${microservice.url.histo-statistics-service}")
	private String histoStatisticsServiceUri;
	@Value("${microservice.url.idt-ordering-service}")
	private String idtOrderingServiceUri;
	@Value("${microservice.url.pacbio-jobs-service}")
	private String pacbioJobsServiceUri;
	@Value("${microservice.url.problem-analyser-service}")
	private String problemAnalyserServiceUri;
	@Value("${microservice.url.irms-service}")
	private String irmsServiceUri;
	@Value("${microservice.url.dcs-service}")
	private String dcsServiceUri;
	@Value("${microservice.url.backup-status-viewer-service}")
	private String backupStatusViewerServiceUri;
}
