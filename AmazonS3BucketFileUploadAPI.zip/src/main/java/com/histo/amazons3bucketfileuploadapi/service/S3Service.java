package com.histo.amazons3bucketfileuploadapi.service;

import com.histo.amazons3bucketfileuploadapi.model.ProgramName;
import com.histo.amazons3bucketfileuploadapi.model.S3FolderUploadRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

public interface S3Service {
    public ResponseEntity<Object> uploadFile(MultipartFile file, String bucketName, String region, String accessKey,
                                             String secretKey, String ClientProjectName);

    public ResponseEntity<Object> uploadFolder(S3FolderUploadRequest uploadRequest, ProgramName programName);
}
