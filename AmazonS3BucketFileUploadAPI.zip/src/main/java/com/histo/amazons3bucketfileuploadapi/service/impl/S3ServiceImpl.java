package com.histo.amazons3bucketfileuploadapi.service.impl;

import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.share.DiskShare;
import com.histo.amazons3bucketfileuploadapi.config.PropertyConfig;
import com.histo.amazons3bucketfileuploadapi.config.SmbConConfig;
import com.histo.amazons3bucketfileuploadapi.config.SqlConnectionSetup;
import com.histo.amazons3bucketfileuploadapi.model.ProgramName;
import com.histo.amazons3bucketfileuploadapi.model.S3FolderUploadRequest;
import com.histo.amazons3bucketfileuploadapi.model.WgsClientTransferStatus;
import com.histo.amazons3bucketfileuploadapi.service.S3Service;
import com.histo.amazons3bucketfileuploadapi.util.AmazonS3Util;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.core.exception.SdkException;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.EnumSet;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class S3ServiceImpl implements S3Service {
    private static final Logger logger = LogManager.getLogger(S3ServiceImpl.class.getName());

    private String fileNameWithPath;
    private final SmbConConfig smbConConfig;
    private final PropertyConfig propertyConfig;

    public S3ServiceImpl(SmbConConfig smbConConfig, PropertyConfig propertyConfig) {
        this.smbConConfig = smbConConfig;
        this.propertyConfig = propertyConfig;
    }

    @Override
    public ResponseEntity<Object> uploadFile(MultipartFile file, String bucketName, String region, String accessKey,
                                             String secretKey, String clientProjectName) {
        try {
            // Save the file temporarily
            Path tempFile = Files.createTempFile("temp", file.getOriginalFilename());
            Files.copy(file.getInputStream(), tempFile, StandardCopyOption.REPLACE_EXISTING);

            String currentDateFolder = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

            // Create project-specific folder and current date subfolder
            String key = clientProjectName + "/" + currentDateFolder + "/" + file.getOriginalFilename();

            logger.info("Upload  process started");
            long startProcess = System.currentTimeMillis();
            S3Client s3Client = S3Client.builder()
                    .region(Region.of(region))
                    .credentialsProvider(() -> AwsBasicCredentials.create(accessKey, secretKey))
                    .build();

            PutObjectRequest request = PutObjectRequest.builder()
                    .bucket(bucketName)
                    .key(key)
                    .build();

            s3Client.putObject(request, RequestBody.fromFile(tempFile));
            // Delete the temporary file
            Files.delete(tempFile);

            logger.info("Upload process completed");
            long endProcess = System.currentTimeMillis(); // end process
            logger.info("Illumina sync process taken time is: {}", AmazonS3Util.getDurationBreakdown(endProcess - startProcess));
            return ResponseEntity.status(HttpStatus.OK).body("File uploaded Successfully");
        } catch (Exception e) {
            logger.error("File upload Error: {}", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("File upload failed");
        }
    }

    @Override
    public ResponseEntity<Object> uploadFolder(S3FolderUploadRequest uploadRequest, ProgramName programName) {
        try {
            String folderPath = uploadRequest.folderPath().replace("\\", "/");
            List<String> folderPathSplit = Arrays.stream(folderPath.split("/"))
                    .filter(path -> !path.equalsIgnoreCase(""))
                    .collect(Collectors.toList());
            folderPath = folderPath.replace("//", "").replace(folderPathSplit.get(0) + "/", "").replace(folderPathSplit.get(1) + "/", "");

            DiskShare smbDiskShare = smbConConfig.getSmbDiskShare(folderPathSplit.get(0), folderPathSplit.get(1)
                    , propertyConfig.getSmbUsername(), propertyConfig.getSmbPassword());

            logger.info("Upload  process started");
            logger.info("Bucket Name: {}", uploadRequest.bucketName());

            long startProcess = System.currentTimeMillis();

            // Validate that the folder exists
            boolean isFolderExist = smbDiskShare.folderExists(folderPath);
            if (!isFolderExist) {
                logger.error("Invalid folder path Folder path = {}", folderPath.replace("/", "\\"));
                return ResponseEntity.status(HttpStatus.CONFLICT).body("Invalid folder path");
            }
            folderRecursion(smbDiskShare, folderPath, uploadRequest);

            logger.info("Upload process completed");
            long endProcess = System.currentTimeMillis(); // end process
            logger.info("Illumina sync process taken time is: {}", AmazonS3Util.getDurationBreakdown(endProcess - startProcess));

            if (programName == ProgramName.FILE_UPLOADER) {
                WgsClientTransferStatus wgsClientTransferStatus = new WgsClientTransferStatus();
                wgsClientTransferStatus.setDestinationUploadPath(uploadRequest.clientProjectName());
                wgsClientTransferStatus.setStatus(3);
                wgsClientTransferStatus.setWgsStatusViewerId(uploadRequest.wgsStatusViewerId());
                updateClientTransferStatus(wgsClientTransferStatus);
            }
            return ResponseEntity.status(HttpStatus.OK).body("Folder uploaded Successfully");
        } catch (Exception e) {
            logger.error("Folder upload error in method uploadFolder(). Error: {}", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Folder upload failed");
        }
    }

    private void updateClientTransferStatus(WgsClientTransferStatus statusData) {
        Connection con = SqlConnectionSetup.getConnection();
        JdbcTemplate jdbcTemplate = new JdbcTemplate(new SingleConnectionDataSource(con, false));

        jdbcTemplate.update("exec WGSUpdateGlobusTransferStatus ?,?,?", statusData.getStatus(),
                statusData.getDestinationUploadPath(), statusData.getWgsStatusViewerId());
    }
    private void folderRecursion(DiskShare diskShare, String folderPath, S3FolderUploadRequest uploadRequest) throws IOException {
        // Iterate through files in the folder and upload them
        if (!folderPath.endsWith("/")) {
            folderPath = folderPath.concat("/");
        }
        List<FileIdBothDirectoryInformation> fileList = diskShare.list(folderPath).stream().filter(
                fileInfo -> !fileInfo.getFileName().equals(".") && !fileInfo.getFileName().equals("..")
        ).toList();
        if (fileList != null) {
            for (FileIdBothDirectoryInformation fileInfo : fileList) {
                boolean isFileExist = diskShare.fileExists(folderPath.concat(fileInfo.getFileName()));
                String filePath = folderPath.concat(fileInfo.getFileName());
                if (isFileExist) {
                    uploadFileInS3(diskShare, fileInfo.getFileName(), uploadRequest, filePath);
                } else {
                    folderRecursion(diskShare, filePath, uploadRequest);
                }
            }
        }
    }

    private void uploadFileInS3(DiskShare diskShare, String fileName, S3FolderUploadRequest uploadRequest, String filePath) throws IOException {

        S3Client s3Client = S3Client.builder()
                .region(Region.of(uploadRequest.region()))
                .credentialsProvider(() -> AwsBasicCredentials.create(uploadRequest.accessKey(), uploadRequest.secretKey()))
                .build();
        String splitClientProjectName = uploadRequest.clientProjectName().split("[\\s-_]+")[0];
        String s3Path = filePath.substring(filePath.indexOf(splitClientProjectName));
        // Specify the S3 object metadata and upload the file
        PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                .bucket(uploadRequest.bucketName())
                .key(s3Path)
                .build();

        com.hierynomus.smbj.share.File file = diskShare.openFile(filePath, EnumSet.of(AccessMask.GENERIC_READ)
                , null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null);

        Path tempFile = Files.createTempFile("temp", fileName);
        Files.copy(file.getInputStream(), tempFile, StandardCopyOption.REPLACE_EXISTING);

        RequestBody requestBody = RequestBody.fromFile(tempFile);
        s3Client.putObject(putObjectRequest, requestBody);
        Files.delete(tempFile);
    }

    private long calculateContentLength(InputStream inputStream) throws IOException {
        // Calculate the content length of the input stream
        long contentLength = 0;
        byte[] buffer = new byte[4096]; // Adjust the buffer size as needed
        int bytesRead;
        while ((bytesRead = inputStream.read(buffer)) != -1) {
            contentLength += bytesRead;
        }
        return contentLength;
    }
}
