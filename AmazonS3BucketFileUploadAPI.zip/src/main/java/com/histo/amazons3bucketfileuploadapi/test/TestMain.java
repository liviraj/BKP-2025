package com.histo.amazons3bucketfileuploadapi.test;

public class TestMain {
    public static void main(String[] args) {
        String filePath = "//histonas2.histogenetics.com/Volume1Backup/Test/PacbioFileDataOrganizer/Syngenta Crop Protection LLC/runs/COH5527A7_2nd/ccs_data/";
        String clientProjectName = "Syngenta-HiFi";
        String split = clientProjectName.split("[\\s-_]+")[0];
        String s3Path = filePath.substring(filePath.indexOf(split));

        System.out.println(s3Path);

    }
}
