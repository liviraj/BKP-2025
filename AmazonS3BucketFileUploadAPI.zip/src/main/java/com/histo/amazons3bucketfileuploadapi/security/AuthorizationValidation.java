package com.histo.amazons3bucketfileuploadapi.security;

import java.sql.Connection;
import java.util.Date;
import java.util.concurrent.CompletableFuture;

import com.microsoft.graph.core.ClientException;
import com.nimbusds.jwt.JWT;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.JWTParser;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;

import com.histo.amazons3bucketfileuploadapi.config.SqlConnectionSetup;
import com.histo.amazons3bucketfileuploadapi.model.UserInformationModel;
import com.microsoft.graph.authentication.IAuthenticationProvider;
import com.microsoft.graph.requests.GraphServiceClient;

import okhttp3.Request;

public class AuthorizationValidation {

	private static final Logger logger = LogManager.getLogger(AuthorizationValidation.class.getName());
	private static final String STATUS = "status";

	MappingJacksonValue mappingJacksonValue;

	public AuthorizationValidation() {
		super();
	}

	public ResponseEntity<Object> isAuthorize(String token) {

		try {
			if (StringUtils.isNotBlank(token)) {
				String emailId = "";
				try {
					IAuthenticationProvider authProvider = requestUrl -> {
						CompletableFuture<String> future = new CompletableFuture<>();
						future.complete(token);
						return future;
					};

					GraphServiceClient<Request> graphClient = GraphServiceClient.builder()
							.authenticationProvider(authProvider).buildClient();

					emailId = graphClient.me().buildRequest().get().userPrincipalName;
				} catch (ClientException e) {
					JWT jwt = JWTParser.parse(token);
					JWTClaimsSet claimsSet = jwt.getJWTClaimsSet();
					if (isTokenExpire(claimsSet.getExpirationTime())) {
						return new ResponseEntity<>("Failed", HttpStatus.UNAUTHORIZED);
					} else {
						emailId = (String) claimsSet.getClaim("unique_name");
					}
				}
				if (StringUtils.isNotBlank(emailId)) {
					Connection con = SqlConnectionSetup.getConnection();
					JdbcTemplate jdbcTemplate = new JdbcTemplate(new SingleConnectionDataSource(con, false));
					String sql = "select UI.LoginName, UI.UserID, UI.FirstName, UI.LastName, UI.EmailAddress from UserInformation UI where UI.EmailAddress = ?";
					UserInformationModel userInformation = jdbcTemplate.queryForObject(sql,
							BeanPropertyRowMapper.newInstance(UserInformationModel.class), emailId);

					if (userInformation != null) {
						return new ResponseEntity<>("Success", HttpStatus.OK);
					} else {
						return new ResponseEntity<>("Failure", HttpStatus.CONFLICT);
					}

				} else {
					return new ResponseEntity<>("Failure", HttpStatus.CONFLICT);
				}
			} else {
				return new ResponseEntity<>("Failure", HttpStatus.UNAUTHORIZED);
			}

		} catch (Exception e) {
			logger.error("Exception message: {}", e);
			return new ResponseEntity<>("Failure", HttpStatus.UNAUTHORIZED);

		}
	}

	private boolean isTokenExpire(Date expiryDate) {
		// Extract the expiration time claim
		return expiryDate != null && expiryDate.before(new Date());
	}
}
