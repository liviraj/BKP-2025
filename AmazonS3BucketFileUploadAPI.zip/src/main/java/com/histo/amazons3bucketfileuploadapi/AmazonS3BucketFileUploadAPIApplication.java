package com.histo.amazons3bucketfileuploadapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmazonS3BucketFileUploadAPIApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmazonS3BucketFileUploadAPIApplication.class, args);
	}

}
