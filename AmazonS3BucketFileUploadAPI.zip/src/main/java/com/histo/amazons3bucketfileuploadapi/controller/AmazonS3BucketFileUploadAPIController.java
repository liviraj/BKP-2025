package com.histo.amazons3bucketfileuploadapi.controller;

import com.histo.amazons3bucketfileuploadapi.model.ProgramName;
import com.histo.amazons3bucketfileuploadapi.model.S3FolderUploadRequest;
import com.histo.amazons3bucketfileuploadapi.security.AuthorizationValidation;
import com.histo.amazons3bucketfileuploadapi.service.S3Service;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@RestController
@RequestMapping("/s3bucket")
public class AmazonS3BucketFileUploadAPIController {
    private static final Logger logger = LogManager.getLogger(AmazonS3BucketFileUploadAPIController.class.getName());

    @Autowired
    private S3Service s3Service;
    private AuthorizationValidation auth;

    public AmazonS3BucketFileUploadAPIController() {
        super();
        this.auth = new AuthorizationValidation();
    }

    @PostMapping(value = "/uploadFile", consumes = "multipart/form-data")
    public ResponseEntity<Object> uploadFile(@RequestParam("file") MultipartFile file, @RequestParam("bucketName") String bucketName, @RequestParam("region") String region,
                                             @RequestParam("accessKey") String accessKey, @RequestHeader("Authorization") String authorization,
                                             @RequestParam("secretKey") String secretKey, @RequestParam("clientProjectName") String clientProjectName) {
        authorization = authorization.replace("Bearer ", "").replace(" ", "");
        ResponseEntity<Object> authorize = auth.isAuthorize(authorization);
        if (authorize.getStatusCode() == HttpStatus.OK) {
            logger.info("File upload process start. Call /uploadFile start");

            // Upload to S3 using dynamic configuration

            ResponseEntity<Object> response = s3Service.uploadFile(file, bucketName, region, accessKey, secretKey,
                    clientProjectName);
            logger.info("File/folder upload process end. Call /upload end");
            return response;
        }
        return authorize;
    }

    @PostMapping("/uploadFolder")
    public ResponseEntity<Object> uploadFolder(@RequestHeader("Authorization") String authorizationHeader, @RequestBody S3FolderUploadRequest uploadRequest) {

        if (authorizationHeader == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Missing 'Authorization' header");
        }
        ResponseEntity<Object> authorizeRes = auth.isAuthorize(authorizationHeader);
        if (authorizeRes.getStatusCode() == HttpStatus.OK) {
                logger.info("upload process start. Call /uploadFolder start");
                s3Service.uploadFolder(uploadRequest, ProgramName.OTHERS);
                logger.info("Upload process end. Call /uploadFolder end");
            return new ResponseEntity<>("Folder upload submitted successfully", HttpStatus.OK);
        }
        return authorizeRes;
    }

    @PostMapping("/fileUploader/uploadFolder")
    public ResponseEntity<Object> uploadFolder(@RequestBody S3FolderUploadRequest uploadRequest) {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.submit(() -> {
            logger.info("upload process start. Call /fileUploader/uploadFolder start");
            s3Service.uploadFolder(uploadRequest, ProgramName.FILE_UPLOADER);
            logger.info("Upload process end. Call /fileUploader/uploadFolder end");
        });
        return new ResponseEntity<>("Folder upload submitted successfully", HttpStatus.OK);
    }
}
