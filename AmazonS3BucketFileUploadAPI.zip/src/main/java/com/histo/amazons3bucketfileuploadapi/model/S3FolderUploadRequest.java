package com.histo.amazons3bucketfileuploadapi.model;

public record S3FolderUploadRequest(
        String folderPath,
        String bucketName,
        String region,
        String accessKey,
        String secretKey,
        String clientProjectName,
        int wgsStatusViewerId
) {
}
