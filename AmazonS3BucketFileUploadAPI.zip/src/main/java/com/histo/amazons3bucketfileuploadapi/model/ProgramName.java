package com.histo.amazons3bucketfileuploadapi.model;

public enum ProgramName {
    FILE_UPLOADER,
    OTHERS
}
