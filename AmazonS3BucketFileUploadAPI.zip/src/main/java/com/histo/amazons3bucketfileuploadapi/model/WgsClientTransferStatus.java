package com.histo.amazons3bucketfileuploadapi.model;

public class WgsClientTransferStatus {
    private int wgsStatusViewerId;
    private int status;
    private String destinationUploadPath;

    public int getWgsStatusViewerId() {
        return wgsStatusViewerId;
    }

    public void setWgsStatusViewerId(int wgsStatusViewerId) {
        this.wgsStatusViewerId = wgsStatusViewerId;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getDestinationUploadPath() {
        return destinationUploadPath;
    }

    public void setDestinationUploadPath(String destinationUploadPath) {
        this.destinationUploadPath = destinationUploadPath;
    }

    @Override
    public String toString() {
        return "WgsClientTransferStatus{" +
                "wgsStatusViewerId=" + wgsStatusViewerId +
                ", status=" + status +
                ", destinationUploadPath='" + destinationUploadPath + '\'' +
                '}';
    }
}
