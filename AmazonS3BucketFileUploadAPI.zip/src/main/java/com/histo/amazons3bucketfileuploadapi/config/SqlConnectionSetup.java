package com.histo.amazons3bucketfileuploadapi.config;

import com.microsoft.sqlserver.jdbc.SQLServerDriver;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import javax.annotation.PostConstruct;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

@Configuration
@PropertySource("classpath:application.properties")
public class SqlConnectionSetup {
	public String histoServerURL;
	public String histoServerUsername;
	public String histoServerPassword;
	
	public static String url;
	public static String Uname;
	public static String Pswd;
	
	
	@Value("${spring.datasource.url}")
	public void setHistoServerURL(String histoServerURL) {
		SqlConnectionSetup.url = histoServerURL;
	}
	@Value("${spring.datasource.username}")
	public void setHistoServerUsername(String histoServerUsername) {
		SqlConnectionSetup.Uname = histoServerUsername;
	}
	@Value("${spring.datasource.password}")
	public void setHistoServerPassword(String histoServerPassword) {
		SqlConnectionSetup.Pswd = histoServerPassword;
	}

	private static Connection sqlcon = null;
	
	@PostConstruct
	private static Connection getSqlConnection() {
		try {
			DriverManager.registerDriver(new SQLServerDriver());
			sqlcon = DriverManager.getConnection(url, Uname, Pswd);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sqlcon;
	}
	
	public static synchronized Connection getConnection() {
		try {
			if(sqlcon == null || sqlcon.isClosed()) 
				getSqlConnection();
			}
			catch (Exception e) {
				System.err.println(e.getMessage());
			}
		return sqlcon;
		
	}
}
