package com.histo.amazons3bucketfileuploadapi.config;

import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component("smbConConfig")
public class SmbConConfig {
    private static final Logger LOGGER = LogManager.getLogger(SmbConConfig.class.getName());
    private final String SMB_DOMAIN_NAME = "histogenetics.com";

    public SmbConConfig() {
    }

    public DiskShare getSmbDiskShare(String serverName, String shareName, String username, String password) {
        DiskShare diskShare;
        SMBClient client = new SMBClient();
        try {
            Connection connection = client.connect(serverName);
            AuthenticationContext authContextSource = new AuthenticationContext(username, password.toCharArray(), SMB_DOMAIN_NAME);
            Session session = connection.authenticate(authContextSource);
            diskShare = (DiskShare) session.connectShare(shareName);
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
        return diskShare;
    }
}
