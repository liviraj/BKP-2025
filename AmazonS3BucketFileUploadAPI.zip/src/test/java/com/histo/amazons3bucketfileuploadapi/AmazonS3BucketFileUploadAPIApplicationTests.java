package com.histo.amazons3bucketfileuploadapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmazonS3BucketFileUploadAPIApplicationTests {

	@Test
	void contextLoads() {
	}

}
