package com.histo.pacbioanalysisservice;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@OpenAPIDefinition(
		servers = {
				@Server(url = "https://webapiuat.histogenetics.com:8765/PacbioAnalysis", description = "UAT Server API Gateway"),
				@Server(url = "https://javawebag01.histogenetics.com:8765/PacbioAnalysis", description = "PROD Server API Gateway"),
				@Server(url = "http://localhost:8765/PacbioAnalysis", description = "local Server"),
				@Server(url = "http://10.201.23.163:8765/PacbioAnalysis", description = "Local US IP API Gateway Server Native"),
				@Server(url = "http://10.201.100.32:8765/PacbioAnalysis", description = "Local IP API Gateway Server Native"),

				@Server(url = "https://javawebag01:8110/PacbioAnalysis", description = "PROD Server Native"),
				@Server(url = "https://webapiuat:8110/PacbioAnalysis", description = "UAT Server native"),
				@Server(url = "http://localhost:8110/PacbioAnalysis", description = "local Native Server"),
				@Server(url = "http://10.201.23.163:8110/PacbioAnalysis", description = "Local US IP Server Native"),
				@Server(url = "http://10.201.100.32:8110/PacbioAnalysis", description = "Local IP Server Native"),
		}
)
public class PacbioAnalysisServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PacbioAnalysisServiceApplication.class, args);
	}

}
