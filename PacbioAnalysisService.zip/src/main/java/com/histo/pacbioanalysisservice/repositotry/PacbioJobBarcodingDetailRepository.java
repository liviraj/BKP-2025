package com.histo.pacbioanalysisservice.repositotry;

import com.histo.pacbioanalysisservice.entity.PacbioJobBarcodingDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface PacbioJobBarcodingDetailRepository extends JpaRepository<PacbioJobBarcodingDetail, Integer> {

    @Query("SELECT DISTINCT BD.autoId, " +
            "BD.totalBarcodes, " +
            "BD.numberOfBarcodedFiles, " +
            "BD.numberOfBarcodedFiles1Kb, " +
            "BD.numberOfMissingBarcodes, " +
            "BD.jobName, " +
            "BD.jobsForWorkFlowId, " +
            "PSM.jobStatusMasterId " +
            "FROM PacbioJobBarcodingDetail BD " +
            "JOIN JobProcessStatusMaster PSM ON BD.jobsForWorkFlowId = PSM.jobsForWorkflowId " +
            "WHERE PSM.jobStatusMasterId = :statusMasterId")
    List<Object[]> findJobDetailsByStatusMasterId(@Param("statusMasterId") Integer statusMasterId);

    PacbioJobBarcodingDetail findByJobName(String jobName);


}