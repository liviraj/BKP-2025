package com.histo.pacbioanalysisservice.repositotry;

import com.histo.pacbioanalysisservice.entity.JobProcessStatusMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JobProcessStatusMasterRepository extends JpaRepository<JobProcessStatusMaster, Long> {
    JobProcessStatusMaster findByJobsForWorkflowIdAndJobProcessMasterId(Long jobsForWorkflowId, Integer jobProcessMasterId);

}