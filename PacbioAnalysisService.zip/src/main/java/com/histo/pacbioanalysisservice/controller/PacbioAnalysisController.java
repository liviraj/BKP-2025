package com.histo.pacbioanalysisservice.controller;

import com.histo.pacbioanalysisservice.model.JobStatusMasterEnum;
import com.histo.pacbioanalysisservice.model.PacbioJobBarcodingUpdateModel;
import com.histo.pacbioanalysisservice.service.PacbioAnalysisService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class PacbioAnalysisController {

    private final PacbioAnalysisService pacbioAnalysisService;

    public PacbioAnalysisController(PacbioAnalysisService pacbioAnalysisService) {
        this.pacbioAnalysisService = pacbioAnalysisService;
    }

    /*@GetMapping("/jobBarcodeDetails/{status}")
    public ResponseEntity<Object> getJobBarcodeDetailsByStatus(@PathVariable("status") JobStatusMasterEnum status) {
        return pacbioAnalysisService.getPacbioJobBarcodingDetailsByStatus(status.getValue());
    }*/

    @PutMapping("jobBarcodeDetails")
    public ResponseEntity<Object> updateJobBarcodeDetails(@RequestBody PacbioJobBarcodingUpdateModel updateModel) {
        return pacbioAnalysisService.updatePacbioJobBarcodingDetails(updateModel);
    }
}
