package com.histo.pacbioanalysisservice.service.impl;

import com.histo.pacbioanalysisservice.entity.JobProcessStatusMaster;
import com.histo.pacbioanalysisservice.entity.PacbioJobBarcodingDetail;
import com.histo.pacbioanalysisservice.model.JobBarcodeDetailsDTO;
import com.histo.pacbioanalysisservice.model.JobProcessMasterEnum;
import com.histo.pacbioanalysisservice.model.JobStatusMasterEnum;
import com.histo.pacbioanalysisservice.model.PacbioJobBarcodingUpdateModel;
import com.histo.pacbioanalysisservice.repositotry.JobProcessStatusMasterRepository;
import com.histo.pacbioanalysisservice.repositotry.PacbioJobBarcodingDetailRepository;
import com.histo.pacbioanalysisservice.service.PacbioAnalysisService;
import com.histo.pacbioanalysisservice.util.PacbioAnalysisUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class PacbioAnalysisServiceImpl implements PacbioAnalysisService {
    private static final Logger LOGGER = LogManager.getLogger(PacbioAnalysisServiceImpl.class.getName());
    private final PacbioJobBarcodingDetailRepository pacbioJobBarcodingDetailRepository;
    private final JobProcessStatusMasterRepository jobProcessStatusMasterRepository;

    public PacbioAnalysisServiceImpl(PacbioJobBarcodingDetailRepository pacbioJobBarcodingDetailRepository, JobProcessStatusMasterRepository jobProcessStatusMasterRepository) {
        this.pacbioJobBarcodingDetailRepository = pacbioJobBarcodingDetailRepository;
        this.jobProcessStatusMasterRepository = jobProcessStatusMasterRepository;
    }


    @Override
    public ResponseEntity<Object> getPacbioJobBarcodingDetailsByStatus(Integer statusId) {
        try {
            List<Object[]> results = pacbioJobBarcodingDetailRepository.findJobDetailsByStatusMasterId(statusId);
            if (results.size() == 0) {
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Data not found");
            }

            List<JobBarcodeDetailsDTO> jobDetailsByStatus = new ArrayList<>();

            for (Object[] result : results) {
                JobBarcodeDetailsDTO barcodeDetailsDTO = new JobBarcodeDetailsDTO(
                        (int) result[0],
                        (Integer) result[1],
                        (Integer) result[2],
                        (Integer) result[3],
                        (Integer) result[4],
                        (LocalDateTime) result[5],
                        (LocalDateTime) result[6],
                        (String) result[7],
                        (int) result[8],
                        (Integer) result[9]
                );
                jobDetailsByStatus.add(barcodeDetailsDTO);
            }
            return ResponseEntity.status(HttpStatus.OK).body(jobDetailsByStatus);
        } catch (Exception e) {
            LOGGER.error(e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Something happened, please try again");
        }
    }

    @Override
    public ResponseEntity<Object> updatePacbioJobBarcodingDetails(PacbioJobBarcodingUpdateModel pacbioJobBarcodingDetails) {
        try {
            PacbioJobBarcodingDetail barcodingDetails = pacbioJobBarcodingDetailRepository.findByJobName(pacbioJobBarcodingDetails.getJobName());
            if (barcodingDetails == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Barcoding detail not found for given id");
            }
            barcodingDetails.setTotalBarcodes(pacbioJobBarcodingDetails.getTotalBarcodes());
            barcodingDetails.setNumberOfBarcodedFiles(pacbioJobBarcodingDetails.getNumberOfBarcodedFiles());
            barcodingDetails.setNumberOfBarcodedFiles1Kb(pacbioJobBarcodingDetails.getNumberOfBarcodedFiles1Kb());
            barcodingDetails.setNumberOfMissingBarcodes(pacbioJobBarcodingDetails.getNumberOfMissingBarcodes());

            pacbioJobBarcodingDetailRepository.save(barcodingDetails);

            JobProcessStatusMaster jobProcessStatusMaster = jobProcessStatusMasterRepository.findByJobsForWorkflowIdAndJobProcessMasterId(
                    (long) barcodingDetails.getJobsForWorkFlowId()
                    , JobProcessMasterEnum.BARCODING.getValue());

            if (jobProcessStatusMaster == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Job Process Status Master detail not found for given id");
            }
            jobProcessStatusMaster.setJobStatusMasterId(pacbioJobBarcodingDetails.getStatusId());
            if (pacbioJobBarcodingDetails.getStatusId() == JobStatusMasterEnum.I.getValue()) {
                jobProcessStatusMaster.setStartTime(PacbioAnalysisUtil.getESTZoneTime());
            } else if (pacbioJobBarcodingDetails.getStatusId() == JobStatusMasterEnum.C.getValue()) {
                jobProcessStatusMaster.setCompletedTime(PacbioAnalysisUtil.getESTZoneTime());
            }
            jobProcessStatusMaster.setLastModifiedOn(PacbioAnalysisUtil.getESTZoneTime());
            jobProcessStatusMasterRepository.save(jobProcessStatusMaster);

            return ResponseEntity.status(HttpStatus.OK).body("Details updated successfully");
        } catch (Exception e) {
            LOGGER.error(e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Something happened, please try again");
        }
    }
}
