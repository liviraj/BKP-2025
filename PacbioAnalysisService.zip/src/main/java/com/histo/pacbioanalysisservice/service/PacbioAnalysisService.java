package com.histo.pacbioanalysisservice.service;

import com.histo.pacbioanalysisservice.model.PacbioJobBarcodingUpdateModel;
import org.springframework.http.ResponseEntity;

public interface PacbioAnalysisService {
    public ResponseEntity<Object> getPacbioJobBarcodingDetailsByStatus(Integer statusId);

    public ResponseEntity<Object> updatePacbioJobBarcodingDetails(PacbioJobBarcodingUpdateModel pacbioJobBarcodingDetails);
}
