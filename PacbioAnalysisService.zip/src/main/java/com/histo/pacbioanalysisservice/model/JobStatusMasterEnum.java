package com.histo.pacbioanalysisservice.model;

public enum JobStatusMasterEnum {
    NS(1), I(2), C(3), H(4), NA(5), F(6);

    private int value;

    JobStatusMasterEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
}
