package com.histo.pacbioanalysisservice.model;

public enum PacbioJobBarcodingDetailStatus {
    NOT_STARTED(1), IN_PROGRESS(2), COMPLETED(3);

    private Integer value;

    PacbioJobBarcodingDetailStatus(Integer value) {
        this.value = value;
    }

    public Integer getValue() {
        return value;
    }
}
