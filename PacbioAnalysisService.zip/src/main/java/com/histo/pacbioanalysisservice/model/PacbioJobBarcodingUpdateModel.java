package com.histo.pacbioanalysisservice.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PacbioJobBarcodingUpdateModel {
    private int totalBarcodes;
    private int numberOfBarcodedFiles;
    private int numberOfBarcodedFiles1Kb;
    private int numberOfMissingBarcodes;
    private Integer statusId;
    private String jobName;
}
