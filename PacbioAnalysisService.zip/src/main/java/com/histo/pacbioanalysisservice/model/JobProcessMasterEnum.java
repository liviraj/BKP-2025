package com.histo.pacbioanalysisservice.model;

import com.netflix.discovery.converters.Auto;

public enum JobProcessMasterEnum {
    JOB_SET_UP(1),
    MACHINE_RUN(2),
    DATA_TRANSFER(3),
    BARCODING(4),
    SECONDARY_ANALYSIS(5),
    DATA_IMPORT(6),
    AUTO_ANALYSIS(7),
    AUTO_REVIEW(8),
    DATA_UPLOAD(9);

    private int value;

    JobProcessMasterEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
}
