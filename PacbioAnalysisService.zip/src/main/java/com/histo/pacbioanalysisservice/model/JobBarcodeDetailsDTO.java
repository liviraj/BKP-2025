package com.histo.pacbioanalysisservice.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;

@Getter
@Setter
@ToString
public class JobBarcodeDetailsDTO {
    private int autoId;
    private Integer totalBarcodes;
    private Integer numberOfBarcodedFiles;
    private Integer numberOfBarcodedFiles1Kb;
    private Integer numberOfMissingBarcodes;
    private LocalDateTime barcodingStartTime;
    private LocalDateTime barcodingEndTime;
    private String jobName;
    private int jobsForWorkFlowId;
    private Integer jobStatusMasterId;

    public JobBarcodeDetailsDTO(int autoId, Integer totalBarcodes, Integer numberOfBarcodedFiles,
                                Integer numberOfBarcodedFiles1Kb, Integer numberOfMissingBarcodes,
                                LocalDateTime barcodingStartTime, LocalDateTime barcodingEndTime,
                                String jobName, int jobsForWorkFlowId, Integer jobStatusMasterId) {
        this.autoId = autoId;
        this.totalBarcodes = totalBarcodes;
        this.numberOfBarcodedFiles = numberOfBarcodedFiles;
        this.numberOfBarcodedFiles1Kb = numberOfBarcodedFiles1Kb;
        this.numberOfMissingBarcodes = numberOfMissingBarcodes;
        this.barcodingStartTime = barcodingStartTime;
        this.barcodingEndTime = barcodingEndTime;
        this.jobName = jobName;
        this.jobsForWorkFlowId = jobsForWorkFlowId;
        this.jobStatusMasterId = jobStatusMasterId;
    }
}

