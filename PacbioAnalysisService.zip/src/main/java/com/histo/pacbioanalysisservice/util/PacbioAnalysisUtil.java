package com.histo.pacbioanalysisservice.util;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

public class PacbioAnalysisUtil {
    public static Date getESTZoneTime() {
        ZonedDateTime estDateTime = ZonedDateTime.now(ZoneId.of("America/New_York"));
        Date estTime = Date.from(estDateTime.toInstant());
        return estTime;
    }
}
