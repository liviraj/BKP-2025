package com.histo.pacbioanalysisservice.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Table(name = "JobProcessStatusMaster")
@Getter
@Setter
@ToString
public class JobProcessStatusMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "JobProcessStatusMasterID")
    private Long jobProcessStatusMasterId;

    @Column(name = "JobsForWorkflowID")
    private long jobsForWorkflowId;

    @Column(name = "JobProcessMasterID")
    private Integer jobProcessMasterId;

    @Column(name = "JobStatusMasterID")
    private Integer jobStatusMasterId;

    @Column(name = "TimeStamp")
    private LocalDateTime timeStamp;

    @Column(name = "LastModifiedOn")
    private Date lastModifiedOn;

    @Column(name = "StartTime")
    private Date startTime;

    @Column(name = "CompletedTime")
    private Date completedTime;
}
