package com.histo.pacbioanalysisservice.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Table(name = "PacbioJobBarcodingDetails")
@Getter
@Setter
@ToString
public class PacbioJobBarcodingDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "AutoID")
    private int autoId;

    @Column(name = "TotalBarcodes")
    private int totalBarcodes;

    @Column(name = "NumberOfBarcodedFiles")
    private int numberOfBarcodedFiles;

    @Column(name = "NumberOfBarcodedFiles1Kb")
    private int numberOfBarcodedFiles1Kb;

    @Column(name = "NumberOfMissingBarcodes")
    private int numberOfMissingBarcodes;

    @Column(name = "JobsForWorkFlowID")
    private int jobsForWorkFlowId;

    @Column(name = "JobName")
    private String jobName;
}

