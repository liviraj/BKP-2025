package com.histo.pacbioanalysisservice.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "JobStatusMaster")
public class JobStatusMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "JobStatusMasterID")
    private Integer jobStatusMasterID;

    @Column(name = "JobStatusName", length = 64)
    private String jobStatusName;

    @Column(name = "JobStatusCode", length = 4)
    private String jobStatusCode;

    @Column(name = "Active")
    private Boolean active;

    @Column(name = "TimeStamp")
    private LocalDateTime timeStamp;
}

