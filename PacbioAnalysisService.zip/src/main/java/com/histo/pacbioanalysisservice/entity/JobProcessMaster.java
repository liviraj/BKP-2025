package com.histo.pacbioanalysisservice.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;

@Entity
@Table(name = "JobProcessMaster")
@Getter
@Setter
@ToString
public class JobProcessMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "JobProcessMasterID")
    private Integer jobProcessMasterID;

    @Column(name = "JobProcessName", length = 64)
    private String jobProcessName;

    @Column(name = "JobProcessOrder")
    private Integer jobProcessOrder;

    @Column(name = "Active")
    private Boolean active;

    @Column(name = "TimeStamp")
    private LocalDateTime timeStamp;
}

