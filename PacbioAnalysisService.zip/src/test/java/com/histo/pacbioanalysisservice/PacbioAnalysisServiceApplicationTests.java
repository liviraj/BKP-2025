package com.histo.pacbioanalysisservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PacbioAnalysisServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
