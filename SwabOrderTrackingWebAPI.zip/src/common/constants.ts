export class Constants {
    public static readonly URL_MS_GRAPH_ME: string = "https://graph.microsoft.com/v1.0/me";

    // invoice mail info
    public static readonly MAIL_TITLE: string = "Client Invoice";
    public static readonly BCC_MAIL: string[] = ["billing@histogenetics.com", "billing_dl@histogenetics.com", "nezih@histogenetics.com" ,"syy@histogenetics.com"];
    public static readonly MAIL_BODY = "\r\nDear Sir/Madam,\r\n\r\nPlease find herewith attached the invoice billed.\r\n\r\nThanks,\r\nHistogenetics\r\n\r\n\r\n*****Please do not reply to this mail. This is an automated mail.****\r\n" 
    public static readonly MAIL_SUBJECT = "Invoice#";
    public static readonly FROM_MAIL = "Billing@Histogenetics.com";
    public static readonly BILLING_CC_MAIL = ["apacci@histogenetics.com", "viji@histogenetics.com", "selenaflores@histogenetics.com"];

    public static readonly MAIL_HOST = "mail.histogenetics.com";

    // swab types
    public static readonly Buccal_Swab_Kit = "HistoGenetics Buccal Swab Kit"
    public static readonly FLOQSwabs = "HistoGenetics FLOQSwabs"

    public static readonly Buccal_Swab_Kit_DES = "Regular FLOQSwabs with 20 mm breaking point, 2 swabs/pouch, 1 buccal swab card holder, 1 envelope"
    public static readonly FLOQSwabs_DES = "Regular FLOQSwabs with 20 mm breaking point, 2 swabs/pouch"

    public static readonly FEDEX_TRACKING_LINK = "https://www.fedex.com/fedextrack/?tracknumbers=";
    public static readonly SOURCE_PROGRAM = "Swab Order";
    public static readonly INVOICE_REF_TYPE = "Invoice";
};

export const Message = (props: any) => {
   return {
    BoxIDValid: `BoxID(${props}) already exists`,
    unauthorizedPath: "You are requesting an unauthorized resource, please contact the administrator"
   }
};