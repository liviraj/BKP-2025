export default class ResponseModel {
    success: boolean;
    message: any;
    data: any;

    constructor(success: boolean, message: any, data?: any) {
        this.success = success
        this.message = message;
        this.data = data;
    }
}