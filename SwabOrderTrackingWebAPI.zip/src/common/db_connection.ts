import 'dotenv/config';
import { config, connect, ConnectionPool, PoolOpts, Connection, MSSQLError, IOptions } from 'mssql/msnodesqlv8';

const _server: string = process.env.DB_HOST == undefined ? "" : process.env.DB_HOST;
const _serverHisto: string = process.env.DB_HOST_HISTO == undefined ? "" : process.env.DB_HOST_HISTO;

const _port: number = Number(process.env.DB_PORT == undefined ? 1433 : process.env.DB_PORT);

const _shipmnetTrackingSystemDatabase: string = process.env.SHIPMENT_TRACKING_SYSTEM_DB == undefined ? "" : process.env.SHIPMENT_TRACKING_SYSTEM_DB;
const _histoSDatabase: string = process.env.HISTO_S_DB == undefined ? "" : process.env.HISTO_S_DB;
const _histoDocumentsDatabase: string = process.env.HISTO_DOCUMENTS == undefined ? "" : process.env.HISTO_DOCUMENTS;

const _user: string = process.env.DB_USER == undefined ? "" : process.env.DB_USER;
const _userHisto: string = process.env.DB_USER_HISTO == undefined ? "" : process.env.DB_USER_HISTO;
const _password: string = process.env.DB_PASS == undefined ? "" : process.env.DB_PASS;
const _minPoolCount: number = Number(process.env.MIN_POOL == undefined ? "" : process.env.MIN_POOL);
const _maxPoolCount: number = Number(process.env.MAX_POOL == undefined ? "" : process.env.MAX_POOL);

const _poolOpts: PoolOpts<Connection> = { min: _minPoolCount, max: _maxPoolCount };
const _options: IOptions = { trustServerCertificate: false, trustedConnection: false };

const _shipmnetTrackingSystemConfig: config = { driver: "msnodesqlv8", server: _server, port: _port, database: _shipmnetTrackingSystemDatabase, user: _user, password: _password, pool: _poolOpts, options: _options }
const _histoSConfig: config = { driver: "msnodesqlv8", server: _serverHisto, port: _port, database: _histoSDatabase, user: _userHisto, password: _password, pool: _poolOpts, options: _options }
const _histoDocumentsConfig: config = { driver: "msnodesqlv8", server: _server, port: _port, database: _histoDocumentsDatabase, user: _user, password: _password, pool: _poolOpts, options: _options }

// ShipmnetTrackingSystem DB
export const ShipmnetTrackingSystemConfigSql = connect(_shipmnetTrackingSystemConfig).catch((err: MSSQLError) => {
    console.log(`❌ ${err}`);
    console.log(`❌ ${err.originalError}`);
});
export const shipmentTrackingSystemConnectionPool = new ConnectionPool(_shipmnetTrackingSystemConfig);

// HistoS DB
export const HistoSConfigSql = connect(_histoSConfig).catch((err: MSSQLError) => {
    console.log(`❌ ${err}`);
    console.log(`❌ ${err.originalError}`);
});
export const histoSConnectionPool = new ConnectionPool(_histoSConfig);

// HistoDocuments DB
export const HistoDocumentsConfigSql = connect(_histoDocumentsConfig).catch((err: MSSQLError) => {
    console.log(`❌ ${err}`);
    console.log(`❌ ${err.originalError}`);
});
export const histoDocumentsConnectionPool = new ConnectionPool(_histoDocumentsConfig);