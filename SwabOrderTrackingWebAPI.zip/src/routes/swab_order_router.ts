import express, { Request, Response } from "express";
import { SwabOrderService } from "../service/swab_order_service";
import { auth } from "../middleware/auth";
import { InventoryStatus, SwabOrder, SwabRequestByClientId, SwabStatus } from "../models/swab_order_model";
import { SwabOrderDA } from "../data_access/swab_order_data_access";
import { SwabUOM as SwabOrderType, T_ShipmentCarrier as ShipmentCarrier } from '@prisma/client';
import ResponseModel from "../common/response_model";

export const swab_order_router = express.Router();

/**
 * @swagger
 * components:
 *   schemas:
 *     SwabOrder:
 *       type: object
 *       required:
 *         - ClientName
 *         - TobeShippedQty
 *         - RequestDaysCount
 *         - ClientID
 *         - RequestID
 *         - DispatchMasterID 
 *       properties:
 *         ClientName:
 *           type: string
 *           description: Client name
 *         TobeShippedQty:
 *           type: integer
 *           description: Number of Swab to be shipped
 *         RequestDaysCount:
 *           type: integer
 *           description: Number of days since request
 *         ClientID:
 *            type: integer
 *            description: Client unique id
 *         RequestId: 
 *            type: integer
 *            description: Swab request unique id
 *         DispatcherMasterId:
 *            type: integer
 *            description: Dispatcher request unique id
 *       example:
 *         ClientName: test
 *         ToBeShippedCount: 500
 *         RequestDaysCount: 2
 *         ClientId: 1
 *         RequestId: 15
 *         DispatchMasterId: 1
 * 
 *     SwabOrderType:
 *       type: object
 *       required:
 *         - SwabOrderTypeId
 *         - SwabOrderType
 *         - SwabOrderTypeValue
 *       properties:
 *         SwabOrderTypeId:
 *           type: integer
 *           description: unique 
 *         SwabOrderType:
 *           type: integer
 *           description: Swab order type
 *         SwabOrderTypeValue:
 *           type: float
 *           description: Swab order type cost
 *       example:
 *         SwabOrderTypeId: 1
 *         SwabOrderType: HistoGenetics FLOQSwabs
 *         requestDaysCount: 0.5
 * 
 *     SwabDispatchStatus:
 *       type: object
 *       properties:
 *         DispatchMasterID:
 *           type: integer
 *           description: unique 
 *         DispatchStatus:
 *           type: string
 *           description: Swab order type
 * 
 *     InventoryStatus:
 *       type: object
 *       properties:
 *         AvailableQty:
 *           type: integer
 *           description: Available quantity
 *         ReOrderLevel:
 *           type: integer
 *           description: Re order level count
 *       example:
 *         AvailableQty: 100
 *         ReOrderLevel: 1000
 * 
 *     ShipmentCarrier:
 *       type: object
 *       properties:
 *         ShipmentCarrierID:
 *           type: integer
 *           description: Unique ID
 *         ShipmentCarrier:
 *           type: string
 *           description: Carrier name
 *       example:
 *         ShipmentCarrierID: 1
 *         ShipmentCarrier: FEDX
 * 
 *     SwabStatus:
 *       type: object
 *       properties:
 *         id:
 *           type: integer
 *           description: Unique ID
 *         status:
 *           type: string
 *           description: Swab status value
 *       example:
 *         id: 1
 *         status: Fully Shipped
 * 
 *     CustomsDoc:
 *       type: object
 *       properties:
 *         DispatchMasterID:
 *           type: integer
 *           description: Unique ID
 *         TrackingNumber:
 *           type: string
 *           description: Shippment tracking number
 *       example:
 *         DispatchMasterID: 1
 *         TrackingNumber: "12345"
 *    
 *     SwabOrderRequestDTO:
 *       type: object
 *       properties:
 *         RequestID:
 *           type: integer
 *           description: Unique ID
 *         ClientID:
 *           type: integer
 *           description: Unique ID
 *         ClientShipmentAutoID:
 *           type: integer
 *           description: Unique ID
 *         RequestedDate:
 *           type: string
 *           description: Swab request date
 *         ClientName:
 *           type: string
 *           description: Client name
 *         QtyRequested:
 *           type: integer
 *           description: Requested quantity
 *         SwabUOM:
 *           type: string
 *           description: Swab type
 *         RequestorName:
 *           type: string
 *           description: Requestor name
 *         RequestorEmailAddress:
 *           type: string
 *           description: Requestor email
 *         RequestorContactNumber:
 *           type: string
 *           description: Requestor contact number
 *         ShippingAddress1:
 *           type: string
 *           description: Shipping address1
 *         Address2:
 *           type: string
 *           description: Shipping address2
 *         City:
 *           type: string
 *           description: City name
 *         State:
 *           type: string
 *           description: State name
 *         Zip:
 *           type: string
 *           description: Zip code
 *         CountryID:
 *           type: string
 *           description: Country ID/ Country Code 
 *         Notes:
 *           type: string
 *           description: Notes 
 *         Status:
 *           type: string
 *           description: Swab request shipped status
 *         isAddressDiffer:
 *            type: boolean
 *            description: Is address diffrent from client address
 * 
 *     SwabOrderRequest:
 *       type: object
 *       properties:
 *          requestDetails: 
 *            type: object
 *            properties:
 *              RequestID:
 *                type: integer
 *                format: int32
 *                description: Swab reqeust unique id
 *              RequestedDate: 
 *                type: string
 *                description: Requested date
 *              ClientID: 
 *                type: integer
 *                format: int32
 *                description: Client unique id
 *              RequestorName: 
 *                type: string
 *                description: Swab requestor name
 *              RequestorEmailAddress: 
 *                type: string
 *                description: Swab requestor email id
 *              RequestorContactNumber:
 *                type: string
 *                description: Requestor contact number
 *              SwabUOMID: 
 *                type: integer
 *                format: int32
 *                description: Swab type unique id
 *              QtyRequested: 
 *                type: integer
 *                format: int32
 *                description: Swab requested qty
 *              TobeShippedQty: 
 *                type: integer
 *                format: int32
 *                description: Swab to be shipped qty
 *              LastModifiedBy: 
 *                type: integer
 *                format: int32
 *                description: UserID
 *          shipmentDetail: 
 *            type: object
 *            properties:
 *              ClientShipmentAutoID:
 *                type: integer
 *                format: int32
 *                description: Swab reqeust shipping unique id
 *              ShippingAddress1: 
 *                type: string
 *                description: Address detail 1
 *              Address2: 
 *                type: string
 *                description: Address detail 2
 *              City: 
 *                type: string
 *                description: City name
 *              State: 
 *                type: string
 *                description: State name
 *              Zip: 
 *                type: string
 *                description: Zip code
 *              CountryID: 
 *                type: string
 *                description: Country id
 *              Notes: 
 *                type: string
 *                description: Notes text
 *              RequestID: 
 *                type: integer
 *                description: Swab request unique ID
 *              ClientID:
 *                type: integer
 *                description: Client unique ID
 *              LastModifiedBy: 
 *                type: integer
 *                format: int32
 *                description: UserID
 * 
 *     ShipmentDetail: 
 *       type: object
 *       properties:
 *         ClientShipmentAutoID:
 *           type: integer
 *           format: int32
 *           description: Swab reqeust shipping unique id
 *         ClientID:
 *           type: integer
 *           format: int32
 *           description: Client id
 *         ShippingAddress1: 
 *           type: string
 *           description: Address detail 1
 *         Address2: 
 *           type: string
 *           description: Address detail 2
 *         City: 
 *           type: string
 *           description: City name
 *         State: 
 *           type: string
 *           description: State name
 *         Zip: 
 *           type: string
 *           description: Zip code
 *         CountryID: 
 *           type: string
 *           description: Country id
 *         Notes: 
 *           type: string
 *           description: Notes text
 *         RequestID: 
 *           type: integer
 *           description: Swab request unique ID
 * 
 *     DispatchDeatail:
 *       type: object
 *       properties:
 *          dispatchMasterDetails: 
 *            type: object
 *            properties: 
 *              DispatchMasterID: 
 *                type: integer
 *                format: int32
 *                description: Dispatch master unique ID
 *              ClientID: 
 *                type: integer
 *                format: int32
 *                description: Client unique ID   
 *              DispatchDate: 
 *                type: string
 *                description: Diapatch date
 *              DispatchBy: 
 *                type: string
 *                description: DispatchBy value  
 *              ShipCarrierID: 
 *                type: integer
 *                format: int32
 *                description: Ship Carrier ID
 *              ShippingTrackingNumber: 
 *                type: string
 *                description: Shipping Tracking Number
 *              DeliveryStatusID: 
 *                type: integer
 *                format: int32
 *                description: Delivery Status ID
 *              DeliveryDate: 
 *                type: string
 *                description: Delivery Date
 *              ReceiverName: 
 *                type: string
 *                description: Receiver Name
 *              ShipmentandHandlingCost: 
 *                type: string
 *                description: Shipment and Handling Cost
 *              SwabCost: 
 *                type: string
 *                description: SwabCost,
 *              LastModifiedBy: 
 *                type: integer
 *                format: int32
 *                description: UserID
 *          dispatchDetails: 
 *            type: object
 *            properties: 
 *              DispatchDetailID: 
 *                type: integer
 *                format: int32
 *                description: Dispatch Detail unique ID
 *              DispatchMasterID: 
 *                type: integer
 *                format: int32
 *                description: Dispatch Master unique ID
 *              RequestID: 
 *                type: integer
 *                format: int32
 *                description: Request unique ID
 *              DispatchQty: 
 *                type: integer
 *                format: int32
 *                description: Dispatch Qty
 *              LotNumber: 
 *                type: string
 *                description: LotNumber
 *              LastModifiedBy: 
 *                type: integer
 *                format: int32
 *                description: UserID
 *
 *     SwabOrderRequestById:
 *       type: object
 *       properties:
 *         RequestID: 
 *           type: integer
 *           format: int32
 *           description: Swab request unique id
 *         RequestedDate: 
 *           type: string
 *           description: Requested date
 *         ClientID: 
 *           type: integer
 *           format: int32
 *           description: Client unique id
 *         RequestorName: 
 *           type: string
 *           description: Swab requestor name
 *         RequestorEmailAddress: 
 *           type: string
 *           description: Swab requestor email id
 *         SwabUOMID: 
 *           type: integer
 *           format: int32
 *           description: Swab type unique id
 *         SwabUOM: 
 *           type: string
 *           description: Swab type
 *         QtyRequested: 
 *           type: integer
 *           format: int32
 *           description: Swab requested qty
 *         ShippingAddress1: 
 *           type: string
 *           description: Address detail 1
 *         Address2: 
 *           type: string
 *           description: Address detail 2
 *         City: 
 *           type: string
 *           description: City name
 *         State: 
 *           type: string
 *           description: State name
 *         Zip: 
 *           type: string
 *           description: Zip code
 *         CountryID: 
 *           type: string
 *           description: Country id
 *         Notes: 
 *           type: string
 *           description: Notes text
 */

/**
  * @swagger
  * tags:
  *   name: SwabOrder
  *   description: SwabOrder managing API
  */

/**
 * @swagger
 * /swabOrder/pending:
 *   get:
 *     summary: Returns the list of pending swab orders
 *     tags: [SwabOrder]
 *     responses:
 *       200:
 *         description: The list of the pending swab orders
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/SwabOrder'
 */
swab_order_router.get("/pending", auth, async (req: Request, res: Response) => {
  await SwabOrderService.getSwabOrderPending()
    .then((val: SwabOrder[]) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 * /swabOrder/types:
 *   get:
 *     summary: Returns the list of  swab order types
 *     tags: [SwabOrder]
 *     responses:
 *       200:
 *         description: The list of the swab order types
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/SwabOrderType'
 */
swab_order_router.get("/types", auth, async (req: Request, res: Response) => {
  await SwabOrderDA.getSwabOrdersType()
    .then((val: SwabOrderType[]) => res.json(val))
    .catch((err) => res.status(500).send(err));
})

/**
 * @swagger
 * /swabOrder/shipmentCarriers:
 *   get:
 *     summary: Returns the list of  shipmentCarriers
 *     tags: [SwabOrder]
 *     responses:
 *       200:
 *         description: The list of the shipmentCarriers
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/ShipmentCarrier'
 */
swab_order_router.get("/shipmentCarriers", auth, async (req: Request, res: Response) => {
  await SwabOrderDA.getShipmentCarriers()
    .then((val: ShipmentCarrier[]) => res.json(val))
    .catch((err) => res.status(500).send(err));
})

/**
 * @swagger
 * /swabOrder/inventoryStatus:
 *   get:
 *     summary: Returns the inventory status
 *     tags: [SwabOrder]
 *     responses:
 *       200:
 *         description: inventory status
 *         content:
 *           application/json:
 *             schema:
 *                 $ref: '#/components/schemas/InventoryStatus'
 */
swab_order_router.get("/inventoryStatus", auth, async (req: Request, res: Response) => {
  await SwabOrderDA.inventoryStatus()
    .then((val: InventoryStatus) => res.json(val))
    .catch((err) => res.status(500).send(err));
})

/**
 * @swagger
 * /swabOrder/deliveryStatus:
 *   get:
 *     summary: Returns the Swab statuses
 *     tags: [SwabOrder]
 *     responses:
 *       200:
 *         description: Swab statuses
 *         content:
 *           application/json:
 *             schema:
 *                 $ref: '#/components/schemas/SwabStatus'
 */
swab_order_router.get("/deliveryStatus", auth, async (req: Request, res: Response) => {
  await SwabOrderDA.getSwabStatuses()
    .then((val: SwabStatus[]) => res.json(val))
    .catch((err) => res.status(500).send(err));
})
/**
 * @swagger
 * /swabOrder/request:
 *   post:
 *     summary: Create the swab request
 *     tags: [SwabOrder]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/SwabOrderRequest'
 *     responses:
 *       200:
 *         description: Swab order request created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SwabOrderRequest'
 *       500:
 *         description: Internal server error
 */
swab_order_router.post("/request", auth, async (req: Request, res: Response) => {
  let requestData: any = req.body;
  await SwabOrderService.createSwabrequest(requestData)
    .then((val: ResponseModel) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 * /swabOrder/request:
 *   get:
 *     summary: Get all swab request
 *     tags: [SwabOrder]
 *     responses:
 *       200:
 *         description: List of all swab request
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/SwabOrderRequestDTO'
 *       500:
 *         description: Internal server error
 */
swab_order_router.get("/request", auth, async (req: Request, res: Response) => {
  await SwabOrderService.getAllSwabRequest()
    .then((val: ResponseModel) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 * /swabOrder/request/{RequestID}:
 *   get:
 *     summary: Get the swab request details by id
 *     tags: [SwabOrder]
 *     parameters:
 *       - in: path
 *         name: RequestID
 *         schema:
 *           type: integer
 *         required: true
 *         description: Swab request unique id
 *     responses:
 *       200:
 *         description:  Swab request details
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SwabOrderRequestById'
 *       500:
 *         description: Internal server error
 */
swab_order_router.get("/request/:RequestID", auth, async (req: Request, res: Response) => {
  const { RequestID } = req.params
  await SwabOrderService.getSwabRequestById(RequestID)
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 * /swabOrder/request/{RequestID}:
 *   delete:
 *     summary: Delete the swab request
 *     tags: [SwabOrder]
 *     parameters:
 *       - in: path
 *         name: RequestID
 *         type: integer
 *         description: Swab request unique id
 *     responses:
 *       200:
 *         description: Deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SwabOrderRequest'
 *       500:
 *         description: Internal server error
 */
swab_order_router.delete("/request/:RequestID", auth, async (req: Request, res: Response) => {
  let RequestID = req.params.RequestID;
  await SwabOrderDA.deleteSwabRequestById(RequestID)
    .then((val: ResponseModel) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 * /swabOrder/request:
 *   put:
 *     summary: Update the swab request
 *     tags: [SwabOrder]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/SwabOrderRequest'
 *     responses:
 *       200:
 *         description: Update wab request
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SwabOrderRequest'
 *       500:
 *         description: Internal server error
 */
swab_order_router.put("/request", auth, async (req: Request, res: Response) => {
  let requestData: any = req.body;
  await SwabOrderDA.updateSwabrequest(requestData)
    .then((val: ResponseModel) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 * /swabOrder/requestFilter:
 *   get:
 *     summary: Get the swab request details by id
 *     tags: [SwabOrder]
 *     parameters:
 *       - in: query
 *         name: RequestPeriod
 *         schema:
 *           type: string
 *           enum: [All, Custom, Last 30 Days, Last 3 Months, Last 6 Months, Last 7 Days, This year, Today, Today and Yesterday, Yesterday]
 *         description: RequestPeriod
 *       - in: query
 *         name: FromDate
 *         schema:
 *           type: string
 *           format: date
 *         description: From date
 *       - in: query
 *         name: ToDate
 *         schema:
 *           type: string
 *           format: date
 *         description: To date
 *       - in: query
 *         name: ClientID
 *         schema:
 *           type: integer
 *         description: Client unique id
 *       - in: query
 *         name: Status
 *         schema:
 *           type: string
 *           enum: [All, Fully Shipped, Partially Shipped, Not Shipped]
 *         description: Request shipped status
 *     responses:
 *       200:
 *         description:  Swab request details
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/SwabOrderRequestDTO'
 *       500:
 *         description: Internal server error
 */
swab_order_router.get("/requestFilter", auth, async (req: Request, res: Response) => {
  const filterValues = req.query;
  await SwabOrderService.getSwabRequestByFilters(filterValues)
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 * /swabOrder/{ClientID}/request:
 *   get:
 *     summary: Get the swab request details by ClientID
 *     tags: [SwabOrder]
 *     parameters:
 *       - in: path
 *         name: ClientID
 *         type: integer
 *         description: Client unique id
 *     responses:
 *       200:
 *         description:  Swab request details
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/SwabOrderRequestDTO'
 *       500:
 *         description: Internal server error
 */
swab_order_router.get("/:ClientID/request", auth, async (req: Request, res: Response) => {
  const ClientID = req.params.ClientID;

  await SwabOrderDA.getSwabRequestByClientID(Number(ClientID))
    .then((val: any) => {
      res.json(val);
    })
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 * /swabOrder/shippingAddress/{RequestID}:
 *   get:
 *     summary: Get the swab request details by ClientID
 *     tags: [SwabOrder]
 *     parameters:
 *       - in: path
 *         name: RequestID
 *         type: integer
 *         description: Swab request unique id
 *     responses:
 *       200:
 *         description:  Shipping details
 *         content:
 *           application/json:
 *             schema:
 *                 $ref: '#/components/schemas/ShipmentDetail'
 *       500:
 *         description: Internal server error
 */
swab_order_router.get("/shippingAddress/:RequestID", auth, async (req: Request, res: Response) => {
  const RequestID = req.params.RequestID;

  await SwabOrderDA.getShippingAddressByRequestID(Number(RequestID))
    .then((val: any) => {
      res.json(val);
    })
    .catch((err) => res.status(500).send(err));
});

// Dispatch Detail Routes
/**
 * @swagger
 * /swabOrder/dispatch:
 *   post:
 *     summary: Create the dispatch request
 *     tags: [SwabOrder]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/DispatchDeatail'
 *     responses:
 *       200:
 *         description: Dispatch detail created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/DispatchDeatail'
 *       500:
 *         description: Internal server error
 */
swab_order_router.post("/dispatch", auth, async (req: Request, res: Response) => {
  let requestData: any = req.body;
  await SwabOrderDA.createDispatch(requestData)
    .then((val: ResponseModel) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 * /swabOrder/dispatch:
 *   put:
 *     summary: Update the dispatch request
 *     tags: [SwabOrder]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/DispatchDeatail'
 *     responses:
 *       200:
 *         description: Dispatch detail created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/DispatchDeatail'
 *       500:
 *         description: Internal server error
 */
swab_order_router.put("/dispatch", auth, async (req: Request, res: Response) => {
  let requestData: any = req.body;
  await SwabOrderDA.updateDiapatch(requestData)
    .then((val: ResponseModel) => { 
      res.statusMessage = val.message;
      return val.success ? res.json(val) : res.status(406).json(val)})
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 * /swabOrder/dispatch/{DispatchMasterID}:
 *   delete:
 *     summary: Delete the dispatch
 *     tags: [SwabOrder]
 *     parameters:
 *       - in: path
 *         name: DispatchMasterID
 *         type: integer
 *         description: Dispatch master unique id
 *     responses:
 *       200:
 *         description: Deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/DispatchDeatail'
 *       500:
 *         description: Internal server error
 */
swab_order_router.delete("/dispatch/:DispatchMasterID", auth, async (req: Request, res: Response) => {
  let DispatchMasterID = req.params.DispatchMasterID;
  await SwabOrderDA.deleteDispatchtById(DispatchMasterID)
    .then((val: ResponseModel) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 * /swabOrder/dispatch:
 *   get:
 *     summary: Get all dispatch
 *     tags: [SwabOrder]
 *     responses:
 *       200:
 *         description: Dispatch detail created successfully
 *         content:
 *           application/json:
 *              schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/DispatchDeatail'
 *       500:
 *         description: Internal server error
 */
swab_order_router.get("/dispatch", auth, async (req: Request, res: Response) => {
  await SwabOrderDA.getAllDispatch()
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 * /swabOrder/dispatchFilter:
 *   get:
 *     summary: Get the swab request details by id
 *     tags: [SwabOrder]
 *     parameters:
 *       - in: query
 *         name: DispatchPeriod
 *         schema:
 *           type: string
 *           enum: [All, Custom, Last 30 Days, Last 3 Months, Last 6 Months, Last 7 Days, This year, Today, Today and Yesterday, Yesterday]
 *         description: Dispatch Period
 *       - in: query
 *         name: FromDate
 *         schema:
 *           type: string
 *           format: date
 *         description: From date
 *       - in: query
 *         name: ToDate
 *         schema:
 *           type: string
 *           format: date
 *         description: To date
 *       - in: query
 *         name: ClientID
 *         schema:
 *           type: integer
 *         description: Client unique id
 *       - in: query
 *         name: BillingStatus
 *         schema:
 *           type: string
 *           enum: [Not Received, Fully Received, Partially Received, Bad Debt, All]
 *         description: Billing status
 *       - in: query
 *         name: DeliveryStatus
 *         schema:
 *           type: string
 *           enum: [Shipped, Delivered, Return, Lost, All]
 *         description: Delivery status
 *     responses:
 *       200:
 *         description:  Swab dispatch details
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/DispatchDeatail'
 *       500:
 *         description: Internal server error
 */
swab_order_router.get("/dispatchFilter", auth, async (req: Request, res: Response) => {
  const filterValues = req.query;
  await SwabOrderDA.getDispatchByFilters(filterValues)
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 * /swabOrder/dispatch/getCustomsDoc:
 *   post:
 *     summary: Get customs doc
 *     tags: [SwabOrder]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CustomsDoc'
 *     responses:
 *       200:
 *         description: Get customs document successfully
 *         content:
 *           application/json:
 *             schema:
 *                $ref: '#/components/schemas/CustomsDoc'
 *       500:
 *         description: Internal server error
 */
swab_order_router.post("/dispatch/getCustomsDoc", auth, async (req: Request, res: Response) => {
  let DispatchMasterID = req.body;
  await SwabOrderDA.getCustomsDoc(DispatchMasterID)
    .then((val: any) => {
      res.json(val)
    })
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 * /swabOrder/dispatch/getPackingSlipPdf:
 *   post:
 *     summary: Get packing doc
 *     tags: [SwabOrder]
 *     parameters:
 *       - in: query
 *         name: DispatchMasterID
 *         type: integer
 *         description: Dispatch master unique id
 *       - in: query
 *         name: ClientID
 *         type: integer
 *         description: Client unique id
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CustomsDoc'
 *     responses:
 *       200:
 *         description: Get packing document successfully
 *         content:
 *           application/json:
 *             schema:
 *                $ref: '#/components/schemas/CustomsDoc'
 *       500:
 *         description: Internal server error
 */
swab_order_router.post("/dispatch/getPackingSlipPdf", auth, async (req: Request, res: Response) => {
  await SwabOrderDA.getPackSlipPdf(req.body)
    .then((val: any) => {
      res.json(val)
    })
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 * /swabOrder/request/{requestId}/dispatchView:
 *   get:
 *     summary: Get disptch details by RequestID
 *     tags: [SwabOrder]
 *     parameters:
 *       - in: path
 *         name: requestId
 *         type: integer
 *         description: Swab request unique id
 *     responses:
 *       200:
 *         description: Dispatch data found successfully
 *       500:
 *         description: Internal server error
 */
swab_order_router.get("/request/:requestId/dispatchView", auth, async (req: Request, res: Response) => {
  let requestId = req.params.requestId;
  await SwabOrderDA.getDispatchByRequestId(Number(requestId))
    .then((val: any) => {
      res.json(val);
    })
    .catch((err) => res.status(500).send(err));
});
/**
 * @swagger
 *  /swabOrder/dispatch/boxID:
 *   get:
 *     summary: Find all BoxID
 *     tags: [SwabOrder]
 *     responses:
 *       200:
 *         description: Data found successfully
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              $ref: '#/components/schemas/ObjectType'
 *            
 *       500:
 *         description: Internal server error
 */
swab_order_router.get("/dispatch/boxID", auth, async (req: Request, res: Response) => {
  await SwabOrderDA.getBoxID().then((val: any) => res.json(val)).catch((err: any) => res.status(500).send(err));
})

/**
 * @swagger
 * /swabOrder/dispatch/BoxIdByLotnumber/{lotNumber}:
 *   get:
 *     summary: Get BoxID by LotNumber
 *     tags: [SwabOrder]
 *     parameters:
 *       - in: path
 *         name: lotNumber
 *         type: string
 *         description: Swab request unique id
 *     responses:
 *       200:
 *         description: Dispatch data found successfully
 *       500:
 *         description: Internal server error
 */
swab_order_router.post("/dispatch/BoxIdByLotnumber", auth, async (req: Request, res: Response) => {
  let requestId = req.body.lotNumber;
  await SwabOrderDA.getBoxIdByLotnumber(requestId)
    .then((val: any) => {
      res.json(val);
    })
    .catch((err) => res.status(500).send(err));
});

swab_order_router.put("/dispatch/updateInvoiceStatus", auth, async (req: Request, res: Response) => {
  let data = req.body;
  await SwabOrderDA.updateIsInvoiceRaised(data)
    .then((val: any) => {
      res.json(val);
    })
    .catch((err) => res.status(500).send(err));
});
