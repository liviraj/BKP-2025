import express, { NextFunction, Request, Response } from "express";
import { InvoiceDataAccess } from "../data_access/invoice_data_access";
import { auth } from "../middleware/auth";
import { ClientProjects } from "../models/invoice_model";


export const invoice_router = express.Router();

/**
  * @swagger
  * tags:
  *   name: Invoice
  *   description: Invoic managing API
  */

/**
 * @swagger
 * components:
 *   schemas:
 *     Response:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           description: API call status
 *         message:
 *           type: string
 *           description: API call message
 *       example:
 *         success: true
 *         message: Successfull
 * 
 *     ClientProjects:
 *       type: object
 *       properties:
 *         ClientProjectID:
 *           type: integer
 *           description: Unique ID
 *         ClientProjectCode:
 *           type: string
 *           description: Project code 
 *         ClientProjectName:
 *           type: string
 *           description: Project name
 * 
 *     CloseEmail:
 *       type: object
 *       properties:
 *         ClientProjectID:
 *           type: integer
 *           description: Unique ID
 *         DispatchID:
 *           type: integer
 *           description: Dispatch Master unique ID 
 *         LastModifiedBy:
 *           type: integer
 *           description: User unique ID
 *         invoiceNumber:
 *           type: integer
 *           description: Invoice number
 *         ClientID:
 *           type: integer
 *           description: Client unique ID 
 *         SwabUOM:
 *           type: string
 *           description: User unique ID 
 * 
 *  
 *     EmailInformation:
 *       type: object
 *       properties:
 *         DispatchID:
 *           type: integer
 *           format: int32
 *           description: Dispatch Master Unique ID
 *         userId:
 *           type: integer
 *           format: int32
 *           description: User unique ID
 *         invoiceNumber:
 *           type: integer
 *           format: int32
 *           description: US Invoice Number
 *         clientId:
 *           type: integer
 *           format: int32
 *           description: Client Unique ID       
 *         From:
 *           type: string
 *           description: From email address
 *         To:
 *           type: array
 *           items:
 *             type: string        
 *           description: To email address
 *         CC:
 *           type: array
 *           items:
 *             type: string
 *           description: CC email address
 *         BCC:
 *           type: array
 *           items:
 *             type: string
 *           description: BCC email address
 *         Subject:
 *           type: string
 *           description: Email subject
 *         Message:
 *           type: string
 *           description: Email message
 * 
 *     Invoice:
 *       type: object
 *       properties:
 *         invoiceDetails: 
 *           type: object
 *           properties:
 *             ClientID:
 *               type: integer
 *               description: Unique ID
 *             ClientProjectID:
 *               type: integer
 *               description: Unique ID
 *             PoNumber:
 *               type: string
 *               description: PO Number 
 *             SwabID:
 *               type: integer
 *               description: Swab type ID
 *             DispatchQty:
 *               type: integer
 *               description: Dispatch quantity
 *             SwabCost:
 *               type: string
 *               description: Swab cost
 *             ShipmentCharges:
 *               type: string
 *               description: Shipment and Handling Charges
 *             LastModifiedBy: 
 *               type: integer
 *               format: int32
 *               description: UserID
 *             SwabUOM:
 *               type: string
 *               description: Swab type
 *             DispatchMasterID:
 *               type: integer
 *               format: int32
 *               description: Dispatch Master Id
 *         shipmentDetail: 
 *            type: object
 *            properties:
 *              ClientShipmentAutoID:
 *                type: integer
 *                format: int32
 *                description: Swab reqeust shipping unique id
 *              ShippingAddress1: 
 *                type: string
 *                description: Address detail 1
 *              Address2: 
 *                type: string
 *                description: Address detail 2
 *              City: 
 *                type: string
 *                description: City name
 *              State: 
 *                type: string
 *                description: State name
 *              Zip: 
 *                type: string
 *                description: Zip code
 *              CountryID: 
 *                type: string
 *                description: Country id
 *              Notes: 
 *                type: string
 *                description: Notes text
 *              RequestID: 
 *                type: integer
 *                description: Swab request unique ID
 *              ClientID:
 *                type: integer
 *                description: Client unique ID
 *              LastModifiedBy: 
 *                type: integer
 *                format: int32
 *                description: UserID
 */

/**
 * @swagger
 * /invoice/clientProjects/{ClientID}:
 *   get:
 *     summary: Returns the list of client projects
 *     tags: [Invoice]
 *     parameters:
 *       - in: path
 *         name: ClientID
 *         schema:
 *           type: integer
 *         required: true
 *         description: Client unique id
 *     responses:
 *       200:
 *         description: The list of client projects
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/ClientProjects'
 */
invoice_router.get("/clientProjects/:ClientID", auth, async (req: Request, res: Response) => {
  let ClientID = req.params.ClientID;
  await InvoiceDataAccess.getClientProjectsByClientID(Number(ClientID))
    .then((val: ClientProjects[]) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 * /invoice:
 *   post:
 *     summary: Create invoice doc
 *     tags: [Invoice]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Invoice'
 *     responses:
 *       200:
 *         description: Invoice created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Response'
 *       500:
 *         description: Internal server error
 */
invoice_router.post("/", auth, async (req: Request, res: Response) => {
  let requesData = req.body;
  await InvoiceDataAccess.createInvoice(requesData)
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 * /invoice/emailInfo/{clientId}/{invoiceNo}:
 *   get:
 *     summary: Get client email information
 *     tags: [Invoice]
 *     parameters:
 *       - in: path
 *         name: clientId
 *         schema:
 *           type: integer
 *         required: true
 *         description: client unique id
 *       - in: path
 *         name: invoiceNo
 *         schema:
 *           type: integer
 *         required: true
 *         description: Invoice Number
 *     responses:
 *       200:
 *         description: Email info found successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/EmailInformation'
 *       500:
 *         description: Internal server error
 */
invoice_router.get("/emailInfo/:clientId/:invoiceNo", auth, async (req: Request, res: Response) => {
  let clientId: number = Number(req.params.clientId);
  let invoiceNo: number = Number(req.params.invoiceNo);

  await InvoiceDataAccess.getEmailInfoByClientID(clientId, invoiceNo)
    .then((val: any) => res.json(val))
    .catch((err: any) => res.status(500).send(err));
});

/**
 * @swagger
 * /invoice/sendEmail:
 *   post:
 *     summary: Get client email information
 *     tags: [Invoice]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/EmailInformation'
 *     responses:
 *       200:
 *         description: Email sent successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Response'
 *       500:
 *         description: Internal server error
 */
invoice_router.post("/sendEmail", auth, async (req: Request, res: Response) => {
  let requesData = req.body;

  await InvoiceDataAccess.sendInvoiceEmail(requesData)
    .then((val: any) => res.json(val))
    .catch((err: any) => res.status(500).send(err));
});

/**
 * @swagger
 * /invoice/closeEmail/{invoiceNo}/{isEMailSend}:
 *   post:
 *     summary: Close email/revert invoice detail
 *     tags: [Invoice]
 *     parameters:
 *       - in: path
 *         name: invoiceNo
 *         schema:
 *           type: integer
 *         description: Invoice number
 *       - in: path
 *         name: isEMailSend
 *         schema:
 *           type: boolean
 *         description: Email send status
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CloseEmail' 
 *     responses:
 *       200:
 *         description: Reverted invoice info successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: string
 *               example: Reverted Successfully
 *       500:
 *         description: Internal server error
 */
invoice_router.post("/closeEmail/:invoiceNo/:isEMailSend", auth, async (req: Request, res: Response) => {
  let invoiceNo = Number(req.params.invoiceNo);
  let emailSendStatus: boolean;
  if (req.params.isEMailSend == 'true') {
    emailSendStatus = true;
  } else {
    emailSendStatus = false;
  }

  let requestData = req.body;

  await InvoiceDataAccess.closeEmail(invoiceNo, emailSendStatus, requestData)
    .then((val: any) => res.json(val))
    .catch((err: any) => res.status(500).send(err));
});

/**
 * @swagger
 * /invoice/ClientAllAddress/{clientID}:
 *   get:
 *     summary: Get client email information
 *     tags: [clientID]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/invoice/ClientAllAddress'
 *     responses:
 *       200:
 *         description: Address
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Response'
 *       500:
 *         description: Internal server error
 */
invoice_router.get("/ClientAllAddress/:clientId", auth, async (req: Request, res: Response) => {
  await InvoiceDataAccess.getClientAddress(Number(req.params.clientId))
    .then((val: any) => res.json(val))
    .catch((err: any) => res.status(500).send(err));
});


/**
 * @swagger
 * /invoice/refreshInvoiceDetails/{dispatchMasterId}:
 *   get:
 *     summary: Get dispatch Master details information
 *     tags: [dispatchMasterId]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/invoice/refreshInvoiceDetails'
 *     responses:
 *       200:
 *         description: Address
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Response'
 *       500:
 *         description: Internal server error
 */
invoice_router.get("/refreshInvoiceDetails/:dispatchMasterId", auth, async (req: Request, res: Response) => {
  await InvoiceDataAccess.refreshInvoiceDetails(Number(req.params.dispatchMasterId))
    .then((val: any) => val.success ? res.json(val) : res.status(422).json(val))
    .catch((err: any) => res.status(500).send(err));
});





