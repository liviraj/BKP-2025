import express, { Request, Response } from "express";
import { InventoryDA } from "../data_access/inventory_data_access";
import { auth } from "../middleware/auth";

export const inventory_router = express.Router();
/**
 * @swagger
 * components:
 *   schemas:
 *     ObjectType:
 *       type: object 
 *       properties:
 *         type:
 *           type: string
 *           description: Request Type
 *       example:
 *         type: object
 */
/**
  * @swagger
  * tags:
  *   name: Inventory
  *   description: Inventory managing API
  */

/**
* @swagger
* /inventory/swabfilter:
 *   get:
 *     summary:Filter swab Inventory
 *     tags: [Inventory]
 *     parameters:
 *       - in: query
 *         name: FromDate
 *         schema:
 *           type: string
 *           format: date
 *         description: From date
 *       - in: query
 *         name: ToDate
 *         schema:
 *           type: string
 *           format: date
 *         description: To date
 *       - in: query
 *         name: VendorID
 *         schema:
 *           type: integer
 *         description: Vendor ID
 *       - in: query
 *         name: LotNumber
 *         schema:
 *           type: string
 *         description: Lot Number
 *     responses:
 *       200:
 *         description: swab Inventory Details
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/ObjectType'
 *       500:
 *         description: Internal server error
 */

inventory_router.get("/swabinventory/filter", auth, async (req: Request, res: Response) => {
    const filters = req.query;
    await InventoryDA.getSwabInventoryData(filters)
      .then((val: any) => res.json(val))
      .catch((err) => res.status(500).send(err));
  });
  
/**
 * @swagger
 *  /inventory/filter/lotNumber:
 *   get:
 *     summary: Find all lotNumber
 *     tags: [Inventory]
 *     responses:
 *       200:
 *         description: Data found successfully
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              $ref: '#/components/schemas/ObjectType'
 *            
 *       500:
 *         description: Internal server error
 */
  inventory_router.get("/filter/lotNumber", auth, async (req: Request, res: Response) => {
    await InventoryDA.FilterLotNumber()
      .then((val: any) => res.json(val))
      .catch((err) => res.status(500).send(err));
  });
  
/**
 * @swagger
 *  /inventory/filter/vcNumber:
 *   get:
 *     summary: Find all Vendor/Customer Name
 *     tags: [Inventory]
 *     responses:
 *       200:
 *         description: Data found successfully
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              $ref: '#/components/schemas/ObjectType'
 *            
 *       500:
 *         description: Internal server error
 */
 inventory_router.get("/filter/vcNumber", auth, async (req: Request, res: Response) => {
  await InventoryDA.getFilteredVCNumber()
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});


/**
 * @swagger
 *  /inventory/filter/PONumber:
 *   get:
 *     summary: Find all PONumber
 *     tags: [Inventory]
 *     responses:
 *       200:
 *         description: Data found successfully
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              $ref: '#/components/schemas/ObjectType'
 *            
 *       500:
 *         description: Internal server error
 */
 inventory_router.get("/filter/PONumber", auth, async (req: Request, res: Response) => {
  await InventoryDA.getFilteredPONumber()
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
* /inventory/boxfilter:
 *   get:
 *     summary:Filter Box Inventory
 *     tags: [Inventory]
 *     parameters:
 *       - in: query
 *         name: FromDate
 *         schema:
 *           type: string
 *           format: date
 *         description: From date
 *       - in: query
 *         name: ToDate
 *         schema:
 *           type: string
 *           format: date
 *         description: To date
 *       - in: query
 *         name: BoxID
 *         schema:
 *           type: integer
 *         description: Box ID
 *       - in: query
 *         name: LotNumber
 *         schema:
 *           type: string
 *         description: Lot Number
 *     responses:
 *       200:
 *         description: box Inventory Details
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/ObjectType'
 *       500:
 *         description: Internal server error
 */

inventory_router.get("/boxinventory/filter", auth, async (req: Request, res: Response) => {
    const filters = req.query;
    await InventoryDA.getBoxInventoryData(filters)
      .then((val: any) => res.json(val))
      .catch((err) => res.status(500).send(err));
  });

  
/**
 * @swagger
 *  /inventory/filter/BoxID:
 *   get:
 *     summary: Find all BoxID
 *     tags: [Inventory]
 *     responses:
 *       200:
 *         description: Data found successfully
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              $ref: '#/components/schemas/ObjectType'
 *            
 *       500:
 *         description: Internal server error
 */
 inventory_router.get("/filter/BoxID", auth, async (req: Request, res: Response) => {
  await InventoryDA.getFilteredBoxID()
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 *  /inventory/validation/BoxID:
 *   get:
 *     summary: Find all BoxID
 *     tags: [Inventory]
 *     responses:
 *       200:
 *         description: Data found successfully
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              $ref: '#/components/schemas/ObjectType'
 *            
 *       500:
 *         description: Internal server error
 */
inventory_router.get("/validation/BoxID", auth, async (req: Request, res: Response) => {
  await InventoryDA.getBoxQty()
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});


/**
 * @swagger
* /inventory/lotinventory/filter:
 *   get:
 *     summary:Filter Lot Inventory
 *     tags: [Inventory]
 *     parameters:
 *       - in: query
 *         name: FromDate
 *         schema:
 *           type: string
 *           format: date
 *         description: From date
 *       - in: query
 *         name: ToDate
 *         schema:
 *           type: string
 *           format: date
 *         description: To date
 *       - in: query
 *         name: BoxID
 *         schema:
 *           type: integer
 *         description: Box ID
 *       - in: query
 *         name: LotNumber
 *         schema:
 *           type: string
 *         description: Lot Number
 *     responses:
 *       200:
 *         description: Lot Inventory Details
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/ObjectType'
 *       500:
 *         description: Internal server error
 */

inventory_router.get("/lotinventory/filter", auth, async (req: Request, res: Response) => {
  const filters = req.query;
  await InventoryDA.getLotInventoryData(filters)
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});