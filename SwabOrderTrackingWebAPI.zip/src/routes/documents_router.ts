import express, { NextFunction, Request, Response } from "express";
import { auth } from "../middleware/auth";
import { DocumentsDA } from "../data_access/documents_data_access";
import { DocumentTypes as DocumentType } from '@prisma/client';

export const documents_router = express.Router();

/**
  * @swagger
  * tags:
  *   name: Documents
  *   description: Documents managing API
  */

/**
 * @swagger
 * components:
 *   schemas:
 *     DocumentType:
 *       type: object
 *       properties:
 *         DocumentTypeID:
 *           type: integer
 *           description: Document type unique code 
 *         DocumentName:
 *           type: string
 *           description: Document type value
 *       example:
 *         DocumentTypeID: 1
 *         DocumentName: PDF
 *     
 *     Document:
 *       type: object
 *       properties:
 *         RefDocID:
 *           type: integer
 *           description: Document unique code 
 *         RefType:
 *           type: string
 *           description: Document ref type
 *         RefTypeID:
 *           type: integer
 *           description: Ref type id 
 *         DocumentTypeID:
 *           type: integer
 *           description: Document type id
 *         DocumentContent:
 *           type: string
 *           description: Document in binary format
 *         RequestID:
 *           type: integer
 *           description: Swab request id
 */
/**
 * @swagger
 * /document/types:
 *   get:
 *     summary: Returns the list of all document types
 *     tags: [Documents]
 *     responses:
 *       200:
 *         description: The list of the file types
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/DocumentType'
 */
documents_router.get("/types", auth, async (req: Request, res: Response) => {
  await DocumentsDA.getFileTypes()
    .then((val: DocumentType[]) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 * /docUpload/upload:
 *   post:
 *     summary: Upload documents
 *     tags: [Documents]
 *     consumes:
 *       - multipart/form-data
 *     parameters:
 *       - in: formData
 *         name: files
 *         type: file
 *         description: The file to upload.
 *       - in: formData
 *         name: DocumentTypeID
 *         type: integer
 *         description: Doc type value.
 *       - in: formData
 *         name: RefType
 *         schema:
 *           type: string
 *           enum: [Request,Dispatch]
 *         description: Reference doc type Request/Dispatch.
 *       - in: formData
 *         name: RefTypeID
 *         type: integer
 *         description: Referance type unique ID RequestID / DispatchMasterID.
 *     responses:
 *       200:
 *         description: Documents upload
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Document'
 */
documents_router.post("/upload", auth, async (req: Request, res: Response) => {
  await DocumentsDA.documentUplaod(req)
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 * /document/{RefDocID}:
 *   delete:
 *     summary: Delete documents by refdoc ID
 *     tags: [Documents]
 *     consumes:
 *       - multipart/form-data
 *     parameters:
 *       - in: path
 *         name: RefDocID
 *         required: true
 *         type: integer
 *         description: Referance document unique id.
 *     responses:
 *       200:
 *         description: Document deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *                 $ref: '#/components/schemas/Document'
 */
 documents_router.delete("/:RefDocID", auth, async (req: Request, res: Response) => {
  let docId = req.params.RefDocID;
  await DocumentsDA.deleteDocById(docId)
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 *  * /document/delete/:{docs}
 *   delete:
 *     summary: Delete documents by refdoc ID's
 *     tags: [Documents]
 *     consumes:
 *       - multipart/form-data
 *     parameters:
 *       - in: path
 *         name: RefDocID
 *         required: true
 *         type: integer
 *         description: Referance document unique id.
 *     responses:
 *       200:
 *         description: Document deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *                 $ref: '#/components/schemas/Document'
 */
documents_router.delete("/delete/:docs", auth, async (req: Request, res: Response) => {
  let docs = req.params.docs.split(",");
  await DocumentsDA.deleteDocuments(docs)
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});
/**
 * @swagger
 * /document/{RefTypeID}/{RefType}:
 *   get:
 *     summary: Returns the list of all documents by RefTypeID
 *     tags: [Documents]
 *     parameters:
 *       - name: RefTypeID
 *         in: path
 *         type: integer
 *         required: true
 *         description: Swab request unique key
 *       - in: path
 *         name: RefType
 *         required: true
 *         schema:
 *           type: string
 *           enum: [Request,Dispatch,Invoice,Dispatch]
 *         description: Reference doc type Request/Dispatch.
 *     responses:
 *       200:
 *         description: The list of the Documents
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Document'
 */
documents_router.get("/:RefDocID", auth, async (req: Request, res: Response) => {
  let RefDocID = req.params.RefDocID;
  await DocumentsDA.findDocByRefDocID(RefDocID)
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});
