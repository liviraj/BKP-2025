import express, { Request, Response } from "express";
import { PurchaseDA } from "../data_access/purchase_data_access";
import { auth } from "../middleware/auth";

export const purchase_router = express.Router();

/**
 * @swagger
 * components:
 *   schemas:
 *     ObjectType:
 *       type: object 
 *       properties:
 *         type:
 *           type: string
 *           description: Request Type
 *       example:
 *         type: object
 */
/**
  * @swagger
  * tags:
  *   name: Purchase
  *   description: SwabOrder managing API
  */

/**
 * @swagger
 * /purchase:
 *   post:
 *     summary: Create the purchase
 *     tags: [Purchase]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ObjectType'
 *     responses:
 *       200:
 *         description: Purchase created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ObjectType'
 *       500:
 *         description: Internal server error
 */
purchase_router.post("/", auth, async (req: Request, res: Response) => {
    let purchase:any = req.body;
    await PurchaseDA.addPurchase(purchase)
      .then((val: any) => res.json(val))
      .catch((err) => res.status(500).send(err));
  });

//   /**
//  * @swagger
//  * /purchase:
//  *   put:
//  *     summary: Update the purchase
//  *     tags: [Purchase]
//  *     requestBody:
//  *       required: true
//  *       content:
//  *         application/json:
//  *           schema:
//  *             $ref: '#/components/schemas/ObjectType'
//  *     responses:
//  *       200:
//  *         description: Purchase updated successfully
//  *         content:
//  *           application/json:
//  *             schema:
//  *               $ref: '#/components/schemas/ObjectType'
//  *       500:
//  *         description: Internal server error
//  */
// purchase_router.put("/", auth, async (req: Request, res: Response) => {
//   let purchase:any = req.body;
//   await PurchaseDA.updatePurchase(purchase)
//     .then((val: any) => res.json(val))
//     .catch((err) => res.status(500).send(err));
// });
  /**
 * @swagger
 * /purchase:
 *   get:
 *     summary: Find all purchase
 *     tags: [Purchase]
 *     responses:
 *       200:
 *         description: Data found successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ObjectType'
 *       500:
 *         description: Internal server error
 */
purchase_router.get("/", auth, async (req: Request, res: Response) => {
    await PurchaseDA.getAllPurchase()
      .then((val: any) => res.json(val))
      .catch((err) => res.status(500).send(err));
  });

   /**
 * @swagger
 * /purchase/swabInventory:
 *   get:
 *     summary: Find all swab inventory
 *     tags: [Purchase]
 *     responses:
 *       200:
 *         description: Data found successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ObjectType'
 *       500:
 *         description: Internal server error
 */
purchase_router.get("/swabInventory", auth, async (req: Request, res: Response) => {
    await PurchaseDA.getAllSwabInventory()
      .then((val: any) => res.json(val))
      .catch((err) => res.status(500).send(err));
  });

   /**
 * @swagger
 * /purchase/vendors:
 *   get:
 *     summary: Find all vendors
 *     tags: [Purchase]
 *     responses:
 *       200:
 *         description: Data found successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ObjectType'
 *       500:
 *         description: Internal server error
 */
purchase_router.get("/vendors", auth, async (req: Request, res: Response) => {
    await PurchaseDA.getAllVendors()
      .then((val: any) => res.json(val))
      .catch((err) => res.status(500).send(err));
  });

    /**
 * @swagger
 * /purchase/filterVendors:
 *   get:
 *     summary: Find all vendors
 *     tags: [Purchase]
 *     responses:
 *       200:
 *         description: Data found successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ObjectType'
 *       500:
 *         description: Internal server error
 */
purchase_router.get("/filterVendors", auth, async (req: Request, res: Response) => {
    await PurchaseDA.getFilterVendors()
      .then((val: any) => res.json(val))
      .catch((err) => res.status(500).send(err));
  });

  /**
 * @swagger
 * /purchase/filter:
 *   get:
 *     summary: Filter Purchase
 *     tags: [Purchase]
 *     parameters:
 *       - in: query
 *         name: DispatchPeriod
 *         schema:
 *           type: string
 *           enum: [All, Custom, Last 30 Days, Last 3 Months, Last 6 Months, Last 7 Days, This year, Today, Today and Yesterday, Yesterday]
 *         description: Dispatch Period
 *       - in: query
 *         name: FromDate
 *         schema:
 *           type: string
 *           format: date
 *         description: From date
 *       - in: query
 *         name: ToDate
 *         schema:
 *           type: string
 *           format: date
 *         description: To date
 *       - in: query
 *         name: VendorID
 *         schema:
 *           type: integer
 *         description: Client unique id
 *     responses:
 *       200:
 *         description:  Purchase Details
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/ObjectType'
 *       500:
 *         description: Internal server error
 */
   purchase_router.get("/filter", auth, async (req: Request, res: Response) => {
    const filters = req.query;
    await PurchaseDA.filterPurchase(filters)
      .then((val: any) => res.json(val))
      .catch((err) => res.status(500).send(err));
  });



