import express, { Request, Response } from "express";
import { auth } from "../middleware/auth";
import { Client, DeliveryStatus, PaymentStatus } from "../models/tracking_system_model";
import { TrackingSystemService } from "../service/tracking_system_service";
import { TrackingSystemDA } from "../data_access/tracking_system_data_access";

export const tracking_system_router = express.Router();


/**
 * @swagger
 * components:
 *   schemas:
 *     DeliveryStatus:
 *       type: object
 *       required:
 *         - DeliveryMasteID
 *         - DeliveryStatus
 *       properties:
 *         DeliveryMasteID:
 *           type: integer
 *           description: Delivery status id 
 *         DeliveryStatus:
 *           type: string
 *           description: Delievery status value
 *       example:
 *         DeliveryMasteID: 1
 *         DeliveryStatus: inprogress
 *     
 *     PaymentStatus:
 *       type: object
 *       required:
 *         - PaymentStatusID
 *         - PaymentStatus
 *       properties:
 *         PaymentStatusID:
 *           type: integer
 *           description: Payment status id 
 *         PaymentStatus:
 *           type: string
 *           description: Payment status value
 *       example:
 *         PaymentStatusID: 1
 *         PaymentStatus: Fully Received 
 *          
 *     Client:
 *       type: object
 *       properties:
 *         ClientID:
 *           type: integer
 *           description: Client unique code 
 *         ClientName:
 *           type: string
 *           description: Client name
 *         Address1:
 *           type: string
 *           description: Address1
 *         Address2:
 *           type: string
 *           description: Address2
 *         City:
 *           type: string
 *           description: City name
 *         State:
 *           type: string
 *           description: State name
 *         PostalCode:
 *           type: string
 *           description: Postalcode
 *         Country:
 *           type: string
 *           description: Country name
 *         ContactPerson:
 *           type: string
 *           description: Contact person name
 *         ContactNumber1:
 *           type: string
 *           description: Contact Number1
 *         ContactNumber2:
 *           type: string
 *           description: Contact Number2
 */
/**
  * @swagger
  * tags:
  *   name: TrackingSystem
  *   description: TrackingSystem managing API
  */
/**
 * @swagger
 * /trackingSystem/deleiveryStatusList:
 *   get:
 *     summary: Returns the list of all delievery status
 *     tags: [TrackingSystem]
 *     responses:
 *       200:
 *         description: The list of the delivery status
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/DeliveryStatus'
 */
tracking_system_router.get("/deleiveryStatusList", auth, async (req: Request, res: Response) => {
    await TrackingSystemService.getDeliveryStatusList()
        .then((val: DeliveryStatus[]) => res.json(val))
        .catch((err) => res.status(500).send(err));
});

/**
/**
 * @swagger
 * /trackingSystem/paymentStatusList:
 *   get:
 *     summary: Returns the list of all payment status
 *     tags: [TrackingSystem]
 *     responses:
 *       200:
 *         description: The list of the payment status
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/PaymentStatus'
 */
tracking_system_router.get("/paymentStatusList", auth, async (req: Request, res: Response) => {
  await TrackingSystemService.getPaymentStatuses()
      .then((val: PaymentStatus[]) => res.json(val))
      .catch((err) => res.status(500).send(err));
});

/**
/**
 * @swagger
 * /trackingSystem/clients:
 *   get:
 *     summary: Returns the list of all clients
 *     tags: [TrackingSystem]
 *     responses:
 *       200:
 *         description: The list of the clients
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Client'
 */
 tracking_system_router.get("/clients", auth, async (req: Request, res: Response) => {
  await TrackingSystemService.getClientNameList()
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
/**
 * @swagger
 * /trackingSystem/clients/{ClientID}:
 *   get:
 *     summary: Returns the clients
 *     tags: [TrackingSystem]
 *     parameters:
 *       - name: ClientID
 *         in: path
 *         type: integer
 *         required: true
 *         description: ClientId 
 *     responses:
 *       200:
 *         description: Clients details
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Client'
 */
 tracking_system_router.get("/clients/:ClientID", auth, async (req: Request, res: Response) => {
  let ClientID = req.params.ClientID;
  await TrackingSystemDA.getClientById(ClientID)
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
/**
 * @swagger
 * /trackingSystem/getDispatchClients:
 *   get:
 *     summary: Returns the list of all clients for dispatch
 *     tags: [TrackingSystem]
 *     responses:
 *       200:
 *         description: The list of the clients
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Client'
 */
 tracking_system_router.get("/getDispatchClients", auth, async (req: Request, res: Response) => {
  await TrackingSystemDA.getDispatchClients()
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
/**
 * @swagger
 * /trackingSystem/getOnlyDispatchDidClients:
 *   get:
 *     summary: Returns the list of all clients for only dispatch done
 *     tags: [TrackingSystem]
 *     responses:
 *       200:
 *         description: The list of dispatch did clients
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Client'
 */
 tracking_system_router.get("/getOnlyDispatchDidClients", auth, async (req: Request, res: Response) => {
  await TrackingSystemDA.getOnlyDispatchDidClients()
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
/**
 * @swagger
 * /trackingSystem/getOnlyRequestDidClients:
 *   get:
 *     summary: Returns the list of all clients for only request done.
 *     tags: [TrackingSystem]
 *     responses:
 *       200:
 *         description: The list of request did clients
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Client'
 */
 tracking_system_router.get("/getOnlyRequestDidClients", auth, async (req: Request, res: Response) => {
  await TrackingSystemDA.getOnlyRequestDidClients()
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

tracking_system_router.get("/getTrackingNumbers", async (req: Request, res: Response) => {
  await TrackingSystemDA.getAllTrackingNumber()
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

tracking_system_router.put("/updateTrackingStatus", async (req: Request, res: Response) => {
  let requestData: any = req.body;
  await TrackingSystemDA.updateTrackingStatus(requestData)
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});


