import express, { NextFunction, Request, Response } from "express";
import { UsersService } from "../service/users_service";
import { auth } from "../middleware/auth";
import { UserName } from "../models/users_model";
import { UsersDA } from "../data_access/users_data_access";
import ResponseModel from "../common/response_model";

export const users_router = express.Router();

/**
 * @swagger
 * components:
 *   schemas:
 *     Login:
 *       type: object
 *       required:
 *         - email
 *       properties:
 *         email:
 *           type: string
 *           description: User email address
 *       example:
 *         email: example@histogenetics.com
 * 
 *     User:
 *       type: object
 *       properties:
 *         UserID:
 *            type: integer
 *            description: User unique id
 *         RoleID:
 *            type: integer
 *            description: User role id 
 *         FirstName:
 *            type: string
 *            description: User first name
 *         LastName:
 *            type: string
 *            description: User last name
 *         RoleName:
 *            type: string
 *            description: User role name
 *         EmailAddress:
 *           type: string
 *           description: User email address 
 * */

/**
  * @swagger
  * tags:
  *   name: Users
  *   description: User managing API
  */

/**
 * @swagger
 * /users/login:
 *   post:
 *     summary: Login using mail
 *     tags: [Users]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Login'
 *     responses:
 *       200:
 *         description: User login successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Login'
 *       500:
 *         description: Internal server error
 */
users_router.post("/login", auth, async (req: Request, res: Response) => {
  let json: any = req.body;
  let email = json.email;
  await UsersService.GetUserInfo(email)
    .then((val: String) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

/**
 * @swagger
 * /users/{EmailAddress}:
 *   get:
 *     summary: Get user by email address
 *     tags: [Users]
 *     parameters:
 *       - in: path
 *         name: EmailAddress
 *         schema:
 *           type: string
 *         required: true
 *         description: User email address
 *     responses:
 *       200:
 *         description: User get successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
 *       500:
 *         description: Internal server error
 */
users_router.get("/:EmailAddress", auth, async (req: Request, res: Response) => {
  let EmailAddress = req.params.EmailAddress;
  await UsersDA.GetUserByEmailAddress(EmailAddress)
    .then((val: any) => res.json(val))
    .catch((err) => res.status(500).send(err));
});

