import { format } from "path";
import { Message } from "../common/constants";
import ResponseModel from "../common/response_model";
import { SwabInventory } from "../models/purchase_model";

const { PrismaClient } = require('@prisma/client');
const prismaSwab = new PrismaClient();
const moment = require('moment');

export module PurchaseDA {

    const PURCHASE_REF_TYPE: string = "Purchase"

    export async function addPurchase(purchaseData: any): Promise<any> {
        try {
            let convertPurchaseDate = moment(purchaseData.PurchaseDate); 
            //BoxID Validation
            let ValidationData = purchaseData.purchaseDetails;
            let filteredValue = ValidationData.map(function (item: any) { return item.BoxID });
            let val = filteredValue.filter((item: any, index: any) => filteredValue.indexOf(item) != index);
            if (val.length === 0) {
                for (let i = 0; i < ValidationData.length; i++) {
                    let swabDetails = await prismaSwab.SwabPurchaseDetails.findFirst({
                        where: {
                            BoxID: ValidationData[i].BoxID
                        }
                    })
                    if (swabDetails !== null || swabDetails?.BoxID) {
                        return new ResponseModel(false, Message(swabDetails.BoxID).BoxIDValid);
                    }
                }
            } else {
                return new ResponseModel(false, `BoxID already exists`);
            }

            let purchase: any = await prismaSwab.swabPurchaseMaster.create({
                data: {
                    VendorID: purchaseData.VendorID,
                    PurchaseDate: convertPurchaseDate.format(),
                    PONumber: purchaseData.PONumber,
                    BoxQty: purchaseData.totalBoxes,
                    Comments: purchaseData.Comments,
                    LastModifiedBy: purchaseData.LastModifiedBy
                }
            });
            await createInventoryLedger(purchase);
            if (purchase != null && purchase != undefined && purchase.PurchaseMasterID > 0) {
                for (let i = 0; i < purchaseData.purchaseDetails.length; i++) {
                    let expDate = moment(purchaseData.purchaseDetails[i].ExpiryDate).format();

                    let SwabPurchaseDetailsList:any = await prismaSwab.SwabPurchaseDetails.create({
                        data: {
                            PurchaseMasterID: purchase.PurchaseMasterID,
                            BoxID: purchaseData.purchaseDetails[i].BoxID,
                            NumberOfSwabs: purchaseData.purchaseDetails[i].NumberOfSwabs,
                            LotNumber: purchaseData.purchaseDetails[i].LotNumber,
                            ExpiryDate: expDate,
                            LastModifiedBy: purchaseData.purchaseDetails[i].LastModifiedBy,
                        }
                    });                    
                    await createLotBalanceUpdate(purchaseData.purchaseDetails[i], SwabPurchaseDetailsList);
                    await createBoxbalanceUpdated(purchaseData.purchaseDetails[i], SwabPurchaseDetailsList);
                }                
                return new ResponseModel(true, "Saved Successfully", { PurchaseMasterID: purchase.PurchaseMasterID })
            } else {
                return new ResponseModel(false, "Creation Failed");
            }
        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal Server Error", error);
        }
    }

    export async function boxIDValidation(purchaseData:any) {
        let ValidationData = purchaseData.purchaseDetails;
        let filteredValue = ValidationData.map(function(item:any){ return item.BoxID });
        let val = filteredValue.filter((item:any, index:any) => filteredValue.indexOf(item) != index);
        if(val.length === 0 ){
            for (let i = 0; i < ValidationData.length; i++) {
                let swabDetails = await prismaSwab.SwabPurchaseDetails.findFirst({
                    where:{
                        BoxID:ValidationData[i].BoxID
                    }
                })
                if(swabDetails !== null || swabDetails !== undefined){
                    return new ResponseModel(false, Message(swabDetails.BoxID).BoxIDValid);
                }
            } 
        }else{
            return new ResponseModel(false, `BoxID already exists`);
        }
    }

    export async function updatePurchase(purchaseMaster: any): Promise<any> {
        try {
            let convertPurchaseDate = moment(purchaseMaster.PurchaseDate);

            // let purchaseAudit = await prismaSwab.swabPurchaseMaster.findUnique({
            //     where: {
            //         PurchaseMasterID: purchaseMaster.PurchaseMasterID
            //     }
            // });

            // let convertPurchaseDateAudit = moment(purchaseAudit.PurchaseDate);
            // let convertLastModifiedAudit = moment(purchaseAudit.LastModifiedOn);

            // let auditMaster = await prismaSwab.swabPurchaseMasterAudit.create({
            //     data: {
            //         VendorID: purchaseAudit.VendorID,
            //         PurchaseDate: convertPurchaseDateAudit.format(),
            //         PONumber: purchaseAudit.PONumber,
            //         BoxQty: purchaseAudit.BoxQty,
            //         Comments: purchaseAudit.Comments,
            //         LastModifiedBy: purchaseAudit.LastModifiedBy,
            //         LastModifiedOn: convertLastModifiedAudit.format()
            //     }
            // });

            let purchase: any = await prismaSwab.swabPurchaseMaster.update({
                where: {
                    PurchaseMasterID: purchaseMaster.PurchaseMasterID
                },
                data: {
                    VendorID: purchaseMaster.VendorID,
                    PurchaseDate: convertPurchaseDate.format(),
                    PONumber: purchaseMaster.PONumber,
                    BoxQty: purchaseMaster.BoxQty,
                    Comments: purchaseMaster.Comments,
                    LastModifiedBy: purchaseMaster.LastModifiedBy
                }
            });


            if (purchase != null && purchase != undefined && purchase.PurchaseMasterID > 0) {
                for (let i = 0; i < purchaseMaster.purchaseDetails.length; i++) {
                    let updateAvailableBoxes: number;
                    let updateAvailableSwabs: number;
                    let convertExpiryDate = moment(purchaseMaster.purchaseDetails[i].convertExpiryDate);

                    // let purchaseDetailAudit = await prismaSwab.swabPurchaseDetails.findUnique({
                    //     where: {
                    //         PurchaseDetailID: purchaseMaster.purchaseDetails[i].PurchaseDetailID
                    //     }
                    // });

                    // await prismaSwab.swabPurchaseDetails.create({
                    //     data: purchaseDetailAudit
                    // });

                    let swabInventory: any = await prismaSwab.swabInventory.findFirst({
                        where: {
                            LotNumber: purchaseMaster.purchaseDetails[i].LotNumber
                        }
                    });

                    if (purchaseMaster.purchaseDetails[i].PurchaseDetailID == undefined || purchaseMaster.purchaseDetails[i].PurchaseDetailID == null || purchaseMaster.purchaseDetails[i].PurchaseDetailID == 0) {

                        let purchaseDetails: any = await prismaSwab.swabPurchaseDetails.create({
                            data: {
                                PurchaseMasterID: purchase.PurchaseMasterID,
                                BoxQty: purchaseMaster.purchaseDetails[i].BoxQty,
                                NumberOfSwabs: purchaseMaster.purchaseDetails[i].NumberOfSwabs,
                                LotNumber: purchaseMaster.purchaseDetails[i].LotNumber,
                                ExpiryDate: convertExpiryDate.format(),
                                LastModifiedBy: purchaseMaster.purchaseDetails[i].LastModifiedBy
                            }
                        });

                        if (swabInventory == null || swabInventory == undefined) {
                            //let createSwabInventory: any = await createLotBalanceUpdate(purchaseMaster.purchaseDetails[i]);
                        } else {
                            let updateSwabInventory: any = await prismaSwab.swabInventory.update({
                                where: {
                                    InventoryID: swabInventory.InventoryID
                                },
                                data: {
                                    AvailableBoxes: swabInventory.AvailableBoxes + purchaseMaster.purchaseDetails[i].BoxQty,
                                    AvailableSwabs: swabInventory.AvailableSwabs + purchaseMaster.purchaseDetails[i].NumberOfSwabs
                                }
                            });
                        }

                    } else {
                        let purchaseDetailsInfo = await prismaSwab.swabPurchaseDetails.findUnique({
                            where: {
                                PurchaseDetailID: purchaseMaster.purchaseDetails[i].PurchaseDetailID
                            }
                        });
                        let purchaseDetails: any = await prismaSwab.swabPurchaseDetails.update({
                            where: {
                                PurchaseDetailID: purchaseMaster.purchaseDetails[i].PurchaseDetailID
                            },
                            data: {
                                PurchaseMasterID: purchase.PurchaseMasterID,
                                BoxQty: purchaseMaster.purchaseDetails[i].BoxQty,
                                NumberOfSwabs: purchaseMaster.purchaseDetails[i].NumberOfSwabs,
                                LotNumber: purchaseMaster.purchaseDetails[i].LotNumber,
                                ExpiryDate: convertExpiryDate.format(),
                                LastModifiedBy: purchaseMaster.purchaseDetails[i].LastModifiedBy
                            }
                        });

                        if (purchaseDetailsInfo.BoxQty < purchaseMaster.purchaseDetails[i].BoxQty) {
                            purchaseDetailsInfo.BoxQty = purchaseDetailsInfo.BoxQty + purchaseMaster.purchaseDetails[i].BoxQty - (purchaseMaster.purchaseDetails[i].BoxQty = purchaseDetailsInfo.BoxQty);
                        }
                        if (purchaseDetailsInfo.NumberOfSwabs < purchaseMaster.purchaseDetails[i].NumberOfSwabs) {
                            purchaseDetailsInfo.NumberOfSwabs = purchaseDetailsInfo.NumberOfSwabs + purchaseMaster.purchaseDetails[i].NumberOfSwabs - (purchaseMaster.purchaseDetails[i].NumberOfSwabs = purchaseDetailsInfo.NumberOfSwabs);
                        }
                        updateAvailableBoxes = purchaseDetailsInfo.BoxQty - purchaseMaster.purchaseDetails[i].BoxQty
                        updateAvailableSwabs = purchaseDetailsInfo.NumberOfSwabs - purchaseMaster.purchaseDetails[i].NumberOfSwabs
                        if (swabInventory == null || swabInventory == undefined) {
                            //let createSwabInventory: any = await createLotBalanceUpdate(purchaseMaster.purchaseDetails[i]);
                        } else {
                            let updateSwabInventory: any = await prismaSwab.swabInventory.update({
                                where: {
                                    InventoryID: swabInventory.InventoryID
                                },
                                data: {
                                    AvailableBoxes: swabInventory.AvailableBoxes + updateAvailableBoxes,
                                    AvailableSwabs: swabInventory.AvailableSwabs + updateAvailableSwabs
                                }
                            });
                        }
                    }
                }

                return new ResponseModel(true, "Updated Successfully", { PurchaseMasterID: purchase.PurchaseMasterID })
            } else {
                return new ResponseModel(false, "Updation Failed");
            }
        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal Server Error", error);
        }
    }
    
    export async function getAllPurchase(): Promise<any> {
        try {
            let purchaseList = await prismaSwab.swabPurchaseMaster.findMany({
                select: {
                    PurchaseMasterID: true,
                    PurchaseDate: true,
                    PONumber: true,
                    BoxQty: true,
                    Comments: true,
                    LastModifiedBy: true,
                    Vendors: {
                        select: {
                            VendorID: true,
                            VendorName: true
                        }
                    }
                }
            });

            for (let i = 0; i < purchaseList.length; i++) {
                let documents = await prismaSwab.referenceDocuments.findMany({
                    where: {
                        RefType: {
                            in: ['Purchase_Packing', 'Purchase_Invoice']
                        },
                        RefTypeID: purchaseList[i].PurchaseMasterID
                    },
                    select: {
                        RefDocID: true,
                        DocumentName: true,
                        RefType: true
                    }
                })

                purchaseList[i].documents = documents;
            }
            return new ResponseModel(true, "Record Found", purchaseList);
        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal Server Error", error);
        }
    }

    export async function createBoxbalanceUpdated(swabInventory: any, SwabPurchaseDetails: any) {
        try{
            let purchaseDetail:any = await prismaSwab.SwabPurchaseDetails.findFirst({
                where: {
                    BoxID: swabInventory.BoxID
                }
            })
            let boxBalance:any = await prismaSwab.SwabInventoryBoxBalance.findFirst({
                where: {
                    PurchaseDetailID: purchaseDetail.PurchaseDetailID
                }
            })
            if (boxBalance === null || !boxBalance.PurchaseDetailID || boxBalance === undefined) {
                await prismaSwab.SwabInventoryBoxBalance.create({
                    data: {
                        PurchaseDetailID: SwabPurchaseDetails.PurchaseDetailID,
                        AvailableSwabs: swabInventory.NumberOfSwabs,
                    }
                });
            } 
        }catch(err){
            console.log(err);
        }
    }

    export async function createInventoryLedger(purchaseMaster: any) {
        try {
            await prismaSwab.SwabInventoryLedger.create({
                data: {
                    TransactionDate: purchaseMaster.PurchaseDate,
                    TransactionType: "P",
                    TransactionTypeID: purchaseMaster.PurchaseMasterID
                }
            });
        } catch (err) {
            console.log(err);
        }
    }

    export async function createLotBalanceUpdate(swabInventory: any, purchaseDetail: any) {        
        try {
            let SwabLotBalanceList: any = await prismaSwab.SwabInventoryLotBalance.findFirst({
                where: {
                    LotNumber: swabInventory.LotNumber
                }
            })
            if (SwabLotBalanceList === null|| SwabLotBalanceList === undefined) {
                await prismaSwab.SwabInventoryLotBalance.create({
                    data: {
                        LotNumber: swabInventory.LotNumber,
                        AvailableSwabs: swabInventory.NumberOfSwabs,
                    }
                });         
            } else {
                await prismaSwab.SwabInventoryLotBalance.update({
                    where: {
                        SwabInventoryBalanceID: SwabLotBalanceList.SwabInventoryBalanceID
                    },
                    data: {
                        AvailableSwabs: SwabLotBalanceList.AvailableSwabs + swabInventory.NumberOfSwabs
                    }
                });  
            }
        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal Server Error", error);
        }
    }
    
    export async function getAllSwabInventory(): Promise<any> {
        try {
            let stockhistoryRecords: any = [];
            let lotNumbers = await prismaSwab.SwabInventoryLotBalance.findMany({
                where: {
                    AvailableSwabs: {
                        gt: 0
                    }
                },
                select: {
                    LotNumber: true,
                    AvailableSwabs: true
                }
            });
            if (lotNumbers.length > 0) {
                for (let i = 0; i < lotNumbers.length; i++) {
                    let swabInventoryBoxBalance = await prismaSwab.SwabInventoryBoxBalance.findMany({
                        where: {
                            AvailableSwabs: { gt: 0, },
                            SwabPurchaseDetails: {
                                LotNumber: lotNumbers[i].LotNumber
                            }
                        },
                        select:{
                            AvailableSwabs: true,
                            PurchaseDetailID: true,
                            SwabPurchaseDetails: true
                        }
                    });
                    if (swabInventoryBoxBalance.length > 0) {
                        stockhistoryRecords = [...stockhistoryRecords, { LotNumber: lotNumbers[i].LotNumber, AvailableBoxes: swabInventoryBoxBalance.length, AvailableSwabs: lotNumbers[i].AvailableSwabs, ExpiryDate: swabInventoryBoxBalance[0].SwabPurchaseDetails.ExpiryDate }];
                    }
                }
            }
            return new ResponseModel(true, "Data Found", { StockHistory: stockhistoryRecords && stockhistoryRecords.length > 0 ? stockhistoryRecords : [] });
        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal Server Error", error);
        }
    }

    export async function getAllVendors(): Promise<any> {
        try {
            let vendors: any = await prismaSwab.vendors.findMany({
                select: {
                    VendorID: true,
                    VendorName: true
                }
            });
            return new ResponseModel(true, "Data Found", vendors);
        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal Server Error", error);
        }
    }

    export async function getFilterVendors(): Promise<any> {
        try {
            let vendors = await prismaSwab.swabPurchaseMaster.findMany({
                select: {
                    Vendors: {
                        select: {
                            VendorID: true,
                            VendorName: true
                        }
                    }
                },
            });

            vendors = vendors.filter((value: any, index: any, self: any) =>
                index === self.findIndex((t: any) => (
                    t.VendorID === value.VendorID && t.VendorName === value.VendorName
                ))
            )
            let filterVendors: any[] = [];
            for (let i = 0; i < vendors.length; i++) {
                filterVendors.push(vendors[i].Vendors)
            }
            return new ResponseModel(true, "Data Found", filterVendors);
        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal Server Error", error);
        }
    }

    export async function filterPurchase(filters: any): Promise<any> {
        try {
            if (filters.PurchasePeriod == "All") {
                filters.FromDate = "01-01-2015";
                filters.ToDate = new Date();
            }
            let formatFromDate = moment(filters.FromDate);
            let formateToDate = moment(filters.ToDate);
            let VendorID = Number(filters.VendorID) > 0 ? Number(filters.VendorID) : undefined;

            let purchaseList = await prismaSwab.swabPurchaseMaster.findMany({
                orderBy: [
                    {
                        PurchaseMasterID: 'desc'
                    }
                ],
                where: {
                    PurchaseDate: {
                        lte: formateToDate.format(),
                        gte: formatFromDate.format(),
                    },
                    VendorID: VendorID
                },
                select: {
                    PurchaseMasterID: true,
                    PurchaseDate: true,
                    PONumber: true,
                    BoxQty: true,
                    Comments: true,
                    LastModifiedBy: true,
                    Vendors: {
                        select: {
                            VendorID: true,
                            VendorName: true
                        }
                    },
                    SwabPurchaseDetails: true
                },
            });
            for (let i = 0; i < purchaseList.length; i++) {
                let documents = await prismaSwab.referenceDocuments.findMany({
                    where: {
                        RefType: {
                            in: ['Purchase_Packing', 'Purchase_Invoice']
                        },
                        RefTypeID: purchaseList[i].PurchaseMasterID
                    },
                    select: {
                        RefDocID: true,
                        DocumentName: true,
                        RefType: true
                    }
                })
                purchaseList[i].LotNumbers = purchaseList[i].SwabPurchaseDetails.map((val:any)=> val.LotNumber);
                //purchaseList[i].ExpDates = purchaseList[i].SwabPurchaseDetails.map((val:any)=> val.ExpiryDate)
                purchaseList[i].TotalSwabs = purchaseList[i].SwabPurchaseDetails.reduce((sum:any, obj:any) => sum + obj.NumberOfSwabs, 0);
                purchaseList[i].documents = documents;
            }
            return new ResponseModel(true, "Data Found", purchaseList);
        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal Server Error", error);
        }
    }
}
