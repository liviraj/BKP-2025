import { Document, Packer, Paragraph, TextRun, Footer, Header, AlignmentType,ImageRun } from "docx";
import * as fs from "fs";
const moment = require('moment');
const path = require("path");

export module DocumentGenerator {

    export async function generateDispatchCustomsDoc(dispatchData: any): Promise<any> {
        let logoPath =  fs.readFileSync(path.resolve(__dirname, "../assets/HistoGenetics_logo.png"));
        let signPath =  fs.readFileSync(path.resolve(__dirname, "../assets/NezihCereb_CEO_Sign.png"));
        let formatedDispatchDate: string = moment(dispatchData.DispatchDate).format('MM/DD/YYYY');
        const doc = new Document({
            sections: [{
                headers: {
                    default: new Header({
                        children: [new Paragraph({
                            children:[
                                new ImageRun({
                                    data: logoPath,
                                    transformation: {
                                        width: 200,
                                        height: 40,
                                    },
                                }),
                            ]
                        })],
                    }),
                },
                footers: {
                    default: new Footer({
                        children: [
                            new Paragraph({
                                children:[
                                    new TextRun({
                                        text: "300 Executive Blvd.",
                                        break: 1,
                                        font: "Century Gothic",
                                        size: 22
                                    }),
                                    new TextRun({
                                        text: "Ossining, NY 10562",
                                        break: 1,
                                        font: "Century Gothic",
                                        size: 22
                                    }),
                                    new TextRun({
                                        text: "",
                                        break: 1,
                                        font: "Century Gothic",
                                        size: 22
                                    }),
                                    new TextRun({
                                        text: "T:(914) 762-0300",
                                        break: 1,
                                        font: "Century Gothic",
                                        size: 22
                                    }),
                                    new TextRun({
                                        text: "F:(914) 762-4441",
                                        break: 1,
                                        font: "Century Gothic",
                                        size: 22
                                    }),
                                    new TextRun({
                                        text: "",
                                        break: 1,
                                        font: "Century Gothic",
                                        size: 22
                                    }),
                                    new TextRun({
                                        text: "www.histogenetics.com",
                                        break: 1,
                                        font: "Century Gothic",
                                        size: 22
                                    }),
                                ]
                            })],
                    }),
                },
                properties: {},
                children: [
                    new Paragraph({

                        children: [
                            new TextRun({
                                text: "",
                                break: 2,
                                font: "Century Gothic",
                                size: 24
                            }),
                            new TextRun({
                                text: formatedDispatchDate,
                                font: "Century Gothic",
                                size: 24
                            }),
                            new TextRun({
                                text: "",
                                break: 1
                            }),
                            new TextRun({
                                text: "From: HistoGenetics",
                                break: 1,
                                font: "Century Gothic",
                                size: 24
                            }),
                            new TextRun({
                                text: "\t300 Executive Blvd.",
                                break: 1,
                                font: "Century Gothic",
                                size: 24
                            }),
                            new TextRun({
                                text: "\tOssining, NY 10562",
                                break: 1,
                                font: "Century Gothic",
                                size: 24
                            }),
                            new TextRun({
                                text: "\tT:(914) 762-0300",
                                break: 1,
                                font: "Century Gothic",
                                size: 24
                            }),
                            new TextRun({
                                text: "\tF:(914) 762-4441",
                                break: 1,
                                font: "Century Gothic",
                                size: 24
                            }),
                            new TextRun({
                                text: "",
                                break: 1,
                                font: "Century Gothic",
                                size: 24
                            }),
                            new TextRun({
                                text: "To whom it may concern,",
                                break: 1,
                                font: "Century Gothic",
                                size: 24
                            }),
                            new TextRun({
                                text: "",
                                break: 1,
                                font: "Century Gothic",
                                size: 24
                            }),
                            new TextRun({
                                text: `Subject: Buccal Swab Kit Shipment \t\t Tracking number:${dispatchData.ShippingTrackingNumber}`,
                                break: 1,
                                font: "Century Gothic",
                                size: 24
                            })
                        ],
                    }),
                    new Paragraph({
                        alignment: AlignmentType.JUSTIFIED,
                        children: [
                            new TextRun({
                                text: "",
                                break: 1,
                                font: "Century Gothic",
                                size: 24
                            }),
                            new TextRun({
                                text: `The shipment is containing ${dispatchData.DispatchQty} buccal swab kits. The buccal swab is ${dispatchData.SwabUOM} used for DNA testing. These buccal swabs are not sold to ${dispatchData.ClientName}, and hence it does not have a retail value. Following are the declared value of the commercial invoice:`,
                                break: 1,
                                font: "Century Gothic",
                                size: 24
                            })
                        ],
                    }),
                    new Paragraph({

                        children: [
                            new TextRun({
                                text: "",
                                break: 1,
                                font: "Century Gothic",
                                size: 24
                            }),
                            new TextRun({
                                text: "Total Declared Commercial value of the shipment:   $1,000.00",
                                break: 1,
                                font: "Century Gothic",
                                size: 24
                            }),
                            new TextRun({
                                text: "",
                                break: 1,
                                font: "Century Gothic",
                                size: 24
                            })
                        ],
                    }),
                    new Paragraph({
                        alignment: AlignmentType.JUSTIFIED,
                        children: [
                            new TextRun({
                                text: `Please understand that this shipment is time sensitive. The shipment contains buccal swabs that are being sent to ${dispatchData.ClientName}, and he/she will collect DNA sample. The swabs will be sent back to us for further DNA testing.`,
                                break: 1,
                                font: "Century Gothic",
                                size: 24
                            }),
                        ],
                    }),

                    new Paragraph({
                        alignment: AlignmentType.LEFT,
                        children: [
                            new TextRun({
                                text: "",
                                break: 6,
                                font: "Century Gothic",
                                size: 24
                            }),
                            new ImageRun({
                                data: signPath,
                                transformation: {
                                    width: 150,
                                    height: 75,
                                },
                            }),
                            new TextRun({
                                text: "Nezih Cereb, MD",
                                break: 1,
                                font: "Century Gothic",
                                size: 24
                            }),
                            new TextRun({
                                text: "HistoGenetics",
                                break: 1,
                                font: "Century Gothic",
                                size: 24
                            }),
                            new TextRun({
                                text: "CEO & Co-founder",
                                break: 1,
                                font: "Century Gothic",
                                size: 24
                            }),
                        ],
                    }),
                ],
            }],
        });

        // Packer.toBuffer(doc).then((buffer) => {
        //     fs.writeFileSync("My Document.docx", buffer);
        // });

        return Packer.toBuffer(doc);
    }

    function createContactInfo(): Paragraph {
        return new Paragraph({
            alignment: AlignmentType.LEFT,
            children: [
                new TextRun({
                    text: "From: HistoGenetics",
                    break: 1
                }),
                new TextRun({
                    text: "\t300 Executive Blvd.",
                    break: 1
                }),
                new TextRun({
                    text: "\tOssining, NY 10562",
                    break: 1
                }),
                new TextRun({
                    text: "\tT:(914) 762-0300",
                    break: 1
                }),
                new TextRun({
                    text: "\tF:(914) 762-4441",
                    break: 1
                })
            ]
        });
    }
}