import { IResult } from "mssql";
import { histoSConnectionPool } from "../common/db_connection";
import * as Sql from 'mssql/msnodesqlv8';
export module UsersDA {

    export async function getUserInfo(data: any): Promise<String> {
        return new Promise<String>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('EmailID', Sql.NVarChar, data);
                
                request.execute('GetUserInfo').then((val: IResult<String>) => {
                    resolve(val.recordset[0]);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    export async function GetUserByEmailAddress(EmailAddress: any): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('EmailID', Sql.NVarChar, EmailAddress);
                
                request.execute('GetUserInfoByEmailID').then((val: IResult<any>) => {
                    if (val.recordset != null && val.recordset != undefined && val.recordset.length != 0){
                        resolve(val.recordset[0]);
                    } else {
                        resolve(val.recordset);
                    }
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }
}