import { text } from "body-parser";
import { Constants, Message } from "../common/constants";
const getStream = require('get-stream')

const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require("path");


export module PDFGenerator {
    export async function generateInvoice(invoiceData: any, pdfPath: string): Promise<any> {
        try {

            //await fs.promises.access(pdfPath);
            if (fs.existsSync(pdfPath)) {

                let doc = new PDFDocument({ size: "A4", margins: { top: 15, bottom: 15, left: 10, right: 40 }, bufferPages: true });
                let pdfName = "Inv" + String(invoiceData.invoiceDetails.invoiceNumber) + "_" + invoiceData.invoiceDetails.ClientName;
                pdfPath += "\\" + pdfName;

                let buffers: any = [];

                doc.registerFont('arial', path.join(__dirname + '/fonts/arial.ttf'));
                doc.registerFont('arial-bold', path.join(__dirname + '/fonts/arial-bold.ttf'));

                generateHeader(doc, 15, 15);
                drawBoldLine(doc);
                generateAddressInfo(doc, invoiceData,);
                generateInoiveAddress(doc, invoiceData.invoiceAddress, invoiceData);
                generateInvoiceTable(doc, invoiceData);
                doc.addPage();
                generateHeader(doc, 15, 15);
                generateAddressInfoTwo(doc, invoiceData);
                generateInoiveAddressTwo(doc, invoiceData);
                generateInvoiceTableTwo(doc, invoiceData);
                generateInvoiceAddresTwo(doc, invoiceData);

                let pdfStream = fs.createWriteStream(pdfPath)
                await doc.pipe(pdfStream);
                doc.end();

                buffers = await getStream.buffer(doc)
                return buffers;
            }
            else {
                return Message("").unauthorizedPath;
            }
        }
        catch (err: any) {
            throw err;
        }
    }


    function generateHeader(doc: any, x: number, y: number) {
        let logoPath = fs.readFileSync(path.resolve(__dirname, "../assets/HistoGenetics_logo.png"));
        doc.image(logoPath, x, y, { width: 120 });

    }

    function generateAddressInfo(doc: any, invoiceData: any) {
        let companyDetails = invoiceData.invoiceDetails.companyDetails;
        let paymentMethod = invoiceData.invoiceDetails.paymentMethod;
        doc.fontSize(10);
        doc.font('arial').text(companyDetails[0].AttributeValue, 20, 50)
            .text(companyDetails[1].AttributeValue, 20, 65)
            .text(companyDetails[2].AttributeValue, 20, 80)
            .text(companyDetails[3].AttributeValue, 20, 95)
            .text(companyDetails[4].AttributeValue, 20, 110)
            .moveDown()
            .moveDown()
            .moveDown();
        doc.font('arial-bold').text(companyDetails[8].AttributeValue, 20, 170);
        doc.font('arial').text(companyDetails[9].AttributeValue, 20, 185)
        doc.font('arial').text(companyDetails[10].AttributeValue, 20, 200);

        doc.font('arial-bold').text(paymentMethod[0].AttributeValue, 300, 50);
        doc.font('arial').text(paymentMethod[1].AttributeValue, 300, 65)
            .text(paymentMethod[2].AttributeValue, 300, 80)
            .moveDown()
            .text(paymentMethod[4].AttributeValue, 300, 110)
            .text(paymentMethod[5].AttributeValue, 300, 125)
            .text(paymentMethod[6].AttributeValue, 300, 140)
            .text(paymentMethod[7].AttributeValue, 300, 155)
            .text(paymentMethod[8].AttributeValue, 300, 170)
            .text(paymentMethod[9].AttributeValue, 300, 185)
            .text(paymentMethod[10].AttributeValue, 300, 200)
            .moveDown()
    }

    function generateInoiveAddress(doc: any, invoiceAddress: any, invoiceData: any) {
        let accountStatement = invoiceData.invoiceDetails.accountDetails[0]
        let outstandingBalance = invoiceData.invoiceDetails.outstandingBalance[0];
        let currentInvoice = invoiceData.invoiceDetails.currentInvoice[0];
        let totalPaymentDue = invoiceData.invoiceDetails.totalPaymentDue[0];
        let cityAndState = invoiceAddress.billToState + ', ' + invoiceAddress.billToCity + ' - ' + invoiceAddress.billToPostalCode;
        doc.fontSize(18).font('arial-bold').text('Invoice', 250, 235, { underline: true });
        let invoiceDate = invoiceData.invoiceDetails.accountDetails[0].StatementDate;
        doc.fontSize(10).font('arial-bold').text('To :', 20, 260)
            .text(invoiceAddress.billToName, 20, 275);
        let yAxios =  invoiceAddress.billToAdditionalName ? 275 + 15 : 275;
        invoiceAddress.billToAdditionalName && doc.text(invoiceAddress.billToAdditionalName, 20, yAxios);
        doc.text(invoiceAddress.billToAddress1, 20, yAxios + 15);
        const billToAddress2 = invoiceAddress.billToAddress2;
        billToAddress2 && billToAddress2.trim().length > 0 && doc.text(billToAddress2, 20, yAxios + 30);
        yAxios = billToAddress2 && billToAddress2.trim().length > 0 ? yAxios : (yAxios - 15);
        doc.text(cityAndState, 20, yAxios + 45)
            .text(invoiceAddress.billToCountry, 20, yAxios + 60);

        let count: number = yAxios + 60;
        if (("otherDetail1" in invoiceAddress) && invoiceAddress.otherDetail1 && invoiceAddress.otherDetail1.length > 0) {
            count += 15;
            doc.text(invoiceAddress.otherDetail1, 20, count);
        } 
        if(("otherDetail2" in invoiceAddress) && invoiceAddress.otherDetail2 && invoiceAddress.otherDetail2.length > 0){
            count += 15;
            doc.text(invoiceAddress.otherDetail2 , 20, count);
        }
        if(("otherDetail3" in invoiceAddress) && invoiceAddress.otherDetail3 && invoiceAddress.otherDetail3.length > 0){
            count += 15;
            doc.text(invoiceAddress.otherDetail3 , 20, count);
        }

        doc.text(`Date: ${invoiceDate}`, 400, 260);

        //let count = calcInvoiceAddressY(invoiceAddress, tempCount + 35);
        count += 35;

        generateHr(doc, 15, 580, count);
        generateHr(doc, 15, 580, count + 30);
        generateHr(doc, 15, 580, count + 60);
        generateHr(doc, 15, 580, count + 90);

        generateVr(doc, 15, count, count + 90);
        generateVr(doc, 310, count, count + 90);
        generateVr(doc, 580, count, count + 90);

        doc.fontSize(12).font('arial-bold').text(outstandingBalance.label, 150, count + 10, { width: 150, align: "right" })
            .text(formatter.format(parseFloat(accountStatement.OpeningBalance)), 360, count + 10, { width: 150, align: "right" })
            .text(currentInvoice.Label, 50, count + 40, { width: 250, align: "right" })
            .text(formatter.format(currentInvoice.Amount), 360, count + 40, { width: 150, align: "right" });

        doc.fontSize(16).font('arial-bold').text(totalPaymentDue.label, 150, count + 68, { width: 150, align: "right" })
            .text(formatter.format(totalPaymentDue.Amount), 360, count + 68, { width: 150, align: "right" });
    }

    function generateInvoiceTable(doc: any, invoiceData: any) {
        let creditStatement: any[] = invoiceData.invoiceDetails.creditStatement;
        let accountStatement = invoiceData.invoiceDetails.accountDetails[0];
        let number = invoiceData.invoiceAddress.billToAdditionalName ? 495 : 480;
        number = invoiceData.invoiceAddress.billToAddress2 && invoiceData.invoiceAddress.billToAddress2 ? number : (number - 15);
        let count = calcInvoiceAddressY(invoiceData.invoiceAddress, number);

        doc.font("arial-bold");

        generateHr(doc, 15, 580, count);
        generateHr(doc, 15, 580, count + 20);
        generateHr(doc, 15, 580, count + 40);
        generateHr(doc, 15, 580, count + 60);

        generateTableRow(
            doc,
            count + 5,
            "Sr.No",
            "Transaction Date",
            "Description",
            "Charges",
            "Credit",
            "Balance"
        );
        doc.fontSize(10).font('arial').text('Opening Balance', 250, count + 25)
            .text(formatter.format(parseFloat(accountStatement.OpeningBalance)), 450, count + 25, { align: "right" });

        let tableVerticalPosition: number = count + 45;
        let tableVerticalLinePosition: number = count + 60;
        let sNo: number = 1;
        for (let i = 0; i < creditStatement.length; i++) {
            generateTableRow(
                doc,
                tableVerticalPosition,
                sNo.toString(),
                creditStatement[i].TransactionDate,
                creditStatement[i].description,
                formatter.format(creditStatement[i].TransactionAmount),
                "",
                formatter.format(creditStatement[i].Balance)
            );

            generateHr(doc, 15, 580, tableVerticalLinePosition);
            tableVerticalPosition += 20;
            tableVerticalLinePosition += 20;
            sNo += 1;
        }

        doc.fontSize(12).font('arial-bold').text('Closing Balance', 250, tableVerticalPosition)
            .text(formatter.format(parseFloat(accountStatement.ClosingBalance)), 450, tableVerticalPosition, { align: "right" });
    }

    function generateAddressInfoTwo(doc: any, invoiceData: any) {
        let companyDetails = invoiceData.invoiceDetails.companyDetails;
        doc.fontSize(10).font('arial').text(companyDetails[0].AttributeValue + ' ' + companyDetails[1].AttributeValue, 20, 50)
            .text(companyDetails[2].AttributeValue + ' ' + companyDetails[3].AttributeValue + '' + companyDetails[4].AttributeValue, 20, 65)
            .text(companyDetails[9].AttributeValue + ' ' + companyDetails[10].AttributeValue + ' ' + 'Directors.', 20, 80);
    }
    function generateInoiveAddressTwo(doc: any, invoiceAddress: any) {
        let invcoieDetails = invoiceAddress.invoiceDetails.accountDetails[0];
        let stateAndCity = invoiceAddress.invoiceAddress.billToState+', '+invoiceAddress.invoiceAddress.billToCity+' - '+invoiceAddress.invoiceAddress.billToPostalCode
        doc.fontSize(12).font('arial-bold').text('INVOICE', 285, 95)
        doc.fontSize(10).font('arial-bold').text('To :', 20, 110);
        doc.fontSize(10).font('arial-bold').text(invoiceAddress.invoiceAddress.billToName, 20, 125)
        let yAxios = invoiceAddress.invoiceAddress.billToAdditionalName ? 140 : 125;
        invoiceAddress.invoiceAddress.billToAdditionalName && doc.fontSize(10).font('arial-bold').text(invoiceAddress.invoiceAddress.billToAdditionalName, 20, yAxios)
        doc.fontSize(10).font('arial').text(invoiceAddress.invoiceAddress.billToAddress1, 20, yAxios + 15);
        const billToAddress2 = invoiceAddress.invoiceAddress.billToAddress2;
        billToAddress2 && billToAddress2.trim().length > 0 && doc.text(billToAddress2, 20, yAxios + 30);
        yAxios = billToAddress2 && billToAddress2.trim().length > 0 ? yAxios : (yAxios - 15);
        // doc.text(invoiceAddress.invoiceAddress.billToAddress2, 20, yAxios + 30)
        doc.text(stateAndCity, 20, yAxios + 45)
            .text(invoiceAddress.invoiceAddress.billToCountry, 20, yAxios + 60);
        let tempCount: number = yAxios + 60;
        if (("otherDetail1" in invoiceAddress.invoiceAddress) && invoiceAddress.invoiceAddress.otherDetail1 && invoiceAddress.invoiceAddress.otherDetail1.length > 0) {
            tempCount += 15;
            doc.text(invoiceAddress.invoiceAddress.otherDetail1, 20, tempCount);
        }
        if (("otherDetail2" in invoiceAddress.invoiceAddress) && invoiceAddress.invoiceAddress.otherDetail2 && invoiceAddress.invoiceAddress.otherDetail2.length > 0) {
            tempCount += 15;
            doc.text(invoiceAddress.invoiceAddress.otherDetail2, 20, tempCount);
        }
        if (("otherDetail3" in invoiceAddress.invoiceAddress) && invoiceAddress.invoiceAddress.otherDetail3 && invoiceAddress.invoiceAddress.otherDetail3.length > 0) {
            tempCount += 15;
            doc.text(invoiceAddress.invoiceAddress.otherDetail3, 20, tempCount);
        }
        doc.moveDown();

        doc.fontSize(10).font('arial-bold')
            .text(`Invoice No     : ${invoiceAddress.invoiceDetails.invoiceNumber}`, 404, 110)
            .text(`Date               : ${invcoieDetails.StatementDate}`, 405, 125)
            .text("TIN                 : 20-5412180", 405, 140)
        if (invoiceAddress.invoiceDetails.PoNumber != undefined && invoiceAddress.invoiceDetails.PoNumber != null && invoiceAddress.invoiceDetails.PoNumber != '' && invoiceAddress.invoiceDetails.PoNumber != '""') {
            let poNumber = invoiceAddress.invoiceDetails.PoNumber;
            doc.fontSize(10).font('arial-bold')
                .text(`PO Number   : ${poNumber.replaceAll('"', '')}`, 405, 155)
        }
    }
    let addressTwoPosition = 0;
    function generateInvoiceTableTwo(doc: any, invoiceData: any) {
        let invoiceDetailsRow = invoiceData.invoiceDetails;

        let totalAmount: number = 0;
        let number: number = invoiceData.invoiceAddress.billToAdditionalName ? 230 : 215;
        number = invoiceData.invoiceAddress.billToAddress2 && invoiceData.invoiceAddress.billToAddress2.trim().length > 0 ? number : (number - 15);
        let count = calcInvoiceAddressY(invoiceData.invoiceAddress, number);
        generateHr(doc, 20, 580, count);
        generateHr(doc, 20, 580, count + 20);

        doc.fontSize(10);
        doc.font("arial-bold");
        generateTableRowTwo(
            doc,
            count + 5,
            150,
            "S.No",
            "Description",
            "Qty",
            "Rate(US$)",
            "Amount(US$)"
        );

        doc.font("arial")
        let hrPossitionStart: number = count;
        let hrPossitionEnd: number = 250;
        let itemPossion: number = count + 25;
        let sNo: number = 1;
        let i = 0;
        let totalPosition = 0;
        for (let item of invoiceDetailsRow.invoiceItems) {
            i = i + 1;
            if (invoiceDetailsRow.SwabCost == "" || invoiceDetailsRow.SwabCost == 0) {
                if (item.SwabUOM == Constants.Buccal_Swab_Kit || item.SwabUOM == Constants.FLOQSwabs) {
                    item.totalAmount = 0;
                }
                generateTableRowTwo(
                    doc,
                    itemPossion,
                    80,
                    sNo.toString(),
                    item.Description,
                    item.DispatchQty,
                    formatter.format(parseFloat(item.UnitPrice)),
                    formatter.format(item.totalAmount)
                );
                totalAmount = parseFloat(invoiceDetailsRow.ShipmentCharges);
            } else {
                generateTableRowTwo(
                    doc,
                    itemPossion,
                    80,
                    sNo.toString(),
                    item.Description,
                    item.DispatchQty,
                    formatter.format(parseFloat(item.UnitPrice)),
                    formatter.format(parseFloat(item.totalAmount))
                );
                totalAmount += parseFloat(item.totalAmount);
            }

            sNo++;
            itemPossion = itemPossion + 35; 
            if(itemPossion >= (invoiceData.invoiceAddress.billToAdditionalName ? 570 : 585)){//row 14 reached limit
                addressTwoPosition = 600;
            }
            if(itemPossion > 590 && itemPossion <= 765){
                totalPosition = totalPosition + 40;
            }else{
                totalPosition = 0;
            }
            let vrEndPosition = 600 + totalPosition
            if(itemPossion + 35 >= 765 && invoiceDetailsRow.invoiceItems.length !== i){ // common Vr height
                let endPosition = vrEndPosition < 800 ? vrEndPosition : 800 ;          
                generateVr(doc, 60,  hrPossitionStart, endPosition);
                generateVr(doc, 20,  hrPossitionStart, endPosition);
                generateVr(doc, 325, hrPossitionStart, endPosition);
                generateVr(doc, 375, hrPossitionStart, endPosition);
                generateVr(doc, 450, hrPossitionStart, endPosition);
                generateVr(doc, 580, hrPossitionStart, endPosition);
                if(invoiceDetailsRow.invoiceItems.length > 14){
                    generateHr(doc, 20, 580, 800 );
                }
            }              
            if(itemPossion >= 765 && invoiceDetailsRow.invoiceItems.length !== i){//on page break required
                doc.addPage();
                hrPossitionStart = 30;
                hrPossitionEnd = 70;
                itemPossion = 35;
                addressTwoPosition = 0;
                generateHr(doc, 20, 580, 30 );
                generateVr(doc, 20, hrPossitionStart,  hrPossitionEnd);
                generateVr(doc, 60, hrPossitionStart,  hrPossitionEnd);
                generateVr(doc, 325, hrPossitionStart, hrPossitionEnd);
                generateVr(doc, 375, hrPossitionStart, hrPossitionEnd);
                generateVr(doc, 580, hrPossitionStart, hrPossitionEnd);
                generateVr(doc, 450, hrPossitionStart, hrPossitionEnd);
                hrPossitionStart = hrPossitionStart + 35;
                hrPossitionEnd = hrPossitionEnd + 40;
            }
            if (itemPossion < 765 && i >= 16 && invoiceDetailsRow.invoiceItems.length !== i) {//dynamic after 1st page    
                let endPosition = hrPossitionEnd < 800 ? hrPossitionEnd : 800 ;                             
                generateVr(doc, 20, hrPossitionStart,  endPosition);
                generateVr(doc, 60, hrPossitionStart,  endPosition);
                generateVr(doc, 325, hrPossitionStart, endPosition);
                generateVr(doc, 375, hrPossitionStart, endPosition);
                generateVr(doc, 450, hrPossitionStart, endPosition);
                generateVr(doc, 580, hrPossitionStart, endPosition);                
                hrPossitionStart = hrPossitionStart + 35;
                hrPossitionEnd = hrPossitionEnd + 40;
            }
            if(invoiceDetailsRow.invoiceItems.length === i ){//last page
                generateVr(doc, 60, hrPossitionStart,  vrEndPosition);
                generateVr(doc, 20, hrPossitionStart,  vrEndPosition);
                generateVr(doc, 325, hrPossitionStart, vrEndPosition);
                generateVr(doc, 375, hrPossitionStart, vrEndPosition);
                generateVr(doc, 580, hrPossitionStart, vrEndPosition);
                generateVr(doc, 450, hrPossitionStart, vrEndPosition);
            }
            if(i < 15){//1st page
                generateVr(doc, 20, hrPossitionStart,  vrEndPosition);
                generateVr(doc, 60, hrPossitionStart,  vrEndPosition);
                generateVr(doc, 325, hrPossitionStart, vrEndPosition);
                generateVr(doc, 375, hrPossitionStart, vrEndPosition);
                generateVr(doc, 450, hrPossitionStart, vrEndPosition);
                generateVr(doc, 580, hrPossitionStart, vrEndPosition);
                hrPossitionStart = hrPossitionStart + 35;
                hrPossitionEnd = hrPossitionEnd + 40;
            }
        }
        generateHr(doc, 20, 580, 600 + totalPosition );
        generateHr(doc, 375, 580, 630 + totalPosition);


        generateVr(doc, 375, 500, 630 + totalPosition);
        generateVr(doc, 450, 500, 630 + totalPosition);
        generateVr(doc, 580, 500, 630 + totalPosition);

        doc.text('Total', 380, 610 + totalPosition);
        doc.fontSize(12).font('arial').text(formatter.format(totalAmount), 0, 610 + totalPosition, { align: "right", });

    }
    function generateInvoiceAddresTwo(doc: any, invoiceData: any) {
        let paymentMethod = invoiceData.invoiceDetails.paymentMethod;
        if(addressTwoPosition===600){
            doc.addPage();
        }
        doc.fontSize(10).font('arial-bold').text(paymentMethod[0].AttributeValue, 20, 635 - addressTwoPosition)
            .text(paymentMethod[1].AttributeValue + ' ' + paymentMethod[2].AttributeValue, 20, 650 - addressTwoPosition)
            .text(paymentMethod[3].AttributeValue, 20, 665 - addressTwoPosition)
            .text(paymentMethod[4].AttributeValue, 20, 680 - addressTwoPosition)
            .text(paymentMethod[5].AttributeValue, 20, 695 - addressTwoPosition)
            .text(paymentMethod[6].AttributeValue, 20, 710 - addressTwoPosition)
            .text(paymentMethod[7].AttributeValue, 20, 725 - addressTwoPosition)
            .text(paymentMethod[8].AttributeValue, 20, 740 - addressTwoPosition)
            .text(paymentMethod[9].AttributeValue, 20, 755 - addressTwoPosition)
            .text(paymentMethod[10].AttributeValue, 20, 770 - addressTwoPosition)
    }

    function generateTableRowTwo(
        doc: any,
        y: number,
        x: number,
        srNo: string,
        description: string,
        charges: string,
        credit: string,
        balance: string
    ) {
        doc
            .fontSize(10)
            .text(srNo, 25, y)
            .text(description, x, y, { width: 240, align: "left" })
            .text(charges, 270, y, { width: 90, align: "right" })
            .text(credit, 350, y, { width: 90, align: "right" })
            .text(balance, 0, y, { align: "right" });
    }

    function generateTableRow(
        doc: any,
        y: number,
        srNo: string,
        transDate: string,
        description: string,
        charges: string,
        credit: string,
        balance: string
    ) {
        doc
            .fontSize(10)
            .text(srNo, 28, y)
            .text(transDate, 70, y)
            .text(description, 150, y, { width: 170, align: "right" })
            .text(charges, 320, y, { width: 90, align: "right" })
            .text(credit, 390, y, { width: 90, align: "right" })
            .text(balance, 0, y, { align: "right" });
    }

    function drawBoldLine(doc: any) {
        doc.lineCap('butt')
            .moveTo(15, 43)
            .lineTo(580, 43)
            .lineWidth(1.3)
            .stroke();
    }

    function generateHr(doc: any, x1: number, x2: number, y: number) {
        doc
            .strokeColor("#000000")
            .lineWidth(1.3)
            .moveTo(x1, y)
            .lineTo(x2, y)
            .stroke();
    }

    function generateVr(doc: any, x: number, y1: number, y2: number) {
        doc
            .strokeColor("#000000")
            .lineWidth(1.3)
            .moveTo(x, y1)
            .lineTo(x, y2)
            .stroke();
    }

    // function formatter.format(dollor: any) {
    //     return "$" + (dollor).toFixed(2);
    // }

    let formatter = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
    });

    function formatDate(date: any) {
        const day = date.getDate();
        const month = date.getMonth() + 1;
        const year = date.getFullYear();

        return year + "/" + month + "/" + day;
    }
    function backGroundColorFill(doc: any) {
        doc.fillColor('#222222');
    }
    
    const calcInvoiceAddressY = (invoiceAddress: any, num: number) => {
        if("otherDetail1" in invoiceAddress && invoiceAddress.otherDetail1 && invoiceAddress.otherDetail1.length > 0){
            num += 15;
        }
        if("otherDetail2" in invoiceAddress && invoiceAddress.otherDetail2 && invoiceAddress.otherDetail2.length > 0){
            num += 15;
        }
        if("otherDetail3" in invoiceAddress && invoiceAddress.otherDetail3 && invoiceAddress.otherDetail3.length > 0){
            num += 15;
        }
        return num;
    }

}

export module PackingPdfGenerator {
    export async function generatePackingPdf(pdfData: any): Promise<any> {
        let { data,clientDetails } = pdfData;
        try {
            let buffers: any = [];
            let doc = new PDFDocument({ size: "A4", margins: { top: 15, bottom: 15, left: 15, right: 40 } });

            generateHeader(doc, 10, 20);
            generateAddressInfo(doc);
            generatePackingSlipHeader(doc);
            generateCustomerAddressInfo(doc,clientDetails);
            generateCustomerInfo(doc,clientDetails);
            generatePackingSlipTable(doc,data);
            //doc.pipe(fs.createWriteStream('Packing_Slip.pdf'));
            doc.end();
            buffers = await getStream.buffer(doc)
            return buffers;
        } catch (err) {
            throw err;
        }
    }

    function generateHeader(doc: any, x: number, y: number) {
        let logoPath = fs.readFileSync(path.resolve(__dirname, "../assets/HistoGenetics_logo.png"));
        doc.image(logoPath, x, y, { width: 140 });
        doc.fontSize(8);        
    }

    function generateHr(doc: any, x1: number, x2: number, y: number) {
        doc
        .strokeColor("#000000")
        .lineWidth(1.3)
        .moveTo(x1, y)
        .lineTo(x2, y)
        .stroke();
    }

    function generatePakageSlipTableRow(
        doc: any,
        fontStyle:any,
        x:any,
        y: number,
        srNo: string,
        productNo:string,
        description: string,
        LotNo: string,
        expData: string,
        qty: string,
        unitOfMeasurement:string
    ) {
        doc
            .fontSize(10)
            .font(fontStyle)
            // .fillColor(color)
            // .stroke(fontStyle)
            .text(srNo, x[0], y,{ align: "left" })
            .text(productNo, x[1], y,{ align: "left" })
            .text(description, x[2], y, { width: 150, align: "left" })
            .text(LotNo, x[3], y, {width: 45, align: "left" })
            .text(expData, x[4], y, { align: "left" })
            .text(qty, x[5], y, { align: "left" })
            .text(unitOfMeasurement, x[6], y,{ width: 170, align: "left" });
            
    }

    function generateAddressInfo(doc:any) {
        doc.moveDown();
        doc.moveDown();
        doc.moveDown();
        doc.moveDown();
        doc.fontSize(10);
        doc.font('Helvetica')
        .text(`300 Executive Boulevard, Ossining, New York - 10562. `, { width: 410, align: 'left' });
        doc.text(`Phone : +1 914-762-0300. Fax : +1 914-292-3652. Website : www.histogenetics.com`, { width: 410, align: 'left' });
        doc.text(`Soo Young Yang Ph.D / Nezih Cereb M.D., Directors`);
    }

    function generatePackingSlipHeader(doc:any){
        generateHr(doc, 15, 580, 100);
        doc.moveDown();
        doc.moveDown();
        doc.fontSize(18);
        doc.font('Helvetica-Bold').text("PACKING LIST",{align: 'center',continued: false});
    }

    function generateCustomerAddressInfo(doc:any,clientDetails:any){
        doc.fontSize(10);
        doc.moveDown();
        doc.font('Helvetica')
        .text("Ship To :",{align: 'left',fontWeight:100})
        doc.text(`${clientDetails.ClientName}`,{ width: 350, align: 'left' });        
        doc.text(`${clientDetails.ShippingAddress2?`${clientDetails.ShippingAddress1},`:`${clientDetails.ShippingAddress1}, ${clientDetails.City}, ${clientDetails.State}, ${clientDetails.CountryID} - ${clientDetails.Zip}`}` ,{ width: 350, align: 'left' });
        if(clientDetails.ShippingAddress2) doc.text(`${clientDetails.ShippingAddress2}, ${clientDetails.City}, ${clientDetails.State}, ${clientDetails.CountryID} - ${clientDetails.Zip}.`, { width: 350, align: 'left' });
        doc.text(`Phone : ${clientDetails.RequestorContactNumber}`, { width: 350, align: 'left' });
    }

    function generateCustomerInfo(doc:any,clientDetails:any){
        doc.moveDown();
        doc.fontSize(10);
        doc.text(`PO #`,420, 146,{align: 'left' });
        doc.text(`Order Date`,420, 156,{align: 'left' });
        doc.text(`Shipment Date`,420, 166,{align: 'left' });
        doc.text(`Carrier`,420, 176,{align: 'left' });     
        doc.text(`Tracking #`,420, 186,{align: 'left' });  
        
        doc.text(`: `,500, 146,{ width: 560, align: 'left' });
        doc.text(`: ${formatDate(clientDetails.RequestedDate)}`,500, 156,{ align: 'left' });
        doc.text(`: ${formatDate(clientDetails.shipmentDate)}`,500, 166,{ align: 'left' });
        doc.text(`: ${clientDetails.ShipCarrier}`,500, 176,{ align: 'left' });     
        doc.text(`: ${clientDetails.trackingNumber}`,500, 186,{ align: 'left' }); 
    }
    

    function generatePackingSlipTable(doc: any, data: any) {

        generateHr(doc, 15, 580, 220);
        generateHr(doc, 15, 580, 240);
        generateHr(doc, 15, 580, 305);

        generatePakageSlipTableRow(
            doc,
            "Helvetica-Bold",
            [21, 55, 165, 300, 355, 425, 477],//x
            227,//y
            "S.No",
            "Product No",
            "Description",
            "Lot #",
            "Expiry Date",
            "Quantity",
            "Unit of Measurement"
        );

        let tableVerticalPosition: number = 250;
        let tableVerticalLinePosition: number = 305;
        let sNo: number = 1;
        let vrLength = 240;
        let nextPgVal = 7;
        let lineDrew = false;
        for (let i = 0; i < data.length; i++) {
            let unitOfmeasurements = data[i].SwabUOMID === 1 ? "Pair" : data[i].SwabUOMID === 2 ? "Kit" : ""
            generatePakageSlipTableRow(
                doc,
                'Helvetica',
                [28, 75, 130, 292, 355, 435, 510],//x
                tableVerticalPosition,//y
                sNo.toString(),
                data[i].SwabUOMID,
                data[i].Description,
                data[i].LotNumber,
                formatDate(data[i].ExpiryDate),
                data[i].DispatchQty.toString(),
                unitOfmeasurements
            );
            // you can adjust this to get the desired margins between text blocks
            
            generateHr(doc, 15, 580, tableVerticalLinePosition);
            tableVerticalPosition += 65;
            tableVerticalLinePosition += 65;
            sNo += 1;
            vrLength += 65;
            if (i !==0 && i % nextPgVal === 0 && data.length >= 9 ) {//&& data.length - 2 > i  
                doc.addPage();    
                generateHr(doc, 15, 580, 170);
                generateHr(doc, 15, 580, 752);
                tableVerticalPosition = 120;
                tableVerticalLinePosition = 105;
                let vrLen = 752 ;//i % 10
                nextPgVal = 10 + nextPgVal;
                let size = 105;
                generateVr(doc, 15, size, vrLen);//start
                generateVr(doc, 50, size, vrLen);//s.no
                generateVr(doc, 112, size, vrLen);//prod no
                generateVr(doc, 280, size, vrLen);//description
                generateVr(doc, 345, size, vrLen);//lot#
                generateVr(doc, 420, size, vrLen);//exp date
                generateVr(doc, 472, size, vrLen);//qty
                generateVr(doc, 580, size, vrLen);//end
            }
            if (i < 9 && !lineDrew && data.length >= 9) {
                let vrLine = 240 + (65 * 8) ;
                //generateHr(doc, 15, 580, tableVerticalLinePosition);
                generateVr(doc, 15, 220, vrLine);//start
                generateVr(doc, 50, 220, vrLine);//s.no
                generateVr(doc, 112, 220, vrLine);//prod no
                generateVr(doc, 280, 220, vrLine);//description
                generateVr(doc, 345, 220, vrLine);//lot#
                generateVr(doc, 420, 220, vrLine);//exp date
                generateVr(doc, 472, 220, vrLine);//qty
                generateVr(doc, 580, 220, vrLine);//end   
            }              
            lineDrew = true         
        } 
        if(data.length < 9 ){
            generateVr(doc, 15, 220, vrLength);//start
            generateVr(doc, 50, 220, vrLength);//s.no
            generateVr(doc, 112, 220, vrLength);//prod no
            generateVr(doc, 280, 220, vrLength);//description
            generateVr(doc, 345, 220, vrLength);//lot#
            generateVr(doc, 420, 220, vrLength);//exp date
            generateVr(doc, 472, 220, vrLength);//qty
            generateVr(doc, 580, 220, vrLength);//end
        }
        // generateVr(doc, 450, 500, 630);
        // generateVr(doc, 580, 500, 630);
    }  
    
    function generateVr(doc: any, x: number, y1: number, y2: number) {
        doc
            .strokeColor("#000000")
            .lineWidth(1.3)
            .moveTo(x, y1)
            .lineTo(x, y2)
            .stroke();
    }

    function formatDate(date: any) {
        date = new Date(date)
        const day = date.getDate();
        const month = date.getMonth() + 1;
        const year = date.getFullYear();

        return ("0" + month ).slice(-2) + "/" + ("0" + day).slice(-2) + "/" +year;
    }
  
}