import { histoSConnectionPool } from "../common/db_connection";
import { AttributeDetail, ClientProjects, SMTPDetails } from "../models/invoice_model";
import * as Sql from 'mssql/msnodesqlv8';
import { IResult } from "mssql";
import { PrismaClient } from '@prisma/client';
import { pid } from 'node:process';
import { Constants, Message } from '../common/constants';
const moment = require('moment');
const os = require("os");
const fs = require('fs');
const nodemailer = require('nodemailer');
import { shipmentTrackingSystemConnectionPool } from "../common/db_connection";

import { PDFGenerator } from "./pdf_generator";
import ResponseModel from "../common/response_model";
import { DocumentsDA } from "./documents_data_access";
import { SwabOrderDA } from "./swab_order_data_access";


const prismaSwab = new PrismaClient();
export module InvoiceDataAccess {

    export async function getClientProjectsByClientID(ClientID: number): Promise<ClientProjects[]> {
        return new Promise<ClientProjects[]>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('ClientID', Sql.Int, ClientID)
                request.execute('GetClientProjectsByClientID').then((val: IResult<ClientProjects>) => {
                    resolve(val.recordset);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    export async function getUsBillingPdfPath(): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then(async (_con) => {
                const request = new Sql.Request(_con);
                const result: any = await request.query(`
                    select AD.AttributeValue from attributedetails AD
                    join attributes A on AD.AttributeID = A.AttributeID
                    where A.AttributeName = 'USBillingPath'
                `)
                resolve(result.recordset[0].AttributeValue);
            }).catch((err) => {
                reject(err);
            })
        })
    }

    async function updateUsInvoiceTable(InvoiceNumber: Number, ClientBillingAddressID:Number): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then(async (_con) => {
                const request = new Sql.Request(_con);
                const result: any = await request.query(`
                    UPDATE USInvoices
                    SET ClientBillingAddressID = ${ClientBillingAddressID}
                    WHERE InvoiceNumber = ${InvoiceNumber} 
                `)
                resolve(result);
            }).catch((err) => {
                reject(err);
            })
        })
    }

    export const getUSInvoiceRecord = async (invoiceNo: number) => {
        if (!invoiceNo) {
            return {};
        }
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then(async (_con) => {
                const request = new Sql.Request(_con);
                const result: any = await request.query(`
                    SELECT * FROM USInvoices
                    WHERE InvoiceNumber = ${invoiceNo}
                `);
                resolve(result.recordset.length > 0 ? result.recordset[0] : {});
            }).catch((err) => {
                reject(err);
            });
        });
    }

    export const getClientRecord = async (clientId: number) => {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then(async (_con) => {
                const request = new Sql.Request(_con);
                const result: any = await request.query(`
                    SELECT * FROM Clients
                    WHERE ClientID = ${clientId}
                `);
                resolve(result.recordset.length > 0 ? result.recordset[0] : {});
            }).catch((err) => {
                reject(err);
            });
        });
    }


    export async function createInvoice(requestData: any): Promise<any> {

        try {
            let invoiceReqModel: any;
            let shippingReqModel: any;
            let swabType: any;
            let hostName: string = os.hostname();
            let processId: number = pid;
            let refDocInfo: any = {};
            let invoiceNumber: number = 0;
            invoiceReqModel = requestData.invoiceDetails;
            shippingReqModel = requestData.invoiceAddress;

            const fetchDispatchMasterDetails: any = await prismaSwab.clientSwabDispatchMaster.findUnique({
                where: {
                    DispatchMasterID: Number(requestData.invoiceDetails.DispatchMasterID)
                },
            });

            // Return and Lost Delivery Status restriction to create a invoice
            if (fetchDispatchMasterDetails && (fetchDispatchMasterDetails.DeliveryStatusID === SwabOrderDA.DeliveryStatus.Lost || fetchDispatchMasterDetails.DeliveryStatusID === SwabOrderDA.DeliveryStatus.Return)) {
                const errMsg = `Invoice cannot be created for ${fetchDispatchMasterDetails.DeliveryStatusID === SwabOrderDA.DeliveryStatus.Lost ? "lost" : "returned"} shipments  `
                return new ResponseModel(false, "Can't create invoice: Shipment is lost or returned", { discription: errMsg })
            }

            let usInvoiceNumber = await getUSInvoiceNumber();
            if (usInvoiceNumber.IsAvailUSInvoicesTable != usInvoiceNumber.IsAvailT_InvoiceTable) {
                let errMsg = "There is migration problem with invoice number " + usInvoiceNumber.PresentUSInvoiceNumber + ". Please correct.";
                return new ResponseModel(false, "Invoice number migration problam", { discription: errMsg });
            }

            requestData.invoiceDetails.USInvoiceSaveType = "USinvoice";  // USInvoiceSaveType



            invoiceReqModel.invoiceItems = await constructInvoiceItems(invoiceReqModel);

            let invoiceBulkInsert: any = await bulkUsInvoicedetailsInsert(invoiceReqModel, hostName, processId);

            let PdfPath = await getUsBillingPdfPath();

            if (invoiceBulkInsert != null) {
                let clientBillingAddressId: number;
                if (shippingReqModel.ClientBillingAddressID) {
                    clientBillingAddressId = shippingReqModel.ClientBillingAddressID;
                }
                else {
                    const newInvoiceAddress = await insertAddressbyClientId(shippingReqModel);
                    clientBillingAddressId = newInvoiceAddress.ClientBillingAddressID;
                }
                invoiceNumber = await insertUsInvoiceData(invoiceReqModel, clientBillingAddressId, 0, hostName, processId);
                await updateUsInvoiceTable(invoiceNumber, clientBillingAddressId);
                if (invoiceNumber != undefined && invoiceNumber != null) {
                    let accountStatemetDetails = await getUsInvoiceAccountStatement(invoiceNumber, 0);

                    requestData.invoiceDetails.accountDetails = accountStatemetDetails[7];
                    requestData.invoiceDetails.outstandingBalance = accountStatemetDetails[9];
                    requestData.invoiceDetails.currentInvoice = accountStatemetDetails[11];
                    requestData.invoiceDetails.totalPaymentDue = accountStatemetDetails[13];
                    requestData.invoiceDetails.creditStatement = accountStatemetDetails[15];
                    requestData.invoiceDetails.fileDetails = accountStatemetDetails[19];
                    requestData.invoiceDetails.companyDetails = accountStatemetDetails[3];
                    requestData.invoiceDetails.paymentMethod = accountStatemetDetails[1];

                    if (accountStatemetDetails != undefined && accountStatemetDetails != null) {
                        requestData.invoiceDetails.invoiceNumber = invoiceNumber;
                        let pdfName = "Inv" + String(invoiceNumber) + "_" + invoiceReqModel.ClientName + ".pdf";
                        let pdfBuffer = await PDFGenerator.generateInvoice(requestData, PdfPath); // invoice pdf creation
                        if (pdfBuffer === Message("").unauthorizedPath) {
                            await closeEmail(invoiceNumber, false, { DispatchID: requestData.invoiceDetails.DispatchMasterID });
                            return new ResponseModel(false, "Invoice Creation Failed", { discription: pdfBuffer });
                        }

                        let updateStatus = await updateInvoiceInHistoS(invoiceNumber, pdfName, pdfBuffer);
                        refDocInfo = await savePDFInShippment(pdfBuffer, pdfName, invoiceReqModel.DispatchMasterID);
                    }

                }
            }

            const swabDispatch = await prismaSwab.clientSwabDispatchMaster.findUnique({
                where: {
                    DispatchMasterID: Number(invoiceReqModel.DispatchMasterID),
                },
            });

            if (swabDispatch != null && swabDispatch != undefined) {
                await prismaSwab.clientSwabDispatchMasterAudit.create({ //audit
                    data: swabDispatch,
                });

                const updateRequestDetail = await prismaSwab.clientSwabDispatchMaster.update({
                    where: { DispatchMasterID: Number(invoiceReqModel.DispatchMasterID) },
                    data: {
                        ShipmentandHandlingCost: invoiceReqModel.ShipmentCharges,
                        LastModifiedBy: Number(shippingReqModel.LastModifiedBy),
                        LastModifiedOn: new Date()
                    },
                });
            }

            // const shipmentDetail = await prismaSwab.swabShipmentClients.findUnique({
            //     where: {
            //         ClientShipmentAutoID: Number(shippingReqModel.ClientShipmentAutoID),
            //     }
            // });

            // if (shipmentDetail != null && shipmentDetail != undefined) {
            //     await prismaSwab.swabShipmentClientsAudit.create({ // audit
            //         data: shipmentDetail
            //     });
            // await prismaSwab.swabShipmentClients.update({
            //     where: { ClientShipmentAddressID: Number(shippingReqModel.ClientShipmentAddressID) },
            //     data: {
            //         ClientShipmentAddressID: clientShipmentAddress.ClientShipmentAddressID,
            //         ClientID: Number(shippingReqModel.ClientID),
            //         Notes: shippingReqModel.Notes,
            //         RequestID: Number(shippingReqModel.RequestID),
            //         LastModifiedBy: Number(shippingReqModel.LastModifiedBy),
            //         LastModifiedOn: new Date()
            //     },
            // });
            // }

            return new ResponseModel(true, "Invoice Created", { RefDocID: refDocInfo.RefDocID, invoiceNumber: invoiceNumber, RefType: refDocInfo.RefType, DocumentTypes: refDocInfo.DocumentTypes, DocumentName: refDocInfo.DocumentName });
        }
        catch (err) {
            return new ResponseModel(false, "Invoice Creation Failed", { discription: err });
        }
    }
    export const updateInvoiceNumberDetails = async (dispatchId: number, invoiceNumber: number) => {
        return await prismaSwab.clientSwabDispatchMaster.update({
            where: {
                DispatchMasterID: dispatchId
            },
            data: {
                InvoiceNumber: invoiceNumber
            }
        });
    }

    export async function sendInvoiceEmail(emailInfoReq: any): Promise<any> {

        try {
            let attributesList: AttributeDetail[] = await getAllAttributesByCategory("General");
            let smtpCredentilals: SMTPDetails = {
                smtpUserName: await attributesList.find(data => data.AttributeName === "SMTPUserName")?.AttributeValue,
                smtpPassword: await attributesList.find(data => data.AttributeName === "SMTPPassword")?.AttributeValue,
                smtpMailHost: await attributesList.find(data => data.AttributeName === "SMTPMailHost")?.AttributeValue,
                smtpPort: await attributesList.find(data => data.AttributeName === "SMTPPort")?.AttributeValue
            }
            let notificationDetail: any = {
                histoRecordID: 0,
                histoRecordType: null,
                emailContent: null,
                addedBy: emailInfoReq.userId
            };
            let emailInfo = await getEmailInfoByClientID(emailInfoReq.clientId, emailInfoReq.invoiceNumber);
            let histoRefID = await saveClientNotificationEmail(notificationDetail);
            emailInfoReq.Message += "\n\nHisto Reference ID : " + histoRefID.outputVal + "-" + moment(new Date()).format("YYYY-MM-DD");
            let invoiceDocs: any[] = await DocumentsDA.findDocsByRefTypeID(emailInfoReq.DispatchID, 'Invoice');
            let invoiceDocFilter: any[] = [];
            for (let doc of invoiceDocs) {
                let invoiceAttachment = {
                    filename: doc.DocumentName,
                    content: doc.DocumentContent
                }
                invoiceDocFilter.push(invoiceAttachment);
            }

            let transport = await nodemailer.createTransport({
                host: smtpCredentilals.smtpMailHost,
                port: smtpCredentilals.smtpPort,
                auth: {
                    user: smtpCredentilals.smtpUserName,
                    pass: smtpCredentilals.smtpPassword
                }
            });

            let mailOptions = {
                from: emailInfoReq.From,
                to: emailInfoReq.To.join(),
                cc: emailInfoReq.CC.join(),
                bcc: emailInfoReq.BCC.join(),
                subject: emailInfoReq.Subject,
                text: emailInfoReq.Message,
                attachments: invoiceDocFilter
            };

            try {
                await updateInvioceNumber(emailInfoReq.DispatchID, emailInfoReq.invoiceNumber);
            } catch (error) {
                console.log(error);
                let updateViaSP = await updateInvioceNumber(emailInfoReq.DispatchID, emailInfoReq.invoiceNumber);
            }


            await transport.sendMail(mailOptions, async (error: any, info: any) => {
                if (error) {
                    await deleteUSInvoice(emailInfoReq.invoiceNumber);
                    await deleteInvoicePDFDoc(emailInfoReq.invoiceNumber, "");
                    let delCount = await deletableSwabInvioceDoc(emailInfoReq.DispatchID, 'Invoice');
                    let invoiceNoUpdate = await prismaSwab.clientSwabDispatchMaster.update({
                        where: {
                            DispatchMasterID: emailInfoReq.DispatchID
                        },
                        data: {
                            InvoiceNumber: 0,
                            IsInvoiceRaised: false
                        }
                    });

                }
            });
        } catch (error) {
            console.log(error);
        }


        return new ResponseModel(true, "Invoice created and e-mail sent successfully.");

    }

     async function updateInvioceNumber(DispatchID:number, invoiceNumber: number): Promise<any> {

        return new Promise<any>((resolve, reject) => {
            shipmentTrackingSystemConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('DispatchMasterID', Sql.Int, DispatchID);
                request.input('InvoiceNumber', Sql.BigInt, invoiceNumber);
                request.execute('UpdateInvioceNumber').then((val: IResult<any>) => {
                    resolve(val)
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    export async function closeEmail(invoiceNo: number, emailSendStatus: boolean, requestData: any): Promise<any> {
        let delValue;
        if (emailSendStatus) {
            let invoiceDetails = {
                ItemDescription: requestData.SwabUOM,
                SwabCost: 0,
                ShipmentCharges: 0,
                UnitPrice: 0,
                USInvoiceSaveType: 'USInvoiceSamples',
                DispatchQty: 0
            };
            let shippingDetails = {
                ShippingAddress1: '',
                Address2: '',
                City: '',
                State: '',
                Zip: '',
                Notes: ''
            }
            let hostName: string = os.hostname();
            let processId: number = pid;
            let bulkInsertNonSample = await bulkUsInvoicedetailsInsertNonSample(invoiceDetails, hostName, processId);
            let saveInvoiceNonSample = await insertUsInvoiceDataNonSample(invoiceDetails, shippingDetails, invoiceNo, hostName, processId);
            const invoiceRecord: any = await histoSConnectionPool.connect().then(async (_con) => {
                const request = new Sql.Request(_con);
                return await request.query(`
                    SELECT PaymentStatus FROM USInvoices
                    WHERE InvoiceNumber = ${invoiceNo}
                `);
            });
            await updateUSInvoiceSentStatus(invoiceNo, invoiceRecord.recordset[0].PaymentStatus, 0);
            await deleteInvoicePDFDoc(invoiceNo, "");

        } else {
            let delpdfInPath = await deleteInvoicePDFDoc(invoiceNo, "");
            let delCount = await deletableSwabInvioceDoc(requestData.DispatchID, 'Invoice');
            delValue = await deleteUSInvoice(invoiceNo);
        }

        // if (delValue.Identity == 1 || delValue.Identity > 0) {
        return new ResponseModel(true, "Invoice details reverted successfully");
        // } else {
        //     return new ResponseModel(true, "Invoice not found");
        // }
    }

    async function constructInvoiceItems(invoiceDetails: any): Promise<any> {
        let invoiceItems: any[] = [];
        if (invoiceDetails.ShipmentCharges == undefined || invoiceDetails.ShipmentCharges == null || invoiceDetails.ShipmentCharges == "") {
            invoiceDetails.ShipmentCharges = Number(0);
        }
        let dispatchDetails: any = await prismaSwab.clientSwabDispatchDetails.findMany({
            where: {
                DispatchMasterID: Number(invoiceDetails.DispatchMasterID)
            }, include: {
                ClientSwabRequestDetails: true,
                ClientSwabDispatchMaster: true
            }
        });
        let i = 0;
        for (let dispatchDetail of dispatchDetails) {
            let swabDetails: any = await prismaSwab.swabUOM.findUnique({
                where: {
                    SwabUOMID: dispatchDetail.ClientSwabRequestDetails.SwabUOMID
                }
            });
            const description = `${swabDetails.Description}_${moment(dispatchDetail.ClientSwabDispatchMaster.DispatchDate).format("MM/DD/YYYY")}_Tracking#${dispatchDetail.ClientSwabDispatchMaster.ShippingTrackingNumber}`;
            const swabType = swabDetails?.SwabUOM;
            const index = invoiceItems.findIndex(val => (val.UnitPrice === dispatchDetail.ClientSwabRequestDetails.SwabPricePerUnit && val.SwabUOM === swabType && val.Description === description))
            if (index >= 0) {
                invoiceItems[index] = {
                    ...invoiceItems[index],
                    DispatchQty: invoiceItems[index].DispatchQty + dispatchDetail.DispatchQty,
                    totalAmount: dispatchDetail.ClientSwabRequestDetails.SwabPricePerUnit * (invoiceItems[index].DispatchQty + dispatchDetail.DispatchQty)
                }
            }
            else {
                invoiceItems[i] = {
                    SwabUOM: swabType,
                    UnitPrice: dispatchDetail.ClientSwabRequestDetails.SwabPricePerUnit,
                    DispatchQty: dispatchDetail.DispatchQty,
                    totalAmount: dispatchDetail.ClientSwabRequestDetails.SwabPricePerUnit * dispatchDetail.DispatchQty,
                    Description: description,
                }
                i++;
            }
        }
        // Swab Cost change 
        if (invoiceItems.length > 0) {
            let totalAmount: number = invoiceItems.reduce((total: number, val) => total + val.totalAmount, 0);
            totalAmount = +totalAmount.toFixed(2);
            const swabCost: number = +Number(invoiceDetails.SwabCost).toFixed(2);
            if (swabCost > 0 && totalAmount !== swabCost) {
                invoiceItems = invoiceItems.map((val, i) => ({ ...val, totalAmount: i === 0 ? Number(invoiceDetails.SwabCost) : 0 }));
            }
        }

        if (invoiceDetails.ShipmentCharges > 0) {
            invoiceItems[i++] = {
                Description: `Shipment and Handling Charges_Tracking#${dispatchDetails[0].ClientSwabDispatchMaster.ShippingTrackingNumber}`,
                UnitPrice: Number(invoiceDetails.ShipmentCharges),
                DispatchQty: 1,
                totalAmount: Number(invoiceDetails.ShipmentCharges)
            }
        }

        return invoiceItems;
    }

    async function deleteInvoicePDFDoc(invoiceNo: number, docType: string) {
        let usInvoiceDocs = await getUSInvoiceDocumentDetails(invoiceNo, docType);
        let PdfPath = await getUsBillingPdfPath();
        if (usInvoiceDocs != null) {
            for (let doc of usInvoiceDocs) {
                let filePath = PdfPath + "\\" + doc.USInvocieName
                fs.unlink(filePath, function (err: any) {
                });
            }
        }
    }

    async function deletableSwabInvioceDoc(reftypeId: number, refType: string) {

        try {
            const refDocsId: any[] = await prismaSwab.referenceDocuments.findMany({
                where: {
                    RefTypeID: Number(reftypeId),
                    RefType: refType
                },
                select: {
                    RefDocID: true
                },
            });
            let refDocIdFilter: number[] = [];
            for (let refId of refDocsId) {
                refDocIdFilter.push(Number(refId.RefDocID));
            }
            const delCount = await prismaSwab.referenceDocuments.deleteMany({
                where: {
                    RefDocID: {
                        in: refDocIdFilter
                    }
                }
            });
            return delCount;
        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal server error", error);
        }

    }
    async function updateUSInvoiceSentStatus(invoiceNo: number, paymentStatus: string, creditAmount: number) {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('invoiceNumber', Sql.BigInt, invoiceNo);
                request.input('PaymentStatus', Sql.VarChar, paymentStatus);
                request.input('CreditAmount', Sql.Numeric, creditAmount);
                request.output('status', Sql.VarChar);

                request.execute('UpdateUSInvoiceSentStatus').then((val: IResult<any>) => {
                    resolve(val.output);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    async function deleteUSInvoice(invoiceNo: number): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('USInvoiceNumber', Sql.Int, invoiceNo)
                request.output('Identity', Sql.Int)

                request.execute('DeleteUSInvoice').then((val: IResult<any>) => {
                    resolve(val.output);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    async function getUSInvoiceDocumentDetails(invoiceNo: number, docType: string): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('InvoiceID', Sql.BigInt, invoiceNo)
                request.input('documentType', Sql.VarChar, docType)

                request.execute('GetUSInvoiceDocumentDetails').then((val: IResult<any>) => {
                    resolve(val.recordset);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    async function saveClientNotificationEmail(notificationDetail: any): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('histoRecordID', Sql.Int, notificationDetail.histoRecordID);
                request.input('histoRecordType', Sql.VarChar, notificationDetail.histoRecordType);
                request.input('emailContent', Sql.VarBinary, notificationDetail.emailContent);
                request.input('addedBy', Sql.Int, notificationDetail.addedBy);
                request.input('addedOn', Sql.DateTime, new Date());
                request.output('outputVal', Sql.Int, 0);

                request.execute('SaveClientNotificationEmail').then((val: IResult<any>) => {
                    resolve(val.output);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }
    async function getAllAttributesByCategory(category: string): Promise<AttributeDetail[]> {
        return new Promise<AttributeDetail[]>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('Category', Sql.VarChar, category)
                request.execute('GetAllAttributesByCategory').then((val: IResult<AttributeDetail>) => {
                    resolve(val.recordset);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    async function savePDFInShippment(pdfBuffer: any, docName: string, dispatchID: number): Promise<any> {
        let saveDoc = await prismaSwab.referenceDocuments.create({
            data: {
                RefType: 'Invoice',
                RefTypeID: dispatchID,
                DocumentTypeID: 1,
                DocumentContent: pdfBuffer,
                DocumentName: docName
            },
            include: {
                DocumentTypes: true
            }
        });
        return saveDoc;
    }


    export async function updateInvoiceInHistoS(invoiceNo: number, invoiceName: string, pdfBinary: any) {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('invoiceNumber', Sql.BigInt, invoiceNo)
                request.input('invoiceName', Sql.VarChar, invoiceName)
                request.input('invoiceImage', Sql.VarBinary, pdfBinary)
                request.input('documentType', Sql.VarChar, 'Invoice')
                request.output('status', Sql.VarChar, '')
                request.input('isDoAudit', Sql.Bit, 0)
                request.input('USinvoiceIDSer', Sql.BigInt, 0)

                request.execute('UpdateUSInvoiceDocuments').then((val: IResult<any>) => {
                    resolve(val.output.status);
                }).catch((err: Sql.MSSQLError) => {
                    console.log(err);
                    reject(err.message);
                });
            });
        });
    }

    export async function getEmailInfoByClientID(clientId: number, invoiceNo: number): Promise<any> {
        let clientInfo = await getClientDetailsByClientID(clientId);
        let emailInfo = {
            From: Constants.FROM_MAIL,
            To: clientInfo[0].ToEmail.split(";"),
            CC: clientInfo[0].CCEmail.split(";"),
            BCC: Constants.BCC_MAIL,
            Subject: Constants.MAIL_SUBJECT + invoiceNo,
            Message: Constants.MAIL_BODY,
            Tittle: Constants.MAIL_TITLE
        }
        return emailInfo;
    }

    async function getClientDetailsByClientID(clientId: number): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('ClientID', Sql.Int, Number(clientId));

                request.execute('GetClientDetailsByClientID').then((val: IResult<any>) => {
                    resolve(val.recordsets[0]);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    function getUsInvoiceAccountStatement(usInvoiceNuber: number, usInvoiceId: number): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('USInvoiceNumber', Sql.Int, Number(usInvoiceNuber));
                request.input('USInvoiceID', Sql.Int, Number(usInvoiceId));

                request.execute('GetAccountStatementForInvoiceNumber').then((val: IResult<any>) => {
                    resolve(val.recordsets);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }
    function getUSInvoiceNumber(): any {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('PresentUSInvoiceNumber', Sql.Int, Number(0))
                request.execute('GetUSInvoiceNumberForEdit').then((val: IResult<any>) => {
                    resolve(val.recordset[0]);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    async function bulkUsInvoicedetailsInsert(invoiceDetails: any, hostName: string, processId: number): Promise<any> {
        if (invoiceDetails.ShipmentCharges == undefined || invoiceDetails.ShipmentCharges == null || invoiceDetails.ShipmentCharges == "") {
            invoiceDetails.ShipmentCharges = Number(0);
        }

        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const table = new Sql.Table("BulkInsertUSInvoiceDetails");
                table.create = true;
                table.columns.add('ItemNumber', Sql.Int);
                table.columns.add('ItemDescription', Sql.VarChar);
                table.columns.add('HLABillingCategory', Sql.VarChar);
                table.columns.add('GeneGroupName', Sql.VarChar);
                table.columns.add('TATDays', Sql.VarChar);
                table.columns.add('Rate', Sql.Numeric);
                table.columns.add('Quantity', Sql.Int);
                table.columns.add('TotalAmount', Sql.Numeric);
                table.columns.add('PCName', Sql.VarChar);
                table.columns.add('ProcessID', Sql.BigInt);
                table.columns.add('USInvoiceSaveType', Sql.VarChar);
                table.columns.add('FCType', Sql.VarChar);
                table.columns.add('FCERate', Sql.Money, { nullable: false });
                table.columns.add('FCAmount', Sql.Money);
                table.columns.add('HLAResolutionCode', Sql.VarChar);
                table.columns.add('FCRate', Sql.Money);
                table.columns.add('C1Requested', Sql.VarChar(1));
                table.columns.add('C2Requested', Sql.VarChar(1));

                let totalAmount = +parseFloat(invoiceDetails.SwabCost).toFixed(2) + +parseFloat(invoiceDetails.ShipmentCharges).toFixed(2);

                for (let invoiceItem of invoiceDetails.invoiceItems) {
                    if (invoiceDetails.SwabCost == "" || invoiceDetails.SwabCost == 0) {
                        if (invoiceItem.SwabUOM == Constants.Buccal_Swab_Kit || invoiceItem.SwabUOM == Constants.FLOQSwabs) {
                            invoiceItem.totalAmount = 0;
                        }
                    }
                    table.rows.add(0, invoiceItem.SwabUOM, null, null, null, parseFloat(invoiceItem.UnitPrice), Number(invoiceItem.DispatchQty), invoiceItem.totalAmount, hostName, processId, invoiceDetails.USInvoiceSaveType, null, 0, 0, null, 0, " ", " ");
                }

                const request = new Sql.Request(_con);

                request.bulk(table, (err, result) => {
                    if (result != undefined) {
                        resolve(result);
                    } else {
                        console.log(err);
                        reject(err);
                    }
                });
            });
        });
    }

    function insertUsInvoiceData(invoiceReqModel: any, clientBillingAddressId: any, usInvoiceNumber: number, hostName: string, processId: number): Promise<any> {

        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('clientID', Sql.Int, Number(invoiceReqModel.ClientID))
                request.input('clientProjectID', Sql.Int, Number(invoiceReqModel.ClientProjectID))
                request.input('subClientID', Sql.Int, 0)
                request.input('invoiceType', Sql.VarChar, 'BS')
                request.input('loginUserID', Sql.Int, Number(invoiceReqModel.LastModifiedBy))
                request.input('classWiseBilling', Sql.Bit, 0)
                request.input('pcName', Sql.VarChar, hostName)
                request.input('processID', Sql.BigInt, processId)
                request.input('invoiceNumber', Sql.BigInt, usInvoiceNumber)
                request.output('identity', Sql.BigInt, 0)
                request.input('clientBillingAddress', Sql.VarChar, clientBillingAddressId.toString())
                //request.input('Remarks', Sql.VarChar, shippingReqModel.Notes)
                request.input('USInvoicePOInfo', Sql.VarChar, invoiceReqModel.PoNumber)
                request.input('ClientCustomAttributeDetailID', Sql.Int, 0)
                request.input('BillingFormatID', Sql.Int, 1)
                request.input('SourceProgram', Sql.VarChar, Constants.SOURCE_PROGRAM)
                // let sp_string = "exec GenerateUSInvoiceNEW " + invoiceReqModel.ClientID + "," + invoiceReqModel.ClientProjectID + "," + 0 + "," + "BS" + "," + invoiceReqModel.LastModifiedBy + "," + 0 + "," + hostName + "," + processId + "," + 0 + "," + 0 + "," + concatClientAddress + "," + shippingReqModel.Notes + "," + invoiceReqModel.PoNumber + "," + 0 + "," + 1;
                //console.log(sp_string);

                request.execute('GenerateUSInvoiceNEW').then((val: IResult<any>) => {
                    resolve(val.output.identity);
                }).catch((err: Sql.MSSQLError) => {
                    console.log(err);
                    reject(err.message);
                });
            });
        });
    }



    async function bulkUsInvoicedetailsInsertNonSample(invoiceDetails: any, hostName: string, processId: number): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const table = new Sql.Table("BulkInsertUSInvoiceDetails");
                table.create = true;
                table.columns.add('ItemNumber', Sql.Int);
                table.columns.add('ItemDescription', Sql.VarChar);
                table.columns.add('HLABillingCategory', Sql.VarChar);
                table.columns.add('GeneGroupName', Sql.VarChar);
                table.columns.add('TATDays', Sql.VarChar);
                table.columns.add('Rate', Sql.Numeric);
                table.columns.add('Quantity', Sql.Int);
                table.columns.add('TotalAmount', Sql.Numeric);
                table.columns.add('PCName', Sql.VarChar);
                table.columns.add('ProcessID', Sql.BigInt);
                table.columns.add('USInvoiceSaveType', Sql.VarChar);
                table.columns.add('FCType', Sql.VarChar);
                table.columns.add('FCERate', Sql.Money, { nullable: false });
                table.columns.add('FCAmount', Sql.Money);
                table.columns.add('HLAResolutionCode', Sql.VarChar);
                table.columns.add('FCRate', Sql.Money);
                table.columns.add('C1Requested', Sql.VarChar(1));
                table.columns.add('C2Requested', Sql.VarChar(1));

                let totalAmount = +parseFloat(invoiceDetails.SwabCost).toFixed(2) + +parseFloat(invoiceDetails.ShipmentCharges).toFixed(2);

                table.rows.add(0, invoiceDetails.ItemDescription, null, null, null, 0, 0, 0, hostName, processId, invoiceDetails.USInvoiceSaveType, null, 0, 0, null, 0, " ", " ");

                const request = new Sql.Request(_con);

                request.bulk(table, (err, result) => {
                    if (result != undefined) {
                        resolve(result);
                    } else {
                        console.log(err);
                        reject(err);
                    }
                });
            });
        });
    }

    function insertUsInvoiceDataNonSample(invoiceReqModel: any, shippingReqModel: any, usInvoiceNumber: number, hostName: string, processId: number): Promise<any> {

        let addressArray: string[] = [shippingReqModel.ShippingAddress1, shippingReqModel.Address2, shippingReqModel.City, shippingReqModel.State, shippingReqModel.Zip];
        let concatClientAddress: string = addressArray.join(";");

        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('clientID', Sql.Int, Number(invoiceReqModel.ClientID))
                request.input('clientProjectID', Sql.Int, Number(invoiceReqModel.ClientProjectID))
                request.input('subClientID', Sql.Int, 0)
                request.input('invoiceType', Sql.VarChar, 'BS')
                request.input('loginUserID', Sql.Int, Number(invoiceReqModel.LastModifiedBy))
                request.input('classWiseBilling', Sql.Bit, 0)
                request.input('pcName', Sql.VarChar, hostName)
                request.input('processID', Sql.BigInt, processId)
                request.input('invoiceNumber', Sql.BigInt, usInvoiceNumber)
                request.output('identity', Sql.BigInt, 0)
                request.input('clientBillingAddress', Sql.VarChar, "")
                request.input('Remarks', Sql.VarChar, "")
                request.input('USInvoicePOInfo', Sql.VarChar, "")
                request.input('ClientCustomAttributeDetailID', Sql.Int, 0)
                request.input('BillingFormatID', Sql.Int, 1)

                request.execute('GenerateUSInvoiceNEW').then((val: IResult<any>) => {
                    resolve(val.output.identity);
                }).catch((err: Sql.MSSQLError) => {
                    console.log(err);
                    reject(err.message);
                });
            });
        });
    }

    export async function getClientAddress(clientId: Number): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then(async (_con) => {
                const request = new Sql.Request(_con);
                const result: any = await request.query(`
                    select * from ClientBillingAddress where ClientID=${clientId} And status=1 order by IsitDefault desc
                `)
                resolve(result.recordsets[0]);
            }).catch((err) => {
                reject(err);
            })
        })
    }

    export const refreshInvoiceDetails = async (dispatchMasterId: number) => {
        const dispatchMasterDetails = await prismaSwab.clientSwabDispatchMaster.findUnique({
            where: {
                DispatchMasterID: dispatchMasterId
            }
        });
        if (dispatchMasterDetails) {

            if (("IsInvoiceRaised" in dispatchMasterDetails) && dispatchMasterDetails.IsInvoiceRaised && ("InvoiceNumber" in dispatchMasterDetails) && dispatchMasterDetails.InvoiceNumber) {
                const invoiceNumber: number = await Number(dispatchMasterDetails.InvoiceNumber);
                const invoiceDetails: any = await getUSInvoiceRecord(invoiceNumber);
                // ValidityStatus = 1 - 'Valid'  or  ValidityStatus = 0 - 'Cancelled'
                if (invoiceDetails && Object.keys(invoiceDetails).length > 0) {
                    if (("ValidityStatus" in invoiceDetails) && invoiceDetails.ValidityStatus)
                        return new ResponseModel(false, `Please verify that Invoice #${invoiceNumber} has not been cancelled, as it is currently still active.`);

                    const tempDispatchMasterId = await Number(dispatchMasterDetails.DispatchMasterID);
                    if (tempDispatchMasterId && invoiceNumber) {
                        const referenceDocumentDetails = await prismaSwab.referenceDocuments.findFirst({
                            where: {
                                RefTypeID: tempDispatchMasterId,
                                RefType: Constants.INVOICE_REF_TYPE,
                                DocumentName: {
                                    startsWith: `Inv${invoiceNumber}`
                                }
                            }
                        });
                        if (referenceDocumentDetails && ("RefDocID" in referenceDocumentDetails)) {
                            await Promise.all([
                                prismaSwab.referenceDocuments.delete({
                                    where: {
                                        RefDocID: referenceDocumentDetails.RefDocID
                                    }
                                }),
                                prismaSwab.cancelInvoiceDetails.create({
                                    data: {
                                        DispatchMasterID: tempDispatchMasterId,
                                        InvoiceNumber: invoiceNumber
                                    }
                                }),
                                prismaSwab.clientSwabDispatchMaster.update({
                                    where: {
                                        DispatchMasterID: tempDispatchMasterId,
                                    },
                                    data: {
                                        IsInvoiceRaised: false,
                                        InvoiceNumber: 0
                                    }
                                })
                            ]);
                            return await new ResponseModel(true, `Invoice #${invoiceNumber} has been reverted successfully`);
                        }
                    }

                    return await new ResponseModel(false, `Invoice document not found in the ReferenceDocuments table`);
                }
                return await new ResponseModel(false, `No invoice has been created for this record. `);
            }
            return await new ResponseModel(false, `The requested invoice record could not be found`);

        } else {
            return new ResponseModel(false, `Records not found. Please check the given id #${dispatchMasterId}.`)
        }
    }

    export async function getClientAddressFromBillingAddressId(clientBillingAddressId: Number): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then(async (_con) => {
                const request = new Sql.Request(_con);
                const result: any = await request.query(`
                    select * from ClientBillingAddress where ClientBillingAddressID=${clientBillingAddressId}
                `)
                resolve(result.recordset.length > 0 ? result.recordset[0] : {});
            }).catch((err) => {
                reject(err);
            })
        })
    }

    export async function insertAddressbyClientId(data: any): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then(async (_con) => {
                const request = new Sql.Request(_con);
                const results: any = await request.query(`
                    INSERT INTO ClientBillingAddress (
                        ClientID,
                        BillToName, 
                        BillToAdditionalName, 
                        BillToAddress1,
                        BillToAddress2,
                        BillToCity,
                        BillToState,
                        BillToPostalCode,
                        BillToCountry,
                        OtherDetail1,
                        OtherDetail2,
                        OtherDetail3,
                        status,
                        IsitDefault,
                        ActivedDate,
                        ActivatedBy
                    )
                    OUTPUT INSERTED.*
                    VALUES (
                        ${Number(data.ClientID)},
                        '${data.billToName}', 
                        '${data.billToAdditionalName}', 
                        '${data.billToAddress1}',
                        '${data.billToAddress2}',
                        '${data.billToCity}',
                        '${data.billToState}',
                        '${data.billToPostalCode}',
                        '${data.billToCountry}',
                        '${data.otherDetail1}',
                        '${data.otherDetail2}',
                        '${data.otherDetail3}',
                        '${true}',
                        '${false}',
                        '${data.activedDate}',
                        '${data.LastModifiedBy}'
                    )
                `);
                resolve(results.recordset[0]);
            }).catch((err) => {
                reject(err);
            })
        })

    }//
}