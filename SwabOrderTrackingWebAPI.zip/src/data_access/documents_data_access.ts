import { DocumentTypes as DocumentType, PrismaClient } from '@prisma/client';
import ResponseModel from '../common/response_model';
import { InvoiceDataAccess } from './invoice_data_access';

const prismaSwab = new PrismaClient();
export module DocumentsDA {

    export async function getFileTypes(): Promise<DocumentType[]> {
        return await prismaSwab.documentTypes.findMany();
    }

    export async function documentUplaod(document: any) {

        let saveDoc: any[] = new Array();
        let requestBody = document.body;
        let requestFiles = document.files;

        try {
            let fileTypes: any = await getFileTypes();

            for (let i = 0; i < requestFiles.length; i++) {

                if (requestBody.RefDocID == undefined || requestBody.RefDocID == null || requestBody.RefDocID == 0 || requestBody.RefDocID == "") {
                    let fileExtention = requestFiles[i].originalname.split(".").pop();

                    let fileType = fileTypes.filter(function (file: any) {
                        return file.DocumentName.toUpperCase() === fileExtention.toUpperCase()
                    });

                    saveDoc[i] = await prismaSwab.referenceDocuments.create({
                        data: {
                            RefType: requestBody.RefType,
                            RefTypeID: Number(requestBody.RefTypeID),
                            DocumentTypeID: Number(fileType[0].DocumentTypeID),
                            DocumentContent: requestFiles[i].buffer,
                            DocumentName: requestFiles[i].originalname
                        }
                    });

                    if (requestBody.invoiceNumber != undefined && requestBody.invoiceNumber != null && requestBody.invoiceNumber > 0 && requestBody.RefType == 'Invoice' || requestBody.RefType == 'invoice') {
                        let saveInHistS = await InvoiceDataAccess.updateInvoiceInHistoS(requestBody.invoiceNumber, requestFiles[i].originalname, requestFiles[i].buffer);
                    }
                }
            }
            return new ResponseModel(true, "File uploaded successfully");
        } catch (error) {
            console.log(error);
            return new ResponseModel(true, "File upload error", error);
        }

    }

    export async function deleteDocById(docId: any): Promise<ResponseModel> {

        try {
            const document = await prismaSwab.referenceDocuments.findUnique({
                where: { RefDocID: Number(docId) },
            });
            if (document != null && document != undefined) {
                await prismaSwab.referenceDocumentsAudit.create({
                    data: document
                });
                const deleteDoc = await prismaSwab.referenceDocuments.delete({
                    where: {
                        RefDocID: Number(docId),
                    },
                });
                return new ResponseModel(true, "Reference doc deleted successfully");
            } else {
                return new ResponseModel(false, "File not found");
            }

        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "File delete error", error);
        }

    }
    export async function deleteDocuments(docs: any): Promise<ResponseModel> {
        try {
            for (let i = 0; i < docs.length; i++) {
                await prismaSwab.referenceDocuments.delete({
                    where: {
                        RefDocID: Number(docs[i])
                    },
                });
            }
            return new ResponseModel(true, "Reference doc deleted successfully");
        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "File delete error", error);
        }
    }
    
    export async function findDocByRefDocID(RefDocID: any): Promise<any> {
        try {
            const refDocs: any = await prismaSwab.referenceDocuments.findUnique({
                where: {
                    RefDocID: Number(RefDocID)
                },
                include: {
                    DocumentTypes: true
                },
            });

            return refDocs;

        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal server error", error);
        }
    }
    export async function findDocsByRefTypeID(RefTypeID: any, RefType: any): Promise<any> {
        try {
            const refDocs: any[] = await prismaSwab.referenceDocuments.findMany({
                where: {
                    RefTypeID: Number(RefTypeID),
                    RefType: RefType
                },
                include: {
                    DocumentTypes: true
                },
            });

            return refDocs;

        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal server error", error);
        }
    }
    export async function getDocsInfo(RefTypeID: any, RefType: any): Promise<any> {
        try {
            const refDocs: any[] = await prismaSwab.referenceDocuments.findMany({
                where: {
                    RefTypeID: Number(RefTypeID),
                    RefType: RefType
                },
                select: {
                    RefDocID: true,
                    RefType: true,
                    DocumentName: true,
                    DocumentTypes:{
                        select:{
                            DocumentName: true
                        }
                    }
                },
            });

            return refDocs;

        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal server error", error);
        }
    }

    export async function getDispatchDocsInfo(RefTypeID: any): Promise<any> {
        try {
            const refDocs: any[] = await prismaSwab.referenceDocuments.findMany({
                where: {
                    RefTypeID: Number(RefTypeID),
                },
                select: {
                    RefDocID: true,
                    RefType: true,
                    DocumentName: true,
                    DocumentTypes:{
                        select:{
                            DocumentName: true
                        }
                    }
                },
            });

            return refDocs;

        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal server error", error);
        }
    }
}