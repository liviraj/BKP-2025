//import { format } from "path";
import ResponseModel from "../common/response_model";
import { SwabOrderDA } from "./swab_order_data_access";
import { TrackingSystemDA } from "./tracking_system_data_access";

const { PrismaClient } = require('@prisma/client');
const prismaSwab = new PrismaClient();
const moment = require('moment');

export module InventoryDA {

    export async function getSwabInventoryData(filters: any): Promise<any> {
        try {

            if (filters.InventoryPeriod === "All") {
                filters.FromDate = "01-01-2015";
                filters.ToDate = moment().endOf('day').format("MM/DD/YYYY, h:mm:ss a");
            }
            else {
                filters.ToDate = moment(filters.ToDate);
            }
            //filters.ToDate.setDate(filters.ToDate.getDate() + 1);
            let inventoryList: any;
            let formatFromDate = moment(filters.FromDate).format();
            let formateToDate = moment(filters.ToDate).format();
            let swabInventoryList : any[] = [];
            let vendorId = Number(filters.VendorID) === 0 ? undefined : Number(filters.VendorID);
            let clientId = Number(filters.ClientID) === 0 ? undefined : Number(filters.ClientID);
            let poNumber = filters.PONumber === "All" ? undefined : filters.PONumber;
            let isSwabPurchase = clientId && !poNumber ? false : true;
            let isSwabDispatch = !clientId && (vendorId || poNumber) ? false : true;

            inventoryList = await prismaSwab.SwabInventoryLedger.findMany({
                where: {
                    TransactionDate: {
                        lte: formateToDate,
                        gte: formatFromDate,
                    },
                },
                select: {
                    TransactionDate: true,
                    TransactionType: true,
                    TransactionTypeID: true
                }

            });
            for (let i = 0; i < inventoryList.length; i++) {
                if (inventoryList[i].TransactionType === "P" && isSwabPurchase) {
                    inventoryList[i].LotNumber = [];
                    let swabPurchaseMasterList = await prismaSwab.SwabPurchaseMaster.findFirst({
                        where: {
                            PurchaseMasterID: inventoryList[i].TransactionTypeID,
                            VendorID: vendorId,
                            PONumber: poNumber
                        },
                        include: {
                            Vendors: true
                        }
                    });
                    if (swabPurchaseMasterList && Object.keys(swabPurchaseMasterList).length > 0) {
                        let SwabPurchaseDetailsList = await prismaSwab.SwabPurchaseDetails.groupBy({
                            by: ['PurchaseMasterID'],
                            where: {
                                PurchaseMasterID: swabPurchaseMasterList.PurchaseMasterID,
                            },
                            _sum: {
                                NumberOfSwabs: true,
                            }
                        });
                        swabInventoryList = [...swabInventoryList, { TransactionDate: swabPurchaseMasterList.PurchaseDate, Description: swabPurchaseMasterList.Comments.trim() === '' ? 'Swab Purchase' : `Swab Purchase - ${swabPurchaseMasterList.Comments}`, VCName: swabPurchaseMasterList.Vendors.VendorName, VCid: swabPurchaseMasterList.VendorID, PONumber: swabPurchaseMasterList.PONumber, SwabPurchased: SwabPurchaseDetailsList && SwabPurchaseDetailsList.length > 0 && SwabPurchaseDetailsList[0]._sum.NumberOfSwabs, SwabDispatched: "", TransactionType: 'P' }];
                    }
                } else if (inventoryList[i].TransactionType === "D" && isSwabDispatch) {
                    let swabMasterDetails = await prismaSwab.ClientSwabDispatchMaster.findFirst({
                        where: {
                            DispatchMasterID: inventoryList[i].TransactionTypeID,
                            ClientID: clientId
                        },
                        include:{
                            ClientSwabDispatchDetails: true
                        }
                    });
                    if (swabMasterDetails && Object.keys(swabMasterDetails).length > 0) {
                        let swabShipmentClients = await prismaSwab.SwabShipmentClients.findFirst({
                            where: {
                                RequestID: swabMasterDetails.ClientSwabDispatchDetails[0].RequestID
                            }
                        });
                        let ClientData = await TrackingSystemDA.getClientById(swabMasterDetails.ClientID);
                        let swabDispatched = swabMasterDetails.ClientSwabDispatchDetails.reduce((sum: any, obj: any) =>{ return sum + Number(obj.DispatchQty)},0);
                        swabInventoryList = [...swabInventoryList, { TransactionDate: swabMasterDetails.DispatchDate, Description: !swabShipmentClients.Notes || swabShipmentClients.Notes.trim() === '' ? swabDispatched <= 0 ? 'Swab Dispatch Returned' : 'Swab Dispatch' : `${swabDispatched <= 0 ?  'Swab Dispatch Returned' : 'Swab Dispatch'} - ${swabShipmentClients.Notes}`, VCName: ClientData.ClientName, VCid: swabMasterDetails.ClientID, PONumber: "", SwabPurchased: "", SwabDispatched: swabDispatched, TransactionType: 'D' }];
                    }
                }
            }
            let swabPurchased = 0, swabDispatched = 0, balance = 0;
            for (let i = 0; i < swabInventoryList.length; i++) {
                swabInventoryList[i].TransactionType === 'D' ? swabDispatched += Number(swabInventoryList[i].SwabDispatched) : swabPurchased += Number(swabInventoryList[i].SwabPurchased);
            }
            balance = swabPurchased - swabDispatched;
            return new ResponseModel(true, "Record Found", { SwabInventory: swabInventoryList, Balance: balance > 0 ? balance : 0 });
        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal Server Error", error);
        }
    }
    export const getFilteredLotNumber = async (): Promise<any> => {
        try {
            let lotFilterRecord = await prismaSwab.SwabInventoryLotBalance.findMany({
                where: {
                    AvailableSwabs: { gt: 0, }
                },
                select: {
                    LotNumber: true,
                    AvailableSwabs: true
                }
            });
            return new ResponseModel(true, "Record Found", lotFilterRecord);
        }
        catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal Server Error", error);
        }
    }
    export const FilterLotNumber = async (): Promise<any> => {
        try {
            let lotFilterRecord = await prismaSwab.SwabInventoryLotBalance.findMany({
                select: {
                    LotNumber: true,
                    AvailableSwabs: true
                }
            });
            for (let i = 0; lotFilterRecord.length > i; i++) {
                let boxIdRecord = await SwabOrderDA.getBoxIdByLotnumber(lotFilterRecord[i].LotNumber);
                lotFilterRecord[i].BoxID = boxIdRecord.success ? boxIdRecord.data.BoxID : [];
            }
            return new ResponseModel(true, "Record Found", lotFilterRecord);
        }
        catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal Server Error", error);
        }
    }
    export const getFilteredVCNumber = async ():  Promise<any> => {
        try {
            let vcNames : any[] = [];
           let inventoryList = await prismaSwab.SwabInventoryLedger.findMany({
                select: {
                    TransactionDate: true,
                    TransactionType: true,
                    TransactionTypeID: true
                }
            });
            if(inventoryList.length > 0){
                for (let i = 0; i < inventoryList.length; i++) {
                    if (inventoryList[i].TransactionType === "P") {
                        inventoryList[i].LotNumber = [];
                        let swabPurchaseMasterList = await prismaSwab.SwabPurchaseMaster.findFirst({
                            where: {
                                PurchaseMasterID: inventoryList[i].TransactionTypeID
                            },
                            include: {
                                Vendors: true
                            }
                        });
                        if(Object.keys(swabPurchaseMasterList).length > 0){
                            vcNames = [...vcNames, { VCName: swabPurchaseMasterList.Vendors.VendorName, VCid: vcNames.length+1, VendorID: swabPurchaseMasterList.VendorID   }];
                        }
                    }
                    else if (inventoryList[i].TransactionType === "D") {
                        let swabMasterDetails = await prismaSwab.ClientSwabDispatchMaster.findFirst({
                            where: {
                                DispatchMasterID: inventoryList[i].TransactionTypeID
                            }
                        });
                        if (swabMasterDetails && Object.keys(swabMasterDetails).length > 0) {
                            let ClientData = await TrackingSystemDA.getClientById(swabMasterDetails.ClientID);
                            vcNames = [...vcNames, { VCName: ClientData.ClientName, VCid: vcNames.length+1, ClientID: swabMasterDetails.ClientID  }];
                        }
                    }
                }
            }
            return new ResponseModel(true, "Record Found", vcNames.filter((val, index, self) => index === self.findIndex(n => n.VCName === val.VCName && (("VendorID" in val) && n.VendorID === val.VendorID) || ("ClientID" in val) && n.ClientID === val.ClientID)));
        }
        catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal Server Error", error);
        }
    }
    export const getFilteredPONumber = async ():  Promise<any> => {
        try {
            let swabPurchaseRecords: any[] = [];
           let inventoryList: any[] = await prismaSwab.SwabInventoryLedger.findMany({
                select: {
                    TransactionDate: true,
                    TransactionType: true,
                    TransactionTypeID: true
                }
            });
            for (let i = 0; i < inventoryList.length; i++) {
                if (inventoryList[i].TransactionType === "P") {
                    let swabPurchaseMasterList = await prismaSwab.SwabPurchaseMaster.findFirst({
                        where: {
                            PurchaseMasterID: inventoryList[i].TransactionTypeID,
                            NOT: {
                                PONumber: ""
                            }
                        },
                        select:{
                            PONumber: true
                        }
                    });
                    swabPurchaseRecords = swabPurchaseMasterList ? [ ...swabPurchaseRecords, swabPurchaseMasterList.PONumber] : swabPurchaseRecords;
                }
            }
            return new ResponseModel(true, "Record Found", [...new Set(swabPurchaseRecords)]);
        }
        catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal Server Error", error);
        }
    }
    export async function getBoxInventoryData(filters: any): Promise<any> {
        try {

            if (filters.InventoryPeriod === "All") {
                filters.FromDate = "01-01-2015";
                filters.ToDate = new Date();
            }
            else {
                filters.ToDate = new Date(filters.ToDate)
                
            }

            let formatFromDate = moment(filters.FromDate).format();
            let formateToDate = moment(filters.ToDate).format();
            let boxId = filters.BoxID ===  "All" ? undefined : filters.BoxID;
            let lotNumber = filters.LotNumber === "All" ? undefined : filters.LotNumber;
           
            let swabPurchaseDetails = await prismaSwab.SwabPurchaseDetails.findMany({
                where: {
                    BoxID: boxId,
                    LotNumber: lotNumber,
                    SwabPurchaseMaster:{
                        PurchaseDate:{
                            lte: formateToDate,
                            gte: formatFromDate,
                        }
                    }
                },
                select:{
                    BoxID: true,
                    NumberOfSwabs: true,
                    LotNumber: true,
                    SwabInventoryBoxBalance: true
                }
            });
            let boxInventory: any[] = [];
            let totSwabsAvailable: any = 0;
            for (let i = 0; i < swabPurchaseDetails.length; i++) {
                let AvailableSwabs = swabPurchaseDetails[i].SwabInventoryBoxBalance[0].AvailableSwabs;
                let TotalSwabs = swabPurchaseDetails[i].NumberOfSwabs;
                boxInventory = [...boxInventory, { BoxID: swabPurchaseDetails[i].BoxID, TotalSwabs, LotNumber: swabPurchaseDetails[i].LotNumber, AvailableSwabs, DispatchedSwabs: Number(TotalSwabs) - Number(AvailableSwabs) }];
                totSwabsAvailable += AvailableSwabs;
            }
            return new ResponseModel(true, "Record Found", { boxInventory, totSwabsAvailable });
        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal Server Error", error);
        }
    }
    export const getFilteredBoxID = async ():  Promise<any> => {
        try {
            let swabPurchaseDetails = await prismaSwab.SwabPurchaseDetails.findMany({
                select:{
                    BoxID: true
                }
            });
            swabPurchaseDetails = swabPurchaseDetails.length > 0 ? swabPurchaseDetails.map((val: any) => val.BoxID) : [];
            return new ResponseModel(true, "Record Found", [...new Set(swabPurchaseDetails)]);
        }
        catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal Server Error", error);
        }
    }
    export const getBoxQty = async ():  Promise<any> => {
        try {
            let swabInventoryBoxBalance = await prismaSwab.SwabInventoryBoxBalance.findMany({
                where: {
                    AvailableSwabs: { gt: 0, }
                },
                select:{
                    AvailableSwabs: true,
                    PurchaseDetailID: true,
                    SwabPurchaseDetails: true
                }
            });
            return new ResponseModel(true, "Record Found", swabInventoryBoxBalance.map((val: any) => ({AvailableSwabs: val.AvailableSwabs, PurchaseDetailID: val.PurchaseDetailID, BoxID: val.SwabPurchaseDetails.BoxID })));
        }
        catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal Server Error", error);
        }
    }
    export async function getLotInventoryData(filters: any): Promise<any> {
        try {

            if (filters.InventoryPeriod === "All") {
                filters.FromDate = "01-01-2015";
                filters.ToDate = new Date();
            }
           
            let formatFromDate = moment(filters.FromDate).format();
            let formateToDate = moment(filters.ToDate).format();
            let vendorId = Number(filters.VendorID) === 0 ? undefined : Number(filters.VendorID);
            let clientId = Number(filters.ClientID) === 0 ? undefined : Number(filters.ClientID);
            let lotNumber = filters.LotNumber === "All" ? undefined : filters.LotNumber;
            let isSwabPurchase = clientId && !vendorId ? false : true;
            let isSwabDispatch = !clientId && vendorId ? false : true;
            let lotInventory: any[] = [];
            let totSwabsAvailable: any = 0;

            let lotBalance = await prismaSwab.SwabInventoryLotBalance.findMany({
                where: {
                    AvailableSwabs: { gte: 0 },
                    LotNumber: lotNumber,
                }
            });
           
            for (let i = 0; i < lotBalance.length; i++) {
                let lotTransactionRecords: any[] = [];
                if (isSwabPurchase) {
                    let swabPurchaseDetails = await prismaSwab.SwabPurchaseDetails.groupBy({
                        by: ['PurchaseMasterID'],
                        where: {
                            LotNumber: lotBalance[i].LotNumber
                        },
                        _sum: {
                            NumberOfSwabs: true
                        },
                        _count:{
                            BoxID: true
                        }
                    });
                    for (let j = 0; j < swabPurchaseDetails.length; j++) {
                        let swabPurchaseMaster = await prismaSwab.SwabPurchaseMaster.findFirst({
                            where: {
                                PurchaseMasterID: swabPurchaseDetails[j].PurchaseMasterID,
                                VendorID: vendorId,
                                PurchaseDate: {
                                    lte: formateToDate,
                                    gte: formatFromDate,
                                }
                            },
                            include: {
                                Vendors: true
                            }
                        });
                        if (swabPurchaseMaster && Object.keys(swabPurchaseMaster).length > 0) {
                            lotTransactionRecords = [...lotTransactionRecords, { TransactionDate: swabPurchaseMaster.PurchaseDate, Description: swabPurchaseMaster.Comments.trim() === '' ? 'Swab Purchase' : `Swab Purchase - ${swabPurchaseMaster.Comments}`, VCName: swabPurchaseMaster.Vendors.VendorName, VCid: swabPurchaseMaster.VendorID, PONumber: swabPurchaseMaster.PONumber, NoOfBoxes: swabPurchaseDetails[j]._count.BoxID, SwabPurchased: swabPurchaseDetails[j]._sum.NumberOfSwabs, SwabDispatched: "" }];
                        }
                    }
                }
                if (isSwabDispatch) {
                    let swabDispatchDetails = await prismaSwab.ClientSwabDispatchDetails.groupBy({
                        by: ["DispatchMasterID", "RequestID"],
                        where: {
                            LotNumber: lotBalance[i].LotNumber
                        },
                        _sum: {
                            DispatchQty: true
                        },
                        _count: {
                            LotNumber: true
                        }
                    });
                    for (let j = 0; j < swabDispatchDetails.length; j++) {
                        let swabDispatchMaster = await prismaSwab.ClientSwabDispatchMaster.findFirst({
                            where: {
                                DispatchMasterID: swabDispatchDetails[j].DispatchMasterID,
                                ClientID: clientId,
                                DispatchDate: {
                                    lte: formateToDate,
                                    gte: formatFromDate,
                                }
                            }
                        });
                        if (swabDispatchMaster && Object.keys(swabDispatchMaster).length > 0) {
                            let swabShipmentClients = await prismaSwab.SwabShipmentClients.findFirst({
                                where: {
                                    RequestID: swabDispatchDetails[j].RequestID
                                }
                            });
                            let ClientData = await TrackingSystemDA.getClientById(swabDispatchMaster.ClientID);
                            lotTransactionRecords = [...lotTransactionRecords, { TransactionDate: swabDispatchMaster.DispatchDate, Description: !swabShipmentClients.Notes || swabShipmentClients.Notes.trim() === '' ? swabDispatchDetails[j]._sum.DispatchQty <= 0 ? 'Swab Dispatch Returned' : 'Swab Dispatch' : `${swabDispatchDetails[j]._sum.DispatchQty <= 0 ? 'Swab Dispatch Returned' : 'Swab Dispatch'} - ${swabShipmentClients.Notes}`, VCName: ClientData.ClientName, VCid: swabDispatchMaster.ClientID, PONumber: "", SwabPurchased: "", SwabDispatched: swabDispatchDetails[j]._sum.DispatchQty, NoOfBoxes: swabDispatchDetails[j]._count.LotNumber }];
                        }
                    }
                }
                if(lotTransactionRecords.length > 0){
                    totSwabsAvailable += lotBalance[i].AvailableSwabs;
                    lotInventory = [...lotInventory, { LotNumber: lotBalance[i].LotNumber, Ledgers: lotTransactionRecords.length > 0 ? lotTransactionRecords.sort((a,b) => moment(a.TransactionDate) - moment(b.TransactionDate)) : [], Balance: lotBalance[i].AvailableSwabs }];
                }    
            }
            return new ResponseModel(true, "Record Found", { lotInventory, totSwabsAvailable });
        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal Server Error", error);
        }
    }
}
