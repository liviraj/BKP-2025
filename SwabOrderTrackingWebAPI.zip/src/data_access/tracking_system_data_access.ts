import { IResult } from "mssql";
import { shipmentTrackingSystemConnectionPool, histoSConnectionPool } from "../common/db_connection";
import * as Sql from 'mssql/msnodesqlv8';
import { DeliveryStatus, PaymentStatus } from "../models/tracking_system_model";
import { PrismaClient as PrismaClientSwab } from '@prisma/client';
import ResponseModel from "../common/response_model";

const prismaSwab = new PrismaClientSwab();

export module TrackingSystemDA {
    export async function getDeliveryStatusList(): Promise<DeliveryStatus[]> {
        return new Promise<DeliveryStatus[]>((resolve, reject) => {
            shipmentTrackingSystemConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.execute('GetDeliveryStatus').then((val: IResult<DeliveryStatus>) => {
                    resolve(val.recordset);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    export async function getPaymentStatuses(): Promise<PaymentStatus[]> {
        return new Promise<PaymentStatus[]>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.execute('GetPaymentStatus').then((val: IResult<PaymentStatus>) => {
                    resolve(val.recordset);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    export async function getClients(): Promise<any> {
        let clients = await prismaSwab.t_Clients.findMany({
            select: {
                ClientCode: true,
                ClientName: true
            }
        });
        return clients;
    }

    export async function getClientNameList(): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.execute('GetClientNameList').then((val: IResult<any>) => {
                    resolve(val.recordset);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    export async function getClientById(ClientID:any): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('ClientID', Sql.Int, ClientID)
                request.execute('GetClientById').then((val: IResult<any>) => {
                        resolve(val.recordset[0]);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    export async function getDispatchClients(): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            shipmentTrackingSystemConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.execute('GetDispatchClients').then((val: IResult<any>) => {
                        resolve(val.recordset);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    export async function getOnlyDispatchDidClients(): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            shipmentTrackingSystemConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.execute('GetOnlyDispatchDidClients').then((val: IResult<any>) => {
                        resolve(val.recordset);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    export async function getOnlyRequestDidClients(): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            shipmentTrackingSystemConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.execute('GetOnlyRequestDidClients').then((val: IResult<any>) => {
                        resolve(val.recordset);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    
    export const getAllTrackingNumber = async (): Promise<any> => {
        try{
            let dispatchMasterList = await prismaSwab.clientSwabDispatchMaster.findMany({
                select: {
                    ShippingTrackingNumber: true,
                    DeliveryStatusID:true
                }
            });
            let filterValue = dispatchMasterList.filter((val:any)=> { return (val.DeliveryStatusID === 1 || val.DeliveryStatusID === 4) && val.ShippingTrackingNumber  } );
            let result = filterValue.map((val)=>{ return val.ShippingTrackingNumber });
            return result;
        }catch(err){
            console.log(err);
            return new ResponseModel(false, "Internal Server Error", err);
        }
    }

    export async function updateTrackingStatus(requestData: any): Promise<ResponseModel> {
        try{
            for(let i=0;i<requestData.length;i++){
                if(!requestData[i].shippingTrackingNumber){
                    console.log("Invalid or Empty Tracking number found");
                    continue;
                }
                await prismaSwab.clientSwabDispatchMaster.updateMany({
                    where: {
                        ShippingTrackingNumber: requestData[i].shippingTrackingNumber
                    },
                    data: {
                        DeliveryStatusID: Number(requestData[i].deliveryStatusID),
                    },
                });
            }            
            return new ResponseModel(true, `Tracking Number status has been updated`);
        }catch(err){
            console.log(err);
            return new ResponseModel(false, "Internal Server Error", err);
        }
    }
    
}