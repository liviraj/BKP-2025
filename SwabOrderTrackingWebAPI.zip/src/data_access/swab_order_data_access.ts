import { IResult } from "mssql";
import { histoSConnectionPool, shipmentTrackingSystemConnectionPool } from "../common/db_connection";
import * as Sql from 'mssql/msnodesqlv8';
import { InventoryStatus, SwabOrder, SwabStatus, ShipmentCarriers, ShipmentDetail } from "../models/swab_order_model";
import { SwabUOM as SwabOrderType, T_ShipmentCarrier as ShipmentCarrier } from '@prisma/client';
import { TrackingSystemService } from "../service/tracking_system_service";
import ResponseModel from "../common/response_model";
import { DocumentGenerator } from "./document_generator";
import { Constants, Message } from "../common/constants";
import { TrackingSystemDA } from "./tracking_system_data_access";
import { DocumentsDA } from './documents_data_access';
import { InventoryDA } from "./inventory_data_access";
import { PackingPdfGenerator } from "./pdf_generator";
import { InvoiceDataAccess } from "./invoice_data_access";

const { PrismaClient } = require('@prisma/client');
const moment = require('moment');

const prismaSwab = new PrismaClient();

export module SwabOrderDA {
    export enum DeliveryStatus {
        Shipped = 1,
        Delivered = 2,
        Return = 3,
        Lost = 4,
        All = 5
    }

    export async function getSwabOrderPending(): Promise<SwabOrder[]> {
        return new Promise<SwabOrder[]>((resolve, reject) => {
            shipmentTrackingSystemConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.execute('GetPendingSwabOrder').then((val: IResult<SwabOrder>) => {
                    resolve(val.recordset);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    export async function getSwabOrdersType(): Promise<SwabOrderType[]> {
        return await prismaSwab.swabUOM.findMany();
    }

    export async function getShipmentCarriers(): Promise<ShipmentCarrier[]> {
        let getShipmentCarriers = await prismaSwab.t_ShipmentCarrier.findMany();
        let firstShipmentCarrier = getShipmentCarriers[0];
        let fedexValue: any = getShipmentCarriers.find((value: { ShipmentCarrier: string; }) => value.ShipmentCarrier == 'FedEx');
        let fedexIndex: number = getShipmentCarriers.indexOf(fedexValue);

        getShipmentCarriers[0] = fedexValue;
        getShipmentCarriers[fedexIndex] = firstShipmentCarrier;

        return getShipmentCarriers;
    }

    export async function getSwabStatuses(): Promise<SwabStatus[]> {
        let swabStatusGroup: SwabStatus[] = [
            {
                id: 1,
                status: "All"
            },
            {
                id: 2,
                status: "Fully Shipped"
            },
            {
                id: 3,
                status: "Partially Shipped"
            },
            {
                id: 4,
                status: "Not Shipped"
            },
            {
                id: 5,
                status: "To be Shipped"
            }
        ];
        return swabStatusGroup;
    }

    export async function inventoryStatus(): Promise<InventoryStatus> {
        let inventoryStatusGroup: InventoryStatus =
        {
            AvailableQty: "--",
            ReOrderLevel: "--"
        }

        return inventoryStatusGroup;
    }

    export async function createSwabrequest(requestDetail: any, shipmentDetail: any): Promise<ResponseModel> {

        try {
            let clientInfo: any;
            let convertRequestedDate = moment(requestDetail.RequestedDate);

            const swabOrderType = await prismaSwab.swabUOM.findUnique(
                {
                    where: { SwabUOMID: Number(requestDetail.SwabUOMID) }
                }
            );


            if (swabOrderType != null && swabOrderType != undefined) {
                const clientById: any = await TrackingSystemService.getClientById(requestDetail.ClientID);

                // Create the new client
                // if (clientById.length == 0 || requestDetail.ClientID == 0) {
                //     let country: any = await getCountryByCountryName(shipmentDetail.CountryID);
                //     clientInfo = await insertUpdateClients(requestDetail, shipmentDetail, country.CountryID);

                //     if (clientInfo.Identity == -1) {
                //         return new ResponseModel(false, "Client already exists")
                //     } else {
                //         requestDetail.ClientID = clientInfo.Identity;
                //         shipmentDetail.ClientID = clientInfo.Identity;
                //     }
                // }

                const saveRequestDetail: any = await prismaSwab.clientSwabRequestDetails.create({
                    data: {
                        RequestedDate: convertRequestedDate.format(),
                        ClientID: Number(requestDetail.ClientID),
                        RequestorName: requestDetail.RequestorName,
                        RequestorEmailAddress: requestDetail.RequestorEmailAddress,
                        SwabUOMID: Number(requestDetail.SwabUOMID),
                        QtyRequested: Number(requestDetail.QtyRequested),
                        TobeShippedQty: Number(requestDetail.QtyRequested),
                        ShippedQty: 0,
                        RequestorContactNumber: requestDetail.RequestorContactNumber,
                        LastModifiedBy: Number(requestDetail.LastModifiedBy),
                        LastModifiedOn: new Date(),
                        // SwabPricePerUnit: requestDetail.SwabPricePerUnit
                    }
                });
                let updatePrice = await updateSwabUnitPrice(requestDetail.SwabPricePerUnit, saveRequestDetail.RequestID);
                return new ResponseModel(true, "Saved Successfully", saveRequestDetail);

            }
            else {
                return new ResponseModel(false, "Swaborder(SwabUOM) type not found");
            }

        } catch (error) {
            console.log(error)
            return new ResponseModel(false, "Prisma error", error);
        }

    }
    async function updateSwabUnitPrice(swabPricePerUnit: string, requestId: number) {
        return new Promise<any>((resolve, reject) => {
            shipmentTrackingSystemConnectionPool.connect().then(async (_con) => {
                const request = new Sql.Request(_con);

                request.input('SwabPricePerUnit', Sql.VarChar, swabPricePerUnit);
                request.input('RequestID', Sql.Int, requestId);

                request.execute('UpdateSwabUnitPrice').then((val: IResult<any>) => {
                    resolve(val.output);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }
    async function insertUpdateClients(requestData: any, shipmentDetail: any, CountryID: number): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then(async (_con) => {
                const request = new Sql.Request(_con);

                request.input('ClientID', Sql.Int, 0);
                request.input('ClientTypeID', Sql.Int, 5);
                request.input('ClientName', Sql.VarChar, requestData.ClientName);
                request.input('ClientDisplayName', Sql.VarChar, requestData.ClientName);
                request.input('BillingAddr1', Sql.VarChar, shipmentDetail.ShippingAddress1);
                request.input('BillingAddr2', Sql.VarChar, shipmentDetail.Address2);
                request.input('BillingCity', Sql.VarChar, shipmentDetail.City);
                request.input('BillingState', Sql.VarChar, shipmentDetail.State);
                request.input('BillingPostalCode', Sql.VarChar, shipmentDetail.Zip);
                request.input('BillingCountryId', Sql.Int, CountryID);
                request.input('BillingContactPerson', Sql.VarChar, requestData.RequestorName);
                request.input('ContNo1', Sql.VarChar, requestData.RequestorContactNumber);
                request.input('ContNo2', Sql.VarChar, null);
                request.input('Fax', Sql.VarChar, null);
                request.input('BillToEmail', Sql.VarChar, requestData.RequestorEmailAddress);
                request.input('BillingCCEmail', Sql.VarChar, Constants.BILLING_CC_MAIL.join(";"));
                request.input('websiteLoginPwd', Sql.VarChar, null);
                request.input('logInUserID', Sql.Int, 0);
                request.input('billingType', Sql.VarChar, "H");
                request.input('clientGroupID', Sql.Int, 1);
                request.input('tobeBilled', Sql.Bit, 1);
                request.input('iseligibleforBulkInvoice', Sql.Int, 0);
                request.input('isPaymentOnCredit', Sql.Int, 1);
                request.input('isReportByPCode', Sql.Int, 1);
                request.input('ClientGSTNo', Sql.VarChar, null);

                request.output('Identity', Sql.Int, null);

                request.input('noMakeID', Sql.TinyInt, 0);
                request.input('Department', Sql.VarChar, null);
                request.input('CPDContactPerson', Sql.VarChar, null);
                request.input('CPDToEmail', Sql.VarChar, null);
                request.input('CDAddress1', Sql.VarChar, null);
                request.input('CDAddress2', Sql.VarChar, null);
                request.input('CDCountryID', Sql.Int, CountryID);
                request.input('CDCity', Sql.VarChar, null);
                request.input('CDState', Sql.VarChar, null);
                request.input('CDPostalCode', Sql.VarChar, null);
                request.input('PDPaymentMethodId', Sql.Int, 4);
                request.input('PDAgreedPricing', Sql.VarChar, null);
                request.input('PDPaymentDaysId', Sql.Int, 3);
                request.input('ODAddressForKit', Sql.VarChar, null);
                request.input('ODWebsiteLoginName', Sql.VarChar, null);

                request.execute('InsertUpdateClients').then((val: IResult<any>) => {
                    resolve(val.output);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }
    export async function getCountryByCountryName(countryName: string): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('CountryName', Sql.VarChar, countryName);
                request.execute('GetCountryByCountryName').then((val: IResult<any>) => {
                    resolve(val.recordset[0]);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }
    export async function createShipmentClient(shipmentDetail: any): Promise<ResponseModel> {
        try {
            const swabRequest = await prismaSwab.clientSwabRequestDetails.findUnique(
                {
                    where: { RequestID: Number(shipmentDetail.RequestID) }
                }
            );
            const clientById = await TrackingSystemService.getClientById(shipmentDetail.ClientID);

            if (swabRequest != null && swabRequest != undefined) {
                if (clientById != null && clientById != undefined) {
                    const clientShipmentAddress = await createClientShipmentAddress(shipmentDetail);
                    const saveShipmentDetail = await prismaSwab.swabShipmentClients.create({
                        data: { ClientID: shipmentDetail.ClientID, RequestID: shipmentDetail.RequestID, LastModifiedBy: shipmentDetail.LastModifiedBy, LastModifiedOn: shipmentDetail.LastModifiedOn, Notes: shipmentDetail.Notes, ClientShipmentAddressID: clientShipmentAddress.ClientShipmentAddressID }
                    });
                    return new ResponseModel(true, "Saved Successfully", saveShipmentDetail);
                } else {
                    return new ResponseModel(false, "Client not found");
                }
            }
            else {
                return new ResponseModel(false, "Swab request  not found");
            }

        } catch (error) {
            console.log(error)
            return new ResponseModel(false, "Prisma error", error);
        }
    }

    export const createClientShipmentAddress = async (shipmentDetail: ShipmentDetail): Promise<any> => {
        try{
            const addressFields = { ShippingAddress1: shipmentDetail.ShippingAddress1, ShippingAddress2: shipmentDetail.Address2, City: shipmentDetail.City, State: shipmentDetail.State, Zip: shipmentDetail.Zip, CountryID: shipmentDetail.CountryID };
            const addressDetails = await prismaSwab.ClientShippingAddresses.findFirst({
                where: {...addressFields}
            })
            if(addressDetails && Object.keys(addressDetails).length > 9){
                return addressDetails;
            }
            else{
                return await prismaSwab.ClientShippingAddresses.create({
                    data: {...addressFields, ClientID: shipmentDetail.ClientID, LastModifiedBy: shipmentDetail.LastModifiedBy, LastModifiedOn: new Date() }
                })
            }
        }
        catch(error){
            console.error(error)
            throw error;
        }
    }

    export async function getAllSwabRequest(): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            shipmentTrackingSystemConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.execute('GetAllSwabRequest').then((val: IResult<any>) => {
                    resolve(val.recordset)
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    export async function getSwabRequestById(RequestID: any): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            shipmentTrackingSystemConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('RequestID', Sql.Int, RequestID);
                request.execute('GetSwabRequestById').then((val: IResult<any>) => {
                    resolve(new ResponseModel(true, "Data found", val.recordset[0]))
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    export async function getSwabRequestByFilters(filterValues: any): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            let fromDate = moment(filterValues.FromDate).format('lll');
            let toDate =  moment(filterValues.ToDate).format('lll');
            shipmentTrackingSystemConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('RequestPeriod', Sql.VarChar, filterValues.RequestPeriod)
                request.input('FromDate', Sql.VarChar, fromDate)
                request.input('ToDate', Sql.VarChar, toDate)
                request.input('ClientID', Sql.Int, filterValues.ClientID)
                request.input('Status', Sql.VarChar, filterValues.Status)
                request.execute('FilterRequestDetail').then(async (val: IResult<any>) => {
                    if(("returnValue" in val) && val.recordset.length === 1 && ("result" in val.recordset[0]) ){
                        return resolve(new ResponseModel(false, "Internal server erorr", val.recordset[0].result));
                    }
                    let updateDocsInfo = val.recordset.length > 0 ? [...val.recordset] : [];
                    for (let i = 0; i < updateDocsInfo.length; i++) {
                        await DocumentsDA.getDocsInfo(updateDocsInfo[i].RequestID, "Request").then(async (res: any) =>  updateDocsInfo[i] = { ...updateDocsInfo[i], documents: res});
                    }
                    resolve(new ResponseModel(true, "Data found", updateDocsInfo));
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    export async function updateSwabrequest(requestData: any): Promise<ResponseModel> {
        try {
            let swabRequestReqModel = requestData.requestDetails;
            let shippingReqModel = requestData.shipmentDetail;

            const swabRequest = await prismaSwab.clientSwabRequestDetails.findUnique({
                where: {
                    RequestID: Number(swabRequestReqModel.RequestID),
                },
            });
            const shipmentDetail = await prismaSwab.swabShipmentClients.findUnique({
                where: {
                    ClientShipmentAutoID: Number(shippingReqModel.ClientShipmentAutoID),
                }
            });

            if (swabRequest != null && swabRequest != undefined && shipmentDetail != null && shipmentDetail != undefined) {
                let convertRequestDate = moment(swabRequestReqModel.RequestedDate);
                let ToBeShippedCountUpdate: number = swabRequestReqModel.QtyRequested;

                // await prismaSwab.clientSwabRequestDetailsAudit.create({ // Swab Audit - Auto update using DB profiler
                //     data: swabRequest,
                // });
                await prismaSwab.swabShipmentClientsAudit.create({
                    data: shipmentDetail
                });

                if (swabRequest.ShippedQty != null) {
                    ToBeShippedCountUpdate = ToBeShippedCountUpdate - swabRequest.ShippedQty;
                }

                const updateRequestDetail = await prismaSwab.clientSwabRequestDetails.update({
                    where: { RequestID: Number(swabRequestReqModel.RequestID) },
                    data: {
                        RequestedDate: convertRequestDate.format(),
                        ClientID: Number(swabRequestReqModel.ClientID),
                        RequestorName: swabRequestReqModel.RequestorName,
                        RequestorEmailAddress: swabRequestReqModel.RequestorEmailAddress,
                        SwabUOMID: Number(swabRequestReqModel.SwabUOMID),
                        QtyRequested: Number(swabRequestReqModel.QtyRequested),
                        RequestorContactNumber: swabRequestReqModel.RequestorContactNumber,
                        TobeShippedQty: Number(ToBeShippedCountUpdate),
                        LastModifiedBy: Number(swabRequestReqModel.LastModifiedBy),
                        LastModifiedOn: new Date()
                    },
                });

                await updateSwabUnitPrice(swabRequestReqModel.SwabPricePerUnit, swabRequestReqModel.RequestID);
                const clientShipmentAddress = await createClientShipmentAddress(shippingReqModel);
                await prismaSwab.swabShipmentClients.update({
                    where: { ClientShipmentAutoID: Number(shippingReqModel.ClientShipmentAutoID) },
                    data: {
                        ClientShipmentAddressID: clientShipmentAddress.ClientShipmentAddressID,
                        ClientID: Number(shippingReqModel.ClientID),
                        Notes: shippingReqModel.Notes,
                        RequestID: Number(shippingReqModel.RequestID),
                        LastModifiedBy: Number(shippingReqModel.LastModifiedBy),
                        LastModifiedOn: new Date()
                    },
                });

                return new ResponseModel(true, "Request detail updated successfully");
            } else {
                return new ResponseModel(false, "Swabrequest/ shipment detail not found");
            }
        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal server erorr", error);
        }
    }

    export async function deleteSwabRequestById(RequestID: any): Promise<ResponseModel> {
        let delRefDocs;
        try {
            const requestDetail = await prismaSwab.clientSwabRequestDetails.findUnique({
                where: { RequestID: Number(RequestID) },
            });
            const shippingDetail = await prismaSwab.swabShipmentClients.findFirst({
                where: {
                    RequestID: Number(RequestID)
                },
            });
            const refDocs: any[] = await prismaSwab.referenceDocuments.findMany({
                where: {
                    RefTypeID: Number(RequestID)
                }
            });

            if (requestDetail != null && shippingDetail != null) {
                if (requestDetail.ShippedQty == 0) {
                    // create audit for request 
                    // await prismaSwab.clientSwabRequestDetailsAudit.create({ // Audit - Auto update using DB profiler
                    //     data: requestDetail
                    // });
                    await prismaSwab.swabShipmentClientsAudit.create({
                        data: shippingDetail
                    });

                    if (refDocs != null && refDocs != undefined && refDocs.length != 0) {
                        refDocs.forEach(async doc => {
                            await prismaSwab.referenceDocumentsAudit.create({
                                data: doc
                            });
                        });

                        delRefDocs = await prismaSwab.referenceDocuments.deleteMany({
                            where: { RefTypeID: Number(RequestID) }
                        });
                    }

                    const delShipmentetail = await prismaSwab.swabShipmentClients.delete({
                        where: { ClientShipmentAutoID: shippingDetail.ClientShipmentAutoID }
                    });
                    const delSwabReq = await prismaSwab.clientSwabRequestDetails.delete({
                        where: { RequestID: Number(RequestID) }
                    });

                    return new ResponseModel(true, "Deleted Successfully");
                } else {
                    return new ResponseModel(false, "Could not delete in-progress/completed request");
                }

            } else {
                return new ResponseModel(false, "Request data not found");
            }
        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal server error", error);
        }
    }

    export async function getSwabRequestByClientID(ClientID: number): Promise<any> {
        let swabRequestList: any = [];

        return new Promise<any>((resolve, reject) => {
            shipmentTrackingSystemConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('ClientID', Sql.Int, ClientID).execute('GetSwabRequestByClientID').then((val: IResult<any>) => {

                    val.recordset.forEach((shippingMain: any) => {
                        let shippingDetailSplit: any;
                        shippingDetailSplit = {
                            ClientShipmentAutoID: shippingMain.ClientShipmentAutoID,
                            ShippingAddress2: shippingMain.ShippingAddress2,
                            City: shippingMain.City,
                            CountryID: shippingMain.CountryID,
                            Notes: shippingMain.Notes,
                            ShippingAddress1: shippingMain.ShippingAddress1,
                            State: shippingMain.State,
                            Zip: shippingMain.Zip,
                            RequestedDate: shippingMain.RequestedDate,
                            QtyRequested: shippingMain.QtyRequested,
                            TobeShippedQty: shippingMain.TobeShippedQty,
                            isAddressDiffer: false
                        }

                        let reposneData = {
                            RequestID: shippingMain.RequestID,
                            RequestedDate: shippingMain.RequestedDate,
                            ClientID: shippingMain.ClientID,
                            SwabUOM: shippingMain.SwabUOM,
                            PricePerUnit: shippingMain.SwabPricePerUnit,
                            QtyRequested: shippingMain.QtyRequested,
                            TobeShippedQty: shippingMain.TobeShippedQty,
                            shippingDetails: shippingDetailSplit
                        }

                        swabRequestList.push(reposneData);
                    });
                    resolve(swabRequestList);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    export async function createShippingAddress(obj:any): Promise<any> {
        try{
            const clientSwabDispatchMaster = await prismaSwab.ClientShippingAddresses.create({
                data:{
                    ClientID:obj.ClientID,
                    ShippingAddress1:obj.ShippingAddress1,
                    ShippingAddress2:obj.ShippingAddress2,
                    City:obj.City,
                    State:obj.State,
                    Zip:obj.Zip,
                    CountryID:obj.CountryID,
                    LastModifiedBy: Number(obj.LastModifiedBy),
                    LastModifiedOn: new Date(),
                }
            })
            return clientSwabDispatchMaster;
        }catch(err){
            console.error(err);
        }
    }

    export async function UpdateDispatchNotes(notes:String,autoID:Number):Promise<any>{
        try{
            await prismaSwab.swabShipmentClients.update({
                where:{
                    ClientShipmentAutoID: autoID ? autoID : 0
                },
                data:{
                    Notes:notes
                }
            })
        }catch(err){
            console.error(err);
        }
    }

    export async function createDispatch(reqData: any): Promise<ResponseModel> {

        try {
            let dispatchMasterDetails = reqData.dispatchMasterDetails;
            let dispatchDetails = reqData.dispatchDetails;
            let saveDispatchDetailsList: any[] = [];
            let convertDispatchDate = moment(dispatchMasterDetails.DispatchDate);
            let convertDeliveryDate = moment(dispatchMasterDetails.DeliveryDate);
            let ClientAddress = reqData.shippingDetails

            let getClientLocationData = await getClientDetailsByID(dispatchMasterDetails.ClientID);
            let clientLocation = getClientLocationData ? Object.keys(getClientLocationData).length > 0 : false;

            await InventoryDA.getFilteredLotNumber().then(val => {
                if (val.success && val.data.length > 0) {
                    let lotNumbers = val.data;
                    for (let i = 0; i < dispatchDetails.length; i++) {
                        for (let j = 0; j < dispatchDetails[i].lotQtyDetails.length; j++) {
                            let requestData = dispatchDetails[i].lotQtyDetails[j];
                            if (("DispatchQty" in requestData) && ("LotNumber" in requestData)) {
                                const lotIndex = lotNumbers.findIndex((val: any) => val.LotNumber === requestData.LotNumber);
                                lotNumbers[lotIndex] = lotIndex >= 0 ? { ...lotNumbers[lotIndex], usedLot: ("usedLot" in lotNumbers[lotIndex]) ? lotNumbers[lotIndex].usedLot + requestData.DispatchQty : requestData.DispatchQty } : lotNumbers[lotIndex];
                            }
                        }
                    }
                    const islotValid = lotNumbers.filter((val: any) => ("usedLot" in val) && val.AvailableSwabs - val.usedLot < 0)
                    if (islotValid && islotValid.length > 0) {
                        return new ResponseModel(false, `Lot #(${islotValid[0].LotNumber}) in the table field must be less than available lots(${islotValid[0].AvailableSwabs})`);
                    }
                }
            })

            for (let i = 0; i < dispatchDetails.length; i++) {
                for (let j = 0; j < dispatchDetails[i].lotQtyDetails.length; j++) {
                    let SwabPurchaseDetailsList: any = await prismaSwab.SwabPurchaseDetails.findFirst({
                        where: {
                            BoxID: dispatchDetails[i].lotQtyDetails[j].BoxID,
                        },
                        select: {
                            PurchaseDetailID: true
                        }
                    })
                    if (!SwabPurchaseDetailsList || SwabPurchaseDetailsList.length == 0) {
                        return new ResponseModel(false, Message(SwabPurchaseDetailsList.BoxID).BoxIDValid);
                    }
                }
            }
            //new address 
            let ClientShippingAddressesList: any;
            ClientShippingAddressesList = await prismaSwab.ClientShippingAddresses.findFirst({
                where: {
                    ClientID: dispatchMasterDetails.ClientID,
                    ShippingAddress1: ClientAddress.ShippingAddress1,
                    ShippingAddress2: ClientAddress.ShippingAddress2,
                    City: ClientAddress.City,
                    State: ClientAddress.State,
                    Zip: ClientAddress.Zip,
                    CountryID: ClientAddress.CountryID,
                }
            });
            if (!ClientShippingAddressesList) {
                ClientAddress.ClientID = dispatchMasterDetails.ClientID;
                ClientAddress.LastModifiedBy = dispatchMasterDetails.LastModifiedBy;
                ClientShippingAddressesList = await createShippingAddress(ClientAddress);
            }
            // await UpdateDispatchNotes(ClientAddress.Notes,ClientAddress.ClientShipmentAutoID);
            const saveDispatchMasterDetail = await prismaSwab.clientSwabDispatchMaster.create({
                data: {
                    ClientID: Number(dispatchMasterDetails.ClientID),
                    DispatchDate: convertDispatchDate.format(),
                    DispatchBy: dispatchMasterDetails.DispatchBy,
                    ShipCarrierID: Number(dispatchMasterDetails.ShipCarrierID),
                    ShippingTrackingNumber: dispatchMasterDetails.ShippingTrackingNumber.replace(/\s/g, ""),
                    DeliveryStatusID: Number(dispatchMasterDetails.DeliveryStatusID) | 1,
                    DeliveryDate: convertDeliveryDate.format(),
                    ReceiverName: dispatchMasterDetails.ReceiverName,
                    ShipmentandHandlingCost: dispatchMasterDetails.ShipmentandHandlingCost,
                    SwabCost: dispatchMasterDetails.SwabCost,
                    LastModifiedBy: Number(dispatchMasterDetails.LastModifiedBy),
                    LastModifiedOn: new Date(),
                    InvCurrency: clientLocation ? 'INR' : 'USD',
                    IsInvoiceRaised: false,
                    ClientShipmentAddressID: ClientShippingAddressesList.ClientShipmentAddressID
                }
            });
            if (saveDispatchMasterDetail != null && saveDispatchMasterDetail != undefined) {
                await prismaSwab.SwabInventoryLedger.create({
                    data: {
                        TransactionDate: convertDispatchDate.format(),
                        TransactionType: "D",
                        TransactionTypeID: saveDispatchMasterDetail.DispatchMasterID
                    }
                });
                for (let i = 0; i < dispatchDetails.length; i++) {
                    dispatchDetails[i].DispatchMasterID = saveDispatchMasterDetail.DispatchMasterID;
                    let saveDispatchDetails: any;
                    let sumOfDispatchQty: number = 0;
                    for (let j = 0; j < dispatchDetails[i].lotQtyDetails.length; j++) {
                        let SwabPurchaseDetailsList: any = await prismaSwab.SwabPurchaseDetails.findFirst({
                            where: {
                                BoxID: dispatchDetails[i].lotQtyDetails[j].BoxID,
                            },
                            select: {
                                PurchaseDetailID: true
                            }
                        })
                        saveDispatchDetails = await prismaSwab.clientSwabDispatchDetails.create({
                            data: {
                                DispatchMasterID: Number(dispatchDetails[i].DispatchMasterID),
                                DispatchQty: Number(dispatchDetails[i].lotQtyDetails[j].DispatchQty),
                                LotNumber: dispatchDetails[i].lotQtyDetails[j].LotNumber,
                                RequestID: Number(dispatchDetails[i].RequestID),
                                LastModifiedBy: Number(saveDispatchMasterDetail.LastModifiedBy),
                                LastModifiedOn: new Date(),
                                PurchaseDetailID: SwabPurchaseDetailsList.PurchaseDetailID
                            }
                        });
                        let SwabInventoryLotBalanceList: any = await prismaSwab.SwabInventoryLotBalance.findFirst({
                            where: {
                                LotNumber: dispatchDetails[i].lotQtyDetails[j].LotNumber
                            }
                        });
                        await prismaSwab.SwabInventoryLotBalance.update({
                            where: {
                                SwabInventoryBalanceID: SwabInventoryLotBalanceList.SwabInventoryBalanceID
                            },
                            data: {
                                AvailableSwabs: Number(SwabInventoryLotBalanceList.AvailableSwabs) - Number(dispatchDetails[i].lotQtyDetails[j].DispatchQty),
                            }
                        });
                        let SwabInventoryBoxBalanceList: any = await prismaSwab.SwabInventoryBoxBalance.findFirst({
                            where: {
                                PurchaseDetailID: SwabPurchaseDetailsList.PurchaseDetailID
                            }
                        });
                        await prismaSwab.SwabInventoryBoxBalance.update({
                            where: {
                                SwabInventoryBalanceID: SwabInventoryBoxBalanceList.SwabInventoryBalanceID
                            },
                            data: {
                                AvailableSwabs: Number(SwabInventoryBoxBalanceList.AvailableSwabs) - Number(dispatchDetails[i].lotQtyDetails[j].DispatchQty),
                            }
                        });

                        sumOfDispatchQty += dispatchDetails[i].lotQtyDetails[j].DispatchQty;
                    }

                    const requestDetails: any = await prismaSwab.clientSwabRequestDetails.findUnique({
                        where: {
                            RequestID: Number(dispatchDetails[i].RequestID)
                        }
                    });

                    if (requestDetails != null && requestDetails != undefined) {
                        let shippedQty = requestDetails.ShippedQty + sumOfDispatchQty;
                        let toShippedQty = requestDetails.QtyRequested - shippedQty;

                        // await prismaSwab.clientSwabRequestDetailsAudit.create({ // Audit - Auto Update using DB profiler
                        //     data: requestDetails
                        // });

                        const updateRequestDetails = await prismaSwab.clientSwabRequestDetails.update({
                            where: {
                                RequestID: Number(requestDetails.RequestID)
                            },
                            data: {
                                ShippedQty: Number(shippedQty),
                                TobeShippedQty: Number(toShippedQty),
                                LastModifiedBy: Number(saveDispatchDetails.LastModifiedBy),
                                LastModifiedOn: new Date()
                            }
                        });

                        saveDispatchDetails = {
                            DispatchDetailID: saveDispatchDetails.DispatchDetailID,
                            RequestID: saveDispatchDetails.RequestID,
                            RequestedDate: saveDispatchDetails.RequestedDate,
                            ClientID: saveDispatchDetails.ClientID,
                            SwabUOM: saveDispatchDetails.SwabUOM,
                            LastModifiedBy: saveDispatchDetails.LastModifiedBy,
                            LastModifiedOn: saveDispatchDetails.LastModifiedOn,
                            DispatchQty: saveDispatchDetails.DispatchQty,
                            LotNumber: saveDispatchDetails.LotNumber,
                        }
                    } else {
                        return new ResponseModel(false, "Request not found");
                    }
                    saveDispatchDetailsList.push(saveDispatchDetails);
                }

                let responseData = {
                    DispatchMasterID: saveDispatchMasterDetail.DispatchMasterID,
                }

                return new ResponseModel(true, "Disptach detail saved successfully", responseData);
            } else {
                return new ResponseModel(false, "Disptach master not found");
            }

        } catch (error) {
            console.log(error)
            return new ResponseModel(false, "Prisma error", error);
        }

    }

    export async function updateDiapatch(reqData: any): Promise<ResponseModel> {

        try {
            let dispatchMasterDetails = reqData.dispatchMasterDetails;
            let dispatchDetails = reqData.dispatchDetails;
            let shipmentDetails = reqData.shippingDetails;
            const lastModifiedBy = dispatchMasterDetails.LastModifiedBy;

            let convertDispatchDate = moment(dispatchMasterDetails.DispatchDate);
            let convertDeliveryDate = moment(dispatchMasterDetails.DeliveryDate);

            const isInvoiceRaised = dispatchMasterDetails.IsInvoiceRaised;
            const invoiceNumber = dispatchMasterDetails.InvoiceNumber;
            let isInvoiceCancelled: boolean = false;

            let fetchDispatchMasterDetails: any = await prismaSwab.clientSwabDispatchMaster.findUnique({
                where: {
                    DispatchMasterID: Number(dispatchMasterDetails.DispatchMasterID)
                },
            });

            const usInvoiceRecord: any = await InvoiceDataAccess.getUSInvoiceRecord(invoiceNumber);

            // Shipment Tracking Number validation before update the records
            if (isInvoiceRaised && usInvoiceRecord?.ValidityStatus && dispatchMasterDetails.ShippingTrackingNumber !== fetchDispatchMasterDetails.ShippingTrackingNumber) {
                return new ResponseModel(false, `Cancel invoice #${invoiceNumber} before updating the tracking number (${dispatchMasterDetails.ShippingTrackingNumber}).`, { discription: `Before proceeding with any record updates, ensure that invoice #${invoiceNumber} is canceled. Updating records without canceling the invoice may lead to inconsistencies or errors in the system. Please verify the invoice status and complete the cancellation process before making any modifications.` });
            }


            // Modify Request Details update
            if (dispatchDetails && dispatchDetails.length > 0) {
                for (const getDispatchDetail of dispatchDetails) {
                    const getRequestDispatchDetail: any = getDispatchDetail;

                    // To Get Required Lot And Box Details for Validation Purpose
                    let getCurrentLotNumbers: any = [], getCurrentBoxId: any = [];
                    if (getRequestDispatchDetail.lotQtyDetails.length > 0) {
                        getRequestDispatchDetail.lotQtyDetails.forEach((val: any) => {
                            getCurrentBoxId = [...getCurrentBoxId, val.BoxID];
                            getCurrentLotNumbers = [...getCurrentLotNumbers, val.LotNumber];
                        });
                    }

                    let getCurrentPurchaseDetails = await prismaSwab.SwabPurchaseDetails.findMany({
                        where: {
                            BoxID: {
                                in: getCurrentBoxId
                            }
                        },
                        select: {
                            PurchaseDetailID: true
                        }
                    });

                    if (getCurrentPurchaseDetails.length > 0) {
                        getCurrentPurchaseDetails = getCurrentPurchaseDetails.map((val: { PurchaseDetailID: Number }) => val.PurchaseDetailID);
                    }

                    let lotBalance = await prismaSwab.SwabInventoryLotBalance.findMany({
                        where: {
                            LotNumber: {
                                in: getCurrentLotNumbers
                            }
                        }
                    });

                    let boxBalance = await prismaSwab.SwabInventoryBoxBalance.findMany({
                        where: {
                            PurchaseDetailID: {
                                in: getCurrentPurchaseDetails
                            }
                        }
                    });

                    const getAllDispatchDetails = await prismaSwab.ClientSwabDispatchDetails.findMany({
                        where: {
                            DispatchMasterID: dispatchMasterDetails.DispatchMasterID,
                            RequestID: getDispatchDetail.RequestID
                        }
                    });

                    const filteredDispatchDetails = getRequestDispatchDetail.lotQtyDetails.filter((val: any) => ("DispatchDetailID" in val && "PurchaseDetailID" in val));
                    const dispatchDetailList = filteredDispatchDetails.map((val: any) => val.DispatchDetailID);
                    const purchaseDetailList = filteredDispatchDetails.map((val: any) => val.PurchaseDetailID);
                    let removedDispatchDetails: any;

                    const filteredSwabDispatchDetails = await prismaSwab.ClientSwabDispatchDetails.findMany({
                        where: {
                            DispatchDetailID: {
                                in: dispatchDetailList
                            }
                        }
                    });

                    const filteredSwabPurchaseDetails = await prismaSwab.SwabPurchaseDetails.findMany({
                        where: {
                            PurchaseDetailID: {
                                in: purchaseDetailList
                            }
                        }
                    })

                    if (getAllDispatchDetails && getAllDispatchDetails.length > 0) {
                        removedDispatchDetails = getAllDispatchDetails.filter((val: any) => !dispatchDetailList.includes(val.DispatchDetailID));
                    }

                    const newDispatchDetails = getRequestDispatchDetail.lotQtyDetails.filter((val: any) => !("DispatchDetailID" in val && "PurchaseDetailID" in val));
                    let onlyDispatchQtyChanges: any = [], oldLotBoxChanges: any = [];
                    for (let i = 0; i < filteredDispatchDetails.length; i++) {
                        const tempSwabDispatchDetail = filteredSwabDispatchDetails.find((val: any) => val.DispatchDetailID === filteredDispatchDetails[i].DispatchDetailID);
                        const tempSwabPurchaseDetail = filteredSwabPurchaseDetails.find((val: any) => val.PurchaseDetailID === filteredDispatchDetails[i].PurchaseDetailID);
                        if (tempSwabDispatchDetail.LotNumber === filteredDispatchDetails[i].LotNumber && filteredDispatchDetails[i].BoxID === tempSwabPurchaseDetail.BoxID) {
                            if (tempSwabDispatchDetail.DispatchQty !== filteredDispatchDetails[i].DispatchQty) {
                                onlyDispatchQtyChanges = [...onlyDispatchQtyChanges, filteredDispatchDetails[i]];
                            }
                        }
                        else {
                            oldLotBoxChanges = [...oldLotBoxChanges, filteredDispatchDetails[i]];
                        }
                    }

                    // Check DispatchQty updates before Cancel the Invoice
                    if (isInvoiceRaised && (removedDispatchDetails.length > 0 || newDispatchDetails.length > 0 || onlyDispatchQtyChanges.length > 0 || oldLotBoxChanges.length > 0)) {
                        if (usInvoiceRecord?.ValidityStatus) {
                            return new ResponseModel(false, `Cancel invoice #${invoiceNumber} before updating the records.`, { discription: `Before proceeding with any record updates, ensure that invoice #${invoiceNumber} is canceled. Updating records without canceling the invoice may lead to inconsistencies or errors in the system. Please verify the invoice status and complete the cancellation process before making any modifications.` });
                        }
                        isInvoiceCancelled = !usInvoiceRecord?.ValidityStatus;
                    }

                    // Validate Lot & Box Balance before update the records in DB
                    // Same Lot Number and BoxID but different Dispatch Qty logic Validation
                    if (onlyDispatchQtyChanges && onlyDispatchQtyChanges.length > 0) {
                        for (let i = 0; i < onlyDispatchQtyChanges.length; i++) {
                            const swabDispatchDetails = filteredSwabDispatchDetails.find((swabDispatch: any) => swabDispatch.DispatchDetailID === onlyDispatchQtyChanges[i].DispatchDetailID);
                            if (swabDispatchDetails) {
                                const index = lotBalance.findIndex((lotVal: any) => lotVal.LotNumber === onlyDispatchQtyChanges[i].LotNumber);
                                if (typeof (index) === "number" && index >= 0) {
                                    lotBalance[index].AvailableSwabs += swabDispatchDetails.DispatchQty;
                                    lotBalance[index].AvailableSwabs -= onlyDispatchQtyChanges[i].DispatchQty;
                                }
                                const boxIndex = boxBalance.findIndex((boxVal: any) => boxVal.PurchaseDetailID === onlyDispatchQtyChanges[i].PurchaseDetailID);
                                if (typeof (boxIndex) === "number" && boxIndex >= 0) {
                                    boxBalance[boxIndex].AvailableSwabs += swabDispatchDetails.DispatchQty;
                                    boxBalance[boxIndex].AvailableSwabs -= onlyDispatchQtyChanges[i].DispatchQty;
                                }
                            }
                        }
                    }
                    // User Deleted Record from Request Details(ClientSwabDispatchDetails)
                    if (removedDispatchDetails && removedDispatchDetails.length > 0) {
                        for (let i = 0; i < removedDispatchDetails.length; i++) {
                            const index = lotBalance.findIndex((val: any) => val.LotNumber === removedDispatchDetails[i].LotNumber);
                            if (typeof (index) === "number" && index >= 0) {
                                lotBalance[index].AvailableSwabs += removedDispatchDetails[i].DispatchQty;
                            }
                            const boxIndex = boxBalance.findIndex((boxVal: any) => boxVal.PurchaseDetailID === removedDispatchDetails[i].PurchaseDetailID);
                            if (typeof (boxIndex) === "number" && boxIndex >= 0) {
                                boxBalance[boxIndex].AvailableSwabs += removedDispatchDetails[i].DispatchQty;
                            }
                        }
                    }
                    // Different Lot Number, BoxID or Dispatch Qty logic Validation
                    if (oldLotBoxChanges && oldLotBoxChanges.length > 0) {
                        for (let i = 0; i < oldLotBoxChanges.length; i++) {
                            const swabDispatchDetails = filteredSwabDispatchDetails.find((swabDispatch: any) => swabDispatch.DispatchDetailID === oldLotBoxChanges[i].DispatchDetailID);
                            if (swabDispatchDetails) {
                                const index = lotBalance.findIndex((val: any) => val.LotNumber === swabDispatchDetails.LotNumber);
                                if (typeof (index) === "number" && index >= 0) {
                                    lotBalance[index].AvailableSwabs += swabDispatchDetails.DispatchQty;
                                }
                                const currentValueIndex = lotBalance.findIndex((val: any) => val.LotNumber === oldLotBoxChanges[i].LotNumber);
                                if (typeof (currentValueIndex) === "number" && currentValueIndex >= 0) {
                                    lotBalance[currentValueIndex].AvailableSwabs -= oldLotBoxChanges[i].DispatchQty;
                                }
                                const boxIndex = boxBalance.findIndex((boxVal: any) => boxVal.PurchaseDetailID === swabDispatchDetails.PurchaseDetailID);
                                if (typeof (boxIndex) === "number" && boxIndex >= 0) {
                                    boxBalance[boxIndex].AvailableSwabs += swabDispatchDetails.DispatchQty;
                                }
                                const newPurchaseDetail = await prismaSwab.SwabPurchaseDetails.findFirst({
                                    where: {
                                        BoxID: oldLotBoxChanges[i].BoxID
                                    }
                                });
                                const currentValueBoxIndex = newPurchaseDetail ? boxBalance.findIndex((boxVal: any) => boxVal.PurchaseDetailID === newPurchaseDetail.PurchaseDetailID) : null;
                                if (typeof (currentValueBoxIndex) === "number" && currentValueBoxIndex >= 0) {
                                    boxBalance[currentValueBoxIndex].AvailableSwabs -= oldLotBoxChanges[i].DispatchQty;
                                }
                            }
                        }
                    }
                    // New Lot Number, BoxID and Dispatch Qty logic validation
                    if (newDispatchDetails && newDispatchDetails.length > 0) {
                        const getAllSwabPurchaseDetails = await prismaSwab.SwabPurchaseDetails.findMany({
                            where: {
                                BoxID: {
                                    in: newDispatchDetails.map((val: any) => val.BoxID)
                                }
                            }
                        })
                        for (let i = 0; i < newDispatchDetails.length; i++) {
                            const lotIndex = lotBalance.findIndex((val: any) => val.LotNumber === newDispatchDetails[i].LotNumber);
                            if (typeof (lotIndex) === "number" && lotIndex >= 0) {
                                lotBalance[lotIndex].AvailableSwabs -= newDispatchDetails[i].DispatchQty;
                            }
                            const getSwabPurchaseDetails = getAllSwabPurchaseDetails.find((val: any) => val.BoxID === newDispatchDetails[i].BoxID);
                            const boxIndex = boxBalance.findIndex((boxVal: any) => boxVal.PurchaseDetailID === getSwabPurchaseDetails.PurchaseDetailID);
                            if (typeof (boxIndex) === "number" && boxIndex >= 0) {
                                boxBalance[boxIndex].AvailableSwabs -= newDispatchDetails[i].DispatchQty;
                            }
                        }
                    }

                    const validLotBalance = lotBalance.find((lotBalVal: any) => lotBalVal.AvailableSwabs < 0);
                    if (validLotBalance) {
                        return new ResponseModel(false, "Requested Dispatch Qty must not be less than lot balance", validLotBalance);
                    }
                    const validBoxBalance = boxBalance.find((boxBalVal: any) => boxBalVal.AvailableSwabs < 0);
                    if (validBoxBalance) {
                        return new ResponseModel(false, "Requested Dispatch Qty must not be less than Box balance", validBoxBalance);
                    }

                    // Revert the dispatched qty to Lot & Box balance details and delete the records(ClientSwabDispatchDetails)
                    if (removedDispatchDetails && removedDispatchDetails.length > 0) {
                        for (let removeDispatchDetailIndex = 0; removeDispatchDetailIndex < removedDispatchDetails.length; removeDispatchDetailIndex++) {
                            const deletedRecord = removedDispatchDetails[removeDispatchDetailIndex];
                            const getLotBalance = await prismaSwab.SwabInventoryLotBalance.findFirst({
                                where: {
                                    LotNumber: deletedRecord.LotNumber
                                }
                            });
                            await prismaSwab.SwabInventoryLotBalance.update({
                                where: {
                                    SwabInventoryBalanceID: getLotBalance.SwabInventoryBalanceID
                                },
                                data: {
                                    AvailableSwabs: (getLotBalance.AvailableSwabs + deletedRecord.DispatchQty)
                                }
                            });

                            const getBoxBalance = await prismaSwab.SwabInventoryBoxBalance.findFirst({
                                where: {
                                    PurchaseDetailID: deletedRecord.PurchaseDetailID
                                }
                            });
                            await prismaSwab.SwabInventoryBoxBalance.update({
                                where: {
                                    SwabInventoryBalanceID: getBoxBalance.SwabInventoryBalanceID
                                },
                                data: {
                                    AvailableSwabs: (getBoxBalance.AvailableSwabs + deletedRecord.DispatchQty)
                                }
                            });
                            await prismaSwab.ClientSwabDispatchDetails.delete({
                                where: {
                                    DispatchDetailID: deletedRecord.DispatchDetailID
                                }
                            });
                        }
                    }

                    // Same Lot Number and BoxID but different Dispatch Qty in request detail updates
                    if (onlyDispatchQtyChanges && onlyDispatchQtyChanges.length > 0) {
                        for (let dispatchQtyIndex = 0; dispatchQtyIndex < onlyDispatchQtyChanges.length; dispatchQtyIndex++) {

                            const val = onlyDispatchQtyChanges[dispatchQtyIndex];

                            const getSwabDispatchDetail = filteredSwabDispatchDetails.find((swabDispatchVal: any) => swabDispatchVal.DispatchDetailID === val.DispatchDetailID);
                            const getLotBalanceDetail = await prismaSwab.SwabInventoryLotBalance.findFirst({
                                where: {
                                    LotNumber: getSwabDispatchDetail.LotNumber
                                }
                            })
                            if (getLotBalanceDetail) {
                                await prismaSwab.SwabInventoryLotBalance.update({
                                    where: {
                                        SwabInventoryBalanceID: getLotBalanceDetail.SwabInventoryBalanceID
                                    },
                                    data: {
                                        AvailableSwabs: (getLotBalanceDetail.AvailableSwabs + getSwabDispatchDetail.DispatchQty - val.DispatchQty)
                                    }
                                });
                            }

                            const getBoxBalanceDetail = await prismaSwab.SwabInventoryBoxBalance.findFirst({
                                where: {
                                    PurchaseDetailID: getSwabDispatchDetail.PurchaseDetailID
                                }
                            })
                            if (getBoxBalanceDetail) {
                                await prismaSwab.SwabInventoryBoxBalance.update({
                                    where: {
                                        SwabInventoryBalanceID: getBoxBalanceDetail.SwabInventoryBalanceID
                                    },
                                    data: {
                                        AvailableSwabs: (getBoxBalanceDetail.AvailableSwabs + getSwabDispatchDetail.DispatchQty - val.DispatchQty)
                                    }
                                })
                            }

                            await prismaSwab.ClientSwabDispatchDetails.update({
                                where: {
                                    DispatchDetailID: val.DispatchDetailID
                                },
                                data: {
                                    DispatchQty: val.DispatchQty
                                }
                            });
                        };
                    }

                    // User may change Lot Number or BoxID to update the details
                    if (oldLotBoxChanges && oldLotBoxChanges.length > 0) {
                        for (let oldBoxLotIndex = 0; oldBoxLotIndex < oldLotBoxChanges.length; oldBoxLotIndex++) {

                            const lotBoxVal = oldLotBoxChanges[oldBoxLotIndex];
                            const newPurchaseDetail = await prismaSwab.SwabPurchaseDetails.findFirst({
                                where: {
                                    BoxID: lotBoxVal.BoxID
                                }
                            });

                            // Revert old value Balance and details
                            const oldValues = filteredSwabDispatchDetails.find((val: any) => val.DispatchDetailID === lotBoxVal.DispatchDetailID);
                            const getLotBalance = await prismaSwab.SwabInventoryLotBalance.findFirst({
                                where: {
                                    LotNumber: oldValues.LotNumber
                                }
                            });
                            await prismaSwab.SwabInventoryLotBalance.update({
                                where: {
                                    SwabInventoryBalanceID: getLotBalance.SwabInventoryBalanceID
                                },
                                data: {
                                    AvailableSwabs: (getLotBalance.AvailableSwabs + oldValues.DispatchQty)
                                }
                            });

                            const getBoxBalance = await prismaSwab.SwabInventoryBoxBalance.findFirst({
                                where: {
                                    PurchaseDetailID: oldValues.PurchaseDetailID
                                }
                            });
                            await prismaSwab.SwabInventoryBoxBalance.update({
                                where: {
                                    SwabInventoryBalanceID: getBoxBalance.SwabInventoryBalanceID
                                },
                                data: {
                                    AvailableSwabs: (getBoxBalance.AvailableSwabs + oldValues.DispatchQty)
                                }
                            });
                            await prismaSwab.ClientSwabDispatchDetails.update({
                                where: {
                                    DispatchDetailID: lotBoxVal.DispatchDetailID
                                },
                                data: {
                                    DispatchQty: lotBoxVal.DispatchQty
                                }
                            });

                            // Update the new Lot Number BoxID qty dispatch details
                            const getUpdatedSwabRequestDetails = await prismaSwab.ClientSwabDispatchDetails.update({
                                where: {
                                    DispatchDetailID: lotBoxVal.DispatchDetailID
                                },
                                data: {
                                    DispatchQty: lotBoxVal.DispatchQty,
                                    LotNumber: lotBoxVal.LotNumber,
                                    PurchaseDetailID: newPurchaseDetail.PurchaseDetailID,
                                    LastModifiedBy: lastModifiedBy,
                                    LastModifiedOn: new Date()
                                }
                            });
                            const getNewLotBalance = await prismaSwab.SwabInventoryLotBalance.findFirst({
                                where: {
                                    LotNumber: lotBoxVal.LotNumber
                                }
                            });
                            await prismaSwab.SwabInventoryLotBalance.update({
                                where: {
                                    SwabInventoryBalanceID: getNewLotBalance.SwabInventoryBalanceID
                                },
                                data: {
                                    AvailableSwabs: (getNewLotBalance.AvailableSwabs - lotBoxVal.DispatchQty)
                                }
                            });
                            const getNewBoxBalance = await prismaSwab.SwabInventoryBoxBalance.findFirst({
                                where: {
                                    PurchaseDetailID: newPurchaseDetail.PurchaseDetailID
                                }
                            });
                            await prismaSwab.SwabInventoryBoxBalance.update({
                                where: {
                                    SwabInventoryBalanceID: getNewBoxBalance.SwabInventoryBalanceID
                                },
                                data: {
                                    AvailableSwabs: (getNewBoxBalance.AvailableSwabs - lotBoxVal.DispatchQty)
                                }
                            });
                        };
                    }

                    // User Added new request detail(Lot Number, BoxID and Dispatch Qty)
                    if (newDispatchDetails && newDispatchDetails.length > 0) {
                        for (let newDispatchIndex = 0; newDispatchIndex < newDispatchDetails.length; newDispatchIndex++) {

                            const newVal = newDispatchDetails[newDispatchIndex];

                            const getPurchaseDetail = await prismaSwab.SwabPurchaseDetails.findFirst({
                                where: {
                                    BoxID: newVal.BoxID
                                }
                            });
                            await prismaSwab.ClientSwabDispatchDetails.create({
                                data: {
                                    DispatchMasterID: dispatchMasterDetails.DispatchMasterID,
                                    RequestID: getRequestDispatchDetail.RequestID,
                                    DispatchQty: newVal.DispatchQty,
                                    LotNumber: newVal.LotNumber,
                                    LastModifiedBy: lastModifiedBy,
                                    LastModifiedOn: new Date(),
                                    PurchaseDetailID: getPurchaseDetail.PurchaseDetailID
                                }
                            });
                            const getLotBalanceDetails = await prismaSwab.SwabInventoryLotBalance.findFirst({
                                where: {
                                    LotNumber: newVal.LotNumber
                                }
                            });
                            await prismaSwab.SwabInventoryLotBalance.update({
                                where: {
                                    SwabInventoryBalanceID: getLotBalanceDetails.SwabInventoryBalanceID
                                },
                                data: {
                                    AvailableSwabs: (getLotBalanceDetails.AvailableSwabs - newVal.DispatchQty)
                                }
                            });

                            const getBoxBalanceDetails = await prismaSwab.SwabInventoryBoxBalance.findFirst({
                                where: {
                                    PurchaseDetailID: getPurchaseDetail.PurchaseDetailID
                                }
                            });
                            await prismaSwab.SwabInventoryBoxBalance.update({
                                where: {
                                    SwabInventoryBalanceID: getBoxBalanceDetails.SwabInventoryBalanceID
                                },
                                data: {
                                    AvailableSwabs: (getBoxBalanceDetails.AvailableSwabs - newVal.DispatchQty)
                                }
                            });
                        };

                    }

                    // To update Client Swab Request Details
                    if (removedDispatchDetails.length > 0 || onlyDispatchQtyChanges.length > 0 || oldLotBoxChanges.length > 0 || newDispatchDetails.length > 0) {

                        const getTotRequestedQty = await prismaSwab.ClientSwabDispatchDetails.groupBy({
                            by: ["RequestID"],
                            _sum: {
                                DispatchQty: true
                            },
                            where: {
                                RequestID: getRequestDispatchDetail.RequestID,
                            }
                        });
                        const getSwabRequestDetails = await prismaSwab.ClientSwabRequestDetails.findFirst({
                            where: {
                                RequestID: getRequestDispatchDetail.RequestID,
                            }
                        });
                        await prismaSwab.ClientSwabRequestDetails.update({
                            where: {
                                RequestID: getRequestDispatchDetail.RequestID,
                            },
                            data: {
                                ShippedQty: getTotRequestedQty[0]._sum.DispatchQty,
                                TobeShippedQty: (getSwabRequestDetails.QtyRequested - getTotRequestedQty[0]._sum.DispatchQty),
                                LastModifiedBy: lastModifiedBy,
                                LastModifiedOn: new Date()
                            }
                        });
                    }
                };
            }



            if (fetchDispatchMasterDetails.DeliveryStatusID !== DeliveryStatus.Return) {
                if (fetchDispatchMasterDetails != null && fetchDispatchMasterDetails != undefined) {
                    if (dispatchDetails != undefined && dispatchDetails != null) {

                        await prismaSwab.clientSwabDispatchMasterAudit.create({
                            data: fetchDispatchMasterDetails
                        });

                        let clientShipmentAddress: any = await createClientShipmentAddress({ ...shipmentDetails, Address2: shipmentDetails.ShippingAddress2, ...dispatchMasterDetails });

                        const updateDispatchMasterDetail = await prismaSwab.clientSwabDispatchMaster.update({
                            where: {
                                DispatchMasterID: dispatchMasterDetails.DispatchMasterID
                            },
                            data: {
                                ClientID: Number(dispatchMasterDetails.ClientID),
                                DispatchDate: convertDispatchDate.format(),
                                DispatchBy: dispatchMasterDetails.DispatchBy,
                                ShipCarrierID: Number(dispatchMasterDetails.ShipCarrierID),
                                ShippingTrackingNumber: dispatchMasterDetails.ShippingTrackingNumber.replace(/\s/g, ""),
                                DeliveryStatusID: Number(dispatchMasterDetails.DeliveryStatusID),
                                DeliveryDate: convertDeliveryDate.format(),
                                ReceiverName: dispatchMasterDetails.ReceiverName,
                                ShipmentandHandlingCost: dispatchMasterDetails.ShipmentandHandlingCost,
                                SwabCost: dispatchMasterDetails.SwabCost,
                                LastModifiedBy: Number(dispatchMasterDetails.LastModifiedBy),
                                LastModifiedOn: new Date(),
                                InvCurrency: dispatchMasterDetails.InvCurrency,
                                IsInvoiceRaised: dispatchMasterDetails.IsInvoiceRaised,
                                ClientShipmentAddressID: clientShipmentAddress.ClientShipmentAddressID
                            }
                        });
                        for (let i = 0; i < dispatchDetails.length; i++) {

                            const requestDetails: any = await prismaSwab.clientSwabRequestDetails.findUnique({
                                where: {
                                    RequestID: Number(dispatchDetails[i].RequestID)
                                }
                            });

                            if (requestDetails != null && requestDetails != undefined) {

                                // update the dispatch and request details for return dispatch
                                if (dispatchMasterDetails.DeliveryStatusID == DeliveryStatus.Return) {
                                    let dispacthQtyTotal: number = 0;
                                    let fetchDispatchDetail: any = await prismaSwab.clientSwabDispatchDetails.findMany({
                                        where: {
                                            DispatchMasterID: Number(dispatchMasterDetails.DispatchMasterID),
                                            RequestID: Number(dispatchDetails[i].RequestID)
                                        }
                                    });

                                    for (let j = 0; j < fetchDispatchDetail.length; j++) {
                                        // await prismaSwab.clientSwabDispatchDetailsAudit.create({  //audit - auto update using DB profiler
                                        //     data: fetchDispatchDetail[j]
                                        // });
                                        let SwabInventoryLotBalanceList: any = await prismaSwab.SwabInventoryLotBalance.findFirst({
                                            where: {
                                                LotNumber: dispatchDetails[i].lotQtyDetails[j].LotNumber
                                            }
                                        });
                                        await prismaSwab.SwabInventoryLotBalance.update({
                                            where: {
                                                SwabInventoryBalanceID: SwabInventoryLotBalanceList.SwabInventoryBalanceID
                                            },
                                            data: {
                                                AvailableSwabs: Number(SwabInventoryLotBalanceList.AvailableSwabs) + Number(dispatchDetails[i].lotQtyDetails[j].DispatchQty),
                                            }
                                        });
                                        let SwabInventoryBoxBalanceList: any = await prismaSwab.SwabInventoryBoxBalance.findFirst({
                                            where: {
                                                PurchaseDetailID: fetchDispatchDetail[j].PurchaseDetailID
                                            }
                                        });
                                        await prismaSwab.SwabInventoryBoxBalance.update({
                                            where: {
                                                SwabInventoryBalanceID: SwabInventoryBoxBalanceList.SwabInventoryBalanceID
                                            },
                                            data: {
                                                AvailableSwabs: Number(SwabInventoryBoxBalanceList.AvailableSwabs) + Number(dispatchDetails[i].lotQtyDetails[j].DispatchQty),
                                            }
                                        });

                                        dispacthQtyTotal += fetchDispatchDetail[j].DispatchQty;

                                        let updateDispatch: any = await prismaSwab.clientSwabDispatchDetails.update({
                                            where: {
                                                DispatchDetailID: Number(fetchDispatchDetail[j].DispatchDetailID)
                                            },
                                            data: {
                                                DispatchQty: 0,
                                                LastModifiedBy: Number(dispatchDetails[i].LastModifiedBy),
                                                LastModifiedOn: new Date()
                                            },
                                        });
                                    }
                                    // await prismaSwab.clientSwabRequestDetailsAudit.create({ //audit - Auto update using DB profiler
                                    //     data: requestDetails
                                    // });

                                    const updateRequestDetail = await prismaSwab.clientSwabRequestDetails.update({
                                        where: {
                                            RequestID: Number(dispatchDetails[i].RequestID)
                                        },
                                        data: {
                                            ShippedQty: requestDetails.ShippedQty - dispacthQtyTotal,
                                            TobeShippedQty: requestDetails.TobeShippedQty + dispacthQtyTotal,
                                            LastModifiedBy: Number(dispatchDetails[i].LastModifiedBy),
                                            LastModifiedOn: new Date()
                                        }
                                    });
                                }

                                const fetchShipmentDetail: any = await prismaSwab.swabShipmentClients.findFirst({
                                    where: {
                                        RequestID: Number(requestDetails.RequestID)
                                    }
                                });

                                await prismaSwab.SwabShipmentClientsAudit.create({
                                    data: fetchShipmentDetail
                                });


                            } else {
                                return new ResponseModel(false, "Request not found");
                            }
                        }

                        if (isInvoiceRaised && (dispatchMasterDetails.ShippingTrackingNumber !== fetchDispatchMasterDetails.ShippingTrackingNumber || isInvoiceCancelled)) { //
                            await InvoiceDataAccess.refreshInvoiceDetails(dispatchMasterDetails.DispatchMasterID);

                            // Auto Generate Invoice if existing invoice is cancelled
                            // const ClientBillingAddressDetails = await InvoiceDataAccess.getClientAddressFromBillingAddressId(usInvoiceRecord?.ClientBillingAddressID);
                            // const clientRecordDetails = await InvoiceDataAccess.getClientRecord(dispatchMasterDetails.ClientID)
                            // const dispatchDetailByMasterId: any = await prismaSwab.clientSwabDispatchDetails.findMany({
                            //     where: {
                            //         DispatchMasterID: dispatchMasterDetails.DispatchMasterID
                            //     },
                            //     include: {
                            //         ClientSwabRequestDetails: true
                            //     }
                            // });

                            // if (ClientBillingAddressDetails && clientRecordDetails && usInvoiceRecord) {

                            //     await prismaSwab.cancelInvoiceDetails.create({
                            //         data: {
                            //             DispatchMasterID: dispatchMasterDetails.DispatchMasterID,
                            //             InvoiceNumber: invoiceNumber
                            //         }
                            //     });

                            //     const swabCostDetails = dispatchDetailByMasterId.reduce((result: any, val: any) => {
                            //         const swabCost = val.DispatchQty * val.ClientSwabRequestDetails.SwabPricePerUnit;
                            //         if (typeof (result) === "number") {
                            //             return { dispatchQty: val.DispatchQty, swabTotalCost: swabCost, swabType: [val.ClientSwabRequestDetails.SwabUOMID] }
                            //         }
                            //         return { dispatchQty: result.dispatchQty + val.DispatchQty, swabTotalCost: result.swabTotalCost + swabCost, swabType: [...result.swabType, val.ClientSwabRequestDetails.SwabUOMID] };
                            //     }, 0);

                            //     const swabTypes = await prismaSwab.swabUOM.findMany({
                            //         where: {
                            //             SwabUOMID: {
                            //                 in: swabCostDetails.swabType
                            //             }
                            //         }
                            //     });

                            //     const swabTypeJoins = swabTypes.map((val: any) => val.SwabUOM).join(",");

                            //     const invoiceDetails = {
                            //         ClientID: dispatchMasterDetails.ClientID,
                            //         PoNumber: usInvoiceRecord?.USInvoicePOInfo || "",
                            //         SwabUOM: swabTypeJoins,
                            //         ClientName: clientRecordDetails?.ClientName,
                            //         ClientProjectID: usInvoiceRecord.ClientProjectID,
                            //         DispatchQty: swabCostDetails.dispatchQty,
                            //         SwabCost: Number(swabCostDetails.swabTotalCost),
                            //         DispatchMasterID: dispatchMasterDetails.DispatchMasterID,
                            //         ShipmentCharges: dispatchMasterDetails.ShipmentandHandlingCost,
                            //         LastModifiedBy: dispatchMasterDetails.LastModifiedBy
                            //     }

                            //     const invoiceAddress = {
                            //         billToName: ClientBillingAddressDetails.BillToName,
                            //         billToAdditionalName: ClientBillingAddressDetails.BillToAdditionalName,
                            //         billToAddress1: ClientBillingAddressDetails.BillToAddress1,
                            //         billToAddress2: ClientBillingAddressDetails.BillToAddress2,
                            //         billToCity: ClientBillingAddressDetails.BillToCity,
                            //         billToState: ClientBillingAddressDetails.BillToState,
                            //         billToPostalCode: ClientBillingAddressDetails.BillToPostalCode,
                            //         billToCountry: ClientBillingAddressDetails.BillToCountry,
                            //         otherDetail1: ClientBillingAddressDetails.OtherDetail1,
                            //         otherDetail2: ClientBillingAddressDetails.OtherDetail2,
                            //         otherDetail3: ClientBillingAddressDetails.OtherDetail3,
                            //         ClientBillingAddressID: ClientBillingAddressDetails.ClientBillingAddressID,
                            //         ClientID: ClientBillingAddressDetails.ClientID,
                            //         isCurrentAddress: ClientBillingAddressDetails.IsitDefault,
                            //         activedDate: ClientBillingAddressDetails.ActivedDate,
                            //         LastModifiedBy: dispatchMasterDetails.LastModifiedBy
                            //     };

                            //     const newInvoiceDetails = await InvoiceDataAccess.createInvoice({ invoiceDetails, invoiceAddress });
                            //     if (newInvoiceDetails && newInvoiceDetails.success) {
                            //         const emailCloseRequest = {
                            //             DispatchID: dispatchMasterDetails.DispatchMasterID,
                            //             LastModifiedBy: dispatchMasterDetails.LastModifiedBy,
                            //             invoiceNumber: newInvoiceDetails?.data?.invoiceNumber || invoiceNumber,
                            //             ClientID: dispatchMasterDetails.ClientID,
                            //             ClientProjectID: usInvoiceRecord.ClientProjectID,
                            //             SwabUOM: swabTypeJoins
                            //         }
                            //         const referenceDocumentDetails = await prismaSwab.referenceDocuments.findFirst({
                            //             where: {
                            //                 RefTypeID: dispatchMasterDetails.DispatchMasterID,
                            //                 RefType: Constants.INVOICE_REF_TYPE,
                            //                 DocumentName: {
                            //                     startsWith: `Inv${invoiceNumber}`
                            //                 }
                            //             }
                            //         });
                            //         await Promise.all([
                            //             InvoiceDataAccess.updateInvoiceNumberDetails(dispatchMasterDetails.DispatchMasterID, newInvoiceDetails?.data?.invoiceNumber),
                            //             InvoiceDataAccess.closeEmail(newInvoiceDetails.data.invoiceNumber, true, emailCloseRequest),
                            //             referenceDocumentDetails && prismaSwab.referenceDocuments.delete({
                            //                 where: {
                            //                     RefDocID: referenceDocumentDetails.RefDocID
                            //                 }
                            //             }),
                            //         ]);
                            //     }
                            // }
                        }

                        return new ResponseModel(true, "Disptach detail updated successfully");
                    } else {
                        return new ResponseModel(false, "Request details not found");
                    }
                } else {
                    return new ResponseModel(false, "Disptach master not found");
                }
            } else {
                return new ResponseModel(false, "Can't update return delivery");
            }

        } catch (error) {
            console.log(error)
            return new ResponseModel(false, "Prisma error", error);
        }

    }

    export async function deleteDispatchtById(DispatchMasterID: any): Promise<ResponseModel> {
        try {
            let delRefDocs;

            let dispatchMaster: any = await prismaSwab.clientSwabDispatchMaster.findUnique({
                where: {
                    DispatchMasterID: Number(DispatchMasterID)
                }
            });

            let dispatchDetail: any = await prismaSwab.clientSwabDispatchDetails.findMany({
                where: {
                    DispatchMasterID: Number(DispatchMasterID)
                }
            });

            const refDocs: any[] = await prismaSwab.referenceDocuments.findMany({
                where: {
                    RefTypeID: Number(DispatchMasterID)
                }
            });

            if (dispatchDetail != null && dispatchDetail != undefined && dispatchMaster != null && dispatchMaster != undefined && dispatchDetail.length > 0) {
                if (dispatchMaster.DeliveryStatusID == 1) {
                    // audit
                    await prismaSwab.clientSwabDispatchMasterAudit.create({
                        data: dispatchMaster
                    });

                    // await prismaSwab.clientSwabDispatchDetailsAudit.createMany({ //audit - auto update using DB profiler
                    //     data: dispatchDetail
                    // });

                    if (refDocs != null && refDocs != undefined && refDocs.length != 0) {

                        await prismaSwab.referenceDocumentsAudit.createMany({
                            data: refDocs
                        });

                        delRefDocs = await prismaSwab.referenceDocuments.deleteMany({
                            where: { RefTypeID: Number(DispatchMasterID) }
                        });
                    }

                    for (let i = 0; i < dispatchDetail.length; i++) {
                        let requestDetail: any = await prismaSwab.clientSwabRequestDetails.findUnique({
                            where: {
                                RequestID: dispatchDetail[i].RequestID
                            }
                        });

                        // await prismaSwab.clientSwabRequestDetailsAudit.create({ Audit - Auto update using DB profiler
                        //     data: requestDetail
                        // });

                        let updateRequestDetail = await prismaSwab.clientSwabRequestDetails.update({
                            where: {
                                RequestID: dispatchDetail[i].RequestID
                            },
                            data: {
                                ShippedQty: requestDetail.ShippedQty - Number(dispatchDetail[i].DispatchQty),
                                TobeShippedQty: requestDetail.TobeShippedQty + Number(dispatchDetail[i].DispatchQty)
                            }
                        });
                    }
                    const delDispatchDetail = await prismaSwab.clientSwabDispatchDetails.deleteMany({
                        where: {
                            DispatchMasterID: Number(DispatchMasterID)
                        }
                    });
                    const deldispatchMaster = await prismaSwab.clientSwabDispatchMaster.delete({
                        where: {
                            DispatchMasterID: Number(DispatchMasterID)
                        }
                    });

                    return new ResponseModel(true, "Deleted successfully");
                } else {
                    return new ResponseModel(false, "Can't delete complete/return delivery");
                }


            } else {
                return new ResponseModel(false, "Dispatch master not found",);
            }

        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal server error", error);
        }
    }

    export async function getAllDispatch(): Promise<any> {
        try {
            return new Promise<any>((resolve, reject) => {
                shipmentTrackingSystemConnectionPool.connect().then((_con) => {
                    const request = new Sql.Request(_con);
                    request.execute('GetAllDispatchDetails').then(async (val: IResult<any>) => {
                        if (val.recordset != null && val.recordset != undefined && val.recordset.length != 0) {

                            let formatedDispatches = await SwabOrderDA.formatDispatchDetails(val.recordset);
                            resolve(formatedDispatches);
                        } else {
                            resolve(val.recordset);
                        }

                    }).catch((err: Sql.MSSQLError) => {
                        reject(err.message);
                    });
                });
            });
        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal server error", error);
        }
    }

    export async function formatDispatchDetails(dispatchs: any): Promise<any> {
        let formatedDispatch: any[] = [];

        let totalDispatchQty: number = 0;
        let swabtypes: any[] = [];
        let swabDescription: any;

        for (let i = 0; i < dispatchs.length; i++) {
            let tempDispatchDetails: any[] = [];
            let dispatchDetailByMasterId: any = await prismaSwab.clientSwabDispatchDetails.findMany({
                where: {
                    DispatchMasterID: dispatchs[i].DispatchMasterID
                },
                include: {
                    ClientSwabRequestDetails: true
                }
            });
            let dispatchMasterList = await prismaSwab.clientSwabDispatchMaster.findFirst({
                where: {
                    DispatchMasterID: dispatchs[i].DispatchMasterID
                },
            });
            let shippmentDetail = await prismaSwab.ClientShippingAddresses.findFirst({
                where: {
                    ClientShipmentAddressID: dispatchMasterList.ClientShipmentAddressID ? dispatchMasterList.ClientShipmentAddressID : 0
                }
            });
            // let getNotesInfo = await prismaSwab.swabShipmentClients.findFirst({
            //     where:{
            //         RequestID :dispatchDetailByMasterId.RequestID
            //     },
            //     select:{
            //         Notes:true
            //     }
            // })
            // if(shippmentDetail) shippmentDetail.Notes = getNotesInfo.Notes;

            let formatDispatchDetails: any[] = [];
            for (let j = 0; j < dispatchDetailByMasterId.length; j++) {
                const validIndex = formatDispatchDetails.findIndex(val => val.RequestID === dispatchDetailByMasterId[j].RequestID);
                if (validIndex >= 0) {
                    formatDispatchDetails[validIndex].lotQtyDetails = [...formatDispatchDetails[validIndex].lotQtyDetails, dispatchDetailByMasterId[j]];
                } else {
                    formatDispatchDetails = [...formatDispatchDetails, { RequestID: dispatchDetailByMasterId[j].RequestID, DispatchMasterID: dispatchDetailByMasterId[j].DispatchMasterID, lotQtyDetails: [dispatchDetailByMasterId[j]] }];
                }
            }
            for (let j = 0; j < formatDispatchDetails.length; j++) {
                let swapType = await prismaSwab.swabUOM.findUnique({
                    where: {
                        SwabUOMID: formatDispatchDetails[j].lotQtyDetails[0].ClientSwabRequestDetails.SwabUOMID
                    }
                });

                let lotQtyDetails: any[] = [];
                for (let k = 0; k < formatDispatchDetails[j].lotQtyDetails.length; k++) {
                    let lotQtyDetail;
                    if (formatDispatchDetails[j].lotQtyDetails[k].PurchaseDetailID) {
                        let SwabPurchaseDetailsList = await prismaSwab.SwabPurchaseDetails.findUnique({
                            where: {
                                PurchaseDetailID: formatDispatchDetails[j].lotQtyDetails[k].PurchaseDetailID
                            }
                        });
                        lotQtyDetail = {
                            DispatchQty: formatDispatchDetails[j].lotQtyDetails[k].DispatchQty,
                            BoxID: SwabPurchaseDetailsList.BoxID,
                            LotNumber: formatDispatchDetails[j].lotQtyDetails[k].LotNumber,
                            DispatchDetailID: formatDispatchDetails[j].lotQtyDetails[k].DispatchDetailID,
                            DispatchMasterID: formatDispatchDetails[j].lotQtyDetails[k].DispatchMasterID,
                            PurchaseDetailID: formatDispatchDetails[j].lotQtyDetails[k].PurchaseDetailID
                        }
                    }
                    else {
                        lotQtyDetail = {
                            DispatchQty: formatDispatchDetails[j].lotQtyDetails[k].DispatchQty,
                            BoxID: "",
                            LotNumber: formatDispatchDetails[j].lotQtyDetails[k].LotNumber,
                            DispatchDetailID: formatDispatchDetails[j].lotQtyDetails[k].DispatchDetailID,
                            DispatchMasterID: formatDispatchDetails[j].lotQtyDetails[k].DispatchMasterID,
                            PurchaseDetailID: formatDispatchDetails[j].lotQtyDetails[k].PurchaseDetailID
                        }
                    }

                    totalDispatchQty = totalDispatchQty + formatDispatchDetails[j].lotQtyDetails[k].DispatchQty;
                    lotQtyDetails.push(lotQtyDetail);
                }
                swabtypes[j] = swapType?.SwabUOM;

                const { DispatchQty, LotNumber, ClientSwabRequestDetails, ...rest } = formatDispatchDetails[j].lotQtyDetails[0];
                const { SwabPricePerUnit, ...swabRequestRest } = ClientSwabRequestDetails;
                const dispatchDetails = {
                    ...rest,
                    ClientSwabRequestDetails: {
                        ...swabRequestRest,
                        SwabUOM: swapType?.SwabUOM,
                        PricePerUnit: SwabPricePerUnit
                    },
                    lotQtyDetails
                }
                tempDispatchDetails = [...tempDispatchDetails, dispatchDetails];

            }

            //             for (let j = 0; j < dispatchDetailByMasterId.length; j++) {
            //                 let swapType = await prismaSwab.swabUOM.findUnique({
            //                     where: {
            //                         SwabUOMID: dispatchDetailByMasterId[j].ClientSwabRequestDetails.SwabUOMID
            //                     }
            //                 });

            //                 let dispatchDetailsByRequestAndDispatchMasterId: any[] = await prismaSwab.clientSwabDispatchDetails.findMany({
            //                     where: {
            //                         RequestID: dispatchDetailByMasterId[j].RequestID,
            //                         DispatchMasterID: dispatchDetailByMasterId[j].DispatchMasterID
            //                     }
            //                 });
            //                 let lotQtyDetails: any[] = [];
            //                 for (let k = 0; k < dispatchDetailsByRequestAndDispatchMasterId.length; k++) {
            //                     let lotQtyDetail;
            //                     if (dispatchDetailsByRequestAndDispatchMasterId[k].PurchaseDetailID) {
            //                         let SwabPurchaseDetailsList = await prismaSwab.SwabPurchaseDetails.findUnique({
            //                             where: {
            //                                 PurchaseDetailID: dispatchDetailsByRequestAndDispatchMasterId[k].PurchaseDetailID
            //                             }
            //                         });
            //                         lotQtyDetail = {
            //                             DispatchQty: dispatchDetailsByRequestAndDispatchMasterId[k].DispatchQty,
            //                             BoxID: SwabPurchaseDetailsList.BoxID,
            //                             LotNumber: dispatchDetailsByRequestAndDispatchMasterId[k].LotNumber,
            //                             DispatchDetailID: dispatchDetailsByRequestAndDispatchMasterId[k].DispatchDetailID,
            //                             DispatchMasterID: dispatchDetailsByRequestAndDispatchMasterId[k].DispatchMasterID,
            //                             PurchaseDetailID: dispatchDetailsByRequestAndDispatchMasterId[k].PurchaseDetailID
            //                         }
            //                     }
            //                     else {
            //                         lotQtyDetail = {
            //                             DispatchQty: dispatchDetailsByRequestAndDispatchMasterId[k].DispatchQty,
            //                             BoxID: "",
            //                             LotNumber: dispatchDetailsByRequestAndDispatchMasterId[k].LotNumber,
            //                             DispatchDetailID: dispatchDetailsByRequestAndDispatchMasterId[k].DispatchDetailID,
            //                             DispatchMasterID: dispatchDetailsByRequestAndDispatchMasterId[k].DispatchMasterID,
            //                             PurchaseDetailID: dispatchDetailsByRequestAndDispatchMasterId[k].PurchaseDetailID
            //                         }
            //                     }

            //                     totalDispatchQty = totalDispatchQty + dispatchDetailsByRequestAndDispatchMasterId[k].DispatchQty;
            //                     lotQtyDetails.push(lotQtyDetail);

            //                     if (k == 1) {
            //                     dispatchDetailByMasterId.forEach((item: any, index: any) => {
            //                     // item.DispatchDetailID === dispatchDetailsByRequestAndDispatchMasterId[index].DispatchDetailID
            //                     if (index == 0) {
            //                     dispatchDetailByMasterId.splice(1, dispatchDetailsByRequestAndDispatchMasterId.length - 1);
            //                     }
            // });
            //                     }
            //                 }

            //                 // dispatchDetailByMasterId[j].ShipmentClients = shippmentDetail;
            //                 dispatchDetailByMasterId[j].ClientSwabRequestDetails.SwabUOM = swapType?.SwabUOM;
            //                 dispatchDetailByMasterId[j].ClientSwabRequestDetails.PricePerUnit = dispatchDetailByMasterId[j].ClientSwabRequestDetails.SwabPricePerUnit;
            //                 // totalDispatchQty = totalDispatchQty + dispatchDetailByMasterId[j].DispatchQty;
            //                 swabtypes[j] = swapType?.SwabUOM;



            //                 dispatchDetailByMasterId[j].lotQtyDetails = lotQtyDetails;

            //                 delete dispatchDetailByMasterId[j].DispatchQty;
            //                 delete dispatchDetailByMasterId[j].LotNumber;
            //                 delete dispatchDetailByMasterId[j].ClientSwabRequestDetails.SwabPricePerUnit;
            //             }

            swabtypes = Array.from(new Set(swabtypes));  // get unique valeus
            // swabDescription = Array.from(new Set(swabDescription));
            if (swabtypes.length > 1) {
                swabDescription = Constants.FLOQSwabs_DES + "," + Constants.Buccal_Swab_Kit_DES;
            } else if (swabtypes[0] == Constants.FLOQSwabs) {
                swabDescription = Constants.FLOQSwabs_DES;
            } else {
                swabDescription = Constants.Buccal_Swab_Kit_DES;
            }

            if (dispatchs[i].InvoiceNumber == 0) {
                dispatchs[i].InvoiceNumber = "";
                dispatchs[i].PaymentStatus = 'Not Applicable';
                dispatchs[i].PaymentStatusCode = 'NA';
            }

            // Add tracknig link/href
            let trackingLink: string = '';

            if (ShipmentCarriers.FEDEX == dispatchs[i].ShipmentCarrier) {
                trackingLink = Constants.FEDEX_TRACKING_LINK + dispatchs[i].ShippingTrackingNumber
            }

            let ClientSwabDispatchMasterList = await prismaSwab.ClientSwabDispatchMaster.findUnique({
                where: {
                    DispatchMasterID: dispatchs[i].DispatchMasterID
                },
                select: {
                    InvCurrency: true,
                    IsInvoiceRaised: true
                }
            });

            let dispatchDetail = {
                DispatchMasterID: dispatchs[i].DispatchMasterID,
                ClientID: dispatchs[i].ClientID,
                ClientName: dispatchs[i].ClientName,
                ShipmentCarrierID: dispatchs[i].ShipmentCarrierID,
                DeliveryStatusID: dispatchs[i].DeliveryStatusID,
                DispatchDate: dispatchs[i].DispatchDate,
                SwabUOM: swabtypes.join(),  // combine swabtype values
                SwabDescription: swabDescription,
                DispatchQty: totalDispatchQty,
                DispatchBy: dispatchs[i].DispatchBy,
                ShippingTrackingNumber: dispatchs[i].ShippingTrackingNumber,
                ShipmentTrackingLink: trackingLink,
                DeliveryDate: dispatchs[i].DeliveryDate,
                ReceiverName: dispatchs[i].ReceiverName,
                ShipmentandHandlingCost: dispatchs[i].ShipmentandHandlingCost,
                SwabCost: dispatchs[i].SwabCost,
                ShipmentCarrier: dispatchs[i].ShipmentCarrier,
                DeliveryStatus: dispatchs[i].DeliveryStatus,
                InvoiceNumber: dispatchs[i].InvoiceNumber,
                PaymentStatus: dispatchs[i].PaymentStatus,
                PaymentStatusCode: dispatchs[i].PaymentStatusCode,
                InvoiceDate: dispatchs[i].InvoiceDate,
                dispathcDetail: tempDispatchDetails,
                InvCurrency: ClientSwabDispatchMasterList.InvCurrency,
                IsInvoiceRaised: ClientSwabDispatchMasterList.IsInvoiceRaised,
                documents: [],
                ShipmentClients: shippmentDetail
            }
            await DocumentsDA.getDispatchDocsInfo(dispatchs[i].DispatchMasterID).then((docs: any) => dispatchDetail = { ...dispatchDetail, documents: docs });
            formatedDispatch.push(dispatchDetail);
            totalDispatchQty = 0;
            swabtypes = [];
            swabDescription = '';
        }

        return formatedDispatch;
    }

    export async function getUniqueListBy(arr: any, key: any): Promise<any[]> {
        return [...new Map(arr.map((item: any) => [item[key], item])).values()]
    }

    export async function getShippingAddressByRequestID(RequestID: number): Promise<any> {
        try {
            const shippingDetail = await prismaSwab.swabShipmentClients.findFirst({
                where: {
                    RequestID: RequestID
                }
            });

            return shippingDetail;
        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Intenal server error", error);
        }
    }

    export async function getDispatchByFilters(filterValues: any): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            let fromDate = moment(filterValues.FromDate).format('lll');
            let toDate = moment(filterValues.ToDate).format('lll');
            shipmentTrackingSystemConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                if (filterValues.ClientID == null || filterValues.ClientID == undefined || filterValues.ClientID == '') {
                    filterValues.ClientID = 0;
                }
                request.input('DispatchPeriod', Sql.NVarChar, filterValues.DispatchPeriod)
                request.input('FromDate', Sql.NVarChar, fromDate)
                request.input('ToDate', Sql.NVarChar, toDate)
                request.input('ClientID', Sql.Int, filterValues.ClientID)
                request.input('PaymentStatus', Sql.NVarChar, filterValues.PaymentStatus)
                request.input('DeliveryStatus', Sql.NVarChar, filterValues.DeliveryStatus)

                request.execute('FilterDispatchDetail').then(async (val: IResult<any>) => {
                    if (val.recordset != null && val.recordset != undefined && val.recordset.length != 0) {
                        let formatedDispatches = await SwabOrderDA.formatDispatchDetails(val.recordset);
                        resolve(formatedDispatches);
                    } else {
                        resolve(val.recordset);
                    }
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    export async function getCustomsDoc(requestModel: any): Promise<any> {
        let swabtypes: any[] = [];
        let totalDispatchQty: number = 0;
        let isCustomDocExists: boolean = false;
        let customeDocument: any;
        try {
            let findCustomsDoc = await prismaSwab.referenceDocuments.findMany({
                where: {
                    RefType: "Customs Document",
                    RefTypeID: Number(requestModel.DispatchMasterID)
                },
                select: {
                    RefDocID: true,
                    RefType: true,
                    DocumentName: true,
                    DocumentTypes: {
                        select: {
                            DocumentName: true
                        }
                    }
                }
            });
            for (let i = 0; i < findCustomsDoc.length; i++) {
                if (findCustomsDoc[i].DocumentName?.includes("Customs")) {
                    isCustomDocExists = true;
                    customeDocument = findCustomsDoc[i];
                    break;
                }
            }
            if (findCustomsDoc == null || findCustomsDoc == undefined || isCustomDocExists == false) {

                let updateDispatchDetail: any = await prismaSwab.clientSwabDispatchMaster.update({
                    where: {
                        DispatchMasterID: requestModel.DispatchMasterID
                    },
                    data: {
                        ShippingTrackingNumber: requestModel.TrackingNumber.replace(/\s/g, "")
                    }
                });

                let dispatchDetailByMasterId: any = await prismaSwab.clientSwabDispatchDetails.findMany({
                    where: {
                        DispatchMasterID: requestModel.DispatchMasterID
                    },
                    include: {
                        ClientSwabRequestDetails: true
                    }
                });

                for (let j = 0; j < dispatchDetailByMasterId.length; j++) {
                    let swapType = await prismaSwab.swabUOM.findUnique({
                        where: {
                            SwabUOMID: dispatchDetailByMasterId[j].ClientSwabRequestDetails.SwabUOMID
                        }
                    });

                    totalDispatchQty = totalDispatchQty + dispatchDetailByMasterId[j].DispatchQty;
                    swabtypes[j] = swapType?.SwabUOM;
                }

                if (swabtypes.length > 1) {
                    swabtypes[1] = " " + swabtypes[1]
                }
                let clientDetail: any = await TrackingSystemDA.getClientById(updateDispatchDetail.ClientID);
                updateDispatchDetail.SwabUOM = swabtypes.join();
                updateDispatchDetail.DispatchQty = totalDispatchQty;
                updateDispatchDetail.ClientName = clientDetail.ClientName;

                let generateDoc = await DocumentGenerator.generateDispatchCustomsDoc(updateDispatchDetail);

                let docTypes = await prismaSwab.documentTypes.findFirst({
                    where: {
                        DocumentName: "DOCX"
                    }
                });

                let todayDate = new Date();
                todayDate = moment(todayDate).format('MM.DD.YYYY');

                let docName = `Customs' support-Buccal swab orders ${clientDetail.ClientName} ${todayDate}`
                let referanceDocs = {
                    RefType: "Customs Document",
                    RefTypeID: Number(requestModel.DispatchMasterID),
                    DocumentTypeID: docTypes?.DocumentTypeID,
                    DocumentContent: generateDoc,
                    DocumentName: docName
                }
                let saveCustomsDoc = await prismaSwab.referenceDocuments.create({
                    data: referanceDocs,
                    include: {
                        DocumentTypes: true
                    }
                });
                return { RefType: saveCustomsDoc.RefType, RefDocID: saveCustomsDoc.RefDocID, DocumentTypes: saveCustomsDoc.DocumentTypes, DocumentName: saveCustomsDoc.DocumentName };
            } else {
                return customeDocument;
            }
        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal server error", error);
        }
    }

    export async function getPackSlipPdf(requestModel: any): Promise<any> {

        try {
            let referanceDocs = null, resultData:any = {};
            let { DispatchMasterID } = requestModel;
            let fileCheck:any = await prismaSwab.referenceDocuments.findMany({
                where :{
                    RefTypeID: DispatchMasterID,
                    RefType: "Packing Slip",
                }
            })
            if(requestModel.trackingNumber){
                let updateDispatchDetail: any = await prismaSwab.clientSwabDispatchMaster.update({
                    where: {
                        DispatchMasterID: requestModel.DispatchMasterID
                    },
                    data: {
                        ShippingTrackingNumber: requestModel.trackingNumber.replace(/\s/g, "")
                    }
                });

            }
            if(!fileCheck || fileCheck.length === 0 ){
                let SDD_List: any = await prismaSwab.ClientSwabDispatchDetails.findMany({
                    where: {
                        DispatchMasterID: DispatchMasterID,
                    },
                    select: {
                        PurchaseDetailID: true,
                        RequestID: true,
                        DispatchQty: true,
                        LotNumber: true
                    }

                })
                let trackingNumberList = await prismaSwab.clientSwabDispatchMaster.findUnique({
                    where:{
                        DispatchMasterID: DispatchMasterID,
                    },
                    select:{
                        ShippingTrackingNumber:true,
                        DispatchDate:true,
                        ShipCarrierID:true,
                        DispatchMasterID:true,
                        ClientSwabDispatchDetails:true,
                        ClientShipmentAddressID:true,
                    }
                })

                let ClientSwabRequestList = await prismaSwab.ClientSwabRequestDetails.findUnique({
                    where:{
                        RequestID:trackingNumberList.ClientSwabDispatchDetails[0].RequestID
                    }
                })

                let shipmentCarrierList = await prismaSwab.T_ShipmentCarrier.findUnique({
                    where : {
                        ShipmentCarrierID:trackingNumberList.ShipCarrierID
                    },
                    select:{
                        ShipmentCarrier:true
                    }
                })

                let clientDetailHisto: any = await TrackingSystemDA.getClientById(requestModel.ClientID);
                let clientDetail = await prismaSwab.ClientShippingAddresses.findFirst({
                    where:{
                        ClientShipmentAddressID:trackingNumberList.ClientShipmentAddressID
                    }
                })
                clientDetail.trackingNumber = trackingNumberList.ShippingTrackingNumber;
                clientDetail.shipmentDate = trackingNumberList.DispatchDate;
                clientDetail.ShipCarrier = shipmentCarrierList.ShipmentCarrier;
                clientDetail.RequestedDate = ClientSwabRequestList.RequestedDate;
                clientDetail.ClientName = clientDetailHisto.ClientName;
                clientDetail.RequestorContactNumber = ClientSwabRequestList.RequestorContactNumber
                resultData.clientDetails = clientDetail;


                if( SDD_List.length > 0 && SDD_List){
                    for (let i = 0; SDD_List.length > i; i++) {
                        let SPD_List = await prismaSwab.SwabPurchaseDetails.findUnique({
                            where: {
                                PurchaseDetailID: SDD_List[i].PurchaseDetailID
                            },
                            select: {
                                ExpiryDate: true
                            }
                        })
                        let SRD_list = await prismaSwab.ClientSwabRequestDetails.findUnique({
                            where: {
                                RequestID: SDD_List[i].RequestID
                            },
                            select: {
                                SwabUOMID: true,
                                ClientID:true
                            }
                        })
                        let SwabUOM_list = await prismaSwab.SwabUOM.findUnique({
                            where: {
                                SwabUOMID: SRD_list.SwabUOMID
                            },
                            select: {
                                SwabUOMID:true,
                                Description: true
                            }
                        })
                        SDD_List[i].ExpiryDate = SPD_List.ExpiryDate;
                        SDD_List[i].SwabUOMID = SRD_list.SwabUOMID;
                        SDD_List[i].Description = SwabUOM_list.Description;
                    }
                    resultData.data = SDD_List;
                    let generateDoc = await PackingPdfGenerator.generatePackingPdf(resultData);
                    let docTypes = await prismaSwab.documentTypes.findFirst({
                        where: {
                            DocumentName: "PDF"
                        }
                    });
                    let docName = resultData.clientDetails.trackingNumber ? `${resultData.clientDetails.ClientName}_${resultData.clientDetails.trackingNumber}`: resultData.clientDetails.ClientName;
                    referanceDocs = {
                        RefType: "Packing Slip",
                        RefTypeID: Number(requestModel.DispatchMasterID),
                        DocumentTypeID: docTypes?.DocumentTypeID,
                        DocumentContent: generateDoc,
                        DocumentName: docName
                    }
                    let packingSlipDoc = await prismaSwab.referenceDocuments.create({
                        data: referanceDocs,
                        include: {
                            DocumentTypes: true
                        }
                    });
                    return { RefType: packingSlipDoc.RefType, RefDocID: packingSlipDoc.RefDocID, DocumentTypes: packingSlipDoc.DocumentTypes, DocumentName: packingSlipDoc.DocumentName };
                }
                return resultData;
            }else{
                return new ResponseModel(false, "File Already Exist");
            }
        } catch (err) {
            console.log(err);
            return new ResponseModel(false, "Internal server error", err);
        }
    }

    export async function getDispatchByRequestId(requestId: number): Promise<any> {
        let dispatchDetailsResponse: any = {
            clientName: null,
            requestDate: null,
            requestItem: null,
            typeOfSwab: null,
            currentStatus: null,
            dispatchDetails: null
        };
        let dispatchDetails: any[] = [];
        let requestStatus: string = '';
        try {
            let requestDetail = await prismaSwab.clientSwabRequestDetails.findUnique({
                where: {
                    RequestID: requestId
                }
            });

            let swabUOMDetails = await prismaSwab.swabUOM.findUnique({
                where: {
                    SwabUOMID: requestDetail.SwabUOMID
                }
            });

            if (requestDetail.QtyRequested == requestDetail.ShippedQty && requestDetail.TobeShippedQty == 0) {
                requestStatus = 'Fully Shipped';
            } else if (requestDetail.QtyRequested == requestDetail.TobeShippedQty && requestDetail.ShippedQty == 0) {
                requestStatus = 'Not Shipped';
            } else if (requestDetail.TobeShippedQty != 0 && requestDetail.ShippedQty != 0) {
                requestStatus = 'Partially Shipped';
            }

            let clientDetail: any = await TrackingSystemDA.getClientById(requestDetail.ClientID);

            dispatchDetails = await prismaSwab.clientSwabDispatchDetails.findMany({
                where: {
                    RequestID: requestId,
                    // ClientSwabDispatchMaster: { // this is for only completed dispatch
                    //     DeliveryStatusID: 2
                    // }
                }
            });

            for (let i = 0; i < dispatchDetails.length; i++) {
                let dispatchDetailsMaster = await prismaSwab.clientSwabDispatchMaster.findUnique({
                    where: {
                        DispatchMasterID: dispatchDetails[i].DispatchMasterID
                    }
                });
                dispatchDetailsMaster.InvoiceNumber = Number(dispatchDetailsMaster.InvoiceNumber);
                let deliveryStatus = await prismaSwab.deliveryMaster.findUnique({
                    where: {
                        DeliveryMasteID: dispatchDetailsMaster.DeliveryStatusID
                    }
                });

                let shippmentCarrier = await prismaSwab.t_ShipmentCarrier.findUnique({
                    where: {
                        ShipmentCarrierID: dispatchDetailsMaster.ShipCarrierID
                    }
                });
                if (dispatchDetailsMaster.InvoiceNumber != 0) {
                    let invoiceDetails = await getUSInvoicesByInvoiceNumber(dispatchDetailsMaster.InvoiceNumber);
                    if (invoiceDetails == undefined) {
                        dispatchDetails[i].invoiceDate = '';
                        dispatchDetails[i].paymentStatus = 'Not Applicable';
                        dispatchDetails[i].paymentStatusCode = 'NA';
                        dispatchDetails[i].paymentStatusID = 0;
                    } else {
                        dispatchDetails[i].invoiceDate = invoiceDetails.InvoiceDate ? invoiceDetails.InvoiceDate : '';
                        dispatchDetails[i].paymentStatus = invoiceDetails.PaymentStatus;
                        dispatchDetails[i].paymentStatusCode = invoiceDetails.PaymentStatusCode;
                        dispatchDetails[i].paymentStatusID = invoiceDetails.PaymentStatusID;

                    }

                } else {
                    dispatchDetails[i].invoiceDate = '';
                    dispatchDetails[i].paymentStatus = 'Not Applicable';
                    dispatchDetails[i].paymentStatusCode = 'NA';
                    dispatchDetails[i].paymentStatusID = 0;
                }

                // Add tracknig link/href
                let trackingLink: string = '';

                if (ShipmentCarriers.FEDEX == shippmentCarrier.ShipmentCarrier) {
                    trackingLink = Constants.FEDEX_TRACKING_LINK + dispatchDetailsMaster.ShippingTrackingNumber
                }

                dispatchDetails[i].dispatchDetailsMaster = dispatchDetailsMaster;
                dispatchDetails[i].deliveryStatus = deliveryStatus;
                dispatchDetails[i].dispatchDetailsMaster.shipmentCarrier = shippmentCarrier.ShipmentCarrier;
                dispatchDetails[i].dispatchDetailsMaster.ShipmentTrackingLink = trackingLink;



            }



            dispatchDetailsResponse.clientName = clientDetail.ClientName;
            dispatchDetailsResponse.requestDate = requestDetail.RequestedDate;
            dispatchDetailsResponse.requestItem = requestDetail.QtyRequested;
            dispatchDetailsResponse.typeOfSwab = swabUOMDetails;
            dispatchDetailsResponse.currentStatus = requestStatus;
            dispatchDetailsResponse.dispatchDetails = dispatchDetails;

            if (dispatchDetailsResponse != null && dispatchDetailsResponse != undefined && dispatchDetails.length > 0) {
                return new ResponseModel(true, "Data found", dispatchDetailsResponse);
            } else {
                return new ResponseModel(false, "Data not found");
            }

        } catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal Server Error", error);
        }
    }

    async function getUSInvoicesByInvoiceNumber(invoiceNumber: number): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then((_con) => {
                const request = new Sql.Request(_con);
                request.input('InvoiceNumber', Sql.BigInt, invoiceNumber);
                request.execute('GetUSInvoicesByInvoiceNumber').then((val: IResult<any>) => {
                    resolve(val.recordset[0]);
                }).catch((err: Sql.MSSQLError) => {
                    reject(err.message);
                });
            });
        });
    }

    export const getBoxID = async (): Promise<any> => {
        try {
            let boxID = await prismaSwab.SwabInventoryBoxBalance.findMany({
                where: {
                    AvailableSwabs: {
                        gt: 0
                    },
                    SwabPurchaseDetails: {
                        ExpiryDate: {
                            gte: new Date(moment().utc())
                        }
                    }
                },
                select: {
                    SwabPurchaseDetails: {
                        select: {
                            BoxID: true
                        }
                    }
                }
            });
            if (boxID.length > 0) {
                boxID = boxID.map((val: any) => val.SwabPurchaseDetails.BoxID);
                boxID = [...new Set(boxID)];
            }
            else {
                boxID = [];
            }
            return { BoxID: boxID };
        }
        catch (error) {
            console.log(error);
            return new ResponseModel(false, "Internal Server Error", error);
        }
    }

    export async function getBoxIdByLotnumber(lotNumber: any): Promise<any> {
        try {
            if (!lotNumber) {
                return new ResponseModel(false, "LotNumber cannot be undefined ,null or Empty string");
            }
            let purchaseDetailList = await prismaSwab.SwabPurchaseDetails.findMany({
                where: {
                    LotNumber: lotNumber,
                },
                select:{
                    LotNumber:true,
                    BoxID:true,
                    SwabInventoryBoxBalance:{
                        select:{
                            AvailableSwabs:true
                        }
                    }
                }
            });
            let BoxID:any = purchaseDetailList.filter(function(val:any) { return val.SwabInventoryBoxBalance[0].AvailableSwabs !== 0 });
            BoxID = BoxID.map((item: any) => { return { BoxID: item.BoxID, AvailableSwabs: item.SwabInventoryBoxBalance[0].AvailableSwabs } });
            if(BoxID.length === 0 ){
                return new ResponseModel(false, "No BoxID available for this LotNumber");
            }
            return new ResponseModel(true, "Record Found", { BoxID: BoxID });
        } catch (err) {
            console.log(err);
            return new ResponseModel(false, "Internal Server Error", err);
        }
    }

    export async function updateIsInvoiceRaised(data: any): Promise<any> {
        try{
            await prismaSwab.clientSwabDispatchMaster.updateMany({
                where: {
                    DispatchMasterID: data.DispatchMasterID
                },
                data: {
                    IsInvoiceRaised: true //data.IsInvoiceRaised,
                },
            });
            return new ResponseModel(true, `IsInvoiceRaised status has been updated`);
        }catch(err){
            console.log(err);
            return new ResponseModel(false, "Internal Server Error", err);
        }
    }

    export async function getClientDetailsByID(ClientID:any): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            histoSConnectionPool.connect().then(async(_con) => {
                const request = new Sql.Request(_con);
                const result:any = await request.query(`
                    select a.ClientID,a.AttributeValue,c.ClientName,c.ClientTypeID from ClientCustomAttributeDetails a, clients c
                    where attributeid=1 and a.ClientID=c.clientid  and AttributeValue='Y' and c.ClientID = ${ClientID}
                    order by 1
                `)
                resolve(result.recordset[0]);
            }).catch((err)=>{
                reject(err);
            })
        })
    }
}

