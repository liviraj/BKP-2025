import express, { NextFunction, Request, Response } from "express";
import axios from 'axios';
import { Constants } from '../common/constants';
export const auth = (req: Request, res: Response, next: NextFunction) => {
    try {
        if (req.headers.authorization == undefined) {
            return res.status(401).send("Authoriation header not provided")
        }
        const token = req.headers.authorization;
        if (!token) {
            return res.status(401).send("Authoriation header not provided");
        }
        const config = {
            headers: { Authorization: token }
        };
        axios.get(Constants.URL_MS_GRAPH_ME, config).then((data: any) => {
            if (data.status === 200) {
                // console.log(data.data.mail);
                next();
            } else {
                return res.status(data.status).send("Unauthorized");
            }
        }).catch((err => {
            return res.status(err.response.status).send(err.response.data.error);
        }));
    } catch (error) {
        res.status(401).send("Invalid token");
    }
};