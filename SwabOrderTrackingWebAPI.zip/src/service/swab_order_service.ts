import { SwabOrder } from '../models/swab_order_model';
import { SwabOrderDA } from '../data_access/swab_order_data_access'
import ResponseModel from '../common/response_model';
export module SwabOrderService {

    export async function getSwabOrderPending(): Promise<SwabOrder[]> {
        return new Promise<SwabOrder[]>((resolve, reject) => {
            SwabOrderDA.getSwabOrderPending().then((result) => {
                resolve(result);
            }).catch((err) => { reject(err) });
        });
    }

    export async function createSwabrequest(data: any): Promise<ResponseModel> {
        let requestDetail: any = data.requestDetails;
        let shipmentDetail: any = data.shipmentDetail;

        let requestRes: any = await SwabOrderDA.createSwabrequest(requestDetail, shipmentDetail);

        if (requestRes.data != null && requestRes.data != undefined && requestRes.data.length != 0) {
            shipmentDetail.RequestID = requestRes.data.RequestID;
            shipmentDetail.LastModifiedOn = new Date();
            let shippingDetail = await SwabOrderDA.createShipmentClient(shipmentDetail);
            if (shippingDetail.data != null && shippingDetail.data != undefined && shippingDetail.data.length != 0) {
                let responseData = {
                    RequestID: requestRes.data.RequestID
                }
                return new ResponseModel(true, "Swab request created successfully", responseData);
            } else {
                return shippingDetail;
            }
        } else {
            return requestRes;
        }

    }

    export async function getAllSwabRequest(): Promise<ResponseModel> {
        return new Promise<ResponseModel>((resolve, reject) => {
            SwabOrderDA.getAllSwabRequest().then((result) => {
                resolve(result);
            }).catch((err) => { reject(err) });
        });
    }

    export async function getSwabRequestById(RequestID: any): Promise<ResponseModel> {
        return new Promise<ResponseModel>((resolve, reject) => {
            SwabOrderDA.getSwabRequestById(RequestID).then((result) => {
                resolve(result);
            }).catch((err) => { reject(err) });
        });
    }

    export async function getSwabRequestByFilters(filterValues: any): Promise<ResponseModel> {
        return new Promise<ResponseModel>((resolve, reject) => {
            SwabOrderDA.getSwabRequestByFilters(filterValues).then((result) => {
                resolve(result);
            }).catch((err) => { reject(err) });
        });
    }
 
}