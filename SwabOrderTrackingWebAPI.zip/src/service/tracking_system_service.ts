import { Client, DeliveryStatus, PaymentStatus } from '../models/tracking_system_model';
import { TrackingSystemDA } from '../data_access/tracking_system_data_access';
import ResponseModel from '../common/response_model';
export module TrackingSystemService {
    export async function getDeliveryStatusList(): Promise<DeliveryStatus[]> {
        return new Promise<DeliveryStatus[]>((resolve, reject) => {
            TrackingSystemDA.getDeliveryStatusList().then((result) => {
                resolve(result);
            }).catch((err) => { reject(err) });
        });
    }

    export async function getPaymentStatuses(): Promise<PaymentStatus[]> {
        return new Promise<PaymentStatus[]>((resolve, reject) => {
            TrackingSystemDA.getPaymentStatuses().then((result) => {
                resolve(result);
            }).catch((err) => { reject(err) });
        });
    }

    export async function getClientNameList(): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            TrackingSystemDA.getClientNameList().then((result) => {
                resolve(result);
            }).catch((err) => { reject(err) });
        });
    }

    export async function getClientById(data:any): Promise<ResponseModel> {
        return new Promise<ResponseModel>((resolve, reject) => {
            TrackingSystemDA.getClientById(data).then((result) => {
                resolve(result);
            }).catch((err) => { reject(err) });
        });
    }
}