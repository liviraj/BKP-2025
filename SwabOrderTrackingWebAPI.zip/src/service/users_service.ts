import { rejects } from 'assert';
import { resolve } from 'path/posix';
import { UsersDA } from '../data_access/users_data_access'
const axios = require('axios')
export module UsersService {

    export async function GetUserInfo(data: any): Promise<String> {
        return new Promise<String>((resolve, reject) => {
            if (data) {
                UsersDA.getUserInfo(data).then((result) => {
                    resolve(result);
                }).catch((err) => { reject(err) });
            } else {
                reject("Input cannot be empty!");
            }
        });
    }
}
