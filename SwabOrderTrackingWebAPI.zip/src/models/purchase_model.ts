export interface SwabInventory {
    LotNumber: string,
    AvailableBoxes: number,
    AvailableSwabs: number,
    LotExpiryDate: any
}