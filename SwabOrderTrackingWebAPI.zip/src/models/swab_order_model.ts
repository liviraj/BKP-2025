import internal from "stream";

export interface SwabOrder {
    ClientName: string,
    TobeShippedQty: number,
    RequestDaysCount: number,
    ClientID: number,
    RequestID: number,
    DispatchMasterID: number
}

export interface InventoryStatus {
    AvailableQty: any,
    ReOrderLevel: any
}

export interface ShipmentDetail {
    ClientID: number
    ShippingAddress1: String
    Address2: String
    City: String
    State: String
    Zip: Number
    CountryID: String
    LastModifiedBy: number
}

export interface SwabUOMModel {
    SwabUOMID: number
    SwabUOM: string | null
    PricePerUnit: string | null
}

export interface SwabStatus {
    id: number
    status: string
}

export interface SwabRequestById {
    RequestID: number
    RequestedDate: string
    ClientID: number
    RequestorName: string
    RequestorEmailAddress: string
    SwabUOMID: number
    SwabUOM: string
    QtyRequested: number
    ShippingAddress1: string
    Address2: string
    City: string
    State: string
    Zip: string
    CountryID: string
    Notes: string
}

export interface SwabRequestByClientId {
    RequestID: number
    RequestedDate: string
    QtyRequested: number
    TobeShippedQty: number
    SwabUOM: string
}

export enum ShipmentCarriers {
    FEDEX = "FedEx",
    UPS = "UPS",
    USPS = "USPS",
    DHL = "DHL",
    TNT = "TNT",
    Others = "Others"
}