export interface ClientProjects {
    ClientProjectID: number,
    ClientProjectCode: string,
    ClientProjectName: string
}

export interface AttributeDetail {
    AttributeDetailID: number,
    AttributeID: number,
    AttributeValue: string,
    DisplayName: string,
    Category: string,
    AttributeName: string
}

export interface SMTPDetails {
    smtpUserName?: string,
    smtpPassword?: string,
    smtpMailHost?: string,
    smtpPort?: string
}