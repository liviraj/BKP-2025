export interface UserName {
    UserID: number,
    LoginName: string
}