export interface DocumentType {
    DoccategoryID: number,
    Doccategory: string
}