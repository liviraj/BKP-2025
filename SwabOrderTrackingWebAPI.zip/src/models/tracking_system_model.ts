export interface DeliveryStatus {
    DeliveryMasteID: number,
    DeliveryStatus: string
}

export interface PaymentStatus {
    PaymentStatusID: number,
    PaymentStatus: string
}

export interface Client {
    ClientID: number,
    ClientName: string,
}