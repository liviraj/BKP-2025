import 'dotenv/config'
import express from "express";
import cors from "cors";
import helmet from "helmet";
import { errorHandler } from "./middleware/error.middleware";
import { notFoundHandler } from "./middleware/not-found.middleware";

// routes
import { users_router } from './routes/users_router';
import { swab_order_router } from './routes/swab_order_router';
import { tracking_system_router } from './routes/tracking_system_router';
import { documents_router } from './routes/documents_router';
import { invoice_router } from './routes/invoice_router';
import { inventory_router } from './routes/inventory_router';
import { purchase_router } from './routes/purchase_router';

const app = express();
const bodyParser = require('body-parser');

const multer = require("multer");
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

const swaggerUI = require("swagger-ui-express");
const swaggerJsDoc = require("swagger-jsdoc");

const options = {
	definition: {
		openapi: "3.0.0",
		info: {
			title: "SwabOrderTrackingWebAPI",
			version: "1.0.0",
			description: "SwabOrderTrackingWeb API  Document",
		},
		components: {
			securitySchemes: {
			  jwt: {
				type: "http",
				scheme: "bearer",
				in: "header",
				bearerFormat: "JWT"
			  },
			}
		  }
		  ,
		  security: [{
			jwt: []
		  }],
		servers: [
			{
				url: "http://localhost:7000",
			},
		],
	},
	// apis: ["./src/routes/*.ts"], // for development
	apis: ["build/routes/*.js"],
};

if (!process.env.PORT) {
	console.error("❌ Port number is not configured !")
	process.exit(1);
}

const PORT: number = parseInt(process.env.PORT as string, 10);

// const specs = swaggerJsDoc(options);

app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(bodyParser.json());

// app.use("/api-docs/",swaggerUi.serve, swaggerUi.setup(swaggerDocument));
// app.use("/api-docs", swaggerUI.serve, swaggerUI.setup(specs));
app.use("/users/", users_router);
app.use("/swabOrder/", swab_order_router);
app.use("/trackingSystem/", tracking_system_router);
app.use("/document/", documents_router);
app.use("/invoice/", invoice_router);
app.use("/purchase", purchase_router);
app.use("/inventory",inventory_router);


app.use("/docUpload",upload.array('files'),documents_router);

app.get('/status', (req, res) => {  res.json('swabAPI is running in server');});

// app.use(errorHandler);
app.use(notFoundHandler);

app.listen(PORT, () => {
	console.log(`✔ Listening on port ${PORT}`);
});