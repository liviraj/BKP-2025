package com.histo.filedataorganizer.util;

import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component("diskShareUtil")
public class DiskShareUtil {
    public DiskShare getDiskShare(String serverName, String userName, String password, String shareName, String domain) {
        DiskShare diskShare;
        try {
            SMBClient clientSource = new SMBClient();
            Connection connectionSource = clientSource.connect(serverName);
            AuthenticationContext authContextSource = new AuthenticationContext(userName, password.toCharArray(), domain);
            Session sessionSource = connectionSource.authenticate(authContextSource);
            diskShare = (DiskShare) sessionSource.connectShare(shareName);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return diskShare;
    }
}
