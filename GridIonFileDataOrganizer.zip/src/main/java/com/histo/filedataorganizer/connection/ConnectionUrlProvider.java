package com.histo.filedataorganizer.connection;

import com.histo.filedataorganizer.config.PropertyConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("connectionUrlProvider")
public class ConnectionUrlProvider {
    @Autowired
    private PropertyConfig propertyConfig;

    // GridION URL
    public String insertGridIonLogUrl() {
        return  propertyConfig.getGridIonBaseUrl().concat("/gridIonRun/gridIonLog");
    }

    public String gridIonLtsStatusUpdateUrl() {
        return propertyConfig.getGridIonBaseUrl().concat("/gridIonRun/gridIonLocalTransferStatus");
    }

    public  String insertLogDetailUrl() {
        return propertyConfig.getGridIonBaseUrl().concat("/gridIonRun/logDetail");
    }
}
