package com.histo.filedataorganizer.connection;

import com.histo.filedataorganizer.model.GridIonLogModel;
import com.histo.filedataorganizer.model.LocalTransferStatus;
import com.histo.filedataorganizer.model.LogDetailModel;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import javax.net.ssl.SSLException;

@Component("connectionIntermittent")
public class ConnectionIntermittent {
    private static Logger LOGGER = LogManager.getLogger(ConnectionIntermittent.class.getName());
    @Autowired
    private ConnectionUrlProvider connectionUrlProvider;

    private final WebClient webClient;

    public ConnectionIntermittent(WebClient webClient) {
        this.webClient = webClient;
    }

    private WebClient getWebClient() {
        SslContext sslContext = null;
        try {
            sslContext = SslContextBuilder
                    .forClient()
                    .trustManager(InsecureTrustManagerFactory.INSTANCE)
                    .build();
        } catch (SSLException e) {
            throw new RuntimeException(e);
        }
        SslContext finalSslContext = sslContext;
        HttpClient httpClient = HttpClient.create().secure(t -> t.sslContext(finalSslContext));
        WebClient webClient = WebClient.builder().clientConnector(new ReactorClientHttpConnector(httpClient)).build();
        return webClient;
    }
    public String callInsertGridIonLog(GridIonLogModel gridIonLogModel) {

        LOGGER.info("callInsertGridIonLog() Request Info. URL:{}, Method: {}", connectionUrlProvider.insertGridIonLogUrl(), HttpMethod.POST);
        String responseMsg = webClient
                .post()
                .uri(connectionUrlProvider.insertGridIonLogUrl())
                .bodyValue(gridIonLogModel)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return responseMsg;

    }

    public String callGridIonLtsStatusUpdate(LocalTransferStatus statusData) {
        LOGGER.info("callGridIonLtsStatusUpdate() Request Info. URL:{}, Method: {}", connectionUrlProvider.gridIonLtsStatusUpdateUrl(), HttpMethod.POST);
        String responseMsg = getWebClient()
                .post()
                .uri(connectionUrlProvider.gridIonLtsStatusUpdateUrl())
                .bodyValue(statusData)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)

                .block();
        return responseMsg;
    }

    public String callInsertLogDetail(LogDetailModel logDetailModel) {
        LOGGER.info("callGridIonLtsStatusUpdate() Request Info. URL:{}, Method: {}", connectionUrlProvider.insertGridIonLogUrl(), HttpMethod.POST);
        String responseMsg = getWebClient()
                .post()
                .uri(connectionUrlProvider.insertGridIonLogUrl())
                .bodyValue(logDetailModel)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return responseMsg;
    }
}
