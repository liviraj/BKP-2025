package com.histo.filedataorganizer.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InputArgs {
    @JsonProperty("sourcePath")
    private String sourcePath;
    @JsonProperty("statusViewerId")
    private int statusViewerId;
    @JsonProperty("runId")
    private int runId;
    @JsonProperty("sourceServer")
    private String sourceServer;
    @JsonProperty("destinationServer")
    private String destinationServer;
    @JsonProperty("sourceShare")
    private String sourceShare;
    @JsonProperty("destinationShare")
    private String destinationShare;
    @JsonProperty("destinationDirectory")
    private String destinationDirectory;
    @JsonProperty("sourceUsername")
    private String sourceUsername;
    @JsonProperty("sourcePassword")
    private String sourcePassword;
    @JsonProperty("destinationUsername")
    private String destinationUsername;
    @JsonProperty("destinationPassword")
    private String destinationPassword;
    @JsonProperty("actionType")
    private String actionType;
    @JsonProperty("programType")
    private String programType;
    @JsonProperty("userId")
    private Integer userId;

    public int getStatusViewerId() {
        return statusViewerId;
    }

    public void setStatusViewerId(int statusViewerId) {
        this.statusViewerId = statusViewerId;
    }

    public int getRunId() {
        return runId;
    }

    public void setRunId(int runId) {
        this.runId = runId;
    }

    public String getSourceServer() {
        return sourceServer;
    }

    public void setSourceServer(String sourceServer) {
        this.sourceServer = sourceServer;
    }

    public String getDestinationServer() {
        return destinationServer;
    }

    public void setDestinationServer(String destinationServer) {
        this.destinationServer = destinationServer;
    }

    public String getSourceShare() {
        return sourceShare;
    }

    public void setSourceShare(String sourceShare) {
        this.sourceShare = sourceShare;
    }

    public String getDestinationShare() {
        return destinationShare;
    }

    public void setDestinationShare(String destinationShare) {
        this.destinationShare = destinationShare;
    }

    public String getSourcePath() {
        return sourcePath;
    }

    public void setSourcePath(String sourcePath) {
        this.sourcePath = sourcePath;
    }

    public String getDestinationDirectory() {
        return destinationDirectory;
    }

    public void setDestinationDirectory(String destinationDirectory) {
        this.destinationDirectory = destinationDirectory;
    }

    public String getSourceUsername() {
        return sourceUsername;
    }

    public void setSourceUsername(String sourceUsername) {
        this.sourceUsername = sourceUsername;
    }

    public String getSourcePassword() {
        return sourcePassword;
    }

    public void setSourcePassword(String sourcePassword) {
        this.sourcePassword = sourcePassword;
    }

    public String getDestinationUsername() {
        return destinationUsername;
    }

    public void setDestinationUsername(String destinationUsername) {
        this.destinationUsername = destinationUsername;
    }

    public String getDestinationPassword() {
        return destinationPassword;
    }

    public void setDestinationPassword(String destinationPassword) {
        this.destinationPassword = destinationPassword;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public String getProgramType() {
        return programType;
    }

    public void setProgramType(String programType) {
        this.programType = programType;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "InputArgs{" +
                "statusViewerId=" + statusViewerId +
                ", runId=" + runId +
                ", sourceServer='" + sourceServer + '\'' +
                ", destinationServer='" + destinationServer + '\'' +
                ", sourceShare='" + sourceShare + '\'' +
                ", destinationShare='" + destinationShare + '\'' +
                ", sourcePath='" + sourcePath + '\'' +
                ", destinationDirectory='" + destinationDirectory + '\'' +
                ", sourceUsername='" + sourceUsername + '\'' +
                ", sourcePassword='" + sourcePassword + '\'' +
                ", destinationUsername='" + destinationUsername + '\'' +
                ", destinationPassword='" + destinationPassword + '\'' +
                ", actionType='" + actionType + '\'' +
                ", programType='" + programType + '\'' +
                ", userId=" + userId +
                '}';
    }
}
