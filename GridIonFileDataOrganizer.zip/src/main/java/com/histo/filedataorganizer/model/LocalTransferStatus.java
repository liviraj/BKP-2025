package com.histo.filedataorganizer.model;

import lombok.*;

@NoArgsConstructor
@Getter
@Setter
@ToString
@AllArgsConstructor
public class LocalTransferStatus {
	private int gridIonStatusViewerId;
	private int status;
    private String sourcePath;
}
