package com.histo.filedataorganizer.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class LogDetailModel {
    private String actionType;
    private String sourceLocation;
    private String destinationLocation;
    private String deleteLocation;
    private String status;
    private String program;
}
