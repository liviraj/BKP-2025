package com.histo.filedataorganizer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GridIonFileDataOrganizerApplication implements CommandLineRunner {

	@Autowired
	private GridIonFileDataOrganizerProcessor gridIonFileDataOrganizerProcessor;

	public static void main(String[] args) {
		SpringApplication app = new SpringApplication(GridIonFileDataOrganizerApplication.class);
		app.setWebApplicationType(WebApplicationType.NONE);
		app.run(args);

	}

	@Override
	public void run(String... args) throws Exception {
		gridIonFileDataOrganizerProcessor.doFileProcess(args);
	}
}
