package com.histo.filedataorganizer;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.histo.filedataorganizer.model.InputArgs;
import com.histo.filedataorganizer.service.FileDataOrganizerService;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Component("gridIonFileDataOrganizerProcessor")
public class GridIonFileDataOrganizerProcessor {
    public static Logger LOGGER = LogManager.getLogger(GridIonFileDataOrganizerProcessor.class.getName());

    @Autowired
    private FileDataOrganizerService fileDataOrganizerService;

    /**
     * Gridion file data organizer test args
     * {"sourceServer":"HISTOINDDC01","sourceShare":"IT_Projects","destinationServer":"HISTOINDDC01.histoindia.com","destinationShare":"IT_Projects","sourceDirectory":"Arockiajayaraj/GridIon/AnalysisPath/Syngenta_2024_03_27_NIC4436A93/NIC4436A93/20240327_1043_P2S-01288-A_PAW19040_ea5048c2/","destinationDirectory":"Arockiajayaraj/GridIon/SourcePath/Syngenta Crop Protection LLC/GridIon/P2P-NIC4436A93/","sourceUsername":"XXXXX","sourcePassword":"YYYYYY","destinationUsername":"XXXXXX","destinationPassword":"YYYYYY","statusViewerId":1,"runId":1,"actionType":"COPY","programType":"GRIDION","userId":3449}
     */
    public void doFileProcess(String args[]) {
        try {
            if (StringUtils.isAllEmpty(args)) {
                LOGGER.debug("Missing arguments. Argument List:" + Arrays.toString(args));
                return;
            }

            LOGGER.info("GridIonFileDataOrganizer Arguments: {}", Arrays.toString(args));
            String argsString = Arrays.toString(args);
            argsString = argsString.replaceAll("[\\{\\}\\[\\]]", "");
            args = argsString.split(",");
            LOGGER.info("args all: {}", Arrays.toString(args));
            InputArgs inputArgs = new InputArgs();
            setValuesFromArgsArray(inputArgs, args);
            inputArgs.setSourcePath(URLDecoder.decode(inputArgs.getSourcePath(), StandardCharsets.UTF_8));
            inputArgs.setDestinationDirectory(URLDecoder.decode(inputArgs.getDestinationDirectory(), StandardCharsets.UTF_8));
            LOGGER.info("Mapped InputArgs: {}", inputArgs);

            fileDataOrganizerService.doFileTransfer(inputArgs); // Md5Checksum action calling
        } catch (Exception e) {
            LOGGER.error("Exception doFileProcess() : {}", e);
        }
    }

    public static void setValuesFromArgsArray(Object obj, String[] args) {
        Class<?> clazz = obj.getClass();
        for (String arg : args) {
            String[] keyValue = arg.split(":");
            if (keyValue.length == 2) {
                String key = keyValue[0].trim().replace("\"","");
                String value = keyValue[1].trim().replace("\"","");
                try {
                    Field field = clazz.getDeclaredField(key);
                    field.setAccessible(true);
                    setFieldValue(field, obj, value, key);
                } catch (NoSuchFieldException | IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private static void setFieldValue(Field field, Object obj, String value, String key) throws IllegalAccessException {
        if (field.getType().equals(Integer.class) || key.equals("statusViewerId") || key.equals("runId") || key.equals("userId")) {
            field.set(obj, Integer.valueOf(value) );
        } else if (field.getType().equals(String.class)) {
            field.set(obj, value);
        } else if (field.getType().equals(Boolean.class)) {
            field.set(obj, Boolean.valueOf(value));
        } else if (field.getType().equals(Double.class)) {
            field.set(obj, Double.valueOf(value));
        }
    }

    private static InputArgs argsMapValidation(InputArgs inputArgs, Map<String, String> mapArgs) {
        if (StringUtils.isBlank(inputArgs.getSourcePath()) || inputArgs.getSourcePath().equals("null")) {
            inputArgs.setSourcePath(mapArgs.get("sourcePath"));
        }
        if (ObjectUtils.isEmpty(inputArgs.getStatusViewerId()) || inputArgs.getStatusViewerId() == 0) {
            if (StringUtils.isBlank(mapArgs.get("statusViewerId"))) {
                inputArgs.setStatusViewerId(0);
            } else {
                inputArgs.setStatusViewerId(Integer.parseInt(mapArgs.get("statusViewerId")));
            }
        }
        if (ObjectUtils.isEmpty(inputArgs.getRunId()) || inputArgs.getRunId() == 0) {
            if (StringUtils.isBlank(mapArgs.get("runId"))) {
                inputArgs.setRunId(0);
            } else {
                inputArgs.setRunId(Integer.parseInt(mapArgs.get("runId")));
            }
        }
        if (StringUtils.isBlank(inputArgs.getSourceServer()) || inputArgs.getSourceServer().equals("null")) {
            inputArgs.setSourceServer(mapArgs.get("sourceServer"));
        }
        if (StringUtils.isBlank(inputArgs.getDestinationServer()) || inputArgs.getDestinationServer().equals("null")) {
            inputArgs.setDestinationServer(mapArgs.get("destinationServer"));
        }
        if (StringUtils.isBlank(inputArgs.getSourceShare()) || inputArgs.getSourceShare().equals("null")) {
            inputArgs.setSourceShare(mapArgs.get("sourceShare"));
        }
        if (StringUtils.isBlank(inputArgs.getDestinationShare()) || inputArgs.getDestinationShare().equals("null")) {
            inputArgs.setDestinationShare(mapArgs.get("destinationShare"));
        }
        if (StringUtils.isBlank(inputArgs.getDestinationDirectory()) || inputArgs.getDestinationDirectory().equals("null")) {
            inputArgs.setDestinationDirectory(mapArgs.get("destinationDirectory"));
        }
        if (StringUtils.isBlank(inputArgs.getSourceUsername()) || inputArgs.getSourceUsername().equals("null")) {
            inputArgs.setSourceUsername(mapArgs.get("sourceUsername"));
        }
        if (StringUtils.isBlank(inputArgs.getSourcePassword()) || inputArgs.getSourcePassword().equals("null")) {
            inputArgs.setSourcePassword(mapArgs.get("sourcePassword"));
        }
        if (StringUtils.isBlank(inputArgs.getDestinationUsername()) || inputArgs.getDestinationUsername().equals("null")) {
            inputArgs.setDestinationUsername(mapArgs.get("destinationUsername"));
        }
        if (StringUtils.isBlank(inputArgs.getDestinationPassword()) || inputArgs.getDestinationPassword().equals("null")) {
            inputArgs.setDestinationPassword(mapArgs.get("destinationPassword"));
        }
        if (StringUtils.isBlank(inputArgs.getActionType()) || inputArgs.getActionType().equals("null")) {
            inputArgs.setActionType(mapArgs.get("actionType"));
        }
        if (StringUtils.isBlank(inputArgs.getProgramType()) || inputArgs.getProgramType().equals("null")) {
            inputArgs.setProgramType(mapArgs.get("programType"));
        }
        if (ObjectUtils.isEmpty(inputArgs.getUserId()) || inputArgs.getUserId() == 0) {
            if (StringUtils.isBlank(mapArgs.get("userId"))) {
                inputArgs.setUserId(0);
            } else {
                inputArgs.setUserId(Integer.parseInt(mapArgs.get("userId")));
            }
        }
        return inputArgs;
    }
}
