package com.histo.filedataorganizer.service.impl;

import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.fileinformation.FileAllInformation;
import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.mssmb2.SMBApiException;
import com.hierynomus.smbj.common.SmbPath;
import com.hierynomus.smbj.share.DiskShare;
import com.hierynomus.smbj.share.File;
import com.histo.filedataorganizer.config.PropertyConfig;
import com.histo.filedataorganizer.connection.ConnectionIntermittent;
import com.histo.filedataorganizer.model.GridIonLogModel;
import com.histo.filedataorganizer.model.InputArgs;
import com.histo.filedataorganizer.model.LocalTransferStatus;
import com.histo.filedataorganizer.model.LogDetailModel;
import com.histo.filedataorganizer.service.FileDataOrganizerService;
import com.histo.filedataorganizer.util.DiskShareUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class FileDataOrganizerServiceImpl implements FileDataOrganizerService {
    public static final Logger LOGGER = LogManager.getLogger(FileDataOrganizerServiceImpl.class.getName());

    @Autowired
    private DiskShareUtil diskShareUtil;
    @Autowired
    private ConnectionIntermittent connectionIntermittent;
    @Autowired
    private PropertyConfig propertyConfig;

    @Override
    public void doFileTransfer(InputArgs inputArgs) {
        try {
            if (!inputArgs.getSourceServer().toLowerCase().contains(propertyConfig.getSmbDomainName())) {
                inputArgs.setSourceServer(inputArgs.getSourceServer().concat(".").concat(propertyConfig.getSmbDomainName()));
            }

            if (!inputArgs.getDestinationServer().toLowerCase().contains(propertyConfig.getSmbDomainName())) {
                inputArgs.setDestinationServer(inputArgs.getDestinationServer().concat(".").concat(propertyConfig.getSmbDomainName()));
            }
            DiskShare sourceDiskShare = diskShareUtil.getDiskShare(inputArgs.getSourceServer()
                    , inputArgs.getSourceUsername(), inputArgs.getSourcePassword()
                    , inputArgs.getSourceShare(), propertyConfig.getSmbDomainName());

            DiskShare destDiskShare = diskShareUtil.getDiskShare(inputArgs.getDestinationServer(), inputArgs.getDestinationUsername()
                    , inputArgs.getDestinationPassword(), inputArgs.getDestinationShare()
                    , propertyConfig.getSmbDomainName());

            if (sourceDiskShare == null || destDiskShare == null) {
                LOGGER.error("Source share or destination share connection is null");
                return;
            }

            SmbPath sourceSmbPath = sourceDiskShare.getSmbPath();
            String sourceParentPath = sourceSmbPath.toUncPath().concat("\\").concat(inputArgs.getSourcePath());
            sourceParentPath = sourceParentPath.replace("/", "\\");
            SmbPath destinationSmbPath = destDiskShare.getSmbPath();
            String destinationParentPath = destinationSmbPath.toUncPath().concat("\\").concat(inputArgs.getDestinationDirectory());
            destinationParentPath = destinationParentPath.replace("/", "\\");

            if (!sourceParentPath.endsWith("\\")) {
                sourceParentPath = sourceParentPath.concat("\\");
            }
            if (!destinationParentPath.endsWith("\\")) {
                destinationParentPath = destinationParentPath.concat("\\");
            }

            if (!inputArgs.getSourcePath().endsWith("/")) {
                inputArgs.setSourcePath(inputArgs.getSourcePath().concat("/"));
            }
            if (!inputArgs.getDestinationDirectory().endsWith("/")) {
                inputArgs.setDestinationDirectory(inputArgs.getDestinationDirectory().concat("/"));
            }

            boolean isSourceFolderExist = sourceDiskShare.folderExists(inputArgs.getSourcePath().replace("\\", "/"));
            if (!isSourceFolderExist) {
                LOGGER.error("Failed: Invalid Source Folder -> {}", sourceParentPath);
                if (inputArgs.getStatusViewerId() != 0) {
                    GridIonLogModel errorLog = new GridIonLogModel(inputArgs.getRunId(), inputArgs.getStatusViewerId(), "Failed: Invalid Source Folder -> " + sourceParentPath, "GridIonFileDataOrganizer", inputArgs.getUserId());
                    connectionIntermittent.callInsertGridIonLog(errorLog);
                } else {
                    doLoggingDetails(inputArgs);
                }
                return;
            }

            FileAllInformation sourceFileInformation = sourceDiskShare.getFileInformation(inputArgs.getSourcePath().replace("\\", "/"));
            boolean isSourceDirectory = sourceFileInformation.getStandardInformation().isDirectory();
            if (!isSourceDirectory) {
                LOGGER.info("Failed: Its a file not a directory : {}", sourceParentPath);
                return;
            }

            LOGGER.info("GridIon Folder Copy Start ...");
            LOGGER.info("Source Location: {}", sourceParentPath);
            LOGGER.info("Destination Loction : {}", destinationParentPath);

            // start time
            long startTime = System.currentTimeMillis();

            insetRunLog(inputArgs, "Copy process started");
            ltsStatusUpdate(inputArgs, 2, destinationParentPath);

            List<FileIdBothDirectoryInformation> masterSourceDirectoryInformationList = sourceDiskShare.list(inputArgs.getSourcePath());
            masterSourceDirectoryInformationList.removeIf(directoryInformation -> directoryInformation.getFileName().equals(".") || directoryInformation.getFileName().equals(".."));

            long sourceFolderSize = 0;
            for (FileIdBothDirectoryInformation directoryInfo : masterSourceDirectoryInformationList) {
                if(directoryInfo.getFileName().equals("datatransfer_complete.txt") || directoryInfo.getFileName().equals("datatransfer_started.txt")) {
                    continue;
                }
                sourceFolderSize += getFileOrFolderSize(sourceDiskShare, inputArgs.getSourcePath().concat(directoryInfo.getFileName()).concat("/"));
            }

            long diskSpaceFree = sourceDiskShare.getShareInformation().getFreeSpace();

            if (diskSpaceFree <= sourceFolderSize) {
                LOGGER.error("No Disk Space");
                ltsStatusUpdate(inputArgs, 4, destinationParentPath);
                insetRunLog(inputArgs, "No Disk Space");
                return;
            }
            String sampleDesPath = inputArgs.getDestinationDirectory();
            for (FileIdBothDirectoryInformation sampleFileInfo : masterSourceDirectoryInformationList) {
                String sampleSourcePath = inputArgs.getSourcePath().concat(sampleFileInfo.getFileName()).concat("/");
                if(sampleFileInfo.getFileName().equals("datatransfer_complete.txt") || sampleFileInfo.getFileName().equals("datatransfer_started.txt")) {
                    continue;
                }
                sampleSourcePath = getMainPath(sampleSourcePath, sourceDiskShare);

                // find the source directory folder size(skip files)
                List<FileIdBothDirectoryInformation> sourceDirectoryInformationList = sourceDiskShare.list(sampleSourcePath);
                sourceDirectoryInformationList.removeIf(directoryInformation -> directoryInformation.getFileName().equals(".") || directoryInformation.getFileName().equals(".."));
                sourceDirectoryInformationList.removeIf(directoryInformation ->
                        !directoryInformation.getFileName().equals("bam_fail") &&
                                !directoryInformation.getFileName().equals("bam_pass") &&
                                !directoryInformation.getFileName().equals("fastq_fail") &&
                                !directoryInformation.getFileName().equals("fastq_pass")
                );
                final String finalSampleSourcePath = sampleSourcePath;
                sourceDirectoryInformationList.removeIf(file -> sourceDiskShare.fileExists(finalSampleSourcePath.concat(file.getFileName())));

                boolean isDestinationExist = destDiskShare.folderExists(sampleDesPath.replace("\\", "/"));
                if (!isDestinationExist) {
                    // create not existing path in destination location
                    List<String> destinationSplit = Arrays.stream(sampleDesPath.replace("\\", "/").split("/")).filter(path -> !path.equalsIgnoreCase("")).toList();
                    String destShareRunPath = "";
                    for (String path : destinationSplit) {
                        destShareRunPath = destShareRunPath.concat(path).concat("/");
                        boolean isDestPathExist = destDiskShare.folderExists(destShareRunPath);
                        if (!isDestPathExist) {
                            destDiskShare.mkdir(destShareRunPath);
                        }
                    }
                } else {
                    if (sourceFolderSize == getFileOrFolderSize(destDiskShare, sampleDesPath)) {
                        LOGGER.info("Destination already exist with all data");
                        ltsStatusUpdate(inputArgs, 3, destinationParentPath);
                        insetRunLog(inputArgs, "Destination already exist with all data");
                        continue;
                    }
                }

                for (FileIdBothDirectoryInformation directoryInfo : sourceDirectoryInformationList) {
                    String sourcePath = sampleSourcePath.concat(directoryInfo.getFileName()).concat("/").replace("\\", "/");
                    String destinationPath = sampleDesPath.concat(directoryInfo.getFileName()).concat("/").replace("\\", "/");
                    boolean destPathExist = destDiskShare.folderExists(destinationPath);
                    if (!destPathExist) {
                        destDiskShare.mkdir(destinationPath);
                    }
                    // copy file/folder source to destination
                    doSmbFileCopy(sourcePath
                            , destinationPath
                            , sourceDiskShare
                            , destDiskShare);
                }
            }
            ltsStatusUpdate(inputArgs, 3, destinationParentPath);
            insetRunLog(inputArgs, "Copied successfully.");

            LOGGER.info("LTS Completed");
            long endTime = System.currentTimeMillis();
            LOGGER.info("Total time taken for transfer (in secs): " + (endTime - startTime) / 1000.0);
        } catch (Exception e) {
            LOGGER.error("Exception happen in LTS process. Exception: {}", e);
        }
    }

    private String getMainPath(String path, DiskShare diskShare) {

        if (!path.endsWith("/")) {
            path = path.concat("/");
        }
        List<FileIdBothDirectoryInformation> sourceDirectoryInformationList = diskShare.list(path);
        sourceDirectoryInformationList.removeIf(directoryInformation ->
                directoryInformation.getFileName().equals(".")
                        || directoryInformation.getFileName().equals("..")
        );

        String finalPath = path;
        List<FileIdBothDirectoryInformation> sourceFolderInfoList = sourceDirectoryInformationList.stream()
                .filter(dirInfo -> diskShare.folderExists(finalPath.concat(dirInfo.getFileName())))
                .collect(Collectors.toList());

        boolean hasBamFail = sourceFolderInfoList.stream()
                .anyMatch(info -> info.getFileName().equals("bam_fail"));
        boolean hasBamPass = sourceFolderInfoList.stream()
                .anyMatch(info -> info.getFileName().equals("bam_pass"));
        boolean hasFastqFail = sourceFolderInfoList.stream()
                .anyMatch(info -> info.getFileName().equals("fastq_fail"));
        boolean hasFastqPass = sourceFolderInfoList.stream()
                .anyMatch(info -> info.getFileName().equals("fastq_pass"));

        if (hasBamFail && hasBamPass && hasFastqFail && hasFastqPass) {
            return path;
        } else {
            for (FileIdBothDirectoryInformation info : sourceFolderInfoList) {
                String subPath = path.concat(info.getFileName()).concat("/");
                String mainPath = getMainPath(subPath, diskShare);
                if (!mainPath.isEmpty()) {
                    return mainPath;
                }
            }
        }
        return "";
    }

    private void doLoggingDetails(InputArgs inputArgs) {
        String sourcePath = "\\\\" + inputArgs.getSourceServer().concat("\\").concat(inputArgs.getSourceShare()).concat("\\")
                .concat(inputArgs.getSourcePath());
        String destPath = "\\\\" + inputArgs.getDestinationServer().concat("\\").concat(inputArgs.getDestinationShare())
                .concat("\\").concat(inputArgs.getDestinationDirectory());

        LogDetailModel logDetail = new LogDetailModel(inputArgs.getActionType()
                , sourcePath.replace("/", "\\")
                , destPath.replace("/", "\\")
                , ""
                , "Failed"
                , "GridIonFileDataOrganizer"
        );
        connectionIntermittent.callInsertLogDetail(logDetail);
    }

    private void insetRunLog(InputArgs inputArgs, String logInfo) {
        GridIonLogModel gridIonLogModel = new GridIonLogModel(inputArgs.getRunId(), inputArgs.getStatusViewerId(), logInfo, "PacBioFileDataOrganizer", inputArgs.getUserId());
        connectionIntermittent.callInsertGridIonLog(gridIonLogModel);
    }

    private void ltsStatusUpdate(InputArgs inputArgs, Integer status, String path) {
        LocalTransferStatus localTransferStatus = new LocalTransferStatus(inputArgs.getStatusViewerId(), status, path);
        connectionIntermittent.callGridIonLtsStatusUpdate(localTransferStatus);
    }

    private long getFileOrFolderSize(DiskShare share, String directoryPath) throws SMBApiException {
        long totalSize = 0;
        directoryPath = directoryPath.replace(share.getSmbPath().toUncPath(), "");
        directoryPath = directoryPath.replace("\\", "/");
        boolean isDirectory = share.getFileInformation(directoryPath).getStandardInformation().isDirectory();
        if (!isDirectory) {
            File file = share.openFile(directoryPath, EnumSet.of(AccessMask.GENERIC_READ), null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null);
            totalSize += file.getFileInformation().getStandardInformation().getEndOfFile();
            file.closeSilently();
            file.close();
            return totalSize;
        }
        for (FileIdBothDirectoryInformation fileInfo : share.list(directoryPath)) {
            String fileName = fileInfo.getFileName();
            if (fileName.equals(".") || fileName.equals("..") || fileName.equals("datatransfer_complete.txt") || fileName.equals("datatransfer_started.txt")) {
                continue;
            }

            String filePath = directoryPath + "/" + fileName;
            if (!fileInfo.getFileName().contains(".")) {
                totalSize += getFileOrFolderSize(share, filePath);
            } else {
                File file = share.openFile(filePath, EnumSet.of(AccessMask.GENERIC_READ), null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null);
                totalSize += file.getFileInformation().getStandardInformation().getEndOfFile();
                file.closeSilently();
                file.close();
            }
        }
        return totalSize;
    }

    public void doSmbFileCopy(String sourcePath, String destinationPath, DiskShare sourceShare, DiskShare
            destinationShare) throws IOException {
        sourcePath = formatPath(sourcePath, sourceShare);
        destinationPath = formatPath(destinationPath, destinationShare);

        if (sourceShare.getFileInformation(sourcePath).getStandardInformation().isDirectory()) {
            List<FileIdBothDirectoryInformation> fileList = sourceShare.list(sourcePath + "/");
            fileList.removeIf(file -> file.getFileName().equals(".") || file.getFileName().equals(".."));

            for (FileIdBothDirectoryInformation fileInfo : fileList) {
                String fileName = fileInfo.getFileName();
                if (fileName.equals(".") || fileName.equals("..") || fileName.equals("datatransfer_complete.txt") || fileName.equals("datatransfer_started.txt")) {
                    continue;
                }

                String sourceFilePath;
                String destinationFilePath;
                if (sourceShare.fileExists(sourcePath.concat(fileName))) {
                    sourceFilePath = sourcePath + "/" + fileName;
                    destinationFilePath = destinationPath + "/" + fileName;
                } else {
                    sourceFilePath = sourcePath + fileName + "/";
                    destinationFilePath = destinationPath + fileName + "/";
                    fileName += "/"; // Adding '/' in directory
                }


                if (fileName.endsWith("/") || fileName.endsWith("\\")) {
                    // It is a directory
                    String[] desNestedDirectory = destinationFilePath.split("/");
                    String currentDirectory = "";
                    for (String directory : desNestedDirectory) {
                        currentDirectory += directory + "/";
                        if (!destinationShare.folderExists(currentDirectory)) {
                            destinationShare.mkdir(currentDirectory);
                        }
                    }
                    doSmbFileCopy(sourceFilePath, destinationFilePath, sourceShare, destinationShare);
                } else {
                    // It is a file
                    copyFile(sourceFilePath, destinationFilePath, sourceShare, destinationShare);
                }
            }
        } else {
            // It is a file
            copyFile(sourcePath, destinationPath, sourceShare, destinationShare);
        }
    }

    private void copyFile(String sourcePath, String destinationPath, DiskShare sourceShare, DiskShare destinationShare) throws IOException {
        try (InputStream inputStream = sourceShare.openFile(sourcePath, EnumSet.of(AccessMask.GENERIC_READ)
                , null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null).getInputStream();
             OutputStream outputStream = destinationShare.openFile(destinationPath, EnumSet.of(AccessMask.GENERIC_WRITE)
                     , null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_CREATE, null).getOutputStream()) {
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        }
    }

    private String formatPath(String path, DiskShare share) {
        return path.replace(share.getSmbPath().toUncPath(), "").replace("\\", "/");
    }
}
