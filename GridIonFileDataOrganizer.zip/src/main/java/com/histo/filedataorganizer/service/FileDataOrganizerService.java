package com.histo.filedataorganizer.service;

import com.histo.filedataorganizer.model.InputArgs;

public interface FileDataOrganizerService {
    public void doFileTransfer(InputArgs inputArgs);
}
