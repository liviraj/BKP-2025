package com.histo.datacopier;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataCopierMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
