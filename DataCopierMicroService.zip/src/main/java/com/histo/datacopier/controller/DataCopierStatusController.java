package com.histo.datacopier.controller;

import com.histo.datacopier.model.*;
import com.histo.datacopier.service.DataCopierService;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/status")
public class DataCopierStatusController {
    private final DataCopierService dataCopierService;

    public DataCopierStatusController(DataCopierService dataCopierService) {
        this.dataCopierService = dataCopierService;
    }
    @PutMapping("/miSeq/experimentStatus")
    public String updateMiSeqExperimentStatus(@RequestBody MiSeqNovaSeqExperimentUpdateModel experiment) {
        return dataCopierService.updateMiSeqExperimentStatus(experiment);
    }
    @PutMapping("/novaSeq/experimentStatus")
    public String updateNovaSeqExperimentStatus(@RequestBody MiSeqNovaSeqExperimentUpdateModel experiment) {
        return dataCopierService.updateNovaSeqExperimentStatus(experiment);
    }

    @PutMapping("/miSeq/machineStatus")
    public String updateMiSeqMachineStatus(@RequestBody MiSeqNovaSeqMachineUpdateModel machine) {
        return dataCopierService.updateMiSeqMachineStatus(machine);
    }
    @PutMapping("/novaSeq/machineStatus")
    public String updateNovaSeqMachineStatus(@RequestBody MiSeqNovaSeqMachineUpdateModel machine) {
        return dataCopierService.updateNovaSeqMachineStatus(machine);
    }

    @PutMapping("/miSeq/monthStatus")
    public String updateMiSeqMonthStatus(@RequestBody MiSeqNovaSeqMonthUpdateModel month) {
        return dataCopierService.updateMiSeqMonthStatus(month);
    }
    @PutMapping("/novaSeq/monthStatus")
    public String updateNovaSeqMonthStatus(@RequestBody MiSeqNovaSeqMonthUpdateModel month) {
        return dataCopierService.updateNovaSeqMonthStatus(month);
    }

    @PutMapping("/miSeq/yearStatus")
    public String updateMiSeqYearStatus(@RequestBody MiSeqNovaSeqYearUpdateModel year) {
        return dataCopierService.updateMiSeqYearStatus(year);
    }
    @PutMapping("/novaSeq/yearStatus")
    public String updateNovaSeqYearStatus(@RequestBody MiSeqNovaSeqYearUpdateModel year) {
        return dataCopierService.updateNovaSeqYearStatus(year);
    }

    @PutMapping("/pacbio/jobStatus")
    public String updatePacbioJobStatus(@RequestBody PacbioJobStatusUpdateModel jobStatus) {
        return dataCopierService.updatePacbioJobStatus(jobStatus);
    }

}
