package com.histo.datacopier.controller;

import com.histo.datacopier.config.IlluminaExperimentStatusProxy;
import com.histo.datacopier.entity.MiSeqMasterData;
import com.histo.datacopier.entity.NovaSeqMasterData;
import com.histo.datacopier.entity.PacbioMasterData;
import com.histo.datacopier.model.*;
import com.histo.datacopier.service.DataCopierService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
// @RequestMapping("/dataCopier")
public class DataCopierController {

    private final DataCopierService dataCopierService;
    private final IlluminaExperimentStatusProxy illuminaExperimentStatusProxy;

    public DataCopierController(DataCopierService dataCopierService, IlluminaExperimentStatusProxy illuminaExperimentStatusProxy) {
        this.dataCopierService = dataCopierService;
        this.illuminaExperimentStatusProxy = illuminaExperimentStatusProxy;
    }

    @GetMapping("/miSeq/sync")
    public MiSeqMasterData getAllMiSeqSyncDetails() {
        return dataCopierService.getAllMiSeqSyncDetails();
    }

    @GetMapping("/novaSeq/sync")
    public NovaSeqMasterData getAllNovaSeqSyncDetails() {
        return dataCopierService.getAllNovaSyncDetails();
    }

    @PutMapping("/miSeq/sync")
    public String updateMiSeqDetails(@RequestBody MiSeqMasterDataUpdateModel miSeqMasterDataUpdateDTO) {
        return dataCopierService.updateMiSeqDetails(miSeqMasterDataUpdateDTO);
    }

    @PutMapping("/novaSeq/sync")
    public String updateNovaSeqDetails(@RequestBody NovaSeqMasterDataUpdateModel novaSeqMasterDataUpdateModel) {
        return dataCopierService.updateNovaSeqDetails(novaSeqMasterDataUpdateModel);
    }

    @GetMapping("/pacbio/sync")
    public PacbioMasterData getAllPacbioSyncDetails() {
        return dataCopierService.getAllPacbioSyncDetails();
    }

    @PutMapping("/pacbio/sync")
    public String updatePacbioSyncDetails(@RequestBody PacbioMasterDataModel pacbioMasterData) {
        return dataCopierService.updatePacbioSyncDetails(pacbioMasterData);
    }

    @PostMapping("/miSeq/detailsSync")
    public ResponseEntity<String> syncMiSeqDetails(@RequestBody MiSeqMasterData illuminaSyncDetails) {
        return dataCopierService.syncMiSeqDetails(illuminaSyncDetails);
    }

    @PostMapping("/novaSeq/detailsSync")
    public ResponseEntity<String> syncNovaSeqDetails(@RequestBody NovaSeqMasterData novaSeqSyncDetails) {
        return dataCopierService.syncNovaSeqDetails(novaSeqSyncDetails);
    }
    @PostMapping("/pacbio/detailsSync")
    public ResponseEntity<String> syncPacbioDetails(@RequestBody PacbioMasterData pacbioSyncDetails) {
        return dataCopierService.syncPacbioDetails(pacbioSyncDetails);
    }

    @PostMapping("/illumina/log")
    public String insertIlluminaBackupLog(@RequestBody IlluminaDataSecondaryBackupLogModel backupLog) {
        return illuminaExperimentStatusProxy.insertIlluminaBackupLog(backupLog);
    }

    @PostMapping("/pacbio/log")
    public String insertPacbioBackupLog(@RequestBody PacbioDataSecondaryBackupLogModel backupLog) {
        return illuminaExperimentStatusProxy.insertPacbioBackupLog(backupLog);
    }
}
