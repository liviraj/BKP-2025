package com.histo.datacopier.repository;

import com.histo.datacopier.entity.MiSeqMasterData;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface MiSeqMasterDataRepository extends MongoRepository<MiSeqMasterData, String> {
}
