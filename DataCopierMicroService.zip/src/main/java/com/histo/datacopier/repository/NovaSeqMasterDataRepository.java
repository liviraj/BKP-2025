package com.histo.datacopier.repository;

import com.histo.datacopier.entity.NovaSeqMasterData;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface NovaSeqMasterDataRepository extends MongoRepository<NovaSeqMasterData, String> {
}
