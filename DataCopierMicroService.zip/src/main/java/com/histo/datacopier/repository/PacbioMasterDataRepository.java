package com.histo.datacopier.repository;

import com.histo.datacopier.entity.PacbioMasterData;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PacbioMasterDataRepository extends MongoRepository<PacbioMasterData, String> {
}
