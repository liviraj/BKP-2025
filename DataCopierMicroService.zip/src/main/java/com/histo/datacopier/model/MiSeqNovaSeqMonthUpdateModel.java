package com.histo.datacopier.model;

public class MiSeqNovaSeqMonthUpdateModel {
    private String id;
    private Integer yearIndex;
    private Integer monthIndex;
    private String monthName;

    public MiSeqNovaSeqMonthUpdateModel() {
    }

    public MiSeqNovaSeqMonthUpdateModel(String id, Integer yearIndex, Integer monthIndex, String monthName) {
        this.id = id;
        this.yearIndex = yearIndex;
        this.monthIndex = monthIndex;
        this.monthName = monthName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getYearIndex() {
        return yearIndex;
    }

    public void setYearIndex(Integer yearIndex) {
        this.yearIndex = yearIndex;
    }

    public Integer getMonthIndex() {
        return monthIndex;
    }

    public void setMonthIndex(Integer monthIndex) {
        this.monthIndex = monthIndex;
    }

    public String getMonthName() {
        return monthName;
    }

    public void setMonthName(String monthName) {
        this.monthName = monthName;
    }

    @Override
    public String toString() {
        return "IlluminaMonthUpdateDTO{" +
                "id='" + id + '\'' +
                ", yearIndex=" + yearIndex +
                ", monthIndex=" + monthIndex +
                ", monthName='" + monthName + '\'' +
                '}';
    }
}
