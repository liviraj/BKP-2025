package com.histo.datacopier.model;

public class MiSeqNovaSeqYearUpdateModel {
    private String id;
    private Integer yearIndex;
    private String yearName;

    public MiSeqNovaSeqYearUpdateModel() {
    }

    public MiSeqNovaSeqYearUpdateModel(String id, Integer yearIndex, String yearName) {
        this.id = id;
        this.yearIndex = yearIndex;
        this.yearName = yearName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getYearIndex() {
        return yearIndex;
    }

    public void setYearIndex(Integer yearIndex) {
        this.yearIndex = yearIndex;
    }

    public String getYearName() {
        return yearName;
    }

    public void setYearName(String yearName) {
        this.yearName = yearName;
    }

    @Override
    public String toString() {
        return "IlluminaYearUpdateDTO{" +
                "id='" + id + '\'' +
                ", yearIndex=" + yearIndex +
                ", yearName='" + yearName + '\'' +
                '}';
    }
}
