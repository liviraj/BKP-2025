package com.histo.datacopier.model;


import com.histo.datacopier.entity.IlluminaMasterDataItem;

import java.util.List;

public class MiSeqMasterDataUpdateModel {
    private String id;
    private List<IlluminaMasterDataItem> illuminaMasterData;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setIlluminaMasterData(List<IlluminaMasterDataItem> illuminaMasterData) {
        this.illuminaMasterData = illuminaMasterData;
    }

    public List<IlluminaMasterDataItem> getIlluminaMasterData() {
        return illuminaMasterData;
    }

    @Override
    public String toString() {
        return "IlluminaMasterDataUpdateDTO{" +
                "id='" + id + '\'' +
                ", illuminaMasterData=" + illuminaMasterData +
                '}';
    }
}