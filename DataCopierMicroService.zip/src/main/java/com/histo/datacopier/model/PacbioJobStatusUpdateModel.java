package com.histo.datacopier.model;

public class PacbioJobStatusUpdateModel {
    private String id;
    private Integer jobIndex;
    private String jobName;

    public PacbioJobStatusUpdateModel() {
    }

    public PacbioJobStatusUpdateModel(String id, Integer jobIndex, String jobName) {
        this.id = id;
        this.jobIndex = jobIndex;
        this.jobName = jobName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getJobIndex() {
        return jobIndex;
    }

    public void setJobIndex(Integer jobIndex) {
        this.jobIndex = jobIndex;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    @Override
    public String toString() {
        return "PacbioJobStatusUpdateDTO{" +
                "id='" + id + '\'' +
                ", jobIndex=" + jobIndex +
                ", jobName='" + jobName + '\'' +
                '}';
    }
}
