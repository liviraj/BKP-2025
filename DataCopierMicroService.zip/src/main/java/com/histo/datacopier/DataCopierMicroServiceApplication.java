package com.histo.datacopier;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
@OpenAPIDefinition(
		servers = {
				@Server(url = "https://javawebag01.histogenetics.com:8765/DataCopier", description = "PROD Server"),
				@Server(url = "https://10.10.4.8:8765/DataCopier", description = "PROD Server in IP"),
				@Server(url = "https://javawebag01.histogenetics.com:8100/DataCopier", description = "PROD Native Server"),
				@Server(url = "https://10.10.4.8:8100/DataCopier", description = "PROD Native Server in IP"),
				@Server(url = "http://localhost:8100/DataCopier", description = "Native Server in IP")
		}
)
public class DataCopierMicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataCopierMicroServiceApplication.class, args);
	}

}
