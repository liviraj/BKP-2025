package com.histo.datacopier.service.impl;

import com.histo.datacopier.config.IlluminaExperimentStatusProxy;
import com.histo.datacopier.entity.MiSeqMasterData;
import com.histo.datacopier.entity.NovaSeqMasterData;
import com.histo.datacopier.entity.PacbioMasterData;
import com.histo.datacopier.model.*;
import com.histo.datacopier.repository.MiSeqMasterDataRepository;
import com.histo.datacopier.repository.NovaSeqMasterDataRepository;
import com.histo.datacopier.repository.PacbioMasterDataRepository;
import com.histo.datacopier.service.DataCopierService;
import io.github.resilience4j.retry.annotation.Retry;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DataCopierServiceImpl implements DataCopierService {
    private static final Logger LOGGER = LogManager.getLogger(DataCopierServiceImpl.class.getName());
    private final MiSeqMasterDataRepository miSeqMasterDataRepository;
    private final NovaSeqMasterDataRepository novaSeqMasterDataRepository;
    private final PacbioMasterDataRepository pacbioMasterDataRepository;
    private final IlluminaExperimentStatusProxy illuminaExperimentStatusProxy;
//    // private final PropertyConfig propertyConfig;
//    Connection con = NextGenSeqSqlCon.getConnection();
//    JdbcTemplate jdbcTemplate = new JdbcTemplate(new SingleConnectionDataSource(con, false));

    public DataCopierServiceImpl(MiSeqMasterDataRepository miSeqMasterDataRepository
            , NovaSeqMasterDataRepository novaSeqMasterDataRepository
            , PacbioMasterDataRepository pacbioMasterDataRepository,
                                 // , PropertyConfig propertyConfig
                                 IlluminaExperimentStatusProxy illuminaExperimentStatusProxy) {
        this.miSeqMasterDataRepository = miSeqMasterDataRepository;
        this.novaSeqMasterDataRepository = novaSeqMasterDataRepository;
        this.pacbioMasterDataRepository = pacbioMasterDataRepository;
        // this.propertyConfig = propertyConfig;
        this.illuminaExperimentStatusProxy = illuminaExperimentStatusProxy;
    }

    @Override
    public ResponseEntity<Object> saveIlluminaSyncDetails(IlluminaMasterDataModel illuminaMasterData) {
        MiSeqMasterData masterData = new MiSeqMasterData();
        masterData.setIlluminaMasterData(illuminaMasterData.getIlluminaMasterData());
        masterData = miSeqMasterDataRepository.save(masterData);
        return new ResponseEntity<>(masterData, HttpStatus.OK);

    }

    @Override
    public String updateMiSeqDetails(MiSeqMasterDataUpdateModel illuminaMasterData) {
        Optional<MiSeqMasterData> illuminaMaster = miSeqMasterDataRepository.findById(illuminaMasterData.getId());
        if (!illuminaMaster.isPresent()) {
            LOGGER.error("Illumina master data not found. Id: {}", illuminaMasterData.getId());
            return "Illumina master data not found.";
        }
        illuminaMaster.get().setIlluminaMasterData(illuminaMasterData.getIlluminaMasterData());
        MiSeqMasterData updateMiSeqMasterData = miSeqMasterDataRepository.save(illuminaMaster.get());
        return "Updated Successfully";
    }

    @Override
    public String updateNovaSeqDetails(NovaSeqMasterDataUpdateModel novaSeqMasterDataUpdateDTO) {
        Optional<NovaSeqMasterData> novaSeqMaster = novaSeqMasterDataRepository.findById(novaSeqMasterDataUpdateDTO.getId());
        if (!novaSeqMaster.isPresent()) {
            LOGGER.error("Illumina master data not found. Id: {}", novaSeqMasterDataUpdateDTO.getId());
            return "Illumina master data not found.";
        }
        novaSeqMaster.get().setIlluminaMasterData(novaSeqMasterDataUpdateDTO.getIlluminaMasterData());
        NovaSeqMasterData updateNovaSeqMasterData = novaSeqMasterDataRepository.save(novaSeqMaster.get());
        return "Updated Successfully";
    }

    @Override
    public MiSeqMasterData getAllMiSeqSyncDetails() {
        List<MiSeqMasterData> miSeqAll = miSeqMasterDataRepository.findAll();
        return miSeqAll.size() > 0 ? miSeqAll.get(0) : null;
    }

    @Override
    public NovaSeqMasterData getAllNovaSyncDetails() {
        List<NovaSeqMasterData> novaSeqAll = novaSeqMasterDataRepository.findAll();
        return novaSeqAll.size() > 0 ? novaSeqAll.get(0) : null;
    }

    @Override
    public String updatePacbioSyncDetails(PacbioMasterDataModel pacbioMasterDataModel) {
        Optional<PacbioMasterData> pacbioMasterData = pacbioMasterDataRepository.findById(pacbioMasterDataModel.getId());
        if (!pacbioMasterData.isPresent()) {
            LOGGER.error("Pacbio master data not found. Id: {}", pacbioMasterDataModel.getId());
            return "Pacbio master data not found.";
        }
        pacbioMasterData.get().setJobs(pacbioMasterDataModel.getJobs());
        PacbioMasterData updatePacbioData = pacbioMasterDataRepository.save(pacbioMasterData.get());
        return "Updated Successfully";
    }

    @Override
    public ResponseEntity<String> syncMiSeqDetails(MiSeqMasterData miSeqSyncDetails) {
        try {
            miSeqSyncDetails = miSeqMasterDataRepository.save(miSeqSyncDetails);
            return new ResponseEntity<>("Successfully details synced", HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error("syncMiSeqDetails() Error: {}" + e);
            return new ResponseEntity<>("Failed to sync details", HttpStatus.CONFLICT);
        }
    }

    @Override
    public ResponseEntity<String> syncNovaSeqDetails(NovaSeqMasterData novaSeqSyncDetails) {
        try {
            novaSeqSyncDetails = novaSeqMasterDataRepository.save(novaSeqSyncDetails);
            return new ResponseEntity<>("Successfully details synced", HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error("syncNovaSeqDetails() Error: {}" + e);
            return new ResponseEntity<>("Failed to sync details", HttpStatus.CONFLICT);
        }
    }

    @Override
    public ResponseEntity<String> syncPacbioDetails(PacbioMasterData allPacbioSyncDetails) {
        try {
            allPacbioSyncDetails = pacbioMasterDataRepository.save(allPacbioSyncDetails);
            return new ResponseEntity<>("Successfully details synced", HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error("syncPacbioDetails() Error: {}" + e);
            return new ResponseEntity<>("Failed to sync details", HttpStatus.CONFLICT);
        }
    }

    @Override
    public PacbioMasterData getAllPacbioSyncDetails() {
        List<PacbioMasterData> pacbioSyncDetails = pacbioMasterDataRepository.findAll();
        return pacbioSyncDetails.size() > 0 ? pacbioSyncDetails.get(0) : null;
    }

    @Override
    @Retry(name = "dataCopierRetry", fallbackMethod = "retryLogFallback")
    public String insertIlluminaBackupLog(IlluminaDataSecondaryBackupLogModel backupLog) {
        return illuminaExperimentStatusProxy.insertIlluminaBackupLog(backupLog);
    }

    @Override
    @Retry(name = "dataCopierRetry", fallbackMethod = "retryLogFallback")
    public String insertPacbioBackupLog(PacbioDataSecondaryBackupLogModel backupLog) {
        return illuminaExperimentStatusProxy.insertPacbioBackupLog(backupLog);
    }

    // Fallback method to be executed when all retries fail
    public String retryLogFallback(Exception e) {
        return e.getMessage();
    }

    @Override
    public String updateMiSeqExperimentStatus(MiSeqNovaSeqExperimentUpdateModel experiment) {

        try {
            MiSeqMasterData masterDocument = miSeqMasterDataRepository.findById(experiment.getId()).get();
            masterDocument.getIlluminaMasterData().get(experiment.getYearIndex())
                    .getMonths().get(experiment.getMonthIndex())
                    .getMachineIds().get(experiment.getMachineIndex())
                    .getExperiments().get(experiment.getExperimentIndex()).setIsCopied("yes");

            MiSeqMasterData updateMiSeq = miSeqMasterDataRepository.save(masterDocument);
            return "Update Successful";
        } catch (Exception e) {
            LOGGER.error("updateMiSeqExperimentStatus() Error: {}" + e);
            return "Update Failed";
        }

    }

    @Override
    public String updateNovaSeqExperimentStatus(MiSeqNovaSeqExperimentUpdateModel experiment) {

        try {
            NovaSeqMasterData masterDocument = novaSeqMasterDataRepository.findById(experiment.getId()).get();
            masterDocument.getIlluminaMasterData().get(experiment.getYearIndex())
                    .getMonths().get(experiment.getMonthIndex())
                    .getMachineIds().get(experiment.getMachineIndex())
                    .getExperiments().get(experiment.getExperimentIndex()).setIsCopied("yes");

            NovaSeqMasterData updateMiSeq = novaSeqMasterDataRepository.save(masterDocument);
            return "Update Successful";
        } catch (Exception e) {
            LOGGER.error("updateNovaSeqExperimentStatus() Error: {}" + e);
            return "Update Failed";
        }

    }

    @Override
    public String updateMiSeqMachineStatus(MiSeqNovaSeqMachineUpdateModel machine) {
        try {
            MiSeqMasterData masterDocument = miSeqMasterDataRepository.findById(machine.getId()).get();
            masterDocument.getIlluminaMasterData().get(machine.getYearIndex())
                    .getMonths().get(machine.getMonthIndex())
                    .getMachineIds().get(machine.getMachineIndex())
                    .setIsCopied("yes");

            MiSeqMasterData updateIllumina = miSeqMasterDataRepository.save(masterDocument);
            return "Update Successful";
        } catch (Exception e) {
            LOGGER.error("updateMiSeqMachineStatus() Error: {}" + e);
            return "Status Update Failed";
        }
    }

    @Override
    public String updateNovaSeqMachineStatus(MiSeqNovaSeqMachineUpdateModel machine) {
        try {
            NovaSeqMasterData masterDocument = novaSeqMasterDataRepository.findById(machine.getId()).get();
            masterDocument.getIlluminaMasterData().get(machine.getYearIndex())
                    .getMonths().get(machine.getMonthIndex())
                    .getMachineIds().get(machine.getMachineIndex())
                    .setIsCopied("yes");

            NovaSeqMasterData updateIllumina = novaSeqMasterDataRepository.save(masterDocument);
            return "Update Successful";
        } catch (Exception e) {
            LOGGER.error("updateNovaSeqMachineStatus() Error: {}" + e);
            return "Status Update Failed";
        }
    }

    @Override
    public String updateMiSeqMonthStatus(MiSeqNovaSeqMonthUpdateModel month) {
        try {
            MiSeqMasterData masterDocument = miSeqMasterDataRepository.findById(month.getId()).get();
            masterDocument.getIlluminaMasterData().get(month.getYearIndex())
                    .getMonths().get(month.getMonthIndex())
                    .setIsCopied("yes");

            MiSeqMasterData updateIllumina = miSeqMasterDataRepository.save(masterDocument);
            return "Update Successful";
        } catch (Exception e) {
            LOGGER.error("updateMiSeqMonthStatus() Error: {}" + e);
            return "Status Update Failed";
        }
    }

    @Override
    public String updateNovaSeqMonthStatus(MiSeqNovaSeqMonthUpdateModel month) {
        try {
            NovaSeqMasterData masterDocument = novaSeqMasterDataRepository.findById(month.getId()).get();
            masterDocument.getIlluminaMasterData().get(month.getYearIndex())
                    .getMonths().get(month.getMonthIndex())
                    .setIsCopied("yes");

            NovaSeqMasterData updateIllumina = novaSeqMasterDataRepository.save(masterDocument);
            return "Update Successful";
        } catch (Exception e) {
            LOGGER.error("updateNovaSeqMonthStatus() Error: {}" + e);
            return "Status Update Failed";
        }
    }

    @Override
    public String updateMiSeqYearStatus(MiSeqNovaSeqYearUpdateModel year) {
        try {
            MiSeqMasterData masterDocument = miSeqMasterDataRepository.findById(year.getId()).get();
            masterDocument.getIlluminaMasterData().get(year.getYearIndex())
                    .setIsCopied("yes");

            MiSeqMasterData updateIllumina = miSeqMasterDataRepository.save(masterDocument);
            return "Update Successful";
        } catch (Exception e) {
            LOGGER.error("updateMiSeqYearStatus() Error: {}" + e);
            return "Status Update Failed";
        }
    }

    @Override
    public String updateNovaSeqYearStatus(MiSeqNovaSeqYearUpdateModel year) {
        try {
            NovaSeqMasterData masterDocument = novaSeqMasterDataRepository.findById(year.getId()).get();
            masterDocument.getIlluminaMasterData().get(year.getYearIndex())
                    .setIsCopied("yes");

            NovaSeqMasterData updateIllumina = novaSeqMasterDataRepository.save(masterDocument);
            return "Update Successful";
        } catch (Exception e) {
            LOGGER.error("updateNovaSeqYearStatus() Error: {}" + e);
            return "Status Update Failed";
        }
    }

    @Override
    public String updatePacbioJobStatus(PacbioJobStatusUpdateModel pacbioJob) {
        try {
            PacbioMasterData masterDocument = pacbioMasterDataRepository.findById(pacbioJob.getId()).get();
            masterDocument.getJobs().get(pacbioJob.getJobIndex()).setCopied(true);
            PacbioMasterData updatePacbio = pacbioMasterDataRepository.save(masterDocument);
            return "Update Successful";
        } catch (Exception e) {
            LOGGER.error("updatePacbioJobStatus() Error: {}" + e);
            return "Status Update Failed";
        }
    }

//    private Timestamp convertStringToTimeStamp(String time) throws ParseException {
//        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
//        Date parsedDate = dateFormat.parse(time);
//        Timestamp timestamp = new Timestamp(parsedDate.getTime());
//        return timestamp;
//    }
}
