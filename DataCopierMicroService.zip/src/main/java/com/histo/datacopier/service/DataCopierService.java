package com.histo.datacopier.service;

import com.histo.datacopier.entity.MiSeqMasterData;
import com.histo.datacopier.entity.NovaSeqMasterData;
import com.histo.datacopier.entity.PacbioMasterData;
import com.histo.datacopier.model.*;
import org.springframework.http.ResponseEntity;

public interface DataCopierService {
    public ResponseEntity<Object> saveIlluminaSyncDetails(IlluminaMasterDataModel illuminaMasterData);

    public String updateMiSeqDetails(MiSeqMasterDataUpdateModel miSeqMasterDataUpdateModel);

    public String updateNovaSeqDetails(NovaSeqMasterDataUpdateModel novaSeqMasterDataUpdateModelMasterData);

    public MiSeqMasterData getAllMiSeqSyncDetails();

    public NovaSeqMasterData getAllNovaSyncDetails();

    public String updatePacbioSyncDetails(PacbioMasterDataModel pacbioMasterData);

    public ResponseEntity<String> syncMiSeqDetails(MiSeqMasterData miSeqSyncDetails);

    public ResponseEntity<String> syncNovaSeqDetails(NovaSeqMasterData miSeqSyncDetails);

    public ResponseEntity<String> syncPacbioDetails(PacbioMasterData pacbioSyncDetails);

    public PacbioMasterData getAllPacbioSyncDetails();

    public String insertIlluminaBackupLog(IlluminaDataSecondaryBackupLogModel backupLog);

    public String insertPacbioBackupLog(PacbioDataSecondaryBackupLogModel backupLog);

    public String updateMiSeqExperimentStatus(MiSeqNovaSeqExperimentUpdateModel experiment);

    public String updateNovaSeqExperimentStatus(MiSeqNovaSeqExperimentUpdateModel experiment);

    public String updateMiSeqMachineStatus(MiSeqNovaSeqMachineUpdateModel machine);

    public String updateNovaSeqMachineStatus(MiSeqNovaSeqMachineUpdateModel machine);

    public String updateMiSeqMonthStatus(MiSeqNovaSeqMonthUpdateModel month);

    public String updateNovaSeqMonthStatus(MiSeqNovaSeqMonthUpdateModel month);

    public String updateMiSeqYearStatus(MiSeqNovaSeqYearUpdateModel year);

    public String updateNovaSeqYearStatus(MiSeqNovaSeqYearUpdateModel year);

    public String updatePacbioJobStatus(PacbioJobStatusUpdateModel pacbioJob);
}
