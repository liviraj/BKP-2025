package com.histo.datacopier.config;

import com.histo.datacopier.model.IlluminaDataSecondaryBackupLogModel;
import com.histo.datacopier.model.PacbioDataSecondaryBackupLogModel;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "IlluminaExperimentStatus", url = "${feign.illumina.base.url}")
public interface IlluminaExperimentStatusProxy {
    @PostMapping("/illumina/log")
    public String insertIlluminaBackupLog(@RequestBody IlluminaDataSecondaryBackupLogModel backupLog);

    @PostMapping("/pacbio/log")
    public String insertPacbioBackupLog(@RequestBody PacbioDataSecondaryBackupLogModel backupLog);
}
