package com.histo.datacopier.entity;

public class IlluminaMasterDataUpdate {
    private String id;
    private IlluminaMasterDataItem illuminaMasterData;

    public IlluminaMasterDataUpdate() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setIlluminaMasterData(IlluminaMasterDataItem illuminaMasterData) {
        this.illuminaMasterData = illuminaMasterData;
    }

    public IlluminaMasterDataItem getIlluminaMasterData() {
        return illuminaMasterData;
    }

    @Override
    public String toString() {
        return "IlluminaMasterData{" + "id='" + id + '\'' + ", illuminaMasterData=" + illuminaMasterData + '}';
    }
}