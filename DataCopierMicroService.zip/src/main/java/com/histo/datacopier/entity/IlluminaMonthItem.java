package com.histo.datacopier.entity;

import java.util.List;
import java.util.Objects;

public class IlluminaMonthItem {
    private String isCopied;
    private String month;
    private List<IlluminaMachineIdsItem> machineIds;

    public IlluminaMonthItem() {
    }

    public void setIsCopied(String isCopied) {
        this.isCopied = isCopied;
    }

    public String getIsCopied() {
        return isCopied;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getMonth() {
        return month;
    }

    public void setMachineIds(List<IlluminaMachineIdsItem> machineIds) {
        this.machineIds = machineIds;
    }

    public List<IlluminaMachineIdsItem> getMachineIds() {
        return machineIds;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof IlluminaMonthItem)) return false;
        IlluminaMonthItem monthItem = (IlluminaMonthItem) o;
        return getMonth().equals(monthItem.getMonth());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getMonth());
    }

    @Override
    public String toString() {
        return "IlluminaMonthItem{" +
                "isCopied='" + isCopied + '\'' +
                ", month='" + month + '\'' +
                ", machineIds=" + machineIds +
                '}';
    }
}