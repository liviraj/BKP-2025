package com.histo.datacopier.entity;

import java.util.Objects;

public class IlluminaExperimentItem {
    private String ngsExpName;
    private String isCopied;

    public IlluminaExperimentItem() {
    }

    public String getNgsExpName() {
        return ngsExpName;
    }

    public void setNgsExpName(String ngsExpName) {
        this.ngsExpName = ngsExpName;
    }

    public String getIsCopied() {
        return isCopied;
    }

    public void setIsCopied(String isCopied) {
        this.isCopied = isCopied;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof IlluminaExperimentItem)) return false;
        IlluminaExperimentItem that = (IlluminaExperimentItem) o;
        return getNgsExpName().equals(that.getNgsExpName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getNgsExpName());
    }

    @Override
    public String toString() {
        return "IlluminaExperimentItem{" +
                "ngsExpName='" + ngsExpName + '\'' +
                ", isCopied='" + isCopied + '\'' +
                '}';
    }
}
