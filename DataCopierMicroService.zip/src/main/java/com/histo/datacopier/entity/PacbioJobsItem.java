package com.histo.datacopier.entity;

import java.util.Objects;

public class PacbioJobsItem {
    private String jobId;
    private boolean isCopied;

    public PacbioJobsItem() {
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getJobId() {
        return jobId;
    }

    public boolean isCopied() {
        return isCopied;
    }

    public void setCopied(boolean copied) {
        isCopied = copied;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PacbioJobsItem)) return false;
        PacbioJobsItem that = (PacbioJobsItem) o;
        return getJobId().equals(that.getJobId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getJobId());
    }

    @Override
    public String toString() {
        return "PacbioJobsItem{" +
                "jobId='" + jobId + '\'' +
                ", isCopied=" + isCopied +
                '}';
    }
}
