package com.histo.datacopier.entity;

import java.util.List;
import java.util.Objects;

public class IlluminaMachineIdsItem {
    private String isCopied;
    private String id;
    private List<IlluminaExperimentItem> experiments;

    public IlluminaMachineIdsItem() {
    }

    public void setIsCopied(String isCopied) {
        this.isCopied = isCopied;
    }

    public String getIsCopied() {
        return isCopied;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setExperiments(List<IlluminaExperimentItem> experiments) {
        this.experiments = experiments;
    }

    public List<IlluminaExperimentItem> getExperiments() {
        return experiments;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof IlluminaMachineIdsItem)) return false;
        IlluminaMachineIdsItem that = (IlluminaMachineIdsItem) o;
        return getId().equals(that.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId());
    }

    @Override
    public String toString() {
        return "IlluminaMachineIdsItem{" +
                "isCopied='" + isCopied + '\'' +
                ", id='" + id + '\'' +
                ", experiments=" + experiments +
                '}';
    }
}