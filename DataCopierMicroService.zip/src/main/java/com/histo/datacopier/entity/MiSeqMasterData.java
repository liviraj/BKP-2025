package com.histo.datacopier.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document
public class MiSeqMasterData {
    @Id
    private String id;
    private List<IlluminaMasterDataItem> illuminaMasterData;

    public MiSeqMasterData() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setIlluminaMasterData(List<IlluminaMasterDataItem> illuminaMasterData) {
        this.illuminaMasterData = illuminaMasterData;
    }

    public List<IlluminaMasterDataItem> getIlluminaMasterData() {
        return illuminaMasterData;
    }

    @Override
    public String toString() {
        return "IlluminaMasterData{" + "id='" + id + '\'' + ", illuminaMasterData=" + illuminaMasterData + '}';
    }
}