package com.histo.datacopier.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document
public class PacbioMasterData {
    @Id
    private String id;
    private List<PacbioJobsItem> jobs;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List<PacbioJobsItem> getJobs() {
        return jobs;
    }

    public void setJobs(List<PacbioJobsItem> jobs) {
        this.jobs = jobs;
    }

    @Override
    public String toString() {
        return "PacbioMasterData{" +
                "id='" + id + '\'' +
                ", jobs=" + jobs +
                '}';
    }
}