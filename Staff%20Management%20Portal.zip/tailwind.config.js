/* eslint-disable no-undef */
/** @type {import('tailwindcss').Config} */
const colors = require('tailwindcss/colors');
const defaultTheme = require('tailwindcss/defaultTheme');

module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}",],
  theme: {
    extend: {
      height: {
        'screen/90': '90vh',
      },
      width: {
        'screen/90': '90vw',
      },
      strokeWidth: {
        "30px": "30px"
      }
    },
    colors: {
      ...colors,
      textOrangeHighlight: '#e36900d9',
      headerColor: "#ef4641",
      homeTextColor: "#7a8c8c",
      darkDarkGrey: "#757575",
      darkGrey: "#7c7a7a",
      lightGrey: "#afacace3",
      darkCustomGrey: "#655f5f",
      sidebarBgColor: "#c6362e",
      borderColor: "#d15d57",
      pathHighlight: "#9d2a25",
      darkGreyBorder: "#9e9ea0",
      boxShadow: "rgba(0, 0, 0, 0.6)",
      blurColor: "#f5f5f594",
      redColor: "#FF0000",
      greenColor: "#00CA00",
      blueColor: "#0072d3",
      blackColor: "#000000",
      lightOrangeHead: "#ffddd4",
      borderBlue: "#66bfe1",
      calendarThemeColor: "#17405d",
      calendarTextColor: "#1A202C",
      lightorangeErrBgColor: '#fecacb',
      wrngMsgTextColor: "#d90e15",
      borderThemeColor: "#f3bebd",
      themeBgColor: "#ffe2e1",
      themeHighlightColor: "#fbd1d0"
    },
    fontFamily: {
      ...defaultTheme.fontFamily,
      fontfamily: ['Nunito Sans', 'sans-serif'],
      // fontfamily: ['Roboto', 'sans-serif'],
      // fontfamily: ['Inter', 'sans-serif'],
      // fontfamily:["Poppins", 'sans-serif'],
      // fontfamily:["Caladea", 'serif'],
      // fontfamily:["Lato", 'sans-serif'],
      // fontfamily:["Montserrat", 'sans-serif'],
      // fontfamily:["Mulish", 'sans-serif'],
      QuattrocentoSans: ["Quattrocento Sans", 'sans-serif'],
      poppinsSans: ["Poppins", 'sans-serif']
    },
    fontSize: {
      ...defaultTheme.fontSize,
      medium: "27px",
      "18px": '18px',
      "16px": '16px',
      "12px": "12px",
      "13px": "13px",
      "14px": "14px",
      "15px": "15px",
      "2rem": "2rem",
    },
    borderWidth: {
      ...defaultTheme.borderWidth,
      3: "3px",
      1: "1px",
      ".5": "0.5px"
    },
    screens: {
      ...defaultTheme.screens,
      xsm: "0px"
    },
    spacing: {
      ...defaultTheme.spacing,
      "8vh": "8vh",
      "7vh": "7vh",
      "6vh": "6vh",
      "5vh": "5vh",
      "20vh": "20vh",
      "50vh": "50vh",
      "75vh": "75vh",
      "78vh": "78vh",
      "80vh": "80vh",
      "85vh": "85vh",
      "90vh": "90vh",
      "93vh": "93vh",
      "employeeCalc_md": "calc(86vh - 2.5rem)",
      "employeeCalc_sm": "calc(100vh - 6rem)",
      "employeeCalc_xsm": "calc(100vh - 4.6rem)",
      "widthCalc": "calc(100vw - 15.9rem)",
      "h_body_md": "calc(100vh - 4.6rem - 3.6rem)"
    },
    minHeight: {
      ...defaultTheme.minHeight,
      ...defaultTheme.spacing,
      "75vh": "75vh",
      "50vh": "50vh",
    },
    minWidth: {
      ...defaultTheme.minWidth,
      ...defaultTheme.spacing,
      "14rem": "14rem",
    },
    boxShadow: {
      ...defaultTheme.boxShadow,
      contextMenu: "2px 2px 7px 1px",
      minShadow: "1px 0.1px 1px"
    },

  },
  plugins: [],
}
