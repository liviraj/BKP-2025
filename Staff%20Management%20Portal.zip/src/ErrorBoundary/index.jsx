import PropTypes from 'prop-types';
import { Component } from 'react';
import { BsExclamationCircleFill } from 'react-icons/bs';
import LoginHeader from '../components/layouts/Header';
import Button from '../components/elements/Button';
import { strings } from '../components/Constants';

class ErrorBoundary extends Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false };
    }

    static getDerivedStateFromError() {
        return { hasError: true };
    }

    componentDidCatch(error, errorInfo) {
        console.error("Errors Found!..");
        console.error(error, errorInfo);
    }

    render() {
        const onRefresh = () => {
            window.location.reload();
        }
        if (this.state.hasError) {
            return (
                <>
                    <LoginHeader />
                    <div className=" flex justify-center items-center flex-col h-90vh w-full text-center font-QuattrocentoSans tracking-wider">
                        <div className='mb-2 flex justify-center'><BsExclamationCircleFill size={35} color="#ef4641" /></div>
                        <h1 className=' text-3xl text-darkGrey font-bold'>Something went wrong </h1>
                        <span className=' text-16px text-darkGreyBorder font-bold'>There was a problem processing the request. Please try again.</span>
                        <div className=" flex justify-center">
                            <Button value={strings.Buttons.refresh} onClick={() => onRefresh()} />
                        </div>
                    </div>
                </>
            )
        }

        return this.props.children;
    }
}

export default ErrorBoundary;

ErrorBoundary.propTypes = {
    children: PropTypes.element
}