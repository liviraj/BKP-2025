

/**
 * Configuration object to be passed to MSAL instance on creation.
 * For a full list of MSAL.js configuration parameters, visit:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/configuration.md
 */


export const msalConfig = {
  auth: {
    clientId: import.meta.env.VITE_CLIENTID,
    authority: import.meta.env.VITE_AUTHORITY,
    // redirectUri: apiConstants.loginRedirectUrl
    redirectUri: import.meta.env.BASE_URL, //process.env.PUBLIC_URL,
    TenantId: import.meta.env.VITE_TENANT_ID,
    Audience: import.meta.env.VITE_AUDIENCE,
  },
  cache: {
    cacheLocation: "sessionStorage", // This configures where your cache will be stored
    storeAuthStateInCookie: false, // Set this to "true" if you are having issues on IE11 or Edge
  },
  system: {
    loggerOptions: {
      loggerCallback: (_level, _message, containsPii) => {
        if (containsPii) {
          return;
        }
      },
    },
  },
};

/**
 * Scopes you add here will be prompted for user consent during sign-in.
 * By default, MSAL.js will add OIDC scopes (openid, profile, email) to any login request.
 * For more information about OIDC scopes, visit:
 * https://docs.microsoft.com/en-us/azure/active-directory/develop/v2-permissions-and-consent#openid-connect-scopes
 */
export const loginScopes = {
  scopes: ["User.Read"],
};

/**
 * Add here the scopes to request when obtaining an access token for MS Graph API. For more information, see:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/resources-and-scopes.md
 */


//https://login.microsoftonline.com/808c5c58-94cd-49e7-801b-96bac7abb8be/oauth2/v2.0/authorize?client_id=dd9498f5-754c-41b0-8bc9-2ae975fb270f&response_type=id_token&redirect_uri=http%3A%2F%2Flocalhost%3A5000%2F@resource=dd9498f5-754c-41b0-8bc9-2ae975fb270f&scope=openid&response_mode=fragment&state=12345&nonce=678910
