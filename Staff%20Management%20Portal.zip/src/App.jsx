import { useEffect, useState } from 'react';
import Home from './components/Home';
import Login from './components/login/Login';
import { store } from './redux/store';

function App() {

  const [isLoginVisible, setIsLoginVisible] = useState(false);

  useEffect(() => {
    window.addEventListener("click", () => setIsLoginVisible(store.getState().user.isLoginVisible));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  if (isLoginVisible) {
    return <Login />
  }
  return <Home />
}

export default App;
