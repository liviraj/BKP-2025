import ReactDOM from 'react-dom/client';
import App from './App';
import { Provider } from 'react-redux';
import { store } from './redux/store';
import { PublicClientApplication } from '@azure/msal-browser';
import { msalConfig } from './config';
import { MsalProvider } from '@azure/msal-react';
import './styles/index.css';
import { Router } from 'react-router-dom';
import { createHashHistory } from 'history';

const msalInstance = new PublicClientApplication(msalConfig);
const basename = import.meta.env.BASE_URL;
const history = createHashHistory({ basename });

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <MsalProvider instance={msalInstance}>
    <Provider store={store}>
      <Router history={history} >
        <App />
      </Router>
    </Provider>
  </MsalProvider>
);
