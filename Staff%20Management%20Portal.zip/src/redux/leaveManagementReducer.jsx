import { createSlice, current } from '@reduxjs/toolkit';

const leaveManagement = {
    leaveHistory: [],
    leaveRequestQueue: {
        leaveHistoryPopup: {
            data: [],
            show: false,
            rowData: {},
            loader: false,
            employeeName: ""
        },
        leaveReqDetailsScreen: {
            view: false,
            reqId: 0,
            empName: '',
            status: '',
            rowData: [],
            selectedRowData: [],
            comments: "",
            requestStatus: '' // Approve or Reject
        },
        selectedRow: {}
    },
    leaveLedger: {
        data: [],
        selectedRow: {},
        showPopUp: false,
        type: "",
        isUPloadAuditorEdit: { show: false, employeeId: '', fromDate: '', toDate: '', leaveType: '' }
    },
    loader: false,
    leaveType: [],
    allLeaveTypes: [],
    approveLeaveRequest: {
        show: false,
        requestId: 0,
        status: ""
    },
    leaveStatus: [],
    payroll: {},
    viewLeaveLedger: {
        data: [],
    },
};

export const leaveManagementReducer = createSlice({
    name: 'leaveManagement',
    initialState: leaveManagement,
    reducers: {
        setLeaveHistoryData: (state, action) => {
            state.leaveHistory = action.payload;
        },
        setLoader: (state, action) => {
            state.loader = action.payload;
        },
        setLeaveType: (state, action) => {
            state.leaveType = action.payload;
        },
        setAllLeaveTypes: (state, action) => {
            state.allLeaveTypes = action.payload;
        },
        setLeaveReqDetails: (state, action) => {
            state.leaveRequestQueue.leaveReqDetailsScreen = action.payload;
        },
        setLeaveLedgerData: (state, action) => {
            state.leaveLedger.data = action.payload;
        },
        setLeaveHistoryPopup: (state, action) => {
            const currentState = current(state);
            state.leaveRequestQueue.leaveHistoryPopup = { ...currentState.leaveRequestQueue.leaveHistoryPopup, ...action.payload };
        },
        setLeaveLedgerSelectedData: (state, action) => {
            state.leaveLedger.selectedRow = action.payload;
        },
        setApproveLeaveRequest: (state, action) => {
            state.approveLeaveRequest = action.payload;
        },
        setLeaveLedgerPopUp: (state, action) => {
            state.leaveLedger.showPopUp = action.payload;
        },
        setLeaveLedgerAddPopup: (state, action) => {
            const currentState = current(state);
            state.leaveLedger = { ...currentState.leaveLedger, ...action.payload };
        },
        resetLeaveLedgerEditPopup: (state) => {
            const currentState = current(state);
            state.leaveLedger = { ...currentState.leaveLedger, selectedRow: {}, type: "" };
        },
        setLeaveRequestQueueSelectedData: (state, action) => {
            state.leaveRequestQueue.selectedRow = action.payload;
        },
        setLeaveStatus: (state, action) => {
            state.leaveStatus = action.payload;
        },
        setPayroll: (state, action) => {
            state.payroll = action.payload;
        },
        setViewLeaveLedgerData: (state, action) => {
            state.viewLeaveLedger.data = action.payload;
        },
        setLeaveLedgerIsUPloadAuditorEdit: (state, action) => {
            state.leaveLedger.isUPloadAuditorEdit = action.payload
        }
    },
});

export const leaveManagementActions = leaveManagementReducer.actions;

export default leaveManagementReducer.reducer;