import { createSlice } from '@reduxjs/toolkit';

const loginResponse = {
    apiResponse: { show: false, status: 200, header: "Message Box", message: "", isOptional: false },
    imageViewer: { show: false, data: "", imageName: "" },
    multiDocumentViewer: { show: false, docs: [], header: "" },
    isMobileCompatible: false
};

export const loginResponseReducer = createSlice({
    name: 'loginResponse',
    initialState: loginResponse,
    reducers: {
        apiResponse: (state, action) => {
            state.apiResponse = action.payload;
        },
        updateImageViewer: (state, action) => {
            state.imageViewer = action.payload;
        },
        setMultiDocumentViewer: (state, action) => {
            state.multiDocumentViewer = action.payload;
        },
        setIsMobileCompatible: (state, action) => {
            state.isMobileCompatible = action.payload;
        }
    },
});

export const loginResponseActions = loginResponseReducer.actions;

export default loginResponseReducer.reducer;