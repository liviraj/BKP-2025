import { createSlice, current } from "@reduxjs/toolkit";

const initialState = {
    holidayList: {
        loader: false,
        data: []
    },
    floatingHolidayList: {
        loader: false,
        data: [],
        yearlyFloatingHolidays: []
    },
    addFloatingHolidayList: {
        loader: false,
        data: [],
        popup: { show: false, action: "", selectedRecord: {} }
    },
    floatingHolidayOptionsPopup: {
        show: false,
        employeeDetails: {}
    },
    holidayName: {
        data: [],
        popup: { show: false, action: "", selectedRecord: {} }
    },
    addHoliday: {
        data: [],
        popup: { show: false, action: "", selectedRecord: {}, selectedRow: [] },
        holidayNames: [],
        isEnableAddButtonforUSA: true
    },
    holidays: [],
    employeeBasedHolidays: [],
    alternateHolidays: []
}

const holidayReducer = createSlice({
    name: "holiday",
    initialState,
    reducers: {
        setHolidayListLoader: (state, action) => {
            state.holidayList.loader = action.payload;
        },
        setAddHolidayPopup: (state, action) => {
            const currentState = current(state);
            state.addHoliday.popup = { ...currentState.addHoliday.popup, ...action.payload };
        },
        setHolidayListData: (state, action) => {
            state.holidayList.data = action.payload;
        },
        setFloatingHolidayListLoader: (state, action) => {
            state.floatingHolidayList.loader = action.payload;
        },
        setFloatingHolidayListData: (state, action) => {
            state.floatingHolidayList.data = action.payload;
        },
        setAddFloatingHolidayLoader: (state, action) => {
            state.addFloatingHolidayList.loader = action.payload;
        },
        setAddFloatingHolidayData: (state, action) => {
            state.addFloatingHolidayList.data = action.payload;
        },
        setAddFloatingHolidayPopup: (state, action) => {
            const currentState = current(state);
            state.addFloatingHolidayList.popup = { ...currentState.addFloatingHolidayList.popup, ...action.payload };
        },
        setFloatingHolidayOptionsPopup: (state, action) => {
            const currentState = current(state);
            state.floatingHolidayOptionsPopup = { ...currentState.floatingHolidayOptionsPopup, ...action.payload };
        },
        setHolidayNameLists: (state, action) => {
            state.holidayName.data = action.payload;
        },
        setHolidayNamePopup: (state, action) => {
            const currentState = current(state);
            state.holidayName.popup = { ...currentState.holidayName.popup, ...action.payload };
        },
        setAddHolidayData: (state, action) => {
            state.addHoliday.data = action.payload;
        },
        setAddHolidayNames: (state, action) => {
            state.addHoliday.holidayNames = action.payload;
        },
        setYearlyFloatingHolidayOptions: (state, action) => {
            state.floatingHolidayList.yearlyFloatingHolidays = action.payload;
        },
        setHolidays: (state, action) => {
            state.holidays = action.payload;
        },
        setEmployeeBasedHolidays: (state, action) => {
            state.employeeBasedHolidays = action.payload;
        },
        setAlternateHolidays: (state, action) => {
            state.alternateHolidays = action.payload;
        },
        setIsEnableAddButtonforUSA: (state, action) => {
            state.addHoliday.isEnableAddButtonforUSA = action.payload;
        }

    }
});

export const holidayActions = holidayReducer.actions;

export default holidayReducer.reducer;