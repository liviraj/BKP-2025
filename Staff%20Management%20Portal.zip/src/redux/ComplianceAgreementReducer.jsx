import { createSlice, current } from '@reduxjs/toolkit';

const initialState = {
    documentPopup: { show: false, selectedRow: {}, action: '', preloadDetails: {} },
    documenType: [],
    loader: false,
    documentData: [],
    agreementDocument: {
        loader: false,
        agreementDocmentPopup: { show: false, selectedRow: {}, action: "" },
        availableUser: {
            treeData: [],
            checkedKeys: [],
            expandedKeys: [],
            searchExpandedKeys: [],
            autoExpandParent: true
        },
        selectedUser: {
            treeData: [],
            checkedKeys: [],
            expandedKeys: [],
        },
    },
    pdfViewerPopup: { show: false, data: null, docxName: '' },
    complianceDocHistory: [],
    notifyPendingPolicies: {
        isShow: false,
        userData: [],
        pendingPolicyUser: {
            treeData: [],
            checkedKeys: [],
            expandedKeys: [],
            searchExpandedKeys: [],
            autoExpandParent: true
        },
        completedPolicyUser: {
            treeData: [],
            checkedKeys: [],
            expandedKeys: [],
            searchExpandedKeys: [],
            autoExpandParent: true
        },
        filterData: [],
        selectedRow: {},
        loader: false
    },
    notificationData: [],
    employeeAgreementPolicy: {
        policyData: [],
        totalCount: 0,
        currentPolicyData: {},
        currentPolicyId: 0,
        isNotification: false
    },
    assignedDocumentHistory: {
        data: []
    },
    agreementPolicyType: [],
    assignedDocumentHistoryPopup: { show: false, selectedRow: {} },
    employeeAcceptanceStatusData: { employeeDetails: [], totalCount: {} },
    employeeagreementPolicyPopup: { show: false },
};

export const ComplianceAgreementReducer = createSlice({
    name: 'ComplianceAgreement',
    initialState: initialState,
    reducers: {
        setLoader: (state, action) => {
            state.loader = action.payload;
        },
        setDocumentPopup: (state, action) => {
            state.documentPopup = action.payload;
        },
        setDocumenType: (state, action) => {
            state.documenType = action.payload;
        },
        setPreloadDetails: (state, action) => {
            state.documentPopup.preloadDetails = action.payload;
        },
        reSetDocumentPopup: (state) => {
            state.documentPopup = initialState.documentPopup;
        },
        setDocumentData: (state, action) => {
            state.documentData = action.payload;
        },
        setAgreementDocmentPopup: (state, action) => {
            state.agreementDocument.agreementDocmentPopup = action.payload;
        },
        setAvailableUser: (state, action) => {
            const currentState = current(state);
            state.agreementDocument.availableUser = { ...currentState.agreementDocument.availableUser, ...action.payload };
        },
        setSelectedUser: (state, action) => {
            const currentState = current(state);
            state.agreementDocument.selectedUser = { ...currentState.agreementDocument.selectedUser, ...action.payload };
        },
        reSetAgreementDocument: (state) => {
            state.agreementDocument = initialState.agreementDocument;
        },
        setPdfViewerPopup: (state, action) => {
            state.pdfViewerPopup = action.payload;
        },
        resetPdfViewerPopup: (state) => {
            state.pdfViewerPopup = initialState.pdfViewerPopup;
        },
        setcomplianceDocHistory: (state, action) => {
            state.complianceDocHistory = action.payload;
        },
        setPendingPolicyUser: (state, action) => {
            const currentState = current(state);
            state.notifyPendingPolicies.pendingPolicyUser = { ...currentState.notifyPendingPolicies.pendingPolicyUser, ...action.payload };
        },
        setCompletedPolicyUser: (state, action) => {
            const currentState = current(state);
            state.notifyPendingPolicies.completedPolicyUser = { ...currentState.notifyPendingPolicies.completedPolicyUser, ...action.payload };
        },
        setFilterData: (state, action) => {
            state.notifyPendingPolicies.filterData = action.payload;
        },
        setUserData: (state, action) => {
            state.notifyPendingPolicies.userData = action.payload;
        },
        resetPendingPolicyUser: (state) => {
            state.notifyPendingPolicies.pendingPolicyUser = initialState.notifyPendingPolicies.pendingPolicyUser;
        },
        resetCompletePolicyUser: (state) => {
            state.notifyPendingPolicies.completedPolicyUser = initialState.notifyPendingPolicies.completedPolicyUser;
        },
        setNotification: (state, action) => {
            state.notificationData = action.payload;
        },
        setEmployeeAgreementPolicy: (state, action) => {
            const currentState = current(state);
            state.employeeAgreementPolicy = { ...currentState.employeeAgreementPolicy, ...action.payload };
        },
        resetEmployeeAgreementPolicy: (state) => {
            state.employeeAgreementPolicy = initialState.employeeAgreementPolicy
        },
        setAssignedDocumentHistoryData: (state, action) => {
            state.assignedDocumentHistory.data = action.payload;
        },
        setAgreementPolicyType: (state, action) => {
            state.agreementPolicyType = action.payload;
        },
        setNotifyPolicyShow: (state, action) => {
            state.notifyPendingPolicies.isShow = action.payload;
        },
        setNotifySelectedRow: (state, action) => {
            state.notifyPendingPolicies.selectedRow = action.payload;
        },
        setNotifyPendingLoader: (state, action) => {
            state.notifyPendingPolicies.loader = action.payload;
        },
        setAgreementDocumentLoader: (state, action) => {
            state.agreementDocument.loader = action.payload;
        },
        setAssignedDocumentHistoryPopup: (state, action) => {
            state.assignedDocumentHistoryPopup = action.payload;
        },
        reSetAssignedDocumentHistoryPopup: (state) => {
            state.assignedDocumentHistoryPopup = initialState.assignedDocumentHistoryPopup;
        },
        setEmployeeAcceptanceStatusData: (state, action) => {
            state.employeeAcceptanceStatusData = action.payload;
        },
        setEmployeeagreementPolicyPopup: (state, action) => {
            state.employeeagreementPolicyPopup = action.payload;
        },
        reSetEmployeeagreementPolicyPopup: (state) => {
            state.employeeagreementPolicyPopup = initialState.employeeagreementPolicyPopup;
        }
    },
});

export const ComplianceAgreementActions = ComplianceAgreementReducer.actions;

export default ComplianceAgreementReducer.reducer;