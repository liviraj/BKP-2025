import { createSlice, current } from '@reduxjs/toolkit';

const complianceReport = {
    employeeType: [],
    data: [],
    loader: false,
    complianceView: { show: false },
    complianceFilterValues: { employeeType: {}, employeeName: {}, selectionYear: "", dateOfJoin: "", designation: "" },
    complianceNotify: { show: false, columns: [], data: [] },
    complianceReportPopup: { show: false, data: {}, isPopupView: false },
    complianceNotifyMailDetails: { show: false, data: [], selectedRow: [] }
};

export const complianceReportReducer = createSlice({
    name: 'complianceReport',
    initialState: complianceReport,
    reducers: {
        setComplianceRecord: (state, action) => {
            state.data = action.payload
        },
        setEmployeeType: (state, action) => {
            state.employeeType = action.payload;
        },
        setComplianceView: (state, action) => {
            state.complianceView = action.payload;
        },
        setLoader: (state, action) => {
            state.loader = action.payload;
        },
        setComplianceFilterValues: (state, action) => {
            const currentState = current(state);
            state.complianceFilterValues = { ...currentState.complianceFilterValues, ...action.payload };
        },
        setComplianceNotify: (state, action) => {
            state.complianceNotify = action.payload;
        },
        setComplianceReportPopup: (state, action) => {
            state.complianceReportPopup = action.payload;
        },
        setComplianceNotifyMailDetails: (state, action) => {
            const currentState = current(state);
            state.complianceNotifyMailDetails = { ...currentState.complianceNotifyMailDetails, ...action.payload };
        }
    },
});

export const complianceReportActions = complianceReportReducer.actions;

export default complianceReportReducer.reducer;