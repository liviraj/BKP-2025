import { createSlice, current } from '@reduxjs/toolkit';

const permissionInitialState = {
    loader: false,
    permissionType: [],
    addPermissionPopup: { show: false, type: "", selectedRow: [] },
    permissionRequestdata: [],
    permissionRequestDetails: [],
    requestApprovalPopup: { show: false, selectedRowData: {}, requestStatus: '' },
    permissionHistoryPopup: { data: [], show: false, rowData: [], loader: false, employeeName: "" },
    redirectPermissionRequest: {
        show: false,
        permissionId: 0,
        status: ""
    },
}

export const permissionReducer = createSlice({
    name: 'permission',
    initialState: permissionInitialState,
    reducers: {
        setLoader: (state, action) => {
            state.loader = action.payload;
        },
        setPermissionType: (state, action) => {
            state.permissionType = action.payload;
        },
        setAddPermissionPopup: (state, action) => {
            const currectState = current(state);
            state.addPermissionPopup = { ...currectState.addPermissionPopup, ...action.payload };
        },
        setpermissionRequestdata: (state, action) => {
            state.permissionRequestdata = action.payload;
        },
        setRequestApprovalPopup: (state, action) => {
            const currectState = current(state);
            state.requestApprovalPopup = { ...currectState.requestApprovalPopup, ...action.payload };
        },
        setPermissionHistoryPopup: (state, action) => {
            const currectState = current(state);
            state.permissionHistoryPopup = { ...currectState.permissionHistoryPopup, ...action.payload };
        },
        setRedirectPermissionRequest: (state, action) => {
            state.redirectPermissionRequest = action.payload;
        },
        setPermissionRequestDetails: (state, action) => {
            state.permissionRequestDetails = action.payload;
        },
    }
})

export const permissionAction = permissionReducer.actions;

export default permissionReducer.reducer;