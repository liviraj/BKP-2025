import { createSlice, current } from '@reduxjs/toolkit'

const requestInitialState = {
    requestData: [],
    popup: { show: false, selectedRow: {}, actions: "", loader: false }, // Add & Edit Request popup
    typeofRequest: [],
    status: [],
    loader: false,
    approvePopup: { show: false, selectedRow: {}, actions: "", loader: false }, // Approve & Reject popup
    trackingRequest: { data: [], requestView: { show: false, selectedRecord: {} } },
    trackingStatus: [],
    assigneeList: []
}

export const myRequestReducer = createSlice({
    name: "MyRequest",
    initialState: requestInitialState,
    reducers: {
        showPopup: (state, action) => {
            const currentState = current(state);
            state.popup = { ...currentState.popup, ...action.payload };
        },
        resetPopup: (state) => {
            state.popup = requestInitialState.popup;
        },
        setTypeOfRequest: (state, action) => {
            state.typeofRequest = action.payload;
        },
        setLoader: (state, action) => {
            state.loader = action.payload;
        },
        setRequestData: (state, action) => {
            state.requestData = action.payload;
        },
        setStatusTypes: (state, action) => {
            state.status = action.payload;
        },
        setApprovePopup: (state, action) => {
            state.approvePopup = action.payload;
        },
        setTrackingRequest: (state, action) => {
            const currentState = current(state);
            state.trackingRequest = { ...currentState.trackingRequest, ...action.payload };
        },
        setTrackingStatus: (state, action) => {
            state.trackingStatus = action.payload;
        },
        setAssigneeList: (state, action) => {
            state.assigneeList = action.payload;
        }
    }
})

export const myRequestActions = myRequestReducer.actions;

export default myRequestReducer.reducer;