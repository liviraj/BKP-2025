import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    balanceSummary: {
        data: [],
        loader: false
    },
    summaryDetails: {
        data: [],
        loader: false
    },
    leaveLedger: {
        data: [],
        loader: false
    }
};

export const sickLeaveReducer = createSlice({
    name: 'sickLeave',
    initialState: initialState,
    reducers: {
        setBalanceSummaryData: (state, action) => {
            state.balanceSummary.data = action.payload;
        },
        setBalanceSummaryLoader: (state, action) => {
            state.balanceSummary.loader = action.payload;
        },
        setSummaryDetailsData: (state, action) => {
            state.summaryDetails.data = action.payload;
        },
        setSummaryDetailLoader: (state, action) => {
            state.summaryDetails.loader = action.payload;
        },
        setLeaveLedgerData: (state, action) => {
            state.leaveLedger.data = action.payload;
        },
        setLeaveLedgerLoader: (state, action) => {
            state.leaveLedger.loader = action.payload;
        },
    },
});

export const sickLeaveActions = sickLeaveReducer.actions;

export default sickLeaveReducer.reducer;