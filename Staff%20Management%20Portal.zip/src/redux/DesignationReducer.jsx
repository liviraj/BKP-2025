import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    designationPopup: { show: false, selectedRow: [], isEditable: false },
    loader: false,
    designationDetails: []
}
export const designationReducer = createSlice({
    name: 'designation',
    initialState: initialState,
    reducers: {
        setDesignationPopup: (state, action) => {
            state.designationPopup = action.payload;
        },
        reSetDesignationPopup: (state) => {
            state.designationPopup = initialState.designationPopup
        },
        setLoader: (state, action) => {
            state.loader = action.payload;
        },
        setDesignationDetails: (state, action) => {
            state.designationDetails = action.payload;
        }
    },
});

export const designationActions = designationReducer.actions;
export default designationReducer.reducer;