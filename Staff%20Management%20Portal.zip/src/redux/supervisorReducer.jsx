import { createSlice, current } from "@reduxjs/toolkit";

const initialState = {
    floatingSupervisorOptionsPopup: {
        show: false,
        employeeDetails: {}
    },
    supervisorName: {
        data: [],
        popup: { show: false, action: "", selectedRecord: {} }
    },
    addFloatingSupervisorList: {
        loader: false,
        data: [],
        popup: { show: false, action: "", selectedRecord: {} }
    },
}

const supervisorReducer = createSlice({
    name: "supervisor",
    initialState,
    reducers: {
        setSupervisorNamePopup: (state, action) => {
            const currentState = current(state);
            state.supervisorName.popup = { ...currentState.supervisorName.popup, ...action.payload };
        },
        editSupervisorNamePopup: (state, action) => {
            state.supervisorName.popup = action.payload
        },
        setFloatingSupervisorOptionsPopup: (state, action) => {
            const currentState = current(state);
            state.floatingSupervisorOptionsPopup = { ...currentState.floatingSupervisorOptionsPopup, ...action.payload };
        },
        setAddFloatingSupervisorPopup: (state, action) => {
            const currentState = current(state);
            state.addFloatingSupervisorList.popup = { ...currentState.addFloatingSupervisorList.popup, ...action.payload };
        },
        setAddFloatingSupervisorLoader: (state, action) => {
            state.addFloatingSupervisorList.loader = action.payload;
        },
    }
});

export const supervisorActions = supervisorReducer.actions;

export default supervisorReducer.reducer;