import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    deputationPopup: { show: false, selectedRow: [], action: '' },
    loader: false,
    deputation: { data: [] }
}
export const deputationReducer = createSlice({
    name: 'deputation',
    initialState: initialState,
    reducers: {
        setLoader: (state, action) => {
            state.loader = action.payload;
        },
        setDeputationPopup: (state, action) => {
            state.deputationPopup = { ...state.deputationPopup, ...action.payload };
        },
        reSetDeputationPoup: (state) => {
            state.deputationPopup = initialState.deputationPopup;
        },
        setDeputationData: (state, action) => {
            state.deputation.data = action.payload;
        }
    },
});

export const deputationActions = deputationReducer.actions;
export default deputationReducer.reducer;