import { createSlice } from "@reduxjs/toolkit"

const initialState = {
    complianceRequestApprovePopup: { show: false, selectedRow: {} },
    approveAndRejectData: []
}

export const AddComplianceRequestReducer = createSlice({
    name: "AddComplianceRequest",
    initialState: initialState,
    reducers: {
        setComplianceRequestApprovePopup: (state, action) => {
            state.complianceRequestApprovePopup = action.payload;
        },
        setApproveAndRejectData: (state, action) => {
            state.approveAndRejectData = action.payload;
        },
    }
})
export const AddComplianceRequestAction = AddComplianceRequestReducer.actions;
export default AddComplianceRequestReducer.reducer;