import { createSlice, current } from '@reduxjs/toolkit';

const eventManagementInitialState = {
    loader: false,
    recordEvents: {
        eventTypes: [],
        participationLevel: [],
        participantName: [],
        recordEventPopup: { show: false, data: [], selectedRow: {}, type: "" },
        participants: {
            treeData: [],
            checkedKeys: [],
            expandedKeys: [],
            searchExpandedKeys: [],
            presentedValue: [],
            autoExpandParent: true
        },
        presenters: {
            treeData: [],
            checkedKeys: [],
            expandedKeys: [],
            originalTreeData: [],
            searchExpandedKeys: [],
            presentedValue: [],
            autoExpandParent: true
        }
    },
    calendarView: {
        date: new Date(),
        data: [],
        selectedYears: [],
        loader: false,
        view: "week"
    },
    tabularView: {
        data: [],
        filterParams: {},
        logViewPopup: { data: [], show: false }
    },
    selectedRecord: {},
    eventPopupView: { show: false, title: "", selectedRow: {}, presenter: [], participant: [] },
    generateSummary: { show: false, selectedParams: {}, employeeDetails: [], summary: [], summaryTable: [] },
    facilityReport: { data: [] },
    generateSummaryDocumentView: { show: false, selectedRow: {}, filterParams: {}, data: [] }
};

export const eventManagementReducer = createSlice({
    name: 'eventManagement',
    initialState: eventManagementInitialState,
    reducers: {
        setLoader: (state, action) => {
            state.loader = action.payload;
        },
        eventTypes: (state, action) => {
            state.recordEvents.eventTypes = action.payload;
        },
        setParticipationLevel: (state, action) => {
            state.recordEvents.participationLevel = action.payload;
        },
        setCalendarDate: (state, action) => {
            state.calendarView.date = action.payload;
        },
        setparticipantName: (state, action) => {
            state.recordEvents.participantName = action.payload;
        },
        setRecordEventPopup: (state, action) => {
            state.recordEvents.recordEventPopup = action.payload;
        },
        setViewEventsData: (state, action) => {
            state.calendarView.data = action.payload;
        },
        setparticipants: (state, action) => {
            const currentState = current(state);
            state.recordEvents.participants = { ...currentState.recordEvents.participants, ...action.payload };
        },
        setViewEventLoader: (state, action) => {
            state.calendarView.loader = action.payload;
        },
        setSelectedYear: (state, action) => {
            state.calendarView.selectedYears = action.payload;
        },
        setCalendarView: (state, action) => {
            state.calendarView.view = action.payload;
        },
        setTabularViewData: (state, action) => {
            state.tabularView.data = action.payload;
        },
        setSelectedRecord: (state, action) => {
            state.selectedRecord = action.payload;
        },
        setTabularViewFilterParams: (state, action) => {
            state.tabularView.filterParams = action.payload;
        },
        setEventPopupView: (state, action) => {
            const currentState = current(state);
            state.eventPopupView = { ...currentState.eventPopupView, ...action.payload };
        },
        setPresenters: (state, action) => {
            const currentState = current(state);
            state.recordEvents.presenters = { ...currentState.recordEvents.presenters, ...action.payload };
        },
        setGenerateSummary: (state, action) => {
            const currentState = current(state);
            state.generateSummary = { ...currentState.generateSummary, ...action.payload };
        },
        setFacilityReport: (state, action) => {
            state.facilityReport = action.payload;
        },
        setLogViewPopup: (state, action) => {
            const currentState = current(state);
            state.tabularView.logViewPopup = { ...currentState.tabularView.logViewPopup, ...action.payload };
        },
        setGenerateSummaryDocumentView: (state, action) => {
            const currentState = current(state);
            state.generateSummaryDocumentView = { ...currentState.generateSummaryDocumentView, ...action.payload };
        },
    },
});

export const eventManagementActions = eventManagementReducer.actions;

export default eventManagementReducer.reducer;