import { createSlice, current } from '@reduxjs/toolkit';


// eslint-disable-next-line react-refresh/only-export-components
const UserCredentials = {
    FName: "",
    LName: "",
    MName: "",
    Name: "",
    Email: "",
    Role: "",
    RoleID: "",
    UserID: 0,
    LocationID: 0,
    token: "",
    loader: false,
    transparentLoader: false,
    isLoginVisible: false,
    sidebarExpand: { isExpand: false, type: "" }
};

export const userReducer = createSlice({
    name: 'user',
    initialState: UserCredentials,
    reducers: {
        setUserDetails: (state, action) => {
            const currentState = current(state);
            return { ...currentState, ...action.payload };
        },
        updateLoader: (state, action) => {
            state.loader = action.payload
        },
        resetUserDetails: () => {
            return { ...UserCredentials };
        },
        updateTransparentLoader: (state, action) => {
            state.transparentLoader = action.payload;
        },
        setSidebarExpand: (state, action) => {
            state.sidebarExpand = action.payload;
        }
    }
});

export const userActions = userReducer.actions;

export default userReducer.reducer;