import { createSlice, current } from '@reduxjs/toolkit';

const loginInitialState = {
    employeeName: [],
    location: [],
    loginID: [],
    roles: [],
    status: [],
    employeeType: [],
    tableRecords: [],
    rowData: {},
    action: "Add",
    loader: false,
    selectedRow: {}
};

export const loginReducer = createSlice({
    name: 'login',
    initialState: loginInitialState,
    reducers: {
        setTableRecords: (state, action) => {
            state.tableRecords = action.payload;
        },
        setUserDetails: (state, action) => {
            const currentState = current(state);
            return { ...currentState, action: "Edit", rowData: action.payload }
        },
        setEmployeeNameLists: (state, action) => {
            state.employeeName = action.payload;
        },
        setLocationLists: (state, action) => {
            state.location = action.payload;
        },
        setLoginIDLists: (state, action) => {
            state.loginID = action.payload;
        },
        setRoleLists: (state, action) => {
            state.roles = action.payload;
        },
        setStatusLists: (state, action) => {
            state.status = action.payload;
        },
        setLoginLoader: (state, action) => {
            state.loader = action.payload;
        },
        setEmployeeType: (state, action) => {
            state.employeeType = action.payload;
        },
        resetUserDetails: (state) => {
            const currentState = current(state);
            return { ...currentState, action: "Add", rowData: {} };
        },
        setSelectedRow: (state, action) => {
            state.selectedRow = action.payload;
        }
    },
});

export const loginActions = loginReducer.actions;

export default loginReducer.reducer;