import { createSlice, current } from '@reduxjs/toolkit';

const initialState = {
    validateLeaveBalancePopup: { show: false, popupData: [] },
    loader: false,
    uploadAuditPopup: { show: false, loader: false },
    attendanceReportView: { show: false, data: [], columns: [], type: {}, header: "", excelParams: {} },
    payrollDetail: { data: [], accordionData: [] },
    uploadAuditor: { data: [] }
}
export const attendancePayrollReducer = createSlice({
    name: 'attendancePayroll',
    initialState: initialState,
    reducers: {
        setValidateLeaveBalance: (state, action) => {
            state.validateLeaveBalancePopup = action.payload;
        },
        setLoader: (state, action) => {
            state.loader = action.payload;
        },
        setUploadAuditorDocumentPopup: (state, action) => {
            state.uploadAuditPopup = action.payload;
        },
        setUploadAuditorDocumentLoader: (state, action) => {
            state.uploadAuditPopup.loader = action.payload;
        },
        setAttendanceReportView: (state, action) => {
            state.attendanceReportView = action.payload;
        },
        setPayrollDetails: (state, action) => {
            const currentState = current(state);
            state.payrollDetail = { ...currentState.payrollDetail, ...action.payload }
        },
        setUploadAuditor: (state, action) => {
            state.uploadAuditor = action.payload
        }
    },
});

export const attendancePayrollActions = attendancePayrollReducer.actions;
export default attendancePayrollReducer.reducer;