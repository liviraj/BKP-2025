import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    loader: false,
    departmentNamePopup: { show: false, selectedRow: [], action: '' },
    departmentName: { data: [] },
    departmentSupervisor: {
        data: [],
        departmentDetails: [],
        departmentSupervisorPopup: { show: false, selectedRow: [], action: '' }
    }
}

const departmentReducer = createSlice({
    name: "department",
    initialState,
    reducers: {
        setLoader: (state, action) => {
            state.loader = action.payload;
        },
        setDepartmentName: (state, action) => {
            state.departmentName.data = action.payload;
        },
        setDepartmentNamePopup: (state, action) => {
            state.departmentNamePopup = { ...state.departmentNamePopup, ...action.payload };
        },
        reSetDepartmentPoup: (state) => {
            state.departmentNamePopup = initialState.departmentNamePopup;
        },
        setDepartmentSupervisor: (state, action) => {
            state.departmentSupervisor.data = action.payload;
        },
        setSupervisorPopup: (state, action) => {
            state.departmentSupervisor.departmentSupervisorPopup = { ...state.departmentSupervisor.departmentSupervisorPopup, ...action.payload }
        },
        setDepartmentDetails: (state, action) => {
            state.departmentSupervisor.departmentDetails = { ...state.departmentSupervisor.departmentDetails, ...action.payload }
        }
    }
});

export const departmentActions = departmentReducer.actions;

export default departmentReducer.reducer;