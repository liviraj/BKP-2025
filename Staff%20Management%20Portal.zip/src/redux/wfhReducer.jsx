import { createSlice, current } from "@reduxjs/toolkit";

const wfhInitalState = {
    loader: false,
    wfhRequest: {
        data: [],
        leaveBalance: {}
    },
    approveRejectRequest: { data: [] },
    addWFHRequest: { show: false, data: [], type: '' },
    approvalViewPopup: {
        show: false,
        selectedRecord: {},
        data: [],
        statusType: ""
    },
    wfhHistoryPopup: {
        data: [],
        show: false,
        selectedRecord: {},
        status: ""
    },
}


export const wfhReducer = createSlice({
    name: 'wfhRequest',
    initialState: wfhInitalState,
    reducers: {
        setLoader: (state, action) => {
            state.loader = action.payload;
        },
        setWFHRequestData: (state, action) => {
            state.wfhRequest = action.payload;
        },
        setApproveRejectRequestData: (state, action) => {
            state.approveRejectRequest.data = action.payload;
        },
        addWFHRequest: (state, action) => {
            const currentState = current(state);
            state.addWFHRequest = { ...currentState.addWFHRequest, ...action.payload }
        },
        setApprovalViewPopup: (state, action) => {
            const currentState = current(state);
            state.approvalViewPopup = { ...currentState.approvalViewPopup, ...action.payload }
        },
        setWFHHistoryPopup: (state, action) => {
            const currentState = current(state);
            state.wfhHistoryPopup = { ...currentState.wfhHistoryPopup, ...action.payload }
        },
        setWFHLeaveBalance: (state, action) => {
            state.wfhRequest.leaveBalance = action.payload
        }
    }
})

export const wfhActions = wfhReducer.actions;

export default wfhReducer.reducer;