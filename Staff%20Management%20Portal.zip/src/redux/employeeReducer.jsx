import { createSlice } from '@reduxjs/toolkit';

const employeeInitialState = {
    employeeName: [],
    designation: [],
    department: [],
    location: [],
    employeeStatus: [],
    employeeType: [],
    clinicalUser: [],
    tableRecords: [],
    rowData: {},
    loader: false,
    employeeDetailView: { show: false, data: {} },
    employeeModule: { action: "Add", data: {}, personal: {}, communication: {}, work: {}, isDisable: false, personalDetails: {}, workDetails: {} },
    grade: [],
    nysComplianceCategory: [],
    nysCompliancePeriod: [],
    trainingCategory: [],
    documentType: []
};

export const employeeReducer = createSlice({
    name: 'employee',
    initialState: employeeInitialState,
    reducers: {
        setTableRecords: (state, action) => {
            state.tableRecords = action.payload;
        },
        setEmployeeNameLists: (state, action) => {
            state.employeeName = action.payload;
        },
        setDesignationLists: (state, action) => {
            state.designation = action.payload;
        },
        setDepartmentLists: (state, action) => {
            state.department = action.payload;
        },
        setLocationLists: (state, action) => {
            state.location = action.payload;
        },
        setEmployeeStatusLists: (state, action) => {
            state.employeeStatus = action.payload;
        },
        setEmployeeTypeLists: (state, action) => {
            state.employeeType = action.payload;
        },
        setClinicalUserLists: (state, action) => {
            state.clinicalUser = action.payload;
        },
        setEmployeeLoader: (state, action) => {
            state.loader = action.payload;
        },
        setEmployeeDetailView: (state, action) => {
            state.employeeDetailView = action.payload;
        },
        setEmployeeModule: (state, action) => {
            state.employeeModule = { ...action.payload };
        },
        setGradeList: (state, action) => {
            state.grade = action.payload;
        },
        setNysComplianceCategory: (state, action) => {
            state.nysComplianceCategory = action.payload;
        },
        setNysCompliancePeriod: (state, action) => {
            state.nysCompliancePeriod = action.payload;
        },
        setTrainingCategory: (state, action) => {
            state.trainingCategory = action.payload;
        },
        setDocumentType: (state, action) => {
            state.documentType = action.payload;
        }
    },
});

export const employeeActions = employeeReducer.actions;

export default employeeReducer.reducer;

