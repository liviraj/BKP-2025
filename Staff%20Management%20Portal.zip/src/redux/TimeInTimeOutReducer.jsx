import { createSlice, current } from "@reduxjs/toolkit";

const initialState = {
    timeInTimeOutPopup: { show: false, action: "Edit", selectedRow: {} },
    addTimeInTimeOutPopup: { show: false },
    viewMissOutPunches: { show: false, selectedRow: {}, data: {} },
    timeInOutUploadDocument: { show: false, data: [], employeeCodes: [], isValidRecord: true },
}

const timeInTimeOutReducer = createSlice({
    name: "timeInTimeOut",
    initialState,
    reducers: {
        setTimeInTimeOutPopup: (state, action) => {
            const currentState = current(state);
            state.timeInTimeOutPopup = { ...currentState.timeInTimeOutPopup, ...action.payload };
        },
        addTimeInTimeOutPopup: (state, action) => {
            const currentState = current(state);
            state.addTimeInTimeOutPopup = { ...currentState.addTimeInTimeOutPopup, ...action.payload };
        },
        viewMissOutPunches: (state, action) => {
            const currentState = current(state);
            state.viewMissOutPunches = { ...currentState.viewMissOutPunches, ...action.payload };
        },
        setTimeInOutUploadDocument: (state, action) => {
            const currentState = current(state);
            state.timeInOutUploadDocument = { ...currentState.timeInOutUploadDocument, ...action.payload };
        }
    }
});

export const timeInTimeOutActions = timeInTimeOutReducer.actions;

export default timeInTimeOutReducer.reducer;