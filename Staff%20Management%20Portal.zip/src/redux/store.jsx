import { configureStore } from '@reduxjs/toolkit';
import userReducer from './userReducer';
import { composeWithDevTools } from 'redux-devtools-extension';
import employeeReducer from './employeeReducer';
import loginReducer from './loginReducer';
import loginResponseReducer from './loginResponseReducer';
import complianceReportReducer from './complianceReportReducer';
import leaveManagementReducer from './leaveManagementReducer';
import sickLeaveReducer from './sickLeaveReducer';
import eventManagementReducer from './eventManagementReducer';
import myRequestReducer from './myRequestReducer';
import permissionReducer from './permissionReducer';
import holidayReducer from './holidayReducer';
import departmentReducer from './departmentReducer';
import attendancePayrollReducer from './AttendancePayrollReducer';
import supervisorReducer from './supervisorReducer';
import designationReducer from './DesignationReducer';
import deputationReducer from './DeputationReducer';
import employeeDashboardReducer from './employeeDashboardReducer';
import wfhReducer from './wfhReducer';
import timeInTimeOutReducer from './TimeInTimeOutReducer';
import ComplianceAgreementReducer from './ComplianceAgreementReducer';
import AddComplianceRequestReducer from './AddComplianceRequest';

export const store = configureStore({
  reducer: {
    user: userReducer,
    employee: employeeReducer,
    login: loginReducer,
    loginResponse: loginResponseReducer,
    complianceReport: complianceReportReducer,
    leaveManagement: leaveManagementReducer,
    sickLeave: sickLeaveReducer,
    eventManagement: eventManagementReducer,
    myRequest: myRequestReducer,
    permission: permissionReducer,
    holiday: holidayReducer,
    attendancePayroll: attendancePayrollReducer,
    designation: designationReducer,
    department: departmentReducer,
    supervisor: supervisorReducer,
    deputation: deputationReducer,
    employeeDashboard: employeeDashboardReducer,
    wfhRequest: wfhReducer,
    timeInTimeOut: timeInTimeOutReducer,
    complianceAgreement: ComplianceAgreementReducer,
    AddComplianceRequest: AddComplianceRequestReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false,
    })
}, composeWithDevTools());
