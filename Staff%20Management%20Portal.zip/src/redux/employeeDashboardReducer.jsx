import { createSlice } from "@reduxjs/toolkit"

const employeeinitialState = {
    birthDayDetails: [],
    employeeLeaveDetails: [],
    employeeDashboardDetails: [],
    leaveAndPermissionHistory: []
}

export const employeeDashboardReducer = createSlice({
    name: 'employeeDashboard',
    initialState: employeeinitialState,
    reducers: {
        getBirthDayDeatils: (state, action) => {
            state.birthDayDetails = action.payload
        },
        getEmployeeLeaveDetails: (state, action) => {
            state.employeeLeaveDetails = action.payload
        },
        getEmployeeDashboardDetails: (state, action) => {
            state.employeeDashboardDetails = action.payload
        },
        getLeaveAndPermissionHistory: (state, action) => {
            state.leaveAndPermissionHistory = action.payload
        }
    }
})
export const employeeDashboardActions = employeeDashboardReducer.actions

export default employeeDashboardReducer.reducer;