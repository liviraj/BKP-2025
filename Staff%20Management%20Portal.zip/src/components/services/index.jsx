import axios from "axios";
import { userReducerState } from "../helper";
import { status } from "../Constants";

const apiURL = import.meta.env.VITE_API_URL;
export const employeeServices = {
    //                                ------------------   Employee Detail Screen  -------------------
    ClinicalUsers: () => {
        return axios.get(`${apiURL}/filter/clinicalHandler`, getRequestOption());
    },
    EmployeeLocation: () => {
        return axios.get(`${apiURL}/filter/location`, getRequestOption());
    },
    EmployeeDepartment: () => {
        return axios.get(`${apiURL}/filter/section`, getRequestOption());
    },
    EmployeeType: () => {
        return axios.get(`${apiURL}/filter/employmentType`, getRequestOption());
    },
    EmployeeStatus: () => {
        return axios.get(`${apiURL}/filter/employeeStatus`, getRequestOption());
    },
    EmployeeDesignation: () => {
        return axios.get(`${apiURL}/filter/designation`, getRequestOption());
    },
    EmployeeName: () => {
        return axios.get(`${apiURL}/filter/employeeName`, getRequestOption());
    },
    getEmployeeDashboardinfo: (id) => {
        return axios.get(`${apiURL}/dashboard/employee-info/${id}`, getRequestOption());
    },
    getEmployeeBirthDayDetails: (id) => {
        return axios.get(`${apiURL}/dashboard/birthday-details/${id}`, getRequestOption());
    },
    getEmployeeLeaveDetails: (id) => {
        return axios.get(`${apiURL}/dashboard/leave-details/${id}`, getRequestOption());
    },
    getEmployeeLeavePermissionHistory: (params) => {
        return axios.get(`${apiURL}/dashboard/employee/requestHistory${Object.keys(params).length > 0 && "?" + Object.entries(params).join('&').replaceAll(',', '=')}`, getRequestOption());
    },
    getEmpChartData: (id) => {
        return axios.get(`${apiURL}/dashboard/org/${id}`, getRequestOption());
    },
    TableRecords: (employeeState) => {
        return axios.get(`${apiURL}/employee${Object.keys(employeeState).length > 0 && "?" + Object.entries(employeeState).join('&').replaceAll(',', '=')}`, getRequestOption());
    },
    EmployeeDetails: (employeeId) => {
        return axios.get(`${apiURL}/employeeDetails/${employeeId}`, getRequestOption());
    },
    getImageData: (type, imageId) => {
        return axios.get(`${apiURL}/employeeDetails?employeeId=${imageId}&type=${type}`, getRequestOption());
    },
    getEmployeeDocument: (type, documentId) => {
        return axios.get(`${apiURL}/${type}/${documentId}`, getRequestOption());
    },
    getCompanyLocation: () => {
        return axios.get(`${apiURL}/filter/location`, getRequestOption());
    },
    getUserRoleService: () => {
        return axios.get(`${apiURL}/filter/role`, getRequestOption());
    },
    //                                ------------------   Employee Personal Screen  -------------------
    createEmployee__personal: (loginId, data) => {
        return axios.post(`${apiURL}/employee/${loginId}`, data, postRequestOption());
    },
    updateEmployee_personal: (employeeId, data) => {
        return axios.put(`${apiURL}/employee/${employeeId}`, data, putRequestOption());
    },
    getEmployee_personal: (employeeId) => {
        return axios.get(`${apiURL}/employee/${employeeId}`, getRequestOption());
    },
    //                                ------------------   Employee Work Screen  -------------------
    getManagerLists: () => {
        return axios.get(`${apiURL}/filter/employeeName`, getRequestOption());
    },
    getgradeLists: () => {
        return axios.get(`${apiURL}/work/gradeName`, getRequestOption());
    },
    getEmployee_work_details: (employeeId) => {
        return axios.get(`${apiURL}/work/${employeeId}`, getRequestOption());
    },
    createEmployee_work: (loginId, data) => {
        return axios.post(`${apiURL}/work/${loginId}`, data, postRequestOption());
    },
    updateEmployee_work: (employeeId, data) => {
        return axios.put(`${apiURL}/work/${employeeId}`, data, putRequestOption());
    },
    //                                ------------------   Employee Continuous Education  -------------------
    getContinuousEducation: (employeeId) => {
        return axios.get(`${apiURL}/continousEducation/details/${employeeId}`, getRequestOption());
    },
    createContinuousEducationDetails: (data) => {
        return axios.post(`${apiURL}/continousEducation`, data, postRequestOption());
    },
    updateEducationDetails: (continuousEducationId, data) => {
        return axios.put(`${apiURL}/continousEducation/${continuousEducationId}`, data, putRequestOption());
    },
    deleteEducationDetails: (continuousEducationId, data) => {
        return axios.delete(`${apiURL}/continousEducation/${continuousEducationId}`, { data, ...deleteRequestOption() });
    },
    //                                ------------------   Employee Work History  -------------------
    createWorkHistory: (data) => {
        return axios.post(`${apiURL}/workHistory`, data, postRequestOption());
    },
    getWorkHistory: (workHistoryId) => {
        return axios.get(`${apiURL}/workHistory/${workHistoryId}`, getRequestOption());
    },
    getWorkHistoryDetails: (employeeID) => {
        return axios.get(`${apiURL}/workHistory/details/${employeeID}`, getRequestOption());
    },
    updateWorkHistoryDetails: (workHistoryId, data) => {
        return axios.put(`${apiURL}/workHistory/${workHistoryId}`, data, putRequestOption()); // workHistoryId
    },
    deleteWorkHistory: (continuousworkHistoryId, data) => {
        return axios.delete(`${apiURL}/workHistory/${continuousworkHistoryId}`, { data, ...deleteRequestOption() });
    },
    //                                ------------------   Employee NYS Compliance  -------------------
    getComplianceCategory: () => {
        return axios.get(`${apiURL}/compliance/category`, getRequestOption());
    },
    getCompliancePeriod: () => {
        return axios.get(`${apiURL}/compliance/period`, getRequestOption());
    },
    getNysComplianceDetails: (employeeId) => {
        return axios.get(`${apiURL}/compliance/details/${employeeId}`, getRequestOption());
    },
    createNysComplianceRecords: (data) => {
        return axios.post(`${apiURL}/compliance`, data, postRequestOption());
    },
    updateNysComplianceRecords: (id, data) => {
        return axios.put(`${apiURL}/compliance/${id}`, data, putRequestOption());
    },
    deleteNysComplianceRecord: (id, data) => {
        return axios.delete(`${apiURL}/compliance/${id}`, { data, ...deleteRequestOption() });
    },
    //                                ------------------   Employee Training Screen  -------------------
    getEmployeeTrainingDetails: (employeeId) => {
        return axios.get(`${apiURL}/training/details/${employeeId}`, getRequestOption());
    },
    createTrainingRecords: (data) => {
        return axios.post(`${apiURL}/training`, data, postRequestOption());
    },
    updateTrainingRecords: (id, data) => {
        return axios.put(`${apiURL}/training/${id}`, data, putRequestOption());
    },
    getTrainingCategory: () => {
        return axios.get(`${apiURL}/training/category`, getRequestOption());
    },
    deleteTrainingRecord: (id, data) => {
        return axios.delete(`${apiURL}/training/${id}`, { data, ...deleteRequestOption() });
    },
    //                                ------------------   Employee Hr Documents  -------------------
    getHrDocumentDetails: (employeeId) => {
        return axios.get(`${apiURL}/hrDocument/details/${employeeId}`, getRequestOption());
    },
    createHrDocumentRecords: (data) => {
        return axios.post(`${apiURL}/hrDocument`, data, postRequestOption());
    },
    updateHrDocumentRecords: (hrDocumentId, data) => {
        return axios.put(`${apiURL}/hrDocument/${hrDocumentId}`, data, putRequestOption());
    },
    hrDocumentType: () => {
        return axios.get(`${apiURL}/hrDocument/type`, getRequestOption());
    },
    deleteHrDocumentRecord: (id, data) => {
        return axios.delete(`${apiURL}/hrDocument/${id}`, { data, ...deleteRequestOption() });
    },

}

export const loginService = {
    createUser: (data, isValidated) => {
        return axios.post(`${apiURL}/users?isNewUser=${isValidated}`, data, postRequestOption());
    },
    editUser: (loginId, data) => {
        return axios.put(`${apiURL}/users/${loginId}`, data, putRequestOption());
    },
    getUserDetails: (loginId) => {
        return axios.get(`${apiURL}/users/${loginId}`, getRequestOption());
    },
    UserInformation: () => {
        return axios.get(`${apiURL}/users/login`, getRequestOption());
    },
    TableRecords: (loginState) => {
        return axios.get(`${apiURL}/users${Object.keys(loginState).length > 0 && "?" + Object.entries(loginState).join('&').replaceAll(',', '=')}`, getRequestOption());
    },
    LoginIdLists: () => {
        return axios.get(`${apiURL}/filter/mappingStatus`, getRequestOption());
    },
    Roles: () => {
        return axios.get(`${apiURL}/filter/role`, getRequestOption());
    },
    EmployeeName: () => {
        return axios.get(`${apiURL}/filter/loginName`, getRequestOption());
    },
    deleteLoginRecord: (loginId, data) => {
        return axios.delete(`${apiURL}/users/${loginId}`, { data, ...deleteRequestOption() });
    },
    //                                ------------------   Add Employee API  -------------------
    getEmployeeDetails: (loginId) => {
        return axios.get(`${apiURL}/employee/employeeCode/${loginId}`, getRequestOption());
    }
}


export const communicationService = {
    createCommunication: (data) => {
        return axios.post(`${apiURL}/communication`, data, postRequestOption());
    },
    editCommunication: (data, empCmmId) => {
        return axios.put(`${apiURL}/communication/${empCmmId}`, data, putRequestOption());
    },
    getCommunicationInfo: (empId) => {
        return axios.get(`${apiURL}/communication/${empId}`, getRequestOption());
    },
    getEmployeeCodeAndDetails: (loginId) => {
        return axios.get(`${apiURL}/employee/${loginId}`, getRequestOption());
    }
}

export const qualificationService = {
    getQualificationList: () => {
        return axios.get(`${apiURL}/qualification`, getRequestOption());
    },
    saveQualification: (data) => {
        return axios.post(`${apiURL}/qualification`, data, postRequestOption());
    },
    putQualification: (data, QualifId) => {
        return axios.put(`${apiURL}/qualification/${QualifId}`, data, putRequestOption());
    },
    getEducationList: (qualifId) => {
        return axios.get(`${apiURL}/qualification/${qualifId}`, getRequestOption());
    },
    getQualificationDetailsByEmpId: (empId) => {
        return axios.get(`${apiURL}/qualification/details/${empId}`, getRequestOption())
    },
    getQualificationDetailsByQualfId: (qualfId) => {
        return axios.get(`${apiURL}/qualification/${qualfId}`, getRequestOption());
    },
    getFileByQualfId: (qualfId) => {
        return axios.get(`${apiURL}/employeeDetails/qualificationCertificate/${qualfId}`, getRequestOption());
    },
    deleteQualificationDetails: (qualfId, data) => {
        return axios.delete(`${apiURL}/qualification/${qualfId}`, { data, ...deleteRequestOption() });
    }
}

export const generalService = {
    uploadDocument: (file) => {
        return axios.post(`${apiURL}/filter/fileConversion`, file, postRequestOptionForFileUpload());
    }
}

export const reportService = {
    complianceRecords: (complianceState) => {
        return axios.get(`${apiURL}/complianceReports/compliance${Object.keys(complianceState).length > 0 ? "?" + Object.entries(complianceState).join('&').replaceAll(',', '=') : ""}`, getRequestOption());
    },
    employeeType: () => {
        return axios.get(`${apiURL}/complianceReports/employeeType`, getRequestOption());
    },
    complianceCertificate: (selectedRecord) => {
        return axios.get(`${apiURL}/complianceReports${Object.keys(selectedRecord).length > 0 ? "?" + Object.entries(selectedRecord).join('&').replaceAll(',', '=') : ""}`, getRequestOption());
    },
    complianceSendMail: (data) => {
        return axios.post(`${apiURL}/complianceReports/emailNotify`, data, postRequestOption());
    },
    complianceEmailTemplate: (params) => {
        return axios.get(`${apiURL}/complianceReports/expiry-email-template${Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', '=') : ""}`, getRequestOption())
    },
    leaveReport: {
        totalHoursReport: (selectedData) => {
            return axios.get(`${apiURL}/attendance/timingReport${Object.keys(selectedData).length > 0 ? "?" + Object.entries(selectedData).join('&').replaceAll(',', '=') : ""}`, getRequestOption())
        },
        employeeAttendanceReport: (selectedData) => {
            return axios.get(`${apiURL}/attendance/reportsByPeriod${Object.keys(selectedData).length > 0 ? "?" + Object.entries(selectedData).join('&').replaceAll(',', '=') : ""}`, getRequestOption())
        },
        leaveAvailedReport: (selectedData) => {
            return axios.get(`${apiURL}/attendance/monthlyReport${Object.keys(selectedData).length > 0 ? "?" + Object.entries(selectedData).join('&').replaceAll(',', '=') : ""}`, getRequestOption());
        }
    }
}

export const leaveManagementService = {
    leaveHistory: {
        getLeaveHistoryData: (params) => {
            return axios.get(`${apiURL}/leave/history${Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', '=') : ""}`, getRequestOption());
        },
        editLeaveHistoryData: (requestId, data, isLossOfPay) => {
            return axios.put(`${apiURL}/leave/request/${requestId}?isLossOfPay=${isLossOfPay}`, data, putRequestOption())
        },
        cancelLeaveHistoryData: (filterRecords) => {
            return axios.post(`${apiURL}/leaveManagement/cancelRequest`, filterRecords, postRequestOption())
        }
    },
    leaveRequest: {
        addLeaveRequest: (userId, data, isLossOfPay) => {
            return axios.post(`${apiURL}/leave/request/${userId}?isLossOfPay=${isLossOfPay}`, data, postRequestOption());
        },
        getLeaveRequestType: (locationId) => {
            return axios.get(`${apiURL}/leave/type/${locationId}`, getRequestOption());
        },
        getLeaveBalance: (loginId) => {
            return axios.get(`${apiURL}/leave/balance/${loginId}`, getRequestOption());
        }
    },
    leaveRequestQueue: {
        getLeaveRequestQueue: (params) => {
            return axios.get(`${apiURL}/leaveManagement${Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', '=') : ""}`, getRequestOption());
        },
        postLeaveRequestApproval: (data) => {
            return axios.get(`${apiURL}/leaveManagement`, data, getRequestOption());
        },
        leaveReqDetails: (reqId, statusVal) => {
            const cancelRequestPath = statusVal === status.cancel ? `cancelRequest/${reqId}` : reqId;
            return axios.get(`${apiURL}/leaveManagement/${cancelRequestPath}`, getRequestOption());
        },
        ackLeaveRequest: (data, isLopFlag) => {
            return axios.post(`${apiURL}/leaveManagement?isLossOfPay=${isLopFlag}`, data, postRequestOption());
        }
    },
    leaveLedger: {
        getLeaveLedger: (selectedRecord) => {
            return axios.get(`${apiURL}/leave/ledger/filter${Object.keys(selectedRecord).length > 0 ? "?" + Object.entries(selectedRecord).join('&').replaceAll(',', '=') : ""}`, getRequestOption());
        },
        updateLeaveLedger: (data, leaveDetailID) => {
            return axios.put(`${apiURL}/leave/ledger/${leaveDetailID}`, data, putRequestOption());
        },
        deleteLeaveLedger: (leaveDetailID, data) => {
            return axios.delete(`${apiURL}/leave/ledger/${leaveDetailID}`, { data, ...deleteRequestOption() });
        },
    },
    leaveStatus: {
        getLeaveStatus: () => {
            return axios.get(`${apiURL}/filter/leaveStatus`, getRequestOption())
        }
    },
    getPayroll: () => {
        return axios.get(`${apiURL}/filter/payRoll`, getRequestOption());
    }
}

export const sickLeaveService = {
    getBalanceSummary: (params) => {
        return axios.get(`${apiURL}/leave/ledger/balance${Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', '=') : ""}`, getRequestOption());
    },
    getSummaryDetails: (params) => {
        return axios.get(`${apiURL}/leave/ledger/summary${Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', '=') : ""}`, getRequestOption());
    },
    getLeaveLedger: (params) => {
        return axios.get(`${apiURL}/sickLeave/ledger${Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', '=') : ""}`, getRequestOption());
    },
    deleteLeaveLedger: (leaveDetailID) => {
        return axios.delete(`${apiURL}/sickLeave/ledger/${leaveDetailID}`, deleteRequestOption());
    },
    updateLeaveLedger: (data, leaveDetailId) => {
        return axios.put(`${apiURL}/leave/ledger/${leaveDetailId}`, data, putRequestOption());
    },
    addLeaveLedger: (data) => {
        return axios.post(`${apiURL}/leave/ledger`, data, postRequestOption());
    },
}

export const eventManagementService = {
    recordEvents: {
        getAllEventTypes: () => {
            return axios.get(`${apiURL}/events/types`, getRequestOption())
        },
        getAllParticipationLevel: () => {
            return axios.get(`${apiURL}/events/participationLevel`, getRequestOption())
        },
        getEventEmployeeName: () => {
            return axios.get(`${apiURL}/events/employeeName`, getRequestOption())
        },
        saveEvent: (data) => {
            return axios.post(`${apiURL}/events`, data, postRequestOption())
        },
        getEditEvent: (id) => {
            return axios.get(`${apiURL}/events/${id}`, getRequestOption())
        },
        editEvent: (id, data) => {
            return axios.put(`${apiURL}/events/${id}`, data, putRequestOption())
        }
    },
    viewEvents: {
        getViewEvents: (params) => {
            return axios.get(`${apiURL}/events/viewEvents${Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', '=') : ""}`, getRequestOption());
        },
        deleteEvent: (params) => {
            return axios.delete(`${apiURL}/events`, { data: params, ...deleteRequestOption() });
        },
        LogViewEvents: (id) => {
            return axios.get(`${apiURL}/events/log/${id}`, getRequestOption());
        }
    },
    reportEvents: {
        getEventReports: (params) => {
            return axios.get(`${apiURL}/events/reports${Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', '=') : ""}`, getRequestOption());
        },
        getDocumentViewforGenerateSummary: (params) => {
            return axios.get(`${apiURL}/events/reports/summary${Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', '=') : ""}`, getRequestOption());
        },
    },
    facilityPersonalReport: {
        getFacilityReport: () => {
            return axios.get(`${apiURL}/events/report/facilityPersonnel`, getRequestOption())
        }
    }
}

export const myRequestService = {
    getRequestType: () => {
        return axios.get(`${apiURL}/requests`, getRequestOption());
    },
    addRequest: (params) => {
        return axios.post(`${apiURL}/requests`, params, postRequestOption());
    },
    getRequest: (params) => {
        return axios.get(`${apiURL}/requests/details${Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', '=') : ""}`, getRequestOption());
    },
    getRequestDetails: (requestId) => {
        return axios.get(`${apiURL}/requests/details/${requestId}`, getRequestOption())
    },
    editRequest: (requestId, params) => {
        return axios.put(`${apiURL}/requests/${requestId}`, params, putRequestOption());
    },
    typeOfStatus: () => {
        return axios.get(`${apiURL}/filter/requestStatus`, getRequestOption());
    },
    approveRequest: (data) => {
        return axios.post(`${apiURL}/requests/approve`, data, postRequestOption());
    },
    trackingRequest: {
        getTrackingRequest: (params) => {
            return axios.get(`${apiURL}/requests/approved/details${Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', '=') : ""}`, getRequestOption());
        },
        getAssigneeList: () => {
            return axios.get(`${apiURL}/requests/assign`, getRequestOption());
        },
        updateTrackingRequestDetails: (id, data) => {
            return axios.put(`${apiURL}/requests/tracking/${id}`, data, putRequestOption());
        }
    },
    getTrackingStatus: () => {
        return axios.get(`${apiURL}/requests/status`, getRequestOption());
    }
}

export const permissionService = {
    permissionType: () => {
        return axios.get(`${apiURL}/permissions/types`, getRequestOption())
    },
    permissionHistory: (params) => {
        return axios.get(`${apiURL}/permissions/history${Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', '=') : ""}`, getRequestOption())
    },
    addpermission: (data) => {
        return axios.post(`${apiURL}/permissions`, data, postRequestOption())
    },
    editPermission: (id, data) => {
        return axios.put(`${apiURL}/permissions/${id}`, data, putRequestOption())
    },
    getCurrentPermission: (id,) => {
        return axios.get(`${apiURL}/permissions/balance/${id}`, getRequestOption())
    },
    permissionApproveOrReject: (data) => {
        return axios.post(`${apiURL}/permissions/requestQueue`, data, postRequestOption())
    },
    getPermissionDetail: (params) => {
        return axios.get(`${apiURL}/permissions/requestDetail${Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', '=') : ""}`, getRequestOption())
    },
    viewPermissionHistory: (params) => {
        return axios.get(`${apiURL}/permissions/history${Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', '=') : ""}`, getRequestOption())
    }
}

export const holidayService = {
    getHolidayDetailsForRestrictions: (params) => {
        return axios.get(`${apiURL}/filter/holiday${Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', "=") : ""}`, getRequestOption())
    },
    setFloatingHolidayPopup: {
        saveFloatingHolidayDetails: (data) => {
            return axios.put(`${apiURL}/floating/holiday`, data, putRequestOption());
        }
    },
    holidayList: {
        getHolidayList: (params) => {
            return axios.get(`${apiURL}/holiday/list${Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', "=") : ""}`, getRequestOption());
        },
        getFloatingHolidayDetails: (params) => {
            return axios.get(`${apiURL}/floating/holiday/list${Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', "=") : ""}`, getRequestOption())
        }
    },
    holidayNameList: {
        getHolidayNameList: (params) => {
            return axios.get(`${apiURL}/holiday/master${params && Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', "=") : ""}`, getRequestOption());
        },
        addHolidayNameList: (data) => {
            return axios.post(`${apiURL}/holiday/master`, data, postRequestOption());
        },
        editHolidayNameList: (holidayId, data) => {
            return axios.put(`${apiURL}/holiday/master/${holidayId}`, data, putRequestOption());
        },
        deleteHolidayNameList: (holidayId, data) => {
            return axios.delete(`${apiURL}/holiday/master/${holidayId}`, { data, ...deleteRequestOption() });
        },
    },
    addHolidays: {
        getHolidayList: (params) => {
            return axios.get(`${apiURL}/holiday/list${params && Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', "=") : ""}`, getRequestOption());
        },
        addHoliday: (data) => {
            return axios.post(`${apiURL}/holiday`, data, postRequestOption());
        },
        editHoliday: (id, data) => {
            return axios.put(`${apiURL}/holiday/${id}`, data, putRequestOption());
        },
        deleteHoliday: (id, data) => {
            return axios.delete(`${apiURL}/holiday/${id}`, { data, ...deleteRequestOption() });
        },
        getalternateHolidays: (id, year) => {
            return axios.get(`${apiURL}/holiday/floating/list?holidayId=${id}&year=${year}`, getRequestOption());
        },
        postUsFederalHoliday: (data, year) => {
            return axios.post(`${apiURL}/holiday/usFederal-holiday/${year}`, data, postRequestOption());
        }
    },
    addFloatingHolidays: {
        getFloatingHolidayRecords: (params) => {
            return axios.get(`${apiURL}/floating/holiday/list${params && Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', "=") : ""}`, getRequestOption());
        }
    },
    floatingHolidayList: {
        getYearlyFloatingHolidays: (year) => {
            return axios.get(`${apiURL}/floating/holiday/${year}`, getRequestOption());
        },
        getFloatingHolidayDetails: (params) => {
            return axios.get(`${apiURL}/floating/holiday${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption());
        }
    }
}

export const payrollService = {
    employeePayrollDetail: (params) => {
        return axios.get(`${apiURL}/payroll${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption())
    },
    payrollUpload: (data) => {
        return axios.post(`${apiURL}/payroll/upload`, data, postRequestOption());
    },
    uploadAuditor: (params) => {
        return axios.get(`${apiURL}/payroll/details${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption())
    },
    editUploadAuditor: (id, data) => {
        return axios.put(`${apiURL}/payroll/${id}`, data, putRequestOption())
    }
}

export const deputationService = {
    getDeputationDetails: (params) => {
        return axios.get(`${apiURL}/deputation${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption());
    },
    deleteDeputationDetails: (id, data) => {
        return axios.delete(`${apiURL}/deputation/${id}`, { data, ...deleteRequestOption() });
    },
    addDeputation: (params) => {
        return axios.post(`${apiURL}/deputation`, params, postRequestOption());
    },
    editDeputation: (id, params) => {
        return axios.put(`${apiURL}/deputation/${id}`, params, putRequestOption());
    },
    getEditDeputationDetail: (id) => {
        return axios.get(`${apiURL}/deputation/${id}`, getRequestOption());
    }
}

export const WFHService = {
    ApproveRejectRequest: {
        getEmployeeWFHHistory: (params) => {
            return axios.get(`${apiURL}/workRequest/history${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption());
        },
        approvalRequest: (params) => {
            return axios.post(`${apiURL}/workRequest/requestQueue`, params, postRequestOption());
        },
        approveOrRejectDetails: (id) => {
            return axios.get(`${apiURL}/workRequest/requestDetail/${id}`, getRequestOption());
        }
    },
    addWFHRequest: (params) => {
        return axios.post(`${apiURL}/workRequest`, params, postRequestOption());
    },
    getWFHRequest: (params) => {
        return axios.get(`${apiURL}/workRequest${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption());
    },
    getWFHBalance: (id) => {
        return axios.get(`${apiURL}/workRequest/balance/${id}`, getRequestOption());
    }
}


export const departmentService = {
    departmentScreenService: {
        addDepartmentService: (params) => {
            return axios.post(`${apiURL}/department`, params, postRequestOption());
        },
        getEditDepartmentService: (id, params) => {
            return axios.put(`${apiURL}/department/${id}`, params, putRequestOption());
        },
        deleteDepartmentService: (params) => {
            return axios.delete(`${apiURL}/department`, { data: params, ...deleteRequestOption() });
        },
        getFilterDepartmentService: (params) => {
            return axios.get(`${apiURL}/department${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption());
        }
    },
    departmentSupervisorService: {
        getDepartmentSupervisorService: (params) => {
            return axios.get(`${apiURL}/department/supervisor${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption());
        },
        addDepartmentSupervisorService: (params) => {
            return axios.post(`${apiURL}/department/supervisor`, params, postRequestOption());
        },
        editDepartmentSupervisor: (id, params) => {
            return axios.put(`${apiURL}/department/supervisor/${id}`, params, putRequestOption());
        },
        deleteDepartmentSupervisor: (data) => {
            return axios.delete(`${apiURL}/department/supervisor`, { data, ...deleteRequestOption() })
        }
    }
}

export const timeInTimeOutService = {
    addTimeInTimeOutRequest: (params) => {
        return axios.post(`${apiURL}/timeInOut`, params, postRequestOption());
    },
    timeIntimeOutHistory: (params) => {
        return axios.get(`${apiURL}/timeInOut${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption());
    },
    getTimeInTimeOutDetails: (params) => {
        return axios.get(`${apiURL}/timeInOut/details${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption());
    },
    updateTimeInTimeOutDetails: (params) => {
        return axios.put(`${apiURL}/timeInOut`, params, putRequestOption());
    },
    getTimeInOutSummary: (params) => {
        return axios.get(`${apiURL}/timeInOut/summary${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption());
    },
    getMissOutPunchDetails: (params) => {
        return axios.get(`${apiURL}/timeInOut/summary-view${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption());
    },
    getTimeSheet: (params) => {
        return axios.get(`${apiURL}/timeInOut/timeSheet${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption());
    },
    uploadTimeInOutDetails: (data) => {
        return axios.post(`${apiURL}/timeInOut/upload`, data, postRequestOption());
    },
    getEmployeeCodeServices: (params) => {
        return axios.get(`${apiURL}/timeInOut/activeEmployee${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption());
    }
}

export const designationService = {
    getDesignationList: (params) => {
        return axios.get(`${apiURL}/designation${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption());
    },
    addDesignation: (params) => {
        return axios.post(`${apiURL}/designation`, params, postRequestOption());
    },
    editDesignation: (id, params) => {
        return axios.put(`${apiURL}/designation/${id}`, params, putRequestOption());
    },
    deleteDesignation: (data) => {
        return axios.delete(`${apiURL}/designation`, { data, ...deleteRequestOption() });
    },
    getDesignationDetail: (id) => {
        return axios.get(`${apiURL}/designation/${id}`, getRequestOption());
    }
}

export const documentPolicyService = {
    complianceAgreement: {
        getDocumentList: (params) => {
            return axios.get(`${apiURL}/policy${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption());
        },
        addDocument: (params) => {
            return axios.post(`${apiURL}/policy`, params, postRequestOption());
        },
        editGetDocumentData: (id) => {
            return axios.get(`${apiURL}/policy/${id}`, getRequestOption());
        },
        editDocument: (id, params) => {
            return axios.put(`${apiURL}/policy/${id}`, params, putRequestOption());
        },
        deleteDocument: (id, data) => {
            return axios.delete(`${apiURL}/policy/${id}`, { data, ...deleteRequestOption() });
        },
        policyAssignDocument: (params) => {
            return axios.post(`${apiURL}/policy/assign`, params, postRequestOption());
        },
        updatePolicyAssignDocument: (params) => {
            return axios.put(`${apiURL}/policy/assign`, params, putRequestOption());
        },
        getPreloadDetails: () => {
            return axios.get(`${apiURL}/policy/preloadDetails`, getRequestOption());
        }
    },
    complianceHistory: {
        getcomplianceHistoryDocument: (params) => {
            return axios.get(`${apiURL}/policy/review/history${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption());
        },
        getcomplianceViewDocument: (params) => {
            return axios.get(`${apiURL}/document`, params, getRequestOption());
        },
        getDocumentData: (id) => {
            return axios.get(`${apiURL}/employeeDetails/policyDocument/${id}`, getRequestOption());
        },
    },
    agreementDocument: {
        sendDocument: () => {
            return axios.get(`${apiURL}/document`, getRequestOption());
        },
        sendDocumentAndNotify: (params) => {
            return axios.get(`${apiURL}/document`, params, getRequestOption());
        },
    },
    policyData: {
        getPolicyData: (isNotify, params) => {
            return axios.get(`${apiURL}/policy/assign/${isNotify}${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption());
        },
        getNotification: (id) => {
            return axios.get(`${apiURL}/policy/review/employee-notify/${id}`, getRequestOption());
        }
    },
    employeeAgreementPolicy: {
        getEmployeeAgreementPolicy: (params) => {
            return axios.get(`${apiURL}/policy/review/${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption());
        },
        sendEmployeeAgreementPolicy: (data) => {
            return axios.post(`${apiURL}/policy/review`, data, postRequestOption());
        }
    },
    assignedDocumentHistory: {
        getFilterRecords: (params) => {
            return axios.get(`${apiURL}/policy/assign/document-history${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption())
        },
        editAssignmentRecords: (id) => {
            return axios.get(`${apiURL}/policy/assign/view/${id}`, getRequestOption())
        },
        getPolicyType: () => {
            return axios.get(`${apiURL}/policy/type`, getRequestOption())
        },
        getPolicyEmployeeDataService: (id) => {
            return axios.get(`${apiURL}/policy/assign/status/${id}`, getRequestOption());
        },
    }
}

export const addComplianceListService = {
    complianceRequestAction: {
        addComplianceRequest: (params) => {
            return axios.post(`${apiURL}/nysCompliance`, params, postRequestOption());
        },
        updateComplianceRequest: (id, data) => {
            return axios.put(`${apiURL}/nysCompliance/${id}`, data, putRequestOption());
        },
        getComplianceRecord: (id) => {
            return axios.get(`${apiURL}/nysCompliance/${id}`, getRequestOption());
        },
        getComplianceRequest: (id) => {
            return axios.get(`${apiURL}/nysCompliance/details/${id}`, getRequestOption());
        },
        deleteComplianceRequest: (id, data) => {
            return axios.delete(`${apiURL}/nysCompliance/${id}`, { data, ...deleteRequestOption() });
        }
    },
    approverAndRejectService: {
        getApproveAndRejectData: (params) => {
            return axios.get(`${apiURL}/nysCompliance${Object.keys(params).length > 0 ? "?" + Object.entries(params).join("&").replaceAll(',', '=') : ''}`, getRequestOption());
        }
    }
}

const getRequestOption = () => {
    const userState = userReducerState();
    const token = userState.token;
    const requestOptions = {
        method: "GET",
        headers: {
            Authorization: token,
            "Content-Type": "application/json",
        }
    }
    return requestOptions;
};

const postRequestOption = () => {
    const userState = userReducerState();
    const token = userState.token;
    const UserID = userState.UserID;
    const requestOptions = {
        method: "POST",
        headers: {
            Authorization: token,
            UserID,
            "Content-Type": "application/json",
        }
    };
    return requestOptions;
};

const putRequestOption = () => {
    const userState = userReducerState();
    const token = userState.token;
    const requestOptions = {
        method: "PUT",
        headers: {
            Authorization: token,
            "Content-Type": "application/json",
        },
    };
    return requestOptions;
};

const deleteRequestOption = () => {
    const userState = userReducerState();
    const token = userState.token;
    const requestOptions = {
        method: "DELETE",
        headers: {
            Authorization: token,
            "Content-Type": "application/json",
        },
    };
    return requestOptions;
};

export const postRequestOptionForFileUpload = () => {
    const userState = userReducerState();
    const token = userState.token;
    const UserID = userState.UserID;
    const requestOptions = {
        method: "POST",
        headers: {
            Authorization: token,
            UserID,
            'Accept': 'application/json',
            "Content-Type": "multipart/form-data; boundary=<calculated when request is sent>",
        }
    };
    return requestOptions;
};
