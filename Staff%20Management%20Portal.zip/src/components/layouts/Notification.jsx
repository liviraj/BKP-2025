import PropTypes from 'prop-types';
import { IoClose } from 'react-icons/io5';
import { useDispatch, useSelector } from 'react-redux';
import { ComplianceAgreementActions } from '../../redux/ComplianceAgreementReducer';
import TransparentLoader from '../loader/TransparentLoader';
import { useHistory } from 'react-router-dom/cjs/react-router-dom.min';
import { routerPath } from '../Constants';
import { userActions } from '../../redux/userReducer';
import { dateFormat } from '../helper';

const Notification = ({ notificationMenu }) => {

    const dispatch = useDispatch();
    const history = useHistory();
    const { notificationData, loader } = useSelector(state => state.complianceAgreement);

    const handleClear = async (id) => {
        dispatch(ComplianceAgreementActions.setLoader(true));
        const clearedData = id === 0 ? [] : notificationData.filter(val => val.policyDetailId !== id); // id = 0 refers clear All.
        dispatch(ComplianceAgreementActions.setNotification(clearedData));
        if (clearedData.length <= 0) await notificationMenu();
        dispatch(ComplianceAgreementActions.setLoader(false));
    }

    const handleViewDocument = async (documentId) => {
        dispatch(ComplianceAgreementActions.setLoader(true));
        dispatch(ComplianceAgreementActions.setEmployeeAgreementPolicy({ currentPolicyId: documentId }));
        await notificationMenu();
        await history.push(routerPath.employeeViewPolicy);
        dispatch(ComplianceAgreementActions.setEmployeeagreementPolicyPopup({ show: true }));
        dispatch(userActions.setSidebarExpand({ isExpand: true, type: "dashboard" }));
        dispatch(ComplianceAgreementActions.setLoader(false));
    }

    return (
        <>
            <div className={` overflow-hidden w-full h-screen absolute sidebarScroll font-fontfamily bg-[#f2f2f2] inline-block`}>
                <div className=' flex justify-between items-center w-full bg-gray-600 text-white h-14 md:h-14 xsm:h-16 font-bold px-3 mb-3'>
                    {notificationData.length > 0 && <span className=' bg-white text-sidebarBgColor  py-1 px-2 rounded-md text-15px cursor-pointer' onClick={() => handleClear(0)}>Clear All </span>}
                    <span className=' p-1 tracking-wider text-18px font-bold'>Notifications</span>
                    <div className=' cursor-pointer' onClick={notificationMenu}><IoClose size={22} color='white' style={{ strokeWidth: '19px' }} /></div>
                </div>
                <div className=' h-[calc(100vh-4.4rem)] overflow-auto'>
                    {
                        notificationData && notificationData.length > 0 ? notificationData.map((val, key) => {
                            return (
                                <div className=' border mb-3 mx-6 rounded-md bg-white border-[#cdcdcd] shadow-lg ' key={key} >
                                    <div className=' bg-[#cdcdcd] p-2 font-bold text-16px text-center'> <p>{val.documentTitle}</p></div>
                                    <div className=' p-2'>
                                        <div > <span className=' font-bold text-14px pr-2'>Status :</span> <span>{val.status}</span></div>
                                        <div className=' mt-1'><span className=' font-bold text-14px pr-2'>Assigned Date :</span> <span>{dateFormat(val.assignedDate)}</span></div>
                                        <div className=' flex justify-between items-center mt-3'><span className=' text-blue-500 cursor-pointer hover:underline font-semibold' onClick={() => handleViewDocument(val.policyDetailId)}>View Document</span><span className=' text-red-500 cursor-pointer font-semibold' onClick={() => handleClear(val.policyDetailId)}>Clear</span></div>
                                    </div>
                                </div>
                            )
                        }) : <p className=' flex justify-center items-center h-full text-17px font-bold'>No new notifications</p>
                    }
                </div>
                <div>
                </div>
            </div>
            {loader && <TransparentLoader />}
        </>
    );
};

Notification.propTypes = {
    notificationMenu: PropTypes.func,
};
export default Notification;