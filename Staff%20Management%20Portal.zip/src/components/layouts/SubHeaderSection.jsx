import PropTypes from 'prop-types';
import ExportFiles from '../elements/ExportFiles';
import TablePrintView from '../Print/PrintView';

function SubHeaderSection({ subHeader, fileProps, headerBorder, employeeName, addtextStyle, printProps, newComponent, addStyles }) {
    return (
        <header className={`flex h-14 min-h-14 md:min-h-14 xsm:min-h-9 md:h-14 sm:h-9 xsm:h-9 items-center justify-between ${headerBorder === false ? '' : 'border-b-1 border-darkGreyBorder'} ${addStyles || ''} `}>
            <div className={`text-headerColor font-fontfamily font-bold tracking-wide ${addtextStyle || ""}`}>{subHeader}</div>
            {newComponent || <></>}
            {fileProps && <ExportFiles {...fileProps} />}
            {printProps && <TablePrintView {...printProps} />}
            {employeeName && <div className='label-shadow font-bold block text-13px font-fontfamily md:text-left tracking-wider'><span className=' text-darkGrey'>Employee Name : </span><span className=' text-headerColor capitalize'>{employeeName}</span></div>}
        </header>
    )
}

export default SubHeaderSection

SubHeaderSection.propTypes = {
    subHeader: PropTypes.string,
    fileProps: PropTypes.object,
    headerBorder: PropTypes.bool,
    employeeName: PropTypes.string,
    addtextStyle: PropTypes.string,
    printProps: PropTypes.object,
    newComponent: PropTypes.element,
    addStyles: PropTypes.string,
}