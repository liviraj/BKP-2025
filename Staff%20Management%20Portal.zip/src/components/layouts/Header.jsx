import header from '../../assets/logo.png';

function LoginHeader() {
    return (
        <header className={`bg-headerColor flex min-h-11 h-7vh md:h-6vh xsm:h-14 items-center justify-center`}>
            <span className='ml-2' > <img src={header} className='h-10 md:h-8 xsm:h-7' alt='#' /></span>
        </header>
    )
}

export default LoginHeader