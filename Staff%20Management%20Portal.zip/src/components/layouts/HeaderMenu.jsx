import PropTypes from 'prop-types';
import header from '../../assets/logo.png';
import { FiMenu, FiHelpCircle } from 'react-icons/fi';
import { useDispatch, useSelector } from 'react-redux';
import { CgProfile } from 'react-icons/cg';
import { Menu, MenuItem, SubMenu } from '@szhsin/react-menu';
import '@szhsin/react-menu/dist/index.css';
import { classNames, setDefaultValue, strings } from '../Constants';
import { TbInfoCircle } from "react-icons/tb";
import { IoPower } from "react-icons/io5";
import { userActions } from '../../redux/userReducer';
import banner from "../../assets/bannerNew.png";
import { pdfViewer, removeSessionStorage, userReducerState } from '../helper';
import leaveManagement from '../../assets/helpDocuments/LeaveManagement.pdf'
import employeeLeaveManagement from '../../assets/helpDocuments/LeaveManagementEmployee.pdf';
import staffManagement from '../../assets/helpDocuments/StaffManagement.pdf';
import myRequests from '../../assets/helpDocuments/MyRequests.pdf';
import eventManagement from '../../assets/helpDocuments/EventManagement.pdf';
import permissionRequest from '../../assets/helpDocuments/PermissionRequest.pdf';
import holidayUSAdmin from '../../assets/helpDocuments/HolidayModuleUSAdmin.pdf';
import holidayIndiaAdmin from '../../assets/helpDocuments/HolidayModuleIndiaAdmin.pdf';
import employeeHoliday from '../../assets/helpDocuments/HolidayModuleEmployee.pdf';
import employeeDashboard from '../../assets/helpDocuments/EmployeeDashboard.pdf';
import indiaAttendanceReport from '../../assets/helpDocuments/IndiaAttendanceReport.pdf';
import deputation from "../../assets/helpDocuments/DeputationModule.pdf";
import designation from "../../assets/helpDocuments/DesignationModule.pdf";
import { FaBell } from "react-icons/fa";
import { useMemo } from 'react';
// import { LuRefreshCw } from "react-icons/lu";

function HeaderMenu({ onMenuUpdate, notificationMenu }) {
    const userDetails = useSelector(state => state.user);
    const getNotificationData = useSelector(state => state.complianceAgreement.notificationData);
    const dispatch = useDispatch();
    const onLogout = () => {
        dispatch(userActions.updateLoader(true));
        removeSessionStorage();
    }
    const onReleaseNotes = () => {
        const windowFeatures = "left=200,top=100,width=2000,height=2020";
        const softwareInventoryPath = import.meta.env.VITE_SOFTWARE_INVENTORY_PATH;
        window.open(`${softwareInventoryPath}ViewReleasedVersions/#/?${encodeURIComponent(JSON.stringify({ SIID: import.meta.env.VITE_SOFTWARE_ID, SoftwareName: import.meta.env.VITE_SOFTWARE_NAME, Name: userReducerState().Name, Email: userReducerState().Email, token: userReducerState().token }))}`, "_blank", windowFeatures);
    }
    const helpDocument = (helpDocumentPath) => {
        fetch(helpDocumentPath)
            .then((response) => response.blob())
            .then((blob) => {
                const reader = new FileReader();
                reader.onload = () => {
                    const base64String = reader.result.split(',')[1]; // Extract the base64 data
                    pdfViewer(base64String);
                };
                reader.readAsDataURL(blob);
            })
            .catch((error) => {
                console.error('Error fetching and converting PDF:', error);
            });
    }
    const handleHolidayModule = () => {
        if (userDetails.Role === strings.userRoles.employee || userDetails.Role === strings.userRoles.superVisor) {
            return employeeHoliday;
        }
        return userReducerState().LocationID === setDefaultValue.location.value ? holidayIndiaAdmin : holidayUSAdmin;
    }
    const isNotified = useMemo(() => getNotificationData?.length > 0, [getNotificationData]);
    
    // const onRefresh = () => {
    //     window.location.reload();
    // }

    return (
        <header className={`bg-headerColor flex h-[4.6rem] items-center justify-between w-screen border-b-2 border-borderColor px-2`}>
            <span className=' flex items-center'>
                <span className=' mr-4 cursor-pointer md:hidden xsm:block' onClick={onMenuUpdate}><FiMenu size={18} color='white' style={{ strokeWidth: "3px" }} /></span>
                <img src={header} className=' h-10 md:h-8 xsm:h-7 mx-auto' alt='#' />
                <img src={banner} className=' ml-4 h-14 md:h-14 sm:h-12 xsm:hidden sm:block mx-auto' alt='#' />
                <span className=' relative sm:top-5 sm:right-[7.1rem] sm:block xsm:hidden text-white font-fontfamily md:text-12px sm:text-[11.5px] tracking-widest whitespace-nowrap font-bold'>{`Version: ${import.meta.env.VITE_PROD_VERSION}`}</span>
            </span>
            <div className=' flex items-center'>
                <span className='flex md:flex xsm:hidden justify-center items-end text-white font-fontfamily font-semibold tracking-wider overflow-hidden whitespace-nowrap text-ellipsis mr-2 flex-col'>
                    <span>Welcome {userDetails.Name}</span>
                    <span className=' text-14px'>{userDetails.UserCode}</span>
                </span>
                <div className={` px-2 cursor-pointer mr-4 relative ${isNotified ? 'customMove' : ''}`} onClick={notificationMenu}>
                    <div ><FaBell className=' text-white w-6 h-6' /></div>
                    {isNotified && <div className=' absolute top-[-15px] right-[2px] w-[18px] h-[18px] bg-white text-center rounded-full text-12px font-fontfamily font-semibold '>{getNotificationData?.length}</div>}
                </div>
                <Menu
                    menuButton={<span className='flex justify-center items-center text-white cursor-pointer '>{userDetails.ImageBinary && userDetails.ImageBinary.length > 0 ? <img className=' h-10 w-10 rounded-full mx-auto' src={`data:image/jpeg/png;base64,${userDetails.ImageBinary}`} alt='#' /> : <CgProfile className=' h-9 w-9 opacity-90' />}</span>}
                    arrow={true}
                    className={`${classNames.contextMenu} border-0`}
                    gap={0}
                    position="auto"
                    overflow="visible"
                    align='end'
                    menuClassName={"headerMenu border border-solid border-white text-headerColor z-20"}
                >
                    <MenuItem className={`${classNames.contextMenuItem} text-13px`} onClick={onReleaseNotes}><FiHelpCircle size={17} className=' mr-1' style={{ strokeWidth: "2.5px" }} />Release Notes</MenuItem>
                    <SubMenu className={`${classNames.contextMenuItem} !p-0 text-13px`} menuClassName={"headerMenu border border-solid border-white text-headerColor"} label={<div className=' w-full flex'><TbInfoCircle size={17} className=' mr-1' style={{ strokeWidth: "2.5px" }} />Help Document</div>}>
                        <MenuItem className={`${classNames.contextMenuItem} text-13px`} onClick={() => helpDocument(employeeDashboard)}>Employee Dashboard</MenuItem>
                        {(userDetails.Role === strings.userRoles.admin || userDetails.Role === strings.userRoles.humanResource) && <MenuItem className={`${classNames.contextMenuItem} text-13px`} onClick={() => helpDocument(staffManagement)}>Staff Management</MenuItem>}
                        <MenuItem className={`${classNames.contextMenuItem} text-13px`} onClick={() => helpDocument(userDetails.Role === strings.userRoles.employee || userDetails.Role === strings.userRoles.superVisor ? employeeLeaveManagement : leaveManagement)}>Leave Management</MenuItem>
                        <MenuItem className={`${classNames.contextMenuItem} text-13px`} onClick={() => helpDocument(myRequests)}>My Request(s)</MenuItem>
                        <MenuItem className={`${classNames.contextMenuItem} text-13px`} onClick={() => helpDocument(permissionRequest)}>Permission Request</MenuItem>
                        <MenuItem className={`${classNames.contextMenuItem} text-13px`} onClick={() => helpDocument(eventManagement)}>Event Management</MenuItem>
                        <MenuItem className={`${classNames.contextMenuItem} text-13px`} onClick={() => helpDocument(handleHolidayModule())}>Holiday</MenuItem>
                        {(userDetails.Role === strings.userRoles.admin || userDetails.Role === strings.userRoles.humanResource) && userReducerState().LocationID === setDefaultValue.location.value && <MenuItem className={`${classNames.contextMenuItem} text-13px`} onClick={() => helpDocument(indiaAttendanceReport)}>India Attendance Report</MenuItem>}
                        <MenuItem className={`${classNames.contextMenuItem} text-13px`} onClick={() => helpDocument(deputation)}>Deputation</MenuItem>
                        <MenuItem className={`${classNames.contextMenuItem} text-13px`} onClick={() => helpDocument(designation)}>Designation</MenuItem>
                    </SubMenu>
                    {/* <MenuItem className={`${classNames.contextMenuItem} text-13px`} onClick={onRefresh}><LuRefreshCw size={16} className=' mr-1' style={{ strokeWidth: "2.5px" }} />Refresh</MenuItem> */}
                    <MenuItem className={`${classNames.contextMenuItem} text-13px`} onClick={onLogout}><IoPower size={17} className=' mr-1' style={{ strokeWidth: "2.5px" }} />Logout</MenuItem>
                </Menu>
            </div>
        </header>
    )
}

export default HeaderMenu

HeaderMenu.propTypes = {
    onMenuUpdate: PropTypes.func,
    notificationMenu: PropTypes.func
}

