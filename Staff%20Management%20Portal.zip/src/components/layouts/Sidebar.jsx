import PropTypes from 'prop-types';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { NavLink } from 'react-router-dom';
import { IoClose } from 'react-icons/io5';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import { FiMinus, FiPlus } from 'react-icons/fi';
import {
  administrationLists,
  leaveManagementLists,
  leaveManagementReducerState,
  reportLists,
  userReducerState,
  eventManagementLists,
  myRequestLists,
  permissionReducerState,
  holidayList,
  dashboardList,
  departmentList,
  designationList,
  deputationList,
  timeInTimeOutList,
} from '../helper';
import { setDefaultValue, strings } from '../Constants';
import { userActions } from '../../redux/userReducer';

function Sidebar({ isDockable, onMenuUpdate }) {
  const userDetails = useSelector((state) => state.user);
  const dispatch = useDispatch();

  const defaultExpandValue = {
    administration: false,
    reports: false,
    leaveManagement: false,
    myRequests: false,
    eventManagement: false,
    holiday: false,
    dashboard: false,
    department: false,
    designation: false,
    deputation: false,
    timeInTimeOut: false
  };

  const [expand, setExpand] = useState(defaultExpandValue);

  const onExpandUpdate = (key) => {
    setExpand((prevExpand) => ({ ...prevExpand, [key]: !prevExpand[key] }));
  };

  useEffect(() => {
    const setDefaultExpand = () => {
      const isExpandLeaveManagement = leaveManagementReducerState().approveLeaveRequest.show;
      const isExpandMyRequest = permissionReducerState().redirectPermissionRequest.show;
      onExpandUpdate(isExpandLeaveManagement ? 'leaveManagement' : (isExpandMyRequest ? 'myRequests' : 'dashboard'));
    };
    setDefaultExpand();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (userDetails.sidebarExpand.isExpand) {
      setExpand({ ...defaultExpandValue, [userDetails.sidebarExpand.type]: true });
      dispatch(userActions.setSidebarExpand({ isExpand: false, type: '' }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userDetails.sidebarExpand]);

  const sidebarLists = [
    {
      label: 'Dashboard',
      key: 'dashboard',
      isVisible: true,
      isDefaultExpand: !leaveManagementReducerState().approveLeaveRequest.show && !permissionReducerState().redirectPermissionRequest.show && userDetails.LocationID === setDefaultValue.usLocation.value,
      viewList: dashboardList,
    },
    {
      label: 'Administration',
      key: 'administration',
      isVisible: [strings.userRoles.admin, strings.userRoles.humanResource].includes(userDetails.Role),
      isDefaultExpand: false,
      viewList: administrationLists,
    },
    {
      label: 'Reports',
      key: 'reports',
      isVisible: [strings.userRoles.admin, strings.userRoles.humanResource].includes(userDetails.Role),
      isDefaultExpand: false,
      viewList: reportLists(userReducerState().LocationID === setDefaultValue.location.value),
    },
    {
      label: 'Leave Management',
      key: 'leaveManagement',
      isVisible: true,
      isDefaultExpand: leaveManagementReducerState().approveLeaveRequest.show || permissionReducerState().redirectPermissionRequest.show,
      viewList: leaveManagementLists,
    },
    {
      label: 'My Request(s)',
      key: 'myRequests',
      isVisible: true,
      isDefaultExpand: false,
      viewList: myRequestLists(userReducerState().LocationID === setDefaultValue.location.value),
    },
    {
      label: 'Event Management',
      key: 'eventManagement',
      isVisible: true,
      isDefaultExpand: false,
      viewList: eventManagementLists,
    },
    {
      label: 'Reports',
      key: 'reports',
      isVisible: [strings.userRoles.employee, strings.userRoles.superVisor].includes(userReducerState().Role) && userReducerState().LocationID === setDefaultValue.usLocation.value,
      isDefaultExpand: false,
      viewList: reportLists(false)
    },
    {
      label: 'Holiday',
      key: 'holiday',
      isVisible: true,
      isDefaultExpand: false,
      viewList: holidayList,
    },
    {
      label: 'Department',
      key: 'department',
      isVisible: [strings.userRoles.admin, strings.userRoles.humanResource].includes(userDetails.Role),
      isDefaultExpand: false,
      viewList: departmentList,
    },
    {
      label: 'Designation',
      key: 'designation',
      isVisible: [strings.userRoles.admin, strings.userRoles.humanResource].includes(userDetails.Role),
      isDefaultExpand: false,
      viewList: designationList,
    },
    {
      label: 'Deputation',
      key: 'deputation',
      isVisible: userReducerState().LocationID === setDefaultValue.location.value && [strings.userRoles.admin, strings.userRoles.humanResource].includes(userDetails.Role),
      isDefaultExpand: false,
      viewList: deputationList
    },
    // {
    //   label: 'Time In / Out',
    //   key: 'timeInTimeOut',
    //   isVisible: userReducerState().LocationID === setDefaultValue.usLocation.value,
    //   isDefaultExpand: false,
    //   viewList: timeInTimeOutList
    // },
  ];

  return (
    <div className={`bg-sidebarBgColor  overflow-y-auto overflow-x-hidden w-full min-h-full sidebarScroll ${isDockable ? 'inline-block h-[99.2vh]' : 'h-employeeCalc_xsm'}`}>
      <div>
        <span className='flex flex-col p-1 justify-center items-center text-white font-fontfamily font-bold tracking-wider border-b-2 h-14 md:h-14 xsm:h-16 border-borderColor overflow-hidden whitespace-nowrap text-ellipsis md:hidden xsm:flex'>
          <span>{userDetails.Name}</span>
          {userDetails.UserCode}
        </span>
      </div>
      {sidebarLists
        .filter((val) => val.isVisible)
        .map((val, idx) => (
          <div key={val.key}>
            <Accordion key={val.key} className='!m-0 !shadow-none !rounded-none !bg-transparent' expanded={expand[val.key]} defaultExpanded={val.isDefaultExpand}>
              <AccordionSummary
                aria-controls='panel1a-content'
                id='panel1a-header'
                expandIcon={expand[val.key] ? <FiMinus color='#fff' /> : <FiPlus color='#fff' />}
                onClick={() => onExpandUpdate(val.key)}
                className='!border-0 !p-0 !m-0 !min-h-6'
                sx={{
                  '& .MuiAccordionSummary-content': { m: '0px !important' },
                  '& .MuiAccordionSummary-expandIconWrapper': { position: 'absolute', left: '9px', marginBottom: '3px' },
                }}
              >
                <span className={`px-4 ${idx === 0 ? 'py-[0.91rem]' : 'py-3'} font-fontfamily border-b-2 border-borderColor tracking-wider w-full text-white pl-8`}>
                  {val.label}
                </span>
              </AccordionSummary>
              <AccordionDetails className='!p-0'>
                <div className='text-white flex flex-col'>
                  {val.viewList.map((item, index) => (
                    <NavLink
                      key={index}
                      onClick={() => {
                        isDockable && onMenuUpdate();
                      }}
                      exact
                      className='pl-12 pr-3 py-3 font-fontfamily border-b-2 border-borderColor tracking-wider cursor-pointer text-white text-ellipsis whitespace-nowrap hover:bg-pathHighlight'
                      activeClassName='bg-pathHighlight'
                      to={item.path}
                      isActive={(_, location) => item.relatedRoutes.some(path => location.pathname === path)}
                    >
                      {item.Name}
                    </NavLink>
                  ))}
                </div>
              </AccordionDetails>
            </Accordion>
          </div>
        ))}
      {userReducerState().LocationID === setDefaultValue.usLocation.value &&
        <div className='text-white flex flex-col'> {
          timeInTimeOutList.map((item, index) => (
            <NavLink
              key={index}
              onClick={() => {
                isDockable && onMenuUpdate();
              }}
              exact
              className='pl-4 pr-3 py-3 font-fontfamily border-b-2 border-borderColor tracking-wider cursor-pointer text-white text-ellipsis whitespace-nowrap hover:bg-pathHighlight'
              activeClassName='bg-pathHighlight'
              to={item.path}
              isActive={(_, location) => item.relatedRoutes.some((path) => location.pathname === path)}
            >
              {item.Name}
            </NavLink>
          ))}
        </div>
      }
      {isDockable && (
        <div className='absolute top-1 right-3 cursor-pointer' onClick={onMenuUpdate}>
          <IoClose size={22} color='white' style={{ strokeWidth: '19px' }} />
        </div>
      )}
    </div>
  );
}

Sidebar.propTypes = {
  isDockable: PropTypes.bool,
  onMenuUpdate: PropTypes.func,
};

export default Sidebar;
