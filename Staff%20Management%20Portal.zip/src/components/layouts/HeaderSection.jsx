import PropTypes from 'prop-types';
import React, { useState } from 'react'
import { useSelector } from 'react-redux';
import { NavLink } from 'react-router-dom';
import { ScrollMenu, VisibilityContext } from 'react-horizontal-scrolling-menu';
import 'react-horizontal-scrolling-menu/dist/styles.css';
import { BsCaretLeftSquare, BsCaretRightSquare } from 'react-icons/bs';
import { routerPath, setDefaultValue, strings } from '../Constants';

function HeaderSection({ routerName, redirectType, employeeName }) {
    const employeeModuleState = useSelector(state => state.employee.employeeModule);
    const userState = useSelector(state => state.user);
    const [isArrowVisible, setIsArrowVisible] = useState(false);

    const employeeDetailList = () => {
        const isDisableRouteWithAddAction = !!(employeeModuleState.action === "Add" && Object.keys(employeeModuleState.personal).length <= 0);
        const isDisableRoute = (Object.keys(employeeModuleState.personal).length <= 0);
        return [
            { router: "Personal", link: routerPath.employeePersonal, isDisable: isDisableRouteWithAddAction },
            { router: "Work", link: routerPath.employeeWork, isDisable: isDisableRouteWithAddAction },
            { router: "Communication", link: routerPath.employeeCommunication, isDisable: isDisableRouteWithAddAction },
            { router: "Qualification", link: routerPath.employeeQualification, isDisable: isDisableRoute },
            { router: "Continuous Education", link: routerPath.employeeContinuousEducation, isDisable: isDisableRoute },
            { router: "Work History", link: routerPath.employeeWorkHistory, isDisable: isDisableRoute },
            { router: "HR Documents", link: routerPath.employeeHrDocuments, isDisable: isDisableRoute },
            { router: "NYS Compliance", link: routerPath.employeeNysCompliance, isDisable: isDisableRoute },
            { router: "Training", link: routerPath.employeeTraining, isDisable: isDisableRoute }
        ];
    }



    const leaveManagementList = () => {
        const employeeList = [
            { router: "Leave Request", link: routerPath.leaveRequest, isDisable: false },
            { router: "Leave History", link: routerPath.leaveHistory, isDisable: false },
            { router: "View Leave Ledger", link: routerPath.viewLeaveLedger, isDisable: false },
        ];
        const supervisorList = [
            { router: "Leave Request Queue", link: routerPath.leaveRequestQueue, isDisable: false },
        ]
        const adminList = [
            { router: "Leave Balance Summary", link: routerPath.leaveBalanceSummary, isDisable: false },
            { router: "Leave Summary Details", link: routerPath.leaveSummaryDetails, isDisable: false },
            { router: "Leave Request Queue", link: routerPath.leaveRequestQueue, isDisable: false },
            { router: "View & Edit Leave Ledger", link: routerPath.leaveLedger, isDisable: false }
        ];
        return (userState.Role === strings.userRoles.admin || userState.Role === strings.userRoles.humanResource) ? [...employeeList, ...adminList] : userState.Role === strings.userRoles.superVisor ? [...employeeList, ...supervisorList] : [...employeeList];
    }

    const myRequestList = () => {
        const employeeList = [
            { router: "My Request", link: routerPath.myRequest, isDisable: false },
        ];
        const adminList = [
            { router: "Approve / Reject Request", link: routerPath.approveRejectRequest, isDisable: false },
            { router: "Tracking Request", link: routerPath.trackingRequest, isDisable: false }
        ]
        return (userState.Role === strings.userRoles.admin || userState.Role === strings.userRoles.humanResource) ? [...employeeList, ...adminList] : [...employeeList];
    }

    const continuousEducationReportList = [
        { router: "Generate Report", link: routerPath.generateReport, isDisable: false },
        { router: "Generate Summary", link: routerPath.generateSummary, isDisable: false },
        { router: "Generate Details", link: routerPath.generateDetails, isDisable: false },
    ];

    const permissionRequestList = () => {
        const employeeList = [
            { router: "Permission Request", link: routerPath.permissionRequest, isDisable: false },
            { router: "Permission Histroy", link: routerPath.permissionHistory, isDisable: false }
        ];
        const adminList = [{ router: "Approve / Reject Request", link: routerPath.permissionApproveRejectRequest, isDisable: false }];
        return (userState.Role === strings.userRoles.employee) ? [...employeeList] : [...employeeList, ...adminList];
    }

    const holidayList = () => {
        const employeeList = [{ router: "Holiday List", link: routerPath.holidayList, isDisable: false }];
        const adminHolidayList = [{ router: "Add Holidays", link: routerPath.addHolidays, isDisable: false }];
        const indiaAdminList = [
            { router: "Floating Holiday List", link: routerPath.floatingHolidayList, isDisable: false },
            { router: "Add Floating Holidays", link: routerPath.addFloatingHolidays, isDisable: false }
        ];
        const adminHolidayNameList = [{ router: "Holiday Name List", link: routerPath.holidayNameList, isDisable: false }];
        if (userState.Role === strings.userRoles.employee || userState.Role === strings.userRoles.superVisor) {
            return [...employeeList]
        } else if ((userState.Role === strings.userRoles.humanResource || userState.Role === strings.userRoles.admin) && userState.LocationID === setDefaultValue.usLocation.value) {
            return [...employeeList, ...adminHolidayList, ...adminHolidayNameList];
        }
        return [...employeeList, ...adminHolidayList, ...indiaAdminList, ...adminHolidayNameList];
    }

    const indiaAttendanceReport = [
        { router: "India Attendance Report", link: routerPath.indiaLeaveReports, isDisable: false },
        { router: "Employee Payroll Detail", link: routerPath.employeePayrollDetails, isDisable: false },
        { router: "Upload Auditor Documents", link: routerPath.uploadAuditDocument, isDisable: false }
    ]


    const complianceDocumentadminList = [
        { router: "Policy Document List ", link: routerPath.createPolicyDocument, isDisable: false },
        { router: "Assigned Document History", link: routerPath.assignedDocumentHistory, isDisable: false }
    ];

    const employeePolicyList = [
        { router: "Policy History", link: routerPath.employeeViewPolicy, isDisable: false },
    ];

    const timeInTimeOutList = () => {
        const employeeList = [
            { router: "Time In / Out Entry", link: routerPath.addTimeInAndTimeOut, isDisable: false },
            { router: "Time In / Out History", link: routerPath.timeInTimeOutHistory, isDisable: false },
        ];
        const adminList = [
            { router: "Time In / Out Employee Records", link: routerPath.timeInTimeOutEmployeeRecords, isDisable: false },
            // { router: "Time In / Out Summary", link: routerPath.timeInTimeOutSummary, isDisable: false },
            { router: "Time Sheet Record", link: routerPath.timeInTimeOutTimeSheet, isDisable: false }
        ];
        return (userState.Role === strings.userRoles.admin || userState.Role === strings.userRoles.humanResource) ? [...employeeList, ...adminList] : [...employeeList];
    }

    const employeeDashboardList = () => {

        const employeeDashboard = [{ router: "Employee Dashboard", link: routerPath.employeeDashboard, isDisable: false }]
        const employeeRequest = [{ router: "Employee Request", link: routerPath.employeeDashboardRequest, isDisable: false }]

        if ((userState.Role === strings.userRoles.humanResource || userState.Role === strings.userRoles.admin) && userState.LocationID === setDefaultValue.location.value) {
            return [...employeeDashboard, ...employeeRequest]
        }
        return employeeDashboard
    }

    const addComplianceList = () => {
        const employeeComplianceRequest = [{ router: "My Compliance Documents", link: routerPath.complianceRequest, isDisable: false }]
        const myTeamComplianceDocuments = [{ router: "My Team Compliance Documents", link: routerPath.myTeamComplianceDocuments, isDisable: false }]
        if (userState.Role === strings.userRoles.humanResource || userState.Role === strings.userRoles.admin || userState.Role === strings.userRoles.superVisor) {
            return [...employeeComplianceRequest, ...myTeamComplianceDocuments]
        }
        return employeeComplianceRequest
    }

    const wfhRequestList = () => {
        const employeeList = [{ router: "WFH Request", link: routerPath.wfhRequest, isDisable: false }, { router: "WFH History", link: routerPath.wfhHistory, isDisable: false }];
        const adminList = [{ router: "Approve / Reject Request", link: routerPath.wfhApproveRejectRequest, isDisable: false }];
        return (userState.Role === strings.userRoles.employee) ? [...employeeList] : [...employeeList, ...adminList]
    }

    const leftArrowIcon = (params) => {
        return <LeftArrow {...params} isArrowVisible={isArrowVisible} />;
    }

    const rightArrowIcon = (params) => {
        return <RightArrow {...params} isArrowVisible={isArrowVisible} />
    }

    return (
        <header className={`flex h-14 min-h-14 md:min-h-14 xsm:min-h-9 md:h-14 sm:h-9 xsm:h-9 items-center justify-between border-b-3 border-headerColor ${employeeName ? " xsm:!min-h-16 md:!min-h-14 md:flex-row xsm:flex-col xsm:justify-center md:justify-between gap-y-0 md:gap-y-0 xsm:gap-y-2" : ""}`}>
            {
                routerName && routerName.length > 0 ? <div className='ml-6 text-headerColor font-fontfamily thinTextStrokeWidth uppercase font-extrabold tracking-wider'>{routerName}</div> :
                    <div className={`flex flex-col px-1 ${employeeName ? " max-w-[calc(100%-22rem)] lg:max-w-[calc(100%-22rem)] md:max-w-[calc(100%-15rem)] xsm:max-w-[100%] gap-0" : "max-w-[calc(99%-1.25rem)]"} ${!isArrowVisible ? ' ml-5' : ""}`}>
                        <ScrollMenu LeftArrow={leftArrowIcon} RightArrow={rightArrowIcon} onUpdate={(VisibilityContext) => {
                            const { isFirstItemVisible, isLastItemVisible } = VisibilityContext;
                            setIsArrowVisible(!(isFirstItemVisible && isLastItemVisible))
                        }}>
                            {redirectType === strings.type.employeeDetails && employeeDetailList().map((val, idx) => <NavLink key={idx} className={`font-fontfamily text-12px font-bold uppercase tracking-wider mx-3 ml-0 text-shadow-sm text-darkDarkGrey whitespace-nowrap ${val.isDisable && " cursor-not-allowed"} hover:!text-headerColor hover:!text-shadow-header-sm `} activeClassName='!text-headerColor !cursor-pointer !text-shadow-header-sm' to={val.link} onClick={e => val.isDisable && e.preventDefault()} >{val.router}</NavLink>)}
                            {redirectType === strings.type.leaveManagement && leaveManagementList().map((val, idx) => <NavLink key={idx} className={`font-fontfamily text-12px font-bold uppercase tracking-wider mr-4 ml-0 text-shadow-sm text-darkDarkGrey whitespace-nowrap ${val.isDisable && " cursor-not-allowed"} hover:!text-headerColor hover:!text-shadow-header-sm `} activeClassName='!text-headerColor !cursor-pointer !text-shadow-header-sm' to={val.link} onClick={e => val.isDisable && e.preventDefault()} >{val.router}</NavLink>)}
                            {redirectType === strings.type.myRequest && myRequestList().map((val, idx) => <NavLink key={idx} className={`font-fontfamily text-12px font-bold uppercase tracking-wider mx-3 ml-0 text-shadow-sm text-darkDarkGrey whitespace-nowrap ${val.isDisable && " cursor-not-allowed"} hover:!text-headerColor hover:!text-shadow-header-sm `} activeClassName='!text-headerColor !cursor-pointer !text-shadow-header-sm' to={val.link} onClick={e => val.isDisable && e.preventDefault()} >{val.router}</NavLink>)}
                            {redirectType === strings.type.continuousEducationReport && continuousEducationReportList.map((val, idx) => <NavLink key={idx} className={`font-fontfamily text-12px font-bold uppercase tracking-wider mx-3 ml-0 text-shadow-sm text-darkDarkGrey whitespace-nowrap ${val.isDisable && " cursor-not-allowed"} hover:!text-headerColor hover:!text-shadow-header-sm `} activeClassName='!text-headerColor !cursor-pointer !text-shadow-header-sm' to={val.link} onClick={e => val.isDisable && e.preventDefault()} >{val.router}</NavLink>)}
                            {redirectType === strings.type.permissionRequest && permissionRequestList().map((val, idx) => <NavLink key={idx} className={`font-fontfamily text-12px font-bold uppercase tracking-wider mx-3 ml-0 text-shadow-sm text-darkDarkGrey whitespace-nowrap ${val.isDisable && " cursor-not-allowed"} hover:!text-headerColor hover:!text-shadow-header-sm `} activeClassName='!text-headerColor !cursor-pointer !text-shadow-header-sm' to={val.link} onClick={e => val.isDisable && e.preventDefault()} >{val.router}</NavLink>)}
                            {redirectType === strings.type.holiday && holidayList().map((val, idx) => <NavLink key={idx} className={`font-fontfamily text-12px font-bold uppercase tracking-wider mx-3 ml-0 text-shadow-sm text-darkDarkGrey whitespace-nowrap ${val.isDisable && " cursor-not-allowed"} hover:!text-headerColor hover:!text-shadow-header-sm `} activeClassName='!text-headerColor !cursor-pointer !text-shadow-header-sm' to={val.link} onClick={e => val.isDisable && e.preventDefault()} >{val.router}</NavLink>)}
                            {redirectType === strings.type.indiaAttendanceReport && indiaAttendanceReport.map((val, idx) => <NavLink key={idx} className={`font-fontfamily text-12px font-bold uppercase tracking-wider mx-3 ml-0 text-shadow-sm text-darkDarkGrey whitespace-nowrap ${val.isDisable && " cursor-not-allowed"} hover:!text-headerColor hover:!text-shadow-header-sm `} activeClassName='!text-headerColor !cursor-pointer !text-shadow-header-sm' to={val.link} onClick={e => val.isDisable && e.preventDefault()} >{val.router}</NavLink>)}
                            {redirectType === strings.type.dashboard && employeeDashboardList().map((val, idx) => <NavLink key={idx} className={`font-fontfamily text-12px font-bold uppercase tracking-wider mx-3 ml-0 text-shadow-sm text-darkDarkGrey whitespace-nowrap ${val.isDisable && " cursor-not-allowed"} hover:!text-headerColor hover:!text-shadow-header-sm `} activeClassName='!text-headerColor !cursor-pointer !text-shadow-header-sm' to={val.link} onClick={e => val.isDisable && e.preventDefault()} >{val.router}</NavLink>)}
                            {redirectType === strings.type.wFHRequest && wfhRequestList().map((val, idx) => <NavLink key={idx} className={`font-fontfamily text-12px font-bold uppercase tracking-wider mx-3 ml-0 text-shadow-sm text-darkDarkGrey whitespace-nowrap ${val.isDisable && " cursor-not-allowed"} hover:!text-headerColor hover:!text-shadow-header-sm `} activeClassName='!text-headerColor !cursor-pointer !text-shadow-header-sm' to={val.link} onClick={e => val.isDisable && e.preventDefault()} >{val.router}</NavLink>)}
                            {redirectType === strings.type.timeInTimeOut && timeInTimeOutList().map((val, idx) => <NavLink key={idx} className={`font-fontfamily text-12px font-bold uppercase tracking-wider mx-3 ml-0 text-shadow-sm text-darkDarkGrey whitespace-nowrap ${val.isDisable && " cursor-not-allowed"} hover:!text-headerColor hover:!text-shadow-header-sm `} activeClassName='!text-headerColor !cursor-pointer !text-shadow-header-sm' to={val.link} onClick={e => val.isDisable && e.preventDefault()} >{val.router}</NavLink>)}
                            {redirectType === strings.type.complianceDocument && complianceDocumentadminList.map((val, idx) => <NavLink key={idx} className={`font-fontfamily text-12px font-bold uppercase tracking-wider mx-3 ml-0 text-shadow-sm text-darkDarkGrey whitespace-nowrap ${val.isDisable && " cursor-not-allowed"} hover:!text-headerColor hover:!text-shadow-header-sm `} activeClassName='!text-headerColor !cursor-pointer !text-shadow-header-sm' to={val.link} onClick={e => val.isDisable && e.preventDefault()} >{val.router}</NavLink>)}
                            {redirectType === strings.type.employeePolicy && employeePolicyList.map((val, idx) => <NavLink key={idx} className={`font-fontfamily text-12px font-bold uppercase tracking-wider mx-3 ml-0 text-shadow-sm text-darkDarkGrey whitespace-nowrap ${val.isDisable && " cursor-not-allowed"} hover:!text-headerColor hover:!text-shadow-header-sm `} activeClassName='!text-headerColor !cursor-pointer !text-shadow-header-sm' to={val.link} onClick={e => val.isDisable && e.preventDefault()} >{val.router}</NavLink>)}
                            {redirectType === strings.type.addComplianceList && addComplianceList().map((val, idx) => <NavLink key={idx} className={`font-fontfamily text-12px font-bold uppercase tracking-wider mx-3 ml-0 text-shadow-sm text-darkDarkGrey whitespace-nowrap ${val.isDisable && " cursor-not-allowed"} hover:!text-headerColor hover:!text-shadow-header-sm `} activeClassName='!text-headerColor !cursor-pointer !text-shadow-header-sm' to={val.link} onClick={e => val.isDisable && e.preventDefault()} >{val.router}</NavLink>)}
                        </ScrollMenu>
                    </div>
            }
            {employeeName && <div className=' max-w-[22rem] lg:max-w-[22rem] md:max-w-[15rem] xsm:max-w-full mr-6 lg:mr-6 xsm:mr-1 flex'><div className=' font-bold block text-13px font-fontfamily md:text-left tracking-wider overflow-hidden whitespace-nowrap text-ellipsis'><span className=' text-darkDarkGrey label-shadow'>Employee Name : </span><span className=' text-headerColor capitalize font-extrabold'>{employeeName}</span></div></div>}
        </header>
    )
}

export default HeaderSection

HeaderSection.propTypes = {
    routerName: PropTypes.string,
    redirectType: PropTypes.string,
    employeeName: PropTypes.string
}

const LeftArrow = ({ isArrowVisible }) => {
    const { isFirstItemVisible, isLastItemVisible, scrollPrev } = React.useContext(VisibilityContext);
    return (
        <span className={` cursor-pointer ${((isFirstItemVisible && isLastItemVisible) || !isArrowVisible) ? 'hidden' : isFirstItemVisible ? " opacity-60 !cursor-default" : ""} mr-2`} onClick={() => scrollPrev()}>
            <BsCaretLeftSquare className={`text-headerColor h-full w-full text-2xl`} />
        </span>
    );
}
LeftArrow.propTypes = {
    isArrowVisible: PropTypes.bool
}

const RightArrow = ({ isArrowVisible }) => {
    const { isLastItemVisible, isFirstItemVisible, scrollNext } = React.useContext(VisibilityContext);
    return (
        <span className={` cursor-pointer ${((isFirstItemVisible && isLastItemVisible) || !isArrowVisible) ? 'hidden' : isLastItemVisible ? 'opacity-60 !cursor-default' : ''} mx-2`} onClick={() => scrollNext()}>
            <BsCaretRightSquare className={`text-headerColor h-full w-full text-2xl`} />
        </span>
    );
}

RightArrow.propTypes = {
    isArrowVisible: PropTypes.bool
}



