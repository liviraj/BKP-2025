import propTypes from 'prop-types';

function GreySubHeader({ subHeader, addStyles }) {
    return (
        <div className={` !border-0 !bg-lightGrey !text-black !font-fontfamily font-bold !h-10 !max-h-10 !min-h-10 flex items-center justify-between px-3 ${addStyles || ""}`}>
            {subHeader}
        </div>
    )
}

export default GreySubHeader

GreySubHeader.propTypes = {
    subHeader: propTypes.string.isRequired,
    addStyles: propTypes.string
}