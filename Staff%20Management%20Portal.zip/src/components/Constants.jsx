/* eslint-disable react-refresh/only-export-components */

export const strings = {
  type: {
    employeeDetails: "Employee Details",
    leaveManagement: "Leave Management",
    eventManagement: "Event Management",
    sickLeave: "Sick Leave",
    myRequest: "My Request",
    continuousEducationReport: "Continuous Education Report",
    permissionRequest: "Permission Request",
    holiday: "Holiday",
    department: "Department",
    indiaAttendanceReport: "India Attendance Report",
    dashboard: "Dashboard",
    wFHRequest: 'WFH Request',
    timeInTimeOut: "Time-In & Time-Out",
    complianceDocument: "complianceDocument",
    employeePolicy: "employeePolicy",
    addComplianceList: "addComplianceList",
  },
  header: {
    employee: "Employee",
    employeeDetails: "Employee Details",
    complianceReports: "Compliance Reports",
    generateReport: "Generate Report",
    generateDetails: "Generate Details",
    generateSummary: "Generate Summary"
  },
  Employees: {
    ClinicalUsers: "clinicalUsers",
    Location: "location",
    Department: "department",
    Type: "type",
    Status: "status",
    Designation: "designation",
    Name: "name"
  },
  Login_Roles: {
    location: "location",
    status: "status",
    login: "login",
    mappingStatus: "mappingStatus",
    role: "role"
  },
  Buttons: {
    Search: "Search",
    Save: "Save",
    Close: "Close",
    Reset: "Reset",
    Update: "Update",
    Previous: "Previous",
    Next: "Next",
    Yes: "Yes",
    No: "No",
    OK: "OK",
    Submit: "Submit",
    Notify: "Notify",
    Verify: "Verify",
    Print: "Print",
    CustomClear: "Clear",
    CreateLogin: "Create Login",
    AddLeaveRequest: "Add Leave Request",
    AddLeave: "Add Leave",
    AddCreditDays: "Add Credit Days",
    addMyRequest: "Add Request",
    addPermission: "Add Permission",
    addHolidayName: "Add Holiday Name",
    setFloatingHolidays: "Set Floating Holidays",
    addHoliday: "Add Holiday",
    uploadAuditDocument: "Upload Auditor Document",
    createDesignation: "Create Designation",
    addDepartment: "Add Department",
    addSupervisor: "Add Supervisor",
    createDeputation: "Add Deputation",
    addWfh: "Add WFH",
    approve: "Approve",
    reject: "Reject",
    cancelLeaveRequest: "Cancel Leave Request",
    cancelWFHRequest: "Cancel WFH Request",
    createDocument: "Create Document",
    confirm: "Confirm",
    retake: "ReTake",
    capture: "Capture",
    cancel: "Cancel",
    send: "Send",
    upload: "Upload",
    view: "View",
    review: "Review",
    refresh: "Refresh"
  },
  constants: {
    Employees: "Employees",
    EmployeeDetails: "Employee Details",
    loader: "loader"
  },
  dropDowns: {
    Employees: {
      ClinicalUsers: "Clinical Users",
      Location: "Location",
      Department: "Department",
      Section: "Section",
      Type: "Employee Type",
      Status: "Employment Status",
      Designation: "Designation",
      Name: "Employee Name"
    },
    Login_Roles: {
      Location: "Location",
      Status: "Status",
      Name: "Employee Name",
      Id: "Mapping Status",
      Role: "Role Name"
    },
    ReportCompliance: {
      EmployeeType: "Employee Type",
      EmployeeName: "Employee Name",
      Year: "Select Year",
      DOJ: "DOJ",
      Designation: "Designation"
    }
  },
  userRoles: {
    employee: "Employee",
    admin: "Administrator", // Administrator, 
    humanResource: "Human Resource",
    superVisor: "Section Supervisor"
  },
  createUserLogin: {
    firstName: "firstName",
    middleName: "middleName",
    lastName: "lastName",
    loginId: "loginId",
    companyLocation: "companyLocation",
    email: "email",
    employeeType: "employeeType",
    employeeRole: "employeeRole",
    error: "error"
  },
  employeePersonal: {
    employeeCode: "employeeCode",
    firstName: "firstName",
    middleName: "middleName",
    lastName: "lastName",
    gender: "gender",
    dateOfBirth: "dateOfBirth",
    fatherName: "fatherName",
    motherName: "motherName",
    maritalStatus: "maritalStatus",
    spouseName: "spouseName",
    noOfChildren: "noOfChildren",
    noOfSiblings: "noOfSiblings",
    panNo: "panNo",
    ssnNo1: "ssnNo1",
    ssnNo2: "ssnNo2",
    ssnNo3: "ssnNo3",
    drivingLicenceNo: "drivingLicenceNo",
    photo: "photo",
    photoBinary: "photoBinary",
    nationality: "nationality",
    passportNumber: "passportNumber",
    issuePlace: "issuePlace",
    issueDate: "issueDate",
    expiryDate: "expiryDate",
    passport: "passport",
    passportBinary: "passportBinary",
    panSsnDlOptions: "panSsnDlOptions",
    panSsnDlDocs: "panSsnDlDocs",
    panSsnDlBinary: "panSsnDlBinary",
  },
  employeeWork: {
    employeeCode: "employeeCode",
    employeeName: "employeeName",
    designation: "designation",
    department: "department",
    dateOfJoining: "dateOfJoining",
    manager: "manager",
    grade: "grade",
    workLocation: "workLocation",
    employmentType: "employmentType",
    workStationId: "workStationId",
    systemId: "systemId",
    laptopId: "laptopId",
    isHandlesClinicalSamples: "isHandlesClinicalSamples",
    employmentStatus: "employmentStatus",
    confirmationDate: "confirmationDate",
    relievingDate: "relievingDate",
    visaType: "visaType",
    placeOfIssue: "placeOfIssue",
    issueDate: "issueDate",
    expiryDate: "expiryDate",
    countryOfIssue: "countryOfIssue",
    currentLocation: "currentLocation",
    getWorkDetails: "getWorkDetails",
    role: "role"
  },
  employeeCommunication: {
    address1: "address1",
    address2: "address2",
    address3: "address3",
    city: "city",
    state: "state",
    country: "country",
    pin: "pin",
    //permanent address
    permAdd1: "permAdd1",
    permAdd2: "permAdd2",
    permAdd3: "permAdd3",
    permCity: "permCity",
    permState: "permState",
    permCountry: "permCountry",
    permPin: "permPin",
    //contact details
    phoneno: "phoneno", //landlane
    alternateContactNumber: "alternateContactNumber",
    cellno: "cellno",
    workPhoneNo: "workPhoneNo",
    extension: "extension",
    emailID: "emailID",
    //emg cont
    emergencyContactName: "emergencyContactName",
    emergencyContactRelation: "emergencyContactRelation",
    emergencyContactAddress1: "emergencyContactAddress1",
    emergencyContactAddress2: "emergencyContactAddress2",
    emergencyContactAddress3: "emergencyContactAddress3",
    emergencyContactNumber: "emergencyContactNumber",
    cmId: "cmId"
  },
  QualificationString: {
    qualification: "qualification",
    empQualificationId: "empQualificationId",
    institution: "institution",
    university: "university",
    majorSubject: "majorSubject",
    isPartOfCLEP: "isPartOfCLEP",
    courseDuration: "courseDuration",
    courseStartDate: "courseStartDate",
    courseEndDate: "courseEndDate",
    location: "location",
    employeeImage: "employeeImage",
    employeeImageBinary: "employeeImageBinary",
    employeeid: "employeeid",
    modifiedBy: "modifiedBy",
    type: "type",
    value: "value"
  },
  workHistory: {
    workHistory: "workHistory",
    workHistoryID: "workHistoryID",
    employerName: "employerName",
    designation: "designation",
    dateofJoin: "dateofJoin",
    relievingDate: "relievingDate",
    reportingTo: "reportingTo",
    certificateImage: "certificateImage",
    employeeId: "employeeId",
    data: "data",
    selectedData: "selectedData",
    employeeImageBinary: "employeeImageBinary",
    employeeImage: "employeeImage",
    modifiedBy: "modifiedBy"
  },
  continuousEducation: {
    courseName: "courseName",
    conductedBy: "conductedBy",
    sponsoredBy: "sponsoredBy",
    duration: "duration",
    description: "description",
    category: "category",
    certificateImage: "certificateImage",
    data: "data",
    selectedData: "selectedData"
  },
  nysCompliance: {
    complianceCategory: "complianceCategory",
    compliancePeriod: "compliancePeriod",
    complianceDate: "complianceDate",
    expiryDate: "expiryDate",
    description: "description",
    documentImage: "documentImage",
    data: "data",
    selectedData: "selectedData",
    compliancePeriodOptions: "compliancePeriodOptions",
    noExpiry: "noExpiry"
  },
  training: {
    trainingCategory: "trainingCategory",
    trainingFrom: "trainingFrom",
    trainingTo: "trainingTo",
    purpose: "purpose",
    documentImage: "documentImage",
    data: "data",
    selectedData: "selectedData"
  },
  hrDocuments: {
    documentDate: "documentDate",
    expiryDate: "expiryDate",
    description: "description",
    documentImage: "documentImage",
    documentType: "documentType",
    data: "data",
    selectedData: "selectedData",
    isDropdownView: "isDropdownView"
  },
  complianceReport: {
    employeeType: "employeeType",
    selectionYear: "selectionYear",
    employeeName: "employeeName",
    dateOfJoin: "dateOfJoin",
    designation: "designation",
    relieved: "Relieved",
    notApplicable: "Not applicable"
  },
  leaveRequest: {
    leaveType: "leaveType",
    fromDate: "fromDate",
    toDate: "toDate",
    firstHalf: "firstHalf",
    secondHalf: "secondHalf",
    reason: "reason",
    employeeName: "employeeName",
    showConfirmPopup: "showConfirmPopup",
    popUpTblData: "popUpTblData",
    location: "location"
  },
  leaveRequestQueue: {
    location: "location",
    employeeName: "employeeName",
    status: "status",
    period: "period",
    fromDate: "fromDate",
    toDate: "toDate",
    leaveType: "leaveType",
    ApproveRejectView: {
      leaveDetails: 'leaveDetails',
    },
    employeeNameOptions: "employeeNameOptions",
    data: "data"
  },
  AddleaveRequestQueue: {
    appliedDate: "appliedDate",
    employeeName: "employeeName",
    location: "location",
    leaveFrom: "leaveFrom",
    leaveTo: "leaveTo",
    reason: "reason"
  },
  viewEditLeaveLedger: {
    location: "location",
    employeeName: "employeeName",
    fromDate: "fromDate",
    toDate: "toDate",
  },
  filterPeriod: {
    all: "All",
    custom: "Custom",
    payrollPeriod: "Payroll Period",
    last30Days: "Last 30 Days",
    last3Months: "Last 3 Months",
    last6Months: "Last 6 Months",
    last7Days: "Last 7 Days",
    thisYear: "This Year",
    today: "Today",
    todayAndYesterday: "Today and Yesterday",
    yesterday: "Yesterday",
    currentPayrollPeriod: "Current Payroll Period",
    previousPayrollPeriod: "Previous Payroll Period",
    nextPayrollPeriod: "Next Payroll Period",
    noExpiry: "noExpiry",
    threeMonths: "3 Months",
    sixMonths: "6 Months",
    oneYear: "1 Year",
  },
  leaveBalanceSummary: {
    year: "year",
    employeeName: "employeeName",
    location: "location",
    leaveType: "leaveType"
  },
  LeaveSummaryDetails: {
    year: "year",
    employeeName: "employeeName",
    location: "location",
    leaveType: "leaveType"
  },
  leaveHistory: {
    period: "period",
    fromDate: "fromDate",
    toDate: "toDate",
    status: "status",
  },
  recordEvents: {
    startDate: "startDate",
    endDate: "endDate",
    isContinuousEducation: "isContinuousEducation",
    type: "type",
    typeDetails: "typeDetails",
    location: "location",
    topic: "topic",
    description: "description",
    guest: "guest",
    updloadDocument: "updloadDocument",
    duration: "duration",
    presenter: "presenter",
    reports: "reports",
    fromDate: "fromDate",
    toDate: "toDate",
    periodDuration: "periodDuration",
    externalPresenters: "externalPresenters",
    workDiscussionTopic: "Weekly Meeting"
  },
  searchEvents: {
    searchBy: "searchBy",
    keyword: "keyword"
  },
  viewEventTabularView: {
    period: "period",
    fromDate: "fromDate",
    toDate: "toDate",
    searchBy: "searchBy",
    keyword: "keyword",
    eventType: "eventType"
  },
  continuousEducationReport: {
    reports: "reports",
    staff: "staff",
    employeeName: "employeeName",
    period: "period",
    fromDate: "fromDate",
    toDate: "toDate",
    location: "location"
  },
  myRequest: {
    status: "status",
    typeOfRequest: "typeOfRequest",
    description: "description",
    uploadFile: "uploadFile",
    employeeName: "employeeName",
    location: "location"
  },
  leaveReports: {
    date: "date",
    period: "period",
    fromDate: "fromDate",
    toDate: "toDate",
    leaveReport: "leaveReport"
  },
  trackingRequest: {
    location: "location",
    employeeName: "employeeName",
    period: "period",
    fromDate: "fromDate",
    toDate: "toDate",
    typeOfRequest: "typeOfRequest"
  },
  trackingRequestView: {
    topic: "topic",
    description: "description",
    status: "status",
    imageBinary: "imageBinary",
    assignedTo: "assignedTo"
  },
  permissionRequest: {
    period: "period",
    fromDate: "fromDate",
    toDate: "toDate",
    permissionType: "permissionType",
    status: "status"
  },
  addPermissionPopup: {
    location: "location",
    employeeName: "employeeName",
    date: "date",
    startTime: "startTime",
    endTime: "endTime",
    permissionType: "permissionType",
    reason: "reason",
    employeeNameOptions: "employeeNameOptions"
  },
  ApproveRejectPermissionRequest: {
    period: "period",
    fromDate: "fromDate",
    toDate: "toDate",
    location: "location",
    employeeName: "employeeName",
    permissionType: "permissionType",
    employeeNameOptions: "employeeNameOptions",
    status: "status"
  },
  permissionHistory: {
    period: "period",
    fromDate: "fromDate",
    toDate: "toDate",
    status: "status",
  },
  holidayList: {
    location: "location",
    year: "year",
    column: 'column',
    isUSAView: 'isUSAView',
    multiSelect: 'multiSelect'
  },
  floatingHolidayList: {
    employeeName: "employeeName",
    year: "year",
    floatingHolidays: "floatingHolidays"
  },
  addHoliday: {
    location: "location",
    holidayName: "holidayName",
    fromDate: "fromDate",
    toDate: "toDate",
    exchangeable: "exchangeable",
    alternateHoliday: "alternateHoliday",
    holidayType: "holidayType",
  },
  addFloatingHoliday: {
    location: "location",
    year: "year",
    employee: "employee"
  },
  editFloatingHolidayPopup: {
    employeeName: "employeeName",
    floatingHolidayList: "floatingHolidayList"
  },
  setFloatingHolidayPopup: {
    employeeName: "employeeName",
    floatingHolidayList: "floatingHolidayList"
  },
  holidayNames: {
    location: "location",
    column: 'column',
    status: 'status'
  },
  holidayNamePopup: {
    holidayName: "holidayName",
    location: "location",
  },
  departmentNamePopup: {
    departmentName: "departmentName",
    description: "description",
  },
  department: {
    status: "status",
  },
  supervisorNamePopup: {
    supervisorName: "supervisorName",
    department: "department",
    location: "location"
  },
  addHolidayPopup: {
    location: "location",
    holidayName: "holidayName",
    fromDate: "fromDate",
    toDate: "toDate",
    exchangeable: "exchangeable",
    alternateHoliday: "alternateHoliday",
    holidayType: "holidayType",
    alternateHolidayOptions: "alternateHolidayOptions",
    holidayOptionTypes: "holidayOptionTypes",
    year: "year",
    date: "date",
    federalHolidayDatas: "federalHolidayDatas"
  },
  employeePayrollDetails: {
    period: "period",
    fromDate: "fromDate",
    toDate: "toDate"
  },
  uploadAuditDocument: {
    employeeName: "employeeName",
    payrollMonth: "payrollMonth",
    selectedYear: "selectedYear",
    leaveType: "leaveType"
  },
  UploadAuditDocumentPopup: {
    leaveType: "leaveType"
  },
  validateLeaveBalacePopup: {
    employeeName: "employeeName",
    auditorPrivilegeLeaveBalance: "auditorPrivilegeLeaveBalance",
    systemPrivilegeLeaveBalance: "systemPrivilegeLeaveBalance",
  },
  designation: {
    location: "location",
    status: "status"
  },
  designationPopup: {
    designationName: "designationName",
    description: "description",
    department: "department",
    location: "location",
    rolesAndResponsibilities: "rolesAndResponsibilities",
    status: "status",
    uploadFile: 'uploadFile'
  },
  deputation: {
    period: "period",
    fromDate: "fromDate",
    toDate: "toDate",
    employeeName: "employeeName",
    deputationLocation: "deputationLocation",
    status: 'status'
  },
  deputationPopup: {
    workLocation: "workLocation",
    employeeName: "employeeName",
    deputationLocation: "deputationLocation",
    deputationSite: "deputationSite",
    deputationFrom: "deputationFrom",
    deputationTo: "deputationTo",
    depatureDate: "depatureDate",
    arrivalDate: "arrivalDate",
    travelDocument: "travelDocument",
    visaValidityFrom: "visaValidityFrom",
    visaValidityTo: "visaValidityTo",
    remarks: "remarks"
  },
  employeeDashboard: {
    tableData: "tableData",
    name: "Name",
    designation: "Designation",
    department: "Department",
    dateofJoining: "Date of Joining",
    reportingTo: "Reporting To",
    supervisor: "Supervisor"
  },
  compliance: {
    generateReport: "Generate Report",
    generateSummary: "Generate Summary",
    generateDetails: "Generate Details"
  },
  employeeRequest: {
    employeeName: "employeeName",
    fromDate: "fromDate",
    toDate: "toDate",
    period: "period",
  },
  wfhApproveReject: {
    period: 'period',
    fromDate: 'fromDate',
    toDate: 'toDate',
    status: 'status',
    employeeName: 'employeeName'
  },
  addWFHRequest: {
    startDate: 'startDate',
    endDate: 'endDate',
    reason: 'reason',
    employeeName: 'employeeName',
    halfDay: "halfDay"
  },
  wfhHistory: {
    period: "period",
    fromDate: "fromDate",
    toDate: "toDate",
    status: "status",
  },
  wfhApproveRejectPopup: {
    employeeName: "employeeName",
    fromDate: "fromDate",
    toDate: "toDate",
    comments: "comments",
    data: "data"
  },
  departmentSupervisor: {
    location: 'location',
    departmentName: 'departmentName'
  },
  timeInTimeOutRequest: {
    data: "data",
    date: "date",
    userRecords: "userRecords",
    employeeName: "employeeName",
    employeeNameOptions: 'employeeNameOptions',
    selectedDate: 'selectedDate'
  },
  timeInOutHistory: {
    period: 'period',
    fromDate: 'fromDate',
    toDate: 'toDate'
  },
  timeInOutEmployeeHistory: {
    period: 'period',
    fromDate: 'fromDate',
    toDate: 'toDate',
    employeeName: 'employeeName',
    employeeNameOptions: 'employeeNameOptions'
  },
  timeInOutSummary: {
    period: 'period',
    fromDate: 'fromDate',
    toDate: 'toDate',
    employeeName: 'employeeName',
    employeeNameOptions: 'employeeNameOptions'
  },
  agreementDocument: {
    policyDocument: 'policyDocument',
    documentTitle: 'documentTitle',
    documentType: 'documentType',
    complianceCategory: 'complianceCategory',
    compliancePeriod: 'compliancePeriod',
    compliancePeriodOptions: 'compliancePeriodOptions',
    status: "status",
    location: "location",
    createDoclocation: "createDoclocation",
    complianceCategoryOptions: "complianceCategoryOptions",
    currentVersion: 'currentVersion',
    documentNumber: 'documentNumber',
    revisionFrequency: 'revisionFrequency',
    authors: 'authors',
    authorsOption: 'authorsOption',
    validityFrom: 'validityFrom',
    validityTo: 'validityTo',
    revisionFrequencyOption: 'revisionFrequencyOption'
  },
  assignDocument: {
    dueDate: "dueDate",
    period: "period",
    documentFromDate: "documentFromDate",
    documentToDate: "documentToDate",
    isNoExpiry: "isNoExpiry",
  },
  policyHistory: {
    completedTasks: "completedTasks",
    totalTasks: "totalTasks",
    progress: "progress",
    year: "year"
  },
  timeSheetRecord: {
    period: 'period',
    fromDate: 'fromDate',
    toDate: 'toDate',
    employeeName: 'employeeName',
    employeeNameOptions: 'employeeNameOptions'
  },
  timeInOUtUPloadDocument: {
    period: 'period',
    fromDate: 'fromDate',
    toDate: 'toDate',
  },
  notifyPendingPolicies: {
    location: 'location',
    year: 'year',
    policyType: 'policyType',
    policyName: 'policyName',
    dueDate: 'dueDate',
    policyNameOption: 'policyNameOption',
    dueDateOption: 'dueDateOption'
  },
  complianceRequest: {
    complianceCategory: "complianceCategory",
    compliancePeriod: "compliancePeriod",
    complianceDate: "complianceDate",
    expiryDate: "expiryDate",
    description: "description",
    documentImage: "documentImage",
    data: "data",
    selectedData: "selectedData",
    compliancePeriodOptions: "compliancePeriodOptions",
    noExpiry: "noExpiry"
  },
  myTeamComplianceDocuments: {
    employeeName: 'employeeName',
    complianceCategory: "complianceCategory",
    compliancePeriod: "compliancePeriod",
    complianceDate: "complianceDate",
    expiryDate: "expiryDate",
    description: "description",
    documentImage: "documentImage",
    data: "data",
    selectedData: "selectedData",
    compliancePeriodOptions: "compliancePeriodOptions",
    noExpiry: "noExpiry"
  },
  approveAndRejectRequest: {
    location: "location",
    employeeName: "employeeName",
    status: "status",
    period: "period",
    fromDate: "fromDate",
    toDate: "toDate",
    employeeNameOptions: "employeeNameOptions",
  }
}

export const routerPath = {
  unAuthorized: "/unauthorized",
  loginView: "/loginview",
  staff: "/staff",
  loginUserForm: "/loginUserForm",
  employeePersonal: "/employee/personal",
  employeeCommunication: "/employee/communication",
  employeeWork: "/employee/work",
  employeeQualification: "/employee/Qualification",
  employeeWorkHistory: "/employee/workHistory",
  employeeContinuousEducation: "/employee/countinuousEducation",
  employeeHrDocuments: "/employee/HrDocuments",
  employeeNysCompliance: "/employee/nysCompliance",
  employeeTraining: "/employee/training",
  reportCompliance: "/reports/compliance",
  indiaLeaveReports: "/reports/IndiaLeaveReports",
  leaveRequest: "/leaveManagement/leaveRequest",
  leaveHistory: "/leaveManagement/leaveHistory",
  leaveRequestQueue: "/leaveManagement/leaveRequestQueue",
  leaveLedger: "/leaveManagement/leaveLedger",
  leaveBalanceSummary: "/leaveManagement/LeaveBalanceSummary",
  leaveSummaryDetails: "/leaveManagement/LeaveSummaryDetails",
  viewLeaveLedger: "/leaveManagement/viewLeaveLedger",
  recordEvents: "/eventManagement/recordEvents",
  viewEvents: "/eventManagement/viewEvents",
  facilityPersonalReport: "/eventManagement/FacilityPersonalReport",
  myRequest: "/myRequest",
  approveRejectRequest: "/myRequests/ApproveAndReject",
  trackingRequest: "/myRequests/TrackingRequests",
  generateReport: "/eventManagement/continuousEducationReport/generateReport",
  generateSummary: "/eventManagement/continuousEducationReport/generateSummary",
  generateDetails: "/eventManagement/continuousEducationReport/generateDetails",
  permissionRequest: "/permission/permissionRequest",
  permissionHistory: "/permission/permissionHistory",
  permissionApproveRejectRequest: "/permission/approveRejectRequest",
  holidayList: "/holiday/holidayListOrganization",
  floatingHolidayList: "/holiday/floatingHolidayList",
  addFloatingHolidays: "/holiday/addFloationHolidays",
  addHolidays: "/holiday/addHolidays",
  holidayNameList: "/holiday/holidayNameList",
  employeePayrollDetails: "/payroll/employeePayrollDetails",
  uploadAuditDocument: "/payroll/uploadAuditorDocument",
  employeeDashboard: "/dashboard/employeeDashboard",
  employeeDashboardRequest: "/dashboard/employeeRequest",
  department: "/department",
  departmentSupervisor: "/department/supervisor",
  designationList: "/designation/designationList",
  deputation: "/deputation",
  wfhRequest: "/WFH/WFHRequest",
  wfhApproveRejectRequest: "/WFH/approveRejectRequest",
  wfhHistory: "/WFH/WFHHistory",
  addTimeInAndTimeOut: "/timeInAndTimeOut/AddTimeinAndTimeOut",
  timeInTimeOutHistory: "/timeInAndTimeOut/History",
  timeInTimeOutEmployeeRecords: "/timeInAndTimeOut/employeeHistory",
  timeInTimeOutSummary: "/timeInAndTimeOut/summary",
  timeInTimeOutTimeSheet: "/timeInAndTimeOut/timeSheet",
  createPolicyDocument: "/policy/document",
  employeeViewPolicy: "/policy/history",
  assignedDocumentHistory: "/policy/assignedDocumentHistory",
  complianceRequest: "/reports/addComplianceList/MyComplianceDocument",
  myTeamComplianceDocuments: "/dashboard/complianceDocument/myTeamComplianceDocuments"
}

export const classNames = {
  contextMenu: "text-headerColor border border-solid border-[#999] font-fontfamily text-12px font-bold bg-white z-10 tracking-wide rounded shadow-contextMenu shadow-boxShadow hover:rounded hover:border-white",
  contextMenuItem: "p-2 cursor-pointer hover:bg-headerColor hover:text-white hover:rounded tracking-wider",
  contextMenuValue: "h-full m-0 !ml-5 min-w-96 w-full",
  contextMenuDisable: " opacity-60 hover:!bg-white hover:!text-headerColor !cursor-text",
  subContextMenu: "whitespace-nowrap",
  grid: {
    gridCols2_And_text: "font-fontfamily font-bold text-14px grid grid-cols-2 md:grid-cols-2 sm:grid-cols-1 xsm:grid-cols-1",
    gridCols12: "grid grid-cols-12",
    gridSplitFirst_4Cols: "col-start-1 col-end-4 md:col-end-5 sm:col-end-6 xsm:col-end-6 flex justify-between",
    gridSplitLast_7Cols: "col-start-5 col-end-13 md:col-start-5 sm:col-start-7 xsm:col-start-7 pl-2 break-words "
  }
}

export const setDefaultValue = {
  status: { value: 2, label: 'Active' },
  statusAll: { value: 1, label: 'All' },
  location: { value: 1, label: 'INDIA' },
  usLocation: { value: 2, label: 'USA' },
  defaultLocation: { value: 0, label: 'ALL' },
  clinicalUser: { value: 1, label: 'All' },
  department: { value: 0, label: 'All', locationId: [0] },
  mappingStatus: { value: 1, label: 'All' },
  employeeType: { value: 0, label: 'All' },
  employeeName: { value: 0, label: "All" },
  employee: { value: 0, label: "All" },
  employmentStatus: {
    confirmed: "Confirmed",
    probation: "Probation",
    relieved: "Relieved",
    active: "Active"
  },
  designation: { value: 0, label: "All" },
  roles: { value: 0, label: "All" },
  complianceReportEmployeeType: { value: 1, label: 'All Technologist' },
  leaveType: { value: 0, label: "All" },
  recordEventType: { value: 7, label: "Conference" },
  presenterType: { value: 1, label: "Internal Presenter" },
  participantType: { value: 3, label: "Participant" },
  requestStatus: { label: "To be Approved", value: "T" },
  requestType: { value: 0, label: 'All' },
  trackingStatus: {
    inProgress: 'InProgress',
    done: 'Done',
    open: 'Open',
    reject: 'Reject'
  },
  permissionType: { value: 0, label: "All" },
  floatingHolidayList: { value: 0, label: "All" },
  privilegeLeave: { "value": 1, "label": "Privilege Leave", "locationId": 1 },
  complianceReports: {
    noExpiry: "No Expiry"
  },
  agreementPolicyType: { label: "All", value: "All" },
  pendingStatusColor: 'Pending',
  complianceReportSupervisorType: { value: 3, label: "All Employees" }
}

export const leaveType = {
  fullDay: "F",
  halfDay: "H"
}

export const colors = {
  mildBlue: "bg-[#a5c3ff]",
  mildYellow: "bg-[#fef9a5]",
  mildRed: "bg-[#ffb6ab]",
  mildPurple: "bg-[#ffccff]",
  mildOrange: "bg-[#ffcc66]",
  liteHighlightOrange: "bg-[#f6e7d8]"
}

export const leaveDetails = [
  { typeId: "sickLeaveDetails", title: "Sick Leave", bgColor: colors.mildBlue },
  { typeId: "vacationLeaveDetails", title: "Vacation", bgColor: colors.mildYellow },
  { typeId: "privilegeLeaveDetails", title: "Privilege Leave", bgColor: colors.mildYellow },
  { typeId: "casualLeaveDetails", title: "Casual Leave", bgColor: colors.mildRed },
  { typeId: "dayOff", title: "Day Off", bgColor: colors.mildPurple },
  { typeId: "emergency", title: "Emergency", bgColor: colors.mildOrange },
]

export const reportFields = { // Compliance Report Fields
  employeeName: { label: 'EmployeeName' },
  doj: { label: 'DOJ' },
  designation: { label: 'Designation' },
  employeeEligibilityVerification: { label: 'I9ExpiryDate', colorCode: 'I9IsValid', noExpiry: "I9DocumentDate" },
  every3yearNyStateClinicalLicense: { label: 'Every 3 years NY State Clinical LicenseExp', colorCode: 'Every 3 years NY State Clinical License IsValid', noExpiry: 'Every 3 years NY State Clinical License' },
  yearNyStateClinicalLicense: { label: '1 year NY State Clinical LicenseExp', colorCode: '1 year NY State Clinical License IsValid', noExpiry: '1 year NY State Clinical License' },
  oneTimeEmployeeTraining: { label: 'One Time Employee TrainingExp', colorCode: 'One Time Employee Training IsValid', noExpiry: 'One Time Employee Training' },
  everyYearCompetencyAssessmentTest: { label: 'Every Year Competency Assessment TestExp', colorCode: 'Every Year Competency Assessment Test IsValid', noExpiry: 'Every Year Competency Assessment Test' },
  thirdMonthCompetencyAssessmentTest: { label: 'Third Month Competency Assessment TestExp', colorCode: 'Third Month Competency Assessment Test IsValid', noExpiry: 'Third Month Competency Assessment Test' },
  sixthMonthCompetencyAssessmentTest: { label: 'Sixth Month Competency Assessment TestExp', colorCode: 'Sixth Month Competency Assessment Test IsValid', noExpiry: 'Sixth Month Competency Assessment Test' },
  continuousEducationCreditInHours: { label: " Continuing Education Credit -in Min", colorCode: "Continuing Education Credit -in Min IsValid", noExpiry: '" Continuing Education Credit -in Min"' },
  everyYearHippaPatientConfidentiality: { label: 'Every Year HIPAA Confidentiality AgreementExp', colorCode: 'Every Year HIPAA Confidentiality Agreement IsValid', noExpiry: 'Every Year HIPAA Confidentiality Agreement' },
  yearFireEducationTraining: { label: '1 year Fire Education TrainingExp', colorCode: '1 year Fire Education Training IsValid', noExpiry: '1 year Fire Education Training' },
  yearBiohazardWasteTraining: { label: '1 year Biohazard Waste TrainingExp', colorCode: '1 year Biohazard Waste Training IsValid', noExpiry: '1 year Biohazard Waste Training' },
  everyYearBloodbornPathogensTraining: { label: 'Every Year Bloodborn Pathogens TrainingExp', colorCode: 'Every Year Bloodborn Pathogens Training IsValid', noExpiry: 'Every Year Bloodborn Pathogens Training' },
  yearPPETraining: { label: '1 year PPE TrainingExp', colorCode: '1 year PPE Training IsValid', noExpiry: '1 year PPE Training' },
  every3yearsDotTraining: { label: 'Every 3 years DOT TrainingExp', colorCode: 'Every 3 years DOT Training IsValid', noExpiry: 'Every 3 years DOT Training' },
  yearSexualHarassmentTraining: { label: '1 year Sexual Harassment TrainingExp', colorCode: '1 year Sexual Harassment Training IsValid', noExpiry: '1 year Sexual Harassment Training' },
  everyYearSupervisorPerformanceReview: { label: 'Every Year Supervisor Performance ReviewExp', colorCode: 'Every Year Supervisor Performance Review IsValid', noExpiry: 'Every Year Supervisor Performance Review' },
  oneYearCovid19: { label: 'One Year Covid-19Exp', colorCode: 'One Year Covid-19 IsValid', noExpiry: 'One Year Covid-19' },
  yearHandHygiene: { label: 'Year Hand HygieneExp', colorCode: 'Year Hand Hygiene IsValid', noExpiry: 'Year Hand Hygiene' },
  yearCyberSecurity: { label: 'Year Cyber SecurityExp', colorCode: 'Year Cyber Security IsValid', noExpiry: 'Year Cyber Security' },
  oneYearHIPAA: { label: 'Year HIPAAExp', colorCode: 'Year HIPAA IsValid', noExpiry: 'Year HIPAA' },
  employeeId: { label: "EmployeeID" }
}

export const status = {
  approved: "A",
  reject: "R",
  cancel: "C",
  tobeApproved: "T",
  tobeCancelled: "TC"
}

export const storageConstants = {
  routerParams: "STORAGE_R_P"
}

export const eventColors = [{
  id: 0, // Purple
  containerStyle: "bg-[#e9d5ff] text-[#8b5cf6]",
  titleColor: "text-[#7c3aed]",
  hoverStyle: "hover:bg-[#e4d2ff] hover:text-[#7c3aed] border-[#c4b5fd]",
  yearStyle: "text-[#7c3aed] hover:text-[#7c3aed] purple-text-shadow"
}, {
  id: 1, // Blue
  containerStyle: "bg-[#bfd8f9] text-[#3B82F6]",
  titleColor: "text-[#1D4ED8]",
  hoverStyle: "hover:bg-[#b2cef3] hover:text-[#1D4ED8] border-[#87b7f7]",
  yearStyle: "text-[#1D4ED8] hover:text-[#1D4ED8] blue-text-shadow"
}, {
  id: 2, // Pink
  containerStyle: " bg-[#FDF2F8] text-[#EC4899]",
  titleColor: "text-[#BE185D]",
  hoverStyle: "hover:bg-[#FCE7F3] hover:text-[#BE185D]  border-[#f9d9eb]",
  yearStyle: "text-[#BE185D] hover:text-[#BE185D] pink-text-shadow"
}, {
  id: 3, // Green
  containerStyle: "bg-[#d6f1d8] text-[#6bbb71]",
  titleColor: "text-[#20a920]",
  hoverStyle: "hover:bg-[#cce7ce] hover:text-[#20a920]  border-[#9bcf9f]",
  yearStyle: "text-[#20a920] hover:text-[#20a920] green-text-shadow"
}, {
  id: 4, // yellow
  containerStyle: " bg-[#fde2ae] text-[#D18700]",
  titleColor: "text-[#A36A00]",
  hoverStyle: "hover:bg-[#fddb99] hover:text-[#A36A00]  border-[#f1ba51]",
  yearStyle: "text-[#A36A00] hover:text-[#A36A00] yellow-text-shadow"
}];

export const eventGreyColor = {
  id: 1,
  containerStyle: "bg-[#E5E7EB] text-[#6B7280]",
  titleColor: "text-[#374151]",
  hoverStyle: "hover:bg-[#E5E7EB] hover:text-[#374151] hover:border-[#E5E7EB]"
}

export const warningMessage = {
  handlePopup_In_BlockState: "Please allow the popup windows for user authentication"
}

export const trackingStatusList = [
  { label: "Open", value: 1, key: "open" },
  { label: "InProgress", value: 2, key: "inProgress" },
  { label: "Done", value: 3, key: "done" },
  { label: "Reject", value: 4, key: "reject" }
]

export const continuousEducationReportOptions = [
  { label: "Continuous Education", value: 0 },
  { label: "Working Discussions", value: 1 }
];

export const popupType = {
  edit: "Edit",
  view: "View"
}

export const floatingHolidayColors = [{
  id: 0, // Dark Blue 
  color: "#204084"
  // color: "#A36A00" // Yellow
}, {
  id: 1, // Cyan 
  color: "#208a88",
  // color: "#BE185D", // Pink
}, {
  id: 2, // light parrot Green
  color: "#6da023"
  // color: "#7c3aed" // Purple
}, {
  id: 3, // Brown
  color: "#682d08"
  // color: "#20a920" // Green
}, {
  id: 4, // 
  color: "#BE185D", // Pink
  // color: "#1D4ED8" // Blue
}];

export const floatingHolidayTypes = {
  checked: "checked",
  unChecked: "unChecked",
  empty: "empty"
}
export const permissionTypes = [
  { label: 'All', value: 0 },
  { label: 'Emergency', value: 1 },
  { label: 'OnDuty', value: 2 },
  { label: 'Personal', value: 3 }
]

export const monthOption = [
  { label: "All", value: 'All' },
  { label: "January", value: 'January' },
  { label: "February", value: 'February' },
  { label: "March", value: 'March' },
  { label: "April", value: 'April' },
  { label: "May", value: 'May' },
  { label: "June", value: 'June' },
  { label: "July", value: 'July' },
  { label: "August", value: 'August' },
  { label: "September", value: 'September' },
  { label: "October", value: 'October' },
  { label: "November", value: 'November' },
  { label: "December", value: 'December' }
]

export const statusOptionsList = [
  { label: "All", value: 0 },
  { label: "Active", value: 1 },
  { label: "InActive", value: 2 }
]

export const addHolidayRecordStatus = {
  active: "Active"
}

export const HolidayNameStatus = [
  { label: "All", value: 'All' },
  { label: "Active", value: 'A' },
  { label: "InActive", value: 'D' }
];

export const devices = {
  mobile: "mobile",
  tablet: "tablet",
  desktop: "desktop"
}

export const complianceCourseType = {
  Course: 'Course',
  Training: 'Training'
}

export const timeInTimeOutUploadDocumentValidation = {
  color: "#ffe9df",
  legendColor: "#f9d3c4",
  name: "Highlighted rows indicate mismatched employee numbers"
}