/* eslint-disable react/prop-types */
/* eslint-disable react-refresh/only-export-components */
import { store } from "../../redux/store";
import { floatingHolidayTypes, routerPath, setDefaultValue, status, strings } from "../Constants";
import moment from "moment-timezone";
import { userActions } from "../../redux/userReducer";
import { Avatar } from "@mui/material";
import Label from "../elements/Label";
import PropTypes from 'prop-types';
import { FaRegSquareCheck } from "react-icons/fa6";
import { TbSquare } from "react-icons/tb";
import { PiXSquare } from 'react-icons/pi';
import { holidayRequests } from "../requests";
import { holidayActions } from "../../redux/holidayReducer";
import fedHolidays from '@18f/us-federal-holidays';

export const userReducerState = () => {
    return store.getState().user;
}

export const employeeReducerState = () => {
    return store.getState().employee;
}

export const loginReducerState = () => {
    return store.getState().login;
}

export const leaveManagementReducerState = () => {
    return store.getState().leaveManagement;
}

export const complainceReportReducerState = () => {
    return store.getState().complianceReport;
}

export const loginResponseReducerState = () => {
    return store.getState().loginResponse;
}

export const myRequestReducerState = () => {
    return store.getState().myRequest;
}

export const eventManagementReducerState = () => {
    return store.getState().eventManagement;
}

export const permissionReducerState = () => {
    return store.getState().permission;
}

export const holidayReducerState = () => {
    return store.getState().holiday;
}

export const wfhReducerState = () => {
    return store.getState().wfhRequest;
}

export const attendancePayrollState = () => {
    return store.getState().attendancePayroll;
}

export const timeInOutReducerState = () => {
    return store.getState().timeInTimeOut;
}

export const complianceAgreementReducerState = () => {
    return store.getState().complianceAgreement;
}

export const administrationLists = [
    { Name: "Staff", path: routerPath.staff, relatedRoutes: [routerPath.staff, routerPath.employeeCommunication, routerPath.employeePersonal, routerPath.employeeWorkHistory, routerPath.employeeQualification, routerPath.employeeWork, routerPath.employeeContinuousEducation, routerPath.employeeHrDocuments, routerPath.employeeNysCompliance, routerPath.employeeTraining] },
    { Name: "Logins & Roles", path: routerPath.loginView, relatedRoutes: [routerPath.loginView, routerPath.loginUserForm] },
    { Name: "Agreements & Documents", path: routerPath.createPolicyDocument, relatedRoutes: [routerPath.createPolicyDocument, routerPath.assignedDocumentHistory] },
];

export const reportLists = (isIndiaAdmin) => {
    const reports = [
        { Name: "Compliance", path: routerPath.reportCompliance, relatedRoutes: [routerPath.reportCompliance] },
        { Name: "Continuous Education Report", path: routerPath.generateReport, relatedRoutes: [routerPath.generateReport, routerPath.generateSummary, routerPath.generateDetails] },
        { Name: "Facility Personal Report", path: routerPath.facilityPersonalReport, relatedRoutes: [routerPath.facilityPersonalReport] },
    ]
    const indiaReports = [
        { Name: "India Attendance Report", path: routerPath.indiaLeaveReports, relatedRoutes: [routerPath.indiaLeaveReports, routerPath.employeePayrollDetails, routerPath.uploadAuditDocument] }
    ]
    return isIndiaAdmin ? [...reports, ...indiaReports] : [...reports]
};

export const leaveManagementLists = [
    { Name: "Leave Management", path: routerPath.leaveRequest, relatedRoutes: [routerPath.leaveRequest, routerPath.leaveHistory, routerPath.viewLeaveLedger, routerPath.leaveRequestQueue, routerPath.leaveLedger, routerPath.leaveBalanceSummary, routerPath.leaveSummaryDetails] }
];

export const myRequestLists = (isIndiaAdmin) => {
    const requestLists = [
        { Name: "My Request (s)", path: routerPath.myRequest, relatedRoutes: [routerPath.myRequest, routerPath.approveRejectRequest, routerPath.trackingRequest] },
        { Name: "Permission Request", path: routerPath.permissionRequest, relatedRoutes: [routerPath.permissionRequest, routerPath.permissionHistory, routerPath.permissionApproveRejectRequest] }
    ];
    const indiaRequestLists = [{ Name: "WFH Request", path: routerPath.wfhRequest, relatedRoutes: [routerPath.wfhRequest, routerPath.wfhHistory, routerPath.wfhApproveRejectRequest] }];
    return isIndiaAdmin ? [...requestLists, ...indiaRequestLists] : [...requestLists];

}

export const eventManagementLists = [
    { Name: "Record Events", path: routerPath.recordEvents, relatedRoutes: [routerPath.recordEvents] },
    { Name: "Events", path: routerPath.viewEvents, relatedRoutes: [routerPath.viewEvents] }
];

export const holidayList = [
    { Name: "Holidays", path: routerPath.holidayList, relatedRoutes: [routerPath.holidayList, routerPath.floatingHolidayList, routerPath.addFloatingHolidays, routerPath.addHolidays, routerPath.holidayNameList] },
];

export const dashboardList = [
    { Name: "Dashboard", path: routerPath.employeeDashboard, relatedRoutes: [routerPath.employeeDashboard, routerPath.employeeDashboardRequest] },
    { Name: "Agreements & HR Documents", path: routerPath.employeeViewPolicy, relatedRoutes: [routerPath.employeeViewPolicy,] },
    { Name: "Compliance Documents", path: routerPath.complianceRequest, relatedRoutes: [routerPath.complianceRequest, routerPath.myTeamComplianceDocuments] },
]

export const designationList = [
    { Name: "Designation", path: routerPath.designationList, relatedRoutes: [routerPath.designationList] }
]

export const departmentList = [
    { Name: "Department", path: routerPath.department, relatedRoutes: [routerPath.department] },
    { Name: "Department Supervisor", path: routerPath.departmentSupervisor, relatedRoutes: [routerPath.departmentSupervisor] },
]

export const deputationList = [
    { Name: "Deputation", path: routerPath.deputation, relatedRoutes: [routerPath.deputation] }
]

export const timeInTimeOutList = [
    { Name: "Time In / Out", path: routerPath.addTimeInAndTimeOut, relatedRoutes: [routerPath.addTimeInAndTimeOut, routerPath.timeInTimeOutHistory, routerPath.timeInTimeOutEmployeeRecords, routerPath.timeInTimeOutSummary, routerPath.timeInTimeOutTimeSheet] }
]

export const mobileNumberValidation = (number) => {
    // eslint-disable-next-line no-useless-escape
    return !!((number === "" || number.match(/^[0-9)\s\(+-]+$/g)) && number.length <= 15);
}

export const numberValidation = (number, maxLength, minVal, maxVal, decimalValue) => {
    if (number === "") {
        return true;
    }
    else if ((maxLength && number.length > maxLength && !decimalValue) || (decimalValue && maxLength && number.length > (maxLength + decimalValue + 1))) {
        return false;
    }
    else if ((minVal || (typeof (minVal) === "number" && minVal === 0)) && maxVal) {
        if (minVal <= Number(number) && maxVal >= Number(number)) {
            // eslint-disable-next-line no-useless-escape
            return decimalValue ? !!number.match(/^[0-9/.]+$/g) : !!number.match(/^[0-9]+$/g);
        }
        return false;
    }
    // eslint-disable-next-line no-useless-escape
    return Number(number) ? (decimalValue ? !!number.match(/^[0-9/.]+$/g) : !!number.match(/^[0-9]+$/g)) : false;
}


export const dateFormat = (date) => {
    return date && !isNaN(new Date(date)) ? store.getState().user.LocationID === setDefaultValue.location.value ? moment(date).format('DD/MM/YYYY') : moment(date).format("MM/DD/YYYY") : ""
}
export const monthAndDateFormat = (date) => {
    return date && !isNaN(new Date(date)) ? store.getState().user.LocationID === setDefaultValue.location.value ? moment(date).format('DD/MM') : moment(date).format("MM/DD") : ""
}

export const dateAndTimeFormat = (date) => {
    return date && !isNaN(new Date(date)) ? store.getState().user.LocationID === setDefaultValue.location.value ? moment(date).format('DD/MM/YYYY HH:mm:ss A') : moment(date).format("MM/DD/YYYY HH:mm:ss A") : ""
}

export const timeFormat = (date) => {
    return date && !isNaN(new Date(date)) ? moment(date).format('hh:mm:ss A') : ""
}

export const complianceReportDateFormat = (date) => {
    return date && !isNaN(new Date(date)) ? moment(new Date(date)).format("MM/DD/YYYY") : ""
}

export const exportDateFormat = (date, isDateOnly, isDateAndHoursMinutesOnly) => {
    if (!date || isNaN(new Date(date))) {
        return ""
    }
    else if (isDateOnly) {
        return moment(date).set({ hours: 0, milliseconds: 0, minutes: 0, seconds: 0 }).format("YYYY-MM-DD HH:mm:ss.SSS");
    } else if (isDateAndHoursMinutesOnly) {
        return moment(date).set({ milliseconds: 0, seconds: 0 }).format("YYYY-MM-DD HH:mm:ss.SSS");
    }
    return moment(date).format("YYYY-MM-DD HH:mm:ss.SSS");
}

export const exportYearFormat = (date) => {
    if (!date || isNaN(new Date(date))) {
        return ""
    }
    return moment(date).year();
}

export const genderOptions = [
    { value: 1, label: "Male" },
    { value: 2, label: "Female" },
];

export const maritalStatusOptions = [
    { value: 1, label: "Single" },
    { value: 2, label: "Married" },
    { value: 3, label: "Separated" }
];

export const isPartOfClinicalUser = {
    yes: "Y",
    no: "N"
};

export const staffInitialState = {
    clinicalUsers: "",
    clinicalUsersId: 0,
    location: "",
    locationId: 0,
    department: "",
    departmentId: 0,
    type: "",
    typeId: 0,
    status: "",
    statusId: 0,
    designation: "",
    designationId: 0,
    name: "",
    nameId: 0
};

export const staffFilterInitialState = {
    locationId: userReducerState().LocationID,
    employeeStatus: setDefaultValue.status.label,
    clinicalHandler: setDefaultValue.clinicalUser.label,
    departmentId: setDefaultValue.department.value,
    employeeType: setDefaultValue.employeeType.label,
    employeeId: setDefaultValue.employee.value,
    designationId: setDefaultValue.designation.value
}

export const loginInitialState = {
    login: "",
    loginId: 0,
    location: "",
    locationId: 0,
    mappingStatus: "",
    mappingStatusId: 0,
    role: "",
    roleId: 0,
    status: "",
    statusId: "",
    employeeName: "",
    employeeId: 0,
}

export const loginFilterInitialState = {
    location: userReducerState().LocationID,
    status: setDefaultValue.status.label,
    mappingStatus: setDefaultValue.mappingStatus.label,
    employeeId: setDefaultValue.employee.value,
    loginId: setDefaultValue.employee.value,
    role: setDefaultValue.roles.value
};

export const InitializeSessionStorage = () => {
    const tempStaffFilterInitialState = {
        locationId: userReducerState().LocationID,
        employeeStatus: setDefaultValue.status.label,
        clinicalHandler: setDefaultValue.clinicalUser.label,
        departmentId: setDefaultValue.department.value,
        employeeType: setDefaultValue.employeeType.label,
        employeeId: setDefaultValue.employee.value,
        designationId: setDefaultValue.designation.value
    }

    const tempLoginFilterInitialState = {
        location: userReducerState().LocationID,
        status: setDefaultValue.status.label,
        mappingStatus: setDefaultValue.mappingStatus.label,
        employeeId: setDefaultValue.employee.value,
        loginId: setDefaultValue.employee.value,
        role: setDefaultValue.roles.value
    };

    sessionStorage.setItem("staffState", JSON.stringify(staffInitialState));
    sessionStorage.setItem("staffFilterState", JSON.stringify(tempStaffFilterInitialState));
    sessionStorage.setItem("staffModifyFilterState", JSON.stringify(tempStaffFilterInitialState));
    sessionStorage.setItem("loginFilterState", JSON.stringify(tempLoginFilterInitialState));
    sessionStorage.setItem("loginModifyFilterState", JSON.stringify(tempLoginFilterInitialState));
    sessionStorage.setItem("loginState", JSON.stringify(loginInitialState));
}

export const removeSessionStorage = () => {
    sessionStorage.setItem("staffState", JSON.stringify(staffInitialState));
    sessionStorage.setItem("staffFilterState", JSON.stringify(staffFilterInitialState));
    sessionStorage.setItem("loginState", JSON.stringify(loginInitialState));
    sessionStorage.setItem("loginFilterState", JSON.stringify(loginFilterInitialState));
    sessionStorage.removeItem("staffState");
    sessionStorage.removeItem("staffFilterState");
    sessionStorage.removeItem("loginState");
    sessionStorage.removeItem("loginFilterState");
    sessionStorage.clear();
    store.dispatch(userActions.setUserDetails({ isLoginVisible: true }));
}

export const periodOptions = [
    { label: "All", value: 1 },
    { label: "Custom", value: 2 },
    { label: "Previous Payroll Period", value: 11 },
    { label: "Current Payroll Period", value: 0 },
    { label: "Next Payroll Period", value: 12 },
    { label: "This Year", value: 7 },
    { label: "Last 6 Months", value: 5 },
    { label: "Last 3 Months", value: 4 },
    { label: "Last 30 Days", value: 3 },
    { label: "Last 7 Days", value: 6 },
    { label: "Today and Yesterday", value: 9 },
    { label: "Today", value: 8 },
    { label: "Yesterday", value: 10 },
]


export const pdfViewer = async (data) => {
    const pdfstr = await fetch(`data:application/pdf;base64,${data}`);
    const blobFromFetch = await pdfstr.blob();
    let blob = new Blob([blobFromFetch], { type: "application/pdf" });
    const blobUrl = URL.createObjectURL(blob);
    window.open(blobUrl, "_blank");
}

export const imageViewer = async (data) => {
    const imgstr = await fetch(`data:image/jpeg;base64,${data}`);
    const blobFromFetch = await imgstr.blob();
    let blob = new Blob([blobFromFetch], { type: "image/jpeg" });
    const blobUrl = URL.createObjectURL(blob);
    window.open(blobUrl, "_blank");
}

function base64ToArrayBuffer(base64) {
    let binaryString = window.atob(base64);
    let binaryLen = binaryString.length;
    let bytes = new Uint8Array(binaryLen);
    for (let i = 0; i < binaryLen; i++) {
        let ascii = binaryString.charCodeAt(i);
        bytes[i] = ascii;
    }
    return bytes;
}

export const downloadFiles = (function () {
    let a = document.createElement("a");
    document.body.appendChild(a);
    a.style = "display: none";
    return function (data, name) {
        let bytes = base64ToArrayBuffer(data);
        let blob = new Blob([bytes], { type: 'application/pdf, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,"image/png", "image/jpeg"' }),
            url = window.URL.createObjectURL(blob);
        a.href = url;
        a.download = name;
        a.click();
        window.URL.revokeObjectURL(url);
    };
}());


export const debugBase64 = (base64URL) => {
    let win = window.open();
    win.document.write('<iframe src="' + base64URL + '" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>');
}

export const localFileDownload = (files) => {
    let reader = new FileReader();
    let file = files;
    reader.onloadend = () => {
        if (file.type === 'image/jpeg' || file.type === 'image/png' || file.type === 'application/pdf') {
            debugBase64(reader.result);
        } else {
            const link = document.createElement('a');
            link.href = reader.result;
            document.body.appendChild(link);
            link.download = file.name;
            link.click();
        }
    }
    reader.readAsDataURL(file);
}

export const fileToBase64Conversion = (file, setCallBack) => {
    let reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = function () {
        let data = reader.result.split("base64,");
        setCallBack({ name: file.name, binary: data && data.length > 0 && data[1] })
    };
    reader.onerror = function (error) {
        console.error('Error: ', error);
    };
}

export const filterParams = {
    typeFormat: (options) => {
        return {
            filterOptions: [
                'contains',
                ...options.map(val => ({
                    displayKey: val,
                    displayName: val,
                    predicate: (_, cellValue) => cellValue && typeof (cellValue) === "string" && cellValue.toLowerCase() === val.toLowerCase(),
                    numberOfInputs: 0,
                })),
            ],
            maxNumConditions: 1,
        }
    },
    keyFormat: (options) => {
        return {
            filterOptions: [
                'contains',
                ...options.map(val => ({
                    displayKey: val.value,
                    displayName: val.label,
                    predicate: (_, cellValue) => cellValue !== null ? typeof (cellValue) === "string" ? cellValue.toLowerCase() === val.value.toLowerCase() : cellValue === val.value : null,
                    numberOfInputs: 0,
                })),
            ],
            maxNumConditions: 1,
        }
    }

}

export const leaveStatus = [
    { label: "All", value: 0, Key: "E" },
    { label: "Approved", value: 1, Key: "A" },
    { label: "Rejected", value: 2, Key: "R" },
    { label: "Partially Approved", value: 3, Key: "PA" },
    { label: "To Be Approved", value: 4, Key: "T" },
    { label: "Cancelled", value: 5, Key: "C" },
    { label: "To Be Cancelled", value: 6, Key: "TC" }
]

export const payRollPeriod = () => {
    const fixedDate = moment("01 Jan 2024", "DD MMM YYYY");
    const currentDate = moment();

    const currentPayrollStartDate = fixedDate.clone().add(Math.floor(currentDate.diff(fixedDate, "days") / 14) * 14, "days");
    const currentPayrollEndDate = currentPayrollStartDate.clone().add(13, "days");

    const previousPayrollStartDate = currentPayrollStartDate.clone().subtract(14, "days");
    const previousPayrollEndDate = previousPayrollStartDate.clone().add(13, "days");

    const nextPayrollStartDate = currentPayrollEndDate.clone().add(1, "day");
    const nextPayrollEndDate = nextPayrollStartDate.clone().add(13, "days");

    const date = moment().date();
    const currentIndPayrollStartDate = date <= 23 ? moment().subtract(1, 'month').date(24) : moment().date(24);
    const currentIndPayrollEndDate = date <= 23 ? moment().date(23) : moment().add(1, 'month').date(23);

    return {
        US: {
            previous: { start: previousPayrollStartDate, end: previousPayrollEndDate },
            current: { start: currentPayrollStartDate, end: currentPayrollEndDate },
            next: { start: nextPayrollStartDate, end: nextPayrollEndDate }
        },
        IND: {
            current: { start: currentIndPayrollStartDate, end: currentIndPayrollEndDate }
        }
    };
}

export const periodDateFormat = (value, setValue) => {
    setValue(strings.leaveRequestQueue.period, value);
    let indiaPayRoll = leaveManagementReducerState().payroll.indiaPayRoll;
    let usPayRoll = leaveManagementReducerState().payroll.usPayRoll;

    switch (value.label) {
        case strings.filterPeriod.last30Days:
            setValue(strings.leaveRequestQueue.fromDate, new Date(moment().subtract(30, 'days').startOf('day')));
            setValue(strings.leaveRequestQueue.toDate, new Date(moment().endOf('day')));
            break;
        case strings.filterPeriod.last3Months:
            setValue(strings.leaveRequestQueue.fromDate, new Date(moment().subtract(3, "months").startOf('day')));
            setValue(strings.leaveRequestQueue.toDate, new Date(moment().endOf('day')));
            break;
        case strings.filterPeriod.last6Months:
            setValue(strings.leaveRequestQueue.fromDate, new Date(moment().subtract(6, "months").startOf('day')));
            setValue(strings.leaveRequestQueue.toDate, new Date(moment().endOf('day')));
            break;
        case strings.filterPeriod.last7Days:
            setValue(strings.leaveRequestQueue.fromDate, new Date(moment().subtract(7, 'days').startOf('day')));
            setValue(strings.leaveRequestQueue.toDate, new Date(moment().endOf('day')));
            break;
        case strings.filterPeriod.thisYear:
            setValue(strings.leaveRequestQueue.fromDate, new Date(moment().set({ date: 1, month: 0 }).startOf('day')));
            setValue(strings.leaveRequestQueue.toDate, new Date(moment().set({ date: 31, month: 11 })));
            break;
        case strings.filterPeriod.today:
            setValue(strings.leaveRequestQueue.fromDate, new Date(moment().startOf('day')));
            setValue(strings.leaveRequestQueue.toDate, new Date(moment().endOf('day')));
            break;
        case strings.filterPeriod.todayAndYesterday:
            setValue(strings.leaveRequestQueue.fromDate, new Date(moment().subtract(1, 'day').startOf('day')));
            setValue(strings.leaveRequestQueue.toDate, new Date(moment().endOf('day')));
            break;
        case strings.filterPeriod.yesterday:
            setValue(strings.leaveRequestQueue.fromDate, new Date(moment().subtract(1, 'day').startOf('day')));
            setValue(strings.leaveRequestQueue.toDate, new Date(moment().subtract(1, 'day').endOf('day')));
            break;
        case strings.filterPeriod.payrollPeriod:
            setValue(strings.leaveRequestQueue.fromDate, payRollPeriod().IND.current.start);
            setValue(strings.leaveRequestQueue.toDate, payRollPeriod().IND.current.end);
            break;
        case strings.filterPeriod.currentPayrollPeriod:
            if (userReducerState().LocationID === setDefaultValue.location.value) {
                setValue(strings.leaveRequestQueue.fromDate, indiaPayRoll.current.startDate);
                setValue(strings.leaveRequestQueue.toDate, indiaPayRoll.current.endDate);
            }
            else {
                setValue(strings.leaveRequestQueue.fromDate, usPayRoll.current.startDate);
                setValue(strings.leaveRequestQueue.toDate, usPayRoll.current.endDate);
            }
            break;
        case strings.filterPeriod.previousPayrollPeriod:
            if (userReducerState().LocationID === setDefaultValue.location.value) {
                setValue(strings.leaveRequestQueue.fromDate, indiaPayRoll.previous.startDate);
                setValue(strings.leaveRequestQueue.toDate, indiaPayRoll.previous.endDate);
            }
            else {
                setValue(strings.leaveRequestQueue.fromDate, usPayRoll.previous.startDate);
                setValue(strings.leaveRequestQueue.toDate, usPayRoll.previous.endDate);
            }
            break;
        case strings.filterPeriod.nextPayrollPeriod:
            if (userReducerState().LocationID === setDefaultValue.location.value) {
                setValue(strings.leaveRequestQueue.fromDate, indiaPayRoll.next.startDate);
                setValue(strings.leaveRequestQueue.toDate, indiaPayRoll.next.endDate);
            }
            else {
                setValue(strings.leaveRequestQueue.fromDate, usPayRoll.next.startDate);
                setValue(strings.leaveRequestQueue.toDate, usPayRoll.next.endDate);
            }
            break;
        case strings.filterPeriod.all:
        case strings.filterPeriod.custom:
        case strings.filterPeriod.customPayrollPeriod:
        default:
            setValue(strings.leaveRequestQueue.fromDate, "");
            setValue(strings.leaveRequestQueue.toDate, "");
    }
}

export const leaveRequestApprovalValidation = (requestStatus, action) => {
    switch (action) {
        case status.approved: { // Approved -> Status - 'T' only selectable
            return (requestStatus !== status.tobeApproved);
        }
        case status.reject: { // Reject -> Status - 'T' only selectable
            return (requestStatus !== status.tobeApproved);
        }
        case status.cancel: {
            if (window.location.hash.toString().includes("leaveManagement/leaveHistory") || window.location.hash.toString().includes("permission/permissionHistory")) { // Cancel -> Status - 'A' only selectable on leave history
                return !(requestStatus === status.tobeApproved || requestStatus === status.approved);
            }
            return !(requestStatus === status.approved || requestStatus === status.tobeCancelled); // Cancel -> Status - 'A' and Status - 'TC'  selectable
        }
        case status.tobeApproved: { // Approve or Rejecte State
            return (requestStatus !== status.tobeApproved);
        }
        default: {
            return false;
        }
    }
}

export const nameConcatenation = (employeeDetails) => {
    return `${("firstName" in employeeDetails) && employeeDetails.firstName ? employeeDetails.firstName : ""}${("middleName" in employeeDetails) && employeeDetails.middleName ? " " + employeeDetails.middleName : ""}${("lastName" in employeeDetails) && employeeDetails.lastName ? " " + employeeDetails.lastName : ""}`;
}

export const periodOptionsWithoutPayroll = [
    { label: "All", value: 1 },
    { label: "Custom", value: 2 },
    { label: "This Year", value: 7 },
    { label: "Last 6 Months", value: 5 },
    { label: "Last 3 Months", value: 4 },
    { label: "Last 30 Days", value: 3 },
    { label: "Last 7 Days", value: 6 },
    { label: "Today and Yesterday", value: 9 },
    { label: "Today", value: 8 },
    { label: "Yesterday", value: 10 },
]
export const policyOptions = [
    { label: "No Expiry", value: 0 },
    { label: "3 Months", value: 3 },
    { label: "6 Months", value: 6 },
    { label: "1 Year", value: 12 },
]

export const LeaveReportOptions = [
    { label: "Employee Attendance", value: 1 },
    { label: "TotalHours Worked", value: 2 },
    { label: "Leave Availed Detailed Report", value: 3 }
]

export const TooltipSlotProps = {
    popper: {
        modifiers: [
            {
                name: 'offset',
                options: {
                    offset: [0, -5],
                },
            },
        ],
    },
}

export const onSelectSearchformatOptionLabel = (data) => {
    return (
        <div className=' flex items-center gap-2'>
            {Object.hasOwn(data, "image") && data.image?.length > 0 ? <img className=' h-8 w-8 rounded-full' src={`data:image/jpeg/png;base64,${data.image}`} alt='#' /> : <Avatar className=' max-h-8 max-w-[2rem] !text-13px !bg-[#b1b1b1]' >{data.label.split(" ").map(val => val[0]).join("")}</Avatar>}
            <span>{data.label}</span>
        </div>
    )
}
export const recordEventsDuration = [
    { label: "One day", value: 1 },
    { label: "Multiple Days", value: 2 }
]
export const getNumberOfYears = (fromDate, toDate) => {
    const fromYear = moment(fromDate).year();
    const toYear = moment(toDate).year();
    return Array.from({ length: toYear - fromYear + 1 }, (v, i) => fromYear + i);
}

export const searchEventOptions = [
    { label: "All", value: 0 },
    { label: "Type", value: 1 },
    { label: "Topic", value: 2 },
    { label: "Description", value: 3 },
];

export const ViewComponentDesign = ({ label, value, valueAddStyle, setValueBold }) => {
    return <>
        <div className=' col-start-1 col-end-5 md:col-end-5 xms:col-end-6 mt-[2.5px]'>
            <Label label={label} setBold={true} />
        </div>
        <div className=' col-start-5 md:col-start-5 xsm:col-start-6 col-end-13'>
            <div className=' flex gap-x-2'>:<span className=' mt-[2.5px]'><Label label={value} setBold={setValueBold} addStyle={valueAddStyle} /></span></div>
        </div>
    </>
};
ViewComponentDesign.propTypes = {
    label: PropTypes.string,
    value: PropTypes.string,
    valueAddStyle: PropTypes.string,
    setValueBold: PropTypes.bool
}

export const treeDataFormation = async (data, keyValue) => {
    let usChild = []
    await data.departments.forEach((value, index) => {
        usChild = [...usChild,
        {
            key: `${keyValue}-${index}`,
            title: value.departmentName,
            children: value.employees.map((innervalue, innerindex) => ({
                ...innervalue,
                key: `${keyValue}-${index}-${innerindex}`,
                title: innervalue.employeeName,
                ischild: true,
            }))
        },
        ];
    })
    return usChild;
}

export const compareFloatingHolidayList = (arr1, arr2) => {
    if (arr1.length !== arr2.length)
        return false;
    for (const firstIndex in arr1) {
        for (const secondIndex in arr1[firstIndex]) {
            const firstObj = arr1[firstIndex][secondIndex];
            const secondObj = arr2[firstIndex][secondIndex];

            if (firstObj.holidayName !== secondObj.holidayName || (!!(firstObj.isUsed) !== !!(secondObj.isUsed))) {
                return false;
            }
        }
    }
    return true;
}

export const onFloatingHolidayReturnCheckBoxIcon = (params) => {
    if (params.data[`${params.colDef.headerName}CheckboxType`]) {
        switch (params.data[`${params.colDef.headerName}CheckboxType`]) {
            case floatingHolidayTypes.empty:
                return <TbSquare size={18} color={params.data[`${params.colDef.headerName}Color`]} className=" stroke-[2.4px]" />
            case floatingHolidayTypes.checked:
                return <FaRegSquareCheck size={18} color={params.data[`${params.colDef.headerName}Color`]} className=" stroke-[4px]" />
            case floatingHolidayTypes.unChecked:
                return <PiXSquare size={20.5} color={params.data[`${params.colDef.headerName}Color`]} className=" stroke-[4px]" />
            default:
                return "";
        }
    }
    return ""
}

export const getDateDifference = (date1, date2, isWeekday) => {
    if (date1 && date2 && moment(date1).isValid() && moment(date2).isValid()) {
        let currentDifference = moment(date2).diff(date1, "days");
        currentDifference = typeof (currentDifference) === "number" ? (currentDifference + 1) : 0;
        if (isWeekday) {
            const isValidHoliday = (selectedDate) => {
                const day = moment(selectedDate).get("day");
                return day !== 0 && day !== 6;
            }
            let count = 0;
            for (let i = 0; i < currentDifference; i++) {
                const selectedDate = moment(date1).add(i, "days");
                if (isValidHoliday(selectedDate)) {
                    count += 1;
                }
            }
            return count;
        }
        return currentDifference;
    }
    return "";
}

export const agGridDateHeaderComponent = ({ displayName, isOnlyDateAndMonth, isCenterView }) => {
    return <div className={`text-center flex !flex-col ag-header ag-header-cell-label !border-0 ${isCenterView ? 'items-center' : 'items-start'}`}><div>{displayName}</div><div className=' text-12px'>{store.getState().user.LocationID === setDefaultValue.location.value ? (isOnlyDateAndMonth ? "(DD/MM)" : "(DD/MM/YYYY)") : (isOnlyDateAndMonth ? "(MM/DD)" : "(MM/DD/YYYY)")}</div></div>
}


export const getLeaveDetails = async (date) => {
    const year = exportYearFormat(date);
    let holidays = holidayReducerState().holidays;
    let tempData = {};
    if (holidays && holidays.length > 0) {
        const validData = holidays.find(val => val.year === year);
        if (validData) {
            return validData
        }
    }
    await store.dispatch(holidayRequests.getHolidayDetailsForRestrictions({ employeeId: 0, locationId: userReducerState().LocationID, year }, async (data) => {
        let holidayDates = [];
        if (data.length > 0) {
            for (const holiday of data) {
                if ("holidayDate" in holiday && holiday.holidayDate?.length > 0) {
                    holidayDates = [...holidayDates, ...holiday.holidayDate.map(val => dateFormat(val))]
                }
            }
        }
        tempData = { year, holidayDetails: data, holidayDates }
        holidays = [...holidays, tempData];
        await store.dispatch(holidayActions.setHolidays(holidays));
    }));
    return tempData;
}

export const getEmployeeBasedLeaveDetails = async (employeeId, locationId, date) => {
    const year = exportYearFormat(date);
    let employeeHolidays = structuredClone(holidayReducerState().employeeBasedHolidays);
    if (employeeHolidays && employeeHolidays.length > 0) {
        const validData = employeeHolidays.find(val => val.empId === employeeId);
        if (validData?.holidays.find(val => val.year === year)) {
            return validData.holidays;
        }
    }
    let tempData = {};
    await store.dispatch(holidayRequests.getHolidayDetailsForRestrictions({ employeeId: employeeId, locationId: locationId, year }, async (data) => {
        let holidayDates = [];
        const filteredData = data && data.length > 0 ? data.filter(val => (("isOptional" in val) && val.isOptional) ? !!(("isEmployeeFloating" in val) && val.isEmployeeFloating) : true) : [];
        if (filteredData.length > 0) {
            for (const holiday of filteredData) {
                if ("holidayDate" in holiday && holiday.holidayDate?.length > 0) {
                    holidayDates = [...holidayDates, ...holiday.holidayDate.map(val => dateFormat(val))]
                }
            }
        }
        tempData = { year, holidayDetails: filteredData, holidayDates }
        const validIndex = employeeHolidays.findIndex(val => val.empId === employeeId);
        if (typeof validIndex === "number" && validIndex >= 0) {
            let holidayLists = employeeHolidays[validIndex].holidays;
            const validYear = holidayLists.findIndex(val => val.year === year);
            if (typeof validYear === "number" && validYear >= 0) {
                employeeHolidays[validIndex].holidays[validYear] = tempData;
            } else {
                employeeHolidays[validIndex].holidays = [...employeeHolidays[validIndex].holidays, tempData];
            }
        } else {
            employeeHolidays = [...employeeHolidays, { empId: employeeId, holidays: [tempData] }];
        }

        await store.dispatch(holidayActions.setEmployeeBasedHolidays(employeeHolidays));
    }));
    return tempData;
}

export const numberConversion = (number) => {
    return number && !isNaN(Number(number)) ? Number(number) : number;
}

export const floatingHolidayColorCodes = {
    optional: { color: "#ffe9df", legendColor: "#fbe3d9", name: "Floating Holiday" },
    selected: { color: "#edffeb", legendColor: "#d1f3cf", name: "Selected Floating Holiday" }
}

export const usFederalHolidays = (year) => {
    const options = { shiftSaturdayHolidays: true, shiftSundayHolidays: true };
    const holidays = fedHolidays.allForYear(year, options);
    if (holidays) {
        return { data: holidays, message: "US federal holiday details retrieved  successfully", status: true };
    }
    return { data: [], message: "No valid US federal holidays found for the specified range.", status: false };
}

export function getMinutesBetweenDates(startDate, endDate) {
    const diff = endDate.getTime() - startDate.getTime();
    return (diff / 3600000);
}

export const halfDayOptions = [
    { label: "Full Day", value: "F" },
    { label: "Half Day", value: "H" }
]

export const dayWithDateFormat = (givenDate, isConcatenated) => {
    if (givenDate && !isNaN(new Date(givenDate))) {
        const date = new Date(givenDate);
        if (isConcatenated) {
            return moment(date).format("ddd MM/DD");
        }
        return { day: moment(date).format("ddd"), date: moment(date).format("MM/DD") };
    }
    return '';
}

export const dayWithDateFormatElement = (date) => {
    const formattedDate = dayWithDateFormat(date);
    if (formattedDate) {
        return <div className=" flex"><div className=" w-7 text-right mr-2">{formattedDate.day}</div> {formattedDate.date}</div>;
    }
    return <></>
}

export const dragReorder = (list, startIndex, endIndex) => {
    const result = Array.from(list);
    const [removed] = result.splice(startIndex, 1);
    result.splice(endIndex, 0, removed);

    return result;
};

export const findCheckedKeys = (treeData, checkedData) => {
    let checkedKeys = [];
    (treeData).forEach(value => {
        if (Object.hasOwn(value, "employeeId") && checkedData && checkedData.length > 0) {
            if (checkedData.find(val => val.employeeId === value.employeeId)) {
                checkedKeys = [...checkedKeys, value.key];
            }
        }
        if (value.children) {
            let childData = findCheckedKeys(value.children, checkedData);
            if (childData && childData.length > 0) { checkedKeys = checkedKeys.concat(childData) }
        }
    })
    return checkedKeys;
}


export const findParents = (nodes, keys) => {
    let ancestorMap = new Set();
    const traverse = (node, ancestors) => {
        if (keys.includes(node.key)) {
            ancestors.forEach(ancestor => ancestorMap.add(ancestor));
        }
        if (node.children) {
            node.children.forEach(child => traverse(child, [...ancestors, node.key]));
        }
    };
    nodes.forEach(node => traverse(node, []));
    return Array.from(ancestorMap);
};

export const findAllChildCheckedParent = (nodes, keys, checkedKeys) => {
    let allChildCheckedParent = [];
    const findCheckedPrent = (nodes) => {
        nodes.forEach(node => {
            if (keys.includes(node.key) && node.children) {
                let checkedChildKey = (node.children.filter(child => checkedKeys.includes(child.key)))
                if (checkedChildKey.length === node.children.length) {
                    allChildCheckedParent.push(node.key);
                }
            }
            if (node.children) {
                findCheckedPrent(node.children)
            }
        })
    }
    findCheckedPrent(nodes)
    return allChildCheckedParent;
}

export const getChildKeys = (treedata, key) => {
    let childKeys = [];
    const traverse = (nodes) => {
        if (!nodes) return;

        for (const node of nodes) {
            childKeys.push(node.key);
            if (node.children) {
                traverse(node.children);
            }
        }
    };
    const findChildKeys = (nodes) => {
        nodes.forEach(node => {
            if (node.key === key && node.children) {
                traverse(node.children);
            }
            if (node.children) {
                findChildKeys(node.children);
            }
        });
    };
    findChildKeys(treedata);
    return childKeys;
};


export const findCheckedValues = (treedata, checkedvalue, participationId, presentedValue) => {
    let checkedNode = [];
    treedata.forEach(value => {
        if (checkedvalue.includes(value.key) && value.ischild) {
            let eventAttendeeID = presentedValue.find(val => val.employeeId === value.employeeId);
            checkedNode = [...checkedNode, {
                "employeeId": value.employeeId,
                "eventAttendeeID": (eventAttendeeID && Object.keys(eventAttendeeID).length > 0) ? eventAttendeeID.eventAttendeeID : 0,
                "eventAttendeeType": "I",
                "eventId": 0,
                "participationLevelID": participationId
            }]
        }
        if (value.children) {
            let childData = findCheckedValues(value.children, checkedvalue, participationId, presentedValue);
            if (childData.length > 0) { checkedNode = checkedNode.concat(childData) }
        }
    });
    return checkedNode;
}

export const getCheckedValues = (data, targetKeys, disableKeys) => {
    let result = [];
    data.forEach(parent => {
        let filteredDepartments = [];
        parent.children.forEach(department => {
            let filteredChildren = department.children
                .filter(child => targetKeys.includes(child.key))
                .map(child => ({
                    ...child,
                    ...(disableKeys?.includes(child.key) ? { isDisable: true } : {})
                }));
            if (filteredChildren.length > 0) {
                filteredDepartments.push({ ...department, children: filteredChildren });
            }
        });
        if (filteredDepartments.length > 0) {
            result.push({ ...parent, children: filteredDepartments });
        }
    });
    return result;
}


export const collectKeys = (nodes, searchValue, treeData) => {
    let keysToExpand = [];
    const traverse = (nodes) => {
        nodes.forEach((node) => {
            if (node.title.toLowerCase().includes(searchValue.toLowerCase())) {
                if (!node.children) {
                    keysToExpand.push(node.key);
                    const parentKey = findParents(treeData, [node.key]);
                    if (parentKey && parentKey.length > 0) {
                        parentKey.forEach(val => {
                            if (!keysToExpand.includes(val)) {
                                keysToExpand.push(val);
                            }
                        });
                    }
                }
            }
            if (node.children) {
                traverse(node.children);
            }
        });
    };

    traverse(nodes);
    return keysToExpand;
}

export const getTreeKeys = (nodes) => {
    const allKeys = [];
    const parentKeys = [];
    const traverse = (nodeList) => {
        nodeList.forEach((node) => {
            allKeys.push(node.key);
            if (node.children && node.children.length > 0) {
                parentKeys.push(node.key);
                traverse(node.children);
            }
        });
    };
    traverse(nodes);
    return { allKeys, parentKeys };
};