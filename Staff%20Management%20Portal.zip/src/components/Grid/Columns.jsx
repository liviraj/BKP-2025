/* eslint-disable react-refresh/only-export-components */
/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import { ContextMenu, MenuItem, ContextMenuTrigger, SubMenu } from "react-contextmenu";
import { FiEdit } from 'react-icons/fi';
import { HiOutlineClipboardList } from 'react-icons/hi';
import { classNames, leaveDetails, reportFields, setDefaultValue, strings, status, permissionTypes, floatingHolidayColors, floatingHolidayTypes, HolidayNameStatus } from '../Constants';
import { store } from '../../redux/store';
import { employeeRequests, eventManagementRequests, leaveManagementRequest, loginRequest, loginUserRequest, myRequestRequests, permissionRequests, reportRequest, userRequest, wfhRequest, deputationRequest, timeInTimeOutRequest, documentPolicyRequest, designationRequest } from '../requests';
import { agGridDateHeaderComponent, complianceReportDateFormat, dateAndTimeFormat, dateFormat, employeeReducerState, filterParams, isPartOfClinicalUser, leaveRequestApprovalValidation, leaveStatus, monthAndDateFormat, onFloatingHolidayReturnCheckBoxIcon, timeFormat, userReducerState, dayWithDateFormatElement, timeInOutReducerState } from '../helper';
import { MdOutlineAddBox, MdOutlineNotificationsActive } from 'react-icons/md';
import { ImBin, ImEye } from 'react-icons/im';
import { PiPlusSquareBold, PiTreeView } from 'react-icons/pi'
import { TiTick, TiCancel } from 'react-icons/ti';
import { IoClose } from 'react-icons/io5';
import { leaveManagementActions } from '../../redux/leaveManagementReducer';
import FormatFilter from './FormatFilter';
import { loginActions } from '../../redux/loginReducer';
import { myRequestActions } from '../../redux/myRequestReducer';
import { eventManagementActions } from '../../redux/eventManagementReducer';
import { VscPreview } from "react-icons/vsc";
import { permissionAction } from "../../redux/permissionReducer";
import { holidayActions } from "../../redux/holidayReducer";
import { departmentActions } from "../../redux/departmentReducer";
import { attendancePayrollActions } from "../../redux/AttendancePayrollReducer";
import { supervisorActions } from "../../redux/supervisorReducer";
import { designationActions } from "../../redux/DesignationReducer";
import { deputationActions } from "../../redux/DeputationReducer";
import { complianceReportActions } from "../../redux/complianceReportReducer";
import moment from "moment";
import PropTypes from "prop-types";
import { wfhActions } from "../../redux/wfhReducer";
import { timeInTimeOutActions } from "../../redux/TimeInTimeOutReducer";
import { ComplianceAgreementActions } from "../../redux/ComplianceAgreementReducer";
import { LiaUserCheckSolid } from "react-icons/lia";
import { FaRegFilePdf } from "react-icons/fa";
import MenuView from "../elements/MenuView";
import { TbCheckupList } from "react-icons/tb";
import { AddComplianceRequestAction } from "../../redux/AddComplianceRequest";




export const employeeDetails = {
    columns: (history, isMobileCompatible) => {

        const staffColumns = [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                checkboxSelection: !isMobileCompatible,
                filter: false,
                minWidth: 85, excelWidth: 7,
                maxWidth: 85
            },
            {
                headerName: "Employee Code",
                field: "employeeCode",
                minWidth: 140, excelWidth: 20,
                maxWidth: 140,
                cellRenderer: params => SetContextMenuTrigger({ params }),
                filter: true
            },
            {
                headerName: "Date Of Joining",
                headerComponent: agGridDateHeaderComponent,
                field: "doj",
                minWidth: 140, excelWidth: 16,
                maxWidth: 140,
                // floatingFilterComponent: FloatingFilterDatePicker,
                filter: FormatFilter,
                suppressMenu: true,
                floatingFilterComponentParams: {
                    suppressFilterButton: false,
                    color: 'orange',
                },
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true })
            },
            {
                headerName: "Employee Name",
                field: "employeeName",
                minWidth: 230, excelWidth: 35,
                cellRenderer: params => SetContextMenuTrigger({
                    params, isSelectable: true, onClick: async () => {
                        await store.dispatch(employeeRequests.loader(true));
                        await store.dispatch(employeeRequests.employeeDetails(params.data, history));
                        store.dispatch(employeeRequests.loader(false));
                    }
                }),

            },
            {
                headerName: "Designation",
                field: "designation",
                minWidth: 280, excelWidth: 40,
                width: 280,
                filter: false,
                cellRenderer: params => SetContextMenuTrigger({ params })
            },
            {
                headerName: "Section",
                field: "department",
                minWidth: 120, excelWidth: 27,
                // maxWidth: 180,
                filter: false,
                cellRenderer: params => SetContextMenuTrigger({ params })
            },
            {
                headerName: "Location",
                field: "location",
                minWidth: 100, excelWidth: 10,
                maxWidth: 100,
                filter: false,
                filterParams: filterParams.typeFormat(['USA', 'INDIA']),
                cellRenderer: params => SetContextMenuTrigger({ params })
            },
            {
                headerName: "Employment Status",
                field: "employeeStatus",
                minWidth: 140, excelWidth: 20,
                maxWidth: 170,
                filter: false,
                filterParams: filterParams.typeFormat([setDefaultValue.employmentStatus.confirmed, setDefaultValue.employmentStatus.relieved, setDefaultValue.employmentStatus.probation]),
                cellRenderer: params => SetContextMenuTrigger({ params })
            },
            {
                headerName: "Employee Type",
                field: "employeeType",
                minWidth: 120, excelWidth: 20,
                filter: false,
                filterParams: filterParams.typeFormat(['Consultant', 'Full Time Employee', 'Intern', 'Part Time Employee', 'Temporary']),
                cellRenderer: params => SetContextMenuTrigger({ params })
            },
            {
                headerName: "Clinical User",
                field: "clinicalHandler",
                minWidth: 120, excelWidth: 15,
                maxWidth: 125,
                filter: false,
                filterParams: filterParams.keyFormat([{ label: 'Yes', value: true }, { label: 'No', value: false }]),
                cellRenderer: params => SetContextMenuTrigger({ params, isBoolean: true })
            }

        ];
        return isMobileCompatible ? [...staffColumns, {
            headerName: "Actions",
            field: "actions",
            cellRenderer: params => {
                const selectedRow = params.data;
                const isViewable = Object.hasOwn(selectedRow, "employeeStatus") && selectedRow.employeeStatus && selectedRow.employeeStatus === setDefaultValue.employmentStatus.relieved;
                const onhandleNavigate = async () => {
                    await store.dispatch(employeeRequests.loader(true));
                    await store.dispatch(employeeRequests.getEmployee_Personal(selectedRow, history));
                    await store.dispatch(employeeRequests.loader(false));
                }
                return <div className=" h-full w-full flex items-center justify-center ml-5">
                    <span className='flex items-center text-headerColor cursor-pointer' onClick={onhandleNavigate}>
                        {isViewable ?
                            <ImEye size={18} /> : <FiEdit size={18} />}
                        <span className='mx-2'>{isViewable ? "View" : "Edit"}</span>
                    </span>

                </div>
            },
            lockPosition: 'right',
            pinned: 'right',
            sortable: false,
            headerClass: " !pl-2 !pr-1",
            filter: false,
            minWidth: 70,
            maxWidth: 70
        }] : staffColumns;
    },
    qualificationColumns: () => [
        {
            headerName: "Degree",
            field: "qualification",
            minWidth: 120,
            maxWidth: 160,
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Institution",
            field: "institution",
            minWidth: 140,
            width: 160,
            cellRenderer: params => SetContextMenuTrigger({ params })
        },
        {
            headerName: "Completed On",
            field: "courseEndDate",
            minWidth: 120,
            maxWidth: 160,
            cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
        },
        {
            headerName: "Certificate Image",
            field: "qualificationId",
            minWidth: 120,
            maxWidth: 200,
            cellRenderer: params => SetContextMenuTrigger({
                params, isDocumentView: true, onClick: async () => {
                    await store.dispatch(employeeRequests.loader(true));
                    await store.dispatch(employeeRequests.viewMultipleDocuments("employeeDetails/qualificationCertificate", params.value, "documentDetails", "Qualification"));
                    store.dispatch(employeeRequests.loader(false));
                }
            }),
        }
    ],
    ContextMenuItems: ({ selectedRow, history }) => {
        const isViewable = selectedRow && Object.hasOwn(selectedRow, "employeeStatus") && selectedRow.employeeStatus && selectedRow.employeeStatus === setDefaultValue.employmentStatus.relieved;
        return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
            <MenuItem
                data={{ menu: "EditEmployeeDetails", history: history }}
                className={classNames.contextMenuItem}
                onClick={(e, data) => handleClick(e, data, selectedRow)}
            >
                {isViewable ?
                    <span className='flex items-center'> <ImEye size={18} /> <span className='mx-2'>View</span></span> :
                    <span className='flex items-center'> <FiEdit size={18} /> <span className='mx-2'>Edit</span></span>
                }
            </MenuItem>
        </ContextMenu>)
    },
    workHistory_columns: (setLoaderValue, isDetailPopup, isMobileCompatible, callBackFunc) => {
        const workHistoryColumns = [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                checkboxSelection: isDetailPopup,
                minWidth: 85,
                maxWidth: 85
            },
            {
                headerName: "Employer Name",
                field: "employerName",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 150,
            },
            {
                headerName: "Designation",
                field: "designation",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 120,
            },
            {
                headerName: "Date Of Join",
                field: "dateOfJoin",
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                minWidth: 140,
                maxWidth: 140,
            },
            {
                headerName: "Date Of Relieve",
                field: "relievingDate",
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                minWidth: 150,
                maxWidth: 160,
            },
            {
                headerName: "Reported To",
                field: "reportingTo",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 120,
            },
            {
                headerName: "Certificate Image",
                field: "employeeWorkHistoryId",
                cellRenderer: params => SetContextMenuTrigger({
                    params, isDocumentView: true, onClick: async () => {
                        await setLoaderValue(true);
                        await store.dispatch(employeeRequests.viewMultipleDocuments("workHistory", params.value, "documentDetails", "Work History"));
                        setLoaderValue(false);
                    }
                }),
                minWidth: 150,
                maxWidth: 160,
            },
        ];
        return isMobileCompatible ? [...workHistoryColumns, {
            headerName: "Actions",
            field: "actions",
            cellRenderer: params => {
                const selectedRow = params.data;
                const isViewable = employeeReducerState().employeeModule.isDisable;
                return <div className=" h-full w-full flex items-center justify-center ml-5 gap-2">
                    <span className='flex items-center text-headerColor cursor-pointer' onClick={() => callBackFunc(selectedRow, "isEdit")}>
                        {isViewable ? <ImEye size={18} /> : <FiEdit size={18} />}
                        {isViewable && <span className='mx-2'>View</span>}
                    </span>
                    {!isViewable && <span className='flex items-center text-headerColor cursor-pointer' onClick={() => callBackFunc(selectedRow, "isDelete")} > <ImBin size={16.5} /></span>}
                </div>
            },
            lockPosition: 'right',
            pinned: 'right',
            sortable: false,
            headerClass: " !pl-2 !pr-1",
            filter: false,
            minWidth: 70,
            maxWidth: 70
        }] : workHistoryColumns;
    },
    workHistory_contextMenuItems: ({ selectedRow, history, callBackFunc }) => {
        const isViewable = employeeReducerState().employeeModule.isDisable;
        return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
            <MenuItem
                data={{ menu: "EditWorkHistoryDetails", history: history }}
                className={classNames.contextMenuItem}
                onClick={() => callBackFunc(selectedRow, "isEdit")}
            >
                {isViewable ?
                    <span className='flex items-center'> <ImEye size={18} /> <span className='mx-2'>View</span></span> :
                    <span className='flex items-center'> <FiEdit size={18} /> <span className='mx-2'>Edit</span></span>
                }
            </MenuItem>
            {!isViewable && <MenuItem
                className={classNames.contextMenuItem}
                onClick={() => callBackFunc(selectedRow, "isDelete")}
            >
                <span className='flex items-center'> <ImBin size={16.5} /> <span className='mx-2'>Delete</span></span>
            </MenuItem>}
        </ContextMenu>)
    },
    continuousEducationDetailViewColumns: () => [
        {
            headerName: "Course Name",
            field: "courseName",
            minWidth: 140,
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Conducted By",
            field: "conductedBy",
            minWidth: 140,
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Duration",
            field: "courseDuration",
            minWidth: 120,
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Category",
            field: "courseCategory",
            minWidth: 120,
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Certificate Image",
            field: "continousEducationId",
            minWidth: 120,
            cellRenderer: params => SetContextMenuTrigger({
                params, isDocumentView: true, onClick: async () => {
                    await store.dispatch(employeeRequests.loader(true));
                    await store.dispatch(employeeRequests.viewMultipleDocuments("employeeDetails/continuousEducationCertificate", params.value, "", "Continuous Education"));
                    store.dispatch(employeeRequests.loader(false));
                }
            }),
        }
    ],
    continuousEducationColumns: (setLoader, isMobileCompatible, callBackFunc) => {
        const continuousEducationCols = [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                checkboxSelection: !isMobileCompatible,
                minWidth: 85,
                maxWidth: 85
            },
            {
                headerName: "Course Name",
                field: "courseName",
                minWidth: 150,
                width: 200,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Conducted By",
                field: "conductedBy",
                minWidth: 150,
                width: 150,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Sponsored By",
                field: "sponsoredBy",
                minWidth: 150,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Duration",
                field: "courseDuration",
                minWidth: 100,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Description",
                field: "courseDescription",
                minWidth: 150,
                width: 150,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Category",
                field: "courseCategory",
                minWidth: 120,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Certificate Image",
                field: "id",
                minWidth: 150,
                maxWidth: 160,
                cellRenderer: params => SetContextMenuTrigger({
                    params, isDocumentView: true, onClick: async () => {
                        await setLoader(true)
                        await store.dispatch(employeeRequests.viewMultipleDocuments("continousEducation", params.data.id, "documentList", "Continuous Education"));
                        setLoader(false);
                    }
                }),
            }
        ];
        return isMobileCompatible ? [...continuousEducationCols, {
            headerName: "Actions",
            field: "actions",
            cellRenderer: params => {
                const selectedRow = params.data;
                const isViewable = employeeReducerState().employeeModule.isDisable;

                return <div className=" h-full w-full flex items-center justify-center ml-5 gap-2">
                    <span className='flex items-center text-headerColor cursor-pointer' onClick={() => callBackFunc(selectedRow, "isEdit")}>
                        {isViewable ?
                            <ImEye size={18} /> : <FiEdit size={18} />}
                        {isViewable && <span className='mx-2'>View</span>}
                    </span>
                    {!isViewable && <span className='flex items-center text-headerColor cursor-pointer' onClick={() => callBackFunc(selectedRow, "isDelete")} > <ImBin size={16.5} /> </span>}
                </div>
            },
            lockPosition: 'right',
            pinned: 'right',
            sortable: false,
            headerClass: " !pl-2 !pr-1",
            filter: false,
            minWidth: 70,
            maxWidth: 70
        }] : continuousEducationCols;
    },
    continuousEducation_contextMenuItems: ({ selectedRow, history, callBackFunc }) => {
        const isViewable = employeeReducerState().employeeModule.isDisable;
        return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
            <MenuItem
                data={{ menu: "EditEducationDetails", history: history }}
                className={classNames.contextMenuItem}
                onClick={() => callBackFunc(selectedRow, "isEdit")}
            >
                {isViewable ?
                    <span className='flex items-center'> <ImEye size={18} /> <span className='mx-2'>View</span></span> :
                    <span className='flex items-center'> <FiEdit size={18} /> <span className='mx-2'>Edit</span></span>
                }
            </MenuItem>
            {!isViewable && <MenuItem
                className={classNames.contextMenuItem}
                onClick={() => callBackFunc(selectedRow, "isDelete")}
            >
                <span className='flex items-center'> <ImBin size={16.5} /> <span className='mx-2'>Delete</span></span>
            </MenuItem>}
        </ContextMenu>)
    },
    nysComplianceColumns: (setLoader, isMobileCompatible, callBackFunc) => {

        const nysComplianceColumns = [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                checkboxSelection: !isMobileCompatible,
                minWidth: 80,
                maxWidth: 80
            },
            {
                headerName: "Compliance Category",
                field: "complianceCategory",
                minWidth: 200,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Compliance Period",
                field: "compliancePeriod",
                minWidth: 200,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Compliance Date",
                field: "complianceDate",
                minWidth: 150,
                maxWidth: 160,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
            },
            {
                headerName: "Expiry Date",
                field: "expiryDate",
                minWidth: 120,
                maxWidth: 130,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
            },
            {
                headerName: "Description",
                field: "description",
                minWidth: 200,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Document Image",
                field: "employeeComplianceId",
                minWidth: 150,
                maxWidth: 150,
                cellRenderer: params => SetContextMenuTrigger({
                    params, isDocumentView: true, onClick: async () => {
                        await setLoader(true)
                        await store.dispatch(employeeRequests.viewMultipleDocuments("compliance", params.value, "documentDetails", "NYS Compliance"));
                        setLoader(false);
                    }
                }),
            }
        ];
        return isMobileCompatible ? [...nysComplianceColumns, {
            headerName: "Actions",
            field: "actions",
            cellRenderer: params => {
                const selectedRow = params.data;
                const isViewable = employeeReducerState().employeeModule.isDisable;
                return <div className=" h-full w-full flex items-center justify-center gap-2 ml-4">
                    <span className='flex items-center text-headerColor cursor-pointer' onClick={() => callBackFunc(selectedRow, "Edit")}>
                        {isViewable ? <ImEye size={18} /> : <FiEdit size={18} />}
                    </span>
                    {!isViewable && <span className=" flex items-center text-headerColor cursor-pointer" onClick={() => callBackFunc(selectedRow, "Delete")}>
                        <ImBin size={16.5} />
                    </span>}
                </div>
            },
            lockPosition: 'right',
            pinned: 'right',
            sortable: false,
            headerClass: " !pl-2 !pr-1",
            filter: false,
            minWidth: 70,
            maxWidth: 70
        }] : nysComplianceColumns;
    },
    nysCompliance_contextMenuItems: ({ selectedRow, history, callBackFunc }) => {
        const isViewable = employeeReducerState().employeeModule.isDisable;
        return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
            <MenuItem
                data={{ menu: "EditNysCompliance", history: history }}
                className={classNames.contextMenuItem}
                onClick={() => callBackFunc(selectedRow, "Edit")}
            >
                {isViewable ?
                    <span className='flex items-center'> <ImEye size={18} /> <span className='mx-2'>View</span></span> :
                    <span className='flex items-center'> <FiEdit size={18} /> <span className='mx-2'>Edit</span></span>
                }
            </MenuItem>
            {!isViewable && <MenuItem
                data={{ menu: "DeleteNysCompliance", history: history }}
                className={classNames.contextMenuItem}
                onClick={() => callBackFunc(selectedRow, "Delete")}
            >
                <span className='flex items-center'> <ImBin size={16.5} /> <span className='mx-2'>Delete</span></span>
            </MenuItem>}
        </ContextMenu>)
    },
    trainingColumns: (setLoader, isMobileCompatible, callBackFunc) => {
        const trainingColumns = [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                checkboxSelection: !isMobileCompatible,
                minWidth: 85,
                maxWidth: 85
            },
            {
                headerName: "Training Category",
                field: "trainingCategory",
                minWidth: 80,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Training From",
                field: "trainingFrom",
                minWidth: 80,
                maxWidth: 150,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
            },
            {
                headerName: "Training To",
                field: "trainingTo",
                minWidth: 80,
                maxWidth: 120,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
            },
            {
                headerName: "Purpose",
                field: "purpose",
                minWidth: 80,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Certificate Image",
                field: "employeeTrainingId",
                minWidth: 80,
                maxWidth: 160,
                cellRenderer: params => SetContextMenuTrigger({
                    params, isDocumentView: true, onClick: async () => {
                        await setLoader(true)
                        await store.dispatch(employeeRequests.viewMultipleDocuments("training", params.value, "documentList", "Training"));
                        setLoader(false);
                    }
                }),
            }
        ]
        return isMobileCompatible ? [...trainingColumns, {
            headerName: "Actions",
            field: "actions",
            cellRenderer: params => {
                const selectedRow = params.data;
                const isViewable = employeeReducerState().employeeModule.isDisable;
                return <div className=" h-full w-full flex items-center justify-center gap-2 ml-4">
                    <span className='flex items-center text-headerColor cursor-pointer' onClick={() => callBackFunc(selectedRow, "Edit")}>
                        {isViewable ? <ImEye size={18} /> : <FiEdit size={18} />}
                    </span>
                    {!isViewable && <span className=" flex items-center text-headerColor cursor-pointer" onClick={() => callBackFunc(selectedRow, "Delete")}>
                        <ImBin size={16.5} />
                    </span>}
                </div>
            },
            lockPosition: 'right',
            pinned: 'right',
            sortable: false,
            headerClass: " !pl-2 !pr-1",
            filter: false,
            minWidth: 70,
            maxWidth: 70
        }] : trainingColumns;
    },
    training_contextMenuItems: ({ selectedRow, history, callBackFunc }) => {
        const isViewable = employeeReducerState().employeeModule.isDisable;
        return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
            <MenuItem
                data={{ menu: "EditTrainingDetails", history: history }}
                className={classNames.contextMenuItem}
                onClick={() => callBackFunc(selectedRow, "Edit")}
            >
                {isViewable ?
                    <span className='flex items-center'> <ImEye size={18} /> <span className='mx-2'>View</span></span> :
                    <span className='flex items-center'> <FiEdit size={18} /> <span className='mx-2'>Edit</span></span>
                }
            </MenuItem>
            {!isViewable && <MenuItem
                data={{ menu: "DeleteTrainigDetails", history: history }}
                className={classNames.contextMenuItem}
                onClick={() => callBackFunc(selectedRow, "Delete")}
            >
                <span className='flex items-center'> <ImBin size={16.5} /> <span className='mx-2'>Delete</span></span>
            </MenuItem>}
        </ContextMenu>)
    },
    hrDocumentColumns: (setLoader, isMobileCompatible, callBackFunc) => {
        const hrDocumentColumns = [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                checkboxSelection: !isMobileCompatible,
                minWidth: 85,
                maxWidth: 85
            },
            {
                headerName: "Document Date",
                field: "documentDate",
                minWidth: 150,
                maxWidth: 160,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
            },
            {
                headerName: "Document Type",
                field: "documentType",
                minWidth: 150,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Uploaded By",
                field: "uploadedBy",
                minWidth: 150,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Uploaded On",
                field: "uploadedOn",
                minWidth: 130,
                maxWidth: 130,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
            },
            {
                headerName: "Description",
                field: "description",
                minWidth: 150,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Document Image",
                field: "documentId",
                minWidth: 140,
                maxWidth: 160,
                cellRenderer: params => SetContextMenuTrigger({
                    params, isDocumentView: true, onClick: async () => {
                        await setLoader(true)
                        await store.dispatch(employeeRequests.viewMultipleDocuments("hrDocument", params.value, "documentList", "HR Documents"));
                        setLoader(false);
                    }
                }),
            },
            {
                headerName: "Expiry Date",
                field: "expiryDate",
                minWidth: 130,
                maxWidth: 130,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
            },
        ]
        return isMobileCompatible ? [...hrDocumentColumns, {
            headerName: "Actions",
            field: "actions",
            cellRenderer: params => {
                const selectedRow = params.data;
                const isViewable = employeeReducerState().employeeModule.isDisable;
                return <div className=" h-full w-full flex items-center justify-center gap-2 ml-4">
                    <span className='flex items-center text-headerColor cursor-pointer' onClick={() => callBackFunc(selectedRow, "Edit")}>
                        {isViewable ? <ImEye size={18} /> : <FiEdit size={18} />}
                    </span>
                    {!isViewable && <span className=" flex items-center text-headerColor cursor-pointer" onClick={() => callBackFunc(selectedRow, "Delete")} >
                        <ImBin size={16.5} />
                    </span>}
                </div>
            },
            lockPosition: 'right',
            pinned: 'right',
            sortable: false,
            headerClass: " !pl-2 !pr-1",
            filter: false,
            minWidth: 70,
            maxWidth: 70
        }] : hrDocumentColumns;
    },
    hrDocument_contextMenuItems: ({ selectedRow, history, callBackFunc }) => {
        const isViewable = employeeReducerState().employeeModule.isDisable;
        return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
            <MenuItem
                data={{ menu: "EditHrDocuments", history: history }}
                className={classNames.contextMenuItem}
                onClick={() => callBackFunc(selectedRow, "Edit")}
            >
                {isViewable ?
                    <span className='flex items-center'> <ImEye size={18} /> <span className='mx-2'>View</span></span> :
                    <span className='flex items-center'> <FiEdit size={18} /> <span className='mx-2'>Edit</span></span>
                }
            </MenuItem>
            {!isViewable && <MenuItem
                data={{ menu: "DeleteHrDocuments", history: history }}
                className={classNames.contextMenuItem}
                onClick={() => callBackFunc(selectedRow, "Delete")}
            >
                <span className='flex items-center'> <ImBin size={16.5} /> <span className='mx-2'>Delete</span></span>
            </MenuItem>}
        </ContextMenu>)
    },
    Birthday_Details: () => [
        {
            headerName: "S.No",
            field: "sno",
            comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
            cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
            lockPosition: 'left',
            excelWidth: 10,
            minWidth: 70,
            maxWidth: 100
        },
        {
            headerName: "Employee Name",
            field: "employeeName",
            minWidth: 150,
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Section",
            field: "section",
            minWidth: 150,
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Date Of Birth",
            headerComponent: ({ displayName }) => agGridDateHeaderComponent({ displayName, isOnlyDateAndMonth: true }),
            field: "dateOfBirthDay",
            minWidth: 150,
            cellRenderer: params => <ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{monthAndDateFormat(params.value)}</div></ContextMenuTrigger>,
        }
    ],
    Leave_Details: () => [
        {
            headerName: "S.No",
            field: "sno",
            comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
            cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
            lockPosition: 'left',
            excelWidth: 10,
            minWidth: 70,
            maxWidth: 100
        },
        {
            headerName: "Employee Name",
            field: "employeeName",
            minWidth: 150,
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Section",
            field: "DepartmentName",
            minWidth: 150,
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Leave Type",
            field: "LeaveTypeName",
            minWidth: 150,
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Leave From",
            headerComponent: agGridDateHeaderComponent,
            field: "LeaveFrom",
            minWidth: 150,
            cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
        },
        {
            headerName: "Leave To",
            headerComponent: agGridDateHeaderComponent,
            field: "LeaveTo",
            minWidth: 150,
            cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
        }
    ],
}

export const EmployeeRequest = {
    EmployeeRequestColumns: [
        {
            headerName: "S.No",
            field: "sno",
            comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
            cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
            lockPosition: 'left',
            minWidth: 70,
            maxWidth: 70,
        },
        {
            headerName: "Employee Name",
            field: "employeeName",
            minWidth: 180,
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Number of Leaves Taken",
            headerClass: " !pl-1 felx justify-center ",
            wrapHeaderText: true,
            children: [
                {
                    headerName: "Sick Leave",
                    field: "totalSlCount",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 150,
                    maxWidth: 160,
                },
                {
                    headerName: "Casual Leave",
                    field: "totalClCount",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 150,
                    maxWidth: 160,
                },
                {
                    headerName: "Privilege Leave",
                    field: "totalplCount",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 150,
                    maxWidth: 160,
                },
            ]
        },
        {
            headerName: "Number of Permissions Taken",
            field: "totalPermissionCount",
            minWidth: 230,
            maxWidth: 250,
            cellRenderer: params => SetContextMenuTrigger({ params })
        },
        {
            headerName: "Number of WFHs Taken",
            field: "totalWfhCount",
            minWidth: 190,
            maxWidth: 200,
            cellRenderer: params => SetContextMenuTrigger({ params })
        },
    ],
}

const handleClick = async (_, data, selectedRow) => {
    switch (data.menu) {
        case 'EditEmployeeDetails':
            await store.dispatch(employeeRequests.loader(true));
            await store.dispatch(employeeRequests.getEmployee_Personal(selectedRow, data.history));
            await store.dispatch(employeeRequests.loader(false));
            break;
        case 'EditLoginDetails':
            await store.dispatch(loginRequest.loader(true));
            await store.dispatch(loginUserRequest.getUserDetails(selectedRow, data.history));
            store.dispatch(loginRequest.loader(false));
            break;
        case 'AddEmployeeDetails':
            await store.dispatch(loginRequest.loader(true));
            await store.dispatch(loginUserRequest.getEmployeeDetails(selectedRow.loginid, data.history));
            store.dispatch(loginRequest.loader(false));
            break;
        default:
            console.error("Please ReCheck the Menu list")
    }
}

const SetContextMenuTrigger = ({ params, isBoolean, isDateView, isSelectable, isDocumentView, onClick, isDateAndTimeView, isTimeView, setBgColor }) => {
    const customClassNames = setBgColor ? `${setBgColor} h-full m-0 pl-5 w-full` : classNames.contextMenuValue;
    if (isBoolean) {
        return (<ContextMenuTrigger id="staff_contextmenu_id"><div className={customClassNames}>{typeof (params.value) === "boolean" ? (params.value ? "Yes" : "No") : <div className=' text-transparent w-96'>ContextMenu</div>}</div></ContextMenuTrigger>)
    }
    else if (isDocumentView) {
        return (<ContextMenuTrigger id="staff_contextmenu_id"><div className={customClassNames}>{<span className=" text-blue-600 underline cursor-pointer" onClick={onClick}>View</span>}</div></ContextMenuTrigger>)
    }
    else if (!params.value && params.value !== 0) {
        return (<ContextMenuTrigger id="staff_contextmenu_id"><div className=' text-transparent w-96'>ContextMenu</div></ContextMenuTrigger>)
    }
    else if (isDateView) {
        return (<ContextMenuTrigger id="staff_contextmenu_id"><div className={customClassNames}>{dateFormat(params.value)}</div></ContextMenuTrigger>)
    }
    else if (isDateAndTimeView) {
        return (<ContextMenuTrigger id="staff_contextmenu_id"><div className={customClassNames}>{dateAndTimeFormat(params.value)}</div></ContextMenuTrigger>)
    }
    else if (isTimeView) {
        return (<ContextMenuTrigger id="staff_contextmenu_id"><div className={customClassNames}>{timeFormat(params.value)}</div></ContextMenuTrigger>)
    }

    return (<ContextMenuTrigger id="staff_contextmenu_id"><div className={customClassNames}>{isSelectable ? <span className=" text-blue-600 underline cursor-pointer" onClick={onClick}>{params.value}</span> : params.value}</div></ContextMenuTrigger>)
}

SetContextMenuTrigger.propTypes = {
    params: PropTypes.any.isRequired,
    isBoolean: PropTypes.bool,
    isDateView: PropTypes.bool,
    isSelectable: PropTypes.bool,
    isDocumentView: PropTypes.bool,
    onClick: PropTypes.func,
    isDateAndTimeView: PropTypes.bool,
    isTimeView: PropTypes.bool,
    setBgColor: PropTypes.string
}

export const loginDetails = {
    columns: (history, isMobileCompatible) => {
        const loginColumns = [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                checkboxSelection: !isMobileCompatible,
                filter: false,
                minWidth: 85,
                maxWidth: 85,
                excelWidth: 7,
            },
            {
                headerName: "Employee Name",
                field: "employeeName",
                minWidth: 100,
                cellRenderer: params => SetContextMenuTrigger({ params }),
                excelWidth: 40,
            },
            {
                headerName: "Employee Code",
                field: "employeeCode",
                minWidth: 80,
                cellRenderer: params => SetContextMenuTrigger({ params }),
                excelWidth: 30
            },
            {
                headerName: "Location",
                field: "location",
                minWidth: 80,
                maxWidth: 120,
                excelWidth: 20,
                filter: false,
                filterParams: filterParams.typeFormat(['USA', 'INDIA']),
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Role Name",
                field: "rolename",
                minWidth: 80,
                excelWidth: 35,
                filter: false,
                filterParams: filterParams.typeFormat(["Administrator", 'Employee', 'Human Resource']),
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Status",
                field: "employmentStatus",
                minWidth: 80,
                maxWidth: 170,
                excelWidth: 20,
                filter: false,
                filterParams: filterParams.typeFormat([setDefaultValue.employmentStatus.confirmed, setDefaultValue.employmentStatus.relieved, setDefaultValue.employmentStatus.probation]),
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
        ];
        return isMobileCompatible ? [...loginColumns, {
            headerName: "Actions",
            field: "actions",
            cellRenderer: params => {
                const selectedRow = params.data;
                const isAddbtnVisible = !(("employeeCode" in selectedRow) && selectedRow?.employeeCode?.length > 0);
                return <div className={` h-full w-full flex items-center justify-center ${isAddbtnVisible ? "gap-1" : "gap-2"}  ml-1`}>
                    {isAddbtnVisible && <span className=" flex items-center text-headerColor cursor-pointer" onClick={() => handleClick(null, { menu: "AddEmployeeDetails", history }, selectedRow)}>
                        <MdOutlineAddBox size={20} />
                    </span>}
                    <span className='flex items-center text-headerColor cursor-pointer' onClick={() => handleClick(null, { menu: "EditLoginDetails", history }, selectedRow)}>
                        <FiEdit size={18} />
                    </span>
                    <span className=" flex items-center text-headerColor cursor-pointer" onClick={async () => {
                        await store.dispatch(loginActions.setSelectedRow({ ...selectedRow }));
                        await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to delete ${selectedRow.employeeName}'s login details?`, isOptional: true }));
                    }}>
                        <ImBin size={16.5} />
                    </span>
                </div>
            },
            lockPosition: 'right',
            pinned: 'right',
            sortable: false,
            headerClass: " !pl-2 !pr-1",
            filter: false,
            minWidth: 90,
            maxWidth: 90
        }] : loginColumns;
    },
    ContextMenuItems: ({ history, selectedRow }) => {
        return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
            <MenuItem
                data={{ menu: "EditLoginDetails", history: history }}
                className={classNames.contextMenuItem}
                onClick={(e, data) => handleClick(e, data, selectedRow)}
            >
                <span className='flex items-center'> <FiEdit size={18} /> <span className='mx-2'>Edit</span></span>
            </MenuItem>
            <MenuItem
                data={{ menu: "DeleteLoginDetails", history: history }}
                className={classNames.contextMenuItem}
                onClick={async (e, data) => {
                    await store.dispatch(loginActions.setSelectedRow({ ...selectedRow }));
                    await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to delete ${selectedRow.employeeName}'s login details?`, isOptional: true }));
                }}
            >
                <span className='flex items-center'> <ImBin size={16.5} /> <span className='mx-2'>Delete</span></span>
            </MenuItem>
            {!(("employeeCode" in selectedRow) && selectedRow.employeeCode && selectedRow.employeeCode.length > 0) && <MenuItem
                data={{ menu: "AddEmployeeDetails", history: history }}
                className={`${classNames.contextMenuItem} ${("employeeCode" in selectedRow) && selectedRow.employeeCode && selectedRow.employeeCode.length > 0 && classNames.contextMenuDisable}`}
                onClick={(e, data) => handleClick(e, data, selectedRow)}
            >
                <span className='flex items-center'> <MdOutlineAddBox size={20} /> <span className='mx-2'>Add Employee</span></span>
            </MenuItem>}
        </ContextMenu>)
    },
}

export const employeeQualification = {
    columns: (setLoader, isMobileCompatible, callBackFunc) => {
        const qualificationColumns = [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                checkboxSelection: !isMobileCompatible,
                minWidth: 85,
                maxWidth: 85
            },
            {
                headerName: "Qualification",
                field: "qualification",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 150,
            },
            {
                headerName: "Institution",
                field: "institution",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 150,
            },
            {
                headerName: "Major Subject",
                field: "majorSubject",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 100,
            },
            {
                headerName: "Type",
                field: "type",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 70,
                maxWidth: 70
            },
            {
                headerName: "Value",
                field: "value",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 90,
                maxWidth: 90
            },
            {
                headerName: "Duration",
                field: "courseDuration",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 120,
            },
            {
                headerName: "Start Date",
                field: "courseStartDate",
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                minWidth: 120,
                maxWidth: 140
            },
            {
                headerName: "End Date",
                field: "courseEndDate",
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                minWidth: 120,
                maxWidth: 140
            },
            {
                headerName: "University",
                field: "university",
                wrapText: true,
                autoHeight: true,
                cellRenderer: params => <ContextMenuTrigger id="staff_contextmenu_id"><div className={`${classNames.contextMenuValue} min-w-full`}>{params.value}</div></ContextMenuTrigger>,
                minWidth: 250
            },
            {
                headerName: "Certificate Image",
                field: "empQualificationId",
                cellRenderer: params => SetContextMenuTrigger({
                    params, isDocumentView: true, onClick: async () => {
                        setLoader(true);
                        await store.dispatch(employeeRequests.viewMultipleDocuments("employeeDetails/qualificationCertificate", params.value, "documentDetails", "Qualification"));
                        setLoader(false);
                    }
                }),
                minWidth: 150
            },
            {
                headerName: "Is part of CLEP",
                field: "isPartOfCLEP",
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{params.value === isPartOfClinicalUser.yes ? "Yes" : "No"}</div></ContextMenuTrigger>),
                minWidth: 150,
                maxWidth: 150
            },
            {
                headerName: "Location",
                field: "location",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 100,
                maxWidth: 100
            }
        ]
        return isMobileCompatible ? [...qualificationColumns, {
            headerName: "Actions",
            field: "actions",
            cellRenderer: params => {
                const selectedRow = params.data;
                const isViewable = employeeReducerState().employeeModule.isDisable;
                return <div className=" h-full w-full flex items-center justify-center gap-2 ml-4">
                    <span className='flex items-center text-headerColor cursor-pointer' onClick={() => callBackFunc(selectedRow, "isEdit")}>
                        {isViewable ? <ImEye size={18} /> : <FiEdit size={18} />}
                    </span>
                    {!isViewable && <span className=" flex items-center text-headerColor cursor-pointer" onClick={() => callBackFunc(selectedRow, "isDelete")} >
                        <ImBin size={16.5} />
                    </span>}
                </div>
            },
            lockPosition: 'right',
            pinned: 'right',
            sortable: false,
            headerClass: " !pl-2 !pr-1",
            filter: false,
            minWidth: 70,
            maxWidth: 70
        }] : qualificationColumns;
    },
    ContextMenuItems: ({ selectedRow, callBackFunc }) => {
        const isViewable = employeeReducerState().employeeModule.isDisable
        return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
            <MenuItem
                className={classNames.contextMenuItem}
                onClick={() => callBackFunc(selectedRow, "isEdit")}
            >
                {isViewable ?
                    <span className='flex items-center'> <ImEye size={18} /> <span className='mx-2'>View</span></span> :
                    <span className='flex items-center'> <FiEdit size={18} /> <span className='mx-2'>Edit</span></span>
                }
            </MenuItem>
            {!isViewable && <MenuItem
                className={classNames.contextMenuItem}
                onClick={() => callBackFunc(selectedRow, "isDelete")}
            >
                <span className='flex items-center'> <ImBin size={16.5} /> <span className='mx-2'>Delete</span></span>
            </MenuItem>}
        </ContextMenu>)
    },
}

export const complianceReport = {
    columns: () => [
        {
            headerName: "S.No",
            field: "sno",
            comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
            cellRenderer: params => (<div className={"h-full m-0 !ml-6 w-full flex items-center"}>{Number(params.node.id) + 1}</div>), //holdToDisplay={0}
            lockPosition: 'left',
            headerClass: " !pl-2 !pr-1",
            minWidth: 60,
            maxWidth: 60,
            excelWidth: 7,
        },
        {
            headerName: "Employee Name",
            field: reportFields.employeeName.label,
            minWidth: 140, excelWidth: 35,
            headerTooltip: "Employee Name",
            headerClass: " !pl-2 !pr-1 ",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            cellRenderer: params => setReportContextMenu({ params }),
        },
        {
            headerName: "DOJ",
            field: reportFields.doj.label,
            headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-start'><div>{displayName}</div><div className=' text-12px'>{"(MM/DD/YYYY)"}</div></div>,
            minWidth: 90, excelWidth: 15,
            maxWidth: 90,
            headerTooltip: "Date Of Joining",
            headerClass: " !pl-2 !pr-1",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,

            cellRenderer: params => setReportContextMenu({ params, isDateView: true }),

        },
        {
            headerName: "Designation",
            field: reportFields.designation.label,
            minWidth: 130, excelWidth: 35,
            headerTooltip: "Designation",
            headerClass: " !pl-2 !pr-1",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,

            cellRenderer: params => setReportContextMenu({ params }),

        },
        {
            headerName: "I-9 Employee Eligibility Verification",
            headerTooltip: "I-9 Employee Eligibility Verification",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            headerClass: " !pl-2 !pr-1",
            field: reportFields.employeeEligibilityVerification.label,
            minWidth: 100, excelWidth: 20,
            cellRenderer: params => setReportContextMenu({ params, isDateView: true }),

        },
        {
            headerName: "Every 3 years NY State Clinical License",
            headerTooltip: "Every 3 years NY State Clinical License",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            headerClass: " !pl-2 !pr-1 ",
            field: reportFields.every3yearNyStateClinicalLicense.label,
            minWidth: 110, excelWidth: 20,
            cellRenderer: params => setReportContextMenu({ params, isDateView: true, isSelectable: true, colorCode: reportFields.every3yearNyStateClinicalLicense.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.every3yearNyStateClinicalLicense.noExpiry }),

        },
        {
            headerName: "1 year NY State Clinical License",
            headerTooltip: "1 year NY State Clinical License",
            headerClass: " !pl-2 !pr-1 ",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.yearNyStateClinicalLicense.label,
            minWidth: 90, excelWidth: 20,
            cellRenderer: params => setReportContextMenu({ params, isDateView: true, isSelectable: true, colorCode: reportFields.yearNyStateClinicalLicense.colorCode, isAllBlueColor: !!params.data[reportFields.every3yearNyStateClinicalLicense.label], noExpiryLabel: reportFields.yearNyStateClinicalLicense.noExpiry })
        },
        {
            headerName: "One Time Employee Training",
            headerTooltip: "One Time Employee Training",
            headerClass: " !pl-2 !pr-1 ",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.oneTimeEmployeeTraining.label,
            minWidth: 90, excelWidth: 20,

            cellRenderer: params => setReportContextMenu({ params, isDateView: true, isSelectable: true, colorCode: reportFields.oneTimeEmployeeTraining.colorCode, isAllBlueColor: true, noExpiryLabel: reportFields.oneTimeEmployeeTraining.noExpiry }),

        },
        {
            headerName: "Every Year Competency Assessment Test",
            headerTooltip: "Every Year Competency Assessment Test",
            headerClass: " !pl-2 !pr-1 ",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.everyYearCompetencyAssessmentTest.label,
            minWidth: 100, excelWidth: 20,

            cellRenderer: params => setReportContextMenu({ params, isDateView: true, isSelectable: true, colorCode: reportFields.everyYearCompetencyAssessmentTest.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.everyYearCompetencyAssessmentTest.noExpiry }),

        },
        {
            headerName: "Third Month Competency Assessment Test",
            headerTooltip: "Third Month Competency Assessment Test",
            headerClass: " !pl-2 !pr-1 ",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.thirdMonthCompetencyAssessmentTest.label,
            minWidth: 100, excelWidth: 20,

            cellRenderer: params => setReportContextMenu({ params, isDateView: true, isSelectable: true, colorCode: reportFields.thirdMonthCompetencyAssessmentTest.colorCode, isBlueCode: true, noExpiryLabel: reportFields.thirdMonthCompetencyAssessmentTest.noExpiry }),

        },
        {
            headerName: "Sixth Month Competency Assessment Test",
            headerTooltip: "Sixth Month Competency Assessment Test",
            headerClass: " !pl-2 !pr-1 ",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.sixthMonthCompetencyAssessmentTest.label,
            minWidth: 100, excelWidth: 20,

            cellRenderer: params => setReportContextMenu({ params, isDateView: true, isSelectable: true, colorCode: reportFields.sixthMonthCompetencyAssessmentTest.colorCode, isBlueCode: true, noExpiryLabel: reportFields.sixthMonthCompetencyAssessmentTest.noExpiry }),

        },
        {
            headerName: "Continuing Education Credit(in Hours)",
            headerTooltip: "Continuing Education Credit(in Hours)",
            headerClass: " !pl-2 !pr-1 ",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.continuousEducationCreditInHours.label,
            minWidth: 95, excelWidth: 20,

            cellRenderer: params => setReportContextMenu({ params, isSelectable: true, onClick: redirectEventManagementReport, colorCode: reportFields.continuousEducationCreditInHours.colorCode, noExpiryLabel: reportFields.continuousEducationCreditInHours.noExpiry }),

        },
        {
            headerName: "Every Year HIPAA Confidentiality Agreement",
            headerTooltip: "Every Year HIPAA Confidentiality Agreement",
            headerClass: " !pl-2 !pr-1 ",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.everyYearHippaPatientConfidentiality.label,
            minWidth: 120, excelWidth: 20,

            cellRenderer: params => setReportContextMenu({ params, isDateView: true, isSelectable: true, colorCode: reportFields.everyYearHippaPatientConfidentiality.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.everyYearHippaPatientConfidentiality.noExpiry }),

        },
        {
            headerName: "1 year Fire Education Training",
            headerTooltip: "1 year Fire Education Training",
            headerClass: " !pl-2 !pr-1 ",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.yearFireEducationTraining.label,
            minWidth: 90, excelWidth: 20,

            cellRenderer: params => setReportContextMenu({ params, isDateView: true, isSelectable: true, colorCode: reportFields.yearFireEducationTraining.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.yearFireEducationTraining.noExpiry }),

        },
        {
            headerName: "1 year Biohazard Waste Training",
            headerTooltip: "1 year Biohazard Waste Training",
            headerClass: " !pl-2 !pr-1 ",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.yearBiohazardWasteTraining.label,
            minWidth: 90, excelWidth: 20,

            cellRenderer: params => setReportContextMenu({ params, isDateView: true, isSelectable: true, colorCode: reportFields.yearBiohazardWasteTraining.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.yearBiohazardWasteTraining.noExpiry }),

        },
        {
            headerName: "Every Year Bloodborn Pathogens Training",
            headerTooltip: "Every Year Bloodborn Pathogens Training",
            headerClass: " !pl-2 !pr-1 ",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.everyYearBloodbornPathogensTraining.label,
            minWidth: 95, excelWidth: 20,

            cellRenderer: params => setReportContextMenu({ params, isDateView: true, isSelectable: true, colorCode: reportFields.everyYearBloodbornPathogensTraining.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.everyYearBloodbornPathogensTraining.noExpiry }),

        },
        {
            headerName: "1 Year PPE Training",
            headerTooltip: "1 Year PPE Training",
            headerClass: " !pl-2 !pr-1 ",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.yearPPETraining.label,
            minWidth: 90, excelWidth: 20,

            cellRenderer: params => setReportContextMenu({ params, isDateView: true, isSelectable: true, colorCode: reportFields.yearPPETraining.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.yearPPETraining.noExpiry }),

        },
        {
            headerName: "Every 3 years DOT Training",
            headerTooltip: "Every 3 years DOT Training",
            headerClass: " !pl-2 !pr-1 ",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.every3yearsDotTraining.label,
            minWidth: 90, excelWidth: 20,

            cellRenderer: params => setReportContextMenu({ params, isDateView: true, isSelectable: true, colorCode: reportFields.every3yearsDotTraining.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.every3yearsDotTraining.noExpiry }),

        },
        {
            headerName: "1 Year Sexual Harassment Training",
            headerTooltip: "1 Year Sexual Harassment Training",
            headerClass: " !pl-2 !pr-1 ",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.yearSexualHarassmentTraining.label,
            minWidth: 100, excelWidth: 20,

            cellRenderer: params => setReportContextMenu({ params, isDateView: true, isSelectable: true, colorCode: reportFields.yearSexualHarassmentTraining.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.yearSexualHarassmentTraining.noExpiry }),

        },
        {
            headerName: "Every Year Supervisor Performance Review",
            headerTooltip: "Every Year Supervisor Performance Review",
            headerClass: " !pl-2 !pr-1 ",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.everyYearSupervisorPerformanceReview.label,
            minWidth: 105, excelWidth: 20,

            cellRenderer: params => setReportContextMenu({ params, isDateView: true, isSelectable: true, colorCode: reportFields.everyYearSupervisorPerformanceReview.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.everyYearSupervisorPerformanceReview }),

        },
        {
            headerName: "Year Cyber Security",
            headerTooltip: "Year Cyber Security",
            headerClass: " !pl-2 !pr-1 ",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.yearCyberSecurity.label,
            minWidth: 90,

            cellRenderer: params => setReportContextMenu({ params, isDateView: true, isSelectable: true, colorCode: reportFields.yearCyberSecurity.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.yearCyberSecurity.noExpiry }),

        },
        {
            headerName: "Year HIPAA",
            headerTooltip: "Year HIPAA",
            headerClass: " !pl-2 !pr-1 ",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.oneYearHIPAA.label,
            minWidth: 90,
            cellRenderer: params => setReportContextMenu({ params, isDateView: true, isSelectable: true, colorCode: reportFields.oneYearHIPAA.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.oneYearHIPAA.noExpiry })
        }
    ],
    complianceViewColumns: (isExpiryNotification) => [
        {
            headerName: "S.No",
            field: "sno",
            comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
            cellRenderer: params => (<div className={"h-full m-0 !ml-4 w-full flex items-center"}>{Number(params.node.id) + 1}</div>), //holdToDisplay={0}
            lockPosition: 'left',
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            filter: false,
            minWidth: 50,
            maxWidth: 50
        },
        {
            headerName: "Employee Name",
            field: reportFields.employeeName.label,
            minWidth: 119,
            headerTooltip: "Employee Name",
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            filter: false,
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            cellRenderer: params => setReportContextMenu({ params, isPopup: true, }),
        },
        {
            headerName: "DOJ",
            field: reportFields.doj.label,
            headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-start'><div>{displayName}</div><div className=' text-[11px]'>{"(MM/DD/YYYY)"}</div></div>,
            minWidth: 80,
            maxWidth: 80,
            headerTooltip: "Date Of Joining",
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, isDateView: true, isPopup: true, }),
        },
        {
            headerName: "Designation",
            field: reportFields.designation.label,
            minWidth: 100,
            headerTooltip: "Designation",
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, isPopup: true }),
        },
        {
            headerName: "I-9 Employee Eligibility Verification",
            headerTooltip: "I-9 Employee Eligibility Verification",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            field: reportFields.employeeEligibilityVerification.label,
            minWidth: 90,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, isDateView: true }),
        },
        {
            headerName: "Every 3 years NY State Clinical License",
            headerTooltip: "Every 3 years NY State Clinical License",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            field: reportFields.every3yearNyStateClinicalLicense.label,
            minWidth: 95,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, hideValidDates: isExpiryNotification, isDateView: true, isSelectable: true, isPopup: true, colorCode: reportFields.every3yearNyStateClinicalLicense.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.every3yearNyStateClinicalLicense.noExpiry })
        },
        {
            headerName: "1 year NY State Clinical License",
            headerTooltip: "1 year NY State Clinical License",
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.yearNyStateClinicalLicense.label,
            minWidth: 80,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, hideValidDates: isExpiryNotification, isDateView: true, isSelectable: true, isPopup: true, colorCode: reportFields.yearNyStateClinicalLicense.colorCode, isAllBlueColor: !!params.data[reportFields.every3yearNyStateClinicalLicense.label], noExpiryLabel: reportFields.yearNyStateClinicalLicense.noExpiry })
        },
        {
            headerName: "One Time Employee Training",
            headerTooltip: "One Time Employee Training",
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.oneTimeEmployeeTraining.label,
            minWidth: 80,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, hideValidDates: isExpiryNotification, isDateView: true, isSelectable: true, isPopup: true, colorCode: reportFields.oneTimeEmployeeTraining.colorCode, isAllBlueColor: true, noExpiryLabel: reportFields.oneTimeEmployeeTraining.noExpiry })
        },
        {
            headerName: "Every Year Competency Assessment Test",
            headerTooltip: "Every Year Competency Assessment Test",
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.everyYearCompetencyAssessmentTest.label,
            minWidth: 90,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, hideValidDates: isExpiryNotification, isDateView: true, isSelectable: true, isPopup: true, colorCode: reportFields.everyYearCompetencyAssessmentTest.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.everyYearCompetencyAssessmentTest.noExpiry })
        },
        {
            headerName: "Third Month Competency Assessment Test",
            headerTooltip: "Third Month Competency Assessment Test",
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.thirdMonthCompetencyAssessmentTest.label,
            minWidth: 90,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, hideValidDates: isExpiryNotification, isDateView: true, isSelectable: true, isPopup: true, colorCode: reportFields.thirdMonthCompetencyAssessmentTest.colorCode, isBlueCode: true, noExpiryLabel: reportFields.thirdMonthCompetencyAssessmentTest.noExpiry })
        },
        {
            headerName: "Sixth Month Competency Assessment Test",
            headerTooltip: "Sixth Month Competency Assessment Test",
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.sixthMonthCompetencyAssessmentTest.label,
            minWidth: 85,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, hideValidDates: isExpiryNotification, isDateView: true, isSelectable: true, isPopup: true, colorCode: reportFields.sixthMonthCompetencyAssessmentTest.colorCode, isBlueCode: true, noExpiryLabel: reportFields.sixthMonthCompetencyAssessmentTest.noExpiry })
        },
        {
            headerName: "Continuing Education Credit(in Hours)",
            headerTooltip: "Continuing Education Credit(in Hours)",
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.continuousEducationCreditInHours.label,
            minWidth: 85,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, hideValidDates: isExpiryNotification, isSelectable: true, onClick: redirectEventManagementReport, isPopup: true, colorCode: reportFields.continuousEducationCreditInHours.colorCode, noExpiryLabel: reportFields.continuousEducationCreditInHours.noExpiry })
        },
        {
            headerName: "Every Year HIPAA Confidentiality Agreement",
            headerTooltip: "Every Year HIPAA Confidentiality Agreement",
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.everyYearHippaPatientConfidentiality.label,
            minWidth: 100,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, hideValidDates: isExpiryNotification, isDateView: true, isSelectable: true, isPopup: true, colorCode: reportFields.everyYearHippaPatientConfidentiality.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.everyYearHippaPatientConfidentiality.noExpiry })
        },
        {
            headerName: "1 year Fire Education Training",
            headerTooltip: "1 year Fire Education Training",
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.yearFireEducationTraining.label,
            minWidth: 80,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, hideValidDates: isExpiryNotification, isDateView: true, isSelectable: true, isPopup: true, colorCode: reportFields.yearFireEducationTraining.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.yearFireEducationTraining.noExpiry })
        },
        {
            headerName: "1 year Biohazard Waste Training",
            headerTooltip: "1 year Biohazard Waste Training",
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.yearBiohazardWasteTraining.label,
            minWidth: 80,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, hideValidDates: isExpiryNotification, isDateView: true, isSelectable: true, isPopup: true, colorCode: reportFields.yearBiohazardWasteTraining.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.yearBiohazardWasteTraining.noExpiry })
        },
        {
            headerName: "Every Year Bloodborn Pathogens Training",
            headerTooltip: "Every Year Bloodborn Pathogens Training",
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.everyYearBloodbornPathogensTraining.label,
            minWidth: 85,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, hideValidDates: isExpiryNotification, isDateView: true, isSelectable: true, isPopup: true, colorCode: reportFields.everyYearBloodbornPathogensTraining.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.everyYearBloodbornPathogensTraining.noExpiry })
        },
        {
            headerName: "1 Year PPE Training",
            headerTooltip: "1 Year PPE Training",
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.yearPPETraining.label,
            minWidth: 80,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, hideValidDates: isExpiryNotification, isDateView: true, isSelectable: true, isPopup: true, colorCode: reportFields.yearPPETraining.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.yearPPETraining.noExpiry })
        },
        {
            headerName: "Every 3 years DOT Training",
            headerTooltip: "Every 3 years DOT Training",
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.every3yearsDotTraining.label,
            minWidth: 80,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, hideValidDates: isExpiryNotification, isDateView: true, isSelectable: true, isPopup: true, colorCode: reportFields.every3yearsDotTraining.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.every3yearsDotTraining.noExpiry })
        },
        {
            headerName: "1 Year Sexual Harassment Training",
            headerTooltip: "1 Year Sexual Harassment Training",
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.yearSexualHarassmentTraining.label,
            minWidth: 81,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, hideValidDates: isExpiryNotification, isDateView: true, isSelectable: true, isPopup: true, colorCode: reportFields.yearSexualHarassmentTraining.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.yearSexualHarassmentTraining.noExpiry })
        },
        {
            headerName: "Every Year Supervisor Performance Review",
            headerTooltip: "Every Year Supervisor Performance Review",
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.everyYearSupervisorPerformanceReview.label,
            minWidth: 85,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, hideValidDates: isExpiryNotification, isDateView: true, isSelectable: true, isPopup: true, colorCode: reportFields.everyYearSupervisorPerformanceReview.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.everyYearSupervisorPerformanceReview.noExpiry }),
        },
        {
            headerName: "Year Cyber Security",
            headerTooltip: "Year Cyber Security",
            headerClass: " !pl-2 !pr-1 ",
            //cellClass: "custom-gridCell",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.yearCyberSecurity.label,
            minWidth: 90,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, hideValidDates: isExpiryNotification, isDateView: true, isSelectable: true, colorCode: reportFields.yearCyberSecurity.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.yearCyberSecurity.noExpiry })
        },
        {
            headerName: "Year HIPAA",
            headerTooltip: "Year HIPAA",
            headerClass: " !pl-2 !pr-1 ",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            field: reportFields.oneYearHIPAA.label,
            minWidth: 90,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, hideValidDates: isExpiryNotification, isDateView: true, isSelectable: true, colorCode: reportFields.oneYearHIPAA.colorCode, isBlueCode: isNaN(new Date(params.value)), noExpiryLabel: reportFields.oneYearHIPAA.noExpiry })
        }
    ],
    complianceNotifyColumns: [
        {
            headerName: "S.No",
            field: "sno",
            comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
            cellRenderer: params => (<div className={"h-full m-0 !ml-4 w-full flex items-center"}>{Number(params.node.id) + 1}</div>), //holdToDisplay={0}
            lockPosition: 'left',
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            checkboxSelection: true,
            headerCheckboxSelection: true,
            filter: false,
            excelWidth: 1,
            minWidth: 80,
            maxWidth: 80
        },
        {
            headerName: "Employee Name",
            field: reportFields.employeeName.label,
            minWidth: 150,
            headerTooltip: "Employee Name",
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            excelWidth: 2,
            filter: true,
            cellRenderer: params => setReportContextMenu({ params, isPopup: true, }),
        },
        {
            headerName: "Designation",
            field: reportFields.designation.label,
            minWidth: 100,
            headerTooltip: "Designation",
            headerClass: " !pl-1 !pr-1 custom-gridHeader",
            cellClass: "custom-gridCell",
            wrapText: true,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
            excelWidth: 3,
            filter: false,
            cellRenderer: params => setReportContextMenu({ params, isPopup: true, }),
        },
    ],
    complianceNotifyMailDetails: () => [
        {
            headerName: "S.No",
            field: "sno",
            comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
            cellRenderer: params => (<div className={"h-full m-0 !ml-6 w-full flex items-center"}>{Number(params.node.id) + 1}</div>), //holdToDisplay={0}
            lockPosition: 'left',
            headerClass: " !pl-2 !pr-1",
            minWidth: 60,
            maxWidth: 60,
            excelWidth: 7,
        },
        {
            headerName: "Compliance Date",
            field: "compliance",
            headerComponent: agGridDateHeaderComponent,
            minWidth: 150,
            excelWidth: 16,
            cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true })
        },
        {
            headerName: "Compliance Category",
            field: "displayName",
            minWidth: 100,
            excelWidth: 25,
            cellRenderer: params => SetContextMenuTrigger({ params })
        },
        {
            headerName: "Compliance Period",
            field: "compliancePeriod",
            minWidth: 100,
            excelWidth: 25,
            cellRenderer: params => SetContextMenuTrigger({ params })
        },
        {
            headerName: "Expiry Date",
            field: "expirydate",
            headerComponent: agGridDateHeaderComponent,
            minWidth: 150,
            excelWidth: 16,
            cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true })
        }
    ]
}

const setReportContextMenu = ({ params, hideValidDates, isDateView, isSelectable, onClick, isPopup, colorCode, isBlueCode, isAllBlueColor, noExpiryLabel }) => {
    const contextMenuValue = `h-full m-0  !pr-1 w-full ${isPopup ? "!pl-1" : "!pl-2"}`;
    if (!params.value && params.value !== 0) {
        return (<div className=' text-transparent'>ContextMenu</div>)
    }
    else if (isDateView) {
        const getColorCodes = () => {
            if (isAllBlueColor) {
                return "text-blue-600";
            } else if (colorCode && colorCode.length > 0 && params.data[colorCode]) {
                if (Number(params.data[colorCode])) {
                    return isNaN(new Date(params.value)) ? 'text-blue-600' : "text-[#008000]"; // Not Expired - Green 
                }
                return isBlueCode ? 'text-blue-600' : " text-[#ff0000]"; // Expired - Red
            }
            return "";
        }
        const getValidRecords = () => {
            if (hideValidDates) {
                if (!(colorCode && colorCode.length > 0 && params.data[colorCode] && Number(params.data[colorCode]) && !isNaN(new Date(params.value)))) {
                    return isNaN(new Date(params.value)) ? complianceReportDateFormat(params.data[noExpiryLabel]) : complianceReportDateFormat(params.value);
                }
            } else {
                return isNaN(new Date(params.value)) ? complianceReportDateFormat(params.data[noExpiryLabel]) : complianceReportDateFormat(params.value)
            }
            return ""
        }
        return (<div className={contextMenuValue}><span className={`${getColorCodes()} ${isSelectable ? "cursor-pointer" : ""}`} onClick={async () => { //colorCode && colorCode.length > 0 && params.data[colorCode] ? (isBlueCode ? 'text-blue-600' : (Number(params.data[colorCode]) ? "text-[#008000]" : " text-[#ff0000]")) : ""
            if (isSelectable && params.value) {
                await store.dispatch(reportRequest.setComplianceLoader(true));
                if (isNaN(new Date(params.value))) {
                    await store.dispatch(reportRequest.getComplianceCertificate({ complianceCategory: params?.colDef?.headerName, employeeId: params.data[reportFields.employeeId.label], expiryDate: params.data[params?.colDef?.headerName], isNoExpiry: 'true' }))
                }
                else {
                    await store.dispatch(reportRequest.getComplianceCertificate({ complianceCategory: params?.colDef?.field, employeeId: params.data[reportFields.employeeId.label], expiryDate: params.value, isNoExpiry: 'false' }))
                }
                store.dispatch(reportRequest.setComplianceLoader(false));
            }
        }} >{getValidRecords()}</span></div>)
    }
    return (<div className={contextMenuValue}>{isSelectable ? <span className="cursor-pointer" onClick={() => onClick(params.data[reportFields.employeeId.label])}>{params.value}</span> : params.value}</div>)
}

const redirectEventManagementReport = async (employeeId) => {
    const eventManagementReport = {
        employeeId: employeeId,
        locationId: setDefaultValue.usLocation.value
    }
    await store.dispatch(complianceReportActions.setComplianceReportPopup({ show: true, data: eventManagementReport, isPopupView: true }))
}

export const leaveManagement = {
    leaveRequest: {
        column: (isMobileCompatible) => {
            const leaveRequestColumn = [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    checkboxSelection: true,
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7
                },
                {
                    headerName: "Applied Date",
                    headerComponent: agGridDateHeaderComponent,
                    field: "appliedDate",
                    minWidth: 90,
                    maxWidth: 130,
                    excelWidth: 16,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                },
                {
                    headerName: "Pending Since",
                    field: "pendingSince",
                    minWidth: 100,
                    maxWidth: 150,
                    excelWidth: 16,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
                {
                    headerName: "Employee Name",
                    field: "employeeName",
                    minWidth: 100,
                    excelWidth: 25,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
                {
                    headerName: "Location",
                    field: "location",
                    minWidth: 80,
                    maxWidth: 100,
                    excelWidth: 20,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
                {
                    headerName: "Leave From",
                    headerComponent: agGridDateHeaderComponent,
                    field: "fromDate",
                    minWidth: 80,
                    excelWidth: 16,
                    maxWidth: 140,
                    cellRenderer: params => <ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{params.value && params.value.length > 0 && params.data.leaveFromForH ? dateFormat(params.value) + ' - ' + params.data.leaveFromForH : ""}</div></ContextMenuTrigger>
                },
                {
                    headerName: "Leave To",
                    headerComponent: agGridDateHeaderComponent,
                    field: "toDate",
                    excelWidth: 16,
                    minWidth: 80,
                    maxWidth: 130,
                    cellRenderer: params => <ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{params.value && params.value.length > 0 && params.data.leaveToForH ? dateFormat(params.value) + ' - ' + params.data.leaveToForH : ""}</div></ContextMenuTrigger>
                },
                {
                    headerName: "Days Applied",
                    field: "noOfDaysApplied",
                    minWidth: 80,
                    maxWidth: 140,
                    excelWidth: 20,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
                {
                    headerName: "Leave Status",
                    field: "cancelApprovalStatus",
                    minWidth: 100,
                    maxWidth: 150,
                    excelWidth: 25,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
                {
                    headerName: "Leave Type",
                    field: "leaveType",
                    excelWidth: 25,
                    minWidth: 80,
                    maxWidth: 150,
                    cellRenderer: params => <ContextMenuTrigger id="staff_contextmenu_id"><div className={`${params.value ? leaveDetails.find(val => val.title === params.value.trim()).bgColor : ""} h-full m-0 pl-5 w-full`}>{params.value}</div></ContextMenuTrigger>
                },
                {
                    headerName: "Reason",
                    field: "reason",
                    excelWidth: 35,
                    minWidth: 80,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
            ]
            return isMobileCompatible ? [...leaveRequestColumn, {
                headerName: "Actions",
                field: "actions",
                cellRenderer: params => {
                    const selectedRow = params.data;
                    return <div className=" h-full w-full flex items-center justify-center ml-5">
                        <span className='flex items-center text-headerColor cursor-pointer' >
                            {(selectedRow.cancelApprovalStatus === leaveStatus[4].label || selectedRow.cancelApprovalStatus === leaveStatus[3].label) && <span
                                onClick={async (e, data) => {
                                    await store.dispatch(leaveManagementRequest.setLoader(true));
                                    await store.dispatch(leaveManagementActions.setLeaveRequestQueueSelectedData({ ...selectedRow, action: status.tobeApproved }));
                                    await store.dispatch(leaveManagementRequest.leaveRequestQueue.getLeaveRequestDetails(selectedRow.requestId, status.tobeApproved));
                                    store.dispatch(leaveManagementRequest.setLoader(false));
                                }}
                            ><span className='flex items-center'>  <TiTick size={18.5} />  <span>/</span> <IoClose size={18} style={{ strokeWidth: "18px" }} /> </span></span>}
                            {(selectedRow.cancelApprovalStatus === leaveStatus[1].label || selectedRow.cancelApprovalStatus === leaveStatus[3].label || selectedRow.cancelApprovalStatus === leaveStatus[6].label) && <span className='mx-2'
                                onClick={async (e, data) => {
                                    await store.dispatch(leaveManagementRequest.setLoader(true));
                                    await store.dispatch(leaveManagementActions.setLeaveRequestQueueSelectedData({ ...selectedRow, action: status.cancel }));
                                    await store.dispatch(leaveManagementRequest.leaveRequestQueue.getLeaveRequestDetails(selectedRow.requestId, status.cancel));
                                    store.dispatch(leaveManagementRequest.setLoader(false));
                                }}
                            > <TiCancel size={20} /> </span>}
                            {<span className='mx-2'
                                onClick={async (e, data) => {
                                    await store.dispatch(leaveManagementRequest.setLoader(true));
                                    await store.dispatch(leaveManagementActions.setLeaveHistoryPopup({ show: true, data: [], rowData: selectedRow }));
                                    store.dispatch(leaveManagementRequest.setLoader(false));
                                }}
                            > <HiOutlineClipboardList size={18} style={{ strokeWidth: "2.5px" }} /> </span>}
                        </span>
                    </div>
                },
                lockPosition: 'right',
                pinned: 'right',
                sortable: false,
                headerClass: " !pl-2 !pr-1",
                filter: false,
                minWidth: 120,
                maxWidth: 120
            }] : leaveRequestColumn;
        },
        contextMenuItems: ({ history, selectedRow }) => {
            return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                {
                    (selectedRow.cancelApprovalStatus === leaveStatus[4].label || selectedRow.cancelApprovalStatus === leaveStatus[3].label) &&
                    <div>
                        <MenuItem
                            data={{ menu: "Approve", history: history }}
                            className={classNames.contextMenuItem}
                            onClick={async (e, data) => {
                                await store.dispatch(leaveManagementRequest.setLoader(true));
                                await store.dispatch(leaveManagementActions.setLeaveRequestQueueSelectedData({ ...selectedRow, action: status.tobeApproved }));
                                await store.dispatch(leaveManagementRequest.leaveRequestQueue.getLeaveRequestDetails(selectedRow.requestId, status.tobeApproved));
                                store.dispatch(leaveManagementRequest.setLoader(false));
                            }}
                        >
                            <span className='flex items-center gap-y-[2px]'>
                                <span><TiTick size={18.5} /></span>
                                <span className=' flex items-center gap-x-1'>Approve  <span className=' ml-[2px]'>/</span> <span className=' flex items-center gap-x-[2px]'><IoClose size={18} style={{ strokeWidth: "18px" }} /> Reject</span></span>
                            </span>
                        </MenuItem>
                    </div>
                }
                {
                    (selectedRow.cancelApprovalStatus === leaveStatus[1].label || selectedRow.cancelApprovalStatus === leaveStatus[3].label || selectedRow.cancelApprovalStatus === leaveStatus[6].label) &&
                    <MenuItem
                        data={{ menu: "Cancel", history: history }}
                        className={classNames.contextMenuItem}
                        onClick={async (e, data) => {
                            await store.dispatch(leaveManagementRequest.setLoader(true));
                            await store.dispatch(leaveManagementActions.setLeaveRequestQueueSelectedData({ ...selectedRow, action: status.cancel }));
                            await store.dispatch(leaveManagementRequest.leaveRequestQueue.getLeaveRequestDetails(selectedRow.requestId, status.cancel));
                            store.dispatch(leaveManagementRequest.setLoader(false));
                        }}
                    >
                        <span className='flex items-center'> <TiCancel size={18} /> <span className='mx-2'>Cancel</span></span>
                    </MenuItem>
                }
                <MenuItem
                    data={{ menu: "leave History", history: history }}
                    className={classNames.contextMenuItem}
                    onClick={async (e, data) => {
                        await store.dispatch(leaveManagementRequest.setLoader(true));
                        await store.dispatch(leaveManagementActions.setLeaveHistoryPopup({ show: true, data: [], rowData: selectedRow }));
                        store.dispatch(leaveManagementRequest.setLoader(false));
                    }}
                >
                    <span className='flex items-center'><HiOutlineClipboardList size={18} style={{ strokeWidth: "2.5px" }} /> <span className='mx-2'>View Leave History</span></span>
                </MenuItem>
            </ContextMenu>)
        },
    },
    leaveHistory: {
        column: (isLeaveHistory, isMobileCompatible, callBackFunc) => {
            const leaveHistoryColumn = [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    checkboxSelection: params => !isMobileCompatible && isLeaveHistory && params.data.approvalStatus && leaveStatus.find(val => val.label === params.data.approvalStatus) ? !leaveRequestApprovalValidation(leaveStatus.find(val => val.label === params.data.approvalStatus).Key, status.cancel) : false,
                    minWidth: 70,
                    maxWidth: 70
                },
                {
                    headerName: "Leave Date",
                    field: "leaveDate",
                    headerComponent: agGridDateHeaderComponent,
                    minWidth: 150,
                    excelWidth: 16,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                },
                {
                    headerName: "F/H Day",
                    field: "fullOrHalfDay",
                    minWidth: 150,
                    excelWidth: 16,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
                {
                    headerName: "Reviewed on",
                    field: "reviewedOn",
                    headerComponent: agGridDateHeaderComponent,
                    minWidth: 150,
                    excelWidth: 16,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                },
                {
                    headerName: "Status",
                    field: "approvalStatus",
                    minWidth: 150,
                    excelWidth: 30,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
                {
                    headerName: "Leave Type",
                    field: "leaveType",
                    minWidth: 150,
                    excelWidth: 20,
                    cellRenderer: params => <div className={`${params.value ? leaveDetails.find(val => val.title === params.value.trim()).bgColor : ""} h-full m-0 pl-5 w-full`}>{params.value}</div>
                },
                {
                    headerName: "Reviewed By",
                    field: "reviewedBy",
                    minWidth: 150,
                    excelWidth: 25,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
            ]
            return isMobileCompatible ? [...leaveHistoryColumn, {
                headerName: "Actions",
                field: "actions",
                cellRenderer: params => {
                    const selectedRow = params.data;
                    return <div className=" h-full w-full flex items-center justify-center ml-5">
                        <span className='flex items-center text-headerColor cursor-pointer' >
                            <span onClick={async () => {
                                await store.dispatch(leaveManagementRequest.setLoader(true));
                                await store.dispatch(leaveManagementActions.setLeaveRequestQueueSelectedData({ ...selectedRow }));
                                await callBackFunc();
                                store.dispatch(leaveManagementRequest.setLoader(false));
                            }}><FiEdit size={18} /></span>
                            <span className='mx-2' onClick={async () => {
                                await store.dispatch(leaveManagementRequest.setLoader(true));
                                await store.dispatch(leaveManagementActions.setLeaveRequestQueueSelectedData({ ...selectedRow, action: status.cancel }));
                                await store.dispatch(leaveManagementRequest.leaveHistory.getHistoryLeaveRequestDetails(selectedRow.leaveRequestId, status.cancel, selectedRow));
                                store.dispatch(leaveManagementRequest.setLoader(false));
                            }}> <TiCancel size={20} /> </span>
                        </span>

                    </div>
                },
                lockPosition: 'right',
                pinned: 'right',
                sortable: false,
                headerClass: " !pl-2 !pr-1",
                filter: false,
                minWidth: 70,
                maxWidth: 70
            }] : leaveHistoryColumn;
        },
        contextMenuItems: ({ history, selectedRow, callBackFunc }) => {
            return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                {
                    selectedRow && Object.hasOwn(selectedRow, "approvalStatus") && selectedRow.approvalStatus === leaveStatus[4].label &&
                    <MenuItem
                        data={{ menu: "Edit", history: history }}
                        className={classNames.contextMenuItem}
                        onClick={async () => {
                            await store.dispatch(leaveManagementRequest.setLoader(true));
                            await store.dispatch(leaveManagementActions.setLeaveRequestQueueSelectedData({ ...selectedRow }));
                            await callBackFunc();
                            store.dispatch(leaveManagementRequest.setLoader(false));
                        }}
                    >
                        <span className='flex items-center'> <FiEdit size={18} /> <span className='mx-2'>Edit</span></span>
                    </MenuItem>
                }
                {
                    selectedRow && Object.hasOwn(selectedRow, "approvalStatus") && (selectedRow.approvalStatus === leaveStatus[4].label || selectedRow.approvalStatus === leaveStatus[1].label) &&
                    <MenuItem
                        data={{ menu: "Cancel", history: history }}
                        className={classNames.contextMenuItem}
                        onClick={async (e, data) => {
                            await store.dispatch(leaveManagementRequest.setLoader(true));
                            await store.dispatch(leaveManagementActions.setLeaveRequestQueueSelectedData({ ...selectedRow, action: status.cancel }));
                            await store.dispatch(leaveManagementRequest.leaveHistory.getHistoryLeaveRequestDetails(selectedRow.leaveRequestId, status.cancel, selectedRow));
                            store.dispatch(leaveManagementRequest.setLoader(false));
                        }}
                    >
                        <span className='flex items-center'> <TiCancel size={20} /> <span className='mx-2'>Cancel</span></span>
                    </MenuItem>
                }
            </ContextMenu>)
        },
    },
    importAttendance: {
        column: () => [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                checkboxSelection: true,
                minWidth: 85,
                maxWidth: 85
            },
            {
                headerName: "Work Date",
                field: "workDate",
                minWidth: 100,
                maxWidth: 140,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
            },
            {
                headerName: "Day",
                field: "day",
                minWidth: 100,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Employee Name",
                field: "employeeName",
                minWidth: 100,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Time In",
                field: "timeIn",
                minWidth: 100,
                maxWidth: 120,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Time Out",
                field: "timeOut",
                minWidth: 100,
                maxWidth: 120,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Hours Worked (hr)",
                field: "",
                minWidth: 100,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Hours Worked (hh:mm)",
                field: "",
                minWidth: 180,
                maxWidth: 200,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Compensations",
                field: "compensations",
                minWidth: 100,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Remarks",
                field: "remarks",
                minWidth: 100,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
        ]
    },
    leaveLedger: {
        column: (isMobileCompatible) => {
            const leaveLedgerColumn = [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    minWidth: 150,
                    maxWidth: 85,
                    checkboxSelection: true,
                },
                {
                    headerName: "Entry Date",
                    field: "entryDate",
                    headerComponent: agGridDateHeaderComponent,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                    lockPosition: 'left',
                    minWidth: 150,
                    maxWidth: 150,
                },
                {
                    headerName: "Employee Name",
                    field: "employeeName",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    lockPosition: 'left',
                    excelWidth: 35,
                    minWidth: 250,
                },
                {
                    headerName: "Description",
                    field: "comments",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    lockPosition: 'left',
                    excelWidth: 40,
                    minWidth: 120,
                },
                {
                    headerName: "Credit Days",
                    field: "creditDays",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    lockPosition: 'left',
                    minWidth: 150,
                    maxWidth: 150,
                },
                {
                    headerName: "Debit Days",
                    field: "debitDays",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    lockPosition: 'left',
                    minWidth: 150,
                    maxWidth: 150,
                },
                {
                    headerName: "Balance Days",
                    field: "balanceDays",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    lockPosition: 'left',
                    excelWidth: 25,
                    minWidth: 160,
                    maxWidth: 160,
                },
                {
                    headerName: "Leave Type",
                    field: "leaveType",
                    excelWidth: 25,
                    minWidth: 150,
                    maxWidth: 150,
                    cellRenderer: params => <ContextMenuTrigger id="staff_contextmenu_id"><div className={`${params.value ? leaveDetails.find(val => val.title === params.value.trim()).bgColor : ""} h-full m-0 pl-5 w-full`}>{params.value}</div></ContextMenuTrigger>,
                },
            ];
            return isMobileCompatible ? [...leaveLedgerColumn, {
                headerName: "Actions",
                field: "actions",
                cellRenderer: params => {
                    const selectedRow = params.data;
                    let isOptional = true;
                    return <div className=" h-full w-full flex items-center justify-center ml-5">
                        <span className='flex items-center text-headerColor cursor-pointer' >
                            <span
                                onClick={async (e, data) => {
                                    await store.dispatch(leaveManagementActions.setLeaveLedgerSelectedData(selectedRow));
                                    await store.dispatch(leaveManagementActions.setLeaveLedgerAddPopup({ showPopUp: true, type: "Add" }));
                                }}
                            >  <PiPlusSquareBold size={20} /></span>
                            <span className='mx-2'
                                onClick={async (e, data) => {
                                    await store.dispatch(leaveManagementActions.setLeaveLedgerSelectedData(selectedRow));
                                    await store.dispatch(leaveManagementActions.setLeaveLedgerPopUp(true))
                                }}
                            >  <FiEdit size={20} /> </span>
                            <span
                                onClick={async (e, data) => {
                                    await store.dispatch(leaveManagementActions.setLeaveLedgerSelectedData(selectedRow));
                                    await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you certain about deleting ${selectedRow.employeeName}'s leave ledger?`, isOptional }));
                                }}
                            > <ImBin size={20} /> </span>
                        </span>
                    </div>
                },
                lockPosition: 'right',
                pinned: 'right',
                sortable: false,
                headerClass: " !pl-2 !pr-1",
                filter: false,
                minWidth: 120,
                maxWidth: 120
            }] : leaveLedgerColumn;
        },
        contextMenuItems: ({ selectedRow }) => {
            let isOptional = true;
            return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                <MenuItem
                    data={{ menu: "leave History" }}
                    className={classNames.contextMenuItem}
                    onClick={async (e, data) => {
                        await store.dispatch(leaveManagementActions.setLeaveLedgerSelectedData(selectedRow));
                        await store.dispatch(leaveManagementActions.setLeaveLedgerAddPopup({ showPopUp: true, type: "Add" }));
                    }}
                >
                    <span className='flex items-center'> <PiPlusSquareBold size={20} /> <span className='mx-2'>Add Credit Days</span></span>
                </MenuItem>
                <MenuItem
                    data={{ menu: "Reject", }}
                    className={classNames.contextMenuItem}
                    onClick={async (e, data) => {
                        await store.dispatch(leaveManagementActions.setLeaveLedgerSelectedData(selectedRow));
                        await store.dispatch(leaveManagementActions.setLeaveLedgerPopUp(true))
                    }}
                >
                    <span className='flex items-center'> <FiEdit size={18} />  <span className='mx-2'>Edit</span></span>
                </MenuItem>
                <MenuItem
                    data={{ menu: "leave History" }}
                    className={classNames.contextMenuItem}
                    onClick={async (e, data) => {
                        await store.dispatch(leaveManagementActions.setLeaveLedgerSelectedData(selectedRow));
                        await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you certain about deleting ${selectedRow.employeeName}'s leave ledger?`, isOptional }));
                    }}
                >
                    <span className='flex items-center'><ImBin size={16.5} /> <span className='mx-2'>Delete</span></span>
                </MenuItem>
            </ContextMenu>)
        },
    },
    viewleaveLedger: {
        column: () => [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                minWidth: 150,
                maxWidth: 85,
                checkboxSelection: false,
            },
            {
                headerName: "Entry Date",
                field: "entryDate",
                headerComponent: agGridDateHeaderComponent,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                lockPosition: 'left',
                minWidth: 150,
                maxWidth: 180,
            },
            {
                headerName: "Description",
                field: "comments",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                excelWidth: 40,
                minWidth: 120,
            },
            {
                headerName: "Credit Days",
                field: "creditDays",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 150,
                maxWidth: 180,
            },
            {
                headerName: "Debit Days",
                field: "debitDays",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 150,
                maxWidth: 180,
            },
            {
                headerName: "Balance Days",
                field: "balanceDays",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                excelWidth: 25,
                minWidth: 160,
                maxWidth: 180,
            },
            {
                headerName: "Leave Type",
                field: "leaveType",
                excelWidth: 25,
                minWidth: 150,
                maxWidth: 190,
                cellRenderer: params => <ContextMenuTrigger id="staff_contextmenu_id"><div className={`${params.value ? leaveDetails.find(val => val.title === params.value.trim()).bgColor : ""} h-full m-0 pl-5 w-full`}>{params.value}</div></ContextMenuTrigger>,
            },
        ]
    }
}

export const sickLeave = {
    balanceSummary: {
        IndiaColumn: () => [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                minWidth: 130,
                maxWidth: 130,
            },
            {
                headerName: "Employee Name",
                field: "employeeName",
                excelWidth: 40,
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 350,
            },
            {
                headerName: leaveDetails[2].title,
                field: "PrivilegeLeaveBalance",
                excelWidth: 35,
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 180,
            },
            {
                headerName: leaveDetails[3].title,
                field: "CasualLeaveBalance",
                excelWidth: 35,
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 180,
            },
            {
                headerName: leaveDetails[0].title,
                field: "SickLeaveBalance",
                excelWidth: 30,
                minWidth: 80,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
        ],
        UsaColumn: () => [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                minWidth: 130,
                maxWidth: 130,
            },
            {
                headerName: "Employee Name",
                field: "employeeName",
                excelWidth: 40,
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 350,
            },
            {
                headerName: leaveDetails[1].title,
                field: "VacationLeaveBalance",
                excelWidth: 35,
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 180,
            },
            {
                headerName: leaveDetails[0].title,
                field: "SickLeaveBalance",
                excelWidth: 35,
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 180,
            },
        ]
    },
    summaryDetails: {
        column: () => [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                minWidth: 150,
                maxWidth: 150,
            },
            {
                headerName: "Employee Name",
                field: "employeeName",
                excelWidth: 40,
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 350,
            },
            {
                headerName: "Date",
                field: "entryDate",
                excelWidth: 25,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                lockPosition: 'left',
                minWidth: 160,
                maxWidth: 200,
            },
            {
                headerName: "Reason",
                field: "comments",
                excelWidth: 45,
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 180,
            },
            {
                headerName: "Days",
                field: "debitDays",
                excelWidth: 25,
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 180,
            },
            {
                headerName: "Leave Type",
                field: "leaveType",
                excelWidth: 30,
                minWidth: 80,
                maxWidth: 200,
                cellRenderer: params => <ContextMenuTrigger id="staff_contextmenu_id"><div className={`${params.value ? leaveDetails.find(val => val.title === params.value.trim()).bgColor : ""} h-full m-0 pl-5 w-full`}>{params.value}</div></ContextMenuTrigger>,
            },

        ]
    },
    leaveLedger: {
        column: () => [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                minWidth: 150,
                maxWidth: 85,
                checkboxSelection: true,
            },
            {
                headerName: "Entry Date",
                field: "entryDate",
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                lockPosition: 'left',
                minWidth: 150,
                maxWidth: 150,
            },
            {
                headerName: "Employee Name",
                field: "employeeName",
                excelWidth: 35,
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 250,
            },
            {
                headerName: "Description",
                field: "comment",
                excelWidth: 40,
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 120,
            },
            {
                headerName: "Credit Days",
                field: "creditDays",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 150,
                maxWidth: 150,
            },
            {
                headerName: "Debit Days",
                field: "debitDays",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 150,
                maxWidth: 150,
            },
            {
                headerName: "Balance Days",
                field: "balance",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                excelWidth: 25,
                minWidth: 160,
                maxWidth: 160,
            },
        ],
        contextMenuItems: ({ selectedRow }) => {
            let isOptional = true;
            return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                <MenuItem
                    data={{ menu: "leave History" }}
                    className={classNames.contextMenuItem}
                    onClick={async (e, data) => {
                        await store.dispatch(leaveManagementActions.setLeaveLedgerSelectedData(selectedRow));
                        await store.dispatch(leaveManagementActions.setLeaveLedgerAddPopup({ showPopUp: true, type: "Add" }));
                    }}
                >
                    <span className='flex items-center'> <PiPlusSquareBold size={18} /> <span className='mx-2'>Add Credit Days</span></span>
                </MenuItem>
                <MenuItem
                    data={{ menu: "Reject", }}
                    className={classNames.contextMenuItem}
                    onClick={async (e, data) => {
                        await store.dispatch(leaveManagementActions.setLeaveLedgerSelectedData(selectedRow));
                        await store.dispatch(leaveManagementActions.setLeaveLedgerPopUp(true));
                    }}
                >
                    <span className='flex items-center'> <FiEdit size={18} />  <span className='mx-2'>Edit</span></span>
                </MenuItem>
                <MenuItem
                    data={{ menu: "leave History" }}
                    className={classNames.contextMenuItem}
                    onClick={async (e, data) => {
                        await store.dispatch(leaveManagementActions.setLeaveLedgerSelectedData(selectedRow));
                        await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you certain about deleting ${selectedRow.employeeName}'s leave ledger?`, isOptional }));
                    }}
                >
                    <span className='flex items-center'><ImBin size={16.5} /> <span className='mx-2'>Delete</span></span>
                </MenuItem>
            </ContextMenu>)
        },
    }
}

export const eventManagement = {
    searchEvents: {
        column: () => [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                minWidth: 150,
                maxWidth: 85,
                excelWidth: 7,
                checkboxSelection: true,
            },
            {
                headerName: "Date",
                field: "date",
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                lockPosition: 'left',
                minWidth: 130,
                maxWidth: 130,
                excelWidth: 20
            },
            {
                headerName: "Event Topic",
                field: "eventTopic",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 150,
                excelWidth: 45
            },
            {
                headerName: "Description",
                field: "description",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 250,
                maxWidth: 400,
                excelWidth: 60
            },
            {
                headerName: "Event Type",
                field: "eventType",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 150,
                maxWidth: 180,
                excelWidth: 30
            },
            {
                headerName: "Duration(In Min)",
                field: "duration",
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                lockPosition: 'left',
                minWidth: 150,
                maxWidth: 150,
                excelWidth: 15
            },
        ],
        contextMenuItems: () => {
            return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                <MenuItem
                    data={{ menu: "Reject", }}
                    className={classNames.contextMenuItem}
                >
                    <span className='flex items-center'> <FiEdit size={18} />  <span className='mx-2'>Edit</span></span>
                </MenuItem>
                <MenuItem
                    data={{ menu: "leave History" }}
                    className={classNames.contextMenuItem}
                >
                    <span className='flex items-center'><ImBin size={16.5} /> <span className='mx-2'>Delete</span></span>
                </MenuItem>
            </ContextMenu>)
        },
    },
    EventRecordsTableView: {
        column: (isMobileCompatible) => {
            const eventRecordCols = [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    minWidth: 150,
                    maxWidth: 85,
                    excelWidth: 7,
                    checkboxSelection: !isMobileCompatible,
                },
                {
                    headerName: "Start Date",
                    headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-center'><div>{displayName}</div><div className=' text-[10.5px]'>{store.getState().user.LocationID === setDefaultValue.location.value ? "(DD/MM/YYYY HH:MM:SS)" : "(MM/DD/YYYY HH:MM:SS)"}</div></div>,
                    field: "eventStartDate",
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateAndTimeView: true }),
                    minWidth: 170,
                    maxWidth: 180,
                    excelWidth: 25
                },
                {
                    headerName: "End Date",
                    headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-center'><div>{displayName}</div><div className=' text-[10.5px]'>{store.getState().user.LocationID === setDefaultValue.location.value ? "(DD/MM/YYYY HH:MM:SS)" : "(MM/DD/YYYY HH:MM:SS)"}</div></div>,
                    field: "eventEndDate",
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateAndTimeView: true }),
                    minWidth: 170,
                    maxWidth: 180,
                    excelWidth: 25
                },
                {
                    headerName: "Event Topic",
                    field: "eventTopic",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 150,
                    excelWidth: 45
                },
                {
                    headerName: "Description",
                    field: "eventDescription",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 150,
                    excelWidth: 45,
                    tooltipField: "eventDescription"
                },
                {
                    headerName: "Event Type",
                    field: "eventType",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 150,
                    maxWidth: 180,
                    excelWidth: 30
                },
                {
                    headerName: "Duration",
                    headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-center'><div>{displayName}</div><div className=' text-12px'>(In Min)</div></div>,
                    field: "durationMin",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    cellClass: " cell-padding-left ",
                    minWidth: 93,
                    maxWidth: 93,
                    excelWidth: 15
                },
                {
                    headerName: "Created By",
                    field: "createdBy",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 140,
                    maxWidth: 140,
                    excelWidth: 30
                },
                {
                    headerName: "Created Date",
                    headerComponent: agGridDateHeaderComponent,
                    field: "createdDate",
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                    minWidth: 126,
                    maxWidth: 126,
                    excelWidth: 25
                },
            ];
            return isMobileCompatible ? [...eventRecordCols, {
                headerName: "Actions",
                field: "actions",
                cellRenderer: params => {
                    const selectedRow = params.data;

                    return <div className={` h-full w-full flex items-center justify-center ml-1`}>
                        <span className='flex items-center text-headerColor cursor-pointer'>
                            <MenuView menuData={[{
                                icon: <ImEye size={18} />, label: "View", subMenu: [{
                                    icon: <VscPreview size={18} />, label: "Event View", onClick: async () => {
                                        await store.dispatch(eventManagementActions.setViewEventLoader(true));
                                        await store.dispatch(eventManagementRequests.recordEvents.getEditEvent(selectedRow, "View"));
                                        store.dispatch(eventManagementActions.setViewEventLoader(false));
                                    }
                                }, {
                                    icon: <PiTreeView size={18} />, label: "Log View", onClick: async () => {
                                        await store.dispatch(eventManagementActions.setViewEventLoader(true));
                                        await store.dispatch(eventManagementRequests.viewEvents.LogViewEventsRequest(selectedRow.eventID));
                                        store.dispatch(eventManagementActions.setViewEventLoader(false));
                                    }
                                }]
                            }, {
                                icon: <FiEdit size={18} />, label: "Edit", onClick: async () => {
                                    await store.dispatch(eventManagementActions.setViewEventLoader(true));
                                    await store.dispatch(eventManagementRequests.recordEvents.getEditEvent(selectedRow, "Edit"));
                                    store.dispatch(eventManagementActions.setViewEventLoader(false));
                                }, isDisable: !(Object.hasOwn(selectedRow, "createdByEmpId") && (userReducerState().Role === strings.userRoles.admin || userReducerState().Role === strings.userRoles.humanResource))
                            }, {
                                icon: <ImBin size={16.5} />, label: "Delete", onClick: async () => {
                                    await store.dispatch(eventManagementActions.setSelectedRecord(selectedRow));
                                    await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to delete "${selectedRow.eventTopic}" events record?`, isOptional: true }));
                                }, isDisable: !(userReducerState().Role === strings.userRoles.admin || userReducerState().Role === strings.userRoles.humanResource)
                            }]} />
                        </span>
                    </div>
                },
                lockPosition: 'right',
                pinned: 'right',
                sortable: false,
                headerClass: " !pl-2 !pr-1",
                filter: false,
                minWidth: 40,
                maxWidth: 70
            }] : eventRecordCols;
        },
        contextMenuItems: ({ selectedRow }) => {
            return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                <SubMenu title={
                    <span className={`${classNames.contextMenuItem} flex items-center `}>
                        <ImEye size={18} />
                        <span className='mx-2'>View</span>
                    </span>
                } className={`${classNames.contextMenu} contextMenu_submenu`}>
                    <MenuItem
                        className={`${classNames.contextMenuItem} ${classNames.subContextMenu}`}
                        onClick={async () => {
                            await store.dispatch(eventManagementActions.setViewEventLoader(true));
                            await store.dispatch(eventManagementRequests.recordEvents.getEditEvent(selectedRow, "View"));
                            store.dispatch(eventManagementActions.setViewEventLoader(false));
                        }}
                    >
                        <span className='flex items-center'>
                            <VscPreview size={18} />
                            <span className='mx-2'>Event View</span>
                        </span>

                    </MenuItem>
                    <MenuItem
                        className={`${classNames.contextMenuItem} ${classNames.subContextMenu}`}
                        onClick={async () => {
                            await store.dispatch(eventManagementActions.setViewEventLoader(true));
                            await store.dispatch(eventManagementRequests.viewEvents.LogViewEventsRequest(selectedRow.eventID));
                            store.dispatch(eventManagementActions.setViewEventLoader(false));
                        }}
                    >
                        <span className='flex items-center'>
                            <PiTreeView size={18} />
                            <span className='mx-2'>Log View</span>
                        </span>
                    </MenuItem>
                </SubMenu>
                {selectedRow && Object.hasOwn(selectedRow, "createdByEmpId") && ((userReducerState().Role === strings.userRoles.admin || userReducerState().Role === strings.userRoles.humanResource) || selectedRow.createdByEmpId === userReducerState().UserID) && <MenuItem
                    data={{ menu: "Reject", }}
                    className={classNames.contextMenuItem}
                    onClick={async () => {
                        await store.dispatch(eventManagementActions.setViewEventLoader(true));
                        await store.dispatch(eventManagementRequests.recordEvents.getEditEvent(selectedRow, "Edit"));
                        store.dispatch(eventManagementActions.setViewEventLoader(false));
                    }}
                >
                    <span className='flex items-center'> <FiEdit size={18} />  <span className='mx-2'>Edit</span></span>
                </MenuItem>}
                {selectedRow && ((userReducerState().Role === strings.userRoles.admin || userReducerState().Role === strings.userRoles.humanResource)) && <MenuItem
                    data={{ menu: "leave History" }}
                    className={classNames.contextMenuItem}
                    onClick={async () => {
                        await store.dispatch(eventManagementActions.setSelectedRecord(selectedRow));
                        await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to delete "${selectedRow.eventTopic}" events record?`, isOptional: true }));
                    }}
                >
                    <span className='flex items-center'><ImBin size={16.5} /> <span className='mx-2'>Delete</span></span>
                </MenuItem>}
            </ContextMenu>)
        },
        LogViewPopupcolumn: () => [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                minWidth: 150,
                maxWidth: 85,
            },
            {
                headerName: "Event Start Date",
                headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-center'><div>{displayName}</div><div className=' text-[10.5px]'>{store.getState().user.LocationID === setDefaultValue.location.value ? "(DD/MM/YYYY HH:MM:SS)" : "(MM/DD/YYYY HH:MM:SS)"}</div></div>,
                field: "EventStartDate",
                cellRenderer: params => SetContextMenuTrigger({ params, isDateAndTimeView: true }),
                minWidth: 170,
                maxWidth: 180,
            },
            {
                headerName: "Event End Date",
                headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-center'><div>{displayName}</div><div className=' text-[10.5px]'>{store.getState().user.LocationID === setDefaultValue.location.value ? "(DD/MM/YYYY HH:MM:SS)" : "(MM/DD/YYYY HH:MM:SS)"}</div></div>,
                field: "EventEndDate",
                cellRenderer: params => SetContextMenuTrigger({ params, isDateAndTimeView: true }),
                minWidth: 170,
                maxWidth: 180,
            },
            {
                headerName: "Event Topic",
                field: "EventTopic",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 120,
            },
            {
                headerName: "Modified Date",
                headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-center'><div>{displayName}</div><div className=' text-[10.5px]'>{store.getState().user.LocationID === setDefaultValue.location.value ? "(DD/MM/YYYY)" : "(MM/DD/YYYY)"}</div></div>,
                field: "LastModifiedDate",
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                minWidth: 130,
                maxWidth: 130,
            },
            {
                headerName: "Modified By",
                field: "LastModifiedBy",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 160,
            },
            {
                headerName: "Modified Column",
                field: "modifiedColumn",
                cellRenderer: params => params.value && params.value.length > 0 && <ContextMenuTrigger id="staff_contextmenu_id">{params.value.split('~').length > 0 ? (params.value.split(',').map((val, idx) => <div key={`${val} ${idx}`} className={classNames.contextMenuValue}>{val}</div>)) : <div className={classNames.contextMenuValue}>{params.value}</div>} </ContextMenuTrigger>,
                minWidth: 150,
                autoHeight: true,
                wrapText: true,
            },
            {
                headerName: "Modified Details",
                field: "ModifiedValue",
                cellRenderer: params => params.value && params.value.length > 0 &&
                    <div >{params.value.split('~').length > 0
                        ? (params.value.split('~').map((val, idx) => val.split("\n").length > 0
                            ? val.split("\n").map((value, index) => <div key={index} className="pl-5 pr-2">{value}</div>)
                            : <div key={idx} className="pl-5 pr-2">{val}</div>))
                        : <div className="pl-5 pr-2">{params.value}</div>}
                    </div>,
                minWidth: 400,
                autoHeight: true,
                wrapText: true,
            }
        ]
    },
    AttendanceRecordTableView: {
        column: () => [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                minWidth: 150,
                maxWidth: 85,
                excelWidth: 7,
                checkboxSelection: true,
            },
            {
                headerName: "Date",
                field: "date",
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                lockPosition: 'left',
                minWidth: 130,
                maxWidth: 130,
                excelWidth: 20
            },
            {
                headerName: "Event Topic",
                field: "eventTopic",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 150,
                excelWidth: 45
            },
            {
                headerName: "Description",
                field: "description",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 250,
                maxWidth: 400,
                excelWidth: 60
            },
            {
                headerName: "Event Type",
                field: "eventType",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                minWidth: 150,
                maxWidth: 180,
                excelWidth: 30
            },
            {
                headerName: "Duration(In Min)",
                field: "duration",
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                lockPosition: 'left',
                minWidth: 150,
                maxWidth: 150,
                excelWidth: 15
            },
        ],
        contextMenuItems: ({ selectedRow }) => {
            return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                <MenuItem
                    data={{ menu: "Reject", }}
                    className={classNames.contextMenuItem}
                >
                    <span className='flex items-center'> <FiEdit size={18} />  <span className='mx-2'>Edit</span></span>
                </MenuItem>
                <MenuItem
                    data={{ menu: "leave History" }}
                    className={classNames.contextMenuItem}
                >
                    <span className='flex items-center'><ImBin size={16.5} /> <span className='mx-2'>Delete</span></span>
                </MenuItem>
            </ContextMenu>)
        },
    },
    FacilityPersonalReport: {
        column: () => [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                minWidth: 59,
                maxWidth: 59,
                headerClass: " !pl-1 !pr-1 custom-gridHeader",
                cellClass: "custom-gridCell",
            },
            {
                headerName: "PFI 9762",
                wrapHeaderText: true,
                headerClass: " !pl-1 !pr-1 custom-gridHeader",
                cellClass: "custom-gridCell",
                children: [
                    {
                        headerName: "Employee Name",
                        wrapHeaderText: true,
                        headerClass: " !pl-1 !pr-1 custom-gridHeader",
                        cellClass: "custom-gridCell",
                        children: [
                            {
                                headerName: "First",
                                field: "firstName",
                                cellRenderer: params => setReportContextMenu({ params }),
                                lockPosition: 'left',
                                minWidth: 130,
                                wrapHeaderText: true,
                                wrapText: true,
                                autoHeight: true,
                                headerClass: " !pl-1 !pr-1 custom-gridHeader",
                                cellClass: "custom-gridCell",
                            },
                            {
                                headerName: "Last",
                                field: "lastName",
                                cellRenderer: params => setReportContextMenu({ params }),
                                lockPosition: 'left',
                                minWidth: 130,
                                wrapHeaderText: true,
                                wrapText: true,
                                autoHeight: true,
                                headerClass: " !pl-1 !pr-1 custom-gridHeader",
                                cellClass: "custom-gridCell",
                            }
                        ]
                    },
                    {
                        headerName: "Education",
                        headerClass: " !pl-1 !pr-1 custom-gridHeader",
                        cellClass: "custom-gridCell",
                        wrapHeaderText: true,
                        children: [
                            {
                                headerName: "Degree",
                                field: "qualification",
                                cellRenderer: params => setReportContextMenu({ params }),
                                lockPosition: 'left',
                                minWidth: 130,
                                wrapHeaderText: true,
                                wrapText: true,
                                autoHeight: true,
                                headerClass: " !pl-1 !pr-1 custom-gridHeader",
                                cellClass: "custom-gridCell",
                            },
                            {
                                headerName: "Major",
                                field: "majorSubject",
                                cellRenderer: params => setReportContextMenu({ params }),
                                lockPosition: 'left',
                                minWidth: 130,
                                wrapHeaderText: true,
                                wrapText: true,
                                autoHeight: true,
                                headerClass: " !pl-1 !pr-1 custom-gridHeader",
                                cellClass: "custom-gridCell",
                            },
                            {
                                headerName: "Year",
                                field: "courseEndDate",
                                cellRenderer: params => setReportContextMenu({ params }),
                                lockPosition: 'left',
                                minWidth: 50,
                                maxWidth: 50,
                                wrapHeaderText: true,
                                wrapText: true,
                                autoHeight: true,
                                headerClass: " !pl-1 !pr-1 custom-gridHeader",
                                cellClass: "custom-gridCell",
                            }
                        ]
                    },
                    {
                        headerName: "Yrs Exp",
                        field: "yrsExp",
                        cellRenderer: params => setReportContextMenu({ params }),
                        lockPosition: 'left',
                        minWidth: 65,
                        maxWidth: 65,
                        wrapHeaderText: true,
                        wrapText: true,
                        autoHeight: true,
                        headerClass: " !pl-1 !pr-1 custom-gridHeader",
                        cellClass: "custom-gridCell",
                    },
                    {
                        headerName: "Job Title",
                        field: "designationName",
                        cellRenderer: params => setReportContextMenu({ params }),
                        lockPosition: 'left',
                        minWidth: 130,
                        wrapHeaderText: true,
                        wrapText: true,
                        autoHeight: true,
                        headerClass: " !pl-1 !pr-1 custom-gridHeader",
                        cellClass: "custom-gridCell",
                    },
                    {
                        headerName: "Dept",
                        field: "departmentName",
                        cellRenderer: params => setReportContextMenu({ params }),
                        lockPosition: 'left',
                        minWidth: 130,
                        wrapHeaderText: true,
                        wrapText: true,
                        autoHeight: true,
                        headerClass: " !pl-1 !pr-1 custom-gridHeader",
                        cellClass: "custom-gridCell",
                    }
                ]
            },
            {
                headerName: "Survey Date",
                wrapHeaderText: true,
                headerClass: " !pl-1 !pr-1 custom-gridHeader",
                cellClass: "custom-gridCell",
                children: [
                    {
                        headerName: "Shift",
                        headerClass: " !pl-1 !pr-1 custom-gridHeader",
                        cellClass: "custom-gridCell",
                        children: [
                            {
                                headerName: "1",
                                field: "shift1",
                                cellRenderer: params => setReportContextMenu({ params, isDateView: true }),
                                lockPosition: 'left',
                                minWidth: 35,
                                maxWidth: 35,
                                wrapText: true,
                                autoHeight: true,
                                headerClass: " !pl-1 !pr-1 custom-gridHeader",
                                cellClass: "custom-gridCell",
                            },
                            {
                                headerName: "2",
                                field: "shift2",
                                cellRenderer: params => setReportContextMenu({ params, isDateView: true }),
                                lockPosition: 'left',
                                minWidth: 35,
                                maxWidth: 35,
                                wrapText: true,
                                autoHeight: true,
                                headerClass: " !pl-1 !pr-1 custom-gridHeader",
                                cellClass: "custom-gridCell",
                            },
                            {
                                headerName: "3",
                                field: "shift3",
                                cellRenderer: params => setReportContextMenu({ params, isDateView: true }),
                                lockPosition: 'left',
                                minWidth: 35,
                                maxWidth: 35,
                                wrapText: true,
                                autoHeight: true,
                                headerClass: " !pl-1 !pr-1 custom-gridHeader",
                                cellClass: "custom-gridCell",
                            },
                            {
                                headerName: "W",
                                field: "shift",
                                cellRenderer: params => setReportContextMenu({ params, isDateView: true }),
                                lockPosition: 'left',
                                minWidth: 35,
                                maxWidth: 35,
                                wrapText: true,
                                autoHeight: true,
                                headerClass: " !pl-1 !pr-1 custom-gridHeader",
                                cellClass: "custom-gridCell",
                            }
                        ]
                    },
                    {
                        headerName: "Hrs: FT PT PD",
                        field: "hrs",
                        cellRenderer: params => setReportContextMenu({ params }),
                        lockPosition: 'left',
                        minWidth: 60,
                        maxWidth: 60,
                        wrapHeaderText: true,
                        wrapText: true,
                        autoHeight: true,
                        headerClass: " !pl-1 !pr-1 custom-gridHeader",
                        cellClass: "custom-gridCell",
                    },
                    {
                        headerName: "CLEP Review",
                        headerClass: " !pl-1 !pr-1 custom-gridHeader",
                        cellClass: "custom-gridCell",
                        children: [
                            {
                                headerName: "Appr. as:",
                                field: "appr",
                                cellRenderer: params => setReportContextMenu({ params }),
                                lockPosition: 'left',
                                minWidth: 75,
                                maxWidth: 75,
                                wrapHeaderText: true,
                                wrapText: true,
                                autoHeight: true,
                                headerClass: " !pl-1 !pr-1 custom-gridHeader",
                                cellClass: "custom-gridCell",
                            },
                            {
                                headerName: "Comments",
                                field: "comments",
                                cellRenderer: params => setReportContextMenu({ params }),
                                lockPosition: 'left',
                                minWidth: 80,
                                maxWidth: 80,
                                wrapHeaderText: true,
                                wrapText: true,
                                autoHeight: true,
                                headerClass: " !pl-1 !pr-1 custom-gridHeader",
                                cellClass: "custom-gridCell",
                            },
                            {
                                headerName: "Reviewed By",
                                field: "reviewedBy",
                                cellRenderer: params => setReportContextMenu({ params }),
                                lockPosition: 'left',
                                minWidth: 100,
                                maxWidth: 100,
                                wrapHeaderText: true,
                                autoHeaderHeight: true,
                                wrapText: true,
                                autoHeight: true,
                                headerClass: " !pl-1 !pr-1 custom-gridHeader",
                                cellClass: "custom-gridCell",
                            },
                            {
                                headerName: "Reviewed Date",
                                field: "reviewDate",
                                cellRenderer: params => setReportContextMenu({ params, isDateView: true }),
                                lockPosition: 'left',
                                minWidth: 100,
                                maxWidth: 100,
                                wrapHeaderText: true,
                                wrapText: true,
                                autoHeight: true,
                                headerClass: " !pl-1 !pr-1 custom-gridHeader",
                                cellClass: "custom-gridCell",
                            }
                        ]
                    },
                ]
            }
        ],
        printColumn:
        {
            multiLineHeader: [
                [{ content: "S.No", field: "sno", rowSpan: 3, styles: { valign: "center" } },
                { content: "PFI 9762", colSpan: 8, },
                { content: "Survey Date", colSpan: 9, }
                ],
                [
                    { content: "Employee Name", colSpan: 2, },
                    { content: "Education", colSpan: 3, },
                    { content: "Yrs Exp", rowSpan: 2, styles: { valign: "center" }, field: "yrsExp", },
                    { content: "Job Title", rowSpan: 2, styles: { valign: "center" }, field: "designationName", },
                    { content: "Dept", rowSpan: 2, styles: { valign: "center" }, field: "departmentName", },
                    { content: "Shift", colSpan: 4, },
                    { content: "Hrs: FT PT PD", rowSpan: 2, field: "hrs", },
                    { content: "CLEP Review", colSpan: 4, },
                ],
                [
                    { content: "First", field: "firstName", },
                    { content: "Last", field: "lastName", },
                    { content: "Degree", field: "qualification", },
                    { content: "Major", field: "majorSubject", },
                    { content: "Year", field: "courseEndDate", },
                    { content: "1", field: "shift1", },
                    { content: "2", field: "shift2", },
                    { content: "3", field: "shift3", },
                    { content: "w", field: "shift", },
                    { content: "Appr.as:", field: "appr", },
                    { content: "comments", field: "comments" },
                    { content: "Reviewed By", field: "reviewedBy", },
                    { content: "Reviewed Date", field: "reviewDate", },
                ]],
            fieldHeader: [
                {
                    headerName: "S.No",
                    field: "sno"
                },
                {
                    headerName: "First",
                    field: "firstName",
                    wrapHeaderText: true,
                },
                {
                    headerName: "Last",
                    field: "lastName",
                    wrapHeaderText: true,
                },
                {
                    headerName: "Degree",
                    field: "qualification",
                    wrapHeaderText: true,
                },
                {
                    headerName: "Major",
                    field: "majorSubject",
                    wrapHeaderText: true,
                },
                {
                    headerName: "Year",
                    field: "courseEndDate",
                    wrapHeaderText: true,
                },
                {
                    headerName: "Yrs Exp",
                    field: "yrsExp",
                    wrapHeaderText: true,
                },
                {
                    headerName: "Job Title",
                    field: "designationName",
                    wrapHeaderText: true,
                },
                {
                    headerName: "Dept",
                    field: "departmentName",
                    wrapHeaderText: true,
                },
                {
                    headerName: "1",
                    field: "shift1",
                },
                {
                    headerName: "2",
                    field: "shift2",
                },
                {
                    headerName: "3",
                    field: "shift3",
                },
                {
                    headerName: "W",
                    field: "shift",
                },
                {
                    headerName: "Hrs: FT PT PD",
                    field: "hrs",
                },
                {
                    headerName: "Appr. as:",
                    field: "appr",
                },
                {
                    headerName: "Comments",
                    field: "comments"
                },
                {
                    headerName: "Reviewed By",
                    field: "reviewedBy",
                },
                {
                    headerName: "Reviewed Date",
                    field: "reviewDate",
                }
            ]
        }
    }
}

export const myRequests = {
    myRequest: {
        column: (isMobileCompatible) => {
            const myRequestColumns = [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    minWidth: 150,
                    maxWidth: 85,
                    excelWidth: 7,
                    checkboxSelection: params => !leaveRequestApprovalValidation(leaveStatus.find(val => val.label === params.data.requestStatus).Key, status.approved) && !isMobileCompatible,
                },
                {
                    headerName: "Date of Request",
                    field: "createdDate",
                    minWidth: 170,
                    maxWidth: 300,
                    excelWidth: 20,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                },
                {
                    headerName: "Types of Request",
                    field: "request",
                    minWidth: 170,
                    maxWidth: 300,
                    excelWidth: 20,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
                {
                    headerName: "Description",
                    field: "description",
                    minWidth: 170,
                    excelWidth: 35,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
                {
                    headerName: "Status",
                    field: "requestStatus",
                    minWidth: 170,
                    maxWidth: 300,
                    excelWidth: 20,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                }
            ];
            return isMobileCompatible ? [...myRequestColumns, {
                headerName: "Actions",
                field: "actions",
                cellRenderer: params => {
                    const selectedRow = params.data;
                    const onhandleNavigate = async () => {
                        await store.dispatch(myRequestActions.setLoader(true));
                        await store.dispatch(myRequestRequests.getRequestDetails(selectedRow.requestId));
                        store.dispatch(myRequestActions.setLoader(false));
                    }
                    return <div className=" h-full w-full flex items-center justify-center ml-5">
                        <span className='flex items-center text-headerColor cursor-pointer' onClick={onhandleNavigate}>
                            {!leaveRequestApprovalValidation(leaveStatus.find(val => val.label === params.data.requestStatus).Key, status.approved) && <FiEdit size={18} />}
                            <span className='mx-2'>{!leaveRequestApprovalValidation(leaveStatus.find(val => val.label === params.data.requestStatus).Key, status.approved) && "Edit"}</span>
                        </span>

                    </div>
                },
                lockPosition: 'right',
                pinned: 'right',
                sortable: false,
                headerClass: " !pl-2 !pr-1",
                filter: false,
                minWidth: 70,
                maxWidth: 70
            }] : myRequestColumns;
        },
        contextMenuItems: ({ selectedRow }) => {
            return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu} >
                {!leaveRequestApprovalValidation(leaveStatus.find(val => val.label === selectedRow.requestStatus).Key, status.approved) &&
                    <MenuItem
                        data={{ menu: "EditMyRequest", }}
                        className={classNames.contextMenuItem}
                        onClick={async (e, data) => {
                            await store.dispatch(myRequestActions.setLoader(true));
                            await store.dispatch(myRequestRequests.getRequestDetails(selectedRow.requestId));
                            store.dispatch(myRequestActions.setLoader(false));
                        }}
                    >
                        <span className='flex items-center'> <FiEdit size={18} />  <span className='mx-2'>Edit</span></span>
                    </MenuItem>
                }
            </ContextMenu >)
        }
    },
    approveRejectRequest: {
        columns: (isMobileCompatible) => {
            const approveRejectColumns = [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7,
                    checkboxSelection: !isMobileCompatible,
                },
                {
                    headerName: "Employee Name",
                    field: "employeeName",
                    minWidth: 170,
                    excelWidth: 40,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
                {
                    headerName: "Date of Request",
                    field: "createdDate",
                    minWidth: 170,
                    maxWidth: 170,
                    excelWidth: 20,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                },
                {
                    headerName: "Types of Request",
                    field: "request",
                    minWidth: 170,
                    maxWidth: 170,
                    excelWidth: 25,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
                {
                    headerName: "Description",
                    field: "description",
                    minWidth: 200,
                    excelWidth: 40,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
                // {
                //     headerName: "Uploaded File",
                //     field: "imageName",
                //     minWidth: 160,
                //     maxWidth: 160,
                //     excelWidth: 40,
                //     cellRenderer: params => SetContextMenuTrigger(params, false, false, true, false, async() => {
                //         await store.dispatch(myRequestActions.setLoader(true));
                //         await store.dispatch(employeeRequests.getEmployeeDocument("employeeDetails/requestDocument", ("requestId" in params.data) ? params.data.requestId : 0));
                //         store.dispatch(myRequestActions.setLoader(false));
                //     }, false, false),
                // },
                {
                    headerName: "Status",
                    field: "requestStatus",
                    minWidth: 170,
                    maxWidth: 170,
                    excelWidth: 20,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
                {
                    headerName: "Approval Date",
                    field: "reviewedOn",
                    minWidth: 140,
                    maxWidth: 140,
                    excelWidth: 20,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                },
                {
                    headerName: "Approved By",
                    field: "reviewedBy",
                    minWidth: 170,
                    excelWidth: 40,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                }
            ];
            return isMobileCompatible ? [...approveRejectColumns, {
                headerName: "Actions",
                field: "actions",
                cellRenderer: params => {
                    const selectedRow = params.data;

                    return <div className=" h-full w-full flex items-center justify-center ml-5">
                        <span className='flex items-center text-headerColor cursor-pointer' >
                            {!leaveRequestApprovalValidation(leaveStatus.find(val => val.label === selectedRow?.requestStatus)?.Key, status.approved) && (
                                <span className='flex items-center text-headerColor cursor-pointer gap-2' >
                                    <span onClick={async (e, data) => {
                                        await store.dispatch(myRequestActions.setLoader(true));
                                        await store.dispatch(myRequestActions.setApprovePopup({ show: true, selectedRow: selectedRow, actions: "Approve", loader: false }));
                                        store.dispatch(myRequestActions.setLoader(false));
                                    }}>
                                        <TiTick size={18} />
                                    </span>

                                    <span onClick={async (e, data) => {
                                        await store.dispatch(myRequestActions.setLoader(true));
                                        await store.dispatch(myRequestActions.setApprovePopup({ show: true, selectedRow: selectedRow, actions: "Reject", loader: false }));
                                        store.dispatch(myRequestActions.setLoader(false));
                                    }}>
                                        <IoClose size={18} />
                                    </span>
                                </span>
                            )}
                            {(selectedRow.requestStatus === leaveStatus[1].label || selectedRow.requestStatus === leaveStatus[2].label) && (
                                <span className='flex items-center text-headerColor cursor-pointer' onClick={async (e, data) => {
                                    await store.dispatch(myRequestActions.setLoader(true));
                                    await store.dispatch(myRequestActions.setApprovePopup({ show: true, selectedRow: selectedRow, actions: "View", loader: false }));
                                    store.dispatch(myRequestActions.setLoader(false));
                                }}>
                                    <ImEye size={18} />
                                    <span className='mx-2'>{"View"}</span>
                                </span>

                            )}


                        </span>

                    </div>
                },
                lockPosition: 'right',
                pinned: 'right',
                sortable: false,
                headerClass: " !pl-2 !pr-1",
                filter: false,
                minWidth: 70,
                maxWidth: 70
            }] : approveRejectColumns;
        },
        contextMenuItems: ({ selectedRow }) => {
            return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu} >
                {(selectedRow.requestStatus === leaveStatus[1].label || selectedRow.requestStatus === leaveStatus[2].label) && <MenuItem
                    className={classNames.contextMenuItem}
                    onClick={async (e, data) => {
                        await store.dispatch(myRequestActions.setLoader(true));
                        await store.dispatch(myRequestActions.setApprovePopup({ show: true, selectedRow: selectedRow, actions: "View", loader: false }));
                        store.dispatch(myRequestActions.setLoader(false));
                    }}
                >
                    <span className='flex items-center'> <ImEye size={18} /> <span className='mx-2'>View</span></span>
                </MenuItem>}
                {!leaveRequestApprovalValidation(leaveStatus.find(val => val.label === selectedRow.requestStatus).Key, status.approved) && <>
                    <MenuItem
                        className={classNames.contextMenuItem}
                        onClick={async (e, data) => {
                            await store.dispatch(myRequestActions.setLoader(true));
                            await store.dispatch(myRequestActions.setApprovePopup({ show: true, selectedRow: selectedRow, actions: "Approve", loader: false }));
                            store.dispatch(myRequestActions.setLoader(false));
                        }}
                    >
                        <span className='flex items-center'> <TiTick size={18.5} /> <span className='mx-2'>Approve</span></span>
                    </MenuItem>
                    <MenuItem
                        className={classNames.contextMenuItem}
                        onClick={async (e, data) => {
                            await store.dispatch(myRequestActions.setLoader(true));
                            await store.dispatch(myRequestActions.setApprovePopup({ show: true, selectedRow: selectedRow, actions: "Reject", loader: false }));
                            store.dispatch(myRequestActions.setLoader(false));
                        }}
                    >
                        <span className='flex items-center'> <IoClose size={18} style={{ strokeWidth: "18px" }} /> <span className='mx-2'>Reject</span></span>
                    </MenuItem>
                </>}

            </ContextMenu>)
        }
    },
    TrackingRequest: {
        columns: [
            {
                headerName: "S.No",
                field: "sno",
                excelWidth: 7
            },
            {
                headerName: "Requested By",
                field: "employeeName",
                excelWidth: 30
            },
            {
                headerName: "Request Date",
                field: "requestDate",
                excelWidth: 14
            },
            {
                headerName: "Assigned By",
                field: "approvedBy",
                excelWidth: 30
            },
            {
                headerName: "Assigned To",
                field: "assignedTo",
                excelWidth: 30
            },
            {
                headerName: "Approved On",
                field: "approvedOn",
                excelWidth: 14
            },
            {
                headerName: "Request Type",
                field: "requestType",
                excelWidth: 85
            },
            {
                headerName: "Request Status",
                field: "status",
                excelWidth: 15
            }
        ]
    }
}

export const generateReport = {
    columns: [
        {
            headerName: "S.No",
            field: "sno",
            comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
            cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
            lockPosition: 'left',
            minWidth: 150,
            maxWidth: 85,
            excelWidth: 7,
        },
        {
            headerName: "Employee Name",
            field: "EmployeeName",
            cellRenderer: params => SetContextMenuTrigger({ params }),
            minWidth: 260,
            excelWidth: 40
        },
        {
            headerName: "Date Of Join",
            headerComponent: agGridDateHeaderComponent,
            field: "DOJ",
            cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
            minWidth: 130,
            maxWidth: 130,
            excelWidth: 20
        },
        {
            headerName: "Designation",
            field: "Designation",
            cellRenderer: params => SetContextMenuTrigger({ params }),
            minWidth: 230,
            excelWidth: 30
        },
        {
            headerName: "Duration(In Hrs)",
            field: "TotalHours",
            cellRenderer: params => SetContextMenuTrigger({ params }),
            minWidth: 150,
            maxWidth: 180,
            excelWidth: 25
        },
    ]
}

export const generateDetails = {
    columns: [
        {
            headerName: "S.No",
            field: "sno",
            comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
            cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
            lockPosition: 'left',
            minWidth: 150,
            maxWidth: 85,
            excelWidth: 7,
        },
        {
            headerName: "Start Date",
            headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-center'><div>{displayName}</div><div className=' text-[10.5px]'>{store.getState().user.LocationID === setDefaultValue.location.value ? "(DD/MM/YYYY HH:MM:SS)" : "(MM/DD/YYYY HH:MM:SS)"}</div></div>,
            field: "EventStartDate",
            cellRenderer: params => SetContextMenuTrigger({ params, isDateAndTimeView: true }),
            minWidth: 170,
            maxWidth: 180,
            excelWidth: 25
        },
        {
            headerName: "End Date",
            headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-center'><div>{displayName}</div><div className=' text-[10.5px]'>{store.getState().user.LocationID === setDefaultValue.location.value ? "(DD/MM/YYYY HH:MM:SS)" : "(MM/DD/YYYY HH:MM:SS)"}</div></div>,
            field: "EventEndDate",
            cellRenderer: params => SetContextMenuTrigger({ params, isDateAndTimeView: true }),
            minWidth: 170,
            maxWidth: 180,
            excelWidth: 25
        },
        {
            headerName: "Event",
            field: "EventTopic",
            cellRenderer: params => SetContextMenuTrigger({ params }),
            minWidth: 230,
            excelWidth: 30
        },
        {
            headerName: "Event Description",
            field: "EventDescription",
            cellRenderer: params => SetContextMenuTrigger({ params }),
            minWidth: 200,
            excelWidth: 40
        },
        {
            headerName: "Duration(In Mins)",
            field: "DurationMin",
            cellRenderer: params => SetContextMenuTrigger({ params }),
            minWidth: 150,
            maxWidth: 160,
            excelWidth: 25
        },
    ]
}

export const generateSummary = {
    columns: [
        {
            headerName: "Program",
            field: "PartLevel",
            minWidth: 80,
            headerClass: "  custom-gridHeader",
            cellClass: "custom-gridCell",
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Conference",
            field: "Conference",
            minWidth: 80,
            headerClass: "  custom-gridHeader",
            cellClass: "custom-gridCell",
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Lecture",
            field: "Lecture",
            minWidth: 80,
            headerClass: "  custom-gridHeader",
            cellClass: "custom-gridCell",
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Safety Lecture",
            field: "SafetyLecture",
            minWidth: 100,
            headerClass: "  custom-gridHeader",
            cellClass: "custom-gridCell",
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Seminar",
            field: "Seminar",
            minWidth: 80,
            headerClass: "  custom-gridHeader",
            cellClass: "custom-gridCell",
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Training New Employee",
            field: "TrainingNewEmployee",
            minWidth: 200,
            headerClass: "  custom-gridHeader",
            cellClass: "custom-gridCell",
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Working Dicussion",
            field: "WorkingDiscussion",
            minWidth: 170,
            headerClass: "  custom-gridHeader",
            cellClass: "custom-gridCell",
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Laboratory Cross Training",
            field: "LaboratoryCrossTraining",
            minWidth: 210,
            headerClass: "  custom-gridHeader",
            cellClass: "custom-gridCell",
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "New Instrument Training",
            field: "NewInstrumentTraining",
            minWidth: 210,
            headerClass: "  custom-gridHeader",
            cellClass: "custom-gridCell",
            cellRenderer: params => SetContextMenuTrigger({ params }),
        }
    ],
    documentView: [
        {
            headerName: "S.No",
            field: "sno",
            comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
            cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
            lockPosition: 'left',
            minWidth: 150,
            maxWidth: 85,
        },
        {
            headerName: "Start Date",
            headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-center'><div>{displayName}</div><div className=' text-[10.5px]'>{store.getState().user.LocationID === setDefaultValue.location.value ? "(DD/MM/YYYY HH:MM:SS)" : "(MM/DD/YYYY HH:MM:SS)"}</div></div>,
            field: "eventStartDate",
            cellRenderer: params => SetContextMenuTrigger({ params, isDateAndTimeView: true }),
            minWidth: 170,
            maxWidth: 180,
        },
        {
            headerName: "End Date",
            headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-center'><div>{displayName}</div><div className=' text-[10.5px]'>{store.getState().user.LocationID === setDefaultValue.location.value ? "(DD/MM/YYYY HH:MM:SS)" : "(MM/DD/YYYY HH:MM:SS)"}</div></div>,
            field: "eventEndDate",
            cellRenderer: params => SetContextMenuTrigger({ params, isDateAndTimeView: true }),
            minWidth: 170,
            maxWidth: 180,
        },
        {
            headerName: "Duration",
            field: "durationInHrs",
            headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-center'><div>{displayName}</div><div className=' text-12px'>(In Hrs)</div></div>,
            cellRenderer: params => SetContextMenuTrigger({ params }),
            cellClass: " cell-padding-left ",
            minWidth: 93,
            maxWidth: 93
        },
        {
            headerName: "Event",
            field: "eventTopic",
            cellRenderer: params => SetContextMenuTrigger({ params }),
            minWidth: 230,
        },
        {
            headerName: "Event Description",
            field: "eventDescription",
            cellRenderer: params => SetContextMenuTrigger({ params }),
            minWidth: 200,
        },
        {
            headerName: "Document View",
            field: "fileName",
            minWidth: 150,
            cellRenderer: params => SetContextMenuTrigger({
                params, isSelectable: true, onclick: () => {
                    store.dispatch(userRequest.imageViewer({ show: true, data: params.data.fileImageBinary, imageName: params.value }));
                }
            }),

        }
    ]
}



export const permission = {
    permissionRequest: {
        columns: (isMobileCompatible) => {
            const permissionHistorycolumns = [

                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    checkboxSelection: !isMobileCompatible,
                    minWidth: 150,
                    maxWidth: 85,
                    excelWidth: 7,
                },
                {
                    headerName: "Date",
                    headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-center'><div>{displayName}</div><div className=' text-[10.5px]'>{store.getState().user.LocationID === setDefaultValue.location.value ? "(DD/MM/YYYY)" : "(MM/DD/YYYY)"}</div></div>,
                    field: "permissionDate",
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                    minWidth: 120,
                    maxWidth: 120,
                    excelWidth: 15
                },
                {
                    headerName: "Start Time",
                    headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-center'><div>{displayName}</div><div className=' text-[10.5px]'>(HH:MM:SS)</div></div>,
                    field: "fromTime",
                    cellRenderer: params => SetContextMenuTrigger({ params, isTimeView: true }),
                    minWidth: 110,
                    maxWidth: 110,
                    excelWidth: 15
                },
                {
                    headerName: "End Time",
                    headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-center'><div>{displayName}</div><div className=' text-[10.5px]'>(HH:MM:SS)</div></div>,
                    field: "toTime",
                    cellRenderer: params => SetContextMenuTrigger({ params, isTimeView: true }),
                    minWidth: 110,
                    maxWidth: 110,
                    excelWidth: 15
                },
                {
                    headerName: "Hrs Taken",
                    field: "noofHrs",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 103,
                    maxWidth: 103,
                    excelWidth: 15
                },
                {
                    headerName: "Remarks",
                    field: "remarks",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 400,
                    width: 500,
                    excelWidth: 100
                },
                {
                    headerName: "Permission Type",
                    field: "permissionType",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 145,
                    excelWidth: 20
                },
                {
                    headerName: "Permission Status",
                    field: 'approvalStatus',
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 160,
                    excelWidth: 20
                }
            ];
            return isMobileCompatible ? [...permissionHistorycolumns, {
                headerName: "Actions",
                field: "actions",
                cellRenderer: params => {
                    const selectedRow = params.data;

                    return <div className=" h-full w-full flex items-center justify-center ml-5 gap-2">
                        {
                            selectedRow && (Object.hasOwn(selectedRow, "status") && selectedRow.status === leaveStatus[4].Key && ("permissionTypeID" in selectedRow) && selectedRow.permissionTypeID !== permissionTypes[2].value) &&
                            <span className='flex items-center text-headerColor cursor-pointer' onClick={async () => {
                                await store.dispatch(permissionAction.setLoader(true));
                                await store.dispatch(permissionAction.setAddPermissionPopup({ show: true, selectedRow: selectedRow, type: "Edit" }))
                                store.dispatch(permissionAction.setLoader(false));
                            }}>{<FiEdit size={18} />}</span>
                        }
                        {
                            selectedRow && ((Object.hasOwn(selectedRow, "status") && selectedRow.status !== leaveStatus[4].Key) || (("permissionTypeID" in selectedRow) && selectedRow.permissionTypeID === permissionTypes[2].value)) &&
                            <span className='flex items-center text-headerColor cursor-pointer' onClick={async () => {
                                await store.dispatch(permissionAction.setLoader(true));
                                await store.dispatch(permissionAction.setAddPermissionPopup({ show: true, selectedRow: selectedRow, type: "View" }))
                                store.dispatch(permissionAction.setLoader(false));
                            }}> {<ImEye size={18} />} <span className='mx-2'>{"View"}</span>  </span>
                        }
                        {
                            selectedRow && Object.hasOwn(selectedRow, "status") && (selectedRow.status === leaveStatus[1].Key || selectedRow.status === leaveStatus[4].Key) && ("permissionTypeID" in selectedRow) && selectedRow.permissionTypeID !== permissionTypes[2].value &&
                            <span className='flex items-center text-headerColor cursor-pointer' onClick={async () => {
                                await store.dispatch(permissionAction.setLoader(true));
                                await store.dispatch(permissionRequests.getPermissionDetailRequest({ permissionId: selectedRow.permissionID }, status.tobeCancelled))
                                store.dispatch(permissionAction.setLoader(false));
                            }}>  {<TiCancel size={18} />}</span>
                        }

                    </div>
                },
                lockPosition: 'right',
                pinned: 'right',
                sortable: false,
                headerClass: " !pl-2 !pr-1",
                filter: false,
                minWidth: 70,
                maxWidth: 70
            }] : permissionHistorycolumns;
        },
        contextMenuItems: ({ selectedRow }) => {
            return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                {selectedRow && (Object.hasOwn(selectedRow, "status") && selectedRow.status === leaveStatus[4].Key && ("permissionTypeID" in selectedRow) && selectedRow.permissionTypeID !== permissionTypes[2].value) && <MenuItem
                    className={classNames.contextMenuItem}
                    onClick={async () => {
                        await store.dispatch(permissionAction.setLoader(true));
                        await store.dispatch(permissionAction.setAddPermissionPopup({ show: true, selectedRow: selectedRow, type: "Edit" }))
                        store.dispatch(permissionAction.setLoader(false));
                    }}
                >
                    <span className='flex items-center'> <FiEdit size={18} />  <span className='mx-2'>Edit</span></span>
                </MenuItem>}
                {selectedRow && ((Object.hasOwn(selectedRow, "status") && selectedRow.status !== leaveStatus[4].Key) || (("permissionTypeID" in selectedRow) && selectedRow.permissionTypeID === permissionTypes[2].value)) && <MenuItem
                    className={classNames.contextMenuItem}
                    onClick={async () => {
                        await store.dispatch(permissionAction.setLoader(true));
                        await store.dispatch(permissionAction.setAddPermissionPopup({ show: true, selectedRow: selectedRow, type: "View" }))
                        store.dispatch(permissionAction.setLoader(false));
                    }}
                >
                    <span className='flex items-center'> <ImEye size={18} /> <span className='mx-2'>View</span></span>
                </MenuItem>}
                {selectedRow && Object.hasOwn(selectedRow, "status") && (selectedRow.status === leaveStatus[1].Key || selectedRow.status === leaveStatus[4].Key) && ("permissionTypeID" in selectedRow) && selectedRow.permissionTypeID !== permissionTypes[2].value && <MenuItem
                    className={classNames.contextMenuItem}
                    onClick={async () => {
                        await store.dispatch(permissionAction.setLoader(true));
                        await store.dispatch(permissionRequests.getPermissionDetailRequest({ permissionId: selectedRow.permissionID }, status.tobeCancelled))
                        store.dispatch(permissionAction.setLoader(false));
                    }}
                >
                    <span className='flex items-center'> <TiCancel size={18} /> <span className='mx-2'>Cancel</span></span>
                </MenuItem>}
            </ContextMenu>)
        }
    },
    ApproveRejectPermissionRequest: {
        columns: (isMobileCompatible) => {
            const approveRejectPermissionColumns = [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    checkboxSelection: !isMobileCompatible,
                    filter: false,
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7
                },
                {
                    headerName: "Employee Name",
                    field: "employeeName",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 142,
                    maxWidth: 250,
                    excelWidth: 35
                },
                {
                    headerName: "Permission Type",
                    field: "permissionType",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 145,
                    excelWidth: 20
                },
                {
                    headerName: "Date",
                    headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-center'><div>{displayName}</div><div className=' text-[10.5px]'>{store.getState().user.LocationID === setDefaultValue.location.value ? "(DD/MM/YYYY)" : "(MM/DD/YYYY)"}</div></div>,
                    field: "permissionDate",
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                    minWidth: 120,
                    maxWidth: 120,
                    excelWidth: 15
                },
                {
                    headerName: "Start Time",
                    headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-center'><div>{displayName}</div><div className=' text-[10.5px]'>(HH:MM:SS)</div></div>,
                    field: "fromTime",
                    cellRenderer: params => SetContextMenuTrigger({ params, isTimeView: true }),
                    minWidth: 110,
                    maxWidth: 110,
                    excelWidth: 15
                },
                {
                    headerName: "End Time",
                    headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-center'><div>{displayName}</div><div className=' text-[10.5px]'>(HH:MM:SS)</div></div>,
                    field: "toTime",
                    cellRenderer: params => SetContextMenuTrigger({ params, isTimeView: true }),
                    minWidth: 110,
                    maxWidth: 110,
                    excelWidth: 15
                },
                {
                    headerName: "Hrs Taken",
                    field: "noofHrs",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 103,
                    maxWidth: 103,
                    excelWidth: 15
                },
                {
                    headerName: "Remarks",
                    field: "remarks",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 300,
                    excelWidth: 100
                },
                {
                    headerName: "Permission Status",
                    field: 'approvalStatus',
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 160,
                    excelWidth: 20
                }
            ];
            return isMobileCompatible ? [...approveRejectPermissionColumns, {
                headerName: "Actions",
                field: "actions",
                cellRenderer: params => {
                    const selectedRow = params.data;

                    return <div className=" h-full w-full flex items-center justify-center ml-5 gap-2">
                        {selectedRow && Object.hasOwn(selectedRow, "status") && selectedRow.status === leaveStatus[4].Key &&
                            <span className='flex items-center text-headerColor cursor-pointer' onClick={async () => {
                                await store.dispatch(permissionAction.setLoader(true));
                                await store.dispatch(permissionRequests.getPermissionDetailRequest({ permissionId: selectedRow.permissionID }, status.tobeApproved))
                                store.dispatch(permissionAction.setLoader(false));
                            }}>
                                <TiTick size={18} /> / <IoClose size={18} style={{ strokeWidth: "18px" }} />
                            </span>
                        }
                        {selectedRow && Object.hasOwn(selectedRow, "status") && (selectedRow.status === leaveStatus[1].Key || selectedRow.status === leaveStatus[6].Key) &&
                            <span className='flex items-center text-headerColor cursor-pointer' onClick={async () => {
                                await store.dispatch(permissionAction.setLoader(true));
                                await store.dispatch(permissionRequests.getPermissionDetailRequest({ permissionId: selectedRow.permissionID }, status.cancel))
                                store.dispatch(permissionAction.setLoader(false));
                            }}>
                                <TiCancel size={18} />
                            </span>
                        }
                        <span className='flex items-center text-headerColor cursor-pointer' onClick={async () => {
                            store.dispatch(permissionAction.setPermissionHistoryPopup({ show: true, rowData: selectedRow }))
                        }}>
                            <HiOutlineClipboardList size={18} />
                        </span>
                    </div>
                },
                lockPosition: 'right',
                pinned: 'right',
                sortable: false,
                headerClass: " !pl-2 !pr-1",
                filter: false,
                minWidth: 90,
                maxWidth: 90
            }] : approveRejectPermissionColumns;
        },
        contextMenuItems: ({ selectedRow }) => {
            return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                {selectedRow && Object.hasOwn(selectedRow, "status") && selectedRow.status === leaveStatus[4].Key && <MenuItem
                    className={classNames.contextMenuItem}
                    onClick={async () => {
                        await store.dispatch(permissionAction.setLoader(true));
                        await store.dispatch(permissionRequests.getPermissionDetailRequest({ permissionId: selectedRow.permissionID }, status.tobeApproved))
                        store.dispatch(permissionAction.setLoader(false));
                    }}
                >
                    <span className='flex items-center gap-y-[2px]'>
                        <span><TiTick size={18.5} /></span>
                        <span className=' flex items-center gap-x-1'>Approve  <span className=' ml-[2px]'>/</span> <span className=' flex items-center gap-x-[2px]'><IoClose size={18} style={{ strokeWidth: "18px" }} /> Reject</span></span>
                    </span>
                </MenuItem>}
                {selectedRow && Object.hasOwn(selectedRow, "status") && (selectedRow.status === leaveStatus[1].Key || selectedRow.status === leaveStatus[6].Key) && <MenuItem
                    className={classNames.contextMenuItem}
                    onClick={async () => {
                        await store.dispatch(permissionAction.setLoader(true));
                        await store.dispatch(permissionRequests.getPermissionDetailRequest({ permissionId: selectedRow.permissionID }, status.cancel))
                        store.dispatch(permissionAction.setLoader(false));
                    }}
                >
                    <span className='flex items-center'> <TiCancel size={18} /> <span className='mx-2'>Cancel</span></span>
                </MenuItem>}
                <MenuItem
                    className={classNames.contextMenuItem}
                    onClick={async () => {
                        store.dispatch(permissionAction.setPermissionHistoryPopup({ show: true, rowData: selectedRow }))
                    }}
                >
                    <span className='flex items-center'><HiOutlineClipboardList size={18} style={{ strokeWidth: "2.5px" }} /> <span className='mx-2'>View Permission History</span></span>
                </MenuItem>
            </ContextMenu>)
        }
    },
    permissionHistory: {
        columns: () => [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                filter: false,
                minWidth: 85,
                maxWidth: 85,
                excelWidth: 7
            },
            {
                headerName: "Date",
                headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-center'><div>{displayName}</div><div className=' text-[10.5px]'>{store.getState().user.LocationID === setDefaultValue.location.value ? "(DD/MM/YYYY)" : "(MM/DD/YYYY)"}</div></div>,
                field: "permissionDate",
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                minWidth: 120,
                maxWidth: 120,
                excelWidth: 15
            },
            {
                headerName: "Start Time",
                headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-center'><div>{displayName}</div><div className=' text-[10.5px]'>(HH:MM:SS)</div></div>,
                field: "fromTime",
                cellRenderer: params => SetContextMenuTrigger({ params, isTimeView: true }),
                minWidth: 110,
                maxWidth: 110,
                excelWidth: 15
            },
            {
                headerName: "End Time",
                headerComponent: ({ displayName }) => <div className='text-center flex !flex-col ag-header ag-header-cell-label !border-0 items-center'><div>{displayName}</div><div className=' text-[10.5px]'>(HH:MM:SS)</div></div>,
                field: "toTime",
                cellRenderer: params => SetContextMenuTrigger({ params, isTimeView: true }),
                minWidth: 110,
                maxWidth: 110,
                excelWidth: 15
            },
            {
                headerName: "Permission Status",
                field: 'approvalStatus',
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 160,
                excelWidth: 20
            },
            {
                headerName: "Permission Type",
                field: 'permissionType',
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 160,
                excelWidth: 20
            },
            {
                headerName: "Reviewed on",
                field: "reviewedOn",
                headerComponent: agGridDateHeaderComponent,
                minWidth: 150,
                excelWidth: 16,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
            },
            {
                headerName: "Reviewed By",
                field: "reviewedBy",
                minWidth: 150,
                excelWidth: 25,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
        ]
    }
}

export const multiImageViewer = {
    columns: [
        {
            headerName: "S.No",
            field: "sno",
            comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
            cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
            lockPosition: 'left',
            filter: false,
            minWidth: 85,
            maxWidth: 85
        },
        {
            headerName: "Document Name",
            field: "name",
            cellRenderer: params => SetContextMenuTrigger({
                params, isSelectable: true, onClick: () => {
                    store.dispatch(userRequest.imageViewer({ show: true, data: params.data.binary, imageName: params.data.name }));
                }
            }),
            minWidth: 250,
        },
    ]
}

export const holiday = {
    holidayList: {
        columns: [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                filter: false,
                minWidth: 85,
                maxWidth: 85,
                excelWidth: 7
            },
            {
                headerName: "Holiday Name",
                field: "name",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 120,
                excelWidth: 30
            },
            {
                headerName: "Start Date",
                field: "startDate",
                headerComponent: agGridDateHeaderComponent,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                minWidth: 120,
                maxWidth: 200,
                excelWidth: 18
            },
            {
                headerName: "End Date",
                field: "endDate",
                headerComponent: agGridDateHeaderComponent,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                minWidth: 120,
                maxWidth: 200,
                excelWidth: 18
            },
            {
                headerName: "Number Of Days",
                field: "numberOfDays",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 120,
                excelWidth: 20
            },

        ],
        USColumns: [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                filter: false,
                minWidth: 85,
                maxWidth: 85,
                excelWidth: 7
            },
            {
                headerName: "Holiday Name",
                field: "name",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 120,
                excelWidth: 40
            },
            {
                headerName: "Holiday Date",
                field: "startDate",
                headerComponent: agGridDateHeaderComponent,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                minWidth: 120,
                excelWidth: 18
            },
        ]
    },
    floatingHolidayList: {
        columns: [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                filter: false,
                minWidth: 85,
                maxWidth: 90,
                excelWidth: 7
            },
            {
                headerName: "Employee Name",
                field: "employeeName",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 120,
                excelWidth: 30
            },
            {
                headerName: "Department Name",
                field: "departmentName",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 120,
                excelWidth: 30
            },
            {
                headerName: "Employee Code",
                field: "employeeCode",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 120,
                maxWidth: 180,
                excelWidth: 25
            },
            {
                headerName: "Holiday Name",
                field: "holidayName",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 120,
                excelWidth: 30
            },
            {
                headerName: "Start Date",
                field: "startDate",
                headerComponent: agGridDateHeaderComponent,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                minWidth: 110,
                maxWidth: 130,
                filter: false,
                excelWidth: 18
            },
            {
                headerName: "End Date",
                field: "endDate",
                headerComponent: agGridDateHeaderComponent,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                minWidth: 100,
                maxWidth: 130,
                filter: false,
                excelWidth: 18
            }
        ]
    },
    addFloatingHolidayList: {
        columns: (isMobileCompatible) => {
            const addFloatingHoliday = [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    filter: false,
                    checkboxSelection: !isMobileCompatible,
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7
                },
                {
                    headerName: "Employee Name",
                    field: "employeeName",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    filter: true,
                    excelWidth: 30
                },
            ];
            return isMobileCompatible ? [...addFloatingHoliday,
            {
                headerName: "Actions",
                field: "actions",
                cellRenderer: params => {
                    const selectedRow = params.data;

                    return <div className={` h-full w-full flex items-center justify-center ml-1`}>
                        <span className='flex items-center text-headerColor cursor-pointer' onClick={() => {
                            store.dispatch(holidayActions.setAddFloatingHolidayLoader(true));
                            store.dispatch(holidayActions.setAddFloatingHolidayPopup({ show: true, action: "Edit", selectedRecord: selectedRow }));
                            store.dispatch(holidayActions.setAddFloatingHolidayLoader(false));
                        }}>
                            <FiEdit size={18} />  <span className='mx-2'>Edit</span>
                        </span>
                    </div>
                },
                lockPosition: 'right',
                pinned: 'right',
                sortable: false,
                headerClass: " !pl-2 !pr-1",
                filter: false,
                minWidth: 70,
                maxWidth: 70
            }
            ] : addFloatingHoliday;
        },
        contextMenuItems: ({ selectedRow }) => {
            return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                <MenuItem
                    className={classNames.contextMenuItem}
                    onClick={() => {
                        store.dispatch(holidayActions.setAddFloatingHolidayLoader(true));
                        store.dispatch(holidayActions.setAddFloatingHolidayPopup({ show: true, action: "Edit", selectedRecord: selectedRow }));
                        store.dispatch(holidayActions.setAddFloatingHolidayLoader(false));
                    }}
                >
                    <span className='flex items-center'> <FiEdit size={18} />  <span className='mx-2'>Edit</span></span>
                </MenuItem>
            </ContextMenu>)
        },
        convertFormattedRecords: (data, isMobileCompatible) => {
            let customColumns = [...holiday.addFloatingHolidayList.columns(isMobileCompatible)];
            let customData = [];
            let tempColorCollections = [];
            for (const firstIndex in data) {
                const floatingHolidayList = data[firstIndex].floatingHolidays;
                let currentRecord = structuredClone(data[firstIndex]);
                for (const index in floatingHolidayList) {
                    const holidayList = floatingHolidayList[index];
                    for (const splitHolidayIndex in holidayList) {
                        const splitHolidayList = holidayList[splitHolidayIndex];
                        let sortIndex = 0;
                        let storeTempColor = tempColorCollections.length > 0 && tempColorCollections.find(val => val.holidayName === splitHolidayList.holidayName) ? tempColorCollections.find(val => val.holidayName === splitHolidayList.holidayName).color : false;
                        if (!storeTempColor) {
                            const color = floatingHolidayColors[(index < floatingHolidayColors.length) ? index : 1].color;
                            tempColorCollections = [...tempColorCollections, { holidayName: splitHolidayList.holidayName, color }];
                            storeTempColor = color;
                            sortIndex = tempColorCollections.length;
                        } else {
                            sortIndex = tempColorCollections.findIndex(val => val.holidayName === splitHolidayList.holidayName);
                        }
                        const checkedValue = holidayList.some(val => val.isUsed) ? (splitHolidayList.isUsed ? floatingHolidayTypes.checked : floatingHolidayTypes.unChecked) : floatingHolidayTypes.empty;
                        currentRecord = { ...currentRecord, [splitHolidayList.holidayName]: splitHolidayList.isUsed, [`${splitHolidayList.holidayName}Color`]: storeTempColor, [`${splitHolidayList.holidayName}CheckboxType`]: checkedValue, index };
                        currentRecord.floatingHolidays[index][splitHolidayIndex].sortIndex = Number(sortIndex);
                        const customClassName = (params) => (params.data[`${params.colDef.headerName}CheckboxType`] === floatingHolidayTypes.unChecked ? " absolute left-[1.2rem] " : "");
                        if (Number(firstIndex) === 0) {
                            customColumns = [
                                ...customColumns,
                                {
                                    headerName: splitHolidayList.holidayName,
                                    field: `${splitHolidayList.holidayName}CheckboxType`,
                                    cellRenderer: params => <ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}><div className={` h-full w-full flex items-center ${customClassName(params)}`}>{onFloatingHolidayReturnCheckBoxIcon(params)}</div></div></ContextMenuTrigger>,
                                    minWidth: 120,
                                    filter: false,
                                    filterParams: filterParams.keyFormat([{ label: 'Yes', value: floatingHolidayTypes.checked }, { label: 'No', value: floatingHolidayTypes.unChecked }]),
                                    excelWidth: 30
                                }
                            ]
                        }
                    }
                }
                customData = [...customData, currentRecord];
            }
            return { columns: customColumns, data: customData };
        }
    },
    AddHolidayName: {
        commonActions: {
            headerName: "Actions",
            field: "actions",
            cellRenderer: params => {
                const selectedRow = params.data;
                return selectedRow?.recordStatus === HolidayNameStatus[1].label ? <div className={` h-full w-full flex items-center justify-center ml-1 gap-2`}>
                    <span className='flex items-center text-headerColor cursor-pointer' onClick={() => store.dispatch(holidayActions.setHolidayNamePopup({ show: true, action: "Edit", selectedRecord: selectedRow }))}>
                        <FiEdit size={18} />
                    </span>
                    <span className='flex items-center text-headerColor cursor-pointer' onClick={async () => {
                        await store.dispatch(holidayActions.setHolidayNamePopup({ action: "Delete", selectedRecord: selectedRow }));
                        await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to delete "${selectedRow.holidayName}" from the list of holiday names?`, isOptional: true }));
                    }}>
                        <ImBin size={16.5} />
                    </span>
                </div> : <></>
            },
            lockPosition: 'right',
            pinned: 'right',
            sortable: false,
            headerClass: " !pl-2 !pr-1",
            filter: false,
            minWidth: 70,
            maxWidth: 70
        },
        columns: (isMobileCompatible) => {
            const addHolidayColumns = [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    filter: false,
                    checkboxSelection: params => !isMobileCompatible && (params.data?.recordStatus === HolidayNameStatus[1].label),
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7
                },
                {
                    headerName: "Holiday Name",
                    field: "holidayName",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    excelWidth: 30,
                    filter: true,
                },
                {
                    headerName: "Location",
                    field: "locationName",
                    minWidth: 80, excelWidth: 10,
                    maxWidth: 100,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
                {
                    headerName: "Status",
                    field: "recordStatus",
                    minWidth: 80, excelWidth: 15,
                    maxWidth: 200,
                    cellRenderer: params => SetContextMenuTrigger({ params })
                },
                {
                    headerName: "Created By",
                    field: "addedBy",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    excelWidth: 30
                },
                {
                    headerName: "Created Date",
                    field: "addedOn",
                    headerComponent: agGridDateHeaderComponent,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                    minWidth: 100,
                    maxWidth: 130,
                    filter: false,
                    excelWidth: 30
                },
                {
                    headerName: "Modified By",
                    field: "modifiedBy",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    excelWidth: 30
                },
                {
                    headerName: "Modified Date",
                    field: "modifiedOn",
                    headerComponent: agGridDateHeaderComponent,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                    minWidth: 100,
                    maxWidth: 130,
                    filter: false,
                    excelWidth: 30
                }
            ];
            return isMobileCompatible ? [...addHolidayColumns, { ...holiday.AddHolidayName.commonActions }] : addHolidayColumns;
        },
        USColumns: (isMobileCompatible) => {
            const addHolidayColumns = [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    filter: false,
                    checkboxSelection: params => !isMobileCompatible && (params.data?.recordStatus === HolidayNameStatus[1].label),
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7
                },
                {
                    headerName: "Holiday Name",
                    field: "holidayName",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    excelWidth: 40,
                    filter: true,
                },
                {
                    headerName: "Location",
                    field: "locationName",
                    minWidth: 80, excelWidth: 15,
                    maxWidth: 100,
                    cellRenderer: params => SetContextMenuTrigger({ params })
                },
                {
                    headerName: "Status",
                    field: "recordStatus",
                    minWidth: 80, excelWidth: 15,
                    maxWidth: 200,
                    cellRenderer: params => SetContextMenuTrigger({ params })
                },
                {
                    headerName: "Active From",
                    field: "addedOn",
                    headerComponent: agGridDateHeaderComponent,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                    minWidth: 100,
                    maxWidth: 170,
                    filter: false,
                    excelWidth: 20
                },
                {
                    headerName: "InActive From",
                    field: "modifiedOn",
                    headerComponent: agGridDateHeaderComponent,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                    minWidth: 100,
                    maxWidth: 170,
                    filter: false,
                    excelWidth: 20
                }
            ];
            return isMobileCompatible ? [...addHolidayColumns, { ...holiday.AddHolidayName.commonActions }] : addHolidayColumns
        },
        contextMenuItems: ({ selectedRow }) => {
            return (selectedRow && Object.hasOwn(selectedRow, "recordStatus") && selectedRow.recordStatus === HolidayNameStatus[1].label && <ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                <MenuItem
                    className={classNames.contextMenuItem}
                    onClick={() => {
                        store.dispatch(holidayActions.setHolidayNamePopup({ show: true, action: "Edit", selectedRecord: selectedRow }));
                    }}
                >
                    <span className='flex items-center'> <FiEdit size={18} />  <span className='mx-2'>Edit</span></span>
                </MenuItem>
                <MenuItem
                    className={classNames.contextMenuItem}
                    onClick={async () => {
                        await store.dispatch(holidayActions.setHolidayNamePopup({ action: "Delete", selectedRecord: selectedRow }));
                        await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to delete "${selectedRow.holidayName}" from the list of holiday names?`, isOptional: true }));
                    }}
                >
                    <span className='flex items-center'> <ImBin size={16.5} /> <span className='mx-2'>Delete</span></span>
                </MenuItem>
            </ContextMenu>)
        },
    },
    AddHolidayList: {
        commonActions: {
            headerName: "Actions",
            field: "actions",
            cellRenderer: params => {
                const selectedRow = params.data;
                return <div className={` h-full w-full flex items-center justify-center gap-2 ml-1`}>
                    <span className='flex items-center text-headerColor cursor-pointer' onClick={() => store.dispatch(holidayActions.setAddHolidayPopup({ show: true, action: "Edit", selectedRecord: selectedRow }))}>
                        <FiEdit size={18} />
                    </span>
                    <span className=" flex items-center text-headerColor cursor-pointer" onClick={async () => {
                        await store.dispatch(holidayActions.setAddHolidayPopup({ action: "Delete", selectedRecord: { ...selectedRow, isExists: false } }));
                        await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to delete "${selectedRow.name}" from the holiday list?`, isOptional: true }));
                    }}>
                        <ImBin size={16.5} />
                    </span>
                </div>
            },
            lockPosition: 'right',
            pinned: 'right',
            sortable: false,
            headerClass: " !pl-2 !pr-1",
            filter: false,
            minWidth: 80,
            maxWidth: 80
        },
        columns: (isMobileCompatible) => {
            const addHolidayCols = [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    filter: false,
                    checkboxSelection: !isMobileCompatible,
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7
                },
                {
                    headerName: "Holiday Name",
                    field: "name",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    filter: true,
                    excelWidth: 30
                },
                {
                    headerName: "Start Date",
                    field: "startDate",
                    headerComponent: agGridDateHeaderComponent,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                    minWidth: 110,
                    maxWidth: 130,
                    filter: false,
                    excelWidth: 18
                },
                {
                    headerName: "End Date",
                    field: "endDate",
                    headerComponent: agGridDateHeaderComponent,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                    minWidth: 100,
                    maxWidth: 130,
                    filter: false,
                    excelWidth: 18
                },
                {
                    headerName: "Number Of Days",
                    field: "numberOfDays",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    maxWidth: 150,
                    filter: false,
                    excelWidth: 20
                },
                {
                    headerName: "Location",
                    field: "locationName",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 100,
                    maxWidth: 100,
                    excelWidth: 30
                },
                {
                    headerName: "Created By",
                    field: "createdBy",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 100,
                    filter: true,
                    excelWidth: 30
                },
                {
                    headerName: "Created Date",
                    field: "addedOn",
                    headerComponent: agGridDateHeaderComponent,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                    minWidth: 100,
                    maxWidth: 130,
                    filter: false,
                    excelWidth: 30
                },
                {
                    headerName: "Modified By",
                    field: "modifiedBy",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 100,
                    filter: true,
                    excelWidth: 30
                },
                {
                    headerName: "Modified Date",
                    field: "modifiedDate",
                    headerComponent: agGridDateHeaderComponent,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                    minWidth: 100,
                    maxWidth: 130,
                    filter: false,
                    excelWidth: 30
                }
            ];
            return isMobileCompatible ? [...addHolidayCols, { ...holiday.AddHolidayList.commonActions }] : addHolidayCols;
        },
        USColumns: (isMobileCompatible) => {
            const addHolidayCols = [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    headerClass: " !pl-1 !pr-1 ",
                    filter: false,
                    checkboxSelection: false,
                    headerCheckboxSelection: false,
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7
                },
                {
                    headerName: "Holiday Name",
                    field: "name",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    filter: true,
                    excelWidth: 40
                },
                {
                    headerName: "Holiday Date",
                    field: "startDate",
                    headerComponent: agGridDateHeaderComponent,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                    minWidth: 200,
                    maxWidth: 200,
                    filter: false,
                    excelWidth: 30
                },
                {
                    headerName: "Created By",
                    field: "createdBy",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 100,
                    filter: true,
                    excelWidth: 30
                },
                {
                    headerName: "Created Date",
                    field: "addedOn",
                    headerComponent: agGridDateHeaderComponent,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                    minWidth: 100,
                    maxWidth: 130,
                    filter: false,
                    excelWidth: 30
                }
            ];
            return isMobileCompatible ? [...addHolidayCols, { ...holiday.AddHolidayList.commonActions }] : addHolidayCols;
        },
        USPopupViewColumns: () => [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                filter: false,
                checkboxSelection: true,
                headerCheckboxSelection: false,
                minWidth: 100,
                maxWidth: 100,
                excelWidth: 7
            },
            {
                headerName: "Holiday Name",
                field: "name",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 120,
                filter: false,
                excelWidth: 40
            },
            {
                headerName: "Government Holiday",
                field: "governmentHolidayDate",
                headerComponent: agGridDateHeaderComponent,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                minWidth: 200,
                maxWidth: 200,
                filter: false,
                excelWidth: 30
            }
        ],
        contextMenuItems: ({ selectedRow }) => {
            return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                <MenuItem
                    className={classNames.contextMenuItem}
                    onClick={() => {
                        store.dispatch(holidayActions.setAddHolidayPopup({ show: true, action: "Edit", selectedRecord: selectedRow }));
                    }}
                >
                    <span className='flex items-center'> <FiEdit size={18} />  <span className='mx-2'>Edit</span></span>
                </MenuItem>
                <MenuItem
                    className={classNames.contextMenuItem}
                    onClick={async () => {
                        await store.dispatch(holidayActions.setAddHolidayPopup({ action: "Delete", selectedRecord: { ...selectedRow, isExists: false } }));
                        await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to delete "${selectedRow.name}" from the holiday list?`, isOptional: true }));
                    }}
                >
                    <span className='flex items-center'> <ImBin size={16.5} /> <span className='mx-2'>Delete</span></span>
                </MenuItem>
            </ContextMenu>)
        }

    }
}

export const indiaAttendanceReport = {
    employeePayrollDetails: {
        newJoinees: {
            columns: () => [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    filter: false,
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7
                },
                {
                    headerName: "Employee Code",
                    field: "employeeCode",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    excelWidth: 30
                },
                {
                    headerName: "Employee Name",
                    field: "employeeName",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    excelWidth: 35
                },
                {
                    headerName: "Date of Joining",
                    field: "dateOfJoining",
                    headerComponent: agGridDateHeaderComponent,
                    minWidth: 150,
                    excelWidth: 16,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true })
                }
            ]
        },
        confirmedEmployees: {
            columns: () => [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    filter: false,
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7
                },
                {
                    headerName: "Employee Code",
                    field: "employeeCode",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    excelWidth: 30
                },
                {
                    headerName: "Employee Name",
                    field: "employeeName",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    excelWidth: 35
                },
                {
                    headerName: "Date of Joining",
                    field: "dateOfJoining",
                    headerComponent: agGridDateHeaderComponent,
                    minWidth: 150,
                    excelWidth: 16,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true })
                },
                {
                    headerName: "Confirmation Date",
                    field: "completionDate",
                    headerComponent: agGridDateHeaderComponent,
                    minWidth: 150,
                    excelWidth: 20,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true })
                }
            ]
        },
        probationEmployee: {
            columns: () => [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    filter: false,
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7
                },
                {
                    headerName: "Employee Code",
                    field: "employeeCode",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    excelWidth: 30
                },
                {
                    headerName: "Employee Name",
                    field: "employeeName",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    excelWidth: 35
                },
                {
                    headerName: "Date of Joining",
                    field: "dateOfJoining",
                    headerComponent: agGridDateHeaderComponent,
                    minWidth: 150,
                    excelWidth: 16,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true })
                },
                {
                    headerName: "probation Completion Date",
                    field: "completionDate",
                    headerComponent: agGridDateHeaderComponent,
                    minWidth: 150,
                    excelWidth: 30,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true })
                }
            ]
        },
        completed2Years: {
            columns: () => [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    filter: false,
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7
                },
                {
                    headerName: "Employee Code",
                    field: "employeeCode",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    excelWidth: 30
                },
                {
                    headerName: "Employee Name",
                    field: "employeeName",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    excelWidth: 35
                },
                {
                    headerName: "Date of Joining",
                    field: "dateOfJoining",
                    headerComponent: agGridDateHeaderComponent,
                    minWidth: 150,
                    excelWidth: 16,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true })
                },
                {
                    headerName: "2 Years Completion Date",
                    field: "completionDate",
                    headerComponent: agGridDateHeaderComponent,
                    minWidth: 150,
                    excelWidth: 30,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true })
                }
            ]
        },
        workingOnSaturday: {
            columns: () => [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    filter: false,
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7
                },
                {
                    headerName: "Employee Code",
                    field: "employeeCode",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    excelWidth: 30
                },
                {
                    headerName: "Employee Name",
                    field: "employeeName",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    excelWidth: 35
                },
                {
                    headerName: "Work Date",
                    field: "completionDate",
                    headerComponent: agGridDateHeaderComponent,
                    minWidth: 150,
                    excelWidth: 20,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true })
                },
                {
                    headerName: "Full/Half Day",
                    field: "day",
                    headerComponent: agGridDateHeaderComponent,
                    minWidth: 150,
                    excelWidth: 45,
                    cellRenderer: params => SetContextMenuTrigger({ params })
                }
            ]
        },
        resignedEmployee: {
            columns: () => [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    filter: false,
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7
                },
                {
                    headerName: "Employee Code",
                    field: "employeeCode",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    excelWidth: 30
                },
                {
                    headerName: "Employee Name",
                    field: "employeeName",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    excelWidth: 35
                },
                {
                    headerName: "Date of Joining",
                    field: "dateOfJoining",
                    headerComponent: agGridDateHeaderComponent,
                    minWidth: 150,
                    excelWidth: 16,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true })
                },
                {
                    headerName: "Relieving Date",
                    field: "completionDate",
                    headerComponent: agGridDateHeaderComponent,
                    minWidth: 150,
                    excelWidth: 20,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true })
                }
            ]
        }

    },
    uploadAuditorDocuments: {
        columns: (isMobileCompatible) => {
            const uploadAuditorColumns = [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    checkboxSelection: params => (!isMobileCompatible && params.data?.isValid) ? (params.data?.isValid !== 'true') : false,
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7
                },
                {
                    headerName: "Employee Name",
                    field: "employeeName",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 150,
                    excelWidth: 40
                },
                {
                    headerName: "Employee Code",
                    field: "employeeCode",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 130,
                    maxWidth: 180,
                    excelWidth: 25
                },
                {
                    headerName: "Payroll Month",
                    field: "payRollMonth",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 130,
                    maxWidth: 190,
                    excelWidth: 25
                },
                {
                    headerName: "Auditor Document Leave Balance",
                    field: "auditorDocLeaveBalance",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 320,
                    excelWidth: 40
                },
                {
                    headerName: "System Leave Balance",
                    field: "ledgerLeaveBalance",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 300,
                    excelWidth: 30
                }
            ];
            return isMobileCompatible ? [...uploadAuditorColumns, {
                headerName: "Actions",
                field: "actions",
                cellRenderer: params => {
                    const isVisible = params.data?.isValid && (params.data?.isValid !== 'true');
                    const onhandleEdit = () => {
                        const selectedRow = params.data;
                        store.dispatch(attendancePayrollActions.setValidateLeaveBalance({ show: true, popupData: selectedRow }));
                    }
                    return <div className=" h-full w-full flex items-center justify-center ml-5 ">
                        {
                            isVisible && <span className='flex items-center text-headerColor cursor-pointer' onClick={onhandleEdit}>
                                <FiEdit size={18} />
                                <span className='mx-2'>Edit</span>
                            </span>
                        }
                    </div>
                },
                lockPosition: 'right',
                pinned: 'right',
                sortable: false,
                headerClass: " !pl-2 !pr-1",
                filter: false,
                minWidth: 50,
                maxWidth: 70
            }] : uploadAuditorColumns;
        },
        contextMenuItems: ({ history, selectedRow }) => {
            return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                {
                    selectedRow.isValid == 'false' &&
                    <div>
                        <MenuItem
                            data={{ menu: "Approve", history: history }}
                            className={classNames.contextMenuItem}
                            onClick={async () => {
                                store.dispatch(attendancePayrollActions.setValidateLeaveBalance({ show: true, popupData: selectedRow }))
                            }}
                        >
                            <span className='flex items-center'> <FiEdit size={18} /> <span className='mx-2'>Edit</span></span>
                        </MenuItem>
                    </div>
                }
            </ContextMenu>)
        },
    },
    employeePersonalDetails: {
        columns: () => [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                filter: false,
                minWidth: 85,
                maxWidth: 85,
                excelWidth: 7
            },
            {
                headerName: "Employee Code",
                field: "employeeCode",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 120,
                excelWidth: 30
            },
            {
                headerName: "Employee Name",
                field: "employeName",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 120,
                excelWidth: 30
            },
            {
                headerName: "Date of Birth",
                field: "DOB",
                headerComponent: agGridDateHeaderComponent,
                minWidth: 150,
                excelWidth: 16,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true })
            },
        ]
    },
    uploadAuditPopup: {
        columns: [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                filter: false,
                checkboxSelection: false,
                minWidth: 85,
                maxWidth: 85,
            },
        ],
        convertFormattedRecords: (jsonData) => {
            let customDatas = [];
            let columns = [...indiaAttendanceReport.uploadAuditPopup.columns];
            if (jsonData.length > 0) {
                const headers = jsonData[0];
                for (const firstIndex in jsonData) {
                    if (firstIndex > 0 && jsonData[firstIndex].length > 0) {
                        let customHeaderObj = {};
                        for (const headerIndex in headers) {
                            if (jsonData[firstIndex].length > headerIndex) {
                                customHeaderObj = { ...customHeaderObj, [headers[headerIndex]]: jsonData[firstIndex][headerIndex] }
                            }
                        }
                        customDatas = [...customDatas, { ...customHeaderObj }];
                    } else if (firstIndex <= 0 && jsonData[firstIndex].length > 0) {
                        for (const headerIndex in headers) {
                            if (headers[headerIndex] !== indiaAttendanceReport.uploadAuditPopup.columns[0].headerName) {
                                columns = [...columns, {
                                    headerName: headers[headerIndex],
                                    field: headers[headerIndex],
                                    cellRenderer: params => SetContextMenuTrigger({ params }),
                                    minWidth: Number(headerIndex) === 1 ? 250 : 120,
                                    width: Number(headerIndex) === 1 ? 400 : 120,
                                }]
                            }

                        }
                    }
                }
            }
            return { columns, data: customDatas }
        },
        employeePersonalDetails: {
            columns: () => [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    filter: false,
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7
                },
                {
                    headerName: "Employee Code",
                    field: "employeeCode",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    excelWidth: 30
                },
                {
                    headerName: "Employee Name",
                    field: "employeName",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    excelWidth: 30
                },
                {
                    headerName: "Date of Birth",
                    field: "DOB",
                    headerComponent: agGridDateHeaderComponent,
                    minWidth: 150,
                    excelWidth: 16,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true })
                },
            ]
        },
    }
}

export const Designation = {
    designationList: {
        columns: (isMobileCompatible) => {
            const designationColumns = [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    filter: false,
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7,
                    checkboxSelection: params => (params.data?.recordStatus && params.data.recordStatus === HolidayNameStatus[1].label),
                },
                {
                    headerName: "Designation Name",
                    field: "designationName",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 320,
                    filter: true,
                    excelWidth: 40
                },
                {
                    headerName: "Description",
                    field: "description",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 320,
                    filter: false,
                    excelWidth: 60
                },
                {
                    headerName: "Location",
                    field: "locationName",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    maxWidth: 210,
                    filter: false,
                    excelWidth: 12
                },
                {
                    headerName: "Status",
                    field: "recordStatus",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    maxWidth: 210,
                    filter: false,
                    excelWidth: 12
                },
                {
                    headerName: "Document",
                    field: "designationId",
                    minWidth: 120,
                    maxWidth: 200,
                    cellRenderer: params => SetContextMenuTrigger({
                        params, isDocumentView: true, onClick: async () => {
                            await store.dispatch(designationActions.setLoader(true));
                            await store.dispatch(employeeRequests.viewMultipleDocuments("employeeDetails/designationDocument", params.value, "", "Designation"));
                            store.dispatch(designationActions.setLoader(false));
                        }
                    })
                }
            ];

            return isMobileCompatible ? [...designationColumns, {
                headerName: "Actions",
                field: "actions",
                cellRenderer: params => {
                    const selectedRow = params.data;

                    return <div className=" h-full w-full flex items-center justify-center ml-5 ">
                        {
                            selectedRow?.recordStatus && selectedRow?.recordStatus === HolidayNameStatus[1].label &&
                            <span className='flex items-center text-headerColor cursor-pointer gap-2' >
                                <span onClick={async () => {
                                    await store.dispatch(designationActions.setLoader(true));
                                    await store.dispatch(designationRequest.getDesignationDetailsRequest(selectedRow.designationId));
                                    store.dispatch(designationActions.setLoader(false));
                                }}> <FiEdit size={18} /></span>
                                <span onClick={async () => {
                                    await store.dispatch(designationActions.setDesignationPopup({ selectedRow: selectedRow }));
                                    await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to remove ' ${selectedRow.designationName} ' designation from the list ?`, isOptional: true }));
                                }}> <IoClose size={16.5} /></span>
                            </span>
                        }
                    </div>
                },
                lockPosition: 'right',
                pinned: 'right',
                sortable: false,
                headerClass: " !pl-2 !pr-1",
                filter: false,
                minWidth: 70,
                maxWidth: 70
            }] : designationColumns;
        },
        contextMenuItems: ({ history, selectedRow }) => {
            return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                {
                    selectedRow?.recordStatus && selectedRow?.recordStatus === HolidayNameStatus[1].label && <div>
                        <MenuItem
                            data={{ menu: "Approve", history: history }}
                            className={classNames.contextMenuItem}
                            onClick={async () => {
                                await store.dispatch(designationActions.setLoader(true));
                                await store.dispatch(designationRequest.getDesignationDetailsRequest(selectedRow.designationId));
                                store.dispatch(designationActions.setLoader(false));
                            }}
                        >
                            <span className='flex items-center'> <FiEdit size={18} /> <span className='mx-2'>Edit</span></span>
                        </MenuItem>
                        <MenuItem
                            className={classNames.contextMenuItem}
                            onClick={async () => {
                                await store.dispatch(designationActions.setDesignationPopup({ selectedRow: selectedRow }));
                                await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to remove ' ${selectedRow.designationName} ' designation from the list ?`, isOptional: true }));
                            }}
                        >
                            <span className='flex items-center'> <IoClose size={18} style={{ strokeWidth: "18px" }} /> <span className='mx-2'>Remove</span></span>
                        </MenuItem>
                    </div>
                }
            </ContextMenu>
            )
        }
    }
}
const handleClickDept = async (event, data, selectedRow) => {
    switch (data.menu) {
        case 'EditDepartment':
            store.dispatch(departmentActions.setLoader(true));
            store.dispatch(departmentActions.setDepartmentNamePopup({ show: true, action: "Edit", selectedRow: selectedRow }));
            store.dispatch(departmentActions.setLoader(false));
            break;
        case 'ViewDepartment':
            store.dispatch(departmentActions.setLoader(true));
            store.dispatch(departmentActions.setDepartmentNamePopup({ show: true, action: "View", selectedRow: selectedRow }));
            store.dispatch(departmentActions.setLoader(false));
            break;
        default:
            console.error("Please ReCheck the Menu list")
    }
}

export const DepartmentColumn = {
    department: {
        column: (isMobileCompatible) => {
            const departmentColumn = [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    filter: false,
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7,
                    checkboxSelection: params => ((params.data?.recordStatus && params.data.recordStatus === HolidayNameStatus[1].label) && !isMobileCompatible),
                },
                {
                    headerName: "Department Name",
                    field: "departmentName",
                    lockPosition: 'center',
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 250,
                    filter: true,
                    excelWidth: 35,
                },
                {
                    headerName: "Status",
                    field: "recordStatus",
                    excelWidth: 16,
                    filter: false,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 90,
                    maxWidth: 90
                },
                {
                    headerName: "Description",
                    field: "description",
                    excelWidth: 70,
                    filter: false,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 300,
                    tooltipField: "description"
                },
            ];
            return isMobileCompatible ? [...departmentColumn, {
                headerName: "Actions",
                field: "actions",
                cellRenderer: params => {
                    const selectedRow = params.data;

                    return <div className=" h-full w-full flex items-center justify-center ml-5 ">
                        {
                            selectedRow?.recordStatus && selectedRow?.recordStatus === HolidayNameStatus[1].label &&
                            <span className='flex items-center text-headerColor cursor-pointer gap-2' >
                                <span onClick={async () => {
                                    await store.dispatch(departmentActions.setLoader(true));
                                    await store.dispatch(departmentActions.setDepartmentNamePopup({ show: true, action: "Edit", selectedRow: selectedRow }));
                                    store.dispatch(departmentActions.setLoader(false));
                                }}> <FiEdit size={18} /></span>
                                <span onClick={async () => {
                                    await store.dispatch(departmentActions.setDepartmentNamePopup({ selectedRow: selectedRow }));
                                    await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to remove ' ${selectedRow.departmentName} ' department from the list ?`, isOptional: true }));
                                }}> <IoClose size={16.5} /></span>
                            </span>
                        }
                    </div>
                },
                lockPosition: 'right',
                pinned: 'right',
                sortable: false,
                headerClass: " !pl-2 !pr-1",
                filter: false,
                minWidth: 70,
                maxWidth: 70
            }] : departmentColumn;
        },
        contextMenuItems: ({ history, selectedRow }) => {
            return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                {
                    selectedRow?.recordStatus && selectedRow?.recordStatus === HolidayNameStatus[1].label && <div>
                        <MenuItem
                            data={{ menu: "EditDepartment", history: history }}
                            className={classNames.contextMenuItem}
                            onClick={(e, data) => handleClickDept(e, data, selectedRow)}
                        >
                            <span className='flex items-center'> <FiEdit size={18} /> <span className='mx-2'>Edit</span></span>
                        </MenuItem>
                        {/* <MenuItem
                            data={{ menu: "ViewDepartment", history: history }}
                            className={classNames.contextMenuItem}
                            onClick={(e, data) => handleClickDept(e, data, selectedRow)}
                        >
                            <span className='flex items-center'> <ImEye size={18} /> <span className='mx-2'>View</span></span>
                        </MenuItem> */}
                        <MenuItem
                            className={classNames.contextMenuItem}
                            onClick={async () => {
                                await store.dispatch(departmentActions.setDepartmentNamePopup({ selectedRow: selectedRow }));
                                await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to remove ' ${selectedRow.departmentName} ' department from the list ?`, isOptional: true }));
                            }}
                        >
                            <span className='flex items-center'> <IoClose size={16.5} /> <span className='mx-2'>Remove</span></span>
                        </MenuItem>
                    </div>
                }
            </ContextMenu>)
        },
    },
}

export const ComplianceDocumentColumn = {
    complianceAgreement: {
        column: (isMobileCompatible) => {
            const createAndEditColumn = [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    filter: false,
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7,
                    checkboxSelection: params => (params.data?.recordStatus && params.data.recordStatus === HolidayNameStatus[1].label) && !isMobileCompatible,
                },
                {
                    headerName: "Document Title",
                    field: "documentTitle",
                    lockPosition: 'center',
                    cellRenderer: params => SetContextMenuTrigger({
                        params, isSelectable: true, onClick: async () => {
                            await store.dispatch(ComplianceAgreementActions.setLoader(true));
                            await store.dispatch(documentPolicyRequest.complianceAgreement.getViewDocument(params.data.documentId));
                            store.dispatch(ComplianceAgreementActions.setLoader(false));
                        }
                    }),
                    minWidth: 300,
                    excelWidth: 30,
                },
                {
                    headerName: "Document Category",
                    field: "documentCategoryName",
                    excelWidth: 20,
                    minWidth: 150,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
                {
                    headerName: "Location",
                    field: "location",
                    excelWidth: 20,
                    minWidth: 95,
                    maxWidth: 95,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
                {
                    headerName: "Document Number",
                    minWidth: 180,
                    field: "documentNumber",
                    excelWidth: 16,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
                {
                    headerName: "Version Number",
                    minWidth: 145,
                    field: "version",
                    excelWidth: 16,
                    maxWidth: 145,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
                {
                    headerName: "Author",
                    field: "author",
                    minWidth: 150,
                    excelWidth: 16,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
                {
                    headerName: "Created On",
                    field: "createdOn",
                    headerComponent: agGridDateHeaderComponent,
                    excelWidth: 16,
                    minWidth: 128,
                    maxWidth: 128,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                },
                {
                    headerName: "Created By",
                    field: "createdBy",
                    minWidth: 150,
                    excelWidth: 16,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
                {
                    headerName: "Status",
                    field: "recordStatus",
                    excelWidth: 16,
                    minWidth: 80,
                    maxWidth: 80,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                },
            ];
            return isMobileCompatible ? [...createAndEditColumn, {
                headerName: "Actions",
                field: "actions",
                cellRenderer: params => {
                    const selectedRow = params.data;
                    return <div className=" h-full w-full flex items-center justify-center ml-5 ">
                        {
                            selectedRow?.recordStatus && selectedRow?.recordStatus === HolidayNameStatus[1].label &&
                            <span className='flex items-center text-headerColor cursor-pointer gap-2' >
                                <span onClick={async () => {
                                    await store.dispatch(ComplianceAgreementActions.setLoader(true));
                                    await store.dispatch(documentPolicyRequest.complianceAgreement.editGetDocumentData(selectedRow.documentId));
                                    store.dispatch(ComplianceAgreementActions.setLoader(false));
                                }}> <FiEdit size={18} /></span>
                                <span onClick={async () => {
                                    await store.dispatch(ComplianceAgreementActions.setLoader(true));
                                    await store.dispatch(documentPolicyRequest.complianceAgreement.getViewDocument(selectedRow.documentId));
                                    store.dispatch(ComplianceAgreementActions.setLoader(false));
                                }}> <FaRegFilePdf size={16.5} /></span>
                                <span onClick={() => store.dispatch(ComplianceAgreementActions.setAgreementDocmentPopup({ show: true, selectedRow: selectedRow, action: 'add' }))}> <LiaUserCheckSolid size={16.5} /></span>
                                <span onClick={async () => {
                                    await store.dispatch(ComplianceAgreementActions.setDocumentPopup({ selectedRow: selectedRow, }));
                                    await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to delete "${selectedRow.documentTitle}" Document?`, isOptional: true }));
                                }}> <IoClose size={16.5} /></span>
                            </span>
                        }
                    </div>
                },
                lockPosition: 'right',
                pinned: 'right',
                sortable: false,
                headerClass: " !pl-2 !pr-1",
                filter: false,
                minWidth: 140,
                maxWidth: 140
            }] : createAndEditColumn;
        },
        contextMenuItems: ({ history, selectedRow }) => {
            return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                {
                    selectedRow?.recordStatus && selectedRow?.recordStatus === HolidayNameStatus[1].label && <div>

                        <MenuItem
                            data={{ menu: "EditDocument", history: history }}
                            className={classNames.contextMenuItem}
                            onClick={async () => {
                                await store.dispatch(ComplianceAgreementActions.setLoader(true));
                                await store.dispatch(documentPolicyRequest.complianceAgreement.editGetDocumentData(selectedRow.documentId));
                                store.dispatch(ComplianceAgreementActions.setLoader(false));
                            }}
                        >
                            <span className='flex items-center'> <FiEdit size={18} /> <span className='mx-2'>Edit Document</span></span>
                        </MenuItem>
                        <MenuItem
                            data={{ menu: "ViewDocument", history: history }}
                            className={classNames.contextMenuItem}
                            onClick={async () => {
                                await store.dispatch(ComplianceAgreementActions.setLoader(true));
                                await store.dispatch(documentPolicyRequest.complianceAgreement.getViewDocument(selectedRow.documentId));
                                store.dispatch(ComplianceAgreementActions.setLoader(false));
                            }}
                        >
                            <span className='flex items-center'> <FaRegFilePdf size={18} /> <span className='mx-2'>View Document</span></span>
                        </MenuItem>
                        <MenuItem
                            data={{ menu: "Assignment", history: history }}
                            className={classNames.contextMenuItem}
                            onClick={() => store.dispatch(ComplianceAgreementActions.setAgreementDocmentPopup({ show: true, selectedRow: selectedRow, action: 'add' }))}
                        >
                            <span className='flex items-center'> <LiaUserCheckSolid size={18} /> <span className='mx-2'>Assignment</span></span>
                        </MenuItem>
                        {/* <MenuItem
                            data={{ menu: "Notify", history: history }}
                            className={classNames.contextMenuItem}
                            onClick={async () => {
                                await store.dispatch(ComplianceAgreementActions.setDocumentPopup({ selectedRow: selectedRow, }));
                                await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Notify ?`, isOptional: true }));
                            }}
                        >
                            <span className='flex items-center'>  <MdOutlineNotificationsActive size={18} /> <span className='mx-2'>Notify</span></span>
                        </MenuItem> */}
                        <MenuItem
                            data={{ menu: "DeleteDocument", history: history }}
                            className={classNames.contextMenuItem}
                            onClick={async () => {
                                await store.dispatch(ComplianceAgreementActions.setDocumentPopup({ selectedRow: selectedRow, }));
                                await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to remove "${selectedRow.documentTitle}" Document?`, isOptional: true }));
                            }}
                        >
                            <span className='flex items-center'> <IoClose size={16.5} /> <span className='mx-2'>Remove Document</span></span>
                        </MenuItem>

                    </div>
                }

            </ContextMenu>)
        },
    },
    assignedDocumentHistory: {
        columns: (isMobileCompatible) => {
            const assignedCols = [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    filter: false,
                    minWidth: 85,
                    maxWidth: 85,
                    checkboxSelection: !isMobileCompatible,
                },
                {
                    headerName: "Document Title",
                    field: "documentTitle",
                    tooltipField: "documentTitle",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 250,
                    filter: false,
                },
                {
                    headerName: "Document Type",
                    field: "documentType",
                    filter: false,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 150,
                },
                {
                    headerName: "Document Category",
                    field: "documentCategory",
                    filter: false,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 180,
                },
                {
                    headerName: "Assigned Date",
                    field: "assignedDate",
                    headerComponent: agGridDateHeaderComponent,
                    filter: false,
                    sortable: false,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                    minWidth: 140,
                    maxWidth: 140
                },
                {
                    headerName: "Acceptance Status",
                    field: "completedPercentage",
                    filter: false,
                    sortable: false,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 160,
                    maxWidth: 160
                },
                // {
                //     headerName: "Due Date",
                //     field: "dueDate",
                //     filter: false,
                //     sortable: false,
                //     cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                //     minWidth: 99,
                //     maxWidth: 99
                // },
                {
                    headerName: "Location",
                    field: "location",
                    filter: false,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 95,
                    maxWidth: 95
                },
            ];

            return isMobileCompatible ? [...assignedCols, {
                headerName: "Actions",
                field: "actions",
                cellRenderer: params => {
                    const selectedRow = params.data;
                    return <div className=" h-full w-full flex items-center justify-center ml-5 ">
                        {
                            <span className='flex items-center text-headerColor cursor-pointer gap-2' >
                                <span onClick={async () => {
                                    await store.dispatch(ComplianceAgreementActions.setLoader(true));
                                    await store.dispatch(documentPolicyRequest.assignedDocumentHistory.editAssignedDocumentRequest(selectedRow));
                                    store.dispatch(ComplianceAgreementActions.setLoader(false));
                                }}> <MdOutlineNotificationsActive size={18} /></span>
                                {/* <span onClick={async () => {
                                    await store.dispatch(ComplianceAgreementActions.setLoader(true));
                                    store.dispatch(ComplianceAgreementActions.setNotifySelectedRow(selectedRow));
                                    const params = {
                                        documentId: selectedRow.documentId,
                                        dueDate: exportDateFormat(selectedRow.dueDate)
                                    }
                                    await store.dispatch(documentPolicyRequest.policyData.getPolicyDataRequest(false, params));
                                    store.dispatch(ComplianceAgreementActions.setLoader(false));
                                }}> <MdOutlineNotificationsActive size={18} /></span> */}
                                <span onClick={async () => {
                                    await store.dispatch(ComplianceAgreementActions.setLoader(true));
                                    await store.dispatch(documentPolicyRequest.assignedDocumentHistory.getPolicyEmployeeDataRequest(selectedRow));
                                    store.dispatch(ComplianceAgreementActions.setLoader(false));
                                }}> <TbCheckupList size={18} /></span>
                            </span>
                        }
                    </div>
                },
                lockPosition: 'right',
                pinned: 'right',
                sortable: false,
                headerClass: " !pl-2 !pr-1",
                filter: false,
                minWidth: 70,
                maxWidth: 70
            }] : assignedCols;
        },
        contextMenuItems: ({ selectedRow }) => {
            return <ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                <MenuItem
                    className={classNames.contextMenuItem}
                    onClick={async () => {
                        await store.dispatch(ComplianceAgreementActions.setLoader(true));
                        await store.dispatch(documentPolicyRequest.assignedDocumentHistory.editAssignedDocumentRequest(selectedRow));
                        store.dispatch(ComplianceAgreementActions.setLoader(false));
                    }}
                >
                    <span className='flex items-center'><FiEdit size={18} /> <span className='mx-2'>Edit</span></span>
                </MenuItem>
                {/* <MenuItem
                    className={classNames.contextMenuItem}
                    onClick={async () => {
                        await store.dispatch(ComplianceAgreementActions.setLoader(true));
                        store.dispatch(ComplianceAgreementActions.setNotifySelectedRow(selectedRow));
                        const params = {
                            documentId: selectedRow.documentId,
                            dueDate: exportDateFormat(selectedRow.dueDate)
                        }
                        await store.dispatch(documentPolicyRequest.policyData.getPolicyDataRequest(false, params));
                        store.dispatch(ComplianceAgreementActions.setLoader(false));
                    }}
                >
                    <span className='flex items-center'> <MdOutlineNotificationsActive size={18} /> <span className='mx-2'>Notify</span></span>
                </MenuItem> */}
                <MenuItem
                    className={classNames.contextMenuItem}
                    onClick={async () => {
                        await store.dispatch(ComplianceAgreementActions.setLoader(true));
                        await store.dispatch(documentPolicyRequest.assignedDocumentHistory.getPolicyEmployeeDataRequest(selectedRow));
                        store.dispatch(ComplianceAgreementActions.setLoader(false));
                    }}
                >
                    <span className='flex items-center'> <TbCheckupList size={18} /> <span className='mx-2'>View Acceptance Status</span></span>
                </MenuItem>
            </ContextMenu>
        },
    },
    viewAcceptanceStatus: {
        columns: () => {
            const viewAcceptanceStatusCols = [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    filter: false,
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7,
                    checkboxSelection: false,
                },
                {
                    headerName: "Employee Name",
                    field: "employeeName",
                    tooltipField: "employeeName",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 180,
                    excelWidth: 40,
                    filter: true,
                },
                {
                    headerName: "Status",
                    field: "isReviewed",
                    filter: true,
                    excelWidth: 15,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 150,
                    maxWidth: 150,
                },
                {
                    headerName: "Assigned Date",
                    headerComponent: agGridDateHeaderComponent,
                    field: "assignedDate",
                    filter: false,
                    excelWidth: 18,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                    minWidth: 150,
                    maxWidth: 150,
                },
                {
                    headerName: "Completion Date",
                    headerComponent: agGridDateHeaderComponent,
                    field: "completedDate",
                    filter: false,
                    sortable: false,
                    excelWidth: 18,
                    cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                    minWidth: 150,
                    maxWidth: 150,
                },

            ];

            return viewAcceptanceStatusCols;
        },

    }

}

const handleClickSupervisor = async (event, data, selectedRow) => {
    switch (data.menu) {
        case 'EditSupervisor':
            store.dispatch(supervisorActions.setAddFloatingSupervisorLoader(true));
            store.dispatch(departmentActions.setSupervisorPopup({ show: true, action: "Edit", selectedRow: selectedRow }));
            store.dispatch(supervisorActions.setAddFloatingSupervisorLoader(false));
            break;
        case 'ViewSupervisor':
            store.dispatch(supervisorActions.setAddFloatingSupervisorLoader(true));
            store.dispatch(departmentActions.setSupervisorPopup({ show: true, action: "View", selectedRow: selectedRow }));
            store.dispatch(supervisorActions.setAddFloatingSupervisorLoader(false));
            break;
        case 'deleteSupervisor':
            store.dispatch(supervisorActions.setAddFloatingSupervisorLoader(true));
            store.dispatch(departmentActions.setSupervisorPopup({ selectedRow: selectedRow }));
            await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to delete Department Supervisor Details?`, isOptional: true }));
            store.dispatch(supervisorActions.setAddFloatingSupervisorLoader(false));
            break;
        default:
            console.error("Please ReCheck the Menu list")
    }
}
export const SupervisorColumn = {
    supervisor: {
        column: (isMobileCompatible) => {
            const SupervisorColumn = [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    filter: false,
                    minWidth: 85,
                    maxWidth: 85,
                    excelWidth: 7,
                    checkboxSelection: true
                },
                {
                    headerName: "Location",
                    field: "location",
                    lockPosition: 'center',
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 100,
                    maxWidth: 100,
                    excelWidth: 15,
                },
                {
                    headerName: "Supervisor Name",
                    field: "supervisorName",
                    lockPosition: 'center',
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 250,
                    maxWidth: 250,
                    excelWidth: 35,
                },
                {
                    headerName: "Department",
                    field: "departmentName",
                    lockPosition: 'center',
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 250,
                    maxWidth: 250,
                    excelWidth: 30,
                },
                {
                    headerName: "Description",
                    field: "description",
                    excelWidth: 100,
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    tooltipField: "description"
                },
            ];
            return isMobileCompatible ? [...SupervisorColumn, {
                headerName: "Actions",
                field: "actions",
                cellRenderer: params => {
                    const selectedRow = params.data;

                    return <div className=" h-full w-full flex items-center justify-center ml-5 ">
                        {
                            selectedRow?.recordStatus && selectedRow?.recordStatus === HolidayNameStatus[1].label &&
                            <span className='flex items-center text-headerColor cursor-pointer gap-2' >
                                <span onClick={async () => {
                                    await store.dispatch(supervisorActions.setAddFloatingSupervisorLoader(true));
                                    await store.dispatch(departmentActions.setSupervisorPopup({ show: true, action: "Edit", selectedRow: selectedRow }));
                                    store.dispatch(supervisorActions.setAddFloatingSupervisorLoader(false));
                                }}> <FiEdit size={18} /></span>
                                <span onClick={async () => {
                                    await store.dispatch(supervisorActions.setAddFloatingSupervisorLoader(true));
                                    await store.dispatch(departmentActions.setSupervisorPopup({ selectedRow: selectedRow }));
                                    await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to delete Department Supervisor Details?`, isOptional: true }));
                                    store.dispatch(supervisorActions.setAddFloatingSupervisorLoader(false));
                                }}> <IoClose size={16.5} /></span>
                            </span>
                        }
                    </div>
                },
                lockPosition: 'right',
                pinned: 'right',
                sortable: false,
                headerClass: " !pl-2 !pr-1",
                filter: false,
                minWidth: 70,
                maxWidth: 70
            }] : SupervisorColumn;
        },
        contextMenuItems: ({ history, selectedRow }) => {
            return <ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                <MenuItem
                    data={{ menu: "EditSupervisor", history: history }}
                    className={classNames.contextMenuItem}
                    onClick={(e, data) => handleClickSupervisor(e, data, selectedRow)}
                >
                    <span className='flex items-center'> <FiEdit size={18} /> <span className='mx-2'>Edit</span></span>
                </MenuItem>
                {/* <MenuItem
                    data={{ menu: "ViewSupervisor", history: history }}
                    className={classNames.contextMenuItem}
                    onClick={(e, data) => handleClickSupervisor(e, data, selectedRow)}
                >
                    <span className='flex items-center'> <ImEye size={18} /> <span className='mx-2'>View</span></span>
                </MenuItem> */}
                <MenuItem
                    data={{ menu: "deleteSupervisor", history: history }}
                    className={classNames.contextMenuItem}
                    onClick={(e, data) => handleClickSupervisor(e, data, selectedRow)}
                >
                    <span className='flex items-center'> <ImBin size={16.5} /> <span className='mx-2'>Delete</span></span>
                </MenuItem>
            </ContextMenu>
        },
    },
}


export const DeputationColumns = {
    deputationList: {
        columns: (isMobileCompatible) => {
            const deputationColumns = [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    filter: false,
                    minWidth: 75,
                    maxWidth: 75,
                    excelWidth: 7,
                    checkboxSelection: params => (!isMobileCompatible && params.data?.employmentStatus) ? (params.data.employmentStatus !== setDefaultValue.employmentStatus.relieved) : false,
                },
                {
                    headerName: "Work Location",
                    field: "workLocation",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 93,
                    maxWidth: 93,
                    excelWidth: 20,
                    wrapHeaderText: true,
                },
                {
                    headerName: "Employee Name",
                    field: "employeeName",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 170,
                    excelWidth: 30,
                    wrapHeaderText: true,
                },
                {
                    headerName: "Deputation Location ",
                    field: "deputationLocation",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 115,
                    maxWidth: 115,
                    excelWidth: 20,
                    wrapHeaderText: true,
                },
                {
                    headerName: "Deputation Site",
                    field: "deputationSite",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 120,
                    excelWidth: 30,
                    wrapHeaderText: true,
                },
                {
                    headerName: "Deputation Date",
                    wrapHeaderText: true,
                    headerClass: ' justify-center',
                    headerGroupComponent: ({ displayName }) => agGridDateHeaderComponent({ displayName: displayName, isCenterView: true }),
                    children: [
                        {
                            headerName: "From",
                            field: "deputationFrom",
                            cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                            headerClass: ' childrenAlignCenter',
                            minWidth: 100,
                            maxWidth: 100,
                            excelWidth: 20,
                            wrapHeaderText: true,
                            wrapText: true,
                            autoHeight: true,
                        },
                        {
                            headerName: "To",
                            field: "deputationTo",
                            cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                            headerClass: ' childrenAlignCenter',
                            minWidth: 100,
                            maxWidth: 100,
                            excelWidth: 20,
                            wrapHeaderText: true,
                        },
                    ]
                },
                {
                    headerName: "Travel Date",
                    wrapHeaderText: true,
                    headerClass: ' justify-center',
                    headerGroupComponent: ({ displayName }) => agGridDateHeaderComponent({ displayName: displayName, isCenterView: true }),
                    children: [
                        {
                            headerName: " From",
                            field: "travelFrom",
                            cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                            headerClass: ' childrenAlignCenter',
                            minWidth: 100,
                            maxWidth: 100,
                            excelWidth: 20,
                            wrapHeaderText: true,
                        },
                        {
                            headerName: " To",
                            field: "travelTo",
                            cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                            headerClass: ' childrenAlignCenter',
                            minWidth: 100,
                            maxWidth: 100,
                            excelWidth: 20,
                            wrapHeaderText: true,
                        },
                    ]
                },
                {
                    headerName: "Visa Validity Date",
                    wrapHeaderText: true,
                    headerClass: ' justify-center',
                    headerGroupComponent: ({ displayName }) => agGridDateHeaderComponent({ displayName: displayName, isCenterView: true }),
                    children: [
                        {
                            headerName: " From",
                            field: "visaValidityFrom",
                            cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                            headerClass: ' childrenAlignCenter',
                            minWidth: 100,
                            maxWidth: 100,
                            excelWidth: 20,
                            wrapHeaderText: true,
                        },
                        {
                            headerName: " To",
                            field: "visaValidityTo",
                            cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                            headerClass: ' childrenAlignCenter',
                            minWidth: 100,
                            maxWidth: 100,
                            excelWidth: 20,
                            wrapHeaderText: true,
                        },
                    ]
                },
                {
                    headerName: "Remarks",
                    field: "remarks",
                    cellRenderer: params => SetContextMenuTrigger({ params }),
                    minWidth: 310,
                    excelWidth: 100,
                    wrapHeaderText: true,
                },
            ];
            return isMobileCompatible ? [...deputationColumns, {
                headerName: "Actions",
                field: "actions",
                cellRenderer: params => {
                    const selectedRow = params.data;
                    const isVisible = selectedRow?.employmentStatus !== setDefaultValue.employmentStatus.relieved;
                    return <div className=" h-full w-full flex items-center justify-center ml-5 ">
                        {
                            isVisible &&
                            <span className='flex items-center text-headerColor cursor-pointer gap-2' >
                                <span onClick={async () => {
                                    await store.dispatch(deputationActions.setLoader(true));
                                    await store.dispatch(deputationRequest.getEditDeputationetailsRequest(selectedRow?.deputationID))
                                    store.dispatch(deputationActions.setLoader(false));
                                }}> <FiEdit size={18} /></span>
                                <span onClick={async () => {
                                    await store.dispatch(deputationActions.setDeputationPopup({ selectedRow: selectedRow }));
                                    await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to delete ${selectedRow.employeeName}'s Deputation Details?`, isOptional: true }));
                                }}> <ImBin size={16.5} /></span>
                            </span>
                        }
                    </div>
                },
                lockPosition: 'right',
                pinned: 'right',
                sortable: false,
                headerClass: " !pl-2 !pr-1",
                filter: false,
                minWidth: 50,
                maxWidth: 70
            }] : deputationColumns;
        },
        excelColumn: () => [
            {
                headerName: "S.No",
                field: "sno",
                excelWidth: 7,
            },
            {
                headerName: "Work Location",
                field: "workLocation",
                excelWidth: 20
            },
            {
                headerName: "Employee Name",
                field: "employeeName",
                excelWidth: 30
            },
            {
                headerName: "Deputation Location ",
                field: "deputationLocation",
                excelWidth: 20
            },
            {
                headerName: "Deputation Site",
                field: "deputationSite",
                excelWidth: 30
            },
            {
                headerName: "Deputation From",
                field: "deputationFrom",
                excelWidth: 20
            },
            {
                headerName: "Deputation To",
                field: "deputationTo",
                excelWidth: 20
            },
            {
                headerName: "Travel From",
                field: "travelFrom",
                excelWidth: 20
            },
            {
                headerName: "Travel To",
                field: "travelTo",
                excelWidth: 20
            },
            {
                headerName: "Visa Validity From",
                field: "visaValidityFrom",
                excelWidth: 20
            },
            {
                headerName: "Visa Validity To",
                field: "visaValidityTo",
                excelWidth: 20
            },
            {
                headerName: "Remarks",
                field: "remarks",
                excelWidth: 100
            },
        ],
        contextMenuItems: ({ history, selectedRow }) => {
            return (selectedRow?.employmentStatus !== setDefaultValue.employmentStatus.relieved && <ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                <div>
                    <MenuItem
                        data={{ menu: "Approve", history: history }}
                        className={classNames.contextMenuItem}
                        onClick={async () => {
                            await store.dispatch(deputationActions.setLoader(true));
                            await store.dispatch(deputationRequest.getEditDeputationetailsRequest(selectedRow?.deputationID))
                            store.dispatch(deputationActions.setLoader(false));
                        }}
                    >
                        <span className='flex items-center'> <FiEdit size={18} /> <span className='mx-2'>Edit</span></span>
                    </MenuItem>
                    <MenuItem
                        className={classNames.contextMenuItem}
                        onClick={async () => {
                            await store.dispatch(deputationActions.setDeputationPopup({ selectedRow: selectedRow }));
                            await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to delete ${selectedRow.employeeName}'s Deputation Details?`, isOptional: true }));
                        }}
                    >
                        <span className='flex items-center'> <ImBin size={16.5} /> <span className='mx-2'>Delete</span></span>
                    </MenuItem>
                </div>
            </ContextMenu>
            )
        }
    }
}

export const indiaLeaveReportColumns = {
    leaveAvailedDetailReport: [
        {
            headerName: "S.No",
            field: "sno",
            comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
            cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
            lockPosition: 'left',
            minWidth: 85,
            maxWidth: 85,
        },
        {
            headerName: "Location",
            field: "Location",
            cellRenderer: params => SetContextMenuTrigger({ params }),
            minWidth: 140
        },
        {
            headerName: "Employee Name",
            field: "EmployeeName",
            cellRenderer: params => SetContextMenuTrigger({ params }),
            minWidth: 150
        },
        {
            headerName: "Leave Date",
            field: "LeaveDate",
            cellRenderer: params => SetContextMenuTrigger({ params }),
            minWidth: 120
        },
        {
            headerName: "Full/Half Day",
            field: "ForH",
            cellRenderer: params => SetContextMenuTrigger({ params }),
            minWidth: 150
        },
        {
            headerName: "Leave Type",
            field: "LeaveType",
            cellRenderer: params => SetContextMenuTrigger({ params }),
            minWidth: 150
        },
        {
            headerName: "Approval Status",
            field: "Status",
            cellRenderer: params => SetContextMenuTrigger({ params }),
            minWidth: 150
        },
        {
            headerName: "TotalHrsWorked",
            field: "TotalHrsWorked",
            cellRenderer: params => SetContextMenuTrigger({ params }),
            minWidth: 150
        }
    ],
    employeeAttendance: (data) => {
        let tempColumns = [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                pinned: 'left',
                minWidth: 85,
                maxWidth: 85,
            },
            {
                headerName: "Employee Code",
                field: "EmployeeCode",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                pinned: 'left',
                minWidth: 140,
                maxWidth: 140,
            },
            {
                headerName: "Employee Name",
                field: "EmployeeName",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                lockPosition: 'left',
                pinned: 'left',
                minWidth: 150
            },
        ];
        const filterData = data.map(val => { const { EmployeeID, ...rest } = val; return rest });
        const excelHeaders = Object.keys(filterData[0]);
        let headers = excelHeaders.filter(val => val !== "EmployeeName" && val !== "EmployeeCode").map(val => {
            const splitDate = val.split("_");
            const date = moment(splitDate[0]);
            return {
                month: moment(date).format("MMMM"),
                date: date.get("date"),
                day: splitDate[1],
                sortDate: new Date(date),
                header: val
            }
        });
        const getColorCode = (value) => {
            switch (value) {
                case 'H':
                    return "text-[#00B050] font-bold";
                case 'L':
                    return "text-[#FF0000] font-bold";
                case 0.5:
                    return "text-[#E2AC00] font-bold";
                default:
                    if (value?.includes("0.5")) {
                        return "text-[#E2AC00] font-bold";
                    }
                    return ""
            }
        }

        headers = headers.sort((a, b) => Date.parse(new Date(a.sortDate)) - Date.parse(new Date(b.sortDate)));
        let months = headers.reduce((result, val) => {
            if (typeof (result) === "number") {
                return [{ month: val.month, mergeCells: 1 }];
            }
            const isValidIdx = result.findIndex(val2 => val2.month === val.month);
            if (isValidIdx < 0) {
                result = [...result, { month: val.month, mergeCells: 1 }]
            }
            else {
                result[isValidIdx].mergeCells = result[isValidIdx].mergeCells + 1;
            }
            return result;
        }, 0);

        for (const monthDetails of months) {
            const filteredHeaders = headers.filter(val => val.month === monthDetails.month);
            tempColumns = [
                ...tempColumns,
                {
                    headerName: monthDetails.month,
                    wrapHeaderText: true,
                    minWidth: 150,
                    headerClass: " flex justify-center ",
                    width: 150,
                    children: filteredHeaders.map(headerDetails => {
                        const tempWidthCalc = filteredHeaders.length > 1 ? 60 : 120
                        return {
                            headerName: headerDetails.date.toString(),
                            field: headerDetails.header,
                            wrapHeaderText: true,
                            minWidth: 60,
                            maxWidth: 60,
                            children: [{
                                headerName: headerDetails.day,
                                wrapHeaderText: true,
                                field: headerDetails.header,
                                minWidth: tempWidthCalc,
                                maxWidth: tempWidthCalc,
                                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={`${classNames.contextMenuValue} ${getColorCode(params.data[params.colDef.field])}`}>{params.data[params.colDef.field]}</div></ContextMenuTrigger>),
                            }]
                        }
                    })
                }
            ]
        }
        return tempColumns;
    },
    totalHoursWorked: (data) => {
        let tempColumns = [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                pinned: 'left',
                minWidth: 85,
                maxWidth: 85,
            },
            {
                headerName: "Employee Name",
                field: "EmployeeName",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                pinned: 'left',
                minWidth: 200
            },
        ];
        const filterData = data.map(val => { const { EmployeeID, ...rest } = val; return rest });
        const excelHeaders = Object.keys(filterData[0]);
        let headers = excelHeaders.filter(val => val !== "EmployeeName").map(val => {
            const splitDate = val.split("_");
            const date = moment(splitDate[0]);
            return {
                month: moment(date).format("MMMM"),
                date: date.get("date"),
                day: splitDate[1],
                sortDate: new Date(date),
                header: val
            }
        });

        const setColorCode = (value) => {
            if (value && !isNaN(Number(value)) && Number(value) < 8) {
                return " bg-[#808080] h-full m-0 w-full flex justify-center items-center "
            }
            return " h-full m-0 w-full flex justify-center items-center "
        }

        headers = headers.sort((a, b) => Date.parse(new Date(a.sortDate)) - Date.parse(new Date(b.sortDate)));
        let months = headers.reduce((result, val) => {
            if (typeof (result) === "number") {
                return [{ month: val.month, mergeCells: 1 }];
            }
            const isValidIdx = result.findIndex(val2 => val2.month === val.month);
            if (isValidIdx < 0) {
                result = [...result, { month: val.month, mergeCells: 1 }]
            }
            else {
                result[isValidIdx].mergeCells = result[isValidIdx].mergeCells + 1;
            }
            return result;
        }, 0);

        for (const monthDetails of months) {
            const filteredHeaders = headers.filter(val => val.month === monthDetails.month);
            tempColumns = [
                ...tempColumns,
                {
                    headerName: monthDetails.month,
                    wrapHeaderText: true,
                    minWidth: 150,
                    headerClass: " flex justify-center ",
                    width: 150,
                    children: filteredHeaders.map(headerDetails => {
                        const tempWidthCalc = filteredHeaders.length > 1 ? 60 : 120
                        return {
                            headerName: headerDetails.date.toString(),
                            field: headerDetails.header,
                            wrapHeaderText: true,
                            minWidth: 60,
                            maxWidth: 60,
                            children: [{
                                headerName: headerDetails.day,
                                wrapHeaderText: true,
                                field: headerDetails.header,
                                minWidth: tempWidthCalc,
                                maxWidth: tempWidthCalc,
                                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={`${setColorCode(params.data[params.colDef.field])}`}>{params.data[params.colDef.field]}</div></ContextMenuTrigger>),
                            }]
                        }
                    })
                }
            ]
        }
        return tempColumns;
    }
}
export const wfhColumns = {
    WFHHistory: {
        columns: [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                checkboxSelection: false,
                filter: false,
                minWidth: 85,
                excelWidth: 7,
                maxWidth: 85
            },
            {
                headerName: "Start Date",
                field: "FromDate",
                headerComponent: agGridDateHeaderComponent,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                minWidth: 140,
                maxWidth: 140,
                excelWidth: 16
            },
            {
                headerName: "End Date",
                field: "ToDate",
                headerComponent: agGridDateHeaderComponent,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                minWidth: 140,
                maxWidth: 140,
                excelWidth: 16
            },
            {
                headerName: "Number of days",
                field: "noOfDays",
                minWidth: 145,
                maxWidth: 145,
                excelWidth: 30,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "F/H Day",
                field: "FullOrHalfDay",
                minWidth: 100,
                maxWidth: 120,
                excelWidth: 16,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Reason",
                field: "Remarks",
                excelWidth: 35,
                minWidth: 80,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Approval Status",
                field: "ApprovalStatus",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 120,
                excelWidth: 35,
                // maxWidth: 160,
            },
        ]
    },
    ApproveAndReject: {
        columns: [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                checkboxSelection: true,
                filter: false,
                minWidth: 85,
                excelWidth: 7,
                maxWidth: 85
            },
            {
                headerName: "Employee Name",
                field: "employeeName",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                excelWidth: 25
            },
            {
                headerName: "Start Date",
                headerComponent: agGridDateHeaderComponent,
                field: "FromDate",
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                minWidth: 70,
                maxWidth: 140,
                excelWidth: 15
            },
            {
                headerName: "End Date",
                headerComponent: agGridDateHeaderComponent,
                field: "ToDate",
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
                minWidth: 70,
                maxWidth: 140,
                excelWidth: 15
            },
            {
                headerName: " Number of days",
                field: "noOfDays",
                minWidth: 145,
                maxWidth: 145,
                excelWidth: 14,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "F/H Day",
                field: "FullOrHalfDay",
                minWidth: 100,
                maxWidth: 140,
                excelWidth: 30,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Reason",
                field: "Remarks",
                excelWidth: 50,
                minWidth: 140,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Approval Status",
                field: "ApprovalStatus",
                cellRenderer: params => SetContextMenuTrigger({ params }),
                minWidth: 120,
                excelWidth: 20,
            },
        ],
        ContextMenuItems: ({ selectedRow }) => {
            const requestDetailsConfirmationView = async (statusKey) => {
                await store.dispatch(wfhActions.setLoader(true));
                await store.dispatch(wfhRequest.ApproveRejectRequest.getApproveOrRejectDetails(selectedRow?.workRequestId, async (data) => {
                    await store.dispatch(wfhActions.setApprovalViewPopup({ show: true, selectedRecord: selectedRow, data, statusType: statusKey }));
                }));
                store.dispatch(wfhActions.setLoader(false));
            }
            return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                {
                    (selectedRow?.ApprovalStatus && (selectedRow?.ApprovalStatus === leaveStatus[4].label || selectedRow?.ApprovalStatus === leaveStatus[3].label)) &&
                    <div>
                        <MenuItem className={classNames.contextMenuItem} onClick={() => requestDetailsConfirmationView(leaveStatus[4].Key)} >
                            <span className='flex items-center gap-y-[2px]'>
                                <span><TiTick size={18.5} /></span>
                                <span className=' flex items-center gap-x-1'>Approve  <span className=' ml-[2px]'>/</span> <span className=' flex items-center gap-x-[2px]'><IoClose size={18} style={{ strokeWidth: "18px" }} /> Reject</span></span>
                            </span>
                        </MenuItem>
                    </div>
                }
                {
                    selectedRow?.ApprovalStatus && selectedRow?.ApprovalStatus === leaveStatus[1].label &&
                    <MenuItem className={classNames.contextMenuItem} onClick={() => requestDetailsConfirmationView(leaveStatus[1].Key)} >
                        <span className='flex items-center'> <TiCancel size={18} /> <span className='mx-2'>Cancel</span></span>
                    </MenuItem>
                }
                <MenuItem className={classNames.contextMenuItem} onClick={() => {
                    store.dispatch(wfhActions.setWFHHistoryPopup({ show: true, selectedRecord: selectedRow, status: selectedRow?.ApprovalStatus }));
                }} >
                    <span className='flex items-center'><HiOutlineClipboardList size={18} style={{ strokeWidth: "2.5px" }} /> <span className='mx-2'>View WFH History</span></span>
                </MenuItem>
            </ContextMenu>)
        }
    },
    wfhApprovalView: {
        column: [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div>), //holdToDisplay={0}
                lockPosition: 'left',
                minWidth: 70,
                maxWidth: 70,
            },
            {
                headerName: "WFH Date",
                headerComponent: agGridDateHeaderComponent,
                field: "requestedDate",
                minWidth: 140,
                maxWidth: 140,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
            },
            {
                headerName: "F/H Day",
                field: "fullOrHalfDay",
                minWidth: 100,
                maxWidth: 100,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Status",
                field: "approvalStatus",
                minWidth: 100,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            }
        ]
    }
}

export const timeInAndTimeOut = {
    timeInAndTimeOutHistory: {
        column: () => [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<div className={classNames.contextMenuValue}>{params.node.rowPinned !== "bottom" ? Number(params.node.id) + 1 : ''}</div>), //holdToDisplay={0}
                lockPosition: 'left',
                minWidth: 70,
                maxWidth: 70,
            },
            {
                headerName: "Date",
                field: "workDate",
                minWidth: 140,
                maxWidth: 140,
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{dayWithDateFormatElement(params.data.workDate)}</div></ContextMenuTrigger>),
            },
            {
                headerName: "In",
                field: "timeIn1",
                minWidth: 100,
                maxWidth: 100,
                colSpan: params => params.node.rowPinned ? (params.columnApi.getAllDisplayedColumns().length) - 4 : 1,
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={params.node.rowPinned ? ' text-right pr-5  borderRight ' : classNames.contextMenuValue}>{params.data.timeIn1}</div></ContextMenuTrigger>),
            },
            {
                headerName: "Out",
                field: "timeOut1",
                minWidth: 100,
                maxWidth: 100,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "In",
                field: "timeIn2",
                minWidth: 100,
                maxWidth: 100,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Out",
                field: "timeOut2",
                minWidth: 100,
                maxWidth: 100,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "In",
                field: "timeIn3",
                minWidth: 100,
                maxWidth: 100,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Out",
                field: "timeOut3",
                minWidth: 100,
                maxWidth: 100,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "In",
                field: "timeIn4",
                minWidth: 100,
                maxWidth: 100,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Out",
                field: "timeOut4",
                minWidth: 100,
                maxWidth: 100,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Total Works",
                field: "totalHoursCalculation",
                minWidth: 127,
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={params.node.rowPinned ? ' text-left px-5  borderRight ' : classNames.contextMenuValue}>{params.data.totalHoursCalculation}</div></ContextMenuTrigger>),
            },
            {
                headerName: "Total Hours",
                field: "workhours",
                minWidth: 120,
                headerComponent: ({ displayName }) => <div className={` flex !flex-col !items-start ag-header ag-header-cell-label !border-0`}><div>{displayName}</div><div className=' text-12px'>(HH:MM)</div></div>,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            }
        ]
    },
    timeInAndTimeOutEmployeeHistory: {
        column: () => [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<div className={classNames.contextMenuValue}>{params.node.rowPinned !== "bottom" ? Number(params.node.id) + 1 : ''}</div>), //holdToDisplay={0}
                lockPosition: 'left',
                checkboxSelection: true,
                excelWidth: 7,
                minWidth: 70,
                maxWidth: 70,
            },
            {
                headerName: "Date",
                field: "workDate",
                excelWidth: 12,
                minWidth: 100,
                maxWidth: 100,
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{dayWithDateFormatElement(params.data.workDate)}</div></ContextMenuTrigger>),
            },
            {
                headerName: 'Employee Name',
                field: 'employeeName',
                excelWidth: 25,
                minWidth: 220,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "In",
                field: "timeIn1",
                minWidth: 100,
                maxWidth: 100,
                excelWidth: 10,
                colSpan: params => params.node.rowPinned ? (params.columnApi.getAllDisplayedColumns().length) - 5 : 1,
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={params.node.rowPinned ? ' text-right pr-5  borderRight ' : classNames.contextMenuValue}>{params.data.timeIn1}</div></ContextMenuTrigger>),
            },
            {
                headerName: "Out",
                field: "timeOut1",
                minWidth: 100,
                maxWidth: 100,
                excelWidth: 10,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "In",
                field: "timeIn2",
                minWidth: 100,
                maxWidth: 100,
                excelWidth: 10,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Out",
                field: "timeOut2",
                minWidth: 100,
                maxWidth: 100,
                excelWidth: 10,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "In",
                field: "timeIn3",
                minWidth: 100,
                maxWidth: 100,
                excelWidth: 10,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Out",
                field: "timeOut3",
                minWidth: 100,
                maxWidth: 100,
                excelWidth: 10,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "In",
                field: "timeIn4",
                minWidth: 100,
                maxWidth: 100,
                excelWidth: 10,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Out",
                field: "timeOut4",
                minWidth: 100,
                maxWidth: 100,
                excelWidth: 10,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Total Works",
                field: "totalHoursCalculation",
                minWidth: 127,
                excelWidth: 15,
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={params.node.rowPinned ? ' text-left px-5  borderRight ' : classNames.contextMenuValue}>{params.data.totalHoursCalculation}</div></ContextMenuTrigger>),
            },
            {
                headerName: "Total Hours",
                field: "workhours",
                minWidth: 120,
                excelWidth: 15,
                headerComponent: ({ displayName }) => <div className={`flex !flex-col items-center justify-center ag-header ag-header-cell-label !border-0`}><div>{displayName}</div><div className=' text-12px'>(HH:MM)</div></div>,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
        ],
        contextMenuItems: ({ selectedRow }) => {
            return (
                <ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
                    <MenuItem
                        data={{ menu: "Approve", history: history }}
                        className={classNames.contextMenuItem}
                        onClick={async () => {
                            await store.dispatch(timeInTimeOutActions.setTimeInTimeOutPopup({ show: true, selectedRow }));
                        }}
                    >
                        <span className='flex items-center'> <FiEdit size={18} /> <span className='mx-2'>Edit</span></span>
                    </MenuItem>

                </ContextMenu>
            )
        },
        uploadAuditPopup: {
            columns: [
                {
                    headerName: "S.No",
                    field: "sno",
                    comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                    cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                    lockPosition: 'left',
                    filter: false,
                    checkboxSelection: false,
                    minWidth: 85,
                    maxWidth: 85,
                },
            ],
            convertFormattedRecords: (jsonData) => {
                let customDatas = [];
                let columns = [...timeInAndTimeOut.timeInAndTimeOutEmployeeHistory.uploadAuditPopup.columns];
                if (jsonData.length > 0) {
                    const headers = jsonData[0];
                    for (const firstIndex in jsonData) {
                        if (firstIndex > 0 && jsonData[firstIndex].length > 0) {
                            let customHeaderObj = {};
                            for (const headerIndex in headers) {
                                if (jsonData[firstIndex].length > headerIndex) {
                                    customHeaderObj = { ...customHeaderObj, [headers[headerIndex]]: jsonData[firstIndex][headerIndex] }
                                }
                            }
                            customDatas = [...customDatas, { ...customHeaderObj }];
                        } else if (firstIndex <= 0 && jsonData[firstIndex].length > 0) {
                            for (const headerIndex in headers) {
                                if (headers[headerIndex] !== timeInAndTimeOut.timeInAndTimeOutEmployeeHistory.uploadAuditPopup.columns[0].headerName) {
                                    columns = [...columns, {
                                        headerName: headers[headerIndex],
                                        field: headers[headerIndex],
                                        cellRenderer: params => SetContextMenuTrigger({ params }),
                                        minWidth: Number(headerIndex) === 1 ? 250 : 120,
                                        width: Number(headerIndex) === 1 ? 400 : 120,
                                    }]
                                }

                            }
                        }
                    }
                }
                return { columns, data: customDatas }
            }
        }
    },
    timeInAndTimeOutSummary: {
        column: (setLoader) => [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<div className={classNames.contextMenuValue}>{params.node.rowPinned !== "bottom" ? Number(params.node.id) + 1 : ''}</div>), //holdToDisplay={0}
                lockPosition: 'left',
                checkboxSelection: false,
                excelWidth: 7,
                filter: false,
                minWidth: 70,
                maxWidth: 70,
            },
            {
                headerName: 'Employee Name',
                field: 'employeeName',
                minWidth: 220,
                cellRenderer: params => SetContextMenuTrigger({
                    params, isSelectable: !!(("remarks" in params.data) && params.data?.remarks?.length > 0), onClick: async () => {
                        await setLoader(true);
                        const payload = {
                            employeeId: params.data?.employeeId,
                            fromDate: params.data?.fromDate,
                            toDate: params.data?.toDate
                        }
                        await store.dispatch(timeInTimeOutRequest.getMissOutPunchDetails(payload, async (data) => {
                            if (timeInOutReducerState().viewMissOutPunches.show) await store.dispatch(timeInTimeOutActions.viewMissOutPunches({ show: false, selectedRow: {}, data: {} }));
                            await store.dispatch(timeInTimeOutActions.viewMissOutPunches({ show: true, selectedRow: params.data, data }));
                        }));
                        setLoader(false);
                    }
                }),
                excelWidth: 30
            },
            {
                headerName: "Total Works",
                field: "totalHoursCalculation",
                minWidth: 127,
                maxWidth: 150,
                cellRenderer: params => SetContextMenuTrigger({ params }),
                excelWidth: 16,
                filter: false,
            },
            {
                headerName: "Total Hours",
                field: "totalWorkHours",
                minWidth: 115,
                maxWidth: 115,
                headerComponent: ({ displayName }) => <div className={`flex !flex-col items-center justify-center ag-header ag-header-cell-label !border-0`}><div>{displayName}</div><div className=' text-12px'>(HH:MM)</div></div>,
                cellRenderer: params => SetContextMenuTrigger({ params }),
                excelWidth: 16,
                filter: false,
            },
            {
                headerName: "Remarks",
                field: "remarks",
                minWidth: 120,
                cellRenderer: params => SetContextMenuTrigger({ params }),
                excelWidth: 25,
                filter: false,
            },
        ]
    },
    viewMissOutPunches: {
        leaveHistoryColumns: [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div>), //holdToDisplay={0}
                lockPosition: 'left',
                minWidth: 70,
                maxWidth: 70,
            },
            {
                headerName: "Leave Requested Date",
                headerComponent: agGridDateHeaderComponent,
                field: "workDate",
                minWidth: 190,
                maxWidth: 190,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
            },
            {
                headerName: "Leave Type",
                field: "leaveType",
                minWidth: 120,
                maxWidth: 120,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "F/H Day",
                field: "fullOrHalfDay",
                minWidth: 120,
                maxWidth: 120,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Status",
                field: "summaryOrStatus",
                minWidth: 120,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            }
        ],
        timeInOutDetailsColumn: [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<div className={classNames.contextMenuValue}>{(params.node.rowPinned !== "bottom" && params.data?.workDate) ? Number(params.node.id) + 1 : ''}</div>), //holdToDisplay={0}
                lockPosition: 'left',
                minWidth: 70,
                maxWidth: 70,
            },
            {
                headerName: "Date",
                field: "workDate",
                minWidth: 110,
                maxWidth: 110,
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{dayWithDateFormatElement(params.data.workDate)}</div></ContextMenuTrigger>),
            },
            {
                headerName: "In",
                field: "timeIn1",
                minWidth: 82,
                colSpan: params => {
                    if (params.node.rowPinned || !params.data?.workDate) {
                        return (params.columnApi.getAllDisplayedColumns()?.length - 8)
                    }
                    return params.data?.dateCategory === strings.type.holiday ? (params.columnApi.getAllDisplayedColumns()?.length - 1) : 1;
                },
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={(params.node.rowPinned || !params.data?.workDate) ? ' text-right pr-5 font-extrabold borderRight ' : (params.data?.dateCategory === strings.type.holiday ? `${classNames.contextMenuValue} text-center font-extrabold` : classNames.contextMenuValue)}>{!params.data?.workDate ? params.data?.employeeName : (params.data?.dateCategory === strings.type.holiday ? params.data?.dateCategory : params.data.timeIn1)}</div></ContextMenuTrigger>),
            },
            {
                headerName: "Out",
                field: "timeOut1",
                minWidth: 82,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "In",
                field: "timeIn2",
                minWidth: 82,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Out",
                field: "timeOut2",
                minWidth: 82,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "In",
                field: "timeIn3",
                minWidth: 82,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Out",
                field: "timeOut3",
                minWidth: 82,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "In",
                field: "timeIn4",
                minWidth: 82,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Out",
                field: "timeOut4",
                minWidth: 82,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Total Works",
                field: "totalHoursCalculation",
                minWidth: 118,
                cellRenderer: params => SetContextMenuTrigger({ params, setBgColor: "borderRight font-extrabold" }),
            },
            {
                headerName: "Regular",
                field: "regular",
                minWidth: 90,
                cellRenderer: params => SetContextMenuTrigger({ params, setBgColor: "borderRight font-extrabold" }),
            },
            {
                headerName: "Vacation",
                field: "vacationLeaveTaken",
                minWidth: 95,
                cellRenderer: params => SetContextMenuTrigger({ params, setBgColor: "borderRight font-extrabold" }),
            },
            {
                headerName: "Sick",
                field: "sickLeaveTaken",
                minWidth: 75,
                cellRenderer: params => SetContextMenuTrigger({ params, setBgColor: "borderRight font-extrabold" }),
            },
            {
                headerName: "Holiday",
                field: "holiday",
                minWidth: 95,
                cellRenderer: params => SetContextMenuTrigger({ params, setBgColor: "borderRight font-extrabold" }),
            },
            {
                headerName: "OT",
                field: "overTime",
                minWidth: 70,
                cellRenderer: params => SetContextMenuTrigger({ params, setBgColor: "borderRight font-extrabold" }),
            },
            // {
            //     headerName: "Total Hours",
            //     field: "workhours",
            //     minWidth: 120,
            //     headerComponent: ({ displayName }) => <div className={` flex !flex-col !items-start ag-header ag-header-cell-label !border-0`}><div>{displayName}</div><div className=' text-12px'>(HH:MM)</div></div>,
            //     cellRenderer: params => SetContextMenuTrigger({ params }),
            // }
        ]
    },
    timeSheetRecord: {
        column: (setLoader) => [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                minWidth: 68,
                maxWidth: 68,
                sortable: false,
                headerClass: " !pl-1 !pr-1",
            },
            {
                headerName: "Employee Name",
                field: "employeeName",
                cellRenderer: params => SetContextMenuTrigger({
                    setBgColor: "forWrapTextConfigurationFunctionality ", params, isSelectable: true, onClick: async () => {
                        await setLoader(true);
                        const payload = {
                            employeeId: params.data?.employeeId,
                            fromDate: params.data?.fromDate,
                            toDate: params.data?.toDate
                        }
                        await store.dispatch(timeInTimeOutRequest.getMissOutPunchDetails(payload, async (data) => {
                            if (timeInOutReducerState().viewMissOutPunches.show) await store.dispatch(timeInTimeOutActions.viewMissOutPunches({ show: false, selectedRow: {}, data: {} }));
                            await store.dispatch(timeInTimeOutActions.viewMissOutPunches({ show: true, selectedRow: params.data, data }));
                        }));
                        setLoader(false);
                    }
                }),
                minWidth: 260,
                wrapHeaderText: true,
                wrapText: true,
                autoHeight: true,
                headerClass: " !pl-1 !pr-1",
            },
            {
                headerName: "Week 1",
                wrapHeaderText: true,
                headerClass: " justify-center",
                children: [
                    {
                        headerName: "Regular",
                        field: "week1_regular",
                        cellRenderer: params => setReportContextMenu({ params }),
                        minWidth: 70,
                        wrapHeaderText: true,
                        wrapText: true,
                        autoHeight: true,
                        sortable: false,
                        headerClass: " !pl-1 !pr-1",
                    },
                    {
                        headerName: "Vacation Taken",
                        field: "week1_vacationLeaveTaken",
                        cellRenderer: params => setReportContextMenu({ params }),
                        minWidth: 78,
                        wrapHeaderText: true,
                        wrapText: true,
                        autoHeight: true,
                        sortable: false,
                        headerClass: " !pl-1 !pr-1",
                    },
                    {
                        headerName: "Sick Leave Taken",
                        field: "week1_sickLeaveTaken",
                        cellRenderer: params => setReportContextMenu({ params }),
                        minWidth: 88,
                        wrapHeaderText: true,
                        wrapText: true,
                        autoHeight: true,
                        sortable: false,
                        headerClass: " !pl-1 !pr-1",
                    },
                    {
                        headerName: "Holiday",
                        field: "week1_holiday",
                        cellRenderer: params => setReportContextMenu({ params }),
                        minWidth: 60,
                        wrapHeaderText: true,
                        wrapText: true,
                        autoHeight: true,
                        sortable: false,
                        headerClass: " !pl-1 !pr-1",
                    },
                    {
                        headerName: "OT",
                        field: "week1_overTime",
                        cellRenderer: params => setReportContextMenu({ params }),
                        minWidth: 40,
                        wrapHeaderText: true,
                        wrapText: true,
                        autoHeight: true,
                        sortable: false,
                        headerClass: " !pl-1 !pr-1",
                    }
                ]
            },
            {
                headerName: "Week 2",
                wrapHeaderText: true,
                headerClass: " justify-center",
                children: [
                    {
                        headerName: "Regular",
                        field: "week2_regular",
                        cellRenderer: params => setReportContextMenu({ params }),
                        minWidth: 70,
                        wrapHeaderText: true,
                        wrapText: true,
                        autoHeight: true,
                        sortable: false,
                        headerClass: " !pl-1 !pr-1",
                    },
                    {
                        headerName: "Vacation Taken",
                        field: "week2_vacationLeaveTaken",
                        cellRenderer: params => setReportContextMenu({ params }),
                        minWidth: 78,
                        wrapHeaderText: true,
                        wrapText: true,
                        autoHeight: true,
                        sortable: false,
                        headerClass: " !pl-1 !pr-1",
                    },
                    {
                        headerName: "Sick Leave Taken",
                        field: "week2_sickLeaveTaken",
                        cellRenderer: params => setReportContextMenu({ params }),
                        minWidth: 88,
                        wrapHeaderText: true,
                        wrapText: true,
                        autoHeight: true,
                        sortable: false,
                        headerClass: " !pl-1 !pr-1",
                    },
                    {
                        headerName: "Holiday",
                        field: "week2_holiday",
                        cellRenderer: params => setReportContextMenu({ params }),
                        minWidth: 60,
                        wrapHeaderText: true,
                        wrapText: true,
                        autoHeight: true,
                        sortable: false,
                        headerClass: " !pl-1 !pr-1",
                    },
                    {
                        headerName: "OT",
                        field: "week2_overTime",
                        cellRenderer: params => setReportContextMenu({ params }),
                        minWidth: 40,
                        wrapHeaderText: true,
                        wrapText: true,
                        autoHeight: true,
                        sortable: false,
                        headerClass: " !pl-1 !pr-1",
                    }
                ]
            },
            {
                headerName: "Total Regular Works",
                field: "totalWorkHours",
                cellRenderer: params => setReportContextMenu({ params }),
                minWidth: 70,
                wrapHeaderText: true,
                wrapText: true,
                autoHeight: true,
                sortable: false,
                headerClass: " !pl-1 !pr-1",
            },
            {
                headerName: "Total OT",
                field: "totalOverTime",
                cellRenderer: params => setReportContextMenu({ params }),
                minWidth: 71,
                wrapHeaderText: true,
                wrapText: true,
                autoHeight: true,
                sortable: false,
                headerClass: " !pl-1 !pr-1",
            },
            {
                headerName: "Total Vacation",
                field: "totalVLTaken",
                cellRenderer: params => setReportContextMenu({ params }),
                minWidth: 70,
                wrapHeaderText: true,
                wrapText: true,
                autoHeight: true,
                sortable: false,
                headerClass: " !pl-1 !pr-1",
            },
            {
                headerName: "Total Sick",
                field: "totalSLTaken",
                cellRenderer: params => setReportContextMenu({ params }),
                minWidth: 50,
                wrapHeaderText: true,
                wrapText: true,
                autoHeight: true,
                sortable: false,
                headerClass: " !pl-1 !pr-1",
            },
            {
                headerName: "Holiday",
                field: "totalHoliday",
                cellRenderer: params => setReportContextMenu({ params }),
                minWidth: 60,
                wrapHeaderText: true,
                wrapText: true,
                autoHeight: true,
                sortable: false,
                headerClass: " !pl-1 !pr-1",
            },
            {
                headerName: "Remarks",
                field: "remarks",
                cellRenderer: params => setReportContextMenu({ params, setBgColor: "forWrapTextConfigurationFunctionality " }),
                minWidth: 200,
                wrapHeaderText: true,
                wrapText: true,
                autoHeight: true,
                sortable: false,
                headerClass: " !pl-1 !pr-1",
            },
        ],
        excelDownload: () => [
            {
                headerName: "S.No",
                field: "sno",
                excelWidth: 7,
            },
            // {
            //     headerName: "Employee Code",
            //     field: "employeeId",
            //     excelWidth: 15,
            // },
            {
                headerName: "Employee Name",
                field: "employeeName",
                excelWidth: 20,
            },
            {
                headerName: "Week1 Regular",
                field: "week1_regular",
                excelWidth: 18,
            },
            {
                headerName: "Week1 Vacation Taken",
                field: "week1_vacationLeaveTaken",
                excelWidth: 22,
            },
            {
                headerName: "Week1 Sick Leave Taken",
                field: "week1_sickLeaveTaken",
                excelWidth: 22,
            },
            {
                headerName: "Week1 Holiday",
                field: "week1_holiday",
                excelWidth: 18,
            },
            {
                headerName: "Week1 Over Time",
                field: "week1_overTime",
                excelWidth: 18,
            },
            {
                headerName: "Week2 Regular",
                field: "week2_regular",
                excelWidth: 18,
            },
            {
                headerName: "Week2 Vacation Taken",
                field: "week2_vacationLeaveTaken",
                excelWidth: 22,
            },
            {
                headerName: "Week2 Sick Leave Taken",
                field: "week2_sickLeaveTaken",
                excelWidth: 22,
            },
            {
                headerName: "Week2 Holiday",
                field: "week2_holiday",
                excelWidth: 18,
            },
            {
                headerName: "Week2 Over Time",
                field: "week2_overTime",
                excelWidth: 18,
            },
            {
                headerName: "Sick Leave Credit",
                field: "sickLeaveCredit",
                excelWidth: 18,
            },
            {
                headerName: "Total Regular Works",
                field: "totalWorkHours",
                excelWidth: 20,
            },
            {
                headerName: "Total OT",
                field: "totalOverTime",
                excelWidth: 20,
            },
            {
                headerName: "Total Vacation",
                field: "totalVLTaken",
                excelWidth: 20,
            },
            {
                headerName: "Total Sick",
                field: "totalSLTaken",
                excelWidth: 20,
            },
            {
                headerName: "Holiday",
                field: "totalHoliday",
                excelWidth: 20,
            },
            {
                headerName: "Remarks",
                field: "remarks",
                excelWidth: 20,
            },
        ]
    }
}

export const addComplianceList = {
    addComplianceList: (setLoader) => [
        {
            headerName: "S.No",
            field: "sno",
            comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
            cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
            lockPosition: 'left',
            checkboxSelection: false,
            minWidth: 80,
            maxWidth: 80
        },
        {
            headerName: "Compliance Category",
            field: "complianceCategory",
            minWidth: 200,
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Compliance Period",
            field: "compliancePeriod",
            minWidth: 200,
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Compliance Date",
            field: "complianceDate",
            minWidth: 150,
            maxWidth: 160,
            cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
        },
        {
            headerName: "Expiry Date",
            field: "expiryDate",
            minWidth: 120,
            maxWidth: 130,
            cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
        },
        {
            headerName: "Description",
            field: "description",
            minWidth: 200,
            cellRenderer: params => SetContextMenuTrigger({ params }),
        },
        {
            headerName: "Document Image",
            field: "employeeComplianceId",
            minWidth: 150,
            maxWidth: 150,
            cellRenderer: params => SetContextMenuTrigger({
                params, isDocumentView: true, onClick: async () => {
                    await setLoader(true)
                    await store.dispatch(employeeRequests.viewMultipleDocuments("compliance", params.value, "documentDetails", "NYS Compliance"));
                    setLoader(false);
                }
            }),
        }
    ],
    myTeamComplianceList: (setLoader, isMobileCompatible, callBackFunc) => {
        const myTeamComplianceListColumn = [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                checkboxSelection: params => !isMobileCompatible && params.data.isValid,
                minWidth: 80,
                maxWidth: 80
            },
            {
                headerName: "Compliance Category",
                field: "complianceCategory",
                minWidth: 200,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Compliance Period",
                field: "compliancePeriod",
                minWidth: 200,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Compliance Date",
                field: "complianceDate",
                minWidth: 150,
                maxWidth: 160,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
            },
            {
                headerName: "Expiry Date",
                field: "expiryDate",
                minWidth: 120,
                maxWidth: 130,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
            },
            {
                headerName: "Description",
                field: "description",
                minWidth: 200,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Document Image",
                field: "employeeComplianceId",
                minWidth: 150,
                maxWidth: 150,
                cellRenderer: params => SetContextMenuTrigger({
                    params, isDocumentView: true, onClick: async () => {
                        await setLoader(true)
                        await store.dispatch(employeeRequests.viewMultipleDocuments("compliance", params.value, "documentDetails", "NYS Compliance"));
                        setLoader(false);
                    }
                }),
            }
        ]
        return isMobileCompatible ? [...myTeamComplianceListColumn, {
            headerName: "Actions",
            field: "actions",
            cellRenderer: params => {
                const selectedRow = params.data;
                const isViewable = employeeReducerState().employeeModule.isDisable;
                return <div className=" h-full w-full flex items-center justify-center gap-2 ml-4">
                    <span className='flex items-center text-headerColor cursor-pointer' onClick={() => callBackFunc(selectedRow)}>
                        {isViewable ? <ImEye size={18} /> : <FiEdit size={18} />}
                    </span>
                </div>
            },
            lockPosition: 'right',
            pinned: 'right',
            sortable: false,
            headerClass: " !pl-2 !pr-1",
            filter: false,
            minWidth: 70,
            maxWidth: 70
        }] : myTeamComplianceListColumn;
    },
    complianceRequest_contextMenuItems: ({ selectedRow, history, callBackFunc }) => {
        const isViewable = employeeReducerState().employeeModule.isDisable;
        return (selectedRow.isValid && <ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
            <MenuItem
                data={{ menu: "EditNysCompliance", history: history }}
                className={classNames.contextMenuItem}
                onClick={() => callBackFunc(selectedRow)}
            >
                {isViewable ?
                    <span className='flex items-center'> <ImEye size={18} /> <span className='mx-2'>View</span></span> :
                    <span className='flex items-center'> <FiEdit size={18} /> <span className='mx-2'>Edit</span></span>
                }
            </MenuItem>
        </ContextMenu>)
    },
    approveAndRejectRequest: (setLoader, isMobileCompatible, callBackFunc) => {
        const approveAndRejectRequestColumns = [
            {
                headerName: "S.No",
                field: "sno",
                comparator: (_valueA, _valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
                cellRenderer: params => (<ContextMenuTrigger id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
                lockPosition: 'left',
                checkboxSelection: !isMobileCompatible,
                minWidth: 80,
                maxWidth: 80
            },
            {
                headerName: "Employee Name",
                field: "complianceCategory",
                minWidth: 200,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Compliance Category",
                field: "complianceCategory",
                minWidth: 200,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Compliance Period",
                field: "compliancePeriod",
                minWidth: 200,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Compliance Date",
                field: "complianceDate",
                minWidth: 150,
                maxWidth: 160,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
            },
            {
                headerName: "Expiry Date",
                field: "expiryDate",
                minWidth: 120,
                maxWidth: 130,
                cellRenderer: params => SetContextMenuTrigger({ params, isDateView: true }),
            },
            {
                headerName: "Description",
                field: "description",
                minWidth: 200,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Status",
                field: "description",
                minWidth: 200,
                cellRenderer: params => SetContextMenuTrigger({ params }),
            },
            {
                headerName: "Document Image",
                field: "employeeComplianceId",
                minWidth: 150,
                maxWidth: 150,
                cellRenderer: params => SetContextMenuTrigger({
                    params, isDocumentView: true, onClick: async () => {
                        await setLoader(true)
                        await store.dispatch(employeeRequests.viewMultipleDocuments("compliance", params.value, "documentDetails", "NYS Compliance"));
                        setLoader(false);
                    }
                }),
            }
        ];
        return isMobileCompatible ? [...approveAndRejectRequestColumns, {
            headerName: "Actions",
            field: "actions",
            cellRenderer: params => {
                const selectedRow = params.data;
                const isViewable = employeeReducerState().employeeModule.isDisable;
                return <div className=" h-full w-full flex items-center justify-center gap-2 ml-4">
                    <span className='flex items-center text-headerColor cursor-pointer' onClick={() => callBackFunc(selectedRow, "Edit")}>
                        <TiTick size={18.5} />  <span>/</span> <IoClose size={18} style={{ strokeWidth: "18px" }} />
                    </span>
                </div>
            },
            lockPosition: 'right',
            pinned: 'right',
            sortable: false,
            headerClass: " !pl-2 !pr-1",
            filter: false,
            minWidth: 70,
            maxWidth: 70
        }] : approveAndRejectRequestColumns;
    },
    approveAndRejectRequest_contextMenuItems: ({ selectedRow, history, callBackFunc }) => {
        const isViewable = employeeReducerState().employeeModule.isDisable;
        return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
            <MenuItem
                data={{ menu: "EditNysCompliance", history: history }}
                className={classNames.contextMenuItem}
                onClick={async () => await store.dispatch(AddComplianceRequestAction.setComplianceRequestApprovePopup({ show: true, selectedRow: {}, }))}
            // onClick={() => callBackFunc(selectedRow, "Edit")}
            >
                <span className='flex items-center gap-y-[2px]'>
                    <span><TiTick size={18.5} /></span>
                    <span className=' flex items-center gap-x-1'>Approve  <span className=' ml-[2px]'>/</span> <span className=' flex items-center gap-x-[2px]'><IoClose size={18} style={{ strokeWidth: "18px" }} /> Reject</span></span>
                </span>
            </MenuItem>
            {!isViewable && <MenuItem
                data={{ menu: "DeleteNysCompliance", history: history }}
                className={classNames.contextMenuItem}
                onClick={async () => { await store.dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to delete compliance category?`, isOptional: true })); }}
            >
                <span className='flex items-center'> <ImBin size={16.5} /> <span className='mx-2'>Delete</span></span>
            </MenuItem>}
        </ContextMenu >)
    },
}