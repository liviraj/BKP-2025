/* eslint-disable react/prop-types */
/* eslint-disable react/display-name */
/* eslint-disable react-refresh/only-export-components */
import { forwardRef, useEffect, useImperativeHandle, useState } from 'react';
import { PatternFormat } from 'react-number-format';
import moment from 'moment-timezone';
import { setDefaultValue } from '../Constants';
import { numberValidation, userReducerState } from '../helper';

export default forwardRef((props, ref) => {
    const [date, setDate] = useState("");

    useImperativeHandle(ref, () => {
        return {
            doesFilterPass(params) {
                if (date && date !== "" && props?.column?.colId) {
                    let splitedVal = date.split("/").map(val => val.trim()).filter(val => val !== "" && val !== "0");
                    const isLocalLocation = userReducerState().LocationID === setDefaultValue.location.value;
                    let value = params.data[props.column.colId];
                    if (splitedVal.length === 1 && numberValidation(splitedVal[0])) {
                        return Number(splitedVal[0]) === (isLocalLocation ? Number(moment(value).get("date")) : (Number(moment(value).get("month")) + 1));
                    }
                    else if ((splitedVal.length === 2 && numberValidation(splitedVal[0]) && numberValidation(splitedVal[1])) || (splitedVal.length === 3 && splitedVal[2].length < 4 && numberValidation(splitedVal[0]) && numberValidation(splitedVal[1]) && numberValidation(splitedVal[2]))) {
                        return isLocalLocation ? (Number(splitedVal[0]) === Number(moment(value).get("date")) && Number(splitedVal[1]) === (Number(moment(value).get('month')) + 1)) : (Number(splitedVal[0]) === (Number(moment(value).get("month")) + 1) && Number(splitedVal[1]) === Number(moment(value).get("date")));
                    }
                    else if (splitedVal.length === 3 && numberValidation(splitedVal[0]) && numberValidation(splitedVal[1]) && numberValidation(splitedVal[2])) {
                        return isLocalLocation ? (Number(splitedVal[0]) === Number(moment(value).get("date")) && Number(splitedVal[1]) === (Number(moment(value).get('month')) + 1) && Number(splitedVal[2]) === Number(moment(value).get("year"))) : (Number(splitedVal[0]) === (Number(moment(value).get("month")) + 1) && Number(splitedVal[1]) === Number(moment(value).get("date")) && Number(splitedVal[2]) === Number(moment(value).get("year")));
                    }
                    return true;
                }
                return false;
            },

            isFilterActive() {
                return date !== "";
            },

            getModel() { },
            setModel() { },
        };
    });

    useEffect(() => {
        props.filterChangedCallback();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [date]);

    const setDateFormat = (date) => {
        let customDate = date;
        let splitedVal = date.split("/").map(val => val.trim());
        customDate = dateReplace(customDate, splitedVal[0], 1, 3);
        customDate = dateReplace(customDate, splitedVal[1], 3, 1);
        return customDate;
    }

    const dateReplace = (customDate, val, count1, count2) => {
        const islocated = userReducerState().LocationID === setDefaultValue.location.value;
        if (val && val !== "" && val !== "0") {
            if (val.length < 2 && ((islocated && Number(val) > count2) || (!islocated && Number(val) > count1))) {
                customDate = customDate.replace(`${val} `, `0${val}`);
            }
        }
        return customDate;
    }

    return (
        <div>
            <header className=' bg-lightGrey text-14px font-bold border border-solid border-darkGrey p-2'>Date Filter</header>
            <div>
                <div className=' bg-white border border-solid border-darkGrey rounded-b p-2'>
                    <PatternFormat
                        format="##/##/####"
                        value={date?.includes("/") ? date.replaceAll("/", "") : date}
                        onValueChange={(values) => {
                            setDate(setDateFormat(values.formattedValue));
                        }}
                        className=' text-14px font-bold font-fontfamily appearance-none border-b-2 border-gray-400 w-full h-full py-2 px-4 text-gray-700 focus:outline-none '
                        isAllowed={(isvalid) => {
                            if (isvalid.formattedValue === "") {
                                return true;
                            }
                            const splitDate = isvalid.formattedValue.split("/");
                            if (splitDate && splitDate.length > 0) {
                                if (userReducerState().LocationID === setDefaultValue.location.value) {
                                    return splitDate[1] < 13 && splitDate[0] < 32;
                                }
                                return splitDate[0] < 13 && splitDate[1] < 32;
                            }
                            return true;
                        }}
                        placeholder={userReducerState().LocationID === setDefaultValue.location.value ? "DD/MM/YYYY" : "MM/DD/YYYY"}
                        valueIsNumericString={true}
                    />
                    <div className='flex justify-end'><button className='border border-solid border-darkGrey rounded px-3 py-2 cursor-pointer mt-3 bg-lightGrey font-bold' onClick={() => setDate("")}>Clear</button></div>
                </div>
            </div>
        </div>
    );
});
