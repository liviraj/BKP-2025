/* eslint-disable react/prop-types */
/* eslint-disable react/display-name */
/* eslint-disable react-refresh/only-export-components */
import { forwardRef, useEffect, useImperativeHandle, useState } from 'react';
import DatePickerElement from '../elements/DatePickerElement';
import { complianceReportDateFormat } from '../helper';

export default forwardRef((props, ref) => {
    const [date, setDate] = useState("");

    useImperativeHandle(ref, () => {
        return {
            doesFilterPass(params) {
                if (date && date !== "" && props?.column?.colId) {
                    return complianceReportDateFormat(params.data[props.column.colId]) === complianceReportDateFormat(date);
                }
                return false;
            },

            isFilterActive() {
                return date !== "";
            },

            getModel() { },
            setModel() { },
        };
    });

    useEffect(() => {
        props.filterChangedCallback();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [date]);

    return (
        <div>
            <header className=' bg-lightGrey text-14px font-bold border border-solid border-darkGrey p-2'>Date Picker</header>
            <div className=' h-96 w-64'>
                <div className=' bg-white border border-solid border-darkGrey rounded-b p-2'>
                    <DatePickerElement value={date} onChange={date => setDate(date)} />
                    <div className='flex justify-end'><button className='border border-solid border-darkGrey rounded px-3 py-2 cursor-pointer mt-3 bg-lightGrey font-bold' onClick={() => setDate("")}>Clear</button></div>
                </div>
            </div>
        </div>
    );
});
