/* eslint-disable react/prop-types */
/* eslint-disable react/display-name */
/* eslint-disable react-refresh/only-export-components */
import PropTypes from 'prop-types';
import {
  forwardRef,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';

const FloatingFilterDatePicker = forwardRef((props, ref) => {
  const [date, setDate] = useState("");
  const inputRef = useRef(null);

  // expose AG Grid Filter Lifecycle callbacks
  useImperativeHandle(ref, () => {
    return {
      onParentModelChanged(parentModel) {
        // When the filter is empty we will receive a null value here
        if (!parentModel) {
          inputRef.current.value = '';
          setDate(null);
        } else {
          inputRef.current.value = parentModel.filter;
          setDate(parentModel.filter);
        }
      },
    };
  });

  const onInputBoxChanged = (e) => {
    if (e.target.value === '') {
      // Remove the filter
      props.parentFilterInstance((instance) => {
        instance.onFloatingFilterChanged(null, null);
      });
      return;
    }

    setDate(e.target.value);
    props.parentFilterInstance((instance) => {
      instance.onFloatingFilterChanged(null, e.target.value);
    });
  };


  return (
    <input
      className={` appearance-none border-[1px] border-gray-400 rounded outline-none floatingFilterStyle px-1 text-gray-700 leading-tight focus:outline-none w-full font-normal label-shadow`}
      value={date}
      onInput={onInputBoxChanged}
      placeholder={"DD/MM/YYYY"}
      type={"text"}
    />
  );
});

export default FloatingFilterDatePicker;

FloatingFilterDatePicker.propTypes = {
  parentFilterInstance: PropTypes.func
}
