import PropTypes from 'prop-types';

const CustomTooltip = (props) => {
  let tooltipValue = "";
  if (props.location === "header") {
    tooltipValue = props?.value && props.value.length > 0 ? props.value : "";
  }
  else if (props.location === "cell") {
    tooltipValue = props?.value && props.value.length > 20 ? props.value : "";
  }

  return (
    <div className={tooltipValue ? "custom-tooltip" : " hidden"}> <span>{tooltipValue || ""}</span></div>
  );
};

export default CustomTooltip;

CustomTooltip.propTypes = {
  location: PropTypes.string,
  value: PropTypes.string
}


