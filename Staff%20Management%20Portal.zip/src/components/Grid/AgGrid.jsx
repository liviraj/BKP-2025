import { useRef, useMemo, useEffect, useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import { AgGridReact } from 'ag-grid-react';
import CustomTooltip from './CustomTooltip';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { leaveManagementReducerState, leaveRequestApprovalValidation, leaveStatus } from '../helper';
import { status, HolidayNameStatus } from '../Constants';

function AgGrid({ data, columns, ContextMenuItems, height, history, callBack, rowStyle, multiRowSelection, getSelectedRow, isSetFilter, defaultAllRowselection, isLeaveHistoryRemoveSelectable, initialAllRowSelection, selectedKeyRowSelection, isUploadAuditDocumentRemoveSelectable, pinnedBottomRowData, isDesignationActiveSelectable, isAutoHeight, maxScrollCount }) {
  const gridRef = useRef();
  const [selectedRow, setSelectedRow] = useState({});
  const scrollCount = maxScrollCount || 15;
  const defaultColDef = useMemo(() => {
    return {
      sortable: true,
      resizable: true,
      width: 100,
      floatingFilter: isSetFilter,
      filter: isSetFilter,
      suppressMenu: true,
      suppressFiltersToolPanel: true,
      floatingFilterComponentParams: {
        suppressFilterButton: true,
      },
      filterParams: {
        buttons: ['clear'],
      },
      flex: 1,
      tooltipComponent: CustomTooltip
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    setSelectedRow({});
    if (isLeaveHistoryRemoveSelectable && gridRef.current.api) {
      gridRef.current.api.forEachNode((node) => {
        const selectedLeaveStatus = node.data.approvalStatus && leaveStatus.find(val => val.label === node.data.approvalStatus) ? leaveStatus.find(val => val.label === node.data.approvalStatus) : {};
        if (Object.keys(selectedLeaveStatus).length > 0) {
          node.selectable = !leaveRequestApprovalValidation(leaveStatus.find(val => val.label === node.data.approvalStatus).Key, status.cancel);
        }
        return node;
      });
    }
    else if (isUploadAuditDocumentRemoveSelectable && gridRef.current.api) {
      gridRef.current.api.forEachNode((node) => {
        const isValidData = node.data?.isValid && (node.data?.isValid === 'true');
        const selectedLeaveStatus = node.data?.isValid ? !(isValidData) : false;
        node.selectable = !!selectedLeaveStatus;
        return node;
      });
    }
    else if (isDesignationActiveSelectable && gridRef.current.api) {
      gridRef.current.api.forEachNode((node) => {
        const selectedDesignationStatus = node.data?.recordStatus ? (node.data?.recordStatus === HolidayNameStatus[1].label) : false;
        node.selectable = !!selectedDesignationStatus;
        return node;
      });
    }
    if (initialAllRowSelection) {
      initialAllLoadSelection();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data])

  const getRowStyle = params => {
    if (params.node.rowIndex % 2 === 0) {
      return { background: "#ffff" };
    }
    else {
      return { backgroundColor: '#ffff' }
    }
  };

  const onSelectionChanged = useCallback(() => {
    const selectedRows = gridRef.current.api.getSelectedRows();
    setSelectedRow(selectedRows && selectedRows.length > 0 ? { ...selectedRows[0] } : {});
    if (getSelectedRow) getSelectedRow(selectedRows);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const initialAllLoadSelection = () => {
    if (gridRef.current.api && data.length > 0) {
      gridRef.current.api.forEachNode((node) => {
        node.setSelected(selectedKeyRowSelection ? !!node.data[selectedKeyRowSelection] : true);
        return node;
      });
      setSelectedRow(gridRef.current.api.getSelectedRows());
      if (getSelectedRow) getSelectedRow(gridRef.current.api.getSelectedRows());
    }
  }

  const onFirstDataRendered = useCallback(() => {
    if (defaultAllRowselection) {
      gridRef.current.api.forEachNode((node) => {
        const currentSelectedRow = leaveManagementReducerState().leaveRequestQueue.selectedRow;
        node.selectable = !leaveRequestApprovalValidation(node.data.status, currentSelectedRow.action);
        node.setSelected(selectedKeyRowSelection ? !!node.data[selectedKeyRowSelection] : (currentSelectedRow.cancelApprovalStatus === leaveStatus[4].label ? true : !leaveRequestApprovalValidation(node.data.status, currentSelectedRow.action)));
        return node;
      });
      setSelectedRow(gridRef.current.api.getSelectedRows());
      if (getSelectedRow) getSelectedRow(gridRef.current.api.getSelectedRows());
    }
    if (initialAllRowSelection) {
      initialAllLoadSelection();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className={`ag-theme-alpine ${(isAutoHeight && data?.length <= scrollCount ? false : height) ? height + " min-h-40 " : ""} w-full`} >
      {ContextMenuItems && selectedRow && Object.keys(selectedRow).length > 0 && <ContextMenuItems selectedRow={selectedRow} history={history} callBackFunc={callBack} />}
      <AgGridReact
        rowData={data}
        animateRows={true}
        rowHeight={38}
        headerHeight={40}
        getRowStyle={rowStyle || getRowStyle}
        ref={gridRef}
        defaultColDef={defaultColDef}
        rowGroupPanelShow={'always'}
        suppressDragLeaveHidesColumns={true}
        tooltipShowDelay={0}
        tooltipHideDelay={6000}
        onSelectionChanged={onSelectionChanged}
        suppressRowHoverHighlight={true}
        suppressRowTransform={true}
        pivotPanelShow={'always'}
        localeText={{ dateFormatOoo: "DD MMM YYYY", noRowsToShow: "No Records Found!" }}
        rowSelection={(ContextMenuItems || multiRowSelection) ? (multiRowSelection ? "multiple" : "single") : null}
        rowMultiSelectWithClick={multiRowSelection}
        onFirstDataRendered={onFirstDataRendered}
        pinnedBottomRowData={pinnedBottomRowData}
        domLayout={isAutoHeight && data?.length <= scrollCount ? "autoHeight" : "normal"}
        // eslint-disable-next-line no-unused-vars
        columnDefs={columns ? columns.map(val => { if ("excelWidth" in val) { const { excelWidth, ...rest } = val; return { ...rest }; } return { ...val } }) : []}>
      </AgGridReact>
    </div>
  )
}

export default AgGrid

AgGrid.propTypes = {
  data: PropTypes.array,
  columns: PropTypes.array,
  ContextMenuItems: PropTypes.any,
  height: PropTypes.string,
  history: PropTypes.any,
  callBack: PropTypes.func,
  rowStyle: PropTypes.func,
  multiRowSelection: PropTypes.bool,
  getSelectedRow: PropTypes.func,
  isSetFilter: PropTypes.bool,
  defaultAllRowselection: PropTypes.bool,
  isLeaveHistoryRemoveSelectable: PropTypes.bool,
  initialAllRowSelection: PropTypes.bool,
  selectedKeyRowSelection: PropTypes.string,
  isUploadAuditDocumentRemoveSelectable: PropTypes.bool,
  pinnedBottomRowData: PropTypes.array,
  isDesignationActiveSelectable: PropTypes.bool,
  isAutoHeight: PropTypes.bool,
  maxScrollCount: PropTypes.number
}