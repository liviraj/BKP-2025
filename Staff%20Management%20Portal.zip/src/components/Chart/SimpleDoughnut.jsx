import { AgChartsReact } from 'ag-charts-react';
import ProtoType from 'prop-types';

function SimpleDoughnut({ data }) {
    const options = {
        autoSize: true,
        data,
        height: 120,
        width: 330,
        series: [
            {
                type: 'pie',
                calloutLabelKey: 'requestType',
                fillOpacity: 0.9,
                strokeWidth: 0,
                angleKey: 'value',
                sectorLabelKey: 'value',
                calloutLabel: {
                    enabled: false,
                },
                sectorLabel: {
                    color: 'white',
                    fontWeight: 'bold',
                    formatter: () => {
                        return "";
                    },
                },
                fills: [
                    '#01c4a1',
                    '#ff8044',
                ],
                innerRadiusRatio: 0.7,
                // innerLabels: [
                //   {
                //     text: numFormatter.format(total),
                //     fontSize: 24,
                //     fontWeight: 'bold',
                //   },
                //   {
                //     text: 'Total',
                //     fontSize: 16,
                //   },
                // ],
                highlightStyle: {
                    item: {
                        fillOpacity: 0,
                        stroke: '#36454F',
                        strokeWidth: 1,
                    },
                },

                tooltip: {
                    renderer: (params) => {
                        return { content: params.datum[params.calloutLabelKey] }
                    },
                },
            },
        ],
        legend: {
            position: "right", // 'bottom', 'left', 'top'
            item: {
                paddingX: 1,
                paddingY: 8,
                marker: {
                    padding: 8,
                },
            },
        }
    };

    return <AgChartsReact options={options} />;
}

export default SimpleDoughnut

SimpleDoughnut.propTypes = {
    data: ProtoType.any
}
