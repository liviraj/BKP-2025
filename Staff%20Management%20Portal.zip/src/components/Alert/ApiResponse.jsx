import { useSelector, useDispatch } from 'react-redux';
import { IoClose } from 'react-icons/io5';
import 'react-responsive-modal/styles.css';
import { Modal } from 'react-responsive-modal';
import { BsFillCheckCircleFill, BsFillExclamationCircleFill } from "react-icons/bs";
import { RiCloseCircleFill } from "react-icons/ri";
import { TiWarning } from "react-icons/ti";
import { userRequest } from '../requests';
import Button from '../elements/Button';
import { removeSessionStorage } from '../helper';
import PropTypes from 'prop-types';
import { strings } from '../Constants';

function ApiResponse({ setResponseCallback }) {

    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const dispatch = useDispatch();

    const handleClose = async () => {
        await dispatch(userRequest.apiResponse({ show: false, status: 200, header: "Message Box", message: "", isOptional: false }));
        if (apiResponseState.status === 401 || apiResponseState.status === 403) {
            removeSessionStorage();
        }
    }

    const handleOptionalType = async (isAcceptable) => {
        if (setResponseCallback) {
            await handleClose();
            setResponseCallback(isAcceptable);
        }
    }

    return (
        <div className='modalView'>
            <Modal open={apiResponseState.show} classNames={{ modal: ' p-0 border-2 border-headerColor !rounded min-w-80' }} showCloseIcon={false} onClose={() => { apiResponseState.isOptional ? handleOptionalType(false) : handleClose() }} onEscKeyDown={() => { apiResponseState.isOptional ? handleOptionalType(false) : handleClose() }} >
                <div className='flex font-fontfamily font-bold text-base justify-between px-2 tracking-wider py-2 w-full bg-headerColor text-white'><span className='tracking-widest'>{apiResponseState.header}</span><span className=' cursor-pointer' onClick={() => { apiResponseState.isOptional ? handleOptionalType(false) : handleClose() }}><IoClose size={22} style={{ strokeWidth: "10px" }} /></span></div>
                <div className='flex justify-center items-center font-fontfamily my-3 mx-6 text-center'>
                    {apiResponseState.isOptional || <span>{ResponseStatusSymbol(apiResponseState.status)}</span>}
                    <span className=' text-16px mx-2 font-bold text-darkGrey' dangerouslySetInnerHTML={{ __html: apiResponseState.message }} ></span>
                </div>
                <div className='flex justify-center'>{apiResponseState.isOptional ? <><Button value={strings.Buttons.Yes} onClick={() => handleOptionalType(true)} /><span className=' mx-2'><Button value={strings.Buttons.No} onClick={() => handleOptionalType(false)} /></span></> : <Button value={strings.Buttons.OK} onClick={handleClose} />}</div>
            </Modal>
        </div>
    )
}

ApiResponse.propTypes = {
    setResponseCallback: PropTypes.func
}
export default ApiResponse;


export const ResponseStatusSymbol = (status) => {
    switch (status) {
        case 200:
            return <BsFillCheckCircleFill size={32} color="#5CFF5C" />
        case 204:
            return <BsFillExclamationCircleFill size={32} color="#eed202" />
        case 401:
            return <BsFillExclamationCircleFill size={32} color="#eed202" />
        case 403:
            return <BsFillExclamationCircleFill size={32} color="#eed202" />
        case 400:
            return <TiWarning size={32} color="#eed202" />
        case 404:
            return <BsFillExclamationCircleFill size={32} color="#eed202" />
        case 500:
            return <RiCloseCircleFill size={32} color="#D0342C" /> // internal server Error
        default:
            return <TiWarning size={32} color="#eed202" />

    }
}