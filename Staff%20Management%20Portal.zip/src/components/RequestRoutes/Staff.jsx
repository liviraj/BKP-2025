import { useEffect, useReducer } from 'react';
import AgGrid from '../Grid/AgGrid';
import { setDefaultValue, strings } from '../Constants';
import Button from '../elements/Button';
import Dropdown from '../elements/Dropdown';
import SubHeaderSection from '../layouts/SubHeaderSection';
import { employeeDetails } from '../Grid/Columns';
import { useSelector, useDispatch } from 'react-redux';
import { employeeRequests } from '../requests';
import { useHistory } from 'react-router-dom';
import TransparentLoader from '../loader/TransparentLoader';
import ApiResponse from '../Alert/ApiResponse';
import { dateFormat, employeeReducerState, staffFilterInitialState, staffInitialState } from '../helper';
import EmployeeDetailView from '../Popup_window/EmployeeDetailView';

function Staff() {
  let currentState = JSON.parse(sessionStorage.getItem("staffState"));
  const [state, dispatch] = useReducer(reducer, currentState);
  const employeeState = useSelector(state => state.employee);
  const userState = useSelector(state => state.user);
  const loginResponseState = useSelector(state => state.loginResponse);
  const reduxDispatch = useDispatch();
  const history = useHistory();

  useEffect(() => {
    const fetchData = async () => {
      await reduxDispatch(employeeRequests.loader(true));
      await Promise.all([
        employeeState.employeeStatus.length <= 0 && reduxDispatch(employeeRequests.status()),
        employeeState.location.length <= 0 && reduxDispatch(employeeRequests.location()),
        employeeState.designation.length <= 0 && reduxDispatch(employeeRequests.employeeDesignation()),
        employeeState.department.length <= 0 && reduxDispatch(employeeRequests.employeeDepartment()),
        employeeState.employeeType.length <= 0 && reduxDispatch(employeeRequests.employeeType()),
        employeeState.employeeName.length <= 0 && reduxDispatch(employeeRequests.employeeName()),
        employeeState.clinicalUser.length <= 0 && reduxDispatch(employeeRequests.clinicalUser())
      ]);
      await Promise.all([
        state.status === "" && dispatch({ type: strings.Employees.Status, data: employeeReducerState().employeeStatus.length > 0 && employeeReducerState().employeeStatus.find(val => val.value === setDefaultValue.status.value) }),
        state.location === "" && dispatch({ type: strings.Employees.Location, data: employeeReducerState().location.length > 0 && employeeReducerState().location.find(val => val.value === userState.LocationID) }),
        state.clinicalUsers === "" && dispatch({ type: strings.Employees.ClinicalUsers, data: employeeReducerState().clinicalUser.length > 0 && employeeReducerState().clinicalUser.find(val => val.value === 1) }),
        state.department === "" && dispatch({ type: strings.Employees.Department, data: employeeReducerState().department.length > 0 ? employeeReducerState().department.find(val => val.value === 0) : setDefaultValue.department }),
        state.type === "" && dispatch({ type: strings.Employees.Type, data: employeeReducerState().employeeType.length > 0 && employeeReducerState().employeeType.find(val => val.employeeTypeId === 0) }),
        state.name === "" && dispatch({ type: strings.Employees.Name, data: employeeReducerState().employeeName.length > 0 && employeeReducerState().employeeName.find(val => val.value === 0) }),
        state.designation === "" && dispatch({ type: strings.Employees.Designation, data: employeeReducerState().designation.length > 0 && employeeReducerState().designation.find(val => val.value === 0) })
      ]);
      sessionStorage.setItem("staffFilterState", sessionStorage.getItem("staffModifyFilterState"));
      await reduxDispatch(employeeRequests.tableDatas());
      await reduxDispatch(employeeRequests.loader(false));
    }
    fetchData();
    return () => { sessionStorage.setItem("staffModifyFilterState", sessionStorage.getItem("staffFilterState")) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onClick = async () => {
    await reduxDispatch(employeeRequests.loader(true));
    sessionStorage.setItem("staffFilterState", sessionStorage.getItem("staffModifyFilterState"));
    await reduxDispatch(employeeRequests.tableDatas());
    sessionStorage.setItem("staffState", JSON.stringify(state));
    await reduxDispatch(employeeRequests.loader(false));
  }
  const onReset = async () => {
    await reduxDispatch(employeeRequests.loader(true));
    await sessionStorage.setItem("staffState", JSON.stringify(staffInitialState));
    await sessionStorage.setItem("staffModifyFilterState", JSON.stringify(staffFilterInitialState));
    await Promise.all([
      dispatch({ type: strings.Buttons.Reset }),
      dispatch({ type: strings.Employees.Status, data: employeeReducerState().employeeStatus.length > 0 && employeeReducerState().employeeStatus.find(val => val.value === setDefaultValue.status.value) }),
      dispatch({ type: strings.Employees.Location, data: employeeReducerState().location.length > 0 && employeeReducerState().location.find(val => val.value === userState.LocationID) }),
      dispatch({ type: strings.Employees.ClinicalUsers, data: employeeReducerState().clinicalUser.length > 0 && employeeReducerState().clinicalUser.find(val => val.value === 1) }),
      dispatch({ type: strings.Employees.Department, data: employeeReducerState().department.length > 0 && employeeReducerState().department.find(val => val.value === 0) }),
      dispatch({ type: strings.Employees.Type, data: employeeReducerState().employeeType.length > 0 && employeeReducerState().employeeType.find(val => val.employeeTypeId === 0) }),
      dispatch({ type: strings.Employees.Name, data: employeeReducerState().employeeName.length > 0 && employeeReducerState().employeeName.find(val => val.value === 0) }),
      dispatch({ type: strings.Employees.Designation, data: employeeReducerState().designation.length > 0 && employeeReducerState().designation.find(val => val.value === 0) })
    ]);
    await sessionStorage.setItem("staffFilterState", sessionStorage.getItem("staffModifyFilterState"));
    await reduxDispatch(employeeRequests.tableDatas());
    reduxDispatch(employeeRequests.loader(false));
  }

  const employeeNameOptn = () => {
    let filterData = [...employeeState.employeeName];
    if (state.locationId !== 0) {
      filterData = filterData.filter(val => (val.locationId === state.locationId || val.locationId === 0));
    }
    if (state.status !== "All") {
      if (state.status === "Active") {
        filterData = filterData.filter(val => ((val.employmentStatus !== "Relieved" && val.employmentStatus !== "") || val.employmentStatus === "All"));
      }
      else {
        filterData = filterData.filter(val => (val.employmentStatus === state.status || val.employmentStatus === "All"));
      }
    }
    return filterData;
  }

  return (
    <>
      <div className='mx-6 xsm:mb-2 lg:mb-0'>
        <SubHeaderSection subHeader="Employee Details" fileProps={{ columns: employeeDetails.columns(history), data: employeeState.tableRecords.map((val, idx) => ({ ...val, sno: idx + 1, doj: val.doj ? dateFormat(val.doj) : "", clinicalHandler: typeof (val.clinicalHandler) === "boolean" ? val.clinicalHandler ? "Yes" : "No" : "" })), docName: "Employee Details" }} />
        <div className='flex mb-6'>
          <div className='grid lg:grid-rows-2 md:grid-rows-3 sm:grid-rows-3 gap-x-4 gap-y-1 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-3 w-full'>
            <div><Dropdown value={state.location === "" ? null : { label: state.location, value: state.locationId }} onChange={(newValue) => userState.Role === strings.userRoles.humanResource || dispatch({ type: strings.Employees.Location, data: newValue })} options={employeeState.location} placeholder={strings.dropDowns.Employees.Location} isLabelView={true} isDisable={userState.Role === strings.userRoles.humanResource} /></div>
            <div><Dropdown value={state.department === "" ? null : { label: state.department, value: state.departmentId }} onChange={(newValue) => dispatch({ type: strings.Employees.Department, data: newValue })} options={employeeState.department} placeholder={strings.dropDowns.Employees.Section} isSearchable={true} isLabelView={true} /></div>
            <div><Dropdown value={state.status === "" ? null : { label: state.status, value: state.statusId }} onChange={(newValue) => dispatch({ type: strings.Employees.Status, data: newValue })} options={employeeState.employeeStatus} placeholder={strings.dropDowns.Employees.Status} isLabelView={true} /></div>
            <div><Dropdown value={state.type === "" ? null : { label: state.type, value: state.typeId }} onChange={(newValue) => dispatch({ type: strings.Employees.Type, data: newValue })} options={employeeState.employeeType} placeholder={strings.dropDowns.Employees.Type} isLabelView={true} /></div>
            <div><Dropdown value={state.clinicalUsersId === 0 ? null : { label: state.clinicalUsers, value: state.clinicalUsersId }} onChange={(newValue) => dispatch({ type: strings.Employees.ClinicalUsers, data: newValue })} options={employeeState.clinicalUser} placeholder={strings.dropDowns.Employees.ClinicalUsers} isLabelView={true} /></div>
            <div><Dropdown value={state.name === "" ? null : { label: state.name, value: state.nameId }} onChange={(newValue) => dispatch({ type: strings.Employees.Name, data: newValue })} options={employeeNameOptn()} placeholder={strings.dropDowns.Employees.Name} isSearchable={true} isLabelView={true} /></div>
            <div><Dropdown value={state.designation === "" ? null : { label: state.designation, value: state.designationId }} onChange={(newValue) => dispatch({ type: strings.Employees.Designation, data: newValue })} options={employeeState.designation} placeholder={strings.dropDowns.Employees.Designation} isSearchable={true} isLabelView={true} /></div>
            <div className=' self-end flex'><Button value={strings.Buttons.Search} onClick={onClick} /> <span className=' mx-3'> <Button value={strings.Buttons.Reset} onClick={() => onReset()} /></span></div>
          </div>
        </div>
        <AgGrid data={employeeState.tableRecords} columns={employeeDetails.columns(history, loginResponseState.isMobileCompatible)} ContextMenuItems={loginResponseState.isMobileCompatible ? false : employeeDetails.ContextMenuItems} history={history} height="h-[calc(94vh-67px-67px-1.5rem-3.5rem-2rem-0.6rem)] lg:h-[calc(94vh-67px-67px-1.5rem-3.5rem-2rem-0.6rem)] md:h-[calc(94vh-67px-67px-67px-1.5rem-3.5rem-2rem-0.6rem)] xsm:h-[62vh]" isSetFilter={true} />
      </div>
      {employeeState.loader && <TransparentLoader />}
      {loginResponseState.apiResponse.show && <ApiResponse />}
      {employeeState.employeeDetailView.show && <EmployeeDetailView />}
    </>
  )
}

export default Staff;

const reducer = (state, action) => {
  setSessionStorage(action, state);
  if (action.type === strings.Buttons.Reset) {
    return { ...staffInitialState };
  }
  else if (action.type && action.data) {
    let stateData = { ...state };
    if (action.type === strings.Employees.Location && state.name !== "") {
      const data = employeeReducerState().employeeName.find(val => val.value === state.nameId && (val.locationId !== action.data.value && action.data.value !== 0));
      if (data && Object.keys(data).length > 0) {
        stateData = { ...stateData, [strings.Employees.Name]: setDefaultValue.employeeName.label, [`${strings.Employees.Name}Id`]: setDefaultValue.employeeName.value };
      }
    }
    if (action.type === strings.Employees.Location && state.department !== "" && action.data.value > 0 && state.departmentId > 0) {
      const data = employeeReducerState().department.find(val => val.value === state.departmentId && !val.locationId.includes(action.data.value));
      if (data && Object.keys(data).length > 0) {
        stateData = { ...stateData, [strings.Employees.Department]: setDefaultValue.department.label, [`${strings.Employees.Department}Id`]: setDefaultValue.department.value }
      }
    }
    if (action.type === strings.Employees.Status && state.name !== "") {
      const data = employeeReducerState().employeeName.find(val => val.value === state.nameId && (val.employmentStatus !== action.data.label && action.data.label !== "All"));
      if (data && Object.keys(data).length > 0) {
        stateData = { ...stateData, [strings.Employees.Name]: setDefaultValue.employeeName.label, [`${strings.Employees.Name}Id`]: setDefaultValue.employeeName.value };
      }
    }
    return { ...stateData, [action.type]: action.data.label, [`${action.type}Id`]: action.data.value };
  }
  else {
    return { ...state };
  }
};


const setSessionStorage = (action, state) => {
  let employeeState = JSON.parse(sessionStorage.getItem("staffModifyFilterState"));
  if (action?.data) {
    switch (action.type) {
      case strings.Employees.ClinicalUsers:
        employeeState = { ...employeeState, clinicalHandler: action.data.label }
        break;
      case strings.Employees.Department:
        employeeState = { ...employeeState, departmentId: action.data.value }
        break;
      case strings.Employees.Designation:
        employeeState = { ...employeeState, designationId: action.data.value }
        break;
      case strings.Employees.Name:
        employeeState = { ...employeeState, employeeId: action.data.value }
        break;
      case strings.Employees.Status:
        if (state.name !== "") {
          const data = employeeReducerState().employeeName.find(val => val.value === state.nameId && (val.employmentStatus !== action.data.label && action.data.label !== "All"));
          if (data && Object.keys(data).length > 0) {
            employeeState = { ...employeeState, employeeId: 0 }
          }
        }
        employeeState = { ...employeeState, employeeStatus: action.data.label }
        break;
      case strings.Employees.Type:
        employeeState = { ...employeeState, employeeType: action.data.label }
        break;
      case strings.Employees.Location:
        if (state.name !== "") {
          let data = employeeReducerState().employeeName.find(val => val.value === state.nameId && (val.locationId !== action.data.value && action.data.value !== 0));
          if (data && Object.keys(data).length > 0) {
            employeeState = { ...employeeState, employeeId: 0 }
          }
        }
        if (state.Department !== "" && action?.data?.value > 0 && state.departmentId > 0) {
          let data = employeeReducerState().department.find(val => val.value === state.departmentId && !val.locationId.includes(action.data.value));
          if (data && Object.keys(data).length > 0) {
            employeeState = { ...employeeState, departmentId: 0 }
          }
        }
        employeeState = { ...employeeState, locationId: action.data?.value }
        break;
      case strings.Buttons.Reset:
        return employeeState;
      default:
        console.error("Type Mismatch Error");
    }
  }
  sessionStorage.setItem("staffModifyFilterState", JSON.stringify(employeeState));
}
