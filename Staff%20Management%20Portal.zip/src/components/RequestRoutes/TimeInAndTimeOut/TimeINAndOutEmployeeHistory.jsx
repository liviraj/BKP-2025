import { useDispatch, useSelector } from "react-redux";
import ApiResponse from "../../Alert/ApiResponse";
import { setDefaultValue, strings } from "../../Constants";
import Button from "../../elements/Button";
import DatePickerElement from "../../elements/DatePickerElement";
import Dropdown from "../../elements/Dropdown";
import AgGrid from "../../Grid/AgGrid";
import HeaderSection from "../../layouts/HeaderSection";
import TransparentLoader from "../../loader/TransparentLoader";
import { useForm } from "react-hook-form";
import { useEffect, useState } from "react";
import { employeeRequests, leaveManagementRequest, timeInTimeOutRequest } from "../../requests";
import { dayWithDateFormat, exportDateFormat, periodDateFormat, periodOptions, userReducerState } from "../../helper";
import { timeInAndTimeOut } from "../../Grid/Columns";
import EditTimeINTimeOutPopup from "../../Popup_window/EditTimeINTimeOutPopup";
import AddButton from "../../elements/AddButton";
import { timeInTimeOutActions } from "../../../redux/TimeInTimeOutReducer";
import AddTimeINTimeOutPopup from "../../Popup_window/AddTimeInTimeOutPopup";
import TimeInOutUploadDocumentPopup from "../../Popup_window/TimeInOutUploadDocumentPopup";
import SubHeaderSection from "../../layouts/SubHeaderSection";
import { TbUpload } from "react-icons/tb";

const TimeINAndOutEmployeeHistory = () => {
    const dispatch = useDispatch();
    const leaveManagementState = useSelector(state => state.leaveManagement);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const employeeState = useSelector(state => state.employee);
    const timeInTimeOutState = useSelector(state => state.timeInTimeOut);

    const { watch, setValue, getValues } = useForm({ defaultValues: initialState });
    const [loader, setLoader] = useState(false);
    const [data, setData] = useState([]);
    const [pinnedData, setPinnedData] = useState([]);

    useEffect(() => {
        const initialLoad = async () => {
            setLoader(true);
            Object.keys(leaveManagementState.payroll).length <= 0 && await dispatch(leaveManagementRequest.getPayroll());
            employeeState.employeeName.length <= 0 && await dispatch(employeeRequests.employeeName());
            await handleReset();
            setLoader(false);
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        setValue(strings.timeInOutEmployeeHistory.employeeNameOptions, filterEmployeeName(employeeState.employeeName ? employeeState.employeeName : []));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [employeeState.employeeName]);

    const filterEmployeeName = (employeeName) => {
        const location = setDefaultValue.usLocation
        if (userReducerState().Role === strings.userRoles.superVisor && employeeName.length > 0 && location) {
            return employeeName.filter((val) =>
                (val.locationId === 0) ||
                ((val.employmentStatus === 'All' || val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation) &&
                    val.supervisorId === userReducerState().UserID) ||
                (location.value === 0)
            );
        }
        else if (employeeName.length > 0 && location) {
            return employeeName.filter((val) =>
                ((val.locationId === location.value || val.locationId === 0) &&
                    (val.employmentStatus === 'All' || val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation)) ||
                (location.value === 0)
            );
        }
        return [];
    }

    const onPeriodChange = (value) => {
        setValue(strings.timeInOutEmployeeHistory.period, value);
        periodDateFormat(value, setValue);
    }

    const handleSearch = async () => {
        setLoader(true);
        const values = getValues();
        let params = {
            employeeId: values?.employeeName ? values.employeeName.value : 0,
            fromDate: values?.fromDate ? exportDateFormat(values.fromDate, true) : '',
            toDate: values?.toDate ? exportDateFormat(values.toDate, true) : ''
        }
        await dispatch(timeInTimeOutRequest.timeIntimeOutHistoryRequest(params, setcallBack));
        setLoader(false);
    }

    const handleReset = async () => {
        setLoader(true);
        onPeriodChange(periodOptions[3]);
        setValue(strings.leaveRequestQueue.employeeName, setDefaultValue.employeeName);
        await handleSearch();
        setLoader(false);
    }

    const setcallBack = async (data) => {
        if (data && 'History' in data) { setData(data.History); }
        if ('TotalHours' in data && data.TotalHours.length > 0) setPinnedData([{ timeIn1: 'Total', totalHoursCalculation: data.TotalHours[0].totalHoursCalculation, workhours: data.TotalHours[0].workhours }]);
    }

    return (
        <>
            <HeaderSection redirectType={strings.type.timeInTimeOut} />
            <div className=" px-6 mb-5 overflow-hidden">
                <SubHeaderSection subHeader={"Time In / Out Employee Records"} fileProps={{ columns: timeInAndTimeOut.timeInAndTimeOutEmployeeHistory.column(), data: data?.map((val, idx) => ({ ...val, sno: idx + 1, workDate: dayWithDateFormat(val.workDate, true) })), docName: "Time In And Time Out Employee Records", isPortraitView: true }} />
                <div className='grid grid-rows-1 md:grid-rows-1 sm:grid-rows-2 xsm:grid-rows-3 gap-x-4 gap-y-1 xl:grid-cols-5 lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 w-full mb-6'>
                    <div><Dropdown placeholder={"Period"} options={periodOptions.filter(val => [2, 11, 0, 12].includes(val.value))} value={watch(strings.timeInOutEmployeeHistory.period)} onChange={e => onPeriodChange(e)} isLabelView={true} /></div>
                    <div><DatePickerElement placeholder='From' disabled={watch(strings.timeInOutEmployeeHistory.period).label !== strings.filterPeriod.custom} value={watch(strings.timeInOutEmployeeHistory.fromDate) ? watch(strings.timeInOutEmployeeHistory.fromDate) : ""} onChange={date => setValue(strings.timeInOutEmployeeHistory.fromDate, date)} isRequired={true} isLabelView={true} /></div>
                    <div><DatePickerElement placeholder='To' disabled={watch(strings.timeInOutEmployeeHistory.period).label !== strings.filterPeriod.custom} value={watch(strings.timeInOutEmployeeHistory.toDate) ? watch(strings.timeInOutEmployeeHistory.toDate) : ""} minDate={watch(strings.timeInOutEmployeeHistory.period).label === strings.filterPeriod.custom && watch(strings.timeInOutEmployeeHistory.fromDate)} onChange={date => setValue(strings.timeInOutEmployeeHistory.toDate, date)} isRequired={true} isLabelView={true} /></div>
                    <div><Dropdown placeholder={"Employee Name"} value={watch(strings.timeInOutEmployeeHistory.employeeName)} options={watch(strings.timeInOutEmployeeHistory.employeeNameOptions)} onChange={e => setValue(strings.timeInOutEmployeeHistory.employeeName, e)} isSearchable={true} isLabelView={true} /></div>
                    <div className=' self-end flex'>
                        <Button value={strings.Buttons.Search} onClick={handleSearch} disabled={watch(strings.timeInOutEmployeeHistory.period).label === strings.filterPeriod.custom && (!watch(strings.timeInOutEmployeeHistory.fromDate) || !watch(strings.timeInOutEmployeeHistory.toDate))} />
                        <span className=' mx-3'> <Button value={strings.Buttons.Reset} onClick={handleReset} /></span>
                    </div>
                </div>
                <div className=" bottomPinned_grid"> <AgGrid data={data} columns={timeInAndTimeOut.timeInAndTimeOutEmployeeHistory.column()} pinnedBottomRowData={pinnedData} ContextMenuItems={timeInAndTimeOut.timeInAndTimeOutEmployeeHistory.contextMenuItems} height="h-[calc(94vh-14rem-67px)] xl:h-[calc(94vh-14.1rem-67px)] lg:h-[calc(94vh-17.3rem-67px)] md:h-[calc(94vh-18.5rem-67px)] xsm:h-[50vh]" isAutoHeight /> </div>
                <div className=" flex mt-3 font-fontfamily text-14px font-bold gap-3">
                    <div className=" flex flex-row items-center" >
                        <AddButton value={'Add Time In / Out'} onClick={() => { dispatch(timeInTimeOutActions.addTimeInTimeOutPopup({ show: true, action: "Add" })); }} />
                    </div>
                    <div className=" flex flex-row items-center" >
                        <AddButton value={'Upload Document'} onClick={() => dispatch(timeInTimeOutActions.setTimeInOutUploadDocument({ show: true }))} icon={<TbUpload size={16} className=" stroke-[2.5px]" />} />
                    </div>
                </div>
            </div>
            {loader && <TransparentLoader />}
            {timeInTimeOutState.timeInTimeOutPopup.show && <EditTimeINTimeOutPopup handleRefresh={handleSearch} />}
            {timeInTimeOutState.addTimeInTimeOutPopup.show && <AddTimeINTimeOutPopup handleRefresh={handleSearch} />}
            {!timeInTimeOutState.timeInTimeOutPopup.show && apiResponseState.show && <ApiResponse />}
            {timeInTimeOutState.timeInOutUploadDocument.show && <TimeInOutUploadDocumentPopup />}
        </>
    );
};

const initialState = {
    period: '',
    fromDate: '',
    toDate: '',
    employeeName: '',
    employeeNameOptions: [],
}

export default TimeINAndOutEmployeeHistory;