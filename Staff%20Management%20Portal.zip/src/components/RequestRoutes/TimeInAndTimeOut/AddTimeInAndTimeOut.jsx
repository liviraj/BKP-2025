import { useEffect, useMemo, useState } from "react"
import { strings } from "../../Constants"
import HeaderSection from "../../layouts/HeaderSection"
import Label from "../../elements/Label";
import Button from "../../elements/Button";
import TransparentLoader from "../../loader/TransparentLoader";
import { dateFormat, exportDateFormat, exportYearFormat, getLeaveDetails, holidayReducerState } from "../../helper";
import { useDispatch, useSelector } from "react-redux";
import ApiResponse from "../../Alert/ApiResponse";
import { timeInTimeOutRequest } from "../../requests";
import DatePickerElement from "../../elements/DatePickerElement";
import moment from "moment";
import { useForm } from "react-hook-form";
import { BsFillCheckCircleFill } from "react-icons/bs";
import { useHistory } from "react-router-dom/cjs/react-router-dom.min";



function AddTimeInAndTimeOut() {

    const dispatch = useDispatch();
    const userState = useSelector(state => state.user);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const history = useHistory();

    const [loader, setLoader] = useState(false);
    const [successMessage, setSuccessMessage] = useState("");
    const { watch, setValue, reset, getValues } = useForm({ defaultValues: initialValue });
    const data = watch(strings.timeInTimeOutRequest.data);
    const userRecords = watch(strings.timeInTimeOutRequest.userRecords);
    const date = watch(strings.timeInTimeOutRequest.date);

    const handleResetData = async () => {
        setLoader(true);
        reset();
        await handleReloadRequest();
        setSuccessMessage("");
        setLoader(false);
    }

    const handleReloadRequest = async () => {
        setLoader(true);
        const data = getValues();
        const params = {
            employeeId: userState.UserID,
            fromDate: exportDateFormat(data.date, true),
            toDate: exportDateFormat(data.date, true)
        }
        await dispatch(timeInTimeOutRequest.timeIntimeOutHistoryRequest(params, async (responseData) => {
            await setValue(strings.timeInTimeOutRequest.userRecords, responseData && ("History" in responseData) && responseData?.History?.length > 0 ? responseData?.History[0] : {});
        }));
        setLoader(false);
    }

    useEffect(() => {
        let tempData = [...data];
        if (userRecords && Object.keys(userRecords).length > 0) {
            const recordsUpdate = (idx, value, validKey) => {
                const validDateAndTime = new Date(`${dateFormat(date)} ${value}`);

                tempData[idx].isLabelView = true;
                tempData[idx].value = validDateAndTime;

                if (validKey && [validKey] in userRecords && !userRecords[validKey]) {
                    const numFormat = Number(idx) + 1;
                    tempData[numFormat].minTime = moment(date).set({ hours: moment(validDateAndTime).get("hours"), minutes: moment(validDateAndTime).get("minutes") + 1, seconds: 0, milliseconds: 0 });
                    tempData = tempData.map((val, index) => {
                        return { ...val, isLabelView: !!(index !== (numFormat)) };
                    });
                    setValue(strings.timeInTimeOutRequest.data, tempData);
                    return true;
                }

                return false;
            }

            if ("timeIn1" in userRecords) {
                if (userRecords.timeIn1) {
                    const isReturnValue = recordsUpdate(0, userRecords.timeIn1, "timeOut1");
                    if (isReturnValue) {
                        return;
                    }
                } else {
                    tempData = tempData.map((val, index) => {
                        return { ...val, isLabelView: !!(index !== 0) };
                    });
                    setValue(strings.timeInTimeOutRequest.data, tempData);
                }
            }
            if ("timeOut1" in userRecords && userRecords.timeOut1) {
                const isReturnValue = recordsUpdate(1, userRecords.timeOut1, "timeIn2");
                if (isReturnValue) {
                    return;
                }
            }
            if ("timeIn2" in userRecords && userRecords.timeIn2) {
                const isReturnValue = recordsUpdate(2, userRecords.timeIn2, "timeOut2");
                if (isReturnValue) {
                    return;
                }
            }
            if ("timeOut2" in userRecords && userRecords.timeOut2) {
                const isReturnValue = recordsUpdate(3, userRecords.timeOut2, "timeIn3");
                if (isReturnValue) {
                    return;
                }
            }
            if ("timeIn3" in userRecords && userRecords.timeIn3) {
                const isReturnValue = recordsUpdate(4, userRecords.timeIn3, "timeOut3");
                if (isReturnValue) {
                    return;
                }
            }
            if ("timeOut3" in userRecords && userRecords.timeOut3) {
                const isReturnValue = recordsUpdate(5, userRecords.timeOut3, "timeIn4");
                if (isReturnValue) {
                    return;
                }
            }
            if ("timeIn4" in userRecords && userRecords.timeIn4) {
                const isReturnValue = recordsUpdate(6, userRecords.timeIn4, "timeOut4");
                if (isReturnValue) {
                    return;
                }
            }
            if ("timeOut4" in userRecords && userRecords.timeOut4) {
                const isReturnValue = recordsUpdate(7, userRecords.timeOut4, "");
                if (isReturnValue) {
                    return;
                }
            }
            setValue(strings.timeInTimeOutRequest.data, tempData);

        } else {
            tempData = tempData.map((val, index) => {
                return { ...val, isLabelView: !!(index !== 0) };
            });
            setValue(strings.timeInTimeOutRequest.data, tempData);
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [userRecords]);

    useEffect(() => {
        const initialLoad = async () => {
            setLoader(true);
            await Promise.all([
                holidayReducerState().holidays.length <= 0 && getLeaveDetails(new Date()),
            ]);
            await handleResetData();
            setLoader(false);
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const handleSumbit = async () => {
        setLoader(true);
        const data = getValues();
        const validRecord = data.data.find(val => !val.isLabelView && val.value);
        if (validRecord) {
            const timeValue = moment(validRecord.value);
            const payload = [{
                createdBy: userState.UserID,
                createdOn: exportDateFormat(new Date()),
                employeeId: userState.UserID,
                logId: Object.keys(userRecords).length > 0 ? userRecords?.logId : 0,
                logTime: exportDateFormat(moment(data.date).set({ hours: timeValue.hours(), minutes: timeValue.minutes() }), false, true),
                logType: validRecord.type,
                workDate: exportDateFormat(data.date, true)
            }]
            await dispatch(timeInTimeOutRequest.addTimeInTimeOutRequest(payload, async () => {
                await handleReloadRequest();
                setSuccessMessage(`Time ${validRecord.type} (${timeValue.format("hh:mm A")}) Saved Successfully`);
            }));
        }
        setLoader(false);
    }

    const handleUpdateData = (index, value) => {
        let tempData = [...data];
        tempData[index].value = value || "";
        setValue(strings.timeInTimeOutRequest.data, tempData);
    }

    const handleDateChange = async (updatedDate) => {
        setLoader(true);
        await setValue(strings.timeInTimeOutRequest.date, updatedDate);
        await setValue(strings.timeInTimeOutRequest.data, timeInTimeOutFormat);
        setSuccessMessage("");
        await handleReloadRequest();
    }

    const lastWorkingdateValidation = useMemo(() => {
        const disableHolidays = holidayReducerState().holidays;
        if (disableHolidays && disableHolidays.length > 0) {
            const getDates = disableHolidays.find(val => val.year === exportYearFormat(date));
            if (getDates && ("holidayDates" in getDates) && getDates.holidayDates.length > 0) {
                let isLastWorkingDate = true;
                let lastDate = moment(date).subtract(1, "day");
                do {
                    const day = moment(lastDate).get("day");
                    if (day !== 0 && day !== 6 && !getDates.holidayDates.includes(dateFormat(lastDate))) {
                        isLastWorkingDate = false;
                        break;
                    } else {
                        lastDate = moment(lastDate).subtract(1, "day");
                    }
                } while (isLastWorkingDate);
                return lastDate;
            }
        }
        return moment().subtract(1, "day");
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [holidayReducerState().holidays]);

    const isDisableSaveFunctionality = useMemo(() => {
        if (userRecords && Object.keys(userRecords).length > 0) {
            if ("timeIn1" in userRecords && !userRecords.timeIn1 && data[0].value) {
                return false;
            } else if ("timeOut1" in userRecords && !userRecords.timeOut1 && data[1].value) {
                return false;
            } else if ("timeIn2" in userRecords && !userRecords.timeIn2 && data[2].value) {
                return false;
            } else if ("timeOut2" in userRecords && !userRecords.timeOut2 && data[3].value) {
                return false;
            } else if ("timeIn3" in userRecords && !userRecords.timeIn3 && data[4].value) {
                return false;
            } else if ("timeOut3" in userRecords && !userRecords.timeOut3 && data[5].value) {
                return false;
            } else if ("timeIn4" in userRecords && !userRecords.timeIn4 && data[6].value) {
                return false;
            } else if ("timeOut4" in userRecords && !userRecords.timeOut4 && data[7].value) {
                return false;
            }
        } else if (data[0].value) {
            return false;
        }
        return true;
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [userRecords, data]);

    useEffect(() => {
        const unblock = history.block(() => {
            if (!isDisableSaveFunctionality) {
                return window.confirm("Changes you made may not be saved.");
            }
            return true;
        });

        return () => {
            unblock();
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isDisableSaveFunctionality]);

    return (
        <>
            <HeaderSection redirectType={strings.type.timeInTimeOut} />
            <div className=" overflow-hidden h-auto md:max-h-h_body_md sm:max-h-full ">
                <div className=" px-6">
                    <div className=" grid grid-cols-12 items-center sm:gap-y-8 mt-8 sm:w-[25rem]" >
                        <div className=" col-start-1 sm:col-end-5 xsm:col-end-12"><Label label={`Date`} required /></div>
                        <div className=" sm:col-start-5 xsm:col-start-1 col-end-12"> <DatePickerElement isRequired value={date} onChange={handleDateChange} disableHolidays={holidayReducerState().holidays} minDate={lastWorkingdateValidation} maxDate={new Date()} isDisableSunday /></div>
                    </div>
                    <div className=" grid xl:grid-cols-8 lg:grid-cols-4 sm:grid-cols-2 my-4 border-collapse border border-r-0 border-darkDarkGrey border-solid text-14px">
                        {
                            data?.map((val, idx) =>
                                <div key={val.id} className={`flex flex-col border-r-1 border-darkDarkGrey border-solid divide-y-1 divide-darkDarkGrey border-collapse ${val.addStyle}`}>
                                    <span className=" px-2 py-1"><Label label={val.label} setBold addStyle={"!text-center"} isDisable={val.isLabelView} /></span>
                                    <span className=" px-2 xl:py-1 xsm:py-2"><DatePickerElement isRequired value={val.value} onChange={date => handleUpdateData(idx, date)} showTimeSelect minTime={val.minTime || moment().set({ hours: 0, minutes: 0, seconds: 0 })} maxTime={moment().set({ hours: 23, minutes: 59, seconds: 0 })} setTimeInterval={1} disabled={val.isLabelView} isRemovable /></span>
                                </div>)
                        }
                    </div>
                    <div className=" flex justify-center items-center my-6 gap-4">
                        <Button value={strings.Buttons.Save} disabled={isDisableSaveFunctionality} onClick={handleSumbit} />
                        <Button value={strings.Buttons.Reset} onClick={handleResetData} />
                    </div>
                </div>
                {successMessage && <div className=" flex justify-center items-center mt-16 text-greenColor font-medium text-14px p-2 text-center gap-2 leading-3"><BsFillCheckCircleFill size={18} />{successMessage}</div>}
            </div>
            {loader && <TransparentLoader />}
            {apiResponseState.show && <ApiResponse />}
        </>
    )
}

export default AddTimeInAndTimeOut;

const timeInTimeOutFormat = [
    {
        label: "IN",
        value: "",
        addStyle: "",
        isLabelView: false,
        minTime: "",
        type: "In",
        id: "In1"
    },
    {
        label: "OUT",
        value: "",
        addStyle: "sm:border-t-0 xsm:border-t-1",
        isLabelView: true,
        minTime: "",
        type: "Out",
        id: "out1"
    },
    {
        label: "IN",
        value: "",
        addStyle: "lg:border-t-0 xsm:border-t-1",
        isLabelView: true,
        minTime: "",
        type: "In",
        id: "In2"
    },
    {
        label: "OUT",
        value: "",
        addStyle: "lg:border-t-0 xsm:border-t-1",
        isLabelView: true,
        minTime: "",
        type: "Out",
        id: "out2"
    },
    {
        label: "IN",
        value: "",
        addStyle: "xl:border-t-0 xsm:border-t-1",
        isLabelView: true,
        minTime: "",
        type: "In",
        id: "In3"
    },
    {
        label: "OUT",
        value: "",
        addStyle: "xl:border-t-0 xsm:border-t-1",
        isLabelView: true,
        minTime: "",
        type: "Out",
        id: "out3"
    },
    {
        label: "IN",
        value: "",
        addStyle: "xl:border-t-0 xsm:border-t-1",
        isLabelView: true,
        minTime: "",
        type: "In",
        id: "In4"
    },
    {
        label: "OUT",
        value: "",
        addStyle: "xl:border-t-0 xsm:border-t-1",
        isLabelView: true,
        minTime: "",
        type: "Out",
        id: "out4"
    },
];

const initialValue = {
    data: timeInTimeOutFormat,
    date: new Date(),
    userRecords: {}
}

