import { useDispatch, useSelector } from "react-redux";
import HeaderSection from "../../layouts/HeaderSection";
import { useForm } from "react-hook-form";
import { useEffect, useState } from "react";
import { employeeRequests, leaveManagementRequest, timeInTimeOutRequest } from "../../requests";
import { setDefaultValue, strings } from "../../Constants";
import { exportDateFormat, periodDateFormat, periodOptions, userReducerState } from "../../helper";
import Dropdown from "../../elements/Dropdown";
import DatePickerElement from "../../elements/DatePickerElement";
import AgGrid from "../../Grid/AgGrid";
import { timeInAndTimeOut } from "../../Grid/Columns";
import TransparentLoader from "../../loader/TransparentLoader";
import ApiResponse from "../../Alert/ApiResponse";
import Button from "../../elements/Button";
import SubHeaderSection from "../../layouts/SubHeaderSection";
import ViewMissOutPunches from "../../Popup_window/ViewMissOutPunches";


const TimeInTimeOutSummary = () => {
    const dispatch = useDispatch();
    const leaveManagementState = useSelector(state => state.leaveManagement);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const employeeState = useSelector(state => state.employee);
    const timeInTimeOutState = useSelector(state => state.timeInTimeOut);

    const { watch, setValue, getValues } = useForm({ defaultValues: initialState });
    const [loader, setLoader] = useState(false);
    const [data, setData] = useState([]);

    useEffect(() => {
        const initialLoad = async () => {
            await setLoader(true);
            Object.keys(leaveManagementState.payroll).length <= 0 && await dispatch(leaveManagementRequest.getPayroll());
            employeeState.employeeName.length <= 0 && await dispatch(employeeRequests.employeeName());
            await handleReset();
            setLoader(false);
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        setValue(strings.timeInOutSummary.employeeNameOptions, filterEmployeeName(employeeState.employeeName ? employeeState.employeeName : []));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [employeeState.employeeName]);

    const filterEmployeeName = (employeeName) => {
        const location = setDefaultValue.usLocation
        if (userReducerState().Role === strings.userRoles.superVisor && employeeName.length > 0 && location) {
            return employeeName.filter((val) =>
                (val.locationId === 0) ||
                ((val.employmentStatus === 'All' || val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation) &&
                    val.supervisorId === userReducerState().UserID) ||
                (location.value === 0)
            );
        }
        else if (employeeName.length > 0 && location) {
            return employeeName.filter((val) =>
                ((val.locationId === location.value || val.locationId === 0) &&
                    (val.employmentStatus === 'All' || val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation)) ||
                (location.value === 0)
            );
        }
        return [];
    }

    const onPeriodChange = (value) => {
        setValue(strings.timeInOutSummary.period, value);
        periodDateFormat(value, setValue);
    }

    const handleSearch = async () => {
        await setLoader(true);
        const values = getValues();
        let params = {
            employeeId: values?.employeeName ? values.employeeName.value : 0,
            fromDate: values?.fromDate ? exportDateFormat(values.fromDate, true) : '',
            toDate: values?.toDate ? exportDateFormat(values.toDate, true) : ''
        }
        await dispatch(timeInTimeOutRequest.getTimeInTimeOutSummaryRequest(params, setcallBack));
        setLoader(false);
    }

    const handleReset = async () => {
        await setLoader(true);
        await onPeriodChange(periodOptions[3]);
        await setValue(strings.leaveRequestQueue.employeeName, setDefaultValue.employeeName);
        await handleSearch();
        setLoader(false);
    }
    const setcallBack = async (data) => {
        await setData(data);
    }

    const setRowStyle = params => {
        return { backgroundColor: ("remarks" in params.data) && params.data?.remarks?.length > 0 ? "#ffe9df" : '#ffff' }
    };

    return (
        <>
            <HeaderSection redirectType={strings.type.timeInTimeOut} />
            <div className=" px-6 mb-5 overflow-hidden">
                <SubHeaderSection subHeader={`Time In / Out Summary`} fileProps={{ columns: timeInAndTimeOut.timeInAndTimeOutSummary.column(), data: data.map((val, idx) => ({ ...val, sno: idx + 1 })), docName: "Time In And Time Out Summary" }} />
                <div className='grid grid-rows-1 md:grid-rows-1 sm:grid-rows-2 xsm:grid-rows-3 gap-x-4 gap-y-1 xl:grid-cols-5 lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 w-full mb-6'>
                    <div><Dropdown placeholder={"Period"} options={periodOptions.filter(val => [2, 11, 0, 12].includes(val.value))} value={watch(strings.timeInOutSummary.period)} onChange={e => onPeriodChange(e)} isLabelView={true} /></div>
                    <div><DatePickerElement placeholder='From' disabled={watch(strings.timeInOutSummary.period).label !== strings.filterPeriod.custom} value={watch(strings.timeInOutSummary.fromDate) ? watch(strings.timeInOutSummary.fromDate) : ""} onChange={date => setValue(strings.timeInOutSummary.fromDate, date)} isRequired={true} isLabelView={true} /></div>
                    <div><DatePickerElement placeholder='To' disabled={watch(strings.timeInOutSummary.period).label !== strings.filterPeriod.custom} value={watch(strings.timeInOutSummary.toDate) ? watch(strings.timeInOutSummary.toDate) : ""} minDate={watch(strings.timeInOutSummary.period).label === strings.filterPeriod.custom && watch(strings.timeInOutSummary.fromDate)} onChange={date => setValue(strings.timeInOutSummary.toDate, date)} isRequired={true} isLabelView={true} /></div>
                    <div><Dropdown placeholder={"Employee Name"} value={watch(strings.timeInOutSummary.employeeName)} options={watch(strings.timeInOutSummary.employeeNameOptions)} onChange={e => setValue(strings.timeInOutSummary.employeeName, e)} isSearchable={true} isLabelView={true} /></div>
                    <div className=' self-end flex'>
                        <Button value={strings.Buttons.Search} onClick={handleSearch} disabled={watch(strings.timeInOutSummary.period).label === strings.filterPeriod.custom && (!watch(strings.timeInOutSummary.fromDate) || !watch(strings.timeInOutSummary.toDate))} />
                        <span className=' mx-3'> <Button value={strings.Buttons.Reset} onClick={handleReset} /></span>
                    </div>
                </div>
                <div className=" bottomPinned_grid"> <AgGrid data={data} columns={timeInAndTimeOut.timeInAndTimeOutSummary.column(setLoader)} height="h-[calc(94vh-15rem)] xl:h-[calc(94vh-15.3rem)] lg:h-[calc(94vh-18.6rem)] md:h-[calc(94vh-19.7rem)] xsm:h-[50vh]" isSetFilter={true} rowStyle={setRowStyle} /> </div>
            </div>
            {loader && <TransparentLoader />}
            {apiResponseState.show && <ApiResponse />}
            {timeInTimeOutState.viewMissOutPunches.show && <ViewMissOutPunches />}
        </>
    );
};

const initialState = {
    period: '',
    fromDate: '',
    toDate: '',
    employeeName: '',
    employeeNameOptions: [],
}

export default TimeInTimeOutSummary;