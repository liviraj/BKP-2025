import { useForm } from "react-hook-form";
import { strings } from "../../Constants";
import HeaderSection from "../../layouts/HeaderSection";
import DatePickerElement from "../../elements/DatePickerElement";
import Dropdown from "../../elements/Dropdown";
import { exportDateFormat, periodDateFormat, periodOptions } from "../../helper";
import AgGrid from "../../Grid/AgGrid";
import { timeInAndTimeOut } from "../../Grid/Columns";
import Button from "../../elements/Button";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { leaveManagementRequest, timeInTimeOutRequest } from "../../requests";
import TransparentLoader from "../../loader/TransparentLoader";
import ApiResponse from "../../Alert/ApiResponse";

const TimeInAndTimeOutHistory = () => {
    const dispatch = useDispatch()
    const leaveManagementState = useSelector(state => state.leaveManagement);
    const userState = useSelector(state => state.user);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);

    const { watch, setValue, getValues } = useForm({ defaultValues: initialState });
    const [loader, setLoader] = useState(false);
    const [data, setData] = useState([]);
    const [pinnedData, setPinnedData] = useState([]);

    useEffect(() => {
        const initialLoad = async () => {
            await setLoader(true);
            Object.keys(leaveManagementState.payroll).length <= 0 && await dispatch(leaveManagementRequest.getPayroll());
            await handleReset();
            setLoader(false);
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const onPeriodChange = (value) => {
        setValue(strings.timeInOutHistory.period, value);
        periodDateFormat(value, setValue);
    }

    const handleSearch = async () => {
        await setLoader(true);
        const values = getValues();
        let params = {
            employeeId: userState.UserID,
            fromDate: values?.fromDate ? exportDateFormat(values.fromDate, true) : '',
            toDate: values?.toDate ? exportDateFormat(values.toDate, true) : ''
        }
        await dispatch(timeInTimeOutRequest.timeIntimeOutHistoryRequest(params, setcallBack));
        setLoader(false);
    }

    const handleReset = async () => {
        await setLoader(true);
        await onPeriodChange(periodOptions[3]);
        await handleSearch();
        setLoader(false);
    }
    const setcallBack = async (data) => {
        if (data) {
            if ('History' in data) await setData([...data.History]);
            if ('TotalHours' in data && data.TotalHours.length > 0) await setPinnedData([{ timeIn1: 'Total', totalHoursCalculation: data.TotalHours[0].totalHoursCalculation, workhours: data.TotalHours[0].workhours }]);
        }
    }
    return (
        <>
            <HeaderSection redirectType={strings.type.timeInTimeOut} />
            <div className=" px-6 mb-5">
                <div className='grid grid-rows-1 md:grid-rows-1 sm:grid-rows-2 xsm:grid-rows-3 gap-x-4 gap-y-1 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-2 w-full mb-6'>
                    <div><Dropdown placeholder={"Period"} options={periodOptions.filter(val => [2, 11, 0, 12].includes(val.value))} value={watch(strings.timeInOutHistory.period)} onChange={e => onPeriodChange(e)} isLabelView={true} /></div>
                    <div><DatePickerElement placeholder='From' disabled={watch(strings.timeInOutHistory.period).label !== strings.filterPeriod.custom} value={watch(strings.timeInOutHistory.fromDate) ? watch(strings.timeInOutHistory.fromDate) : ""} onChange={date => setValue(strings.timeInOutHistory.fromDate, date)} isRequired={true} isLabelView={true} /></div>
                    <div><DatePickerElement placeholder='To' disabled={watch(strings.timeInOutHistory.period).label !== strings.filterPeriod.custom} value={watch(strings.timeInOutHistory.toDate) ? watch(strings.timeInOutHistory.toDate) : ""} minDate={watch(strings.timeInOutHistory.period).label === strings.filterPeriod.custom && watch(strings.timeInOutHistory.fromDate)} onChange={date => setValue(strings.timeInOutHistory.toDate, date)} isRequired={true} isLabelView={true} /></div>
                    <div className=' self-end flex'>
                        <Button value={strings.Buttons.Search} onClick={handleSearch} disabled={watch(strings.timeInOutHistory.period).label === strings.filterPeriod.custom && (!watch(strings.timeInOutHistory.fromDate) || !watch(strings.timeInOutHistory.toDate))} />
                        <span className=' mx-3'> <Button value={strings.Buttons.Reset} onClick={handleReset} /></span>
                    </div>
                </div>
                <div className=" bottomPinned_grid"> <AgGrid data={data} columns={timeInAndTimeOut.timeInAndTimeOutHistory.column()} pinnedBottomRowData={pinnedData} height="h-[calc(94vh-11.8rem)] lg:h-[calc(94vh-11.8rem)] md:h-[calc(94vh-15.1rem)] xsm:h-[45vh]" isAutoHeight /></div>
            </div>
            {loader && <TransparentLoader />}
            {apiResponseState.show && <ApiResponse />}
        </>
    );
};
const initialState = {
    period: '',
    fromDate: '',
    toDate: ''
}
export default TimeInAndTimeOutHistory;