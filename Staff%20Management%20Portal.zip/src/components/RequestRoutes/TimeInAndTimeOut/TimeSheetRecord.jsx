import { setDefaultValue, strings } from "../../Constants";
import DatePickerElement from "../../elements/DatePickerElement";
import Dropdown from "../../elements/Dropdown";
import HeaderSection from "../../layouts/HeaderSection";
import SubHeaderSection from "../../layouts/SubHeaderSection";
import { exportDateFormat, periodDateFormat, periodOptions, userReducerState } from "../../helper";
import { useForm } from "react-hook-form";
import Button from "../../elements/Button";
import { useEffect, useState } from "react";
import TransparentLoader from "../../loader/TransparentLoader";
import { useDispatch, useSelector } from "react-redux";
import { employeeRequests, leaveManagementRequest, timeInTimeOutRequest } from "../../requests";
import AgGrid from "../../Grid/AgGrid";
import { timeInAndTimeOut } from "../../Grid/Columns";
import ApiResponse from "../../Alert/ApiResponse";
import ViewMissOutPunches from "../../Popup_window/ViewMissOutPunches";


const TimeSheetRecord = () => {
    const dispatch = useDispatch();
    const leaveManagementState = useSelector(state => state.leaveManagement);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const employeeState = useSelector(state => state.employee);
    const timeInTimeOutState = useSelector(state => state.timeInTimeOut);

    const { watch, setValue, getValues } = useForm({ defaultValues: initialState });
    const [loader, setLoader] = useState(false);
    const [data, setData] = useState([]);

    useEffect(() => {
        const initalRender = async () => {
            await setLoader(true);
            Object.keys(leaveManagementState.payroll).length <= 0 && await dispatch(leaveManagementRequest.getPayroll());
            employeeState.employeeName.length <= 0 && await dispatch(employeeRequests.employeeName());
            await handleReset();
            setLoader(false);
        }
        initalRender();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    useEffect(() => {
        setValue(strings.timeInOutSummary.employeeNameOptions, filterEmployeeName(employeeState.employeeName ? employeeState.employeeName : []));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [employeeState.employeeName]);

    const onPeriodChange = (value) => {
        setValue(strings.timeSheetRecord.period, value);
        periodDateFormat(value, setValue);
    }

    const handleSearch = async () => {
        await setLoader(true);
        const values = getValues();
        let params = {
            employeeId: values?.employeeName ? values.employeeName.value : 0,
            fromDate: values?.fromDate ? exportDateFormat(values.fromDate, true) : '',
            toDate: values?.toDate ? exportDateFormat(values.toDate, true) : ''
        }
        await dispatch(timeInTimeOutRequest.getTimeSheetRequest(params, setcallBack));
        setLoader(false);
    }

    const setcallBack = async (data) => {
        await setData(data);
    }

    const handleReset = async () => {
        await setLoader(true);
        await onPeriodChange(periodOptions[3]);
        await setValue(strings.leaveRequestQueue.employeeName, setDefaultValue.employeeName);
        await handleSearch();
        setLoader(false);
    }

    const setRowStyle = params => {
        return { backgroundColor: ("remarks" in params.data) && params.data?.remarks?.length > 0 ? "#ffe9df" : '#ffff' }
    };

    const filterEmployeeName = (employeeName) => {
        const location = setDefaultValue.usLocation
        if (userReducerState().Role === strings.userRoles.superVisor && employeeName.length > 0 && location) {
            return employeeName.filter((val) =>
                (val.locationId === 0) ||
                ((val.employmentStatus === 'All' || val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation) &&
                    val.supervisorId === userReducerState().UserID) ||
                (location.value === 0)
            );
        }
        else if (employeeName.length > 0 && location) {
            return employeeName.filter((val) =>
                ((val.locationId === location.value || val.locationId === 0) &&
                    (val.employmentStatus === 'All' || val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation)) ||
                (location.value === 0)
            );
        }
        return [];
    }

    return (
        <>
            <HeaderSection redirectType={strings.type.timeInTimeOut} />
            <div className=" px-6 mb-5 overflow-hidden">
                <SubHeaderSection subHeader={`Time Sheet Record`} fileProps={{ columns: timeInAndTimeOut.timeSheetRecord.excelDownload(), data: data.map((val, idx) => ({ ...val, sno: idx + 1 })), docName: "Time Sheet Record" }} />
                <div className='grid grid-rows-1 md:grid-rows-1 sm:grid-rows-2 xsm:grid-rows-3 gap-x-4 gap-y-1 xl:grid-cols-5 lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 w-full mb-6'>
                    <div><Dropdown placeholder={"Period"} options={periodOptions.filter(val => [2, 11, 0, 12].includes(val.value))} value={watch(strings.timeSheetRecord.period)} onChange={e => onPeriodChange(e)} isLabelView={true} /></div>
                    <div><DatePickerElement placeholder='From' disabled={watch(strings.timeSheetRecord.period).label !== strings.filterPeriod.custom} value={watch(strings.timeSheetRecord.fromDate) ? watch(strings.timeSheetRecord.fromDate) : ""} onChange={date => setValue(strings.timeSheetRecord.fromDate, date)} isRequired={true} isLabelView={true} /></div>
                    <div><DatePickerElement placeholder='To' disabled={watch(strings.timeSheetRecord.period).label !== strings.filterPeriod.custom} value={watch(strings.timeSheetRecord.toDate) ? watch(strings.timeSheetRecord.toDate) : ""} minDate={watch(strings.timeSheetRecord.period).label === strings.filterPeriod.custom && watch(strings.timeSheetRecord.fromDate)} onChange={date => setValue(strings.timeSheetRecord.toDate, date)} isRequired={true} isLabelView={true} /></div>
                    <div><Dropdown placeholder={"Employee Name"} value={watch(strings.timeSheetRecord.employeeName)} options={watch(strings.timeSheetRecord.employeeNameOptions)} onChange={e => setValue(strings.timeSheetRecord.employeeName, e)} isSearchable={true} isLabelView={true} /></div>
                    <div className=' self-end flex'>
                        <Button value={strings.Buttons.Search} onClick={handleSearch} disabled={watch(strings.timeSheetRecord.period).label === strings.filterPeriod.custom && (!watch(strings.timeSheetRecord.fromDate) || !watch(strings.timeSheetRecord.toDate))} />
                        <span className=' mx-3'> <Button value={strings.Buttons.Reset} onClick={handleReset} /></span>
                    </div>
                </div>
                <div className=" headerCell-FullBorder"><AgGrid data={data} columns={timeInAndTimeOut.timeSheetRecord.column(setLoader)} height="h-[calc(94vh-15rem)] xl:h-[calc(94vh-15.3rem)] lg:h-[calc(94vh-18.6rem)] md:h-[calc(94vh-19.7rem)] xsm:h-[50vh]" rowStyle={setRowStyle} /></div>
            </div>
            {loader && <TransparentLoader />}
            {apiResponseState.show && <ApiResponse />}
            {timeInTimeOutState.viewMissOutPunches.show && <ViewMissOutPunches />}

        </>
    );
};

const initialState = {
    period: '',
    employeeName: '',
    fromDate: '',
    toDate: '',
    employeeNameOptions: []
}

export default TimeSheetRecord;