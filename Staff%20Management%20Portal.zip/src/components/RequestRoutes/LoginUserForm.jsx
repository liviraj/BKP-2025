import { useEffect, useState, useReducer } from 'react';
import SubHeaderSection from '../layouts/SubHeaderSection';
import TransparentLoader from '../loader/TransparentLoader';
import Dropdown from '../elements/Dropdown';
import Button from '../elements/Button';
import TextField from '../elements/TextField';
import { employeeRequests, loginRequest, loginUserRequest } from '../requests';
import { useDispatch, useSelector } from 'react-redux';
import { classNames, routerPath, strings } from '../Constants';
import Label from '../elements/Label';
import RadioButton from '../elements/RadioButton';
import { MdOutlineError } from 'react-icons/md';
import { useHistory } from 'react-router-dom';
import ApiResponse from '../Alert/ApiResponse';
import Mail from '../elements/Mail';
import { loginReducerState } from '../helper';


function LoginUserForm() {

    const [state, dispatch] = useReducer(reducer, initialState)
    const [loader, setLoader] = useState(false);
    const reduxDispatch = useDispatch();
    const history = useHistory();
    const userState = useSelector(state => state.user);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const loginState = useSelector(state => state.login);
    const gridSplit_firstSet = `col-start-1 col-end-5 md:col-end-6 sm:col-end-6 xsm:col-end-6 my-2`;
    const gridSplit_secondSet = `col-start-6 col-end-13 md:col-start-7 sm:col-start-7 xsm:col-start-7 my-2`;

    useEffect(() => {
        const initialApiCall = async () => {
            try {
                setLoader(true);
                await loginState.employeeType <= 0 && await reduxDispatch(loginUserRequest.getEmployeType());
                if (loginState.action === "Edit") {
                    const userDetails = loginState.rowData;
                    const employeeType = loginReducerState().employeeType;
                    await dispatch({
                        type: strings.Buttons.Update, data: {
                            firstName: userDetails.firstName ? userDetails.firstName : "",
                            middleName: userDetails.middleName ? userDetails.middleName : "",
                            lastName: userDetails.lastName ? userDetails.lastName : "",
                            loginId: userDetails.loginId ? userDetails.loginId : "",
                            email: userDetails.emailId ? userDetails.emailId : "",
                            employeeRole: userDetails.roleId && loginState.roles.find(val => val.value === userDetails.roleId) ? loginState.roles.find(val => val.value === userDetails.roleId)?.label : "",
                            companyLocation: userDetails.locationID && loginState.location.find(val => val.value === userDetails.locationID) ? loginState.location.find(val => val.value === userDetails.locationID) : {},
                            employeeType: userDetails.employeeType && employeeType.find(val => val.value === userDetails.employeeType) ? employeeType.find(val => val.value === userDetails.employeeType) : {},
                        }
                    })
                }
                else {
                    await dispatch({ type: strings.createUserLogin.companyLocation, data: userState.LocationID && loginState.location.find(val => val.value === userState.LocationID) ? loginState.location.find(val => val.value === userState.LocationID) : {} });
                }
                setLoader(false);
            } catch (error) {
                setLoader(false);
            }
        }
        initialApiCall();
        // eslint-disable-next-line no-unused-expressions
        return async () => { await reduxDispatch(loginUserRequest.resetUserDetails()); }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const handleClose = async () => {
        await history.push(routerPath.loginView);
    }
    const setCallBack = async (data) => {
        if (loginState.action === "Add") {
            await reduxDispatch(employeeRequests.setEmployeeModule({ communication: {}, work: {}, personalDetails: {}, workDetails: {}, action: "Add", data: data, personal: {}, isDisable: false }));
            await history.push(routerPath.employeePersonal);
        }
        else {
            await handleClose();
        }
        await reduxDispatch(loginRequest.employeeName());
    }
    const onSaveUserDetails = async () => {
        setLoader(true);
        dispatch({ type: strings.createUserLogin.error, data: "" });
        if (loginState.action === "Add") {
            await reduxDispatch(loginUserRequest.createUser({
                employeeId: 0,
                employeeType: state.employeeType.value,
                firstName: state.firstName,
                lastName: state.lastName,
                locationID: state.companyLocation.value,
                // loginId: state.loginId,
                middleName: state.middleName,
                modifiedBy: userState.UserID,
                createdBy: userState.UserID,
                roleId: loginState.roles.find(val => val.label === state.employeeRole).value,
                emailId: state.email
            }, false, setCallBack));
        }
        else {
            const userDetails = loginState.rowData;
            await reduxDispatch(loginUserRequest.updateUserInfo(state.loginId, {
                employeeId: userDetails.employeeId,
                employeeType: state.employeeType.value,
                firstName: state.firstName,
                lastName: state.lastName,
                locationID: state.companyLocation.value,
                // loginId: state.loginId,
                middleName: state.middleName,
                modifiedBy: userState.UserID,
                recordStatus: userDetails.recordStatus,
                roleId: loginState.roles.find(val => val.label === state.employeeRole).value,
                emailId: state.email
            }, setCallBack));
        }
        setLoader(false);
    }
    const setResponseCallback = async (isAcceptable) => {
        if (isAcceptable) {
            await setLoader(true);
            await reduxDispatch(loginUserRequest.createUser({
                employeeId: 0,
                employeeType: state.employeeType.value,
                firstName: state.firstName,
                lastName: state.lastName,
                locationID: state.companyLocation.value,
                // loginId: state.loginId,
                middleName: state.middleName,
                modifiedBy: userState.UserID,
                createdBy: userState.UserID,
                roleId: loginState.roles.find(val => val.label === state.employeeRole).value,
                emailId: state.email
            }, true, setCallBack));
            await setLoader(false);
        }
    }
    return (
        <>
            {/* <HeaderSection routerName={`${loginState.action === "Add" ? "Create" : "Edit"} Login`} /> */}
            <div className='mx-6'>
                <SubHeaderSection subHeader={`${loginState.action === "Add" ? "Create" : "Edit"} Login - User Credentials`} />
                <div className="font-fontfamily font-bold tracking-wide text-14px grid grid-cols-2 xl:grid-cols-2 lg:grid-cols-2 md:grid-cols-1 sm:grid-cols-1 xsm:grid-cols-1 my-5">
                    <form className={classNames.grid.gridCols12}>
                        <span className={gridSplit_firstSet}> <Label label='Employee First Name' required={true} /></span> <span className={gridSplit_secondSet}><TextField onChange={(e) => dispatch({ type: strings.createUserLogin.firstName, data: e.target.value })} value={state.firstName} isRequired={true} /></span>
                        <span className={gridSplit_firstSet}> <Label label='Employee Middle Name' /></span> <span className={gridSplit_secondSet}><TextField onChange={(e) => dispatch({ type: strings.createUserLogin.middleName, data: e.target.value })} value={state.middleName} /></span>
                        <span className={gridSplit_firstSet}> <Label label='Employee Last Name' required={true} /></span> <span className={gridSplit_secondSet}><TextField onChange={(e) => dispatch({ type: strings.createUserLogin.lastName, data: e.target.value })} value={state.lastName} isRequired={true} /></span>
                        <span className={gridSplit_firstSet}> <Label label='Employee Work Email Address' required={true} /></span> <span className={gridSplit_secondSet}><Mail value={state.email.trim().length > 0 ? [state.email] : []} onChange={(val) => dispatch({ type: strings.createUserLogin.email, data: val.length > 0 ? val[val.length - 1] : "" })} isRequired={true} /></span>
                        {/* <span className={gridSplit_firstSet}> <Label label='Login ID' required={true} /></span> <span className={gridSplit_secondSet}><TextField onChange={(e) => dispatch({ type: strings.createUserLogin.loginId, data: e.target.value })} value={state.loginId} isDisable={loginState.action === "Edit"} isRequired={true} /></span> */}
                        <span className={gridSplit_firstSet}> <Label label='Role' required={true} /></span> <span className={gridSplit_secondSet}> <RadioButton options={loginState.roles.filter(val => val.value !== 0).map(val => val.label)} value={state.employeeRole} onChange={(e) => dispatch({ type: strings.createUserLogin.employeeRole, data: e.target.value })} isRequired={true} /></span>
                        <span className={gridSplit_firstSet}> <Label label='Company Location' /></span> <span className={gridSplit_secondSet}><Dropdown value={state.companyLocation} options={loginState.location.filter(val => val.value !== 0)} onChange={(value) => userState.Role === strings.userRoles.humanResource || dispatch({ type: strings.createUserLogin.companyLocation, data: value })} isDisable={(userState.Role === strings.userRoles.humanResource || loginState.action !== "Add")} /></span>
                        <span className={gridSplit_firstSet}> <Label label='Employee Type' required={true} /></span> <span className={gridSplit_secondSet}> <Dropdown value={state.employeeType} options={loginState.employeeType.filter(val => val.value !== "All")} onChange={(value) => dispatch({ type: strings.createUserLogin.employeeType, data: value })} isDisable={!!(loginState.rowData?.employeeCode && loginState.rowData?.employeeCode.length > 0)} isRequired={true} /></span>
                    </form>
                </div>
            </div>
            {state.error.length > 0 && <div className='flex justify-center items-end flex-row bg-red-200 font-fontfamily font-bold text-16px py-3'>
                <MdOutlineError size={26} color='#d80000' /> <span className='mx-2'>{state.error}</span>
            </div>}
            <div className="justify-center flex flex-row gap-3 sm:flex-row mt-3">
                <Button disabled={!(state.firstName && state.lastName && state.employeeRole && state.email && Object.keys(state.employeeType).length)} value={loginState.action === "Add" ? strings.Buttons.Save : strings.Buttons.Update} onClick={onSaveUserDetails} />
                <Button value={strings.Buttons.Close} onClick={() => handleClose()} />
                {loginState.action === "Add" && <Button value={strings.Buttons.Reset} onClick={() => dispatch({ type: strings.Buttons.Reset, data: { ...initialState, [strings.createUserLogin.companyLocation]: state.companyLocation } })} />}
            </div>
            {loader && <TransparentLoader />}
            {apiResponseState.show && <ApiResponse setResponseCallback={setResponseCallback} />}
        </>
    )
}

export default LoginUserForm

const initialState = {
    firstName: "",
    middleName: "",
    lastName: "",
    email: "",
    loginId: "",
    employeeRole: "",
    companyLocation: {},
    employeeType: {},
    error: ""
}


const reducer = (state, action) => {
    if (action.type === strings.Buttons.Reset) {
        return { ...action.data }
    }
    else if (action.type === strings.Buttons.Update) {
        return { ...state, ...action.data }
    }
    else if (action.type) {
        return { ...state, [action.type]: action.data };
    }
    else {
        return { ...state };
    }
};