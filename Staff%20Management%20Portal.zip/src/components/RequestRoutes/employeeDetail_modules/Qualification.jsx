import { useState, useEffect } from 'react';
import HeaderSection from '../../layouts/HeaderSection';
import TextField from '../../elements/TextField';
import Label from '../../elements/Label';
import Dropdown from '../../elements/Dropdown';
import DatePickerElement from '../../elements/DatePickerElement';
import AgGrid from '../../Grid/AgGrid';
import { employeeQualification } from '../../Grid/Columns';
import { useHistory } from 'react-router-dom';
import Button from '../../elements/Button';
import { useForm } from "react-hook-form";
import { routerPath, strings } from '../../Constants';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import { useDispatch, useSelector } from 'react-redux';
import { qualificationrequest, userRequest } from '../../requests';
import UploadAndDeleteDocument from '../../elements/UploadAndDeleteDocument';
import ImageViewer from '../../ViewDocs/ImageViewer';
import TransparentLoader from '../../loader/TransparentLoader';
import ApiResponse from '../../Alert/ApiResponse';
import { exportDateFormat, isPartOfClinicalUser, nameConcatenation, numberValidation } from '../../helper';
import MultiImageViewer from '../../ViewDocs/MultiImageViewer';


const gridFirstSectionLabel = "col-start-1 col-end-4 md:col-end-4 sm:col-end-6 xsm:col-end-6";
const gridSectionValue = `col-start-5 col-end-10 lg:col-end-10 md:col-end-13 sm:col-end-13 xsm:col-end-13 lg:col-start-5 md:col-start-7 sm:col-start-7 xsm:col-start-7`;



function Qualification() {
    const dispatch = useDispatch();
    const history = useHistory();
    const userState = useSelector((state) => state.user);
    const [education, setEducation] = useState([]);
    const [loader, setLoader] = useState(false);
    const [qualificationList, setQualificationList] = useState([]);
    const [currentRowData, setCurrentRowData] = useState({});
    const { handleSubmit, watch, setValue, reset } = useForm({ defaultValues: QualificationState });
    const loginResponseState = useSelector(state => state.loginResponse);
    const employeeModuleState = useSelector(state => state.employee.employeeModule);//employeeModuleState.employeeId
    const { qualification, empQualificationId, institution, university, majorSubject, isPartOfCLEP, courseDuration, courseStartDate, courseEndDate, location, employeeImage, type, value } = strings.QualificationString;

    useEffect(() => {
        setLoader(true);
        const getLocationInfo = async () => {
            await Promise.all([
                dispatch(qualificationrequest.getQualificationList(setQualificationList)),
                dispatch(qualificationrequest.getQualificationDetailsByEmpId(employeeModuleState.personal.employeeId, setEducation))
            ])
            setLoader(false);
        }
        getLocationInfo();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onSaveValidation = () => {
        let isValid = true;
        if (!watch(qualification) || !watch(institution)) { // !watch(courseDuration) || !watch(type) || !watch(value)
            isValid = false;
        }
        return isValid;
    }

    const onSaveQualification = async (data) => {
        try {
            setLoader(true);
            let resultValue = {
                qualification: Object.keys(data.qualification).length > 0 ? data.qualification.label : "",
                empQualificationId: data.empQualificationId,
                institution: data.institution,
                university: data.university,
                majorSubject: data.majorSubject,
                isPartOfCLEP: data.isPartOfCLEP ? isPartOfClinicalUser.yes : isPartOfClinicalUser.no, //percentage or cgpa
                courseDuration: data.courseDuration,
                courseStartDate: exportDateFormat(data.courseStartDate, true),
                courseEndDate: exportDateFormat(data.courseEndDate, true),
                location: data.location,
                employeeImage: "",
                employeeImageBinary: "",
                type: data.type ? data.type : "",// grade/cgpa/% type
                value: data.value,// grade/cgpa/% value
                employeeId: employeeModuleState.personal.employeeId,
                modifiedBy: userState.UserID,
            }
            if (watch('isRowEdit')) {
                let documentLists = data.employeeImage.length > 0 ? data.employeeImage.filter(val => Object.keys(val).length <= 2).map(val => ({ documentName: val.name, documentBinary: val.binary, recordStatus: "A" })) : [];

                if (currentRowData.documentDetails.length > 0) {
                    const documentId = data.employeeImage.map(val => ("id" in val) ? val.id : 0)
                    let deletedDocs = currentRowData.documentDetails.filter(val => !documentId.includes(val.id));
                    if (deletedDocs?.length > 0) {
                        deletedDocs = deletedDocs.map(val => {
                            // eslint-disable-next-line no-unused-vars
                            const { documentName, documentBinary, ...rest } = val;
                            return { ...rest, recordStatus: "D" }
                        })
                        documentLists = [...documentLists, ...deletedDocs];
                    }
                }

                resultValue = { ...resultValue, documentDetails: documentLists }
                await dispatch(qualificationrequest.putQualification(resultValue, watch(empQualificationId)));//qualifId

            } else {
                resultValue = { ...resultValue, documentDetails: data.employeeImage.length > 0 ? data.employeeImage.map(val => ({ documentName: val.name, documentBinary: val.binary, recordStatus: "A" })) : [] };
                await dispatch(qualificationrequest.saveQualification(resultValue));
            }
            await dispatch(qualificationrequest.getQualificationDetailsByEmpId(employeeModuleState.personal.employeeId, setEducation));
            reset();
            setLoader(false);
        } catch (err) {
            console.error(err);
            setLoader(false);
        }
    }

    const updateLocalState = (data, qualifId) => {
        setValue("isRowEdit", true);
        setValue(qualification, data.qualification.length > 0 ? qualificationList.find((val) => val.label === data.qualification) : {});
        setValue(institution, data.institution);
        setValue(university, data.university);
        setValue(majorSubject, data.majorSubject);
        setValue(type, data.type);
        setValue(value, data.value);
        setValue(isPartOfCLEP, data.isPartOfCLEP === isPartOfClinicalUser.yes);
        setValue(courseDuration, data.courseDuration);
        setValue(courseStartDate, data.courseStartDate?.length > 0 ? new Date(data.courseStartDate) : "");
        setValue(courseEndDate, data.courseEndDate?.length > 0 ? new Date(data.courseEndDate) : "");
        setValue(location, data.location);
        setValue(employeeImage, data.documentDetails && data.documentDetails.length > 0 ? data.documentDetails.map(val => {
            const { documentName, documentBinary, ...rest } = val;
            return { ...rest, name: documentName, binary: documentBinary };
        }) : []);
        setValue(empQualificationId, qualifId);
        setCurrentRowData({ ...data });
    }
    const setCallback = async (status) => {
        if (status) {
            await dispatch(qualificationrequest.getQualificationDetailsByEmpId(employeeModuleState.personal.employeeId, setEducation));
            reset();
        }
    }
    const updateSelectedRow = async (data, type) => {
        setLoader(true);
        if (type === "isEdit") {
            await dispatch(qualificationrequest.getQualificationDetailsByQualfId(data.empQualificationId, updateLocalState));
        }
        else {
            setCurrentRowData(data);
            await dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to delete "${data?.qualification}" qualification record?`, isOptional: true }));
        }
        setLoader(false);
    }

    const onDeleteConfirmation = async (isAccepted) => {
        if (isAccepted) {
            setLoader(true);
            const userInfo = {
                modifiedBy: userState.UserID,
                modifiedDate: exportDateFormat(new Date())
            }
            await dispatch(qualificationrequest.deleteQualificationDetails(currentRowData.empQualificationId, userInfo, setCallback));
            setLoader(false);
        }
        setCurrentRowData({});
    }

    return (
        <div>
            <HeaderSection redirectType={strings.type.employeeDetails} employeeName={Object.keys(employeeModuleState.personal).length > 0 ? employeeModuleState.personal.employeeName : nameConcatenation(employeeModuleState.data)} />
            <div>
                <div className='pt-4 px-6 overflow-auto h-auto md:max-h-h_body_md sm:max-h-full' >
                    <fieldset className={"font-fontfamily font-bold text-14px grid grid-cols-2 lg:grid-cols-2 md:grid-cols-1 sm:grid-cols-1 xsm:grid-cols-1"} disabled={employeeModuleState.isDisable}>
                        <div className={`grid grid-cols-12 my-2 gap-y-2 items-center`}>
                            <span className={gridFirstSectionLabel}> <Label label="Qualification" required={true} /></span> <span className={gridSectionValue}><Dropdown options={qualificationList} value={watch(qualification)} onChange={(e) => setValue(qualification, e)} isRequired={true} isSearchable={true} isViewable={employeeModuleState.isDisable} /></span>
                            <span className={gridFirstSectionLabel}> <Label label="Institution" required={true} /></span> <span className={gridSectionValue}><TextField value={watch(institution)} onChange={(e) => setValue(institution, e.target.value)} isRequired={true} /></span>
                            <span className={gridFirstSectionLabel}> <Label label="University" /></span> <span className={gridSectionValue}><TextField value={watch(university)} onChange={(e) => setValue(university, e.target.value)} /></span>
                            <span className={gridFirstSectionLabel}> <Label label="Major Subject" /></span> <span className={gridSectionValue}><TextField value={watch(majorSubject)} onChange={(e) => setValue(majorSubject, e.target.value)} /></span>
                            <span className={`${gridFirstSectionLabel} self-start pt-2`}> <Label label="Grade/Percentage/CGPA" /></span> <span className={gridSectionValue}>
                                <RadioGroup row={false} className='font-fontfamily text-12px' value={watch(type)} onChange={(e) => { setValue(type, e.target.value); setValue(value, '') }} >
                                    <div className=' flex flex-row gap-y-2' style={{ gap: "3vh" }}><FormControlLabel value={"G"} className=' min-w-16' control={<Radio sx={{ color: "grey", '&.Mui-checked': { color: "#ef4641", }, }} />} label={<Label label="Grade" />} /><TextField isDisable={!!(watch(type) && watch(type) !== "G")} value={watch(value) && watch(type) === "G" ? watch(value) : ""} onChange={(e) => setValue(value, e.target.value)} /></div>
                                    <div className=' flex flex-row' style={{ gap: "3vh" }}><FormControlLabel value={"P"} className=' min-w-16' control={<Radio sx={{ color: "grey", '&.Mui-checked': { color: "#ef4641", }, }} />} label={<Label label="%" />} /><TextField isDisable={!!(watch(type) && watch(type) !== 'P')} value={watch(value) && watch(type) === 'P' ? watch(value) : ''} maxLength={5} onChange={(e) => numberValidation(e.target.value, 3, 0, 100, 2) && setValue(value, e.target.value)} /></div>
                                    <div className=' flex flex-row' style={{ gap: "3vh" }}><FormControlLabel value={"C"} className=' min-w-16' control={<Radio sx={{ color: "grey", '&.Mui-checked': { color: "#ef4641", }, }} />} label={<Label label="CGPA" />} /><TextField isDisable={!!(watch(type) && watch(type) !== 'C')} value={watch(value) && watch(type) === 'C' ? watch(value) : ""} onChange={(e) => numberValidation(e.target.value, 2, 0, 10, 2) && setValue(value, e.target.value)} /></div>
                                </RadioGroup>
                            </span>
                        </div>
                        <div className={`grid grid-cols-12 my-2 gap-y-2 items-center`}>
                            <span className={`col-start-1 col-end-13 `}>
                                <FormControlLabel
                                    checked={!!watch(isPartOfCLEP)}
                                    control={
                                        <Checkbox onChange={(e) => setValue(isPartOfCLEP, e.target.checked)} />
                                    }
                                    label="Is Part of Clincal Laboratory Evaluation ?"
                                />
                            </span>
                            <span className={gridFirstSectionLabel}> <Label label="Duration" /></span> <span className={gridSectionValue}><TextField value={watch(courseDuration)} onChange={(e) => setValue(courseDuration, e.target.value)} /></span>
                            <span className={gridFirstSectionLabel}> <Label label="Start Date" /></span> <span className={gridSectionValue}><DatePickerElement value={watch(courseStartDate)} onChange={(e) => setValue(courseStartDate, e)} maxDate={watch(courseEndDate) ? watch(courseEndDate) : new Date()} isViewable={employeeModuleState.isDisable} /></span>
                            <span className={gridFirstSectionLabel}> <Label label="End Date" /></span> <span className={gridSectionValue}><DatePickerElement value={watch(courseEndDate)} onChange={(e) => setValue(courseEndDate, e)} minDate={watch(courseStartDate)} isViewable={employeeModuleState.isDisable} /></span>
                            <span className={gridFirstSectionLabel}> <Label label="Location" /></span> <span className={gridSectionValue}><TextField value={watch(location)} onChange={(e) => setValue(location, e.target.value)} /></span>
                            <span className={gridFirstSectionLabel}> <Label label="Certificate Image" /></span> <span className={gridSectionValue}><UploadAndDeleteDocument label="Certificate Image" onChange={file => setValue(employeeImage, file)} file={watch(employeeImage)} isViewable={employeeModuleState.isDisable} isMultiDocument /></span>
                        </div>
                    </fieldset>
                    <div className="justify-center flex flex-row gap-3 sm:flex-row my-3 lg:my-3 md:my-1 sm:my-0 xsm:my-0">
                        {employeeModuleState.isDisable || <Button value={watch('isRowEdit') ? strings.Buttons.Update : strings.Buttons.Save} onClick={handleSubmit(onSaveQualification)} disabled={!onSaveValidation()} />}
                        {employeeModuleState.isDisable && <Button value={strings.Buttons.CustomClear} onClick={() => reset()} />}
                        <Button value={strings.Buttons.Close} onClick={() => history.push(routerPath.staff)} />
                        {employeeModuleState.isDisable || <Button value={strings.Buttons.Reset} onClick={() => {
                            if (watch('isRowEdit')) {
                                updateLocalState(currentRowData, watch('empQualificationId'))
                            } else {
                                reset()
                            }
                        }} />}
                    </div>
                    <AgGrid data={education} columns={employeeQualification.columns(setLoader, loginResponseState.isMobileCompatible, updateSelectedRow)} height=" h-[calc(93vh-333px-3.5rem-48px-4.6rem-3.5rem)] md:h-[calc(93vh-333px-3.5rem-48px-4.6rem-3.5rem)]  xsm:h-[20.1rem]" ContextMenuItems={loginResponseState.isMobileCompatible ? false : employeeQualification.ContextMenuItems} history={history} callBack={updateSelectedRow} isAutoHeight maxScrollCount={6} />
                </div>
            </div>
            {!loginResponseState.multiDocumentViewer.show && loginResponseState.imageViewer.show && <ImageViewer />}
            {loginResponseState.multiDocumentViewer.show && <MultiImageViewer />}
            {loader && <TransparentLoader />}
            {loginResponseState.apiResponse.show && <ApiResponse setResponseCallback={onDeleteConfirmation} />}
        </div>
    )
}

const QualificationState = {
    qualification: "",
    empQualificationId: 0,
    institution: "",
    university: "",
    majorSubject: "",
    isPartOfCLEP: '', //percentage or cgpa
    courseDuration: "",
    courseStartDate: "",
    courseEndDate: "",
    location: "",
    employeeImage: [],
    type: false,// grade/cgpa/% type
    value: "",// grade/cgpa/% value
    employeeid: "",
    modifiedBy: "",
    loader: false,
    isRowEdit: false,
}

export default Qualification