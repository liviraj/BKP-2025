import { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from "react-hook-form";
import HeaderSection from '../../layouts/HeaderSection';
import Label from '../../elements/Label';
import TextField from '../../elements/TextField';
import UploadAndDeleteDocument from '../../elements/UploadAndDeleteDocument';
import Button from '../../elements/Button';
import AgGrid from '../../Grid/AgGrid';
import { employeeDetails } from '../../Grid/Columns';
import { routerPath, strings } from '../../Constants';
import TransparentLoader from '../../loader/TransparentLoader';
import ImageViewer from '../../ViewDocs/ImageViewer';
import { employeeRequests, userRequest } from '../../requests';
import { exportDateFormat, nameConcatenation } from '../../helper';
import ApiResponse from '../../Alert/ApiResponse';
import DatePickerElement from '../../elements/DatePickerElement';
import Dropdown from '../../elements/Dropdown';
import MultiImageViewer from '../../ViewDocs/MultiImageViewer';


function Training() {
    const gridSectionLabel = "col-start-1 col-end-4 md:col-end-4 sm:col-end-6 xsm:col-end-6";
    const gridSectionValue = `col-start-5 col-end-10 lg:col-end-10 md:col-end-13 sm:col-end-13 xsm:col-end-13 lg:col-start-5 md:col-start-7 sm:col-start-7 xsm:col-start-7`;
    const history = useHistory();
    const employeeModuleState = useSelector(state => state.employee.employeeModule);
    const loginResponseState = useSelector(state => state.loginResponse);
    const employeeState = useSelector(state => state.employee);
    const userState = useSelector(state => state.user);
    const { handleSubmit, watch, setValue, reset } = useForm({ defaultValues: initialState });
    const dispatch = useDispatch();
    const [loader, setLoader] = useState(false);
    const [selectedRecord, setSelectedRecord] = useState({});

    useEffect(() => {
        const componentDidMount = async () => {
            await setLoader(true);
            await Promise.all([
                employeeState.trainingCategory.length <= 0 && dispatch(employeeRequests.getTrainingCategory()),
                onLoad()
            ]);
            setLoader(false);
        }
        componentDidMount();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const onReset = async () => {
        await setLoader(true);
        const selectedData = watch(strings.training.selectedData);
        Object.keys(selectedData).length > 0 ? await selectedDataUpdate(selectedData) : await resetReocrds();
        setLoader(false);
    }

    const onLoad = async () => {
        if (employeeModuleState.personal && Object.keys(employeeModuleState.personal).length > 0) {
            await dispatch(employeeRequests.getEmployeeTrainingDetails(employeeModuleState.personal.employeeId, async (isValid, data) => {
                if (isValid) {
                    await setValue(strings.training.data, data);
                }
            }));
        }
    }

    const setCallBack = async (isValid) => {
        if (isValid) {
            await resetReocrds();
            await onLoad();
        }
    }

    const resetReocrds = async () => {
        const data = watch(strings.training.data);
        await reset();
        await setValue(strings.training.data, data);
    }

    const onSubmit = async (data) => {
        const selectedData = watch(strings.training.selectedData);
        await setLoader(true);
        if (employeeModuleState.personal && Object.keys(employeeModuleState.personal).length > 0) {
            let trainingRecords = {
                employeeID: employeeModuleState.personal.employeeId,
                employeeTrainingCategoryID: Object.keys(data.trainingCategory).length > 0 ? data.trainingCategory.value : 0,
                modifiedBy: userState.UserID,
                purpose: data.purpose,
                trainingDocBinary: data.documentImage.length > 0 ? data.documentImage[0].binary : "",
                trainingDocumentName: data.documentImage.length > 0 ? data.documentImage[0].name : "",
                trainingFrom: exportDateFormat(data.trainingFrom, true),
                trainingTo: exportDateFormat(data.trainingTo, true)
            }
            if (Object.keys(selectedData).length <= 0) {
                trainingRecords = { ...trainingRecords, documentList: data.documentImage.length > 0 ? data.documentImage.map(val => ({ documentName: val.name, documentBinary: val.binary, recordStatus: "A" })) : [] }
                await dispatch(employeeRequests.createTrainingRecords(trainingRecords, setCallBack));
            } else {
                let documentLists = data.documentImage.length > 0 ? data.documentImage.filter(val => Object.keys(val).length <= 2).map(val => ({ documentName: val.name, documentBinary: val.binary, recordStatus: "A" })) : [];

                if (selectedData.documentList.length > 0) {
                    const documentId = data.documentImage.map(val => ("id" in val) ? val.id : 0)
                    let deletedDocs = selectedData.documentList.filter(val => !documentId.includes(val.id));
                    if (deletedDocs?.length > 0) {
                        deletedDocs = deletedDocs.map(val => {
                            // eslint-disable-next-line no-unused-vars
                            const { documentName, documentBinary, ...rest } = val;
                            return { ...rest, recordStatus: "D" }
                        })
                        documentLists = [...documentLists, ...deletedDocs];
                    }
                }

                trainingRecords = { ...trainingRecords, documentList: documentLists }
                await dispatch(employeeRequests.updateTrainingRecords(selectedData.employeeTrainingId, trainingRecords, setCallBack));
            }

        }
        setLoader(false);
    }
    const selectedDataUpdate = async (selectedData) => {
        await Promise.all([
            setValue(strings.training.trainingCategory, selectedData.employeeTrainingCategoryID > 0 ? employeeState.trainingCategory.find(val => val.value === selectedData.employeeTrainingCategoryID) : {}),
            setValue(strings.training.trainingFrom, selectedData.trainingFrom?.length > 0 ? new Date(selectedData.trainingFrom) : ""),
            setValue(strings.training.trainingTo, selectedData.trainingTo?.length > 0 ? new Date(selectedData.trainingTo) : ""),
            setValue(strings.training.purpose, selectedData.purpose),
            setValue(strings.training.documentImage, selectedData.documentList && selectedData.documentList.length > 0 ? selectedData.documentList.map(val => {
                const { documentName, documentBinary, ...rest } = val;
                return { ...rest, name: documentName, binary: documentBinary };
            }) : []),
            setValue(strings.training.data, watch(strings.training.data)),
            setValue(strings.training.selectedData, { ...selectedData })
        ]);
    }
    const setAction = async (selectedData, action) => {
        await setLoader(true);
        if (action === "Edit") {
            await dispatch(employeeRequests.getTrainingData(selectedData.employeeTrainingId, async (isValid, data) => {
                if (isValid) {
                    await selectedDataUpdate({ ...data, employeeTrainingId: selectedData.employeeTrainingId });
                    await onLoad();
                }
            }));
        }
        else {
            setSelectedRecord(selectedData);
            await dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to delete "${selectedData.trainingCategory}" category record?`, isOptional: true }));
        }
        setLoader(false);
    }

    const setDeleteConfirm = async (isAccepted) => {
        if (isAccepted) {
            await setLoader(true);
            const userInfo = {
                modifiedBy: userState.UserID,
                modifiedDate: exportDateFormat(new Date())
            }
            await dispatch(employeeRequests.deleteTrainingRecord(selectedRecord.employeeTrainingId, userInfo, setCallBack));
            setLoader(false);
        }
        setSelectedRecord({});
    }

    return (
        <div>
            <HeaderSection redirectType={strings.type.employeeDetails} employeeName={Object.keys(employeeModuleState.personal).length > 0 ? employeeModuleState.personal.employeeName : nameConcatenation(employeeModuleState.data)} />
            <div>
                <div className='pt-4 px-6 overflow-auto h-auto md:max-h-h_body_md sm:max-h-full'>
                    <div className={"font-fontfamily font-bold text-14px grid grid-cols-2 lg:grid-cols-2 md:grid-cols-1 sm:grid-cols-1 xsm:grid-cols-1"}>
                        <fieldset className={`grid grid-cols-12 my-2 gap-y-3 items-center`} disabled={employeeModuleState.isDisable}>
                            <span className={gridSectionLabel}> <Label label="Training Category" required={true} /></span> <span className={gridSectionValue} ><Dropdown value={watch(strings.training.trainingCategory)} onChange={value => setValue(strings.training.trainingCategory, value)} options={employeeState.trainingCategory} isRequired={true} isViewable={employeeModuleState.isDisable} /></span>
                            <span className={gridSectionLabel}> <Label label="Training From" required={true} /></span> <span className={gridSectionValue} ><DatePickerElement value={watch(strings.training.trainingFrom)} onChange={date => setValue(strings.training.trainingFrom, date)} isRequired={true} maxDate={watch(strings.training.trainingTo) ? watch(strings.training.trainingTo) : new Date()} isViewable={employeeModuleState.isDisable} /></span>
                            <span className={gridSectionLabel}> <Label label="Training To" required={true} /></span> <span className={gridSectionValue} ><DatePickerElement value={watch(strings.training.trainingTo)} onChange={date => setValue(strings.training.trainingTo, date)} isRequired={true} minDate={watch(strings.training.trainingFrom)} isViewable={employeeModuleState.isDisable} /></span>
                            <span className={gridSectionLabel}> <Label label="Purpose" /></span> <span className={gridSectionValue} ><TextField value={watch(strings.training.purpose)} onChange={e => setValue(strings.training.purpose, e.target.value)} /></span>
                            <span className={gridSectionLabel}> <Label label="Document Image" /></span> <span className={gridSectionValue} ><UploadAndDeleteDocument label={"Choose File"} file={watch(strings.training.documentImage)} onChange={file => setValue(strings.training.documentImage, file)} isViewable={employeeModuleState.isDisable} isMultiDocument /></span>
                        </fieldset>
                    </div>
                    <div className=' flex justify-center items-center my-3 gap-x-3 lg:my-3 md:my-1 sm:my-0 xsm:my-0'>
                        {employeeModuleState.isDisable || <Button value={Object.keys(watch(strings.training.selectedData)).length > 0 ? strings.Buttons.Update : strings.Buttons.Save} disabled={!(watch(strings.training.trainingCategory) && watch(strings.training.trainingFrom) && watch(strings.training.trainingTo))} onClick={handleSubmit(onSubmit)} />}
                        {employeeModuleState.isDisable && <Button value={strings.Buttons.CustomClear} onClick={() => resetReocrds()} />}
                        <Button value={strings.Buttons.Close} onClick={() => history.push(routerPath.staff)} />
                        {employeeModuleState.isDisable || <Button value={strings.Buttons.Reset} onClick={() => onReset()} />}
                    </div>
                    <AgGrid data={watch(strings.training.data)} columns={employeeDetails.trainingColumns(setLoader, loginResponseState.isMobileCompatible, setAction)} height="h-[calc(93vh-261px-3.5rem-48px-4.6rem-6rem)] md:h-[calc(93vh-261px-3.5rem-48px-4.6rem-6rem)] xsm:h-[24.8rem]" ContextMenuItems={loginResponseState.isMobileCompatible ? false : employeeDetails.training_contextMenuItems} history={history} callBack={setAction} isAutoHeight maxScrollCount={6} />
                </div>
            </div>
            {loader && <TransparentLoader />}
            {!loginResponseState.multiDocumentViewer.show && loginResponseState.imageViewer.show && <ImageViewer />}
            {loginResponseState.multiDocumentViewer.show && <MultiImageViewer />}
            {loginResponseState.apiResponse.show && <ApiResponse setResponseCallback={setDeleteConfirm} />}
        </div>
    )
}

export default Training

const initialState = {
    trainingCategory: "",
    trainingFrom: "",
    trainingTo: "",
    purpose: "",
    documentImage: [],
    data: [],
    selectedData: {}
}