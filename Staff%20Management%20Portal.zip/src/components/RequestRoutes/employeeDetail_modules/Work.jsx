import { useEffect, useMemo } from 'react'
import HeaderSection from '../../layouts/HeaderSection'
import Label from '../../elements/Label';
import TextField from '../../elements/TextField';
import DatePickerElement from '../../elements/DatePickerElement';
import Dropdown from '../../elements/Dropdown';
import Button from '../../elements/Button';
import { useHistory } from 'react-router-dom';
import { useForm } from "react-hook-form";
import { routerPath, setDefaultValue, strings } from '../../Constants';
import { useDispatch, useSelector } from 'react-redux';
import { employeeRequests, loginRequest } from '../../requests';
import TransparentLoader from '../../loader/TransparentLoader';
import ApiResponse from '../../Alert/ApiResponse';
import { employeeReducerState, exportDateFormat, loginReducerState, nameConcatenation, userReducerState } from '../../helper';
import AutoSizeButton from '../../elements/AutoSizeButton';
import { MdOutlineKeyboardDoubleArrowLeft } from "react-icons/md";
import { employeeActions } from '../../../redux/employeeReducer';

function Work() {
    const gridFirstSectionLabel = "col-start-1 col-end-4 md:col-end-4 sm:col-end-6 xsm:col-end-6";
    const gridSectionValue = `col-start-5 col-end-10 lg:col-end-10 md:col-end-13 sm:col-end-13 xsm:col-end-13 lg:col-start-5 md:col-start-7 sm:col-start-7 xsm:col-start-7`;
    const gridSecondSectionLabel = "col-start-1 lg:col-start-1 md:col-start-1 sm:col-start-1 xsm:col-start-1 col-end-5 lg:col-end-5 md:col-end-6 sm:col-end-6 xsm:col-end-6";
    const employeeState = useSelector(state => state.employee);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const employeeModuleState = useSelector(state => state.employee.employeeModule);
    const { handleSubmit, watch, setValue, reset, getValues } = useForm({ defaultValues: initialState });
    const history = useHistory();
    const dispatch = useDispatch();
    const employeeDepartment = watch(strings.employeeWork.department);
    const employmentStatus = watch(strings.employeeWork.employmentStatus);

    const setCreateCallBack = async (isSuccessed, response) => {
        if (isSuccessed) {
            if (Object.keys(employeeModuleState.personalDetails).length > 0) {
                const personalDetails = employeeModuleState.personal && Object.keys(employeeModuleState.personal).length > 0 ? { ...employeeModuleState.personal } : Object.keys(employeeModuleState.data).length > 0 ? { ...employeeModuleState.data } : {}
                await Promise.all([
                    employeeModuleState.personal && Object.keys(employeeModuleState.personal).length <= 0 && dispatch(employeeRequests.employeeName()),
                    employeeModuleState.personal && Object.keys(employeeModuleState.personal).length <= 0 && dispatch(loginRequest.employeeName()),
                    dispatch(employeeRequests.setEmployeeModule({ ...employeeModuleState, personal: { ...personalDetails, ...employeeModuleState.personalDetails.params, ...response } })),
                ]);
                history.push(routerPath.employeeCommunication);
            } else {
                setCallBack(isSuccessed);
            }
        }
    }

    const setCallBack = async (isSuccessed) => {
        if (isSuccessed) {
            await history.push(routerPath.employeeCommunication);
            await dispatch(employeeRequests.employeeName());
        }
    }

    const onSubmit = async (data) => {
        await setValue(strings.constants.loader, true);
        if (Object.keys(data.getWorkDetails).length <= 0) {
            const workDetails = {
                clinicalHandler: !!(Object.keys(data.isHandlesClinicalSamples).length > 0 && data.isHandlesClinicalSamples.label === "Yes"),
                confirmationDate: exportDateFormat(data.confirmationDate, true),
                countryIssued: data.countryOfIssue,
                createdBy: userReducerState().UserID,
                currentLocation: Object.keys(data.currentLocation).length > 0 ? data.currentLocation.value : 0, // dropdown
                departmentID: Object.keys(data.department).length > 0 ? data.department.value : 0, // dropdown
                designationID: Object.keys(data.designation).length > 0 ? data.designation.value : 0, // dropdown
                doj: exportDateFormat(data.dateOfJoining, true),
                employeeID: employeeModuleState.personal.employeeId,
                employmentStatus: Object.keys(data.employmentStatus).length > 0 ? data.employmentStatus.label : 0,
                employmentType: data.employmentType && Object.keys(data.employmentType).length > 0 ? data.employmentType.employeeTypeId : 0,
                expiryDateWork: exportDateFormat(data.expiryDate, true),
                gradeID: Object.keys(data.grade).length > 0 ? data.grade.value : 0, // API side balance
                issueDateWork: exportDateFormat(data.issueDate, true),
                laptopID: data.laptopId,
                locationID: Object.keys(data.workLocation).length > 0 ? data.workLocation.value : 0, // dropdown
                modifiedBy: userReducerState().UserID,
                placeofIssue: data.placeOfIssue,
                relievingDate: exportDateFormat(data.relievingDate, true),
                reportingTo: Object.keys(data.manager).length > 0 ? data.manager.value : 0, // dropdown
                systemID: data.systemId,
                visaType: data.visaType,
                workStationID: data.workStationId
            }
            const personalDetails = Object.keys(employeeModuleState.personalDetails).length > 0 ? employeeModuleState.personalDetails.params : null;
            await dispatch(employeeRequests.createEmployee_work(Object.keys(employeeModuleState.personalDetails).length > 0 ? employeeModuleState.data.loginId : 0, { employee: personalDetails, workDto: workDetails }, setCreateCallBack));
        } else {
            await dispatch(employeeRequests.updateEmployee_work(data.getWorkDetails.employeeWorkId, {
                clinicalHandler: !!(Object.keys(data.isHandlesClinicalSamples).length > 0 && data.isHandlesClinicalSamples.label === "Yes"),
                confirmationDate: exportDateFormat(data.confirmationDate, true),
                countryIssued: data.countryOfIssue,
                createdBy: userReducerState().UserID,
                currentLocation: Object.keys(data.currentLocation).length > 0 ? data.currentLocation.value : 0, // dropdown
                departmentID: Object.keys(data.department).length > 0 ? data.department.value : 0,
                designationID: Object.keys(data.designation).length > 0 ? data.designation.value : 0, // dropdown
                doj: exportDateFormat(data.dateOfJoining, true),
                employeeID: employeeModuleState.personal.employeeId,
                employmentStatus: Object.keys(data.employmentStatus).length > 0 ? data.employmentStatus.label : 0,
                employmentType: Object.keys(data.employmentType).length > 0 ? data.employmentType.employeeTypeId : 0,
                expiryDateWork: exportDateFormat(data.expiryDate, true),
                gradeID: Object.keys(data.grade).length > 0 ? data.grade.value : 0, // API side balance
                issueDateWork: exportDateFormat(data.issueDate, true),
                laptopID: data.laptopId,
                locationID: Object.keys(data.workLocation).length > 0 ? data.workLocation.value : 0, // dropdown
                modifiedBy: userReducerState().UserID,
                placeofIssue: data.placeOfIssue,
                recordStatus: data.getWorkDetails.recordStatus,
                relievingDate: exportDateFormat(data.relievingDate, true),
                reportingTo: Object.keys(data.manager).length > 0 ? data.manager.value : 0, // dropdown
                systemID: data.systemId,
                visaType: data.visaType,
                workStationID: data.workStationId
            }, setCallBack));
        }

        setValue(strings.constants.loader, false);
    }

    const onReset = async () => {
        await reset();
        await setValue(strings.constants.loader, true);
        await onLoadData();
        setValue(strings.constants.loader, false);
    }

    useEffect(() => {
        const componentDidMount = async () => {
            await setValue(strings.constants.loader, true);
            await Promise.all([
                employeeState.designation.length <= 0 && dispatch(employeeRequests.employeeDesignation()),
                employeeState.department.length <= 0 && dispatch(employeeRequests.employeeDepartment()),
                employeeState.grade.length <= 0 && dispatch(employeeRequests.getGrade()),
                employeeState.location.length <= 0 && dispatch(employeeRequests.location()),
                employeeState.employeeType.length <= 0 && dispatch(employeeRequests.employeeType()),
                employeeState.clinicalUser.length <= 0 && dispatch(employeeRequests.clinicalUser()),
                employeeState.employeeName.length <= 0 && dispatch(employeeRequests.employeeName()),
                employeeState.employeeStatus.length <= 0 && dispatch(employeeRequests.status()),
                loginReducerState().status.length <= 0 && dispatch(loginRequest.status())
            ]);
            await onLoadData();
            setValue(strings.constants.loader, false);
        }
        componentDidMount();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onLoadData = async () => {

        if (Object.keys(employeeModuleState.workDetails).length > 0) {
            reset(employeeModuleState.workDetails);
        }
        else if (Object.keys(employeeModuleState.personal).length > 0) {
            setValue(strings.employeeWork.employeeName, employeeModuleState.personal.firstName + " " + employeeModuleState.personal?.middleName + " " + employeeModuleState.personal.lastName);
            setValue(strings.employeeWork.employeeCode, employeeModuleState.personal.employeeCode ? employeeModuleState.personal.employeeCode : "");
            employeeModuleState.personal?.locationId && setValue(strings.employeeWork.workLocation, employeeState.location.find(val => val.value === employeeModuleState.personal.locationId));
            employeeModuleState.personal?.employmentType && setValue(strings.employeeWork.employmentType, employeeState.employeeType.find(val => val.value === employeeModuleState.personal.employmentType));
            await Object.keys(watch(strings.employeeWork.getWorkDetails)).length <= 0 && await dispatch(employeeRequests.getEmployee_work_details(employeeModuleState.personal.employeeId, async (isValid, data) => {
                if (isValid) {
                    await setValue(strings.employeeWork.getWorkDetails, data.length > 0 ? data[0] : {});
                }
            }));
        } else if (employeeModuleState.data && Object.keys(employeeModuleState.data).length > 0) {
            reset({
                ...getValues(),
                [strings.employeeWork.employeeName]: employeeModuleState.data?.firstName + " " + employeeModuleState.data?.middleName + " " + employeeModuleState.data?.lastName,
                [strings.employeeWork.employeeCode]: employeeModuleState.data.employeeCode ? employeeModuleState.data.employeeCode : "",
                [strings.employeeWork.workLocation]: employeeModuleState.data?.locationId ? employeeState.location.find(val => val.value === employeeModuleState.personal.locationId) : "",
                [strings.employeeWork.employmentType]: employeeModuleState.data?.employmentType ? employeeState.employeeType.find(val => val.value === employeeModuleState.personal.employmentType) : ""
            });
        }

        const workDetails = watch(strings.employeeWork.getWorkDetails);
        if (workDetails && Object.keys(workDetails).length > 0) {
            await Promise.all([
                setValue(strings.employeeWork.dateOfJoining, workDetails.doj && !isNaN(new Date(workDetails.doj)) ? new Date(workDetails.doj) : ""),
                setValue(strings.employeeWork.designation, employeeState.designation.find(val => val.value === workDetails.designationID)),
                setValue(strings.employeeWork.grade, workDetails.gradeID > 0 ? employeeReducerState().grade.find(val => val.value === workDetails.gradeID) : {}),
                setValue(strings.employeeWork.workStationId, workDetails.workStationID),
                setValue(strings.employeeWork.systemId, workDetails.systemID),
                setValue(strings.employeeWork.laptopId, workDetails.laptopID),
                setValue(strings.employeeWork.manager, employeeReducerState().employeeName.find(val => val.value === workDetails.reportingTo)),
                setValue(strings.employeeWork.department, employeeState.department.find(val => val.value === workDetails.departmentID)),
                workDetails.locationID && setValue(strings.employeeWork.workLocation, employeeState.location.find(val => val.value === workDetails.locationID)),
                workDetails.employmentType && setValue(strings.employeeWork.employmentType, employeeState.employeeType.find(val => val.employeeTypeId === workDetails.employmentType)),
                setValue(strings.employeeWork.visaType, workDetails.visaType),
                setValue(strings.employeeWork.placeOfIssue, workDetails.placeofIssue),
                setValue(strings.employeeWork.issueDate, workDetails.issueDateWork && !isNaN(new Date(workDetails.issueDateWork)) ? new Date(workDetails.issueDateWork) : ""),
                setValue(strings.employeeWork.expiryDate, workDetails.expiryDateWork && !isNaN(new Date(workDetails.expiryDateWork)) ? new Date(workDetails.expiryDateWork) : ""),
                setValue(strings.employeeWork.countryOfIssue, workDetails.countryIssued),
                workDetails.currentLocation && setValue(strings.employeeWork.currentLocation, employeeState.location.find(val => val.value === workDetails.currentLocation)),
                setValue(strings.employeeWork.confirmationDate, workDetails.confirmationDate && !isNaN(new Date(workDetails.confirmationDate)) ? new Date(workDetails.confirmationDate) : ""),
                setValue(strings.employeeWork.relievingDate, workDetails.relievingDate && !isNaN(new Date(workDetails.relievingDate)) ? new Date(workDetails.relievingDate) : ""),
                setValue(strings.employeeWork.employmentStatus, employeeState.employeeStatus.find(val => val.label === workDetails.employmentStatus)),
                setValue(strings.employeeWork.isHandlesClinicalSamples, employeeState.clinicalUser.find(val => val.label === (workDetails.clinicalHandler ? "Yes" : "No"))),
                workDetails.roleName && setValue(strings.employeeWork.role, loginReducerState().roles.find(val => val.label.toLowerCase() === workDetails.roleName.toLowerCase()))
            ]);
        }
        else if (employeeModuleState.data && Object.keys(employeeModuleState.data).length > 0) {
            await Promise.all([
                employeeModuleState.data.locationId && setValue(strings.employeeWork.workLocation, employeeState.location.find(val => val.value === employeeModuleState.data.locationId)),
                employeeModuleState.data.employmentType && setValue(strings.employeeWork.employmentType, employeeState.employeeType.find(val => val.employeeTypeId === employeeModuleState.data.employmentType)),
                employeeModuleState.data.roleName && setValue(strings.employeeWork.role, loginReducerState().roles.find(val => val.label.toLowerCase() === employeeModuleState.data.roleName.toLowerCase()))
            ])
        }
        else {
            userReducerState().Role === strings.userRoles.humanResource && await setValue(strings.employeeWork.workLocation, employeeReducerState().location.find(val => val.value === userReducerState().LocationID));
        }
    }

    const onhandlePrevious = async () => {
        await dispatch(employeeActions.setEmployeeModule({ ...employeeModuleState, workDetails: getValues() }));
        await history.push(routerPath.employeePersonal);
    }

    const supervisorManagerOptions = useMemo(() => {
        const isIndiaLocation = (Object.keys(employeeModuleState.personal).length > 0 ? employeeModuleState.personal.locationId : employeeModuleState.data.locationId) === setDefaultValue.location.value;
        if (isIndiaLocation) {
            return employeeState.employeeName.filter(val => (val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation))
        }
        else if (employeeDepartment?.sortOrder) {
            return employeeState.employeeName.filter(val =>
                (val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation)
                && val.locationId === setDefaultValue.usLocation.value
                && val.sortOrder
                && (val.sortOrder.split(",").includes(employeeDepartment.sortOrder.toString()) || val.sortOrder.split(",").includes("0"))
                && (val.roleName === strings.userRoles.superVisor || val.roleName === strings.userRoles.humanResource || val.roleName === strings.userRoles.admin))
        }
        return [];

    }, [employeeModuleState, employeeState, employeeDepartment]);

    const handleDisable = () => {
        if (watch(strings.employeeWork.employeeName) && watch(strings.employeeWork.designation) && watch(strings.employeeWork.department) && watch(strings.employeeWork.dateOfJoining) && watch(strings.employeeWork.manager) && watch(strings.employeeWork.isHandlesClinicalSamples) && employmentStatus) {
            if (employmentStatus?.label === setDefaultValue.employmentStatus.confirmed) {
                return !watch(strings.employeeWork.confirmationDate);
            }
            else if (employmentStatus.label === setDefaultValue.employmentStatus.relieved) {
                return !watch(strings.employeeWork.relievingDate);
            }
            return false;
        }
        return true;
    }

    const handleEmploymentStatusValidity = (type) => {
        return !!(employmentStatus && employmentStatus?.label === type)
    }

    return (
        <div>
            <HeaderSection redirectType={strings.type.employeeDetails} employeeName={Object.keys(employeeModuleState.personal).length > 0 ? employeeModuleState.personal.employeeName : nameConcatenation(employeeModuleState.data)} />
            <div>
                <div className='pt-4 px-6 overflow-auto h-auto md:max-h-h_body_md sm:max-h-full'>
                    <fieldset className={"font-fontfamily font-bold text-14px grid grid-cols-2 lg:grid-cols-2 md:grid-cols-1 sm:grid-cols-1 xsm:grid-cols-1"} disabled={employeeModuleState.isDisable}>
                        <div className={`grid grid-cols-12 my-2 gap-y-3 items-center`}>
                            <span className={gridFirstSectionLabel}> <Label label="Employee Code" /></span> <span className={gridSectionValue} ><TextField value={watch(strings.employeeWork.employeeCode)} isDisable={true} onChange={e => setValue(strings.employeeWork.employeeCode, e.target.value)} /></span>
                            <span className={gridFirstSectionLabel}> <Label label="Employee Name" required={true} /> </span> <span className={gridSectionValue}><TextField value={watch(strings.employeeWork.employeeName)} isDisable={true} onChange={e => setValue(strings.employeeWork.employeeName, e.target.value)} isRequired={true} /></span>
                            <span className={gridFirstSectionLabel}> <Label label="Designation" required={true} /></span> <span className={gridSectionValue}><Dropdown value={watch(strings.employeeWork.designation)} options={employeeState.designation.filter(val => val.value > 0)} onChange={data => setValue(strings.employeeWork.designation, data)} isSearchable={true} isRequired={true} isViewable={employeeModuleState.isDisable} /></span>
                            <span className={gridFirstSectionLabel}> <Label label="Section" required={true} /></span> <span className={gridSectionValue}><Dropdown value={employeeDepartment} options={(Object.keys(employeeModuleState.personal).length > 0 ? employeeModuleState.personal.locationId : employeeModuleState.data.locationId) === setDefaultValue.location.value ? employeeState.department.filter(val => val.value > 0) : employeeState.department.filter(val => val.value > 0 && Object.hasOwn(val, "locationId") && val.locationId.includes(setDefaultValue.usLocation.value))} onChange={data => {
                                setValue(strings.employeeWork.department, data);
                                if ((Object.keys(employeeModuleState.personal).length > 0 ? employeeModuleState.personal.locationId : employeeModuleState.data.locationId) === setDefaultValue.usLocation.value && employeeDepartment.value !== data.value) {
                                    setValue(strings.employeeWork.manager, "")
                                }
                            }} isSearchable={true} isRequired={true} isViewable={employeeModuleState.isDisable} /></span>
                            <span className={gridFirstSectionLabel}> <Label label="Date Of Joining" required={true} /></span> <span className={gridSectionValue}><DatePickerElement value={watch(strings.employeeWork.dateOfJoining)} onChange={date => setValue(strings.employeeWork.dateOfJoining, date)} isRequired={true} isViewable={employeeModuleState.isDisable} /></span>
                            <span className={gridFirstSectionLabel}> <Label label="Supervisor / Manager" required={true} /></span> <span className={gridSectionValue}><Dropdown value={watch(strings.employeeWork.manager)} options={supervisorManagerOptions} onChange={data => setValue(strings.employeeWork.manager, data)} isSearchable={true} isRequired={true} isViewable={employeeModuleState.isDisable} /></span>
                            <span className={gridFirstSectionLabel}> <Label label="Grade" /></span> <span className={gridSectionValue}><Dropdown value={watch(strings.employeeWork.grade)} options={employeeState.grade} onChange={data => setValue(strings.employeeWork.grade, data)} isViewable={employeeModuleState.isDisable} /></span>
                            <span className={gridFirstSectionLabel}> <Label label="Work Location" required /></span> <span className={gridSectionValue}><Dropdown value={watch(strings.employeeWork.workLocation)} isRequired options={employeeState.location.filter(val => val.value > 0)} onChange={data => setValue(strings.employeeWork.workLocation, data)} isViewable={employeeModuleState.isDisable} /></span>
                            <span className={gridFirstSectionLabel}> <Label label="Employment Type" /></span> <span className={gridSectionValue}><Dropdown value={watch(strings.employeeWork.employmentType)} options={employeeState.employeeType.filter(val => val.value !== "All")} onChange={data => setValue(strings.employeeWork.employmentType, data)} isDisable={true} isViewable={employeeModuleState.isDisable} /></span>
                            {/* <span className={gridFirstSectionLabel}> <Label label="Role"  /></span> <span className={gridSectionValue}><Dropdown value={watch(strings.employeeWork.role)} options={loginReducerState().roles} onChange={data => setValue(strings.employeeWork.role, data)} isDisable={true} /></span> */}
                            <span className={gridFirstSectionLabel}> <Label label="Work Station ID" /></span> <span className={gridSectionValue}><TextField value={watch(strings.employeeWork.workStationId)} onChange={e => setValue(strings.employeeWork.workStationId, e.target.value)} /></span>
                            <span className={gridFirstSectionLabel}> <Label label="System ID" /></span> <span className={gridSectionValue}><TextField value={watch(strings.employeeWork.systemId)} onChange={e => setValue(strings.employeeWork.systemId, e.target.value)} /></span>
                            <span className={gridFirstSectionLabel}> <Label label="Laptop ID" /></span> <span className={gridSectionValue}><TextField value={watch(strings.employeeWork.laptopId)} onChange={e => setValue(strings.employeeWork.laptopId, e.target.value)} /></span>
                        </div>
                        <div className=' grid'>
                            <div className={`grid grid-cols-12 my-2 gap-y-3 items-center`}>
                                <span className={gridSecondSectionLabel}> <Label label="Handles Clinical Samples?" required={true} /></span> <span className={gridSectionValue}><Dropdown value={watch(strings.employeeWork.isHandlesClinicalSamples)} options={employeeState.clinicalUser.filter(val => val.value !== 1)} onChange={data => setValue(strings.employeeWork.isHandlesClinicalSamples, data)} isRequired={true} isViewable={employeeModuleState.isDisable} /></span>
                                <span className='col-start-5 col-end-10 lg:col-end-10 md:col-end-13 sm:col-end-13 xsm:col-end-13 lg:col-start-5 md:col-start-1 sm:col-start-1 xsm:col-start-1'><span className={" col-span-full flex justify-center"}> <span className='font-fontfamily text-12px font-bold uppercase tracking-wider mx-3 ml-0 text-shadow-sm  text-headerColor'>Work Status</span></span></span>
                                <span className={gridSecondSectionLabel}> <Label label="Employment Status" required={true} /></span> <span className={gridSectionValue}><Dropdown value={employmentStatus} options={employeeState.employeeStatus.filter(val => val.value > 2)} onChange={data => setValue(strings.employeeWork.employmentStatus, data)} isRequired={true} isViewable={employeeModuleState.isDisable} /></span>
                                <span className={gridSecondSectionLabel}> <Label label="Confirmation Date" required={handleEmploymentStatusValidity(setDefaultValue.employmentStatus.confirmed)} /></span> <span className={gridSectionValue}><DatePickerElement value={watch(strings.employeeWork.confirmationDate)} onChange={date => setValue(strings.employeeWork.confirmationDate, date)} minDate={watch(strings.employeeWork.dateOfJoining)} isViewable={employeeModuleState.isDisable} isRequired={handleEmploymentStatusValidity(setDefaultValue.employmentStatus.confirmed)} isRemovable /></span>
                                <span className={gridSecondSectionLabel}> <Label label="Relieving Date" required={handleEmploymentStatusValidity(setDefaultValue.employmentStatus.relieved)} /></span> <span className={gridSectionValue}><DatePickerElement value={watch(strings.employeeWork.relievingDate)} onChange={date => setValue(strings.employeeWork.relievingDate, date)} isViewable={employeeModuleState.isDisable} isRequired={handleEmploymentStatusValidity(setDefaultValue.employmentStatus.relieved)} isRemovable /></span>
                                <span className='col-start-5 col-end-10 lg:col-end-10 md:col-end-13 sm:col-end-13 xsm:col-end-13 lg:col-start-5 md:col-start-1 sm:col-start-1 xsm:col-start-1'><span className={" col-span-full flex justify-center"}> <span className='font-fontfamily text-12px font-bold uppercase tracking-wider mx-3 ml-0 text-shadow-sm  text-headerColor'>Visa Details</span></span></span>
                                <span className={gridSecondSectionLabel}> <Label label="Visa type" /></span> <span className={`${gridSectionValue} h-fit`}><TextField value={watch(strings.employeeWork.visaType)} onChange={e => setValue(strings.employeeWork.visaType, e.target.value)} /></span>
                                <span className={gridSecondSectionLabel}> <Label label="Place of Issue" /></span> <span className={`${gridSectionValue} h-fit`}><TextField value={watch(strings.employeeWork.placeOfIssue)} onChange={e => setValue(strings.employeeWork.placeOfIssue, e.target.value)} /></span>
                                <span className={gridSecondSectionLabel}> <Label label="Issue Date" /></span><span className={gridSectionValue}><DatePickerElement value={watch(strings.employeeWork.issueDate)} onChange={date => setValue(strings.employeeWork.issueDate, date)} maxDate={watch(strings.employeeWork.expiryDate) ? watch(strings.employeeWork.expiryDate) : new Date()} isViewable={employeeModuleState.isDisable} /></span>
                                <span className={gridSecondSectionLabel}> <Label label="Expiry Date" /></span><span className={gridSectionValue}><DatePickerElement value={watch(strings.employeeWork.expiryDate)} onChange={date => setValue(strings.employeeWork.expiryDate, date)} minDate={watch(strings.employeeWork.issueDate)} isViewable={employeeModuleState.isDisable} /></span>
                                <span className={gridSecondSectionLabel}> <Label label="Country of Issue" /></span><span className={`${gridSectionValue} h-fit`}><TextField value={watch(strings.employeeWork.countryOfIssue)} onChange={e => setValue(strings.employeeWork.countryOfIssue, e.target.value)} /></span>
                                <span className={gridSecondSectionLabel}> <Label label="Current Location" /></span><span className={gridSectionValue}><Dropdown isMenuTopPlacement={true} value={watch(strings.employeeWork.currentLocation)} options={employeeState.location.filter(val => val.value > 0)} onChange={data => setValue(strings.employeeWork.currentLocation, data)} isViewable={employeeModuleState.isDisable} /></span>
                            </div>
                        </div>
                    </fieldset>
                    {Object.keys(watch(strings.employeeWork.getWorkDetails)).length <= 0
                        ? <div className='flex justify-center items-center mt-4 lg:mt-2 md:mt-0 sm:mt-0 xsm:mt-0 gap-x-3'>
                            {Object.keys(employeeModuleState.personalDetails).length > 0 && <div> <AutoSizeButton value={strings.Buttons.Previous} icon={<MdOutlineKeyboardDoubleArrowLeft size={20} />} onClick={onhandlePrevious} /> </div>}
                            <Button value={strings.Buttons.Save} disabled={handleDisable() && watch(strings.employeeWork.workLocation)} onClick={handleSubmit(onSubmit)} />
                        </div>
                        :
                        <div className=' flex justify-center items-end mt-4 lg:mt-2 md:mt-0 sm:mt-0 xsm:mt-0 gap-x-3'>
                            {employeeModuleState.isDisable || <Button value={Object.keys(watch(strings.employeeWork.getWorkDetails)).length > 0 ? strings.Buttons.Update : strings.Buttons.Save}
                                disabled={handleDisable()} onClick={handleSubmit(onSubmit)} />}
                            <Button value={strings.Buttons.Close} onClick={() => history.push(routerPath.staff)} />
                            {employeeModuleState.isDisable || <Button value={strings.Buttons.Reset} onClick={onReset} />}
                        </div>}
                </div>
            </div>
            {watch(strings.constants.loader) && <TransparentLoader />}
            {apiResponseState.show && <ApiResponse />}
        </div>
    )
}

export default Work

const initialState = {
    employeeCode: "",
    employeeName: "",
    designation: "",
    department: "",
    dateOfJoining: "",
    manager: "",
    grade: {},
    workLocation: "",
    employmentType: {},
    workStationId: "",
    systemId: "",
    laptopId: "",
    isHandlesClinicalSamples: "",
    employmentStatus: "",
    confirmationDate: "",
    relievingDate: "",
    visaType: "",
    placeOfIssue: "",
    issueDate: "",
    expiryDate: "",
    countryOfIssue: "",
    currentLocation: {},
    loader: "",
    getWorkDetails: {},
    role: {}
}