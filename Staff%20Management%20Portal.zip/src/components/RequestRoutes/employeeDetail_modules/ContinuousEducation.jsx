import { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from "react-hook-form";
import HeaderSection from '../../layouts/HeaderSection';
import Label from '../../elements/Label';
import TextField from '../../elements/TextField';
import UploadAndDeleteDocument from '../../elements/UploadAndDeleteDocument';
import Button from '../../elements/Button';
import AgGrid from '../../Grid/AgGrid';
import { employeeDetails } from '../../Grid/Columns';
import { routerPath, strings } from '../../Constants';
import TransparentLoader from '../../loader/TransparentLoader';
import ImageViewer from '../../ViewDocs/ImageViewer';
import { employeeRequests, userRequest } from '../../requests';
import { exportDateFormat, nameConcatenation } from '../../helper';
import ApiResponse from '../../Alert/ApiResponse';
import MultiImageViewer from '../../ViewDocs/MultiImageViewer';


function ContinuousEducation() {
    const gridSectionLabel = "col-start-1 col-end-4 md:col-end-4 sm:col-end-6 xsm:col-end-6";
    const gridSectionValue = `col-start-4 lg:col-start-4 md:col-start-5 col-end-10 lg:col-end-10 md:col-end-13 sm:col-end-13 xsm:col-end-13 lg:col-start-5 md:col-start-7 sm:col-start-7 xsm:col-start-7`;
    const history = useHistory();
    const employeeModuleState = useSelector(state => state.employee.employeeModule);
    const loginResponseState = useSelector(state => state.loginResponse);
    const userState = useSelector(state => state.user);
    const { handleSubmit, watch, setValue, reset } = useForm({ defaultValues: initialState });
    const dispatch = useDispatch();
    const [loader, setLoader] = useState(false);
    const [selectedRecord, setSelectedRecord] = useState([]);

    useEffect(() => {
        const componentDidMount = async () => {
            setLoader(true);
            await onLoad();
            setLoader(false);
        }
        componentDidMount();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const onReset = async () => {
        await setLoader(true);
        const selectedData = watch(strings.continuousEducation.selectedData);
        Object.keys(selectedData).length > 0 ? await selectedDataUpdate(selectedData) : await resetRecords();
        setLoader(false);
    }

    const onLoad = async () => {
        if (employeeModuleState.personal && Object.keys(employeeModuleState.personal).length > 0) {
            await dispatch(employeeRequests.getEducationDetails(employeeModuleState.personal.employeeId, async (isValid, data) => {
                if (isValid) {
                    await setValue(strings.continuousEducation.data, data);
                }
            }));
        }
    }
    const setCallBack = async (isValid) => {
        if (isValid) {
            await resetRecords();
            await onLoad();
        }
    }

    const resetRecords = async () => {
        const data = watch(strings.continuousEducation.data);
        await reset();
        await setValue(strings.continuousEducation.data, data);
    }

    const onSubmit = async (data) => {
        const selectedData = watch(strings.continuousEducation.selectedData);
        setLoader(true);
        if (employeeModuleState.personal && Object.keys(employeeModuleState.personal).length > 0) {
            if (Object.keys(selectedData).length <= 0) {
                await dispatch(employeeRequests.createEducationDetails({
                    conductedBy: data.conductedBy,
                    courseCategory: data.category,
                    courseDescription: data.description,
                    courseDuration: data.duration,
                    courseName: data.courseName,
                    employeeId: employeeModuleState.personal.employeeId,
                    employeeImage: "",
                    employeeImageBinary: "",
                    modifiedBy: userState.UserID,
                    sponsoredBy: data.sponsoredBy,
                    documentList: data.certificateImage.length > 0 ? data.certificateImage.map(val => ({ documentName: val.name, documentBinary: val.binary, recordStatus: "A" })) : []
                }, setCallBack))
            } else {

                let documentLists = data.certificateImage.length > 0 ? data.certificateImage.filter(val => Object.keys(val).length <= 2).map(val => ({ documentName: val.name, documentBinary: val.binary, recordStatus: "A" })) : [];

                if (selectedData.documentList.length > 0) {
                    const documentId = data.certificateImage.map(val => ("id" in val) ? val.id : 0)
                    let deletedDocs = selectedData.documentList.filter(val => !documentId.includes(val.id));
                    if (deletedDocs?.length > 0) {
                        deletedDocs = deletedDocs.map(val => {
                            // eslint-disable-next-line no-unused-vars
                            const { documentName, documentBinary, ...rest } = val;
                            return { ...rest, recordStatus: "D" }
                        })
                        documentLists = [...documentLists, ...deletedDocs];
                    }
                }

                await dispatch(employeeRequests.updateEducationDetails(selectedData.id, {
                    conductedBy: data.conductedBy,
                    courseCategory: data.category,
                    courseDescription: data.description,
                    courseDuration: data.duration,
                    courseName: data.courseName,
                    employeeId: employeeModuleState.personal.employeeId,
                    employeeImage: "",
                    employeeImageBinary: "",
                    modifiedBy: userState.UserID,
                    sponsoredBy: data.sponsoredBy,
                    documentList: documentLists
                }, setCallBack));

            }
        }
        setLoader(false);
    }
    const selectedDataUpdate = async (selectedData) => {
        await setValue(strings.continuousEducation.courseName, selectedData.courseName);
        await setValue(strings.continuousEducation.conductedBy, selectedData.conductedBy);
        await setValue(strings.continuousEducation.sponsoredBy, selectedData.sponsoredBy);
        await setValue(strings.continuousEducation.duration, selectedData.courseDuration);
        await setValue(strings.continuousEducation.description, selectedData.courseDescription);
        await setValue(strings.continuousEducation.category, selectedData.courseCategory);
        await setValue(strings.continuousEducation.certificateImage, selectedData.documentList && selectedData.documentList.length > 0 ? selectedData.documentList.map(val => {
            const { documentName, documentBinary, ...rest } = val;
            return { ...rest, name: documentName, binary: documentBinary };
        }) : []);
        await setValue(strings.continuousEducation.data, watch(strings.continuousEducation.data));
        await setValue(strings.continuousEducation.selectedData, { ...selectedData });
    }
    const setEditBack = async (selectedData, type) => {
        await setLoader(true);
        if (type === "isEdit") {
            await dispatch(employeeRequests.getCourseData(selectedData.id, async (isValid, data) => {
                if (isValid) {
                    await selectedDataUpdate({ ...data, id: selectedData.id });
                    await onLoad();
                }
            }));
        }
        else {
            setSelectedRecord(selectedData);
            await dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to delete "${selectedData.courseName}" course record?`, isOptional: true }));
        }
        setLoader(false);
    }
    const onhandleDelete = async (isAccepted) => {
        if (isAccepted) {
            setLoader(true);
            const userInfo = {
                modifiedBy: userState.UserID,
                modifiedDate: exportDateFormat(new Date())
            }
            await dispatch(employeeRequests.deleteEducationDetails(selectedRecord.id, userInfo, setCallBack));
            setLoader(false);
        }
        setSelectedRecord({});
    }

    return (
        <div>
            <HeaderSection redirectType={strings.type.employeeDetails} employeeName={Object.keys(employeeModuleState.personal).length > 0 ? employeeModuleState.personal.employeeName : nameConcatenation(employeeModuleState.data)} />
            <div>
                <fieldset className='pt-4 px-6 overflow-auto h-auto md:max-h-h_body_md sm:max-h-full' disabled={employeeModuleState.isDisable}>
                    <div className={"font-fontfamily font-bold text-14px grid grid-cols-2 lg:grid-cols-2 md:grid-cols-1 sm:grid-cols-1 xsm:grid-cols-1"}>
                        <div className={`grid grid-cols-12 my-2 gap-y-2 items-center`}>
                            <span className={gridSectionLabel}> <Label label="Course Name" required={true} /></span> <span className={gridSectionValue} ><TextField value={watch(strings.continuousEducation.courseName)} onChange={e => setValue(strings.continuousEducation.courseName, e.target.value)} isRequired={true} /></span>
                            <span className={gridSectionLabel}> <Label label="Conducted By" required={true} /></span> <span className={gridSectionValue} ><TextField value={watch(strings.continuousEducation.conductedBy)} onChange={e => setValue(strings.continuousEducation.conductedBy, e.target.value)} isRequired={true} /></span>
                            <span className={gridSectionLabel}> <Label label="Sponsored By" required={true} /></span> <span className={gridSectionValue} ><TextField value={watch(strings.continuousEducation.sponsoredBy)} onChange={e => setValue(strings.continuousEducation.sponsoredBy, e.target.value)} isRequired={true} /></span>
                            <span className={gridSectionLabel}> <Label label="Duration" required={true} /></span> <span className={gridSectionValue} ><TextField value={watch(strings.continuousEducation.duration)} onChange={e => setValue(strings.continuousEducation.duration, e.target.value)} isRequired={true} /></span>
                            <span className={gridSectionLabel}> <Label label="Description" /></span> <span className={gridSectionValue} ><TextField value={watch(strings.continuousEducation.description)} onChange={e => setValue(strings.continuousEducation.description, e.target.value)} /></span>
                            <span className={gridSectionLabel}> <Label label="Category" required={true} /></span> <span className={gridSectionValue} ><TextField value={watch(strings.continuousEducation.category)} onChange={e => setValue(strings.continuousEducation.category, e.target.value)} isRequired={true} /></span>
                            <span className={gridSectionLabel}> <Label label="Certificate Image" /></span> <span className={gridSectionValue} ><UploadAndDeleteDocument label={"Choose File"} file={watch(strings.continuousEducation.certificateImage)} onChange={file => setValue(strings.continuousEducation.certificateImage, file)} isViewable={employeeModuleState.isDisable} isMultiDocument /></span>
                        </div>
                    </div>
                    <div className=' flex justify-center items-center gap-3 my-3 lg:my-3 md:my-1 sm:my-0 xsm:my-0'>
                        {employeeModuleState.isDisable || <Button value={Object.keys(watch(strings.continuousEducation.selectedData)).length > 0 ? strings.Buttons.Update : strings.Buttons.Save} disabled={!(watch(strings.continuousEducation.courseName) && watch(strings.continuousEducation.conductedBy) && watch(strings.continuousEducation.sponsoredBy) && watch(strings.continuousEducation.duration) && watch(strings.continuousEducation.category))} onClick={handleSubmit(onSubmit)} />}
                        {employeeModuleState.isDisable && <Button value={strings.Buttons.CustomClear} onClick={() => resetRecords()} />}
                        <Button value={strings.Buttons.Close} onClick={() => history.push(routerPath.staff)} />
                        {employeeModuleState.isDisable || <Button value={strings.Buttons.Reset} onClick={() => onReset()} />}
                    </div>
                    <AgGrid data={watch(strings.continuousEducation.data)} columns={employeeDetails.continuousEducationColumns(setLoader, loginResponseState.isMobileCompatible, setEditBack)} height="h-[calc(93vh-336px-3.5rem-48px-4.6rem-6rem)] md:h-[calc(93vh-336px-3.5rem-48px-4.6rem-6rem)] xsm:h-[20rem]" ContextMenuItems={loginResponseState.isMobileCompatible ? false : employeeDetails.continuousEducation_contextMenuItems} history={history} callBack={setEditBack} isAutoHeight maxScrollCount={5} />
                </fieldset>
            </div>
            {loader && <TransparentLoader />}
            {!loginResponseState.multiDocumentViewer.show && loginResponseState.imageViewer.show && <ImageViewer />}
            {loginResponseState.multiDocumentViewer.show && <MultiImageViewer />}
            {loginResponseState.apiResponse.show && <ApiResponse setResponseCallback={onhandleDelete} />}
        </div>
    )
}

export default ContinuousEducation

const initialState = {
    courseName: "",
    conductedBy: "",
    sponsoredBy: "",
    duration: "",
    description: "",
    category: "",
    certificateImage: [],
    data: [],
    selectedData: {}
}