import { useEffect } from 'react';
import HeaderSection from '../../layouts/HeaderSection';
import TextField from '../../elements/TextField';
import RadioButton from '../../elements/RadioButton';
import Label from '../../elements/Label';
import Dropdown from '../../elements/Dropdown';
import { BsPersonSquare } from 'react-icons/bs';
import DatePickerElement from '../../elements/DatePickerElement';
import UploadAndDeleteDocument from '../../elements/UploadAndDeleteDocument';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Button from '../../elements/Button';
import { exportDateFormat, genderOptions, maritalStatusOptions, nameConcatenation, numberValidation, userReducerState } from '../../helper';
import { routerPath, setDefaultValue, strings } from '../../Constants';
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from 'react-redux';
import { employeeRequests, loginRequest } from '../../requests';
import TransparentLoader from '../../loader/TransparentLoader';
import { useHistory } from 'react-router-dom';
import ApiResponse from '../../Alert/ApiResponse';
import moment from 'moment-timezone';
import ImageViewer from '../../ViewDocs/ImageViewer';
import PasswordField from '../../elements/PasswordField';
import AutoSizeButton from '../../elements/AutoSizeButton';
import { MdKeyboardDoubleArrowRight } from "react-icons/md";
import { employeeActions } from '../../../redux/employeeReducer';

function Personal() {
  const gridFirstSectionLabel = "col-start-1 col-end-4 md:col-end-4 sm:col-end-6 xsm:col-end-6";
  const gridSectionValue = `col-start-5 col-end-10 lg:col-end-10 md:col-end-13 sm:col-end-13 xsm:col-end-13 lg:col-start-5 md:col-start-7 sm:col-start-7 xsm:col-start-7`;
  const gridSecondSectionLabel = "col-start-2 lg:col-start-2 md:col-start-1 sm:col-start-1 xsm:col-start-1 col-end-4 lg:col-end-4 md:col-end-6 sm:col-end-6 xsm:col-end-6 pt-2";

  const employeeModuleState = useSelector(state => state.employee.employeeModule);
  const loginResponseState = useSelector(state => state.loginResponse);
  const { handleSubmit, watch, setValue, reset } = useForm({ defaultValues: initialState });
  const image = watch(strings.employeePersonal.photo);
  const maritalStatus = watch(strings.employeePersonal.maritalStatus);
  const panSsnDlOptions = watch(strings.employeePersonal.panSsnDlOptions);
  const dispatch = useDispatch();
  const history = useHistory();



  useEffect(() => {
    try {
      onLoadData();
    }
    catch (e) {
      console.error(e);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const setCallBack = async (isSuccess, response, data) => {
    if (isSuccess) {
      const personalDetails = employeeModuleState.personal && Object.keys(employeeModuleState.personal).length > 0 ? { ...employeeModuleState.personal } : Object.keys(employeeModuleState.data).length > 0 ? { ...employeeModuleState.data } : {}
      await Promise.all([
        employeeModuleState.personal && Object.keys(employeeModuleState.personal).length <= 0 && dispatch(employeeRequests.employeeName()),
        employeeModuleState.personal && Object.keys(employeeModuleState.personal).length <= 0 && dispatch(loginRequest.employeeName()),
        dispatch(employeeRequests.setEmployeeModule({ ...employeeModuleState, personal: { ...personalDetails, ...data, ...response } })),
      ]);
      await history.push(routerPath.employeeWork);
    }
  }

  const onSubmit = async (data) => {
    await setValue(strings.constants.loader, true);
    if (employeeModuleState.personal && Object.keys(employeeModuleState.personal).length > 0) {
      await dispatch(employeeRequests.updateEmployee_Personal(employeeModuleState.personal.employeeId, {
        childNos: Number(data.noOfChildren),
        siblingsNo: data.noOfSiblings,
        dob: isNaN(new Date(data.dateOfBirth)) ? "" : exportDateFormat(data.dateOfBirth, true),
        employeeCode: employeeModuleState.personal.employeeCode,
        expiryDate: isNaN(new Date(data.expiryDate)) ? "" : exportDateFormat(data.expiryDate, true),
        fatherName: data.fatherName,
        firstName: data.firstName,
        gender: data.gender,
        idProofImageBinary: data.panSsnDlDocs.length > 0 ? data.panSsnDlDocs[0].binary : "",
        idProofImg: data.panSsnDlDocs.length > 0 ? data.panSsnDlDocs[0].name : "",
        image: data.photo.length > 0 ? data.photo[0].name : "",
        issueDate: isNaN(new Date(data.issueDate)) ? "" : exportDateFormat(data.issueDate, true),
        issuePlace: data.issuePlace,
        lastName: data.lastName,
        maritalStatus: Object.keys(data.maritalStatus).length > 0 ? data.maritalStatus.label : "",
        middleName: data.middleName,
        modifiedBy: userReducerState().UserID,
        motherName: data.motherName,
        nationality: data.nationality,
        panSsn: data.panSsnDlOptions,
        panSsnNumber: data.panSsnDlOptions === "PAN" ? data.panNo : data.panSsnDlOptions === "SSN" ? data.ssnNo1 + data.ssnNo2 + data.ssnNo3 : data.drivingLicenceNo,
        passportImage: data.passport.length > 0 ? data.passport[0].name : "",
        passportImageBinary: data.passport.length > 0 ? data.passport[0].binary : "",
        passportNo: data.passportNumber,
        photoImageBinary: data.photo.length > 0 ? data.photo[0].binary : "",
        recordStatus: employeeModuleState.personal.recordStatus,
        spouseName: data.spouseName,
      }, setCallBack))
    }
    else {
      const employeePersonalAPIParams = {
        employeeCode: employeeModuleState.data.employeeCode,
        childNos: Number(data.noOfChildren), // watch(strings.employeePersonal.noOfChildren),
        siblingsNo: data.noOfSiblings,
        createdBy: userReducerState().UserID,
        dob: isNaN(new Date(data.dateOfBirth)) ? "" : exportDateFormat(data.dateOfBirth, true),
        expiryDate: isNaN(new Date(data.expiryDate)) ? "" : exportDateFormat(data.expiryDate, true),
        fatherName: data.fatherName,
        firstName: data.firstName,
        gender: data.gender,
        image: data.photo.length > 0 ? data.photo[0].name : "",
        photoImageBinary: data.photo.length > 0 ? data.photo[0].binary : "",
        issueDate: isNaN(new Date(data.issueDate)) ? "" : exportDateFormat(data.issueDate, true),
        issuePlace: data.issuePlace,
        lastName: data.lastName,
        maritalStatus: Object.keys(data.maritalStatus).length > 0 ? data.maritalStatus.label : "",
        middleName: data.middleName,
        modifiedBy: userReducerState().UserID,
        modifiedDate: exportDateFormat(new Date()),
        motherName: data.motherName,
        nationality: data.nationality,
        panSsn: data.panSsnDlOptions,
        panSsnNumber: data.panSsnDlOptions === "PAN" ? data.panNo : data.panSsnDlOptions === "SSN" ? data.ssnNo1 + data.ssnNo2 + data.ssnNo3 : data.drivingLicenceNo,
        idProofImg: data.panSsnDlDocs.length > 0 ? data.panSsnDlDocs[0].name : "",
        idProofImageBinary: data.panSsnDlDocs.length > 0 ? data.panSsnDlDocs[0].binary : "",
        passportImage: data.passport.length > 0 ? data.passport[0].name : "",
        passportNo: data.passportNumber,
        passportImageBinary: data.passport.length > 0 ? data.passport[0].binary : "",
        spouseName: data.spouseName,
      }
      await dispatch(employeeActions.setEmployeeModule({ ...employeeModuleState, personalDetails: { data, params: employeePersonalAPIParams } }));
      await history.push(routerPath.employeeWork);

      // employeeModuleState.data && Object.keys(employeeModuleState.data).length > 0 && await dispatch(employeeRequests.createEmployee_Personal(employeeModuleState.data.loginId, {
      //   employeeCode: employeeModuleState.data.employeeCode,
      //   childNos: Number(data.noOfChildren), // watch(strings.employeePersonal.noOfChildren),
      //   siblingsNo: data.noOfSiblings,
      //   createdBy: userReducerState().UserID,
      //   dob: isNaN(new Date(data.dateOfBirth)) ? "" : exportDateFormat(data.dateOfBirth, true),
      //   expiryDate: isNaN(new Date(data.expiryDate)) ? "" : exportDateFormat(data.expiryDate, true),
      //   fatherName: data.fatherName,
      //   firstName: data.firstName,
      //   gender: data.gender,
      //   image: data.photo.length > 0 ? data.photo[0].name : "",
      //   photoImageBinary: data.photo.length > 0 ? data.photo[0].binary : "",
      //   issueDate: isNaN(new Date(data.issueDate)) ? "" : exportDateFormat(data.issueDate, true),
      //   issuePlace: data.issuePlace,
      //   lastName: data.lastName,
      //   maritalStatus: Object.keys(data.maritalStatus).length > 0 ? data.maritalStatus.label : "",
      //   middleName: data.middleName,
      //   modifiedBy: userReducerState().UserID,
      //   modifiedDate: exportDateFormat(new Date()),
      //   motherName: data.motherName,
      //   nationality: data.nationality,
      //   panSsn: data.panSsnDlOptions,
      //   panSsnNumber: data.panSsnDlOptions === "PAN" ? data.panNo : data.panSsnDlOptions === "SSN" ? data.ssnNo1 + data.ssnNo2 + data.ssnNo3 : data.drivingLicenceNo,
      //   idProofImg: data.panSsnDlDocs.length > 0 ? data.panSsnDlDocs[0].name : "",
      //   idProofImageBinary: data.panSsnDlDocs.length > 0 ? data.panSsnDlDocs[0].binary : "",
      //   passportImage: data.passport.length > 0 ? data.passport[0].name : "",
      //   passportNo: data.passportNumber,
      //   passportImageBinary: data.passport.length > 0 ? data.passport[0].binary : "",
      //   spouseName: data.spouseName,
      // }, setCallBack));
    }
    setValue(strings.constants.loader, false);
  };

  const panSsnDlOptionChange = (value) => {
    setValue(strings.employeePersonal.panSsnDlOptions, value);
    if (value !== "PAN") {
      setValue(strings.employeePersonal.panNo, "");
    }
    if (value !== "SSN") {
      setValue(strings.employeePersonal.ssnNo1, "");
      setValue(strings.employeePersonal.ssnNo2, "");
      setValue(strings.employeePersonal.ssnNo3, "");
    }
    if (value !== "DL") {
      setValue(strings.employeePersonal.drivingLicenceNo, "");
    }
  };

  const onLoadData = () => {
    if (employeeModuleState.data && Object.keys(employeeModuleState.data).length > 0) {
      setValue(strings.employeePersonal.employeeCode, employeeModuleState.data.employeeCode);
      setValue(strings.employeePersonal.firstName, employeeModuleState.data.firstName);
      setValue(strings.employeePersonal.middleName, employeeModuleState.data.middleName);
      setValue(strings.employeePersonal.lastName, employeeModuleState.data.lastName);
    }
    if (employeeModuleState.personal && Object.keys(employeeModuleState.personal).length > 0) {
      const personalState = Object.entries({ ...employeeModuleState.personal });
      for (const keypairs of personalState) {
        if (keypairs.length === 2 && Object.keys(initialState).includes(keypairs[0]) && keypairs[1]) {
          if (keypairs[0] === strings.employeePersonal.maritalStatus) {
            keypairs[1].length > 0 && setValue(keypairs[0], maritalStatusOptions.find(val => val.label === keypairs[1]));
          }
          else if (keypairs[0] === strings.employeePersonal.issueDate || keypairs[0] === strings.employeePersonal.expiryDate) {
            keypairs[1] && setValue(keypairs[0], new Date(keypairs[1]));
          }
          else {
            setValue(keypairs[0], keypairs[1]);
          }
        }
        else if (keypairs.length === 2 && keypairs[0] === "childNos" && keypairs[1] && typeof (Number(keypairs[1])) === "number") {
          setValue(strings.employeePersonal.noOfChildren, Number(keypairs[1]));
        }
        else if (keypairs.length === 2 && keypairs[0] === "siblingsNo" && keypairs[1]) {
          setValue(strings.employeePersonal.noOfSiblings, keypairs[1]);
        }
        else if (keypairs.length === 2 && keypairs[0] === "dob" && keypairs[1]) {
          setValue(strings.employeePersonal.dateOfBirth, new Date(keypairs[1]));
        }
        else if (keypairs.length === 2 && keypairs[0] === "panSsn" && keypairs[1]) {
          setValue(strings.employeePersonal.panSsnDlOptions, keypairs[1]);
        }
        else if (keypairs.length === 2 && keypairs[0] === "panSsnNumber" && keypairs[1]) {
          const panSsnOptions = employeeModuleState.personal["panSsn"];
          if (panSsnOptions === "PAN") {
            setValue(strings.employeePersonal.panNo, keypairs[1]);
          }
          else if (panSsnOptions === "SSN" && keypairs[1].length === 9) {
            setValue(strings.employeePersonal.ssnNo1, keypairs[1].slice(0, 3));
            setValue(strings.employeePersonal.ssnNo2, keypairs[1].slice(3, 5));
            setValue(strings.employeePersonal.ssnNo3, keypairs[1].slice(5, 9));
          }
          else if (panSsnOptions === "DL") {
            setValue(strings.employeePersonal.drivingLicenceNo, keypairs[1]);
          }
        }
        else if (keypairs.length === 2 && keypairs[0] === "image" && keypairs[0].length > 0 && keypairs[1]) {
          setValue(strings.employeePersonal.photo, [{ name: keypairs[1], binary: employeeModuleState.personal["photoImageBinary"] }]);
        }
        else if (keypairs.length === 2 && keypairs[0] === "idProofImg" && keypairs[0].length > 0 && keypairs[1]) {
          setValue(strings.employeePersonal.panSsnDlDocs, [{ name: keypairs[1], binary: employeeModuleState.personal["idProofImageBinary"] }]);
        }
        else if (keypairs.length === 2 && keypairs[0] === "passportImage" && keypairs[0].length > 0 && keypairs[1]) {
          setValue(strings.employeePersonal.passport, [{ name: keypairs[1], binary: employeeModuleState.personal["passportImageBinary"] }]);
        }
        else if (keypairs.length === 2 && keypairs[0] === "passportNo" && keypairs[0].length > 0 && keypairs[1]) {
          setValue(strings.employeePersonal.passportNumber, employeeModuleState.personal["passportNo"]);
        }
      }
    } else if (Object.keys(employeeModuleState.personalDetails).length > 0) {
      reset(employeeModuleState.personalDetails.data);
    }
  }

  const onReset = () => {
    reset();
    onLoadData();
  }

  return (
    <>
      <HeaderSection redirectType={strings.type.employeeDetails} employeeName={Object.keys(employeeModuleState.personal).length > 0 ? employeeModuleState.personal.employeeName : nameConcatenation(employeeModuleState.data)} />
      <div>
        <div className='pt-1 px-6 overflow-auto h-auto md:max-h-h_body_md sm:max-h-full'>
          <fieldset className={"font-fontfamily font-bold text-14px grid grid-cols-2 lg:grid-cols-2 md:grid-cols-1 sm:grid-cols-1 xsm:grid-cols-1"} disabled={employeeModuleState.isDisable}>
            <div className={`grid grid-cols-12 mt-2 gap-y-2 items-center`}>
              <span className={gridFirstSectionLabel}> <Label label="Employee Code" /></span> <span className={gridSectionValue} ><TextField value={watch(strings.employeePersonal.employeeCode)} isDisable={true} onChange={e => setValue(strings.employeePersonal.employeeCode, e.target.value)} /></span>
              <span className={gridFirstSectionLabel}> <Label label="First Name" required={true} /> </span> <span className={gridSectionValue}><TextField value={watch(strings.employeePersonal.firstName)} onChange={e => setValue(strings.employeePersonal.firstName, e.target.value)} isDisable={true} isRequired={true} /></span>
              <span className={gridFirstSectionLabel}> <Label label="Middle Name" /></span> <span className={gridSectionValue}><TextField value={watch(strings.employeePersonal.middleName)} onChange={e => setValue(strings.employeePersonal.middleName, e.target.value)} isDisable={true} /></span>
              <span className={gridFirstSectionLabel}> <Label label="Last Name" required={true} /></span> <span className={gridSectionValue}><TextField value={watch(strings.employeePersonal.lastName)} onChange={e => setValue(strings.employeePersonal.lastName, e.target.value)} isDisable={true} isRequired={true} /></span>
              <span className={gridFirstSectionLabel}> <Label label="Gender" required={true} /></span> <span className={gridSectionValue}><RadioButton options={genderOptions.map(val => val.label)} value={watch(strings.employeePersonal.gender)} onChange={e => setValue(strings.employeePersonal.gender, e.target.value)} isRequired={true} /></span>
              <span className={`${gridFirstSectionLabel}`}> <Label label="Date of Birth" required={true} /></span> <span className={`${gridSectionValue} mb-1`}><DatePickerElement value={watch(strings.employeePersonal.dateOfBirth)} onChange={date => setValue(strings.employeePersonal.dateOfBirth, date)} maxDate={moment().subtract(18, 'years')} isRequired={true} isViewable={employeeModuleState.isDisable} /></span>
              <span className={gridFirstSectionLabel}> <Label label="Father Name" /></span> <span className={gridSectionValue}><TextField value={watch(strings.employeePersonal.fatherName)} onChange={e => setValue(strings.employeePersonal.fatherName, e.target.value)} /></span>
              <span className={gridFirstSectionLabel}> <Label label="Mother Name" /></span> <span className={gridSectionValue}><TextField value={watch(strings.employeePersonal.motherName)} onChange={e => setValue(strings.employeePersonal.motherName, e.target.value)} /></span>
              <span className={gridFirstSectionLabel}> <Label label="Marital Status" required={true} /></span> <span className={gridSectionValue}><Dropdown options={maritalStatusOptions} value={maritalStatus} onChange={data => { setValue(strings.employeePersonal.maritalStatus, data); data.value === 1 && setValue(strings.employeePersonal.spouseName, ""); data.value === 1 && setValue(strings.employeePersonal.noOfChildren, ""); }} isRequired={true} isViewable={employeeModuleState.isDisable} /></span>
              <span className={gridFirstSectionLabel}> <Label label="Spouse Name" /></span> <span className={gridSectionValue}><TextField value={watch(strings.employeePersonal.spouseName)} onChange={e => setValue(strings.employeePersonal.spouseName, e.target.value)} isDisable={!!(maritalStatus && Object.keys(maritalStatus).length > 0 && ("value" in maritalStatus) && maritalStatus.value === 1)} /></span>
              <span className={gridFirstSectionLabel}> <Label label="Number of Children" /></span> <span className={gridSectionValue}><TextField value={watch(strings.employeePersonal.noOfChildren)} type={"number"} onChange={e => e.target.validationMessage.length <= 0 && numberValidation(e.target.value, 2, 1, 20) && setValue(strings.employeePersonal.noOfChildren, e.target.value)} isDisable={!!(maritalStatus && Object.keys(maritalStatus).length > 0 && ("value" in maritalStatus) && maritalStatus.value === 1)} /></span>
              <span className={gridFirstSectionLabel}> <Label label="Number of Siblings" /></span> <span className={gridSectionValue}><TextField value={watch(strings.employeePersonal.noOfSiblings)} type={"number"} onChange={e => e.target.validationMessage.length <= 0 && numberValidation(e.target.value, 2, 1, 20) && setValue(strings.employeePersonal.noOfSiblings, e.target.value)} /></span>
              <span className={`${gridFirstSectionLabel} self-start pt-2`}> <Label label={((Object.keys(employeeModuleState.personal).length > 0 ? employeeModuleState.personal.locationId : employeeModuleState.data.locationId) === setDefaultValue.location.value) ? "PAN/DL Number" : "SSN/DL Number"} /></span> <span className={gridSectionValue}>
                <RadioGroup row={false} value={panSsnDlOptions} onChange={e => panSsnDlOptionChange(e.target.value)} className='font-fontfamily text-12px' >
                  {((Object.keys(employeeModuleState.personal).length > 0 ? employeeModuleState.personal.locationId : employeeModuleState.data.locationId) === setDefaultValue.location.value) ? <div className=' flex flex-row'> <FormControlLabel value={"PAN"} className=' min-w-16' control={<Radio sx={{ color: "grey", '&.Mui-checked': { color: "#ef4641", }, }} />} label={<Label label="PAN" />} /><TextField value={watch(strings.employeePersonal.panNo)} isDisable={panSsnDlOptions !== "PAN"} onChange={e => setValue(strings.employeePersonal.panNo, e.target.value)} /></div>
                    : <div className=' flex flex-row my-2 w-full h-full'><FormControlLabel value={"SSN"} control={<Radio sx={{ color: "grey", '&.Mui-checked': { color: "#ef4641", }, }} />} label={<Label label="SSN" />} /><PasswordField maxLength={3} isSpacer={true} value={watch(strings.employeePersonal.ssnNo1)} onChange={e => e.target.value.length <= 3 && setValue(strings.employeePersonal.ssnNo1, e.target.value)} isDisable={panSsnDlOptions !== "SSN"} /><span className=' mx-1' /><PasswordField maxLength={2} isSpacer={true} value={watch(strings.employeePersonal.ssnNo2)} onChange={e => e.target.value.length <= 2 && setValue(strings.employeePersonal.ssnNo2, e.target.value)} isDisable={panSsnDlOptions !== "SSN"} /><span className=' mx-1' /><PasswordField type="password" maxLength={4} isSpacer={true} value={watch(strings.employeePersonal.ssnNo3)} onChange={e => e.target.value.length <= 4 && setValue(strings.employeePersonal.ssnNo3, e.target.value)} isDisable={panSsnDlOptions !== "SSN"} /></div>}
                  <div className=' flex flex-row'><FormControlLabel value={"DL"} className=' min-w-16' control={<Radio sx={{ color: "grey", '&.Mui-checked': { color: "#ef4641", }, }} />} label={<Label label="DL" />} /><TextField value={watch(strings.employeePersonal.drivingLicenceNo)} onChange={e => setValue(strings.employeePersonal.drivingLicenceNo, e.target.value)} isDisable={panSsnDlOptions !== "DL"} /></div>
                </RadioGroup>
              </span>
              <span className={`${gridSectionValue} h-min`}><UploadAndDeleteDocument label="Upload ID Proof" onChange={file => setValue(strings.employeePersonal.panSsnDlDocs, file)} file={watch(strings.employeePersonal.panSsnDlDocs)} isViewable={employeeModuleState.isDisable} /></span>
            </div>
            <div className=' grid order-last lg:order-last md:order-first sm:order-first xsm:order-first'>

              <div className={`grid grid-cols-12 my-2 gap-y-2 items-center`}>
                <span className='col-start-5 col-end-10 lg:col-end-10 md:col-end-13 sm:col-end-13 xsm:col-end-13 lg:col-start-5 md:col-start-1 sm:col-start-1 xsm:col-start-1'><span className='flex w-full h-full justify-center items-center mt-4 pb-6'> {image && image.length > 0 ? <img className=' h-40 w-40 rounded mx-auto' src={`data:image/jpeg/png;base64,${image[0].binary}`} alt='#' /> : <BsPersonSquare size={160} color='#c6362e' />}</span></span>
                <span className={gridSecondSectionLabel}> <Label label="Photo" /></span> <span className={gridSectionValue}><UploadAndDeleteDocument label="Upload Employee Photo" onChange={file => setValue(strings.employeePersonal.photo, file)} file={image} isImageView={true} isViewable={employeeModuleState.isDisable} /></span>
                <span className={gridSecondSectionLabel}></span><span className={gridSectionValue}></span>
                <span className='col-start-5 col-end-10 lg:col-end-10 md:col-end-13 sm:col-end-13 xsm:col-end-13 lg:col-start-5 md:col-start-1 sm:col-start-1 xsm:col-start-1'><span className={" col-span-full flex justify-center"}> <span className='font-fontfamily text-12px font-bold uppercase tracking-wider mx-3 ml-0 text-shadow-sm  text-headerColor'>Passport Details</span></span></span>
                <span className={gridSecondSectionLabel}> <Label label="Nationality" required={true} /></span> <span className={`${gridSectionValue} h-fit`}><TextField value={watch(strings.employeePersonal.nationality)} onChange={e => setValue(strings.employeePersonal.nationality, e.target.value)} isRequired={true} /></span>
                <span className={gridSecondSectionLabel}> <Label label="Passport Number" /></span> <span className={`${gridSectionValue} h-fit`}><TextField value={watch(strings.employeePersonal.passportNumber)} onChange={e => setValue(strings.employeePersonal.passportNumber, e.target.value)} /></span>
                <span className={gridSecondSectionLabel}> <Label label="Issue Place" /></span> <span className={`${gridSectionValue} h-fit`}><TextField value={watch(strings.employeePersonal.issuePlace)} onChange={e => setValue(strings.employeePersonal.issuePlace, e.target.value)} /></span>
                <span className={gridSecondSectionLabel}> <Label label="Issue Date" /></span> <span className={gridSectionValue}><DatePickerElement value={watch(strings.employeePersonal.issueDate)} onChange={(date) => setValue(strings.employeePersonal.issueDate, date)} maxDate={watch(strings.employeePersonal.expiryDate) ? watch(strings.employeePersonal.expiryDate) : new Date()} /></span>
                <span className={gridSecondSectionLabel}> <Label label="Expiry Date" /></span> <span className={gridSectionValue}><DatePickerElement value={watch(strings.employeePersonal.expiryDate)} onChange={(date) => setValue(strings.employeePersonal.expiryDate, date)} minDate={watch(strings.employeePersonal.issueDate)} /></span>
                <span className={gridSecondSectionLabel}></span><span className={gridSectionValue}><UploadAndDeleteDocument label={"Upload Passport"} onChange={file => setValue(strings.employeePersonal.passport, file)} file={watch(strings.employeePersonal.passport)} isViewable={employeeModuleState.isDisable} /></span>
                <span className={gridSecondSectionLabel}></span><span className={gridSectionValue}></span>
                <span className={gridSecondSectionLabel}></span><span className={gridSectionValue}></span>
              </div>
            </div>
          </fieldset>
          {Object.keys(employeeModuleState.personal).length <= 0
            ? <div className='flex justify-center items-center'><div>
              <AutoSizeButton value={strings.Buttons.Next} disabled={!(watch(strings.employeePersonal.firstName) && watch(strings.employeePersonal.lastName) && watch(strings.employeePersonal.gender) && watch(strings.employeePersonal.dateOfBirth) && watch(strings.employeePersonal.maritalStatus) && watch(strings.employeePersonal.nationality))} isIconLastPos icon={<MdKeyboardDoubleArrowRight size={20} />} onClick={handleSubmit(onSubmit)} />
            </div></div>
            : <div className=' flex justify-center items-center gap-x-3'>
              {employeeModuleState.isDisable || <Button value={strings.Buttons.Update} disabled={!(watch(strings.employeePersonal.firstName) && watch(strings.employeePersonal.lastName) && watch(strings.employeePersonal.gender) && watch(strings.employeePersonal.dateOfBirth) && watch(strings.employeePersonal.maritalStatus) && watch(strings.employeePersonal.nationality))} onClick={handleSubmit(onSubmit)} />}
              <Button value={strings.Buttons.Close} onClick={() => history.push(routerPath.staff)} />
              {employeeModuleState.isDisable || <Button value={strings.Buttons.Reset} onClick={() => onReset()} />}
            </div>}
        </div>
      </div>
      {watch(strings.constants.loader) && <TransparentLoader />}
      {loginResponseState.imageViewer.show && <ImageViewer />}
      {loginResponseState.apiResponse.show && <ApiResponse />}
    </>
  )
}

export default Personal

const initialState = {
  employeeCode: "",
  firstName: "",
  middleName: "",
  lastName: "",
  gender: "",
  dateOfBirth: "",
  fatherName: "",
  motherName: "",
  maritalStatus: "",
  spouseName: "",
  noOfChildren: "",
  noOfSiblings: "",
  panNo: "",
  ssnNo1: "",
  ssnNo2: "",
  ssnNo3: "",
  drivingLicenceNo: "",
  photo: [],
  nationality: "",
  issuePlace: "",
  issueDate: "",
  expiryDate: "",
  passport: [],
  passportNumber: "",
  panSsnDlOptions: "",
  panSsnDlDocs: [],
  loader: false
}

