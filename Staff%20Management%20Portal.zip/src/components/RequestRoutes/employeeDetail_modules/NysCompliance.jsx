import { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from "react-hook-form";
import HeaderSection from '../../layouts/HeaderSection';
import Label from '../../elements/Label';
import TextField from '../../elements/TextField';
import UploadAndDeleteDocument from '../../elements/UploadAndDeleteDocument';
import Button from '../../elements/Button';
import AgGrid from '../../Grid/AgGrid';
import { employeeDetails } from '../../Grid/Columns';
import { routerPath, strings } from '../../Constants';
import TransparentLoader from '../../loader/TransparentLoader';
import ImageViewer from '../../ViewDocs/ImageViewer';
import { employeeRequests, userRequest } from '../../requests';
import { exportDateFormat, nameConcatenation } from '../../helper';
import ApiResponse from '../../Alert/ApiResponse';
import DatePickerElement from '../../elements/DatePickerElement';
import Dropdown from '../../elements/Dropdown';
import MultiImageViewer from '../../ViewDocs/MultiImageViewer';
import CheckBox from '../../elements/CheckBox';


function NysCompliance() {
    const gridSectionLabel = "col-start-1 col-end-4 lg:col-end-3 md:col-end-4 sm:col-end-6 xsm:col-end-6";
    const gridSectionValue = `col-start-5 col-end-10 lg:col-end-6 md:col-end-13 sm:col-end-13 xsm:col-end-13 lg:col-start-3 md:col-start-7 sm:col-start-7 xsm:col-start-7`;
    const history = useHistory();
    const employeeState = useSelector(state => state.employee);
    const employeeModuleState = useSelector(state => state.employee.employeeModule);
    const loginResponseState = useSelector(state => state.loginResponse);
    const userState = useSelector(state => state.user);
    const { handleSubmit, watch, setValue, reset } = useForm({ defaultValues: initialState });
    const dispatch = useDispatch();
    const [loader, setLoader] = useState(false);
    const [selectedRecord, setSelectedRecord] = useState({});

    useEffect(() => {
        const componentDidMount = async () => {
            await setLoader(true);
            await onLoad();
            await Promise.all([
                employeeState.nysCompliancePeriod.length <= 0 && dispatch(employeeRequests.getCompliancePeriod()),
                employeeState.nysComplianceCategory.length <= 0 && dispatch(employeeRequests.getComplianceCategory())
            ]);
            setLoader(false);
        }
        componentDidMount();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const onReset = async () => {
        await setLoader(true);
        const selectedData = watch(strings.nysCompliance.selectedData);
        Object.keys(selectedData).length > 0 ? await selectedDataUpdate(selectedData) : await resetRecords();
        setLoader(false);
    }

    const onLoad = async () => {
        if (employeeModuleState.personal && Object.keys(employeeModuleState.personal).length > 0) {
            await dispatch(employeeRequests.getNysComplianceDetails(employeeModuleState.personal.employeeId, async (isValid, data) => {
                if (isValid) {
                    await setValue(strings.nysCompliance.data, data);
                }
            }));
        }
    }

    const setCallBack = async (isValid) => {
        if (isValid) {
            await resetRecords();
            await onLoad();
        }
    }

    const resetRecords = async () => {
        const data = watch(strings.nysCompliance.data);
        await reset();
        await setValue(strings.nysCompliance.data, data);
    }

    const onSubmit = async (data) => {
        const selectedData = watch(strings.nysCompliance.selectedData);
        await setLoader(true);
        if (employeeModuleState.personal && Object.keys(employeeModuleState.personal).length > 0) {
            let NysComplianceRecords = {
                complianceCategoryID: Object.keys(data.complianceCategory).length > 0 ? data.complianceCategory.value : 0,
                complianceDate: exportDateFormat(data.complianceDate, true),
                compliancePeriod: Object.keys(data.compliancePeriod).length > 0 ? data.compliancePeriod.label : "",
                createdBy: userState.UserID,
                description: data.description,
                documentImage: "",
                documentName: "",
                employeeID: employeeModuleState.personal.employeeId,
                expiryDate: exportDateFormat(data.expiryDate, true),
                authenticateUserRole: userState.Role
            }
            if (Object.keys(selectedData).length <= 0) {
                NysComplianceRecords = { ...NysComplianceRecords, documentDetails: data.documentImage.length > 0 ? data.documentImage.map(val => ({ documentName: val.name, documentBinary: val.binary, recordStatus: "A" })) : [] }
                await dispatch(employeeRequests.createNysComplianceRecords(NysComplianceRecords, setCallBack));
            } else {
                let documentLists = data.documentImage.length > 0 ? data.documentImage.filter(val => Object.keys(val).length <= 2).map(val => ({ documentName: val.name, documentBinary: val.binary, recordStatus: "A" })) : [];

                if (selectedData?.documentDetails?.length > 0) {
                    const documentId = data.documentImage.map(val => ("id" in val) ? val.id : 0)
                    let deletedDocs = selectedData.documentDetails.filter(val => !documentId.includes(val.id));
                    if (deletedDocs?.length > 0) {
                        deletedDocs = deletedDocs.map(val => {
                            // eslint-disable-next-line no-unused-vars
                            const { documentName, documentBinary, ...rest } = val;
                            return { ...rest, recordStatus: "D" }
                        })
                        documentLists = [...documentLists, ...deletedDocs];
                    }
                }
                NysComplianceRecords = { ...NysComplianceRecords, documentDetails: documentLists }
                await dispatch(employeeRequests.updateNysComplianceRecords(selectedData.employeeComplianceId, NysComplianceRecords, setCallBack));
            }
        }
        setLoader(false);
    }

    const selectedDataUpdate = async (selectedData) => {
        const complianceCategory = selectedData.complianceCategoryID > 0 ? employeeState?.nysComplianceCategory.find(val => val.value === selectedData.complianceCategoryID) : {};
        await Promise.all([
            setValue(strings.nysCompliance.complianceCategory, complianceCategory || {}),
            setValue(strings.nysCompliance.compliancePeriod, selectedData.compliancePeriod.length > 0 ? employeeState?.nysCompliancePeriod.find(val => val.label === selectedData.compliancePeriod) : {}),
            setValue(strings.nysCompliance.complianceDate, selectedData.complianceDate.length > 0 ? new Date(selectedData.complianceDate) : ""),
            setValue(strings.nysCompliance.description, selectedData.description),
            setValue(strings.nysCompliance.expiryDate, selectedData?.expiryDate?.length > 0 ? new Date(selectedData.expiryDate) : ""),
            setValue(strings.nysCompliance.documentImage, selectedData.documentDetails && selectedData.documentDetails.length > 0 ? selectedData.documentDetails.map(val => {
                const { documentName, documentBinary, ...rest } = val;
                return { ...rest, name: documentName, binary: documentBinary };
            }) : []),
            setValue(strings.nysCompliance.data, watch(strings.nysCompliance.data)),
            setValue(strings.nysCompliance.selectedData, { ...selectedData }),
            setValue(strings.nysCompliance.compliancePeriodOptions, employeeState?.nysCompliancePeriod?.filter(val => complianceCategory?.compliancePeriodIds?.some(id => id === val.value))),
            setValue(strings.nysCompliance.noExpiry, !(selectedData?.expiryDate && selectedData.expiryDate?.length > 0))
        ]);
    }

    const setAction = async (selectedData, action) => {
        await setLoader(true);
        if (action === "Edit") {
            await dispatch(employeeRequests.getNysComplianceData(selectedData.employeeComplianceId, async (isValid, data) => {
                if (isValid) {
                    await selectedDataUpdate({ ...data, employeeComplianceId: selectedData.employeeComplianceId });
                    await onLoad();
                }
            }));
        }
        else {
            setSelectedRecord(selectedData);
            await dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to delete "${selectedData.complianceCategory}" compliance category?`, isOptional: true }));
        }
        setLoader(false);
    }

    const handleDeleteConfirmation = async (isAccepted) => {
        if (isAccepted) {
            setLoader(true);
            const userInfo = {
                modifiedBy: userState.UserID,
                modifiedDate: exportDateFormat(new Date())
            }
            await dispatch(employeeRequests.deleteNysComplianceRecord(selectedRecord.employeeComplianceId, userInfo, setCallBack));
            setLoader(false);
        }
        setSelectedRecord({});
    }

    const setComplianceCategoryUpdate = (value) => {
        setValue(strings.nysCompliance.complianceCategory, value);
        setValue(strings.nysCompliance.compliancePeriod, {});
        setValue(strings.nysCompliance.compliancePeriodOptions, employeeState?.nysCompliancePeriod?.filter(val => value?.compliancePeriodIds?.some(id => id === val.value)));
    }

    return (
        <div>
            <HeaderSection redirectType={strings.type.employeeDetails} employeeName={Object.keys(employeeModuleState.personal).length > 0 ? employeeModuleState.personal.employeeName : nameConcatenation(employeeModuleState.data)} />
            <div>
                <div className='pt-4 px-6 overflow-auto h-auto md:max-h-h_body_md sm:max-h-full'>
                    <div className={"font-fontfamily font-bold text-14px grid grid-cols-2 lg:grid-cols-1 md:grid-cols-1 sm:grid-cols-1 xsm:grid-cols-1"}>
                        <fieldset className={`grid grid-cols-12 my-2 gap-y-3 items-center`} disabled={employeeModuleState.isDisable}>
                            <span className={gridSectionLabel}> <Label label="Compliance Category" required={true} /></span> <span className={gridSectionValue} ><Dropdown value={watch(strings.nysCompliance.complianceCategory)} onChange={value => setComplianceCategoryUpdate(value)} options={employeeState?.nysComplianceCategory} isRequired={true} isViewable={employeeModuleState.isDisable} /></span>
                            <span className={gridSectionLabel}> <Label label="Compliance Period" required={true} /></span> <span className={gridSectionValue} ><Dropdown isDisable={Object.keys(watch(strings.nysCompliance.complianceCategory)).length <= 0} value={watch(strings.nysCompliance.compliancePeriod)} onChange={value => setValue(strings.nysCompliance.compliancePeriod, value)} options={watch(strings.nysCompliance.compliancePeriodOptions)} isRequired={true} isViewable={employeeModuleState.isDisable} /></span>
                            <span className={gridSectionLabel}> <Label label="Compliance Date" required={true} /></span> <span className={gridSectionValue} ><DatePickerElement value={watch(strings.nysCompliance.complianceDate)} onChange={date => setValue(strings.nysCompliance.complianceDate, date)} maxDate={watch(strings.nysCompliance.expiryDate)} isRequired={true} isViewable={employeeModuleState.isDisable} /></span>
                            <span className={gridSectionLabel}> <Label label="Description" required={true} /></span> <span className={gridSectionValue} ><TextField value={watch(strings.nysCompliance.description)} onChange={e => setValue(strings.nysCompliance.description, e.target.value)} isRequired={true} /></span>
                            <span className={gridSectionLabel}> <Label label="Expiry Date" required={!watch(strings.nysCompliance.noExpiry)} /></span> <span className={gridSectionValue} ><DatePickerElement value={watch(strings.nysCompliance.expiryDate)} onChange={date => setValue(strings.nysCompliance.expiryDate, date)} minDate={watch(strings.nysCompliance.complianceDate)} isRequired={true} isViewable={employeeModuleState.isDisable} disabled={!!watch(strings.nysCompliance.noExpiry)} /></span>
                            <span className='col-end-6 sm:col-end-4 lg:col-start-6 lg:col-end-9 xl:col-end-8 col-start-1 lg:ml-10'> <CheckBox data={[{ label: "No Expiry" }]} value={watch(strings.nysCompliance.noExpiry)} onChange={e => { setValue(strings.nysCompliance.noExpiry, e.target.checked); setValue(strings.nysCompliance.expiryDate, '') }} /></span>
                            <span className={gridSectionLabel}> <Label label="Certificate Image" /></span> <span className={gridSectionValue} ><UploadAndDeleteDocument label={"Choose File"} file={watch(strings.nysCompliance.documentImage)} onChange={file => setValue(strings.nysCompliance.documentImage, file)} isViewable={employeeModuleState.isDisable} isMultiDocument /></span>
                        </fieldset>
                    </div>
                    <div className=' flex justify-center items-center gap-x-3 my-3 lg:my-3 md:my-1 sm:my-0 xsm:my-0'>
                        {employeeModuleState.isDisable || <Button value={Object.keys(watch(strings.nysCompliance.selectedData)).length > 0 ? strings.Buttons.Update : strings.Buttons.Save} disabled={!(watch(strings.nysCompliance.complianceCategory) && Object.keys(watch(strings.nysCompliance.compliancePeriod)).length > 0 && watch(strings.nysCompliance.complianceDate) && watch(strings.nysCompliance.description) && (watch(strings.nysCompliance.noExpiry) ? true : watch(strings.nysCompliance.expiryDate)))} onClick={handleSubmit(onSubmit)} />}
                        {employeeModuleState.isDisable && <Button value={strings.Buttons.CustomClear} onClick={() => resetRecords()} />}
                        <Button value={strings.Buttons.Close} onClick={() => history.push(routerPath.staff)} />
                        {employeeModuleState.isDisable || <Button value={strings.Buttons.Reset} onClick={() => onReset()} />}
                    </div>
                    <AgGrid data={watch(strings.nysCompliance.data)} columns={employeeDetails.nysComplianceColumns(setLoader, loginResponseState.isMobileCompatible, setAction)} height="h-[calc(93vh-315px-3.5rem-48px-4.6rem-6rem)] md:h-[calc(93vh-315px-3.5rem-48px-4.6rem-6rem)] xsm:h-[21.5rem]" ContextMenuItems={loginResponseState.isMobileCompatible ? false : employeeDetails.nysCompliance_contextMenuItems} history={history} callBack={setAction} isAutoHeight maxScrollCount={4} />
                </div>
            </div>
            {loader && <TransparentLoader />}
            {!loginResponseState.multiDocumentViewer.show && loginResponseState.imageViewer.show && <ImageViewer />}
            {loginResponseState.multiDocumentViewer.show && <MultiImageViewer />}
            {loginResponseState.apiResponse.show && <ApiResponse setResponseCallback={handleDeleteConfirmation} />}
        </div>
    )
}

export default NysCompliance

const initialState = {
    complianceCategory: {},
    compliancePeriod: {},
    complianceDate: "",
    expiryDate: "",
    description: "",
    documentImage: [],
    data: [],
    selectedData: {},
    compliancePeriodOptions: [],
    noExpiry: false
}