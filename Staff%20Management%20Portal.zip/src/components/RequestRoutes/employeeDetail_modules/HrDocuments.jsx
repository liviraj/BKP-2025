import { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from "react-hook-form";
import HeaderSection from '../../layouts/HeaderSection';
import Label from '../../elements/Label';
import TextField from '../../elements/TextField';
import UploadAndDeleteDocument from '../../elements/UploadAndDeleteDocument';
import Button from '../../elements/Button';
import AgGrid from '../../Grid/AgGrid';
import { employeeDetails } from '../../Grid/Columns';
import { routerPath, strings } from '../../Constants';
import TransparentLoader from '../../loader/TransparentLoader';
import ImageViewer from '../../ViewDocs/ImageViewer';
import { employeeRequests, userRequest } from '../../requests';
import { employeeReducerState, exportDateFormat, nameConcatenation } from '../../helper';
import ApiResponse from '../../Alert/ApiResponse';
import DatePickerElement from '../../elements/DatePickerElement';
import Dropdown from '../../elements/Dropdown';
import MultiImageViewer from '../../ViewDocs/MultiImageViewer';


function HRDocuments() {
    const gridSectionLabel = "col-start-1 col-end-4 md:col-end-4 sm:col-end-6 xsm:col-end-6";
    const gridSectionValue = `col-start-5 col-end-10 lg:col-end-10 md:col-end-13 sm:col-end-13 xsm:col-end-13 lg:col-start-5 md:col-start-7 sm:col-start-7 xsm:col-start-7`;
    const history = useHistory();
    const employeeModuleState = useSelector(state => state.employee.employeeModule);
    const loginResponseState = useSelector(state => state.loginResponse);
    const userState = useSelector(state => state.user);
    const employeeState = useSelector(state => state.employee);
    const { handleSubmit, watch, setValue, reset } = useForm({ defaultValues: initialState });
    const dispatch = useDispatch();
    const [loader, setLoader] = useState(false);
    const documentType = watch(strings.hrDocuments.documentType);
    const [selectedRecord, setSelectedRecord] = useState({});

    useEffect(() => {
        const componentDidMount = async () => {
            await setLoader(true);
            await Promise.all([
                employeeReducerState().documentType.length <= 0 && await dispatch(employeeRequests.setDocumentType()),
                onLoad()
            ]);
            setLoader(false);
        }
        componentDidMount();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const onReset = async () => {
        await setLoader(true);
        const selectedData = watch(strings.hrDocuments.selectedData);
        Object.keys(selectedData).length > 0 ? await selectedDataUpdate(selectedData) : await resetRecords();
        setLoader(false);
    }

    const onLoad = async () => {
        if (employeeModuleState.personal && Object.keys(employeeModuleState.personal).length > 0) {
            await dispatch(employeeRequests.getHrDocumentDetails(employeeModuleState.personal.employeeId, async (isValid, data) => {
                if (isValid) {
                    await setValue(strings.hrDocuments.data, data);
                }
            }));
        }
    }
    const setCallBack = async (isValid) => {
        if (isValid) {
            await resetRecords();
            await onLoad();
        }
    }
    const resetRecords = async () => {
        const data = watch(strings.hrDocuments.data);
        await reset();
        await setValue(strings.hrDocuments.data, data);
    }
    const onSubmit = async (data) => {
        const selectedData = watch(strings.hrDocuments.selectedData);
        await setLoader(true);
        if (employeeModuleState.personal && Object.keys(employeeModuleState.personal).length > 0) {
            let hrDocumentRecords = {
                description: data.description,
                documentDate: exportDateFormat(data.documentDate, true),
                documentImage: "",
                documentName: "",
                documentType: data.isDropdownView ? "" : data.documentType,
                documentTypeId: data.isDropdownView && Object.keys(data.documentType).length > 0 ? data.documentType.value : 0,
                employeeId: employeeModuleState.personal.employeeId,
                expiryDate: typeof (data.expiryDate) === "string" && data.expiryDate.length <= 0 ? null : exportDateFormat(data.expiryDate, true),
                modifiedBy: userState.UserID,
            };
            if (Object.keys(selectedData).length <= 0) {
                hrDocumentRecords = { ...hrDocumentRecords, documentList: data.documentImage.length > 0 ? data.documentImage.map(val => ({ documentName: val.name, documentBinary: val.binary, recordStatus: "A" })) : [] }
                await dispatch(employeeRequests.createHrDocumentRecords(hrDocumentRecords, setCallBack));
            } else {
                let documentLists = data.documentImage.length > 0 ? data.documentImage.filter(val => Object.keys(val).length <= 2).map(val => ({ documentName: val.name, documentBinary: val.binary, recordStatus: "A" })) : [];

                if (selectedData.documentList.length > 0) {
                    const documentId = data.documentImage.map(val => ("id" in val) ? val.id : 0)
                    let deletedDocs = selectedData.documentList.filter(val => !documentId.includes(val.id));
                    if (deletedDocs?.length > 0) {
                        deletedDocs = deletedDocs.map(val => {
                            // eslint-disable-next-line no-unused-vars
                            const { documentName, documentBinary, ...rest } = val;
                            return { ...rest, recordStatus: "D" }
                        })
                        documentLists = [...documentLists, ...deletedDocs];
                    }
                }
                hrDocumentRecords = { ...hrDocumentRecords, documentList: documentLists }
                await dispatch(employeeRequests.updateHrDocumentRecords(selectedData.documentId, hrDocumentRecords, setCallBack));
            }
        }
        setLoader(false);
    }
    const selectedDataUpdate = async (selectedData) => {
        await Promise.all([
            setValue(strings.hrDocuments.documentDate, selectedData.documentDate?.length > 0 ? new Date(selectedData.documentDate) : ""),
            setValue(strings.hrDocuments.expiryDate, selectedData.expiryDate?.length > 0 ? new Date(selectedData.expiryDate) : ""),
            setValue(strings.hrDocuments.description, selectedData.description),
            setValue(strings.hrDocuments.documentImage, selectedData.documentList && selectedData.documentList.length > 0 ? selectedData.documentList.map(val => {
                const { documentName, documentBinary, ...rest } = val;
                return { ...rest, name: documentName, binary: documentBinary };
            }) : []),
            setValue(strings.hrDocuments.data, watch(strings.hrDocuments.data)),
            setValue(strings.hrDocuments.selectedData, { ...selectedData }),
        ]);
        let documentTypeData = selectedData?.documentTypeId ? employeeState.documentType.find(val => val.value === selectedData.documentTypeId) : selectedData.documentType;
        await Promise.all([
            setValue(strings.hrDocuments.documentType, documentTypeData),
            setValue(strings.hrDocuments.isDropdownView, !!(documentTypeData && typeof (documentTypeData) === "object" && Object.keys(documentTypeData).length > 0)),
        ]);
    }
    const setAction = async (selectedData, action) => {
        await setLoader(true);
        if (action === "Edit") {
            await dispatch(employeeRequests.getHrDocumentData(selectedData.documentId, async (isValid, data) => {
                if (isValid) {
                    await selectedDataUpdate({ ...data, documentId: selectedData.documentId });
                }
            }));
        }
        else {
            setSelectedRecord(selectedData);
            await dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to delete "${selectedData.documentType}" document record?`, isOptional: true }));
        }
        setLoader(false);
    }

    const onDeleteConfirmation = async (isAccepted) => {
        await setLoader(true);
        if (isAccepted) {
            const userInfo = {
                modifiedBy: userState.UserID,
                modifiedDate: exportDateFormat(new Date())
            }
            await dispatch(employeeRequests.deleteHRDocumentRecord(selectedRecord.documentId, userInfo, setCallBack));
        }
        setLoader(false);
        setSelectedRecord({});
    }

    return (
        <div>
            <HeaderSection redirectType={strings.type.employeeDetails} employeeName={Object.keys(employeeModuleState.personal).length > 0 ? employeeModuleState.personal.employeeName : nameConcatenation(employeeModuleState.data)} />
            <div>
                <div className='pt-4 px-6 overflow-auto h-auto md:max-h-h_body_md sm:max-h-full'>
                    <fieldset className={"font-fontfamily font-bold text-14px grid grid-cols-2 lg:grid-cols-2 md:grid-cols-1 sm:grid-cols-1 xsm:grid-cols-1"} disabled={employeeModuleState.isDisable}>
                        <div className={`grid grid-cols-12 my-2 gap-y-3 items-center`}>
                            <span className={gridSectionLabel}> <Label label="Document Type" required={true} /></span> <span className={gridSectionValue} >{!watch(strings.hrDocuments.isDropdownView) ? <TextField value={documentType && typeof (documentType) === "string" ? documentType : ""} onChange={e => setValue(strings.hrDocuments.documentType, e.target.value)} isDisable={true} isRequired={true} /> : <Dropdown value={documentType} onChange={data => setValue(strings.hrDocuments.documentType, data)} options={employeeReducerState().documentType} isRequired={true} isViewable={employeeModuleState.isDisable} />}</span>
                            <span className={gridSectionLabel}> <Label label="Document Date" required={true} /></span> <span className={gridSectionValue} ><DatePickerElement value={watch(strings.hrDocuments.documentDate)} onChange={date => setValue(strings.hrDocuments.documentDate, date)} isRequired={true} maxDate={watch(strings.hrDocuments.expiryDate) ? watch(strings.hrDocuments.expiryDate) : new Date()} isViewable={employeeModuleState.isDisable} /></span>
                            <span className={gridSectionLabel}> <Label label="Expiry Date" /></span> <span className={gridSectionValue} ><DatePickerElement value={watch(strings.hrDocuments.expiryDate)} onChange={date => setValue(strings.hrDocuments.expiryDate, date)} minDate={watch(strings.hrDocuments.documentDate)} isViewable={employeeModuleState.isDisable} /></span>
                            <span className={gridSectionLabel}> <Label label="Description" /></span> <span className={gridSectionValue} ><TextField value={watch(strings.hrDocuments.description)} onChange={e => setValue(strings.hrDocuments.description, e.target.value)} /></span>
                            <span className={gridSectionLabel}> <Label label="Certificate Image" /></span> <span className={gridSectionValue} ><UploadAndDeleteDocument label={"Choose File"} file={watch(strings.hrDocuments.documentImage)} onChange={file => setValue(strings.hrDocuments.documentImage, file)} isViewable={employeeModuleState.isDisable} isMultiDocument /></span>
                        </div>
                    </fieldset>
                    <div className=' flex justify-center items-center gap-3 my-3 lg:my-3 md:my-1 sm:my-0 xsm:my-0'>
                        {employeeModuleState.isDisable || <Button value={Object.keys(watch(strings.hrDocuments.selectedData)).length > 0 ? strings.Buttons.Update : strings.Buttons.Save} disabled={!(watch(strings.hrDocuments.documentDate) && (watch(strings.hrDocuments.isDropdownView) ? documentType : true))} onClick={handleSubmit(onSubmit)} />}
                        {employeeModuleState.isDisable && <Button value={strings.Buttons.CustomClear} onClick={() => resetRecords()} />}
                        <Button value={strings.Buttons.Close} onClick={() => history.push(routerPath.staff)} />
                        {employeeModuleState.isDisable || <Button value={strings.Buttons.Reset} onClick={() => onReset()} />}
                    </div>
                    <AgGrid data={watch(strings.hrDocuments.data)} columns={employeeDetails.hrDocumentColumns(setLoader, loginResponseState.isMobileCompatible, setAction)} height="h-[calc(93vh-261px-3.5rem-48px-4.6rem-6rem)] md:h-[calc(93vh-261px-3.5rem-48px-4.6rem-6rem)] xsm:h-[24.95rem]" ContextMenuItems={loginResponseState.isMobileCompatible ? false : employeeDetails.hrDocument_contextMenuItems} history={history} callBack={setAction} isAutoHeight maxScrollCount={5} />
                </div>
            </div>
            {loader && <TransparentLoader />}
            {!loginResponseState.multiDocumentViewer.show && loginResponseState.imageViewer.show && <ImageViewer />}
            {loginResponseState.multiDocumentViewer.show && <MultiImageViewer />}
            {loginResponseState.apiResponse.show && <ApiResponse setResponseCallback={onDeleteConfirmation} />}
        </div>
    )
}

export default HRDocuments

const initialState = {
    documentDate: "",
    expiryDate: "",
    description: "",
    documentType: "",
    documentImage: [],
    data: [],
    selectedData: {},
    isDropdownView: true
}