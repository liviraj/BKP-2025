import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import HeaderSection from '../../layouts/HeaderSection';
import TextField from '../../elements/TextField';
import Label from '../../elements/Label';
import Dropdown from '../../elements/Dropdown';
import CheckBox from '../../elements/CheckBox';
import Button from '../../elements/Button';
import { CommunicationRequest, employeeRequests } from '../../requests';
import { useForm } from "react-hook-form";
import { routerPath, strings } from '../../Constants';
import { useHistory } from 'react-router-dom';
import TransparentLoader from '../../loader/TransparentLoader';
import ApiResponse from '../../Alert/ApiResponse';
import Mail from '../../elements/Mail';
import { employeeReducerState, mobileNumberValidation, nameConcatenation, numberValidation } from '../../helper';

const gridFirstSectionLabel = "col-start-1 col-end-4 md:col-end-4 sm:col-end-6 xsm:col-end-6";
const gridSectionValue = `col-start-5 col-end-10 lg:col-end-10 md:col-end-13 sm:col-end-13 xsm:col-end-13 lg:col-start-5 md:col-start-7 sm:col-start-7 xsm:col-start-7`;


function Communication() {
  const dispatch = useDispatch();
  const history = useHistory();
  const userState = useSelector((state) => state.user);
  const employeeModuleState = useSelector(state => state.employee.employeeModule);//employeeModuleState.employeeId
  const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
  const { handleSubmit, watch, setValue, reset } = useForm({ defaultValues: CommunicationState });
  let {
    address1, address2, address3, city, state, country, pin, permAdd1, permAdd2, permAdd3, permCity, permState, permCountry, permPin, phoneno, alternateContactNumber, cellno,
    workPhoneNo, extension, emailID, emergencyContactName, emergencyContactRelation, emergencyContactAddress1, emergencyContactAddress2, emergencyContactAddress3,
    emergencyContactNumber, cmId
  } = strings.employeeCommunication;
  const [empCode, setEmpCode] = useState("");
  const [empName, setEmpName] = useState("");
  const [loader, setLoader] = useState(false);
  const [communicationDetails, setCommunicationDetails] = useState([]);
  const isChecked = !!watch('permAddressIsSaneAsAbove');

  const validateCheckBox = (data) => {
    if (
      data.address1 === data.permAdd1 &&
      data.address2 === data.permAdd2 &&
      data.address3 === data.permAdd3 &&
      data.city === data.permCity &&
      data.state === data.permState &&
      data.country === data.permCountry &&
      data.pin === data.permPin
    ) {
      setValue("permAddressIsSaneAsAbove", true)
    }
  }

  const updateCommunicationValue = (responseData) => {
    try {
      if (responseData && responseData.length > 0) {
        let data = responseData[0];
        setCommunicationDetails(responseData);
        setValue(address1, data.address1);
        setValue(address2, data.address2);
        setValue(address3, data.address3);
        setValue(city, data.city);
        setValue(state, data.state);
        setValue(country, watch('location').filter((val) => val.value === Number(data.country))[0]);
        setValue(pin, data.pin);
        //permanent address
        setValue(permAdd1, data.permAdd1);
        setValue(permAdd2, data.permAdd2);
        setValue(permAdd3, data.permAdd3);
        setValue(permCity, data.permCity);
        setValue(permState, data.permState);
        setValue(permCountry, watch('location').filter((val) => val.value === Number(data.permCountry))[0]);
        setValue(permPin, data.permPin);
        //contact details
        setValue(phoneno, data.phoneno); //landlane
        setValue(alternateContactNumber, data.alternateContactNumber);
        setValue(cellno, data.cellno);
        setValue(workPhoneNo, data.workPhoneNo);
        setValue(extension, data.extension);
        setValue(emailID, data.emailID);
        //emg cont
        setValue(emergencyContactName, data.emergencyContactName);
        setValue(emergencyContactRelation, data.emergencyContactRelation);
        setValue(emergencyContactAddress1, data.emergencyContactAddress1);
        setValue(emergencyContactAddress2, data.emergencyContactAddress2);
        setValue(emergencyContactAddress3, data.emergencyContactAddress3);
        setValue(emergencyContactNumber, data.emergencyContactNumber);
        setValue(cmId, data.employeeCommunicationId);

        validateCheckBox(data)
      }
    } catch (err) {
      console.error(err)
    }
  }

  useEffect(() => {
    setLoader(true);
    const getLocation = async () => {
      await employeeReducerState().location.length <= 0 && dispatch(employeeRequests.location());
      await setValue('location', employeeReducerState().location.filter(val => val.value > 0));
      await setEmpCode(employeeModuleState.personal.employeeCode ? employeeModuleState.personal.employeeCode : "");
      await setEmpName(employeeModuleState.personal.firstName + " " + employeeModuleState.personal?.middleName + " " + employeeModuleState.personal.lastName);
      await dispatch(CommunicationRequest.getCommunicationInfo(employeeModuleState.personal.employeeId, updateCommunicationValue));
      setLoader(false);
    }
    getLocation();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const onSaveValidation = () => {
    let isValid = true;
    if (!watch(address1) || !watch(city) || !watch(state) || !watch(country) || !watch(pin) || !watch(permAdd1) || !watch(permCity) || !watch(permState) || !watch(permCountry) || !watch(permPin) || !watch(emailID)) {
      isValid = false
    }
    return isValid;
  }

  const onSaveCommunication = async () => {
    let saveValidation = onSaveValidation();
    if (saveValidation) {
      let finalData = {
        "address1": watch(address1),
        "address2": watch(address2),
        "address3": watch(address3),
        "city": watch(city),
        "state": watch(state),
        "country": watch(country).value,
        "pin": watch(pin),
        //permanent address
        "permAdd1": watch(permAdd1),
        "permAdd2": watch(permAdd2),
        "permAdd3": watch(permAdd3),
        "permCity": watch(permCity),
        "permState": watch(permState),
        "permCountry": watch(permCountry).value,
        "permPin": watch(permPin),
        //contact details
        "phoneno": watch(phoneno), //landlane
        "alternateContactNumber": watch(alternateContactNumber),
        "cellno": watch(cellno),
        "workPhoneNo": watch(workPhoneNo),
        "extension": watch(extension),
        "emailID": watch(emailID),
        //emg cont
        "emergencyContactName": watch(emergencyContactName),
        "emergencyContactRelation": watch(emergencyContactRelation),
        "emergencyContactAddress1": watch(emergencyContactAddress1),
        "emergencyContactAddress2": watch(emergencyContactAddress2),
        "emergencyContactAddress3": watch(emergencyContactAddress3),
        "emergencyContactNumber": watch(emergencyContactNumber),
        "employeeId": employeeModuleState.personal.employeeId,//loginUserInfo.loginId,
        "modifiedBy": userState.UserID,
        "createdBy": userState.UserID,
        // "createdDate": Date(),
        // "recordStatus": {},
      }
      setLoader(true);
      if (communicationDetails.length > 0) {
        await dispatch(CommunicationRequest.editCommunication(finalData, watch(cmId), history));
      } else {
        await dispatch(CommunicationRequest.createCommunication(finalData, history));
      }
      setLoader(false);
    }
  }

  const onAddressConfirmChange = (e) => {
    setValue("permAddressIsSaneAsAbove", e.target.checked)
    if (e.target.checked) {
      setValue(permAdd1, watch(address1));
      setValue(permAdd2, watch(address2));
      setValue(permAdd3, watch(address3));
      setValue(permCity, watch(city));
      setValue(permState, watch(state));
      setValue(permCountry, watch(country));
      setValue(permPin, watch(pin));
    }
    else {
      setValue(permAdd1, "");
      setValue(permAdd2, "");
      setValue(permAdd3, "");
      setValue(permCity, "");
      setValue(permState, "");
      setValue(permCountry, "");
      setValue(permPin, "");
    }
  }
  const onReset = async () => {
    await setLoader(true);
    await reset();
    await updateCommunicationValue(communicationDetails);
    setLoader(false);
  }

  return (
    <div>
      <HeaderSection redirectType={strings.type.employeeDetails} employeeName={Object.keys(employeeModuleState.personal).length > 0 ? employeeModuleState.personal.employeeName : nameConcatenation(employeeModuleState.data)} />
      <div>
        <div className='pt-2 px-6 overflow-auto h-auto md:max-h-h_body_md sm:max-h-full'>
          <fieldset className={"font-fontfamily font-bold text-14px grid grid-cols-2 lg:grid-cols-2 md:grid-cols-1 sm:grid-cols-1 xsm:grid-cols-1"} disabled={employeeModuleState.isDisable}>
            <div className={`grid grid-cols-12 mt-2 gap-y-2 items-center`}>
              <span className={gridFirstSectionLabel}> <Label label="Employee Code" /></span> <span className={gridSectionValue}><TextField isDisable={true} value={empCode} /></span>
              <span className={gridFirstSectionLabel}><Label label="Employee Name" /> </span> <span className={gridSectionValue}><TextField isDisable={true} value={empName} /></span>
              <span className={gridFirstSectionLabel}> <Label label="Communication Address" required={true} /></span> <span className={gridSectionValue}><TextField value={watch(address1)} onChange={(e) => { setValue(address1, e.target.value); if (isChecked) { setValue(permAdd1, e.target.value) } }} isRequired={true} /></span>
              <span className={gridFirstSectionLabel}> </span> <span className={gridSectionValue}><TextField value={watch(address2)} onChange={(e) => { setValue(address2, e.target.value); if (isChecked) { setValue(permAdd2, e.target.value) } }} /></span>
              <span className={gridFirstSectionLabel}> </span> <span className={gridSectionValue}><TextField value={watch(address3)} onChange={(e) => { setValue(address3, e.target.value); if (isChecked) { setValue(permAdd3, e.target.value) } }} /></span>
              <span className={gridFirstSectionLabel}> <Label label="City" required={true} /></span> <span className={gridSectionValue}><TextField value={watch(city)} onChange={(e) => { setValue(city, e.target.value); if (isChecked) { setValue(permCity, e.target.value) } }} isRequired={true} /></span>
              <span className={gridFirstSectionLabel}> <Label label="State" required={true} /></span> <span className={gridSectionValue}><TextField value={watch(state)} onChange={(e) => { setValue(state, e.target.value); if (isChecked) { setValue(permState, e.target.value) } }} isRequired={true} /></span>
              <span className={gridFirstSectionLabel}> <Label label="Country" required={true} /></span> <span className={gridSectionValue}><Dropdown value={watch(country)} options={watch("location")} onChange={(e) => { setValue(country, e); if (isChecked) { setValue(permCountry, e) } }} isRequired={true} isViewable={employeeModuleState.isDisable} /></span>
              <span className={gridFirstSectionLabel}> <Label label="PIN Code/ZIP Code" required={true} /></span> <span className={gridSectionValue}><TextField type={'number'} value={watch(pin)} onChange={(e) => { numberValidation(e.target.value, 20) && setValue(pin, e.target.value); if (isChecked && numberValidation(e.target.value, 20)) { setValue(permPin, e.target.value) } }} isRequired={true} /></span>
              <span className={" col-span-full flex items-center"}><CheckBox value={isChecked} height="2vh" onChange={onAddressConfirmChange} data={[{ label: "Same as Above", defaultChecked: false, disabled: false }]} /></span>
              <span className={gridFirstSectionLabel}></span> <span className={gridSectionValue}></span>
              <span className={gridFirstSectionLabel}></span> <span className={gridSectionValue}></span>
              <span className={gridFirstSectionLabel}> <Label label="Permanent Address" required={true} /></span> <span className={gridSectionValue}><TextField isDisable={isChecked} value={watch(permAdd1)} onChange={(e) => setValue(permAdd1, e.target.value)} isRequired={true} /></span>
              <span className={gridFirstSectionLabel}> </span> <span className={gridSectionValue}><TextField isDisable={isChecked} value={watch(permAdd2)} onChange={(e) => setValue(permAdd2, e.target.value)} /></span>
              <span className={gridFirstSectionLabel}> </span> <span className={gridSectionValue}><TextField isDisable={isChecked} value={watch(permAdd3)} onChange={(e) => setValue(permAdd3, e.target.value)} /></span>
              <span className={gridFirstSectionLabel}> <Label label="City" required={true} /></span> <span className={gridSectionValue}><TextField isDisable={isChecked} value={watch(permCity)} onChange={(e) => setValue(permCity, e.target.value)} isRequired={true} /></span>
              <span className={gridFirstSectionLabel}> <Label label="State" required={true} /></span> <span className={gridSectionValue}><TextField isDisable={isChecked} value={watch(permState)} onChange={(e) => setValue(permState, e.target.value)} isRequired={true} /></span>
              <span className={gridFirstSectionLabel}> <Label label="Country" required={true} /></span> <span className={gridSectionValue}><Dropdown isDisable={isChecked} options={watch("location")} value={watch(permCountry)} onChange={(e) => setValue(permCountry, e)} isRequired={true} isViewable={employeeModuleState.isDisable} /></span>
              <span className={gridFirstSectionLabel}> <Label label="PIN Code/ZIP Code" required={true} /></span> <span className={gridSectionValue}><TextField type={'number'} isDisable={isChecked} value={watch(permPin)} onChange={(e) => numberValidation(e.target.value, 20) && setValue(permPin, e.target.value)} isRequired={true} /></span>
            </div>

            <div className={`grid grid-cols-12 mt-2 gap-y-2 items-center`}>
              <span className={gridFirstSectionLabel}><Label label="Land Line Number" /> </span> <span className={gridSectionValue}><TextField value={watch(phoneno)} onChange={(e) => mobileNumberValidation(e.target.value) && setValue(phoneno, e.target.value)} isNumField={true} /></span>
              <span className={gridFirstSectionLabel}> <Label label="Alternate Phone" /></span> <span className={gridSectionValue}><TextField value={watch(alternateContactNumber)} onChange={(e) => mobileNumberValidation(e.target.value) && setValue(alternateContactNumber, e.target.value)} isNumField={true} /></span>
              <span className={gridFirstSectionLabel}> <Label label="Mobile Number" /></span> <span className={gridSectionValue}><TextField value={watch(cellno)} onChange={(e) => mobileNumberValidation(e.target.value) && setValue(cellno, e.target.value)} isNumField={true} /></span>
              <span className={gridFirstSectionLabel}> <Label label="Office Number" /></span> <span className={gridSectionValue}><TextField value={watch(workPhoneNo)} onChange={(e) => mobileNumberValidation(e.target.value) && setValue(workPhoneNo, e.target.value)} isNumField={true} /></span>
              <span className={gridFirstSectionLabel}> <Label label="Extn." /></span> <span className={gridSectionValue}><TextField value={watch(extension)} onChange={(e) => setValue(extension, e.target.value)} /></span>
              <span className={gridFirstSectionLabel}> <Label label="Personal Email ID" required={true} /></span> <span className={gridSectionValue}><Mail value={watch(emailID)?.trim().length > 0 ? [watch(emailID)] : []} onChange={(val) => { setValue(emailID, val.length > 0 ? val[val.length - 1] : "") }} isRequired={true} isViewable={employeeModuleState.isDisable} /></span>
              <span className={gridFirstSectionLabel}></span> <span className={gridSectionValue}></span>
              <span className='col-start-5 col-end-10 lg:col-end-10 md:col-end-13 sm:col-end-13 xsm:col-end-13 lg:col-start-5 md:col-start-1 sm:col-start-1 xsm:col-start-1'> <span className={" col-span-full flex justify-center"}> <span className='font-fontfamily text-12px font-bold uppercase tracking-wider mx-3 ml-0 text-shadow-sm  text-headerColor'>Emergency Contact</span></span> </span>
              <span className={gridFirstSectionLabel}></span> <span className={gridSectionValue}></span>
              <span className={gridFirstSectionLabel}> <Label label="Name" /></span> <span className={gridSectionValue}><TextField value={watch(emergencyContactName)} onChange={(e) => setValue(emergencyContactName, e.target.value)} /></span>
              <span className={gridFirstSectionLabel}> <Label label="Relation" /></span> <span className={gridSectionValue}><TextField value={watch(emergencyContactRelation)} onChange={(e) => setValue(emergencyContactRelation, e.target.value)} /></span>
              <span className={gridFirstSectionLabel}> <Label label="Address" /></span> <span className={gridSectionValue}><TextField value={watch(emergencyContactAddress1)} onChange={(e) => setValue(emergencyContactAddress1, e.target.value)} /></span>
              <span className={gridFirstSectionLabel}> </span> <span className={gridSectionValue}><TextField value={watch(emergencyContactAddress2)} onChange={(e) => setValue(emergencyContactAddress2, e.target.value)} /></span>
              <span className={gridFirstSectionLabel}> </span> <span className={gridSectionValue}><TextField value={watch(emergencyContactAddress3)} onChange={(e) => setValue(emergencyContactAddress3, e.target.value)} /></span>
              <span className={gridFirstSectionLabel}> <Label label="Phone" /></span> <span className={gridSectionValue}><TextField value={watch(emergencyContactNumber)} onChange={(e) => mobileNumberValidation(e.target.value) && setValue(emergencyContactNumber, e.target.value)} isNumField={true} /></span>
            </div>
          </fieldset>
          <div className="justify-center flex flex-row gap-3 sm:flex-row mt-2">
            {employeeModuleState.isDisable || <Button value={communicationDetails.length <= 0 ? strings.Buttons.Save : strings.Buttons.Update} onClick={handleSubmit(onSaveCommunication)} disabled={!onSaveValidation()} />}
            <Button value={strings.Buttons.Close} onClick={() => history.push(routerPath.staff)} />
            {employeeModuleState.isDisable || <Button value={strings.Buttons.Reset} onClick={() => onReset()} />}
          </div>
        </div>
        {apiResponseState.show && <ApiResponse />}
      </div>
      {loader && <TransparentLoader />}
    </div>
  )
}

const CommunicationState = {
  "address1": "",
  "address2": "",
  "address3": "",
  "city": "",
  "state": "",
  "country": 0,
  "pin": "",
  //permanent address
  "permAdd1": "",
  "permAdd2": "",
  "permAdd3": "",
  "permCity": "",
  "permState": "",
  "permCountry": "",
  "permPin": "",
  //contact details
  "phoneno": "", //landlane
  "alternateContactNumber": "",
  "cellno": "",
  "workPhoneNo": "",
  "extension": "",
  "emailID": "",
  //emg cont
  "emergencyContactName": "",
  "emergencyContactRelation": "",
  "emergencyContactAddress1": "",
  "emergencyContactAddress2": "",
  "emergencyContactAddress3": "",
  "emergencyContactNumber": "",
  //local values
  "permAddressIsSaneAsAbove": "",
  "cmId": 0,
  location: [],
}


export default Communication