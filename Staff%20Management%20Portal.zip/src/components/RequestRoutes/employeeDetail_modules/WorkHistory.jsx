import { useEffect, useState } from 'react'
import HeaderSection from '../../layouts/HeaderSection'
import Label from '../../elements/Label';
import TextField from '../../elements/TextField';
import { routerPath, strings } from '../../Constants';
import { useForm } from "react-hook-form";
import { useHistory } from 'react-router-dom';
import Button from '../../elements/Button';
import { employeeDetails } from '../../Grid/Columns';
import AgGrid from '../../Grid/AgGrid';
import TransparentLoader from '../../loader/TransparentLoader';
import { employeeRequests, userRequest } from '../../requests';
import { useDispatch, useSelector } from 'react-redux';
import UploadAndDeleteDocument from '../../elements/UploadAndDeleteDocument';
import { exportDateFormat, nameConcatenation } from '../../helper';
import ImageViewer from '../../ViewDocs/ImageViewer';
import DatePickerElement from '../../elements/DatePickerElement';
import ApiResponse from '../../Alert/ApiResponse';
import MultiImageViewer from '../../ViewDocs/MultiImageViewer';


function WorkHistory() {
  const gridSplit_firstSet = `col-start-1 col-end-4 md:col-end-4 sm:col-end-6 xsm:col-end-6`;
  const gridSplit_secondSet = `col-start-5 col-end-10 lg:col-end-10 md:col-end-13 sm:col-end-13 xsm:col-end-13 lg:col-start-5 md:col-start-7 sm:col-start-7 xsm:col-start-7`;
  const dispatch = useDispatch();
  const { handleSubmit, reset, setValue, watch } = useForm({ defaultValues: initialState });
  const history = useHistory();
  const { employerName, designation, dateofJoin, relievingDate, reportingTo } = strings.workHistory;
  const loginResponseState = useSelector(state => state.loginResponse);
  const employeeModuleState = useSelector(state => state.employee.employeeModule);
  const userState = useSelector(state => state.user);
  const [loader, setLoader] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState({});

  useEffect(() => {
    const componentDidMount = async () => {
      await setLoader(true);
      await onLoadData();
      setLoader(false);
    }
    componentDidMount();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const onReset = async () => {
    await setLoader(true);
    const selectedData = watch(strings.workHistory.selectedData);
    Object.keys(selectedData).length > 0 ? await selectedDataUpdate(selectedData) : await resetRecords();
    setLoader(false);
  }
  const resetRecords = async () => {
    const data = watch(strings.workHistory.data);
    await reset();
    await setValue(strings.workHistory.data, data);
  }

  const onSaveValidation = () => {
    let isValid = true;
    if (!watch(employerName) || !watch(designation) || !watch(dateofJoin) || !watch(relievingDate) || !watch(reportingTo)) {
      isValid = false;
    }
    return isValid;
  }

  const onLoadData = async () => {
    if (employeeModuleState.personal && Object.keys(employeeModuleState.personal).length > 0) {
      await dispatch(employeeRequests.getWorkHistoryDetails(employeeModuleState.personal.employeeId, async (isValid, data) => {
        if (isValid) {
          await setValue(strings.workHistory.data, data);
        }
      }));
    }
  }

  const setCallBack = async (isValid) => {
    if (isValid) {
      await resetRecords();
      await onLoadData();
    }
  }

  const onSubmit = async (data) => {
    try {
      if (onSaveValidation()) {
        await setLoader(true);
        let records = {
          employerName: data.employerName,
          designation: data.designation,
          dateofJoin: exportDateFormat(data.dateofJoin, true),
          relievingDate: exportDateFormat(data.relievingDate, true),
          reportingTo: data.reportingTo,
          employeeId: employeeModuleState.personal.employeeId,
          employeeImage: "",
          employeeImageBinary: "",
          modifiedBy: userState.UserID,

        }
        if (Object.keys(watch(strings.workHistory.selectedData)).length > 0) {

          const selectedData = watch(strings.workHistory.selectedData);
          let documentLists = data.employeeImage.length > 0 ? data.employeeImage.filter(val => Object.keys(val).length <= 2).map(val => ({ documentName: val.name, documentBinary: val.binary, recordStatus: "A" })) : [];

          if (selectedData.documentDetails.length > 0) {
            const documentId = data.employeeImage.map(val => ("id" in val) ? val.id : 0)
            let deletedDocs = selectedData.documentDetails.filter(val => !documentId.includes(val.id));
            if (deletedDocs?.length > 0) {
              deletedDocs = deletedDocs.map(val => {
                // eslint-disable-next-line no-unused-vars
                const { documentName, documentBinary, ...rest } = val;
                return { ...rest, recordStatus: "D" }
              })
              documentLists = [...documentLists, ...deletedDocs];
            }
          }
          records = { ...records, documentDetails: documentLists }

          await dispatch(employeeRequests.updateWorkHistoryDetails(data.selectedData.employeeWorkHistoryId, records, setCallBack));//qualifId

        } else {
          records = { ...records, documentDetails: data.employeeImage.length > 0 ? data.employeeImage.map(val => ({ documentName: val.name, documentBinary: val.binary, recordStatus: "A" })) : [] }
          await dispatch(employeeRequests.createemploeeWorkHistory(records, setCallBack));
        }
        setLoader(false);

      }
    } catch (err) {
      console.error(err);
    }
  }
  const setLoaderValue = (isload) => {
    setLoader(isload);
  }

  const selectedDataUpdate = async (selectedData) => {
    await Promise.all([
      setValue(strings.workHistory.employerName, selectedData.employerName),
      setValue(strings.workHistory.designation, selectedData.designation),
      setValue(strings.workHistory.dateofJoin, selectedData.dateofJoin && selectedData.dateofJoin.length > 0 ? new Date(selectedData.dateofJoin) : ""),
      setValue(strings.workHistory.relievingDate, selectedData.relievingDate && selectedData.relievingDate.length > 0 ? new Date(selectedData.relievingDate) : ""),
      setValue(strings.workHistory.reportingTo, selectedData.reportingTo),
      setValue(strings.workHistory.employeeId, selectedData.employeeId),
      setValue(strings.workHistory.employeeImage, selectedData.documentDetails && selectedData.documentDetails.length > 0 ? selectedData.documentDetails.map(val => {
        const { documentName, documentBinary, ...rest } = val;
        return { ...rest, name: documentName, binary: documentBinary };
      }) : []),
      setValue(strings.workHistory.data, watch(strings.workHistory.data)),
      setValue(strings.workHistory.selectedData, { ...selectedData })
    ]);
  }

  const setEditBack = async (selectedData, type) => {
    await setLoader(true);
    if (type === "isEdit") {
      await dispatch(employeeRequests.getWorkHistory(selectedData.employeeWorkHistoryId, async (isValid, data) => {
        if (isValid) {
          await selectedDataUpdate({ ...data, employeeWorkHistoryId: selectedData.employeeWorkHistoryId });
          await onLoadData();
        }
      }));
    }
    else {
      setSelectedRecord(selectedData);
      await dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to delete "${selectedData.employerName}" employer record?`, isOptional: true }));
    }
    setLoader(false);
  }

  const setDeleteConfirm = async (isAccepted) => {
    if (isAccepted) {
      await setLoader(true);
      const userInfo = {
        modifiedBy: userState.UserID,
        modifiedDate: exportDateFormat(new Date())
      }
      await dispatch(employeeRequests.deleteWorkHistory(selectedRecord?.employeeWorkHistoryId, userInfo, setCallBack));
      setLoader(false);
    }
    setSelectedRecord({});
  }



  return (
    <div>
      <HeaderSection redirectType={strings.type.employeeDetails} employeeName={Object.keys(employeeModuleState.personal).length > 0 ? employeeModuleState.personal.employeeName : nameConcatenation(employeeModuleState.data)} />
      <div>
        <div className='pt-4 px-6 overflow-auto h-auto md:max-h-h_body_md sm:max-h-full'>
          <fieldset className='font-fontfamily font-bold text-14px grid grid-cols-2 lg:grid-cols-2 md:grid-cols-1 sm:grid-cols-1 xsm:grid-cols-1' disabled={employeeModuleState.isDisable} >
            <div className='grid grid-cols-12 my-2 gap-y-2 items-center' >
              <span className={gridSplit_firstSet}><Label label='Employer Name' required={true} /></span>
              <span className={gridSplit_secondSet}><TextField onChange={(e) => setValue(employerName, e.target.value)} value={watch(employerName)} isRequired={true} /></span>
              <span className={gridSplit_firstSet}> <Label label='Designation' required={true} /></span>
              <span className={gridSplit_secondSet}><TextField onChange={(e) => setValue(designation, e.target.value)} value={watch(designation)} isRequired={true} /></span>
              <span className={gridSplit_firstSet}> <Label label='Date of join' required={true} /></span>
              <span className={gridSplit_secondSet}><DatePickerElement onChange={(date) => { setValue(dateofJoin, date) }} value={watch(dateofJoin)} maxDate={watch(relievingDate) ? watch(relievingDate) : new Date()} isRequired={true} isViewable={employeeModuleState.isDisable} /></span>
              <span className={gridSplit_firstSet}> <Label label='Date of Relieve' required={true} /></span>
              <span className={gridSplit_secondSet}><DatePickerElement onChange={(date) => setValue(relievingDate, date)} value={watch(relievingDate)} isRequired={true} minDate={watch(dateofJoin)} isViewable={employeeModuleState.isDisable} /></span>
              <span className={gridSplit_firstSet}> <Label label='Reported To' required={true} /></span>
              <span className={gridSplit_secondSet}><TextField onChange={(e) => setValue(reportingTo, e.target.value)} value={watch(reportingTo)} isRequired={true} /></span>
              <span className={gridSplit_firstSet}> <Label label="Certificate Image" /></span>
              <span className={gridSplit_secondSet}><UploadAndDeleteDocument label="Certificate Image" onChange={file => setValue(strings.workHistory.employeeImage, file)} file={watch(strings.workHistory.employeeImage)} isViewable={employeeModuleState.isDisable} isMultiDocument /></span>
            </div>
          </fieldset>
          <div className="justify-center flex flex-row gap-5 sm:flex-row my-3 lg:my-3 md:my-1 sm:my-0 xsm:my-0">
            {employeeModuleState.isDisable || <Button value={Object.keys(watch(strings.workHistory.selectedData)).length > 0 ? strings.Buttons.Update : strings.Buttons.Save} disabled={!onSaveValidation()} onClick={handleSubmit(onSubmit)} />}
            {employeeModuleState.isDisable && <Button value={strings.Buttons.CustomClear} onClick={() => resetRecords()} />}
            <Button value={strings.Buttons.Close} onClick={() => history.push(routerPath.staff)} />
            {employeeModuleState.isDisable || <Button value={strings.Buttons.Reset} onClick={() => onReset()} />}
          </div>
          <AgGrid data={watch(strings.workHistory.data) ? watch(strings.workHistory.data) : []} columns={employeeDetails.workHistory_columns(setLoaderValue, !loginResponseState.isMobileCompatible, loginResponseState.isMobileCompatible, setEditBack)} height="h-[calc(93vh-289px-3.5rem-48px-4.6rem-6rem)] md:h-[calc(93vh-289px-3.5rem-48px-4.6rem-6rem)] xsm:h-[22.5rem]" ContextMenuItems={loginResponseState.isMobileCompatible ? false : employeeDetails.workHistory_contextMenuItems} history={history} callBack={setEditBack} isAutoHeight maxScrollCount={5} />
        </div>
      </div>
      {loader && <TransparentLoader />}
      {!loginResponseState.multiDocumentViewer.show && loginResponseState.imageViewer.show && <ImageViewer />}
      {loginResponseState.multiDocumentViewer.show && <MultiImageViewer />}
      {loginResponseState.apiResponse.show && <ApiResponse setResponseCallback={setDeleteConfirm} />}
    </div>
  )
}

export default WorkHistory

const initialState = {
  employeeId: 0,
  employerName: "",
  designation: "",
  dateofJoin: "",
  relievingDate: "",
  reportingTo: "",
  employeeImage: [],
  selectedData: {},
  modifiedBy: ""
}

