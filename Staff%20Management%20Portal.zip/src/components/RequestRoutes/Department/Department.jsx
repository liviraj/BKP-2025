import { useEffect } from "react"
import AgGrid from "../../Grid/AgGrid"
import { useForm } from "react-hook-form"
import Button from "../../elements/Button"
import Dropdown from "../../elements/Dropdown"
import { exportDateFormat } from "../../helper"
import AddButton from "../../elements/AddButton"
import ApiResponse from "../../Alert/ApiResponse"
import { departmentRequest } from "../../requests"
import { DepartmentColumn } from "../../Grid/Columns"
import { useDispatch, useSelector } from "react-redux"
import { HolidayNameStatus, strings } from "../../Constants"
import SubHeaderSection from "../../layouts/SubHeaderSection"
import TransparentLoader from "../../loader/TransparentLoader"
import DepartmentPopup from "../../Popup_window/DepartmentPopup"
import { departmentActions } from "../../../redux/departmentReducer"

function Department() {

    const dispatch = useDispatch();
    const { departmentNamePopup, loader, departmentName } = useSelector(state => state.department);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const { UserID } = useSelector(state => state.user);
    const loginResponseState = useSelector(state => state.loginResponse);

    const { watch, setValue, getValues } = useForm({ defaultValues: initialValue });

    const addDepartmentNamePopupVisibale = () => {
        dispatch(departmentActions.setDepartmentNamePopup({ show: true, action: "Add" }));
    }

    useEffect(() => {
        const onInitialLoad = async () => {
            await dispatch(departmentActions.setLoader(true));
            await handleReset()
            await dispatch(departmentActions.setLoader(false));
        }
        onInitialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const handleSearch = async () => {
        await dispatch(departmentActions.setLoader(true));
        const data = getValues();
        let params = {
            status: data.status.label,
        }
        await dispatch(departmentRequest.departmentScreenRequest.getFilterDepartmentRequest(params));
        dispatch(departmentActions.setLoader(false));

    }

    const onDeleteConfirmation = async (isAcceptable) => {
        if (isAcceptable) {
            await dispatch(departmentActions.setLoader(true));
            const params = {
                id: departmentNamePopup.selectedRow?.id,
                modifiedBy: UserID,
                modifiedDate: exportDateFormat(new Date()),
            }
            await dispatch(departmentRequest.departmentScreenRequest.deleteDepartmentRequest(params, setCallBack));
            dispatch(departmentActions.setLoader(false));
        }
    }

    const setCallBack = async (status) => {
        if (status) {
            await dispatch(departmentActions.reSetDepartmentPoup());
            await handleSearch();
        }
    }

    const handleReset = async () => {
        await dispatch(departmentActions.setLoader(true));
        setValue(strings.department.status, HolidayNameStatus[1]);
        await handleSearch();
        dispatch(departmentActions.setLoader(false));
    }
    return (
        <><div className='px-6 ' >
            <SubHeaderSection subHeader="Department" fileProps={{ columns: DepartmentColumn.department.column(loginResponseState.isMobileCompatible), data: departmentName.data?.map((val, inx) => ({ ...val, sno: inx + 1, })), docName: 'Department' }} />
            <div className='grid  gap-x-4 gap-y-1 xl:grid-cols-5 lg:grid-cols-4  md:grid-cols-2 sm:grid-cols-3 w-full mb-6'>
                <Dropdown options={HolidayNameStatus} value={watch(strings.department.status)} onChange={value => setValue(strings.department.status, value)} isLabelView={true} placeholder={"Status"} />
                <div className=' self-end flex gap-3'>
                    <Button value={strings.Buttons.Submit} onClick={handleSearch} />
                    <Button value={strings.Buttons.Reset} onClick={handleReset} />
                </div>
            </div>
            <AgGrid data={departmentName?.data} columns={DepartmentColumn.department.column(loginResponseState.isMobileCompatible)} ContextMenuItems={loginResponseState.isMobileCompatible ? false : DepartmentColumn.department.contextMenuItems} isDesignationActiveSelectable height="lg:h-[calc(100vh-17rem)] md:h-[calc(100vh-17rem)]  sm:h-[calc(100vh-16rem)] h-[calc(100vh-18.5rem)] " isSetFilter />
            <div className="mx-2 flex flex-row items-center font-fontfamily text-14px font-bold mt-3 text-darkGrey mb-3" >
                <AddButton value={strings.Buttons.addDepartment} onClick={addDepartmentNamePopupVisibale} />
            </div>
        </div>
            {loader && <TransparentLoader />}
            {departmentNamePopup?.show && <DepartmentPopup setCallBack={setCallBack} />}
            {(!departmentNamePopup.show && apiResponseState.show) && <ApiResponse setResponseCallback={onDeleteConfirmation} />}
        </>
    )
}

export default Department;

const initialValue = {
    status: HolidayNameStatus[1],
}

