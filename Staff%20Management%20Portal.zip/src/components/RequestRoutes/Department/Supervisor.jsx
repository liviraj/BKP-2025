import SubHeaderSection from "../../layouts/SubHeaderSection"
import AgGrid from "../../Grid/AgGrid"
import { SupervisorColumn } from "../../Grid/Columns"
import { useEffect } from "react"
import AddButton from "../../elements/AddButton"
import { strings } from "../../Constants"
import { useDispatch, useSelector } from "react-redux"
import TransparentLoader from "../../loader/TransparentLoader"
import SupervisorPopup from "../../Popup_window/SupervisorPopup"
import Dropdown from "../../elements/Dropdown"
import Button from "../../elements/Button"
import { useForm } from "react-hook-form"
import { departmentRequest, employeeRequests } from "../../requests"
import ApiResponse from "../../Alert/ApiResponse"
import { employeeReducerState, exportDateFormat, userReducerState } from "../../helper"
import { departmentActions } from "../../../redux/departmentReducer"

function SuperVisor() {
    const dispatch = useDispatch();
    const employeeState = useSelector(state => state.employee);
    const { data, departmentSupervisorPopup } = useSelector(state => state.department.departmentSupervisor);
    const { loader } = useSelector(state => state.department)
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const { UserID, Role } = useSelector(state => state.user);
    const loginResponseState = useSelector(state => state.loginResponse);

    const { watch, setValue, getValues } = useForm({ defaultValues: initialState })

    useEffect(() => {
        const initialLoad = async () => {
            await dispatch(departmentActions.setLoader(true));
            employeeState.location.length <= 0 && await dispatch(employeeRequests.location());
            await dispatch(employeeRequests.employeeDepartment());
            await handleReset();
            dispatch(departmentActions.setLoader(false));
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const handleReset = async () => {
        await dispatch(departmentActions.setLoader(true));
        await setValue(strings.departmentSupervisor.location, employeeReducerState().location.find(val => val.value === userReducerState().LocationID));
        await setValue(strings.departmentSupervisor.departmentName, employeeReducerState().department.find(val => val.value === 0));
        await handleSearch();
        dispatch(departmentActions.setLoader(false));
    }

    const handleSearch = async () => {
        await dispatch(departmentActions.setLoader(true));
        let values = getValues()
        const payload = {
            locationId: values.location ? values.location.value : 0,
            // masterId: values.departmentName ? values.departmentName.value : 0
        }
        await dispatch(departmentRequest.departmentSupervisor.getDepartmentSupervisor(payload));
        dispatch(departmentActions.setLoader(false));
    }
    const setCallBack = async (isValid) => {
        if (isValid) {
            await dispatch(departmentActions.setLoader(true));
            await dispatch(departmentActions.setSupervisorPopup({ show: false, action: "", selectedRecord: {} }));
            await handleSearch();
            dispatch(departmentActions.setLoader(false));
        }

    }

    const setResponseCallback = async (status) => {
        await dispatch(departmentActions.setLoader(true));
        if (status) {
            const data = departmentSupervisorPopup.selectedRow;
            const params = {
                "id": data?.autoId,
                "isExists": true,
                "locationId": data?.location?.value,
                "modifiedBy": UserID,
                "modifiedDate": exportDateFormat(new Date())
            }
            await dispatch(departmentRequest.departmentSupervisor.deleteDepartmentSupervisorRequest(params, setCallBack));
        }
        dispatch(departmentActions.setLoader(false));

    }

    return (
        <><div className='px-6 overflow-hidden h-auto' >
            <SubHeaderSection subHeader="Supervisor" fileProps={{ columns: SupervisorColumn.supervisor.column(loginResponseState.isMobileCompatible), data: data?.map((val, idx) => ({ ...val, sno: idx + 1 })), docName: 'Department Supervisor' }} />
            <div className='flex mb-6 md:mb-6 xsm:mb-4' >
                <div className='grid md:grid-rows-1 sm:grid-rows-2 xsm:grid-rows-3 gap-x-4 gap-y-1 lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 xsm:grid-cols-1 w-full'>
                    {/* <div><Dropdown placeholder={"Department Name"} value={watch(strings.departmentSupervisor.departmentName)} options={employeeState.department} onChange={e => setValue(strings.departmentSupervisor.departmentName, e)} isSearchable={true} isLabelView={true} /></div> */}
                    <div><Dropdown placeholder={"Location"} value={watch(strings.departmentSupervisor.location)} options={employeeState.location} onChange={data => setValue(strings.departmentSupervisor.location, data)} isLabelView={true} isDisable={Role === strings.userRoles.humanResource} isRequired={true} /></div>
                    <div className=' self-end flex'>
                        <Button value={strings.Buttons.Search} onClick={handleSearch} disabled={!(watch(strings.departmentSupervisor.location) && watch(strings.departmentSupervisor.departmentName))} />
                        <span className=' mx-3'> <Button value={strings.Buttons.Reset} onClick={handleReset} /></span>
                    </div>
                </div>
            </div>
            <AgGrid data={data} columns={SupervisorColumn.supervisor.column(loginResponseState.isMobileCompatible)} ContextMenuItems={loginResponseState.isMobileCompatible ? false : SupervisorColumn.supervisor.contextMenuItems} history={history} height="h-[calc(94vh-20rem)] md:h-[calc(94vh-13.6rem)] sm:h-[calc(94vh-16.2rem)] xsm:h-[calc(94vh-20.6rem)]" />
            <div className="mx-2 flex flex-row items-center font-fontfamily text-14px font-bold mt-3 text-darkGrey mb-3" >
                <AddButton value={strings.Buttons.addSupervisor} onClick={() => dispatch(departmentActions.setSupervisorPopup({ show: true, action: "Add" }))} />
            </div>
        </div>
            {loader && <TransparentLoader />}
            {departmentSupervisorPopup?.show && <SupervisorPopup setCallBack={setCallBack} />}
            {(apiResponseState.show && !departmentSupervisorPopup?.show) && <ApiResponse setResponseCallback={setResponseCallback} />}
        </>
    )
}

export default SuperVisor;

const initialState = {
    location: '',
    departmentName: ''
}
