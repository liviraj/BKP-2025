import { useState, useEffect } from 'react';
import HeaderSection from '../../layouts/HeaderSection';
import { useForm } from "react-hook-form";
import { strings } from '../../Constants';
import { useDispatch, useSelector } from 'react-redux';
import SubHeaderSection from '../../layouts/SubHeaderSection';
import DatePickerElement from '../../elements/DatePickerElement';
import Button from '../../elements/Button';
import Dropdown from '../../elements/Dropdown';
import { leaveManagement } from '../../Grid/Columns';
import AgGrid from '../../Grid/AgGrid';
import { useHistory } from 'react-router-dom';
import { employeeRequests, leaveManagementRequest, sickLeaveRequests } from '../../requests';
import TransparentLoader from '../../loader/TransparentLoader';
import { exportDateFormat, periodOptions, userReducerState, periodDateFormat, employeeReducerState, dateFormat, leaveManagementReducerState } from '../../helper';
import ApiResponse from '../../Alert/ApiResponse';
import LeaveLedgerEditScreen from '../../Popup_window/LeaveLedgerEditScreen';
import { leaveManagementActions } from '../../../redux/leaveManagementReducer';
import AddButton from '../../elements/AddButton';

function ViewEditLeaveLedger() {
	const history = useHistory();
	const { watch, setValue, getValues } = useForm({ defaultValues: initialState });
	const employeeState = useSelector(state => state.employee);
	const leaveLedgerState = useSelector(state => state.leaveManagement.leaveLedger);
	const leaveManagementState = useSelector(state => state.leaveManagement);
	const loginResponseState = useSelector(state => state.loginResponse);
	const dispatch = useDispatch();
	const [loader, setLoader] = useState(false);
	const location = watch(strings.leaveRequestQueue.location);

	useEffect(() => {
		const fetchValues = async () => {
			setLoader(true);
			await Promise.all([
				employeeState.employeeStatus <= 0 && dispatch(employeeRequests.status()),
				employeeState.employeeName.length <= 0 && dispatch(employeeRequests.employeeName()),
				employeeState.location.length <= 0 && dispatch(employeeRequests.location()),
				Object.keys(leaveManagementState.payroll).length <= 0 && dispatch(leaveManagementRequest.getPayroll())
			])
			await onReset();
			setLoader(false);
		}
		fetchValues();
		return () => dispatch(leaveManagementActions.setLeaveLedgerData([]));
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	useEffect(() => {
		setValue(strings.leaveRequestQueue.employeeNameOptions, filterEmployeeName(employeeState.employeeName ? employeeState.employeeName : [], watch(strings.leaveRequestQueue.location), watch(strings.leaveRequestQueue.status)));
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [employeeState.employeeName, watch(strings.leaveRequestQueue.location), watch(strings.leaveRequestQueue.status)]);

	const onReset = async () => {
		setLoader(true);
		let editData = leaveLedgerState.isUPloadAuditorEdit;
		setValue(strings.leaveRequestQueue.location, employeeReducerState().location.find(val => val.value === userReducerState().LocationID));
		setValue(strings.leaveRequestQueue.status, employeeReducerState().employeeStatus.find((val) => val.label === "Active"));

		if (editData.show) {
			onPeriodChange(periodOptions.find((val) => val.value === 2));
			setValue(strings.leaveRequestQueue.fromDate, editData?.fromDate)
			setValue(strings.leaveRequestQueue.toDate, editData?.toDate)
			setValue(strings.leaveRequestQueue.employeeName, watch(strings.leaveRequestQueue.employeeNameOptions).find(val => val.employeeId == editData.employeeId));
			setValue(strings.leaveRequestQueue.leaveType, leaveManagementReducerState().allLeaveTypes.find(val => val.value === Number(editData?.leaveType)));
			await onSubmit()
		}
		else {
			onPeriodChange(periodOptions.find((val) => val.value === 7));
			setValue(strings.leaveRequestQueue.employeeName, "");
			setValue(strings.leaveRequestQueue.leaveType, "");
			dispatch(leaveManagementRequest.setLeaveLedgerData([]));
		}
		setLoader(false);
	}

	const onPeriodChange = (value) => {
		setValue(strings.leaveRequestQueue.period, value);
		periodDateFormat(value, setValue);
	}

	const filterLeaveLedger = () => {
		let filterRecords = {};
		const data = getValues();
		const employeeName = data.employeeName;
		const employeeStatus = data.status;
		const employeeLocation = data.location;
		const period = data.period;
		if (employeeName) {
			filterRecords = { ...filterRecords, employeeId: employeeName.value }
		}
		if (employeeStatus) {
			filterRecords = { ...filterRecords, employmentStatus: employeeStatus.label }
		}
		if (employeeLocation) {
			filterRecords = { ...filterRecords, locationId: employeeLocation.value }
		}
		if ("leaveType" in data) {
			filterRecords = { ...filterRecords, leaveType: data.leaveType.label }
		}
		if (period && period.label !== "All") {
			filterRecords = { ...filterRecords, fromDate: exportDateFormat(data.fromDate, true), toDate: exportDateFormat(data.toDate, true) }
		}
		return filterRecords;
	}

	const onSubmit = async () => {
		await setLoader(true);
		await dispatch(leaveManagementRequest.leaveLedger.getLeaveLedger(filterLeaveLedger()));
		setLoader(false);
	}

	const filterEmployeeName = (employeeName, location, status) => {
		let filterData = employeeName && employeeName.length > 0 ? [...employeeName] : [];
		if (employeeName && location && status) {
			if (location.value !== 0) {
				filterData = filterData.filter(val => (val.locationId === location.value || val.locationId === 0));
			}
			if (status.label !== "All") {
				if (status.label === "Active") {
					filterData = filterData.filter(val => ((val.employmentStatus !== "Relieved" && val.employmentStatus !== "") || val.employmentStatus === "All"));
				}
				else {
					filterData = filterData.filter(val => (val.employmentStatus === status.label || val.employmentStatus === "All"));
				}
			}
		}
		return filterData;
	}

	const onLedgerDelete = async (acceptanceFlag) => {
		if (acceptanceFlag) {
			await setLoader(true);
			const data = {
				leaveType: leaveLedgerState.selectedRow.leaveType,
				locationId: leaveLedgerState.selectedRow.locationId,
				updatedBy: userReducerState().UserID
			}
			await dispatch(leaveManagementRequest.leaveLedger.deleteLeaveLedger(leaveLedgerState.selectedRow.leaveLedgerId, data));
			await dispatch(leaveManagementRequest.leaveLedger.getLeaveLedger(filterLeaveLedger()));
			setLoader(false);
		}
	}

	const updateLeaveLedger = async (ledgerData, type) => {
		await setLoader(true);
		const selectedRow = leaveLedgerState.selectedRow;
		if (type) {
			const data = type === "Add" ? {
				comments: ledgerData.comments,
				creditAddedBy: userReducerState().UserID,
				creditAddedOn: exportDateFormat(new Date()),
				creditDays: ledgerData.creditDays,
				employeeId: selectedRow.employeeId,
				entryDate: exportDateFormat(ledgerData.entryDate),
				leaveType: ledgerData.leaveType.label,
				locationId: selectedRow.locationId
			} : {
				comments: ledgerData.comments,
				creditAddedBy: userReducerState().UserID,
				creditAddedOn: exportDateFormat(new Date()),
				creditDays: ledgerData.creditDays,
				employeeId: ledgerData.employeeName.value,
				entryDate: exportDateFormat(ledgerData.entryDate),
				leaveType: ledgerData.leaveType.label,
				locationId: ledgerData.location.value
			}
			await dispatch(sickLeaveRequests.LeaveLedger.addLeaveLedger(data));
		}
		else {
			const data = {
				balanceDays: selectedRow.balanceDays,
				comments: ledgerData.comments,
				creditDays: ledgerData.creditDays,
				debitDays: ledgerData.debitDays,
				employeeId: ledgerData.employeeId,
				leaveType: selectedRow.leaveType,
				locationId: selectedRow.locationId,
				modifiedBy: userReducerState().UserID,
				modifiedOn: exportDateFormat(new Date())
			}
			await dispatch(leaveManagementRequest.leaveLedger.updateLeaveLedger(data, selectedRow.leaveLedgerId));
		}
		await onSubmit();
		setLoader(false);
	}

	const onlocationChange = async (data) => {
		if (leaveManagementState.allLeaveTypes && location && data.value !== 0) {
			const leaveType = watch(strings.leaveRequestQueue.leaveType);
			const isValid = leaveManagementState.allLeaveTypes.filter(val => val.locationId === data.value).find(val => val.label === leaveType.label);
			if (!isValid) {
				await setValue(strings.leaveRequestQueue.leaveType, leaveManagementState.allLeaveTypes.find(val => val.locationId === 0));
			}
		}
		await setValue(strings.leaveRequestQueue.location, data);
	}

	return (
		<div>
			<HeaderSection redirectType={strings.type.leaveManagement} />
			<div className='px-6 overflow-auto h-auto md:max-h-h_body_md sm:max-h-full'>
				<SubHeaderSection subHeader="View & Edit Leave Ledger" fileProps={{ columns: leaveManagement.leaveLedger.column(history), data: leaveLedgerState.data.map((val, idx) => ({ ...val, sno: idx + 1, entryDate: val.entryDate ? dateFormat(val.entryDate) : "" })), docName: "Leave Ledger" }} />
				<div className='flex mb-6 md:mb-6 xsm:mb-4' >
					<div className='grid xl:grid-rows-1 lg:grid-rows-2 md:grid-rows-2 sm:grid-rows-3 xsm:grid-rows-3 gap-x-4 gap-y-1 xl:grid-cols-4 lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 xsm:grid-cols-1 w-full'>
						<div><Dropdown placeholder={"Period"} options={periodOptions} value={watch(strings.leaveRequestQueue.period)} onChange={e => onPeriodChange(e)} isLabelView={true} /></div>
						<div><DatePickerElement placeholder='From' disabled={watch(strings.leaveRequestQueue.period).label !== strings.filterPeriod.custom} value={watch(strings.leaveRequestQueue.fromDate) ? watch(strings.leaveRequestQueue.fromDate) : ""} onChange={date => setValue(strings.leaveRequestQueue.fromDate, date)} isRequired={true} isLabelView={true} /></div>
						<div><DatePickerElement placeholder='To' disabled={watch(strings.leaveRequestQueue.period).label !== strings.filterPeriod.custom} value={watch(strings.leaveRequestQueue.toDate) ? watch(strings.leaveRequestQueue.toDate) : ""} minDate={watch(strings.leaveRequestQueue.period).label === strings.filterPeriod.custom && watch(strings.leaveRequestQueue.fromDate)} onChange={date => setValue(strings.leaveRequestQueue.toDate, date)} isRequired={true} isLabelView={true} /></div>
						<div><Dropdown placeholder={"Location"} value={location} options={employeeState.location} onChange={data => userReducerState().Role === strings.userRoles.humanResource || onlocationChange(data)} isSearchable={true} isLabelView={true} isDisable={userReducerState().Role === strings.userRoles.humanResource} /></div>
						<div><Dropdown placeholder={"Status"} value={watch(strings.leaveRequestQueue.status)} options={employeeState.employeeStatus} onChange={e => setValue(strings.leaveRequestQueue.status, e)} isSearchable={true} isLabelView={true} /></div>
						<div><Dropdown placeholder={"Employee Name"} value={watch(strings.leaveRequestQueue.employeeName)} options={watch(strings.leaveRequestQueue.employeeNameOptions)} onChange={e => setValue(strings.leaveRequestQueue.employeeName, e)} isSearchable={true} isLabelView={true} /></div>
						<div><Dropdown placeholder={"Leave Type"} value={watch(strings.leaveRequestQueue.leaveType)} options={leaveManagementState.allLeaveTypes && location ? leaveManagementState.allLeaveTypes.filter(val => (location.value === 0 && val.locationId === 1) || (val.locationId === 0 || val.locationId === location.value)) : []} onChange={e => setValue(strings.leaveRequestQueue.leaveType, e)} isLabelView={true} /></div>
						<div className=' self-end flex gap-x-3'>
							<Button value={strings.Buttons.Search} onClick={onSubmit} disabled={!(watch(strings.leaveRequestQueue.period) && location && watch(strings.leaveRequestQueue.employeeName) && watch(strings.leaveRequestQueue.status) && watch(strings.leaveRequestQueue.leaveType))} />
							<Button value={strings.Buttons.Reset} onClick={() => onReset()} />
						</div>
					</div>
				</div>
				<AgGrid data={leaveLedgerState.data} rowSelection={true} columns={leaveManagement.leaveLedger.column(loginResponseState.isMobileCompatible)} ContextMenuItems={loginResponseState.isMobileCompatible ? false : leaveManagement.leaveLedger.contextMenuItems} history={history} height="h-[calc(94vh-67px-67px-3.5rem-1.5rem-3.5rem-4.6rem)] lg:h-[calc(94vh-67px-67px-3.5rem-1.5rem-3.5rem-4.6rem-0.5rem)] md:h-[calc(94vh-67px-67px-67px-3.5rem-1.5rem-3.5rem-4.6rem-0.5rem)] xsm:h-[58vh]" />
				<div className="mx-2 flex flex-row items-center font-fontfamily text-14px font-bold mt-3 text-darkGrey" >
					<AddButton value={strings.Buttons.AddCreditDays} onClick={() => dispatch(leaveManagementActions.setLeaveLedgerAddPopup({ showPopUp: true, type: "setCommonPopup" }))} />
				</div>
			</div>
			{loginResponseState.apiResponse.show && <ApiResponse setResponseCallback={onLedgerDelete} />}
			{loader && <TransparentLoader />}
			{leaveLedgerState.showPopUp && <LeaveLedgerEditScreen onConfirmedValue={updateLeaveLedger} />}
		</div>
	)
}

const initialState = {
	location: "",
	employeeName: "",
	status: "",
	period: "",
	fromDate: "",
	toDate: "",
	employeeNameOptions: [],
	leaveType: ""
}

export default ViewEditLeaveLedger