import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { useDispatch, useSelector } from 'react-redux'
import { employeeRequests, leaveManagementRequest, sickLeaveRequests } from '../../requests'
import HeaderSection from '../../layouts/HeaderSection'
import { setDefaultValue, strings } from '../../Constants'
import SubHeaderSection from '../../layouts/SubHeaderSection'
import Dropdown from '../../elements/Dropdown'
import Button from '../../elements/Button'
import DatePickerElement from '../../elements/DatePickerElement'
import AgGrid from '../../Grid/AgGrid'
import TransparentLoader from '../../loader/TransparentLoader'
import { sickLeaveActions } from '../../../redux/sickLeaveReducer'
import moment from 'moment-timezone'
import { sickLeave } from '../../Grid/Columns'
import { dateFormat, employeeReducerState, userReducerState } from '../../helper'


function LeaveSummaryDetails() {
    const { handleSubmit, watch, setValue, reset } = useForm({ defaultValues: initialState });
    const employeeState = useSelector(state => state.employee);
    const leaveManagementState = useSelector(state => state.leaveManagement);
    const summaryDetailState = useSelector(state => state.sickLeave.summaryDetails);
    const location = watch(strings.LeaveSummaryDetails.location);
    const dispatch = useDispatch();

    useEffect(() => {
        const componentDidMount = async () => {
            await dispatch(sickLeaveActions.setSummaryDetailLoader(true));
            await Promise.all([
                leaveManagementState.leaveType.length <= 0 && dispatch(leaveManagementRequest.leaveRequest.getLeaveType(userReducerState().LocationID)),
                employeeState.employeeName.length <= 0 && dispatch(employeeRequests.employeeName()),
                employeeState.location.length <= 0 && dispatch(employeeRequests.location())
            ]);
            await resetRecords();
            await setValue(strings.LeaveSummaryDetails.location, employeeState.location.find(val => val.value === userReducerState().LocationID));
            dispatch(sickLeaveActions.setSummaryDetailLoader(false));
        };
        componentDidMount();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const resetRecords = async () => {
        await dispatch(sickLeaveActions.setSummaryDetailLoader(true));
        await reset();
        await setValue(strings.LeaveSummaryDetails.location, employeeReducerState().location.find(val => val.value === userReducerState().LocationID));
        await setValue(strings.LeaveSummaryDetails.employeeName, "");
        await setValue(strings.LeaveSummaryDetails.leaveType, "");
        await dispatch(sickLeaveActions.setSummaryDetailsData([]));
        dispatch(sickLeaveActions.setSummaryDetailLoader(false));
    }

    const onSubmit = async (data) => {
        await dispatch(sickLeaveActions.setSummaryDetailLoader(true));
        let params = {};
        if ("year" in data) {
            params = { ...params, year: moment(data.year).format("YYYY") }
        }
        if ("employeeName" in data) {
            params = { ...params, employeeId: data.employeeName.value, employmentStatus: data.employeeName.employmentStatus }
        }
        if ("location" in data) {
            params = { ...params, locationId: data.location.value }
        }
        if ("leaveType" in data) {
            params = { ...params, leaveType: data.leaveType.label }
        }
        await dispatch(sickLeaveRequests.SummaryDetails.getFilterParams(params));
        dispatch(sickLeaveActions.setSummaryDetailLoader(false));
    }

    const onlocationChange = async (data) => {
        const employeeName = watch(strings.LeaveSummaryDetails.employeeName);
        if (leaveManagementState.allLeaveTypes && location && data.value !== 0) {
            const leaveType = watch(strings.LeaveSummaryDetails.leaveType);
            const isValid = leaveManagementState.allLeaveTypes.filter(val => val.locationId === data.value).find(val => val.label === leaveType.label);
            if (!isValid) {
                await setValue(strings.LeaveSummaryDetails.leaveType, leaveManagementState.allLeaveTypes.find(val => val.locationId === 0));
            }
        }
        if (employeeName && employeeState.employeeName && location) {
            if (employeeName.value !== 0 && employeeName.locationId !== data.value && data.value !== 0) {
                await setValue(strings.LeaveSummaryDetails.employeeName, setDefaultValue.employeeName);
            }
        }
        await setValue(strings.LeaveSummaryDetails.location, data);
    }

    return (
        <div>
            <HeaderSection redirectType={strings.type.leaveManagement} />
            <div className='px-6 overflow-hidden h-auto md:max-h-h_body_md sm:max-h-full'>
                <SubHeaderSection subHeader={"Leave Summary"} fileProps={{ columns: sickLeave.summaryDetails.column(), data: summaryDetailState.data.map((val, idx) => ({ ...val, sno: idx + 1, entryDate: dateFormat(val.entryDate) })), docName: "Sick Leave Summary" }} />
                <div className='flex mb-6'>
                    <div className='grid grid-rows-1 md:grid-rows-1 sm:grid-rows-2 xsm:grid-rows-3 gap-x-4 gap-y-1 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-2 w-full'>
                        <div><DatePickerElement showYearDropdown={true} value={watch(strings.LeaveSummaryDetails.year) ? watch(strings.LeaveSummaryDetails.year) : ""} onChange={date => setValue(strings.LeaveSummaryDetails.year, date)} isRequired={true} isLabelView={true} placeholder={strings.dropDowns.ReportCompliance.Year} /></div>
                        <div><Dropdown placeholder={strings.dropDowns.ReportCompliance.EmployeeName} value={watch(strings.LeaveSummaryDetails.employeeName) ? watch(strings.LeaveSummaryDetails.employeeName) : ""} onChange={data => setValue(strings.LeaveSummaryDetails.employeeName, data)} isLabelView={true}
                            options={location && employeeState.employeeName.filter((val) => ((val.locationId === setDefaultValue.defaultLocation.value) || ((location.value === setDefaultValue.defaultLocation.value || val.locationId === location.value) && (val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation))))} isSearchable={true} /></div>
                        <div><Dropdown placeholder={"Location"} value={location} options={employeeState.location ? employeeState.location : []} onChange={data => userReducerState().Role === strings.userRoles.humanResource || onlocationChange(data)} isLabelView={true} isDisable={userReducerState().Role === strings.userRoles.humanResource} /></div>
                        <div><Dropdown placeholder={"Leave Type"} value={watch(strings.LeaveSummaryDetails.leaveType)} options={leaveManagementState.allLeaveTypes && location ? leaveManagementState.allLeaveTypes.filter(val => (location.value === 0 && val.locationId === 1) || (val.locationId === 0 || val.locationId === location.value)) : []} onChange={e => setValue(strings.LeaveSummaryDetails.leaveType, e)} isLabelView={true} /></div>
                        <div className=' self-end flex gap-x-3'>
                            <Button value={strings.Buttons.Search} disabled={!(watch(strings.LeaveSummaryDetails.year) && watch(strings.LeaveSummaryDetails.employeeName) && location && watch(strings.LeaveSummaryDetails.leaveType))} onClick={handleSubmit(onSubmit)} />
                            <Button value={strings.Buttons.Reset} onClick={resetRecords} />
                        </div>
                    </div>
                </div>
                <AgGrid height="h-[calc(94vh-67px-3.5rem-1.5rem-3.5rem-2rem)] lg:h-[calc(94vh-67px-3.5rem-1.5rem-3.5rem-2rem)] md:h-[calc(94vh-67px-67px-3.5rem-1.5rem-3.5rem-2rem)] xsm:h-[70vh]" columns={sickLeave.summaryDetails.column()} data={summaryDetailState.data ? summaryDetailState.data : []} />
            </div>
            {summaryDetailState.loader && <TransparentLoader />}
        </div>
    )
}

export default LeaveSummaryDetails

const initialState = {
    year: new Date(),
    employeeName: ""
}