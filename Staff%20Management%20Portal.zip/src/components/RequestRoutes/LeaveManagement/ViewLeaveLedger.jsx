import { useState, useEffect } from 'react';
import HeaderSection from '../../layouts/HeaderSection';
import { useForm } from "react-hook-form";
import { setDefaultValue, strings } from '../../Constants';
import { useDispatch, useSelector } from 'react-redux';
import SubHeaderSection from '../../layouts/SubHeaderSection';
import DatePickerElement from '../../elements/DatePickerElement';
import Button from '../../elements/Button';
import Dropdown from '../../elements/Dropdown';
import { leaveManagement } from '../../Grid/Columns';
import AgGrid from '../../Grid/AgGrid';
import { useHistory } from 'react-router-dom';
import { employeeRequests, leaveManagementRequest } from '../../requests';
import TransparentLoader from '../../loader/TransparentLoader';
import { exportDateFormat, periodOptions, userReducerState, periodDateFormat, employeeReducerState, dateFormat, leaveManagementReducerState } from '../../helper';
import ApiResponse from '../../Alert/ApiResponse';
import { leaveManagementActions } from '../../../redux/leaveManagementReducer';

function ViewLeaveLedger() {
    const history = useHistory();
    const { watch, setValue, getValues } = useForm({ defaultValues: initialState });
    const employeeState = useSelector(state => state.employee);
    const leaveLedgerState = useSelector(state => state.leaveManagement.viewLeaveLedger);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const empDetails = useSelector(state => state.employee);
    const leaveManagementState = useSelector(state => state.leaveManagement);
    const userstate = useSelector(state => state.user)
    const dispatch = useDispatch();
    const [loader, setLoader] = useState(false);

    useEffect(() => {
        const fetchValues = async () => {
            setLoader(true);
            await Promise.all([
                employeeState.employeeStatus <= 0 && dispatch(employeeRequests.status()),
                Object.keys(leaveManagementState.payroll).length <= 0 && dispatch(leaveManagementRequest.getPayroll())
            ])
            await onReset();
            setLoader(false);
        }
        fetchValues();
        return () => dispatch(leaveManagementActions.setLeaveLedgerData([]));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onReset = async () => {
        await setLoader(true);
        await Promise.all([
            setValue(strings.leaveRequestQueue.employeeName, ""),
            setValue(strings.leaveRequestQueue.status, employeeReducerState().employeeStatus.find((val) => val.label === "Active")),
            leaveManagementReducerState().allLeaveTypes.length > 0 && await setValue(strings.leaveRequestQueue.leaveType, leaveManagementReducerState().allLeaveTypes.find(val => val.label === setDefaultValue.leaveType.label))
        ]);
        await onPeriodChange(periodOptions.find((val) => val.value === 7));
        await dispatch(leaveManagementRequest.setLeaveLedgerData([]));
        await onSubmit();
        setLoader(false);
    }

    const onPeriodChange = (value) => {
        setValue(strings.leaveRequestQueue.period, value);
        periodDateFormat(value, setValue);
    }

    const filterLeaveLedger = () => {
        let filterRecords = {};
        const data = getValues();
        const employeeName = userstate.UserID;
        const employeeStatus = empDetails?.employeeStatus.find((val) => val.label === 'Active');
        const employeeLocation = userstate.LocationID;
        const period = data.period;
        if (employeeName) {
            filterRecords = { ...filterRecords, employeeId: employeeName }
        }
        if (employeeStatus) {
            filterRecords = { ...filterRecords, employmentStatus: employeeStatus.label }
        }
        if (employeeLocation) {
            filterRecords = { ...filterRecords, locationId: employeeLocation }
        }
        if ("leaveType" in data) {
            filterRecords = { ...filterRecords, leaveType: data.leaveType.label }
        }
        if (period && period.label !== "All") {
            filterRecords = { ...filterRecords, fromDate: exportDateFormat(data.fromDate, true), toDate: exportDateFormat(data.toDate, true) }
        }
        return filterRecords;
    }

    const onSubmit = async () => {
        await setLoader(true);
        await dispatch(leaveManagementRequest.viewleaveLedger.getLeaveLedger(filterLeaveLedger()));
        setLoader(false);
    }

    return (
        <div>
            <HeaderSection redirectType={strings.type.leaveManagement} />
            <div className='px-6 overflow-hidden h-auto md:max-h-h_body_md sm:max-h-full'>
                <SubHeaderSection subHeader="View Leave Ledger" fileProps={{ columns: leaveManagement.viewleaveLedger.column(), data: leaveLedgerState.data.map((val, idx) => ({ ...val, sno: idx + 1, entryDate: val.entryDate ? dateFormat(val.entryDate) : "" })), docName: "View Leave Ledger" }} />
                <div className='flex mb-6 md:mb-6 xsm:mb-4' >
                    <div className='grid grid-rows-1 md:grid-rows-1 sm:grid-rows-2 xsm:grid-rows-3 gap-x-4 gap-y-1 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-2 w-full'>
                        <div><Dropdown placeholder={"Period"} options={periodOptions} value={watch(strings.leaveRequestQueue.period)} onChange={e => onPeriodChange(e)} isLabelView={true} /></div>
                        <div><DatePickerElement placeholder='From' disabled={watch(strings.leaveRequestQueue.period).label !== strings.filterPeriod.custom} value={watch(strings.leaveRequestQueue.fromDate) ? watch(strings.leaveRequestQueue.fromDate) : ""} onChange={date => setValue(strings.leaveRequestQueue.fromDate, date)} isRequired={true} isLabelView={true} /></div>
                        <div><DatePickerElement placeholder='To' disabled={watch(strings.leaveRequestQueue.period).label !== strings.filterPeriod.custom} value={watch(strings.leaveRequestQueue.toDate) ? watch(strings.leaveRequestQueue.toDate) : ""} minDate={watch(strings.leaveRequestQueue.period).label === strings.filterPeriod.custom && watch(strings.leaveRequestQueue.fromDate)} onChange={date => setValue(strings.leaveRequestQueue.toDate, date)} isRequired={true} isLabelView={true} /></div>
                        <div><Dropdown placeholder={"Leave Type"} value={watch(strings.leaveRequestQueue.leaveType)} options={leaveManagementState.allLeaveTypes ? leaveManagementState.allLeaveTypes.filter(val => (val.locationId === 0 || val.locationId === userReducerState().LocationID)) : []} onChange={e => setValue(strings.leaveRequestQueue.leaveType, e)} isLabelView={true} /></div>
                        <div className=' self-end flex gap-x-3'>
                            <Button value={strings.Buttons.Search} onClick={onSubmit} disabled={!(watch(strings.leaveRequestQueue.period) && watch(strings.leaveRequestQueue.leaveType))} />
                            <Button value={strings.Buttons.Reset} onClick={() => onReset()} />
                        </div>
                    </div>
                </div>
                <AgGrid data={leaveLedgerState.data} columns={leaveManagement.viewleaveLedger.column()} history={history} height="h-[calc(94vh-67px-3.5rem-1.5rem-3.5rem-2rem)] lg:h-[calc(94vh-67px-3.5rem-1.5rem-3.5rem-2rem)] md:h-[calc(94vh-67px-67px-3.5rem-1.5rem-3.5rem-2rem)] xsm:h-[70vh]" />
            </div>
            {apiResponseState.show && <ApiResponse />}
            {loader && <TransparentLoader />}
        </div>
    )
}

const initialState = {
    location: "",
    employeeName: "",
    status: "",
    period: "",
    fromDate: "",
    toDate: "",
    leaveType: ""
}

export default ViewLeaveLedger