import { useEffect, useState } from 'react'
import HeaderSection from '../../layouts/HeaderSection'
import { strings } from '../../Constants'
import AgGrid from '../../Grid/AgGrid'
import { leaveManagement } from '../../Grid/Columns'
import { useDispatch, useSelector } from 'react-redux'
import { leaveManagementRequest } from '../../requests'
import TransparentLoader from '../../loader/TransparentLoader'
import ApiResponse from '../../Alert/ApiResponse'
import SubHeaderSection from '../../layouts/SubHeaderSection'
import { useHistory } from 'react-router-dom';
import { periodOptionsWithoutPayroll, dateFormat, exportDateFormat, leaveStatus, periodDateFormat } from '../../helper';
import Dropdown from '../../elements/Dropdown'
import DatePickerElement from '../../elements/DatePickerElement'
import { useForm } from 'react-hook-form'
import Button from '../../elements/Button'
import LeaveRequestQueueApprovalView from '../../Popup_window/LeaveRequestQueueApprovalView'
import AddLeaveRequestPopup from '../../Popup_window/AddLeaveRequestPopup'

function LeaveHistory() {
    const dispatch = useDispatch();
    const history = useHistory();
    const leaveManagementState = useSelector(state => state.leaveManagement);
    const userState = useSelector(state => state.user);
    const { watch, setValue, getValues } = useForm({ defaultValues: initialState });
    const [openAddScreen, setOpenAddScreen] = useState(false);
    const loginResponseState = useSelector(state => state.loginResponse);

    useEffect(() => {
        const componentDidMount = async () => {
            await dispatch(leaveManagementRequest.setLoader(true));
            await dispatch(leaveManagementRequest.leaveStatus.getLeaveStatus())
            await onReset()
            dispatch(leaveManagementRequest.setLoader(false));
        }
        componentDidMount();

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onPeriodChange = (value) => {
        setValue(strings.leaveRequestQueue.period, value);
        periodDateFormat(value, setValue);
    }
    const filterLeaveReqQueue = async () => {
        await dispatch(leaveManagementRequest.setLoader(true));
        const data = getValues();
        let filterRecords = { employeeId: userState.UserID };
        const period = data.period;
        const employeeStatus = data.status;
        if (employeeStatus) {
            filterRecords = { ...filterRecords, approvalStatus: employeeStatus.label }
        }
        if (period && period.label !== "All") {
            filterRecords = { ...filterRecords, fromDate: exportDateFormat(data.fromDate, true), toDate: exportDateFormat(data.toDate, true) }
        }
        await dispatch(leaveManagementRequest.leaveHistory.getLeaveHistoryDatas(filterRecords));
        await dispatch(leaveManagementRequest.setLoader(false));

    }
    const onReset = async () => {
        await dispatch(leaveManagementRequest.setLoader(true));
        await setValue(strings.leaveRequestQueue.status, leaveStatus[4]);
        await onPeriodChange(periodOptionsWithoutPayroll[0]);
        await filterLeaveReqQueue();
        await dispatch(leaveManagementRequest.setLoader(false));
    }

    const handlePopup = () => {
        setOpenAddScreen(true)
    }

    const cacelLeaveRequest = async () => {
        await dispatch(leaveManagementRequest.setLoader(true));
        let selectedRow = leaveManagementState?.leaveRequestQueue?.leaveReqDetailsScreen?.selectedRowData;
        let filterRecords = {
            cancelRequestedBy: userState.UserID,
            cancelRequestedOn: exportDateFormat(new Date()),
            leaveRequestDetailId: selectedRow.map((val) => val.leaveRequestDetailsId),
            cancelRequestComments: leaveManagementState?.leaveRequestQueue?.leaveReqDetailsScreen?.comments
        }
        await dispatch(leaveManagementRequest.leaveHistory.cancelLeaveHistoryData(filterRecords, setCallBack));
        dispatch(leaveManagementRequest.setLoader(false));
    }

    const setCallBack = async (isSuccess) => {
        if (isSuccess) {
            filterLeaveReqQueue && await filterLeaveReqQueue();
        }
    }
    return (
        <div>
            <HeaderSection redirectType={strings.type.leaveManagement} />
            <div className='px-6 overflow-hidden h-auto md:max-h-h_body_md sm:max-h-full' >
                <SubHeaderSection subHeader="Leave History" fileProps={{ columns: leaveManagement.leaveHistory.column(), data: leaveManagementState.leaveHistory.map((val, idx) => ({ ...val, sno: idx + 1, leaveDate: val.leaveDate ? dateFormat(val.leaveDate) : "" })), docName: `${userState.Name} Leave_History` }} />
                <div className='flex mb-6 md:mb-6 xsm:mb-4 ' >
                    <div className='grid grid-rows-1 md:grid-rows-1 sm:grid-rows-2 xsm:grid-rows-3 gap-x-4 gap-y-1 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-2 w-full'>
                        <div><Dropdown placeholder={"Period"} options={periodOptionsWithoutPayroll} value={watch(strings.leaveHistory.period)} onChange={e => onPeriodChange(e)} isLabelView={true} /></div>
                        <div><DatePickerElement placeholder='From' disabled={watch(strings.leaveHistory.period).label !== strings.filterPeriod.custom} value={watch(strings.leaveHistory.fromDate)} onChange={date => setValue(strings.leaveHistory.fromDate, date)} isRequired={true} isLabelView={true} /></div>
                        <div><DatePickerElement placeholder='To' disabled={watch(strings.leaveHistory.period).label !== strings.filterPeriod.custom} value={watch(strings.leaveHistory.toDate)} onChange={date => setValue(strings.leaveHistory.toDate, date)} minDate={watch(strings.leaveHistory.period).label === strings.filterPeriod.custom && watch(strings.leaveHistory.fromDate)} isRequired={true} isLabelView={true} /></div>
                        <div><Dropdown placeholder={"Status"} value={watch(strings.leaveHistory.status)} options={leaveManagementState.leaveStatus && leaveManagementState.leaveStatus.length > 0 ? leaveManagementState.leaveStatus.filter(val => val.label !== leaveStatus[3].label) : []} onChange={e => setValue(strings.leaveHistory.status, e)} isSearchable={true} isLabelView={true} /></div>
                        <div className=' self-end flex'>
                            <Button value={strings.Buttons.Search} onClick={() => filterLeaveReqQueue()} disabled={watch(strings.leaveHistory.period).label === strings.filterPeriod.custom && (!watch(strings.leaveHistory.fromDate) || !watch(strings.leaveHistory.toDate))} />
                            <span className=' mx-3'> <Button value={strings.Buttons.Reset} onClick={() => onReset()} /></span>
                        </div>
                    </div>
                </div>
                <AgGrid height="h-[calc(94vh-67px-3.5rem-1.5rem-3.5rem-2rem)] lg:h-[calc(94vh-67px-3.5rem-1.5rem-3.5rem-2rem)] md:h-[calc(94vh-67px-67px-3.5rem-1.5rem-3.5rem-2rem)] xsm:h-[70vh]" data={leaveManagementState.leaveHistory} columns={leaveManagement.leaveHistory.column(true, loginResponseState.isMobileCompatible, handlePopup)} history={history} callBack={handlePopup} ContextMenuItems={loginResponseState.isMobileCompatible ? false : leaveManagement.leaveHistory.contextMenuItems} isLeaveHistoryRemoveSelectable={true} />
            </div>
            {<LeaveRequestQueueApprovalView isCancel={true} onSubmit={cacelLeaveRequest} />}
            {openAddScreen && <AddLeaveRequestPopup openAddScreen={openAddScreen} setOpenAddScreen={setOpenAddScreen} filterLeaveReqQueue={filterLeaveReqQueue} isEditable={true} />}
            {leaveManagementState.loader && <TransparentLoader />}
            {loginResponseState.apiResponse.show && !openAddScreen && <ApiResponse />}
        </div>
    )
}


const initialState = {
    period: "",
    fromDate: "",
    toDate: "",
    status: leaveStatus[4],
}
export default LeaveHistory