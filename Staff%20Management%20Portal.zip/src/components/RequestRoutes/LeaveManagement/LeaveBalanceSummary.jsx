import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { useDispatch, useSelector } from 'react-redux'
import { employeeRequests, leaveManagementRequest, sickLeaveRequests } from '../../requests'
import HeaderSection from '../../layouts/HeaderSection'
import { setDefaultValue, strings } from '../../Constants'
import SubHeaderSection from '../../layouts/SubHeaderSection'
import Dropdown from '../../elements/Dropdown'
import Button from '../../elements/Button'
import DatePickerElement from '../../elements/DatePickerElement'
import AgGrid from '../../Grid/AgGrid'
import TransparentLoader from '../../loader/TransparentLoader'
import { sickLeaveActions } from '../../../redux/sickLeaveReducer'
import moment from 'moment-timezone'
import { sickLeave } from '../../Grid/Columns'
import { employeeReducerState, userReducerState } from '../../helper'


function LeaveBalanceSummary() {
    const { handleSubmit, watch, setValue, reset, getValues } = useForm({ defaultValues: initialState });
    const employeeState = useSelector(state => state.employee);
    const leaveManagementState = useSelector(state => state.leaveManagement);
    const balanceSummaryState = useSelector(state => state.sickLeave.balanceSummary)
    const dispatch = useDispatch();
    const location = watch(strings.leaveBalanceSummary.location);

    useEffect(() => {
        const componentDidMount = async () => {
            await dispatch(sickLeaveActions.setBalanceSummaryLoader(true));
            await Promise.all([
                leaveManagementState.leaveType.length <= 0 && dispatch(leaveManagementRequest.leaveRequest.getLeaveType(userReducerState().LocationID)),
                employeeState.employeeName.length <= 0 && dispatch(employeeRequests.employeeName()),
                employeeState.location.length <= 0 && dispatch(employeeRequests.location())
            ]);
            await resetRecords();
            dispatch(sickLeaveActions.setBalanceSummaryLoader(false));
        };
        componentDidMount();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const resetRecords = async () => {
        await dispatch(sickLeaveActions.setBalanceSummaryLoader(true));
        await reset();
        await setValue(strings.leaveBalanceSummary.location, employeeReducerState().location.find(val => val.value === userReducerState().LocationID));
        await setValue(strings.leaveBalanceSummary.employeeName, setDefaultValue.employeeName);
        await onSubmit(getValues());
        dispatch(sickLeaveActions.setBalanceSummaryLoader(false));
    }

    const onSubmit = async (data) => {
        await dispatch(sickLeaveActions.setBalanceSummaryLoader(true));
        let params = {};
        if ("year" in data) {
            params = { ...params, year: moment(data.year).format("YYYY") }
        }
        if ("employeeName" in data) {
            params = { ...params, employeeId: data.employeeName.value, employmentStatus: data.employeeName.employmentStatus }
        }
        if ("location" in data) {
            params = { ...params, locationId: data.location.value }
        }
        await dispatch(sickLeaveRequests.balanceSummary.getFilterParams(params));
        dispatch(sickLeaveActions.setBalanceSummaryLoader(false));
    }
    const onlocationChange = async (data) => {
        const employeeName = watch(strings.leaveBalanceSummary.employeeName);
        if (leaveManagementState.allLeaveTypes && location && data.value !== 0) {
            const leaveType = watch(strings.leaveBalanceSummary.leaveType);
            const isValid = leaveManagementState.allLeaveTypes.filter(val => val.locationId === data.value).find(val => val.label === leaveType.label);
            if (!isValid) {
                await setValue(strings.leaveBalanceSummary.leaveType, leaveManagementState.allLeaveTypes.find(val => val.locationId === 0));
            }
        }
        if (employeeName && employeeState.employeeName && location) {
            if (employeeName.value !== 0 && employeeName.locationId !== data.value && data.value !== 0) {
                await setValue(strings.leaveBalanceSummary.employeeName, setDefaultValue.employeeName);
            }
        }
        await setValue(strings.leaveBalanceSummary.location, data);
    }
    return (
        <div>
            <HeaderSection redirectType={strings.type.leaveManagement} />
            <div className='px-6 overflow-auto h-auto md:max-h-h_body_md sm:max-h-full'>
                <SubHeaderSection subHeader={"Leave Balance Summary"} fileProps={{ columns: balanceSummaryState.data && balanceSummaryState.data.length > 0 ? ("VacationLeaveBalance" in balanceSummaryState.data[0]) ? sickLeave.balanceSummary.UsaColumn() : sickLeave.balanceSummary.IndiaColumn() : (userReducerState().LocationID === setDefaultValue.location.value ? sickLeave.balanceSummary.IndiaColumn() : sickLeave.balanceSummary.UsaColumn()), data: balanceSummaryState.data.map((val, idx) => ({ ...val, sno: idx + 1 })), docName: "Leave Balance Summary" }} />
                <div className='flex mb-6'>
                    <div className='grid grid-rows-1 md:grid-rows-1 sm:grid-rows-2 xsm:grid-rows-3 gap-x-4 gap-y-1 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-2 w-full'>
                        <div><DatePickerElement showYearDropdown={true} value={watch(strings.leaveBalanceSummary.year) ? watch(strings.leaveBalanceSummary.year) : ""} onChange={date => setValue(strings.leaveBalanceSummary.year, date)} isRequired={true} isLabelView={true} placeholder={strings.dropDowns.ReportCompliance.Year} /></div>
                        <div><Dropdown placeholder={"Location"} value={location} options={employeeState.location ? employeeState.location.filter(val => val.value > 0) : []} onChange={data => userReducerState().Role === strings.userRoles.humanResource || onlocationChange(data)} isLabelView={true} isDisable={userReducerState().Role === strings.userRoles.humanResource} /></div>
                        <div><Dropdown placeholder={strings.dropDowns.ReportCompliance.EmployeeName} value={watch(strings.leaveBalanceSummary.employeeName) ? watch(strings.leaveBalanceSummary.employeeName) : ""} onChange={data => setValue(strings.leaveBalanceSummary.employeeName, data)} isLabelView={true}
                            options={location ? employeeState.employeeName.filter((val) => ((val.locationId === setDefaultValue.defaultLocation.value) || ((location.value === setDefaultValue.defaultLocation.value || val.locationId === location.value) && (val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation)))) : []} isSearchable={true} /></div>
                        {/* <div><Dropdown placeholder={"Leave Type"} value={watch(strings.leaveBalanceSummary.leaveType)} options={leaveManagementState.allLeaveTypes && location ? leaveManagementState.allLeaveTypes.filter(val => (location.value === 0 && val.locationId === 1) || (val.locationId === 0 || val.locationId === location.value)) : []} onChange={e => setValue(strings.leaveBalanceSummary.leaveType, e)} isLabelView={true} /></div> */}
                        <div className=' self-end flex'><Button value={strings.Buttons.Search} onClick={handleSubmit(onSubmit)} /> <span className=' mx-3'> <Button value={strings.Buttons.Reset} onClick={resetRecords} /></span></div>
                    </div>
                </div>
                <AgGrid height="h-[calc(100vh-4rem-7rem-1.5rem-67px-1.5rem)] lg:h-[calc(100vh-4rem-7rem-1.5rem-67px-1.5rem)] sm:h-[calc(100vh-4rem-7rem-1.5rem-134px)] xsm:h-[calc(100vh-4rem-7rem-1.5rem-268px)] " columns={balanceSummaryState.data && balanceSummaryState.data.length > 0 ? ("VacationLeaveBalance" in balanceSummaryState.data[0]) ? sickLeave.balanceSummary.UsaColumn() : sickLeave.balanceSummary.IndiaColumn() : (userReducerState().LocationID === setDefaultValue.location.value ? sickLeave.balanceSummary.IndiaColumn() : sickLeave.balanceSummary.UsaColumn())} data={balanceSummaryState.data ? balanceSummaryState.data : []} />
            </div>
            {balanceSummaryState.loader && <TransparentLoader />}
        </div>
    )
}

export default LeaveBalanceSummary

const initialState = {
    year: new Date(),
    employeeName: "",
    location: "",
    leaveType: ""
}