import { useState, useEffect } from 'react';
import HeaderSection from '../../layouts/HeaderSection';
import { useForm } from "react-hook-form";
import { setDefaultValue, status, strings } from '../../Constants';
import SubHeaderSection from '../../layouts/SubHeaderSection';
import DatePickerElement from '../../elements/DatePickerElement';
import Button from '../../elements/Button';
import Dropdown from '../../elements/Dropdown';
import { leaveManagement } from '../../Grid/Columns';
import AgGrid from '../../Grid/AgGrid';
import { useHistory } from 'react-router-dom';
import AddLeaveRequestPopup from '../../Popup_window/AddLeaveRequestPopup';
import { employeeRequests, leaveManagementRequest } from '../../requests';
import { useDispatch, useSelector } from 'react-redux';
import TransparentLoader from '../../loader/TransparentLoader';
import { leaveStatus, exportDateFormat, periodOptions, userReducerState, periodDateFormat, dateFormat, employeeReducerState, leaveManagementReducerState } from '../../helper';
import LeaveHistoryPopup from '../../Popup_window/LeaveHistoryPopup';
import LeaveRequestQueueApprovalView from '../../Popup_window/LeaveRequestQueueApprovalView';
import ApiResponse from '../../Alert/ApiResponse';
import { leaveManagementActions } from '../../../redux/leaveManagementReducer';
import AddButton from '../../elements/AddButton';


function LeaveRequestQueue() {
	const history = useHistory();
	const dispatch = useDispatch();
	const userDetails = useSelector((state) => state.user);
	const leaveReqData = useSelector((state) => state.leaveManagement.leaveRequestQueue.leaveReqDetailsScreen);
	const leaveManagementState = useSelector(state => state.leaveManagement);
	const loginResponseState = useSelector(state => state.loginResponse);
	const { watch, setValue, getValues } = useForm({ defaultValues: initialState });
	const employeeState = useSelector(state => state.employee);
	const [openAddScreen, setOpenAddScreen] = useState(false);

	const leaveReqQueueData = watch(strings.leaveRequestQueue.data);
	const location = watch(strings.leaveRequestQueue.location);

	const setLeaveReqQueueData = async (data) => {
		await setValue(strings.leaveRequestQueue.data, data);
	}

	const filterEmployeeName = (employeeName, location) => {
		if (userReducerState().Role === strings.userRoles.superVisor && employeeName.length > 0 && location) {
			return employeeName.filter((val) =>
				(val.locationId === 0) ||
				((val.employmentStatus === 'All' || val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation) &&
					val.supervisorId === userReducerState().UserID) ||
				(location.value === 0)
			);
		}
		else if (employeeName.length > 0 && location) {
			return employeeName.filter((val) =>
				((val.locationId === location.value || val.locationId === 0) &&
					(val.employmentStatus === 'All' || val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation)) ||
				(location.value === 0)
			);
		}
		return [];
	}


	useEffect(() => {
		const fetchValues = async () => {
			await dispatch(leaveManagementRequest.setLoader(true));
			await Promise.all([
				employeeState.employeeName.length <= 0 && dispatch(employeeRequests.employeeName()),
				employeeState.location.length <= 0 && dispatch(employeeRequests.location()),
				leaveManagementState.leaveType.length <= 0 && dispatch(leaveManagementRequest.leaveRequest.getLeaveType(userDetails.LocationID)),
				leaveManagementState.leaveStatus.length <= 0 && dispatch(leaveManagementRequest.leaveStatus.getLeaveStatus()),
				Object.keys(leaveManagementState.payroll).length <= 0 && dispatch(leaveManagementRequest.getPayroll())
			]);
			await onReset();
			if (leaveManagementState.approveLeaveRequest.show && leaveManagementState.approveLeaveRequest.status) {
				await dispatch(leaveManagementActions.setLeaveRequestQueueSelectedData({ cancelApprovalStatus: leaveManagementState.approveLeaveRequest.status === status.approved || leaveManagementState.approveLeaveRequest.status === status.tobeApproved ? leaveStatus[4].label : leaveStatus[6].label, action: leaveManagementState.approveLeaveRequest.status }));
				await dispatch(leaveManagementRequest.leaveRequestQueue.getLeaveRequestDetails(leaveManagementState.approveLeaveRequest.requestId, leaveManagementState.approveLeaveRequest.status));
				await dispatch(leaveManagementActions.setApproveLeaveRequest({ show: false, requestId: 0, status: "" }));
			}
			dispatch(leaveManagementRequest.setLoader(false));
		}
		fetchValues();
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	useEffect(() => {
		setValue(strings.leaveRequestQueue.employeeNameOptions, filterEmployeeName(employeeState.employeeName ? employeeState.employeeName : [], watch(strings.leaveRequestQueue.location)));
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [employeeState.employeeName, watch(strings.leaveRequestQueue.location), watch(strings.leaveRequestQueue.status)]);

	const onReset = async () => {
		await dispatch(leaveManagementRequest.setLoader(true));
		await setValue(strings.leaveRequestQueue.employeeName, setDefaultValue.employeeName);
		await setValue(strings.leaveRequestQueue.location, employeeReducerState().location.find(val => val.value === userReducerState().LocationID));
		await setValue(strings.leaveRequestQueue.status, leaveStatus[4]);
		leaveManagementReducerState().allLeaveTypes.length > 0 && await setValue(strings.leaveRequestQueue.leaveType, leaveManagementReducerState().allLeaveTypes.find(val => val.label === setDefaultValue.leaveType.label));
		await onPeriodChange(periodOptions.find((val) => val.value === 0));
		await filterLeaveReqQueue();
		leaveManagementState.approveLeaveRequest.show || dispatch(leaveManagementRequest.setLoader(false));
	}

	const filterLeaveReqQueue = async () => {
		await dispatch(leaveManagementRequest.setLoader(true));
		const data = getValues();
		let filterRecords = { leaveType: "", supervisorEmployeeId: userReducerState().Role === strings.userRoles.superVisor ? userReducerState().UserID : 0 };
		const employeeName = data.employeeName;
		const employeeStatus = data.status;
		const employeeLocation = data.location;
		const period = data.period;
		if (employeeName) {
			filterRecords = { ...filterRecords, employeeId: employeeName.value }
		}
		if (employeeStatus) {
			filterRecords = { ...filterRecords, status: employeeStatus.label }
		}
		if (employeeLocation) {
			filterRecords = { ...filterRecords, locationId: employeeLocation.value }
		}
		if ("leaveType" in data) {
			filterRecords = { ...filterRecords, leaveType: data.leaveType.label }
		}
		if (period && period.label !== "All") {
			filterRecords = { ...filterRecords, fromDate: exportDateFormat(data.fromDate, true), toDate: exportDateFormat(data.toDate, true) }
		}
		await dispatch(leaveManagementRequest.leaveRequestQueue.leaveReqEmpFilter(filterRecords, setLeaveReqQueueData));
		leaveManagementState.approveLeaveRequest.show || dispatch(leaveManagementRequest.setLoader(false));
	}

	const resetPopUpData = async () => {
		await dispatch(leaveManagementActions.setLeaveReqDetails({ view: false, reqId: 0, empName: '', status: '', rowData: [], selectedRowData: [], comments: "", requestStatus: '' }));
		await filterLeaveReqQueue();
	}

	const onPeriodChange = (value) => {
		setValue(strings.leaveRequestQueue.period, value);
		periodDateFormat(value, setValue);
	}

	const onSubmit = async (isLopFlag) => {
		const leaveRequestDetails = leaveManagementReducerState().leaveRequestQueue.leaveReqDetailsScreen;
		let data = {
			"approvedBy": userDetails.UserID,
			"approverComments": leaveReqData.comments,
			"leaveRequestDetailId": leaveReqData.selectedRowData.map((val) => val.leaveRequestDetailsId),
			"requestId": leaveReqData.reqId,
			"status": leaveRequestDetails.status === status.tobeApproved ? leaveRequestDetails.requestStatus : leaveRequestDetails.status,
			approvedOn: exportDateFormat(new Date())
		}
		await dispatch(leaveManagementRequest.setLoader(true));
		await dispatch(leaveManagementRequest.leaveRequestQueue.ackLeaveReqQueue(data, isLopFlag, resetPopUpData));
		dispatch(leaveManagementRequest.setLoader(false));
	}

	const onApiResSubmit = async (isLopFlag) => {
		const leaveRequestDetails = leaveManagementReducerState().leaveRequestQueue.leaveReqDetailsScreen;
		let data = {
			"approvedBy": userDetails.UserID,
			"approverComments": leaveReqData.comments,
			"leaveRequestDetailId": leaveReqData.selectedRowData.map((val) => val.leaveRequestDetailsId),
			"requestId": leaveReqData.reqId,
			"status": leaveRequestDetails.status === status.tobeApproved ? leaveRequestDetails.requestStatus : leaveRequestDetails.status,
			approvedOn: exportDateFormat(new Date())
		}
		await dispatch(leaveManagementRequest.setLoader(true));
		if (isLopFlag) await dispatch(leaveManagementRequest.leaveRequestQueue.ackLeaveReqQueue(data, !!isLopFlag, resetPopUpData));
		dispatch(leaveManagementRequest.setLoader(false));
	}
	const onlocationChange = async (data) => {
		if (leaveManagementState.allLeaveTypes && location && data.value !== 0) {
			const leaveType = watch(strings.leaveRequestQueue.leaveType);
			const isValid = leaveManagementState.allLeaveTypes.filter(val => val.locationId === data.value).find(val => val.label === leaveType.label);
			if (!isValid) {
				await setValue(strings.leaveRequestQueue.leaveType, leaveManagementState.allLeaveTypes.find(val => val.locationId === 0));
			}
		}
		await setValue(strings.leaveRequestQueue.location, data);
	}
	return (
		<div>
			<HeaderSection redirectType={strings.type.leaveManagement} />
			<div className='px-6 overflow-auto h-auto md:max-h-h_body_md sm:max-h-full' >
				<SubHeaderSection subHeader="Leave Request Queue" fileProps={{ columns: leaveManagement.leaveRequest.column(history).filter(val => val.headerName !== "Pending Since"), data: leaveReqQueueData.map((val, idx) => ({ ...val, sno: idx + 1, appliedDate: val.appliedDate ? dateFormat(val.appliedDate) : "", fromDate: val.fromDate ? dateFormat(val.fromDate) + "-" + val.leaveFromForH : '', toDate: val.toDate ? dateFormat(val.toDate) + "-" + val.leaveToForH : '' })), docName: "Leave Request Queue" }} />
				<div className='flex mb-6 md:mb-6 xsm:mb-4' >
					<div className='grid xl:grid-rows-1 lg:grid-rows-2 md:grid-rows-2 sm:grid-rows-3 xsm:grid-rows-3 gap-x-4 gap-y-1 xl:grid-cols-4 lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 xsm:grid-cols-1 w-full'>
						<div><Dropdown placeholder={"Period"} options={periodOptions} value={watch(strings.leaveRequestQueue.period)} onChange={e => onPeriodChange(e)} isLabelView={true} /></div>
						<div><DatePickerElement placeholder='From' disabled={watch(strings.leaveRequestQueue.period).label !== strings.filterPeriod.custom} value={watch(strings.leaveRequestQueue.fromDate)} onChange={date => setValue(strings.leaveRequestQueue.fromDate, date)} isRequired={true} isLabelView={true} /></div>
						<div><DatePickerElement placeholder='To' disabled={watch(strings.leaveRequestQueue.period).label !== strings.filterPeriod.custom} value={watch(strings.leaveRequestQueue.toDate)} onChange={date => setValue(strings.leaveRequestQueue.toDate, date)} minDate={watch(strings.leaveRequestQueue.period).label === strings.filterPeriod.custom && watch(strings.leaveRequestQueue.fromDate)} isRequired={true} isLabelView={true} /></div>
						<div><Dropdown placeholder={"Location"} value={location} options={employeeState.location} onChange={data => userReducerState().Role === strings.userRoles.admin && onlocationChange(data)} isSearchable={true} isLabelView={true} isDisable={userReducerState().Role !== strings.userRoles.admin} /></div>
						<div><Dropdown placeholder={"Employee Name"} value={watch(strings.leaveRequestQueue.employeeName)} options={watch(strings.leaveRequestQueue.employeeNameOptions)} onChange={e => setValue(strings.leaveRequestQueue.employeeName, e)} isSearchable={true} isLabelView={true} /></div>
						<div><Dropdown placeholder={"Status"} value={watch(strings.leaveRequestQueue.status)} options={leaveManagementState.leaveStatus} onChange={e => setValue(strings.leaveRequestQueue.status, e)} isSearchable={true} isLabelView={true} /></div>
						<div><Dropdown placeholder={"Leave Type"} value={watch(strings.leaveRequestQueue.leaveType)} options={leaveManagementState.allLeaveTypes && location ? leaveManagementState.allLeaveTypes.filter(val => (location.value === 0 && val.locationId === 1) || (val.locationId === 0 || val.locationId === location.value)) : []} onChange={e => setValue(strings.leaveRequestQueue.leaveType, e)} isLabelView={true} /></div>
						<div className=' self-end flex'>
							<Button value={strings.Buttons.Search} onClick={() => filterLeaveReqQueue()} disabled={watch(strings.leaveRequestQueue.period).label === strings.filterPeriod.custom && (!watch(strings.leaveRequestQueue.fromDate) || !watch(strings.leaveRequestQueue.toDate))} />
							<span className=' mx-3'> <Button value={strings.Buttons.Reset} onClick={() => onReset()} /></span>
						</div>
					</div>
				</div>
				<AgGrid data={leaveReqQueueData} columns={leaveManagement.leaveRequest.column(loginResponseState.isMobileCompatible)} ContextMenuItems={loginResponseState.isMobileCompatible ? false : leaveManagement.leaveRequest.contextMenuItems} history={history} height="h-[calc(94vh-67px-67px-3.5rem-1.5rem-3.5rem-4.6rem)] lg:h-[calc(94vh-67px-67px-3.5rem-1.5rem-3.5rem-4.6rem-0.5rem)] md:h-[calc(94vh-67px-67px-67px-3.5rem-1.5rem-3.5rem-4.6rem-0.5rem)] xsm:h-[58vh]" />
				{userReducerState().Role === strings.userRoles.superVisor || <div className="mx-2 flex flex-row items-center font-fontfamily text-14px font-bold mt-3 text-darkGrey" >
					<AddButton value={strings.Buttons.AddLeaveRequest} onClick={() => setOpenAddScreen(true)} />
				</div>}
			</div>
			{leaveManagementState.leaveRequestQueue.leaveHistoryPopup.show && <LeaveHistoryPopup />}
			{leaveReqData.view && <LeaveRequestQueueApprovalView onSubmit={onSubmit} />}
			{openAddScreen && <AddLeaveRequestPopup openAddScreen={openAddScreen} setOpenAddScreen={setOpenAddScreen} locationOptn={employeeState.location} filterLeaveReqQueue={filterLeaveReqQueue} />}
			{leaveManagementState.loader && <TransparentLoader />}
			{loginResponseState.apiResponse.show && !openAddScreen && <ApiResponse setResponseCallback={onApiResSubmit} />}
		</div>
	)
}

const initialState = {
	location: { label: 'INDIA', value: 1 },
	employeeName: "",
	status: { label: "To be Approved", value: 4 },
	period: "",
	fromDate: "",
	toDate: "",
	employeeNameOptions: [],
	data: [],
	leaveType: []
}


export default LeaveRequestQueue