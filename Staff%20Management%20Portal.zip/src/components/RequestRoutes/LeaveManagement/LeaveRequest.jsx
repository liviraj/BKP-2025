import { useEffect, useState } from 'react'
import HeaderSection from '../../layouts/HeaderSection'
import { leaveDetails, leaveType, setDefaultValue, strings } from '../../Constants'
import SubHeaderSection from '../../layouts/SubHeaderSection'
import RadioButton from '../../elements/RadioButton'
import Label from '../../elements/Label'
import DatePickerElement from '../../elements/DatePickerElement'
import CheckBox from '../../elements/CheckBox'
import TextArea from '../../elements/TextArea'
import { dateFormat, exportDateFormat, getLeaveDetails, holidayReducerState } from '../../helper'
import SimpleDoughnut from '../../Chart/SimpleDoughnut'
import { useForm } from "react-hook-form";
import AutoSizeButton from '../../elements/AutoSizeButton'
import { useDispatch, useSelector } from 'react-redux'
import { leaveManagementRequest } from '../../requests'
import TransparentLoader from '../../loader/TransparentLoader'
import ApiResponse from '../../Alert/ApiResponse'
import LeaveConfirmationView from '../../Popup_window/LeaveConfirmationView';
import moment from 'moment-timezone'

function LeaveRequest() {
  const { handleSubmit, watch, setValue, reset } = useForm({ defaultValues: initialState });
  const userState = useSelector(state => state.user);
  const leaveManagementState = useSelector(state => state.leaveManagement);
  const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
  const [isVisible, setIsVisible] = useState(false);
  const [leaveBalance, setLeaveBalance] = useState({});
  const dispatch = useDispatch();

  let fromDate = watch(strings.leaveRequest.fromDate);
  let toDate = watch(strings.leaveRequest.toDate);

  const getLeaveBalanceBack = (data) => {
    if (userState.LocationID === setDefaultValue.location.value) {
      data.privilegeLeaveDetails = data.vacationLeaveDetails;
      delete data.vacationLeaveDetails;
    }
    const keys = Object.keys(data).length > 0 ? Object.keys(data) : [];
    let chartRecord = []
    for (const i in keys) {
      const detailKeys = leaveDetails.find(val => val.typeId === keys[i]);
      if (detailKeys) {
        let balanceDetails = data[detailKeys.typeId];
        if (balanceDetails && Object.keys(balanceDetails).length > 1) {
          const balance = ("balance" in balanceDetails) ? balanceDetails.balance : 0;
          const taken = ("totalDebit" in balanceDetails) ? balanceDetails.totalDebit : 0;
          chartRecord = [...chartRecord, { ...detailKeys, data: [{ requestType: `Available ${balance}`, value: balance }, { requestType: `Taken ${taken}`, value: taken }] }]
        }
      }
    }
    setLeaveBalance({ leaveAvailed: data, chartRecord });
  }

  useEffect(() => {
    const componenDidMount = async () => {
      await dispatch(leaveManagementRequest.setLoader(true));
      await Promise.all([
        leaveManagementState.leaveType.length <= 0 && dispatch(leaveManagementRequest.leaveRequest.getLeaveType(userState.LocationID)),
        dispatch(leaveManagementRequest.leaveRequest.getLeaveBalance(userState.UserID, getLeaveBalanceBack)),
        holidayReducerState().holidays.length <= 0 && getLeaveDetails(new Date())
      ]);
      dispatch(leaveManagementRequest.setLoader(false));
    }
    componenDidMount();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const setCallBack = async (isSuccess) => {
    if (isSuccess) {
      await dispatch(leaveManagementRequest.leaveRequest.getLeaveBalance(userState.UserID, getLeaveBalanceBack));
      await reset();
    }
  }

  const onSubmitRequest = async (isLossOfPay) => {
    const formatData = {
      employeeId: userState.UserID,
      isCompensatory: "",
      leaveEnteredBy: userState.UserID,
      leaveFrom: exportDateFormat(fromDate, true),
      leaveFromForH: watch(strings.leaveRequest.firstHalf) ? leaveType.halfDay : leaveType.fullDay,
      leaveTo: exportDateFormat(toDate, true),
      leaveToForH: watch(strings.leaveRequest.secondHalf) ? leaveType.halfDay : leaveType.fullDay,
      remarks: watch(strings.leaveRequest.reason),
      typeofLeave: leaveManagementState.leaveType.find(val => val.label === watch(strings.leaveRequest.leaveType)).value,
      leaveEnteredOn: exportDateFormat(new Date()),
      leaveRequestDetailId: 0
    }
    setIsVisible(false);
    await dispatch(leaveManagementRequest.leaveRequest.addLeaveRequest(userState.UserID, { ...formatData }, isLossOfPay, setCallBack));
  }

  const submit = async () => {
    await dispatch(leaveManagementRequest.setLoader(true));
    await onSubmitRequest(false);
    dispatch(leaveManagementRequest.setLoader(false));
  }

  const onAlertClose = () => {
    setIsVisible(false);
  }
  const onAlertConfirmation = (isConfirmed) => {
    if (isConfirmed) {
      handleSubmit(submit);
    }
    else {
      onAlertClose();
    }

  }
  const setResponseCallback = async (isAcceptable) => {
    await dispatch(leaveManagementRequest.setLoader(true));
    if (isAcceptable) {
      await onSubmitRequest(true);
    }
    dispatch(leaveManagementRequest.setLoader(false));
  }

  const onDateChange = async (date, type) => {
    dispatch(leaveManagementRequest.setLoader(true));
    await getLeaveDetails(date);
    setValue(type, date);
    dispatch(leaveManagementRequest.setLoader(false));
  }

  return (
    <div>
      <HeaderSection redirectType={strings.type.leaveManagement} />
      <div className=' overflow-auto h-screen md:h-screen xsm:h-auto md:max-h-h_body_md sm:max-h-full text-14px grid grid-cols-12'>
        <div className={` col-start-1 col-end-9 lg:col-end-9 md:col-end-13 xsm:col-end-13 my-2 font-fontfamily font-bold`}>
          <div className='mx-6'>
            <SubHeaderSection subHeader={"Leave Request"} />
            <div className=' my-5'>
              <Label label={"Leave Type"} required={true} />
              <RadioButton options={leaveManagementState.leaveType.map(val => val.label)} value={watch(strings.leaveRequest.leaveType)} onChange={e => setValue(strings.leaveRequest.leaveType, e.target.value)} />
              <div className=' grid lg:grid-cols-3 md:grid-cols-2 sm:grid-cols-1 xsm:grid-cols-1 my-4 gap-x-10 gap-y-2'>
                <div>
                  <Label label={"From"} required={true} />
                  <DatePickerElement value={fromDate} onChange={date => { onDateChange(date, strings.leaveRequest.fromDate); if (date && toDate && moment(date).format("MM/DD/YYYY") === moment(toDate).format("MM/DD/YYYY") && watch(strings.leaveRequest.secondHalf) && watch(strings.leaveRequest.firstHalf)) { setValue(strings.leaveRequest.secondHalf, false); setValue(strings.leaveRequest.firstHalf, false) } }} isWeekday={true} maxDate={toDate} disableHolidays={holidayReducerState().holidays} />
                  <CheckBox data={[{ label: "Half Day" }]} value={watch(strings.leaveRequest.firstHalf)} onChange={e => { setValue(strings.leaveRequest.firstHalf, e.target.checked); if (fromDate && toDate && moment(fromDate).format("MM/DD/YYYY") === moment(toDate).format("MM/DD/YYYY") && watch(strings.leaveRequest.secondHalf)) { setValue(strings.leaveRequest.secondHalf, false) } }} />
                </div>
                <div>
                  <Label label={"To"} required={true} />
                  <DatePickerElement value={toDate} onChange={date => { onDateChange(date, strings.leaveRequest.toDate); if (fromDate && date && moment(fromDate).format("MM/DD/YYYY") === moment(date).format("MM/DD/YYYY") && watch(strings.leaveRequest.secondHalf) && watch(strings.leaveRequest.firstHalf)) { setValue(strings.leaveRequest.secondHalf, false); setValue(strings.leaveRequest.firstHalf, false) } }} minDate={fromDate} isWeekday={true} disableHolidays={holidayReducerState().holidays} />
                  <CheckBox data={[{ label: "Half Day" }]} value={watch(strings.leaveRequest.secondHalf)} onChange={e => { setValue(strings.leaveRequest.secondHalf, e.target.checked); if (fromDate && toDate && moment(fromDate).format("MM/DD/YYYY") === moment(toDate).format("MM/DD/YYYY") && watch(strings.leaveRequest.firstHalf)) { setValue(strings.leaveRequest.firstHalf, false) } }} />
                </div>
              </div>
              <Label label={"Reason"} required={true} />
              <TextArea height={" h-40"} isRequired={true} value={watch(strings.leaveRequest.reason)} onChange={e => setValue(strings.leaveRequest.reason, e.target.value)} />
              <div className='flex justify-center w-full'><span className=' font-normal flex justify-center my-4 h-10 text-lg w-48 '><AutoSizeButton value={"Apply Leave"} disabled={!(watch(strings.leaveRequest.leaveType) && watch(strings.leaveRequest.fromDate) && watch(strings.leaveRequest.toDate) && watch(strings.leaveRequest.reason))} onClick={() => setIsVisible(true)} /></span></div>
              {(Object.keys(leaveBalance).length > 0 && leaveBalance.leaveAvailed.lastLeaveFromDate && leaveBalance.leaveAvailed.lastLeaveToDate) ? <div className='flex justify-center text-blueColor'> {`Last Leave Requested Date: ${dateFormat(leaveBalance.leaveAvailed.lastLeaveFromDate) + ' - ' + dateFormat(leaveBalance.leaveAvailed.lastLeaveToDate)}`} </div> : ""}
            </div>
          </div>
        </div>

        <div className='order-last lg:order-last md:order-first xsm:order-first col-start-9 lg:col-start-9 md:col-start-1 xsm:col-start-1 col-end-13 bg-pink-50 rounded h-full'>
          <div className='flex m-7 border-1 rounded shadow-boxShadow box-shadow border-white bg-white p-3 font-fontfamily flex-col'>
            <div className='flex justify-center w-full font-bold'>Last Leave Availed</div>
            <div className='flex justify-center w-full py-3 text-16px items-center'>Last leave availed: <span className='font-bold text-14px mx-1'>{dateFormat(leaveBalance && Object.keys(leaveBalance).length > 0 ? leaveBalance?.leaveAvailed?.lastLeaveAvailed?.date : "")}</span></div>
            <div className='flex justify-center w-full text-16px items-center'>Approval Status: <span className='font-bold text-14px mx-1'>{leaveBalance && Object.keys(leaveBalance).length > 0 ? leaveBalance?.leaveAvailed?.lastLeaveAvailed?.status : ""}</span></div>
          </div>
          {
            leaveBalance && Object.keys(leaveBalance).length > 0 && leaveBalance.chartRecord && leaveBalance.chartRecord.length > 0 && leaveBalance.chartRecord.map((val, idx) =>
              <div className='flex m-7 border-0 rounded shadow-boxShadow box-shadow border-white bg-white font-fontfamily flex-col min-h-32 h-40 max-h-40 overflow-hidden' key={idx}>
                <div className={`flex justify-center w-full font-bold py-2 ${val.bgColor} rounded-t label-shadow tracking-wider`}>{val.title}</div>
                <SimpleDoughnut data={val.data} />
              </div>
            )
          }
        </div>

      </div>
      {isVisible && <LeaveConfirmationView onSubmit={submit} show={isVisible} onClose={onAlertClose} onConfirm={onAlertConfirmation}
        data={{
          fromDate: watch(strings.leaveRequest.fromDate),
          toDate: watch(strings.leaveRequest.toDate),
          firstHalf: watch(strings.leaveRequest.firstHalf),
          secondHalf: watch(strings.leaveRequest.secondHalf),
          disableHolidays: holidayReducerState().holidays
        }}
      />}
      {leaveManagementState.loader && <TransparentLoader />}
      {apiResponseState.show && <ApiResponse setResponseCallback={setResponseCallback} />}
    </div>
  )
}

export default LeaveRequest;

const initialState = {
  leaveType: "",
  fromDate: "",
  toDate: "",
  firstHalf: "",
  secondHalf: "",
  reason: "",
}