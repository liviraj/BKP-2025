import { useForm } from "react-hook-form";
import Button from "../../elements/Button";
import DatePickerElement from "../../elements/DatePickerElement";
import Dropdown from "../../elements/Dropdown";
import { dateFormat, employeeReducerState, exportDateFormat, periodDateFormat, periodOptions, userReducerState } from "../../helper";
import { setDefaultValue, strings } from "../../Constants";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useMemo } from "react";
import { deputationActions } from "../../../redux/DeputationReducer";
import { deputationRequest, employeeRequests, leaveManagementRequest } from "../../requests";
import TransparentLoader from "../../loader/TransparentLoader";
import SubHeaderSection from "../../layouts/SubHeaderSection";
import AgGrid from "../../Grid/AgGrid";
import AddButton from "../../elements/AddButton";
import { DeputationColumns } from "../../Grid/Columns";
import DeputationPopup from "../../Popup_window/DeputationPopup";
import ApiResponse from "../../Alert/ApiResponse";

const Deputation = () => {
    const dispatch = useDispatch();
    const employeeState = useSelector(state => state.employee);
    const { LocationID, UserID } = useSelector(state => state.user);
    const loginResponseState = useSelector(state => state.loginResponse);
    const { loader, deputationPopup, deputation } = useSelector(state => state.deputation);
    const { watch, setValue, getValues } = useForm({ defaultValues: initialValue });
    const leaveManagementState = useSelector(state => state.leaveManagement);

    useEffect(() => {
        const onInitialLoad = async () => {
            await dispatch(deputationActions.setLoader(true));
            await Promise.all([
                employeeState.location.length <= 0 && dispatch(employeeRequests.location()),
                employeeState.employeeName.length <= 0 && dispatch(employeeRequests.employeeName()),
                employeeState.employeeStatus.length <= 0 && dispatch(employeeRequests.status()),
                Object.keys(leaveManagementState.payroll).length <= 0 && dispatch(leaveManagementRequest.getPayroll())
            ])
            await handleReset();
            dispatch(deputationActions.setLoader(false));
        }
        onInitialLoad();
        return async () => {
            await dispatch(deputationActions.setDeputationData([]));
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const onPeriodChange = (value) => {
        setValue(strings.deputation.period, value);
        periodDateFormat(value, setValue);
    }

    const employeeNameOptions = useMemo(() => {
        let employeeOptions = employeeState.employeeName;
        const status = watch(strings.deputation.status);
        const confirmed = setDefaultValue.employmentStatus.confirmed;
        const probation = setDefaultValue.employmentStatus.probation;
        const relieved = setDefaultValue.employmentStatus.relieved;
        let value = []
        switch (status?.label) {
            case setDefaultValue.employmentStatus.active:
                value = employeeOptions.filter(val => val.employmentStatus === confirmed || val.employmentStatus === probation || val.value === 0)
                break;
            case confirmed:
                value = employeeOptions.filter(val => val.employmentStatus === confirmed || val.value === 0)
                break;
            case probation:
                value = employeeOptions.filter(val => val.employmentStatus === probation || val.value === 0);
                break;
            case relieved:
                value = employeeOptions.filter(val => val.employmentStatus === relieved || val.value === 0)
                break;
            default:
                value = employeeOptions
        }
        setValue(strings.deputation.employeeName, value)
        return value;
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [employeeState, watch(strings.deputation.status)])
    const handleSearch = async () => {
        await dispatch(deputationActions.setLoader(true));
        const data = getValues();
        const params = {
            deputationLocationId: data?.deputationLocation?.value,
            employeeId: (data?.employeeName?.employeeId) ? data.employeeName.employeeId : 0,
            fromDate: exportDateFormat(data.fromDate),
            toDate: exportDateFormat(data.toDate),
            status: data?.status?.label
        }
        await dispatch(deputationRequest.getDeputationDetailsRequest(params));
        dispatch(deputationActions.setLoader(false));
    }
    const handleReset = async () => {
        await dispatch(deputationActions.setLoader(true));
        await onPeriodChange(periodOptions.find((val) => val.value === 7));
        await setValue(strings.deputation.deputationLocation, employeeReducerState().location.find((val) => val.value !== LocationID && val.value !== 0));
        await setValue(strings.deputation.employeeName, employeeReducerState().employeeName.find((val) => val.value === 0));
        await setValue(strings.deputation.status, employeeReducerState().employeeStatus.find(val => val.value === 2))
        await handleSearch();
        dispatch(deputationActions.setLoader(false));
    }
    const onDeleteConfirmation = async (isAcceptable) => {
        if (isAcceptable) {
            await dispatch(deputationActions.setLoader(true));
            const params = {
                modifiedBy: UserID,
                modifiedDate: exportDateFormat(new Date())
            }
            await dispatch(deputationRequest.deleteDeputationRequest(deputationPopup.selectedRow?.deputationID, params, setCallBack));
            dispatch(deputationActions.setLoader(false));
        }
    }

    const setCallBack = async (status) => {
        if (status) {
            await dispatch(deputationActions.reSetDeputationPoup());
            await handleSearch();
        }
    }
    return (
        <>
            <div className="px-6">
                <SubHeaderSection subHeader={"Deputation"} fileProps={{ columns: DeputationColumns.deputationList.excelColumn(), data: deputation?.data?.map((val, inx) => ({ ...val, sno: inx + 1, deputationFrom: dateFormat(val.deputationFrom), deputationTo: dateFormat(val.deputationTo), travelFrom: dateFormat(val.travelFrom), travelTo: dateFormat(val.travelTo), visaValidityFrom: dateFormat(val.visaValidityFrom), visaValidityTo: dateFormat(val.visaValidityTo) })), docName: 'Deputation' }} />
                <div className='flex mb-6 md:mb-6 xsm:mb-4' >
                    <div className='grid xl:grid-rows-1 lg:grid-rows-2 md:grid-rows-2 sm:grid-rows-3 xsm:grid-rows-3 gap-x-4 gap-y-1 xl:grid-cols-4 lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 xsm:grid-cols-1 w-full'>
                        <div><Dropdown placeholder={"Period"} options={periodOptions} value={watch(strings.deputation.period)} onChange={e => onPeriodChange(e)} isLabelView={true} /></div>
                        <div><DatePickerElement placeholder='From' disabled={watch(strings.deputation.period).label !== strings.filterPeriod.custom} value={watch(strings.deputation.fromDate) ? watch(strings.deputation.fromDate) : ""} onChange={date => setValue(strings.deputation.fromDate, date)} isRequired={true} isLabelView={true} /></div>
                        <div><DatePickerElement placeholder='To' disabled={watch(strings.deputation.period).label !== strings.filterPeriod.custom} value={watch(strings.deputation.toDate) ? watch(strings.deputation.toDate) : ""} minDate={watch(strings.deputation.period).label === strings.filterPeriod.custom && watch(strings.deputation.fromDate)} onChange={date => setValue(strings.deputation.toDate, date)} isRequired={true} isLabelView={true} /></div>
                        <div><Dropdown placeholder={"Employee Name"} value={watch(strings.deputation.employeeName)} options={employeeNameOptions} onChange={e => setValue(strings.deputation.employeeName, e)} isSearchable={true} isLabelView={true} /></div>
                        <div><Dropdown placeholder={"Deputation Location"} value={watch(strings.deputation.deputationLocation)} options={employeeState.location && employeeState.location.length > 0 ? employeeState.location : []} onChange={data => userReducerState().Role === strings.userRoles.humanResource || setValue(strings.deputation.deputationLocation, data)} isSearchable={true} isLabelView={true} isDisable={userReducerState().Role !== strings.userRoles.admin} /></div>
                        <div><Dropdown placeholder={"Employment Status"} value={watch(strings.deputation.status)} options={employeeState.employeeStatus} onChange={data => setValue(strings.deputation.status, data)} isLabelView={true} /></div>
                        <div className=' self-end flex'>
                            <Button value={strings.Buttons.Search} onClick={handleSearch} disabled={!((watch(strings.deputation.period)?.label === strings.filterPeriod.custom ? (watch(strings.deputation.fromDate) && watch(strings.deputation.toDate)) : true) && watch(strings.deputation.employeeName) && watch(strings.deputation.deputationLocation))} />
                            <span className=' mx-3'> <Button value={strings.Buttons.Reset} onClick={handleReset} /></span>
                        </div>
                    </div>
                </div>
                <div className="headerCell-FullBorder">  <AgGrid data={deputation?.data} columns={DeputationColumns.deputationList.columns(loginResponseState.isMobileCompatible)} ContextMenuItems={loginResponseState.isMobileCompatible ? false : DeputationColumns.deputationList.contextMenuItems} height="lg:h-[calc(100vh-21.1rem)] h-[calc(100vh-24.4rem)]" /></div>
                <div className="flex items-center mt-3 mb-3">
                    <AddButton value={strings.Buttons.createDeputation} onClick={() => dispatch(deputationActions.setDeputationPopup({ show: true }))} />
                </div>
            </div>
            {(!deputationPopup.show && loginResponseState.apiResponse.show) && <ApiResponse setResponseCallback={onDeleteConfirmation} />}
            {loader && <TransparentLoader />}
            {deputationPopup.show && <DeputationPopup setCallBack={setCallBack} />}
        </>
    );
};

export default Deputation;

const initialValue = {
    period: "",
    fromDate: "",
    toDate: "",
    employeeName: "",
    deputationLocation: "",
    status: ''
}