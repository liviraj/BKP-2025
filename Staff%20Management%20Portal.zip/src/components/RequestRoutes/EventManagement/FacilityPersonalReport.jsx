import { useEffect } from 'react';
import SubHeaderSection from '../../layouts/SubHeaderSection';
import AgGrid from '../../Grid/AgGrid';
import { eventManagement } from '../../Grid/Columns';
import { FacilityPersonalPritView } from '../../Print/PrintView';
import { useDispatch, useSelector } from 'react-redux';
import { eventManagementRequests } from '../../requests';
import TransparentLoader from '../../loader/TransparentLoader';
import { eventManagementActions } from '../../../redux/eventManagementReducer';
import { eventManagementReducerState } from '../../helper';

const FacilityPersonalReport = () => {
    const dispatch = useDispatch()
    const { facilityReport, loader } = useSelector(state => state.eventManagement)
    useEffect(() => {
        const initialLoad = async () => {
            await dispatch(eventManagementActions.setLoader(true));
            await dispatch(eventManagementRequests.facilityPersonalReport.getFacilityReport())
            dispatch(eventManagementActions.setLoader(false));
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    return (
        <>
            <div className='overflow-hidden mx-6'>
                <div>
                    <SubHeaderSection subHeader="Facility Personal Report" newComponent={<FacilityPersonalPritView columns={eventManagement.FacilityPersonalReport.printColumn} data={eventManagementReducerState().facilityReport.data.map((val, id) => ({ ...val, sno: id + 1 }))} />} />
                    <div className='grid lg:grid-cols-2 font-fontfamily font-medium text-13px my-4 grid-cols-1 md:gap-2 gap-4'>
                        <div className=' order-2 lg:order-1'><p className=' whitespace-normal'>New York State Department  <br />
                            Wadsworth center <br />
                            Clinical Laboratory Evaluation program <br />
                            Empire state plaza <br />
                            p.o Box 509 <br />
                            Albany <br />
                            New york 12201 - 0509 <br /></p>
                            <p>Telephone: <a href='tel:+5184855378' className=' text-blueColor hover:underline'>(518) 485 5378 </a></p>
                            <p> FAX: (518) 485 5414 </p>
                            <p> Email: <a href='mailto:CLEP@health.state.ny.us' className=' text-blueColor hover:underline'>CLEP@health.state.ny.us</a> </p>
                            <p> web: <a href='https://www.wadsworth.org/regulatory/clep' target="_blank" className=' text-blueColor hover:underline'>www.wadsworth.org/labcert/clep/clep.html</a></p>
                        </div>
                        <div className=' flex lg:items-end items-start flex-col order-1 lg:order-2'>
                            <div className=' flex items-start'><span className=' font-extrabold pr-2 min-w-[6rem]'>Laboratory :</span><span className=' w-[150px] block'>7962</span></div>
                            <div className=' flex items-start'><span className=' font-extrabold pr-2 min-w-[6rem]'>Name and Adress of Laboratory :</span><span className=' w-[150px] block'>HistoGenetics Inc <br />300 Executive BLVD  <br />Ground FL  <br />Ossining <br />NY 10562 <br /></span></div>
                            <div className=' flex items-start'><span className=' font-extrabold pr-2 min-w-[6rem]'>Consultant :</span><span className=' w-[150px] block'></span></div>
                        </div>
                    </div>
                </div>
                <div className='headerCell-FullBorder'><AgGrid data={facilityReport.data ? facilityReport.data : []} columns={eventManagement.FacilityPersonalReport.column()} height="h-[calc(100vh-25.5rem)] min-h-[21rem]" /></div>
            </div>
            {loader && <TransparentLoader />}
        </>
    );
};

export default FacilityPersonalReport;

