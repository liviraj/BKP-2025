import { useEffect, useState } from 'react';
import CalendarView from './CustomizedCalendar/CalendarView'
import ViewEventTabularView from './ViewEventTabularView';
import moment from 'moment-timezone';
import { ViewComponentDesign, dateAndTimeFormat, exportDateFormat, userReducerState } from '../../helper';
import { useDispatch, useSelector } from 'react-redux';
import TransparentLoader from '../../loader/TransparentLoader';
import { eventManagementActions } from '../../../redux/eventManagementReducer';
import { eventManagementRequests } from '../../requests';
import ApiResponse from '../../Alert/ApiResponse';
import { Views } from 'react-big-calendar';
import ModelBox from '../../elements/ModelBox';
import TextArea from '../../elements/TextArea';
import Label from '../../elements/Label';
import RecordEventPopup from '../../Popup_window/RecordEventPopup';
import LogViewPopup from '../../Popup_window/LogViewPopup';


function ViewEvents() {
  const eventState = useSelector(state => state.eventManagement);
  const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
  const { recordEventPopup } = useSelector(state => state.eventManagement.recordEvents);
  const dispatch = useDispatch();

  const [isCalendarView, setIsCalendarView] = useState(true);

  useEffect(() => {
    const initialLoad = async () => {
      await dispatch(eventManagementActions.setViewEventLoader(true));
      const params = {
        employeeId: userReducerState().UserID,
        fromdate: exportDateFormat(moment().set({ month: 0, date: 1 }).subtract(1, "years"), true),
        toDate: exportDateFormat(moment().set({ month: 11, date: 31 }).add(1, "years"), true)
      }
      await dispatch(eventManagementRequests.viewEvents.getViewEvents(params, true));
      await dispatch(eventManagementActions.setCalendarView(Views.WEEK));
      let presenter = recordEventPopup?.data?.attendeeDetailsDTO && recordEventPopup.data.attendeeDetailsDTO.length > 0 && recordEventPopup.data.attendeeDetailsDTO.filter(val => val.participationLevelID === 1 || val.participationLevelID === 2)
      let participant = recordEventPopup?.data?.attendeeDetailsDTO && recordEventPopup.data.attendeeDetailsDTO.length > 0 && recordEventPopup.data.attendeeDetailsDTO.filter(val => val.participationLevelID === 3)
      await dispatch(eventManagementActions.setEventPopupView({ presenter: presenter, participant: participant }))
      dispatch(eventManagementActions.setViewEventLoader(false));
    }
    initialLoad();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const onReload = async () => {
      if (isCalendarView && Object.keys(eventState.selectedRecord).length > 0) {
        await dispatch(eventManagementActions.setViewEventLoader(true));
        const params = {
          employeeId: userReducerState().UserID,
          fromdate: exportDateFormat(moment(eventState.calendarView.date).set({ month: 0, date: 1 }), true),
          toDate: exportDateFormat(moment(eventState.calendarView.date).set({ month: 11, date: 31 }), true)
        }
        await dispatch(eventManagementRequests.viewEvents.getViewEvents(params, true));
        await dispatch(eventManagementActions.setSelectedRecord({}));
        let presenter = recordEventPopup?.data?.attendeeDetailsDTO && recordEventPopup.data.attendeeDetailsDTO.length > 0 && recordEventPopup.data.attendeeDetailsDTO.filter(val => val.participationLevelID === 1 || val.participationLevelID === 2)
        let participant = recordEventPopup?.data?.attendeeDetailsDTO && recordEventPopup.data.attendeeDetailsDTO.length > 0 && recordEventPopup.data.attendeeDetailsDTO.filter(val => val.participationLevelID === 3)
        await dispatch(eventManagementActions.setEventPopupView({ presenter: presenter, participant: participant }));
        dispatch(eventManagementActions.setViewEventLoader(false));
      }
    }
    onReload();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [eventState, isCalendarView, dispatch]);

  const handleDelete = async (isAcceptable) => {
    if (isAcceptable) {
      await dispatch(eventManagementActions.setViewEventLoader(true));
      const params = {
        EventId: eventState.selectedRecord.eventID,
        modifiedBy: userReducerState().UserID,
        modifiedDate: exportDateFormat(new Date())
      }
      await dispatch(eventManagementRequests.viewEvents.deleteEvent(params, async () => {
        await dispatch(eventManagementRequests.viewEvents.getTabularView(eventState.tabularView.filterParams));
      }));
      dispatch(eventManagementActions.setViewEventLoader(false));
    }
  }

  return (
    <div>
      <div className='h-auto'>
        <div className=' bg-themeBgColor w-full h-14 min-h-14 md:min-h-14 xsm:min-h-10 md:h-14 sm:h-10 xsm:h-10 flex items-center font-fontfamily px-4 border-b-2 border-solid border-b-borderThemeColor' >
          <button className={` ${isCalendarView ? " bg-white text-headerColor border-borderThemeColor " : "text-darkDarkGrey border-transparent hover:bg-themeHighlightColor hover:border-borderThemeColor "} border-2 border-solid md:mt-6 xsm:mt-4 md:h-4/5 xsm:h-full w-auto px-4 font-fontfamily text-12px font-bold uppercase tracking-wider text-shadow-sm  whitespace-nowrap rounded-t-xl  hover:!text-headerColor  `} onClick={() => setIsCalendarView(true)} >Calendar View</button>
          <button className={` ${!isCalendarView ? "bg-white text-headerColor border-borderThemeColor " : "text-darkDarkGrey border-transparent hover:bg-themeHighlightColor hover:border-borderThemeColor "} border-2 border-solid md:mt-6 xsm:mt-4 md:h-4/5 xsm:h-full w-auto px-4 font-fontfamily text-12px font-bold uppercase tracking-wider text-shadow-sm  whitespace-nowrap rounded-t-xl  hover:!text-headerColor `} onClick={() => setIsCalendarView(false)} >Tabular View</button>
        </div>
        {isCalendarView ? <CalendarView /> : <ViewEventTabularView />}
      </div>
      <>
        {eventState.calendarView.loader && <TransparentLoader />}
        {apiResponseState.show && <ApiResponse setResponseCallback={handleDelete} />}
        {eventState.eventPopupView.show && <ModelBox open={eventState.eventPopupView.show} onClose={() => dispatch(eventManagementActions.setEventPopupView({ show: false, title: "", selectedRow: {} }))} headerTitle={eventState.eventPopupView.title} Component={
          <div className=' w-[45rem] md:w-[45rem] sm:w-[90vw] xsm:w-[90vw] max-w-[90vw] mx-4 my-3 tracking-wide'>
            <div className='grid grid-cols-12 gap-5'>
              <div className='grid col-start-1 col-end-13 md:col-end-7'>
                <div className=' grid col-start-1 col-end-13'>
                  <ViewComponentDesign label={"Topic"} value={("eventTopic" in eventState.eventPopupView.selectedRow) && eventState.eventPopupView.selectedRow.eventTopic ? eventState.eventPopupView.selectedRow.eventTopic : ""} valueAddStyle="text-headerColor !font-semibold " />
                  <ViewComponentDesign label={"Start Date"} value={("eventStartDate" in eventState.eventPopupView.selectedRow) ? dateAndTimeFormat(eventState.eventPopupView.selectedRow.eventStartDate) : ""} />
                  <ViewComponentDesign label={"End Date"} value={("eventEndDate" in eventState.eventPopupView.selectedRow) ? dateAndTimeFormat(eventState.eventPopupView.selectedRow.eventEndDate) : ""} />
                  <ViewComponentDesign label={"Type"} value={("eventType" in eventState.eventPopupView.selectedRow) && eventState.eventPopupView.selectedRow.eventType ? eventState.eventPopupView.selectedRow.eventType : ""} />
                  <ViewComponentDesign label={"Description"} value={""} />
                  <div className='col-start-1 col-end-13'><TextArea value={("eventDescription" in eventState.eventPopupView.selectedRow) && eventState.eventPopupView.selectedRow.eventDescription ? eventState.eventPopupView.selectedRow.eventDescription : ""} isViewable={true} height={" !h-32 md:!h-[12rem] text-13px tracking-normal "} /></div>
                </div>
              </div>
              <div className='grid col-start-1 col-end-13 md:col-start-7 md:col-end-13 gap-y-2 '>
                <div><Label label={"Presenter"} setBold={true} />
                  <ul className=' max-h-[8rem] p-2 h-[8rem] overflow-auto label-shadow text-gray-700 rounded border-2 border-gray-200 bg-gray-200 text-13px'>
                    {eventState.eventPopupView.presenter && eventState.eventPopupView.presenter.length > 0 ? eventState.eventPopupView.presenter.map((val, idx) => { return <li key={idx}>{val.employeeName}</li> }) : <li >No Presenter found</li>}
                  </ul></div>
                <div><Label label={"Participant"} setBold={true} />
                  <ul className=' max-h-[8rem] p-2 h-[8rem] overflow-auto label-shadow text-gray-700 rounded border-2 border-gray-200 bg-gray-200 text-13px'>
                    {eventState.eventPopupView.participant && eventState.eventPopupView.participant.length > 0 ? eventState.eventPopupView.participant.map((val, idx) => { return <li key={idx}>{val.employeeName}</li> }) : <li>No Participant found</li>}
                  </ul></div>
              </div>
            </div>
          </div>
        } />}
        {recordEventPopup.show && <RecordEventPopup />}
        {eventState.tabularView.logViewPopup.show && <LogViewPopup />}
      </>
    </div>
  )
}

export default ViewEvents