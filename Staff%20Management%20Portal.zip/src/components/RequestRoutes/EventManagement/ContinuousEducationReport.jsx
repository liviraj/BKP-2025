import PropTypes from 'prop-types';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { dateFormat, eventManagementReducerState, exportDateFormat } from '../../helper';

import AgGrid from '../../Grid/AgGrid';
import { generateSummary } from '../../Grid/Columns';
import { eventManagementActions } from '../../../redux/eventManagementReducer';
import { eventManagementRequests } from '../../requests';



export function GenerateSummary({ className, filterParams, setLoader }) {
    const generateSummaryState = useSelector(state => state.eventManagement.generateSummary);
    const [employeeDetails, setEmployeeDetails] = useState({ name: "", position: "", description: "", period: "" })
    const dispatch = useDispatch();

    useEffect(() => {
        const onload = () => {
            let name = "", position = "", description = "", period = "";
            if (generateSummaryState.employeeDetails.length > 0) {
                const employeeDetailsState = generateSummaryState.employeeDetails[0];
                if ("Ename" in employeeDetailsState) {
                    name = employeeDetailsState.Ename;
                }
                if ("Description" in employeeDetailsState) {
                    description = employeeDetailsState.Description;
                }
                if ("Designation" in employeeDetailsState) {
                    position = employeeDetailsState.Designation;
                }
                period = `${dateFormat(generateSummaryState.selectedParams.fromDate)} - ${dateFormat(generateSummaryState.selectedParams.toDate)}`;
            }
            setEmployeeDetails({ name, position, description, period });
        }
        onload();

    }, [generateSummaryState]);

    return (
        <div className={`${className} font-fontfamily px-6 overflow-auto`}>
            <div className=' flex justify-end text-12px text-calendarTextColor font-bold leading-4'>ASHI #03-1-NY-26-2<br />CLIA #33D0985173 <br />UNOS # </div>
            <div className='text-13px text-calendarTextColor font-bold leading-4 flex justify-start'>Date : {dateFormat(new Date())}</div>
            <div className='text-14px text-calendarTextColor font-bold leading-4 flex justify-center'>G. CONTINUING EDUCATION SUMMARY FORM</div>
            <div className='text-12px text-calendarTextColor font-bold leading-4 flex justify-center my-3'>
                The minimum hours of continuing education will be met if the individual is ABHI certified and has maintained continued certification. For directors/technical supervisors
                not maintaining continued certification, a minimum of 50 hours/year is required. For general supervisors not maintaining contiued certification, a minimum of 27 hours/year is required. For those testing personnel
                not maintaining continued certification, a minimum of 12 hours/year is required.
            </div>
            <div className=' grid 2xl:grid-cols-10 xl:grid-cols-8 text-12px text-calendarTextColor leading-5'>
                <SingleValueComponent label={"Name"} value={employeeDetails.name} />
                <SingleValueComponent label={"Position"} value={employeeDetails.position} />
                <SingleValueComponent label={"Description"} value={employeeDetails.description} />
                <SingleValueComponent label={"Period"} value={employeeDetails.period} />
            </div>
            {generateSummaryState.summary && generateSummaryState.summary.length > 0 ? generateSummaryState.summary.map((val, idx) => <div key={idx}>
                <DoubleValueComponent program={("Program" in val) && val.Program} participiationHours={("PartHrs" in val) && val.PartHrs} participiationLevel={("PartLevel" in val) && val.PartLevel} approvedByAbhi={("AbhiApproval" in val) && val.AbhiApproval} content={("Contents" in val) && val.Contents} contentOnClick={async () => {
                    await setLoader(true);
                    const params = {
                        employeeId: ("employeeId" in filterParams.employeeName) ? filterParams.employeeName.employeeId : 0,
                        fromDate: exportDateFormat(filterParams.fromDate),
                        toDate: exportDateFormat(filterParams.toDate),
                        locationId: Object.keys(filterParams.location).length > 0 ? filterParams.location.value : 0,
                        reportCategory: val.Program,
                        reportType: val.PartLevel,
                    }
                    await dispatch(eventManagementRequests.reportEvents.getDocumentViewforGenerateSummary(params, async (data) => {
                        await dispatch(eventManagementActions.setGenerateSummaryDocumentView({ show: true, selectedRow: val, filterParams, data: data || [] }));
                    }));
                    setLoader(false);
                }} />
            </div>) : <DoubleValueComponent />}
            {(eventManagementReducerState().generateSummary.summary.length > 0 || eventManagementReducerState().generateSummary.summaryTable.length > 0 || eventManagementReducerState().generateSummary.employeeDetails.length > 0) && <>
                <div className='text-13px text-calendarTextColor font-bold leading-4 flex justify-start mt-4 mb-1 '>Summary of contact hours by type :</div>
                <AgGrid columns={generateSummary.columns} data={eventManagementReducerState().generateSummary.summaryTable} height={" h-56 "} />
            </>}
        </div>
    )
}

GenerateSummary.propTypes = {
    className: PropTypes.string,
    filterParams: PropTypes.object,
    setLoader: PropTypes.func
}

const SingleValueComponent = ({ label, value }) => {
    return <>
        <div className=' col-start-1 col-end-2 font-bold'>{label}</div>
        <div className=' col-start-2 col-end-13 gap-2 flex'> <span className=' font-bold'>:</span>
            <div className=' border-b-1 border-blackColor border-solid w-full font-semibold text-[#818181] text-13px pl-1'>{value}</div>
        </div>
    </>
}

SingleValueComponent.propTypes = {
    label: PropTypes.string,
    value: PropTypes.string
}

const DoubleValueComponent = ({ program, participiationHours, participiationLevel, approvedByAbhi, content, contentOnClick }) => {
    return <div className='grid 2xl:grid-cols-10 xl:grid-cols-8 text-12px text-calendarTextColor leading-5 my-2'>
        <SingleValueComponent label={"Program"} value={program || ""} />
        <div className=' col-start-1 col-end-2 font-bold'>Participation Hours</div>
        <div className=' col-start-2 xl:col-end-4 xsm:col-end-13 gap-2 flex mr-4'> <span className=' font-bold'>:</span>
            <div className=' border-b-1 border-blackColor border-solid w-full font-semibold text-[#818181] text-13px pl-1'>{participiationHours || ""}</div>
        </div>
        <div className=' xl:col-start-4 xsm:col-start-1 xl:col-end-5 xsm:col-end-2 font-bold'>Participation Level</div>
        <div className=' xl:col-start-5 xsm:col-start-2 col-end-13 gap-2 flex'> <span className=' font-bold'>:</span>
            <div className=' border-b-1 border-blackColor border-solid w-full font-semibold text-[#818181] text-13px pl-1'>{participiationLevel || ""}</div>
        </div>
        <div className=' col-start-1 col-end-2 font-bold'>Approved by ABHI?</div>
        <div className=' col-start-2 xl:col-end-4 xsm:col-end-13 gap-2 flex mr-4'> <span className=' font-bold'>:</span>
            <div className=' border-b-1 border-blackColor border-solid w-full font-semibold text-[#818181] text-13px pl-1'>{approvedByAbhi || ""}</div>
        </div>
        <div className=' xl:col-start-4 xsm:col-start-1 xl:col-end-5 xsm:col-end-2 font-bold'>Content</div>
        <div className=' xl:col-start-5 xsm:col-start-2 col-end-13 gap-2 flex'> <span className=' font-bold'>:</span>
            <div className=' border-b-1 border-blackColor border-solid w-full font-semibold text-[#818181] text-13px pl-1'>{content ? <span onClick={contentOnClick} className=' cursor-pointer text-blue-600 hover:underline'>{content}</span> : ""}</div>
        </div>
    </div>
}

DoubleValueComponent.propTypes = {
    program: PropTypes.string,
    participiationHours: PropTypes.string,
    participiationLevel: PropTypes.string,
    approvedByAbhi: PropTypes.string,
    content: PropTypes.string,
    contentOnClick: PropTypes.func
}

export const ContinuousEducationReportFooter = ({ isPopup }) => {
    return <footer className={`text-12px bg-themeBgColor text-headerColor text-center border-borderThemeColor border-1 border-solid ${isPopup ? 'md:relative' : 'md:fixed '}   xsm:relative bottom-0 z-10 lg:h-14 xsm:h-auto flex items-center justify-center w-full`}>Copyright(c) 2001 by the American Society of Histocompatibility and immunogenetics, Lenexa, Kansas. <br /> All Rights Reserved. No part of the contents of this document may be reproduced or transmitted in any form or by any means without the written permission of the publisher.
        <span className={` ${isPopup ? 'md:relative ' : 'md:fixed '}  xsm:relative bottom-2 right-2 self-end z-10 bg-themeBgColor px-3 py-1`}>Rev. 12/9</span>
    </footer>
}


ContinuousEducationReportFooter.propTypes = {
    isPopup: PropTypes.bool
}