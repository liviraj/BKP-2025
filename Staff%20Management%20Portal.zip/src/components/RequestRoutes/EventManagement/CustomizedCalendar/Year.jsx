import PropTypes from 'prop-types';
import React, { useMemo, useState } from 'react'
import moment from 'moment-timezone'
import { store } from '../../../../redux/store'
import { eventManagementActions } from '../../../../redux/eventManagementReducer'
import { Views } from 'react-big-calendar'
import { eventColors } from '../../../Constants'
import { Tooltip } from '@mui/material'
import { useDispatch } from 'react-redux';
import { eventManagementRequests } from '../../../requests';

function createCalendar(currentDate) {
  if (!currentDate) {
    currentDate = moment()
  } else {
    currentDate = moment(currentDate)
  }

  const first = currentDate.clone().startOf('month')
  const last = currentDate.clone().endOf('month')
  const weeksCount = Math.ceil((first.day() + last.date()) / 7)
  const calendar = Object.assign([], { currentDate, first, last })

  for (let weekNumber = 0; weekNumber < weeksCount; weekNumber++) {
    const week = []
    calendar.push(week)
    calendar.year = currentDate.year()
    calendar.month = currentDate.month()

    for (let day = 7 * weekNumber; day < 7 * (weekNumber + 1); day++) {
      const date = currentDate.clone().set('date', day + 1 - first.day())
      date.calendar = calendar
      week.push(date)
    }
  }

  return calendar
}

function CalendarDate(props) {

  const [show, setShow] = useState(false)
  const dispatch = useDispatch();
  const { dateToRender, dateOfMonth, selectedDate, events } = props;

  const dateFormatComparison = (date) => (new Date(moment(date).set({ hour: 0, minute: 0, second: 0 })).toString());

  const setStyle = useMemo(() => {
    const isValid = events.find(val => dateFormatComparison(val.start) === dateFormatComparison(dateToRender));
    const styleIndex = isValid ? isValid.styleId : -1;
    return styleIndex > -1 ? eventColors.find(val => val.id === styleIndex).yearStyle : " hidden ";
  }, [dateToRender, events]);

  const getEventTopics = useMemo(() => {
    const getEvents = events.filter(val => dateFormatComparison(val.start) === dateFormatComparison(dateToRender));
    if (getEvents && getEvents.length > 0) {
      const onEventClick = async (event) => {
        setShow(false);
        await dispatch(eventManagementActions.setViewEventLoader(true));
        await dispatch(eventManagementRequests.recordEvents.getEditEvent(event, "View"))
        dispatch(eventManagementActions.setViewEventLoader(false));
      }
      return <div className=' bg-white' onMouseLeave={() => setShow(false)}>
        <div className='border border-solid border-[#e5e5e5] gap-1 box-highlight-shadow'>
          <div className=' bg-[#edf2f7] text-[#6d6f9c] font-bold text-16px px-[10px] py-[2px] border-solid border-b border-[#e5e5e5]'>{moment(dateToRender).format(" dddd MMM DD ")}</div>
          <div className=' m-2'>
            {getEvents.map((val, idx) => <div key={idx} className={` flex p-1 my-[2px] items-center text-13px cursor-pointer ${eventColors.find(style => style.id === val.styleId)?.containerStyle} ${eventColors.find(style => style.id === val.styleId)?.hoverStyle} `} onClick={() => onEventClick(val)}>{val.data.appointment.title}</div>)}
          </div>
        </div>
      </div>
    }
    return ""
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dateToRender, events]);

  if (dateToRender.month() < dateOfMonth.month()) {
    return (
      <button disabled={true} className=" h-8 w-8 text-13px font-fontfamily outline-none border-none text-gray-500">
        {dateToRender.date()}
      </button>
    )
  }

  if (dateToRender.month() > dateOfMonth.month()) {
    return (
      <button disabled={true} className="h-8 w-8 text-13px font-fontfamily outline-none border-none text-gray-500">
        {dateToRender.date()}
      </button>
    )
  }

  return (
    <Tooltip title={getEventTopics} describeChild disableTouchListener
      open={show}
      onMouseEnter={() => setShow(true)}
      onClick={() => setShow(false)}
      onClose={() => setShow(false)}
      componentsProps={{
        tooltip: {
          sx: {
            bgcolor: 'transparent',
            margin: 0,
            padding: 0,
            borderRadius: 5,
            borderWidth: 2,
            border: "solid",
            borderColor: "transparent"
          },
        },
      }} >
      <button className={` h-8 w-8 inline-flex justify-center items-center cursor-pointer rounded border-1 border-solid border-transparent hover:border-borderBlue hover:font-bold ${dateToRender.format('YYYY-MM-DD') === moment(selectedDate).format('YYYY-MM-DD') ? ' font-bold  !border-borderBlue' : ''}  outline-none  text-13px font-fontfamily `} onClick={() => props.onClick(dateToRender)} >
        {dateToRender.date()}
        <span className=' relative h-0 w-0 inline-flex'>
          <span className={` absolute text-18px font-mono h-0 w-0 bottom-[9px] ${dateToRender.date() < 10 ? " right-[8.5px]" : " right-[12.5px]"} rounded ${setStyle} font-extrabold `} >.</span>
        </span>
      </button>
      {/* <span className=' relative h-0 w-0 inline-flex' onClick={() => props.onClick(dateToRender)}>
        <span className={` absolute h-0 w-0 bottom-[8px] right-[18px] rounded ${setStyle()} font-extrabold `} >.</span>
      </span> */}
    </Tooltip>
  )
}

CalendarDate.propTypes = {
  dateToRender: PropTypes.any,
  dateOfMonth: PropTypes.any,
  selectedDate: PropTypes.any,
  events: PropTypes.array,
  onClick: PropTypes.func
}

class Calendar extends React.Component {
  state = {
    calendar: undefined
  }

  componentDidMount() {
    this.setState({ calendar: createCalendar(this.props.date) })
  }

  componentDidUpdate(prevProps) {
    if (this.props.date !== prevProps.date) {
      this.setState({ calendar: createCalendar(this.props.date) })
    }
  }

  render() {
    if (!this.state.calendar) {
      return null
    }

    return (
      <div className=" m-1 mb-4 calendarbtn-shadow bg-warmGray-50">
        <div className=" font-fontfamily text-center font-bold text-calendarThemeColor">
          {this.state.calendar.currentDate.format('MMMM').toUpperCase()}
        </div>
        <div>
          {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, index) => (
            <span key={index} className=" inline-block h-8 w-8 text-13px font-fontfamily text-center leading-7 bg-calendarThemeColor text-white">
              {day}
            </span>
          ))}

          {this.state.calendar.map((week, index) => (
            <div key={index}>
              {week.map(date => (
                <CalendarDate
                  key={date.date()}
                  dateToRender={date}
                  dateOfMonth={this.state.calendar.currentDate}
                  onClick={date => {
                    store.dispatch(eventManagementActions.setCalendarDate(date))
                    this.props.onView(Views.DAY)
                  }
                  }
                  {...this.props}
                />
              ))}
            </div>
          ))}
        </div>
      </div>
    )
  }
}

Calendar.propTypes = {
  date: PropTypes.any,
  onView: PropTypes.func
}

class Year extends React.Component {
  render() {
    let { date, ...restprops } = this.props;
    const months = []
    const firstMonth = moment(date).set({ month: 0, date: 1 }); // dates.startOf(date, 'year')

    for (let i = 0; i < 12; i++) {
      months.push(
        <Calendar key={i + 1} date={moment(firstMonth).add(i, "month")} selectedDate={date} {...restprops} /> //dates.add(firstMonth, i, 'month')
      )
    }

    return <div className=" flex flex-wrap justify-between">{months.map(month => month)}</div>
  }
}

Year.title = (date, { localizer }) => localizer.format(date, 'yearHeaderFormat')

export default Year

Year.propTypes = {
  date: PropTypes.any
}
