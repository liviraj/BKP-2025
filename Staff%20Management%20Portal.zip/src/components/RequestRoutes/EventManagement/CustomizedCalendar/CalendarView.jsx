import { useState, useCallback, useMemo, useEffect } from 'react';
import { Calendar, Views, momentLocalizer } from 'react-big-calendar';
import moment from 'moment-timezone';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import { AppointmentEvent, BlockoutEvent } from './customEvents';
import DatePickerElement from '../../../elements/DatePickerElement';
import ButtonGroup from '@mui/material/ButtonGroup';
import { PiArrowLeftBold, PiArrowRightBold } from 'react-icons/pi';
import ToggleButtonElement from '../../../elements/ToggleButtonElement';
import Year from './Year';
import { useDispatch, useSelector } from 'react-redux';
import { eventManagementActions } from '../../../../redux/eventManagementReducer';
import { eventManagementReducerState, exportDateFormat, userReducerState } from '../../../helper';
import { eventManagementRequests } from '../../../requests';

function CalendarView() {
  const [events, setEvents] = useState([]);
  const dispatch = useDispatch();

  const calendarViewState = useSelector(state => state.eventManagement.calendarView);
  const eventState = useSelector(state => state.eventManagement);

  const STEP = 5;
  const TIME_SLOTS = 60 / STEP;

  useEffect(() => {

    calendarViewState.data.length > 0 && setEvents(calendarViewState.data.map((val, idx) => {
      return {
        id: idx,
        ...val,
        start: moment(val.eventStartDate).toDate(),
        end: moment(val.eventEndDate).toDate(),
        styleId: idx % 5,
        data: {
          appointment: {
            title: val.eventTopic,
            description: val.eventDescription
          }
        }
      }
    }));
  }, [calendarViewState.data, eventState])

  const setDate = async (date) => {
    await eventRecordCheck(date);
    await dispatch(eventManagementActions.setCalendarDate(date));
  }
  const setView = async (view) => {
    const date = calendarViewState.date;
    await eventRecordCheck(date);
    await dispatch(eventManagementActions.setCalendarView(view));
  }

  const onPrevClick = useCallback(async () => {
    const date = calendarViewState.date;
    if (calendarViewState.view === Views.DAY) {
      setDate(moment(date).subtract(1, "d").toDate());
    } else if (calendarViewState.view === Views.WEEK) {
      setDate(moment(date).subtract(1, "w").toDate());
    } else if (calendarViewState.view === year) {
      setDate(moment(date).subtract(1, "year").toDate());
    } else {
      setDate(moment(date).subtract(1, "M").toDate());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [calendarViewState]);

  const onNextClick = useCallback(async () => {
    const date = calendarViewState.date;
    if (calendarViewState.view === Views.DAY) {
      setDate(moment(date).add(1, "d").toDate());
    } else if (calendarViewState.view === Views.WEEK) {
      setDate(moment(date).add(1, "w").toDate());
    } else if (calendarViewState.view === year) {
      setDate(moment(date).add(1, "year").toDate());
    } else {
      setDate(moment(date).add(1, "M").toDate());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [calendarViewState]);

  const eventRecordCheck = async (date) => {
    const getYear = moment(date).year();
    if (!eventManagementReducerState().calendarView.selectedYears.includes(getYear)) {
      await dispatch(eventManagementActions.setViewEventLoader(true));
      const params = {
        employeeId: userReducerState().UserID,
        fromdate: exportDateFormat(moment(date).set({ month: 0, date: 1 }), true),
        toDate: exportDateFormat(moment(date).set({ month: 11, date: 31 }), true)
      }
      await dispatch(eventManagementRequests.viewEvents.getViewEvents(params));
      dispatch(eventManagementActions.setViewEventLoader(false));
    }
  }

  const dateText = useMemo(() => {
    const date = calendarViewState.date;

    if (calendarViewState.view === Views.DAY) {
      return moment(date).format("dddd, MMMM DD");
    }
    else if (calendarViewState.view === Views.WEEK) {
      const from = moment(date)?.startOf("week");
      const to = moment(date)?.endOf("week");
      return `${from.format("MMMM DD")} to ${to.format("MMMM DD")}`;
    }
    else if (calendarViewState.view === Views.MONTH) {
      return moment(date).format("MMMM YYYY");
    }
    else if (calendarViewState.view === year) {
      return moment(date).get("year");
    }
    else if (calendarViewState.view === Views.AGENDA) {
      const from = moment(date);
      const to = moment(date).add(30, "days");
      return `${from.format("dddd, MMMM DD")} to ${to.format("dddd, MMMM DD")}`;
    }
  }, [calendarViewState]);

  const components = {
    event: ({ event }) => {

      const data = event?.data;
      const onClick = async (event) => {
        await dispatch(eventManagementActions.setViewEventLoader(true));
        await dispatch(eventManagementRequests.recordEvents.getEditEvent(event, "View"));
        dispatch(eventManagementActions.setViewEventLoader(false));
      }
      if (data?.appointment) {
        return (
          <AppointmentEvent
            appointment={data?.appointment}
            isMonthView={calendarViewState.view === Views.MONTH}
            event={event}
            onClick={onClick}
          />
        );
      }

      if (data?.blockout) {
        return <BlockoutEvent
          blockout={data?.blockout}
          onClick={onClick}
          event={event}
          isMonthView={calendarViewState.view === Views.MONTH}
        />;
      }

      return null;
    },
    // timeSlotWrapper: ({
    //   children,
    //   value,
    //   resource,
    // }) => {
    //   return cloneElement(children, {
    //     onContextMenu: (e) => {
    //       e.preventDefault();
    //       setContextMenuInfo({
    //         xPosition: e.clientX,
    //         yPosition: e.clientY,
    //         selectedTime: value,
    //         resourceId: resource,
    //       });
    //     },
    //   });
    // },

  };

  const onDateChange = async (date) => {
    await eventRecordCheck(date);
    await dispatch(eventManagementActions.setCalendarDate(date))
  }

  return (
    <div className='h-auto md:max-h-h_body_md sm:max-h-full overflow-auto'>
      <div className=' flex justify-between items-center w-full gap-2 px-6 flex-wrap min-h-16 xl:max-h-16 xl:h-16 lg:max-h-28 lg:h-28 md:max-h-36 md:h-36 xsm:py-2 md:py-0 bg-white relative'>
        <div className=' flex justify-between items-center'>
          <DatePickerElement value={calendarViewState.date} onChange={date => onDateChange(date)} />
        </div>
        <div className=' flex gap-4 flex-wrap'>
          <button className='calendarbtn' onClick={() => setDate(new Date())}>Today</button>
          <ButtonGroup variant="contained" aria-label="Basic button group">
            <button className='calendarbtn !border-r-0 !rounded-r-none' onClick={onPrevClick}><PiArrowLeftBold size={18} color='#506F85' /></button>
            <div className=' bg-calendarThemeColor text-white text-15px w-64 flex justify-center items-center customDateView'>{dateText}</div>
            <button className='calendarbtn !border-l-0 !rounded-l-none' onClick={onNextClick}><PiArrowRightBold size={18} color='#506F85' /></button>
          </ButtonGroup>
        </div>
        <ToggleButtonElement value={calendarViewState.view} onChange={(e) => setView(e.target.value)} options={VIEW_OPTIONS} />
      </div>
      <div className=" xsm:h-75vh xl:md:h-[calc(100vh-4.6rem-3.6rem-1rem-4rem)] lg:h-[calc(100vh-4.6rem-3.6rem-1rem-7rem)] md:h-[calc(100vh-4.6rem-3.6rem-1rem-9rem)]  mx-6 overflow-auto">
        <Calendar
          defaultDate={moment(new Date(), 'YYYY-MM-DD').toDate()}
          defaultView={Views.MONTH}
          events={events}
          className=' customCalendar'
          localizer={momentLocalizer(moment)}
          components={components}
          date={calendarViewState.date}
          view={calendarViewState.view}
          views={{
            day: true,
            week: true,
            month: true,
            year: Year
          }}
          messages={{ year: "Year" }}
          onView={setView}
          onNavigate={setDate}
          handleDragStart={() => false}
          popup={true}
          toolbar={false}
          // draggableAccessor={(event) => true}
          step={STEP}
          timeslots={TIME_SLOTS}
        />
      </div>
    </div>
  )
}

export default CalendarView

export const year = "year";

// eslint-disable-next-line react-refresh/only-export-components
export const VIEW_OPTIONS = [
  { id: Views.DAY, label: "Day" },
  { id: Views.WEEK, label: "Week" },
  { id: Views.MONTH, label: "Month" },
  { id: year, label: "Year" }
  // { id: Views.AGENDA, label: "Agenda" }
];
