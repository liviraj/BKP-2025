import PropTypes from 'prop-types';
import moment from "moment-timezone";
import { eventColors, eventGreyColor, setDefaultValue } from "../../../Constants";
import { Tooltip } from '@mui/material';
import { useMemo } from 'react';
import { userReducerState } from '../../../helper';


export function AppointmentEvent({
  appointment,
  isMonthView,
  onClick,
  event
}) {
  const dateDiffInDays = (start, end) => {
    const _MS_PER_DAY = 1000 * 60 * 60 * 24;
    const utc1 = Date.UTC(start.getFullYear(), start.getMonth(), start.getDate());
    const utc2 = Date.UTC(end.getFullYear(), end.getMonth(), end.getDate());

    return Math.floor((utc2 - utc1) / _MS_PER_DAY);
  }

  const { title, description } = appointment;
  const style = event.styleId ? eventColors.find(val => val.id === event.styleId) : eventColors[0];
  const diffDays = dateDiffInDays(new Date(event.start), new Date(event.end));
  const dateFormat = userReducerState().LocationID === setDefaultValue.location.value ? "DD/MM/YYYY h:mm A" : "MM/DD/YYYY h:mm A";

  const getEventDetails = useMemo(() => {
    if (isMonthView || diffDays) {
      return <div className=' bg-transparent rounded' onClick={e => e.stopPropagation()}>
        <div className={`border border-solid !rounded border-[#e5e5e5] gap-1 box-highlight-shadow font-fontfamily ${style.containerStyle} p-1 ${isMonthView ? " overflow-hidden h-7 " : ""} ${style.hoverStyle}`}>
          <div className=" flex justify-center flex-col gap-[5px]">
            <div className=" text-[11px]">{`${moment(event.start).format(dateFormat)} - ${moment(event.end).format(dateFormat)}`}</div>
            <div className={` text-13px font-bold ${style.titleColor}`}>{title}</div>
            <div className=" text-[11px] w-full ">{description}</div>
          </div>
        </div>
      </div>
    }
    return ""
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <div className={` h-full ${style.containerStyle} p-1 ${isMonthView ? " overflow-hidden h-7 " : ""} ${style.hoverStyle} border-1 border-solid border-transparent font-fontfamily`} onClick={() => onClick(event)}>
      <div className=" flex justify-center flex-col gap-[5px]">
        {!(isMonthView || diffDays) && <div className=" text-[11px]">{`${moment(event.start).format("h:mm A")} - ${moment(event.end).format("h:mm A")}`}</div>}
        <Tooltip
          componentsProps={{
            tooltip: {
              sx: {
                bgcolor: 'transparent',
                margin: 0,
                padding: 0,
                borderRadius: 5,
                borderWidth: 2,
                border: "solid",
                borderColor: "transparent"
              },
            },
          }}
          title={getEventDetails}>
          <div className={` text-13px font-bold ${style.titleColor}`}>{title}</div>
        </Tooltip>
        {!(isMonthView || diffDays) && <div className=" text-[11px] w-full ">{description}</div>}
      </div>
    </div>
  );
}
AppointmentEvent.propTypes = {
  appointment: PropTypes.object,
  isMonthView: PropTypes.bool,
  onClick: PropTypes.func,
  event: PropTypes.object
}

export function BlockoutEvent({ blockout, onClick, event, isMonthView }) {
  const { title } = blockout;
  const style = eventGreyColor;
  return (
    <div className={` h-full ${style.containerStyle} p-1 ${style.hoverStyle} border-1 border-solid border-transparent font-fontfamily`} onClick={() => onClick(event)}>
      <div className=" flex justify-center flex-col gap-[5px]">
        {isMonthView || <div className=" text-[11px]">{`${moment(event.start).format("h:mm A")} - ${moment(event.end).format("h:mm A")}`}</div>}
        <div className={` font-bold text-13px text-center ${style.titleColor}`}>{title}</div>
      </div>
    </div>
  );
}

BlockoutEvent.propTypes = {
  blockout: PropTypes.object,
  onClick: PropTypes.func,
  event: PropTypes.object,
  isMonthView: PropTypes.bool
}
