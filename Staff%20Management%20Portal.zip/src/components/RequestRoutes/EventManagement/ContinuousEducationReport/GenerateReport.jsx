import { useEffect, useMemo, useState } from 'react'
import HeaderSection from '../../../layouts/HeaderSection'
import { continuousEducationReportOptions, strings } from '../../../Constants'
import SubHeaderSection from '../../../layouts/SubHeaderSection'
import Dropdown from '../../../elements/Dropdown'
import { dateFormat, employeeReducerState, exportDateFormat, periodDateFormat, periodOptionsWithoutPayroll, userReducerState } from '../../../helper'
import DatePickerElement from '../../../elements/DatePickerElement'
import Button from '../../../elements/Button'
import { useDispatch, useSelector } from 'react-redux'
import { useForm } from 'react-hook-form'
import ApiResponse from '../../../Alert/ApiResponse'
import TransparentLoader from '../../../loader/TransparentLoader'
import { generateReport } from '../../../Grid/Columns'
import AgGrid from '../../../Grid/AgGrid'
import { employeeRequests, eventManagementRequests } from '../../../requests'
import { ContinuousEducationReportFooter } from '../ContinuousEducationReport'


function GenerateReport() {
  const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
  const complianceReportState = useSelector(state => state.complianceReport);
  const employeeState = useSelector(state => state.employee);


  const dispatch = useDispatch();

  const { watch, setValue, getValues } = useForm({ defaultValues: initialState });
  const [loader, setLoader] = useState(false);
  const [data, setData] = useState([]);
  const location = watch(strings.continuousEducationReport.location);
  const employeeName = watch(strings.continuousEducationReport.employeeName);
  const fromDate = watch(strings.continuousEducationReport.fromDate);
  const todate = watch(strings.continuousEducationReport.toDate);
  const reports = watch(strings.continuousEducationReport.reports);

  useEffect(() => {
    const onInitialLoad = async () => {
      setLoader(true);
      await Promise.all([
        employeeState.location.length <= 0 && dispatch(employeeRequests.location()),
        employeeState.employeeName.length <= 0 && dispatch(employeeRequests.employeeName()),
      ])
      await onReset();
      setLoader(false);
    }
    onInitialLoad();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const onPeriodChange = (value) => {
    setValue(strings.continuousEducationReport.period, value);
    periodDateFormat(value, setValue);
    return value;
  }

  const onlocationChange = async (data) => {
    await setValue(strings.continuousEducationReport.location, data);
  }
  const onSubmit = async () => {
    await setLoader(true);
    let data = getValues()
    const params = {
      employeeId: data.employeeName.employeeId,
      fromDate: exportDateFormat(data.fromDate, true),
      toDate: exportDateFormat(data.toDate, true),
      reportCategory: strings.header.generateReport,
      reportType: data.reports.value,
      locationId: data.location.value
    }
    await dispatch(eventManagementRequests.reportEvents.getEventReports(params, async (records) => {
      await setData(records);
      // await dispatch(eventManagementActions.setGenerateReportViewPopup({ show: true, data: records, header: `Continuous Education Report ${staff && staff.value !== 0 ? `- ${staff.label}` : ""}` }));
    }));
    setLoader(false);
  }
  const onReset = async () => {

    await setLoader(true);
    await Promise.all([
      setValue(strings.continuousEducationReport.employeeName, ""),
      setValue(strings.continuousEducationReport.location, employeeReducerState().location.find(val => val.value === userReducerState().LocationID)),
      setValue(strings.continuousEducationReport.reports, continuousEducationReportOptions[0]),
      onPeriodChange(periodOptionsWithoutPayroll.find((val) => val.value === 7)),
      setData([])
    ]);
    if (complianceReportState.complianceReportPopup.isPopupView) {
      await Promise.all([
        setValue(strings.continuousEducationReport.employeeName, employeeState.employeeName.find((val) => val.value == complianceReportState.complianceReportPopup.data.employeeId)),
        setValue(strings.continuousEducationReport.location, employeeReducerState().location.find(val => val.value === complianceReportState.complianceReportPopup.data.locationId))
      ]);
      if (onDisable()) {
        await onSubmit()
      }
    }
    setLoader(false);
  }

  const employeeNameOptions = useMemo(() => {
    let employeeOptions = employeeState.employeeName;
    employeeOptions = employeeOptions.filter(val => ((val.employmentStatus !== "Relieved" && val.employmentStatus !== "") || val.employmentStatus === "All"));
    if (location && employeeOptions.length > 0) {
      employeeOptions = employeeOptions.filter(val => (val.locationId === location.value || val.locationId === 0));
    }
    if (employeeName?.value && !employeeOptions.find(val => val.value === employeeName.value)) {
      setValue(strings.continuousEducationReport.employeeName, employeeOptions.find(val => val.value === 0));
    }
    return employeeOptions;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [employeeState, location])

  const onDisable = () => {
    const values = getValues()
    return values.employeeName && values.fromDate && values.toDate && values.reports;
  }

  return (
    <div>
      {!complianceReportState.complianceReportPopup.isPopupView && <HeaderSection redirectType={strings.type.continuousEducationReport} />}
      <div className=' overflow-auto h-auto md:max-h-[calc(100vh-4.6rem-3.6rem-3.5rem)] sm:max-h-full'>
        <div className='px-6'>
          <SubHeaderSection subHeader="Continuous Education Report" printProps={{ columns: generateReport.columns, data: data.map((val, idx) => ({ ...val, sno: idx + 1, DOJ: dateFormat(val.DOJ) })), header: "Continuous Education - Generate Report" }} />
          <div className='flex mb-6 md:mb-6 xsm:mb-4' >
            <div className='grid xl:grid-rows-1 lg:grid-rows-2 md:grid-rows-2 sm:grid-rows-3 xsm:grid-rows-3 gap-x-4 gap-y-1 xl:grid-cols-4 lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 xsm:grid-cols-1 w-full'>
              <div><Dropdown placeholder={"Period"} options={periodOptionsWithoutPayroll.filter(val => val.value > 1)} value={watch(strings.continuousEducationReport.period)} onChange={e => onPeriodChange(e)} isLabelView={true} /></div>
              <div><DatePickerElement placeholder='From' disabled={watch(strings.continuousEducationReport.period).label !== strings.filterPeriod.custom} value={fromDate || ""} onChange={date => setValue(strings.continuousEducationReport.fromDate, date)} isRequired={true} isLabelView={true} /></div>
              <div><DatePickerElement placeholder='To' disabled={watch(strings.continuousEducationReport.period).label !== strings.filterPeriod.custom} value={todate || ""} minDate={watch(strings.continuousEducationReport.period).label === strings.filterPeriod.custom && fromDate} onChange={date => setValue(strings.continuousEducationReport.toDate, date)} isRequired={true} isLabelView={true} /></div>
              <div><Dropdown placeholder={"Location"} value={location} options={employeeState.location && employeeState.location.length > 0 ? employeeState.location.filter(val => val.value > 0) : []} onChange={data => userReducerState().Role === strings.userRoles.humanResource || onlocationChange(data)} isSearchable={true} isLabelView={true} isDisable={userReducerState().Role !== strings.userRoles.admin} /></div>
              <div><Dropdown placeholder={"Reports"} value={reports} options={continuousEducationReportOptions} onChange={e => setValue(strings.continuousEducationReport.reports, e)} isSearchable={true} isLabelView={true} /></div>
              <div><Dropdown placeholder={"Employee Name"} value={employeeName} options={employeeNameOptions} onChange={e => setValue(strings.continuousEducationReport.employeeName, e)} isSearchable={true} isLabelView={true} /></div>
              <div className=' self-end flex gap-x-3'>
                <Button value={strings.Buttons.Search} onClick={onSubmit} disabled={!onDisable()} />
                <Button value={strings.Buttons.Reset} onClick={() => onReset()} />
              </div>
            </div>
          </div>
          <AgGrid data={data} columns={generateReport.columns} height="h-[calc(94vh-67px-67px-3.5rem-1.5rem-4.6rem-0.5rem-3.5rem)] lg:h-[calc(94vh-67px-67px-3.5rem-1.5rem-4.6rem-1rem-3.5rem)] md:h-[calc(94vh-67px-67px-67px-3.5rem-1.5rem-4.6rem-1rem-3.5rem)] xsm:h-[58vh]" />
        </div>
        {!complianceReportState.complianceReportPopup.isPopupView && <ContinuousEducationReportFooter />}
      </div>
      {apiResponseState.show && <ApiResponse />}
      {loader && <TransparentLoader isFullWidth={complianceReportState.complianceReportPopup.isPopupView} />}
    </div>
  )
}

export default GenerateReport

const initialState = {
  location: "",
  reports: "",
  employeeName: "",
  period: "",
  fromDate: "",
  toDate: "",
}