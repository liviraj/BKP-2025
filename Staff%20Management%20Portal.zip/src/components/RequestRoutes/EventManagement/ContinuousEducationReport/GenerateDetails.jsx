import { useEffect, useMemo, useState } from 'react'
import HeaderSection from '../../../layouts/HeaderSection'
import { continuousEducationReportOptions, strings } from '../../../Constants'
import SubHeaderSection from '../../../layouts/SubHeaderSection'
import Dropdown from '../../../elements/Dropdown'
import { dateAndTimeFormat, employeeReducerState, exportDateFormat, periodDateFormat, periodOptionsWithoutPayroll, userReducerState } from '../../../helper'
import DatePickerElement from '../../../elements/DatePickerElement'
import Button from '../../../elements/Button'
import { useDispatch, useSelector } from 'react-redux'
import { useForm } from 'react-hook-form'
import ApiResponse from '../../../Alert/ApiResponse'
import TransparentLoader from '../../../loader/TransparentLoader'
import { generateDetails } from '../../../Grid/Columns'
import AgGrid from '../../../Grid/AgGrid'
import { eventManagementRequests } from '../../../requests'
import { ContinuousEducationReportFooter } from '../ContinuousEducationReport'


function GenerateDetails() {
  const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
  const employeeState = useSelector(state => state.employee);
  const complianceReportState = useSelector(state => state.complianceReport);
  const dispatch = useDispatch();

  const { watch, setValue, handleSubmit, getValues } = useForm({ defaultValues: initialState });
  const [loader, setLoader] = useState(false);
  const [data, setData] = useState([]);
  const location = watch(strings.continuousEducationReport.location);
  const employeeName = watch(strings.continuousEducationReport.employeeName);

  useEffect(() => {
    onReset();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const onPeriodChange = (value) => {
    setValue(strings.continuousEducationReport.period, value);
    periodDateFormat(value, setValue);
  }

  const onlocationChange = async (data) => {
    await setValue(strings.continuousEducationReport.location, data);
  }
  const onSubmit = async () => {
    const data = getValues()
    await setLoader(true);
    const params = {
      employeeId: data.employeeName.employeeId,
      fromDate: exportDateFormat(data.fromDate, true),
      toDate: exportDateFormat(data.toDate, true),
      reportCategory: strings.header.generateDetails,
      reportType: data.reports.value,
      locationId: data.location.value
    }
    await dispatch(eventManagementRequests.reportEvents.getEventReports(params, async (records) => {
      await setData(records);
    }));
    setLoader(false);
  }
  const onReset = async () => {
    setLoader(true);
    setValue(strings.continuousEducationReport.employeeName, "");
    setValue(strings.continuousEducationReport.location, employeeState.location.find(val => val.value === userReducerState().LocationID));
    setValue(strings.continuousEducationReport.reports, continuousEducationReportOptions[0]);
    onPeriodChange(periodOptionsWithoutPayroll[2]);
    setData([]);
    if (complianceReportState.complianceReportPopup.isPopupView) {
      setValue(strings.continuousEducationReport.employeeName, employeeState.employeeName.find((val) => val.value == complianceReportState.complianceReportPopup.data.employeeId));
      setValue(strings.continuousEducationReport.location, employeeReducerState().location.find(val => val.value === complianceReportState.complianceReportPopup.data.locationId));
      onPeriodChange(periodOptionsWithoutPayroll.find((val) => val.value === 7));
      if (onDisable()) {
        await onSubmit()
      }
    }
    setLoader(false);
  }

  const employeeNameOptions = useMemo(() => {
    let employeeOptions = employeeState.employeeName;
    employeeOptions = employeeOptions.filter(val => (val.employmentStatus !== "Relieved" && val.employmentStatus !== "" && val.employmentStatus !== "All"));
    if (location && employeeOptions.length > 0) {
      employeeOptions = employeeOptions.filter(val => (val.locationId === location.value || val.locationId === 0));
    }
    if (employeeName?.value && !employeeOptions.find(val => val.value === employeeName.value)) {
      setValue(strings.continuousEducationReport.employeeName, "");
    }
    return employeeOptions;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [employeeState, location]);

  const onDisable = () => {
    const values = getValues()
    return (values.employeeName && values.fromDate && values.toDate && values.reports)
  }


  return (
    <div>
      {!complianceReportState.complianceReportPopup.isPopupView && <HeaderSection redirectType={strings.type.continuousEducationReport} />}
      <div className='overflow-auto h-auto md:max-h-[calc(100vh-4.6rem-3.6rem-3.5rem)] sm:max-h-full'>
        <div className='px-6'>
          <SubHeaderSection subHeader="Continuous Education Report" printProps={{ columns: generateDetails.columns, data: data.map((val, idx) => ({ ...val, sno: idx + 1, EventStartDate: dateAndTimeFormat(val.EventStartDate), EventEndDate: dateAndTimeFormat(val.EventEndDate) })), header: "Continuous Education - Generate Details" }} />
          <div className='flex mb-6 md:mb-6 xsm:mb-4' >
            <div className='grid xl:grid-rows-1 lg:grid-rows-2 md:grid-rows-2 sm:grid-rows-3 xsm:grid-rows-3 gap-x-4 gap-y-1 xl:grid-cols-4 lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 xsm:grid-cols-1 w-full'>
              <div><Dropdown placeholder={"Period"} options={periodOptionsWithoutPayroll.filter(val => val.value > 1)} value={watch(strings.continuousEducationReport.period)} onChange={e => onPeriodChange(e)} isLabelView={true} /></div>
              <div><DatePickerElement placeholder='From' disabled={watch(strings.continuousEducationReport.period).label !== strings.filterPeriod.custom} value={watch(strings.continuousEducationReport.fromDate) ? watch(strings.continuousEducationReport.fromDate) : ""} onChange={date => setValue(strings.continuousEducationReport.fromDate, date)} isRequired={true} isLabelView={true} /></div>
              <div><DatePickerElement placeholder='To' disabled={watch(strings.continuousEducationReport.period).label !== strings.filterPeriod.custom} value={watch(strings.continuousEducationReport.toDate) ? watch(strings.continuousEducationReport.toDate) : ""} minDate={watch(strings.continuousEducationReport.period).label === strings.filterPeriod.custom && watch(strings.continuousEducationReport.fromDate)} onChange={date => setValue(strings.continuousEducationReport.toDate, date)} isRequired={true} isLabelView={true} /></div>
              <div><Dropdown placeholder={"Location"} value={location} options={employeeState.location && employeeState.location.length > 0 ? employeeState.location.filter(val => val.value > 0) : []} onChange={data => userReducerState().Role === strings.userRoles.humanResource || onlocationChange(data)} isSearchable={true} isLabelView={true} isDisable={userReducerState().Role !== strings.userRoles.admin} /></div>
              <div><Dropdown placeholder={"Reports"} value={watch(strings.continuousEducationReport.reports)} options={continuousEducationReportOptions} onChange={e => setValue(strings.continuousEducationReport.reports, e)} isSearchable={true} isLabelView={true} /></div>
              <div><Dropdown placeholder={"Employee Name"} value={employeeName} options={employeeNameOptions} onChange={e => setValue(strings.continuousEducationReport.employeeName, e)} isSearchable={true} isLabelView={true} /></div>
              <div className=' self-end flex gap-x-3'>
                <Button value={strings.Buttons.Search} onClick={handleSubmit(onSubmit)} disabled={!onDisable()} />
                <Button value={strings.Buttons.Reset} onClick={() => onReset()} />
              </div>
            </div>
          </div>
          <AgGrid data={data} columns={generateDetails.columns} height="h-[calc(94vh-67px-67px-3.5rem-1.5rem-4.6rem-0.5rem-3.5rem)] lg:h-[calc(94vh-67px-67px-3.5rem-1.5rem-4.6rem-1rem-3.5rem)] md:h-[calc(94vh-67px-67px-67px-3.5rem-1.5rem-4.6rem-1rem-3.5rem)] xsm:h-[58vh]" />
        </div>
        {!complianceReportState.complianceReportPopup.isPopupView && <ContinuousEducationReportFooter />}
      </div>
      {apiResponseState.show && <ApiResponse />}
      {loader && <TransparentLoader isFullWidth={complianceReportState.complianceReportPopup.isPopupView} />}
    </div>
  )
}

export default GenerateDetails

const initialState = {
  location: "",
  reports: "",
  employeeName: "",
  period: "",
  fromDate: "",
  toDate: "",
}