import { useEffect, useMemo, useState } from 'react'
import HeaderSection from '../../../layouts/HeaderSection'
import { continuousEducationReportOptions, strings } from '../../../Constants'
import SubHeaderSection from '../../../layouts/SubHeaderSection'
import Dropdown from '../../../elements/Dropdown'
import { employeeReducerState, eventManagementReducerState, exportDateFormat, periodDateFormat, periodOptionsWithoutPayroll, userReducerState } from '../../../helper'
import DatePickerElement from '../../../elements/DatePickerElement'
import Button from '../../../elements/Button'
import { useDispatch, useSelector } from 'react-redux'
import { useForm } from 'react-hook-form'
import ApiResponse from '../../../Alert/ApiResponse'
import TransparentLoader from '../../../loader/TransparentLoader'
import { eventManagementRequests } from '../../../requests'
import { ContinuousEducationReportFooter, GenerateSummary as GenerateSummaryComponent } from '../ContinuousEducationReport'
import { eventManagementActions } from '../../../../redux/eventManagementReducer'
import { GenerateSummaryPrintView } from '../../../Print/PrintView'
import { generateSummary } from '../../../Grid/Columns'
import GenerateSummaryDocumentView from '../../../Popup_window/GenerateSummaryDocumentView'


function GenerateSummary() {
  const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
  const employeeState = useSelector(state => state.employee);
  const generateSummaryDocumentViewState = useSelector(state => state.eventManagement.generateSummaryDocumentView);
  const complianceReportState = useSelector(state => state.complianceReport);


  const dispatch = useDispatch();

  const { watch, setValue, getValues } = useForm({ defaultValues: initialState });
  const [loader, setLoader] = useState(false);
  const location = watch(strings.continuousEducationReport.location);
  const employeeName = watch(strings.continuousEducationReport.employeeName);

  useEffect(() => {
    onReset();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const onPeriodChange = (value) => {
    setValue(strings.continuousEducationReport.period, value);
    periodDateFormat(value, setValue);
    return value;
  }

  const onlocationChange = async (data) => {
    await setValue(strings.continuousEducationReport.location, data);
  }
  const onSubmit = async () => {
    const data = getValues()
    await setLoader(true);
    const params = {
      employeeId: data.employeeName.employeeId,
      fromDate: exportDateFormat(data.fromDate, true),
      toDate: exportDateFormat(data.toDate, true),
      reportCategory: strings.header.generateSummary,
      reportType: continuousEducationReportOptions[0].value,
      locationId: data.location.value
    }
    await dispatch(eventManagementRequests.reportEvents.getEventReports(params, async (records) => {
      const employeeDetails = ("EmployeeDetail" in records) && records.EmployeeDetail && records.EmployeeDetail.length > 0 ? records.EmployeeDetail : [];
      const summary = ("Summary" in records) && records.Summary && records.Summary.length > 0 ? records.Summary : [];
      const summaryTable = ("TableContent" in records) && records.TableContent && records.TableContent.length > 0 ? records.TableContent : [];
      await dispatch(eventManagementActions.setGenerateSummary({ show: false, selectedParams: data, employeeDetails, summary, summaryTable }));
    }));
    setLoader(false);
  }
  const onReset = async () => {
    await setLoader(true);
    await Promise.all([
      setValue(strings.continuousEducationReport.employeeName, ""),
      setValue(strings.continuousEducationReport.location, employeeState.location.find(val => val.value === userReducerState().LocationID)),
      onPeriodChange(periodOptionsWithoutPayroll.find((val) => val.value === 7)),
      dispatch(eventManagementActions.setGenerateSummary({ show: false, selectedParams: {}, employeeDetails: [], summary: [], summaryTable: [] }))
    ]);
    if (complianceReportState.complianceReportPopup.isPopupView) {
      await Promise.all([
        setValue(strings.continuousEducationReport.employeeName, employeeState.employeeName.find((val) => val.value == complianceReportState.complianceReportPopup.data.employeeId)),
        setValue(strings.continuousEducationReport.location, employeeReducerState().location.find(val => val.value === complianceReportState.complianceReportPopup.data.locationId))
      ]);
      if (onDisable()) {
        await onSubmit()
      }
    }
    setLoader(false);
  }

  const employeeNameOptions = useMemo(() => {
    let employeeOptions = employeeState.employeeName;
    employeeOptions = employeeOptions.filter(val => (val.employmentStatus !== "Relieved" && val.employmentStatus !== "" && val.employmentStatus !== "All"));
    if (location && employeeOptions.length > 0) {
      employeeOptions = employeeOptions.filter(val => (val.locationId === location.value || val.locationId === 0));
    }
    if (employeeName?.value && !employeeOptions.find(val => val.value === employeeName.value)) {
      setValue(strings.continuousEducationReport.employeeName, "");
    }
    return employeeOptions;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [employeeState, location]);

  const onDisable = () => {
    const values = getValues();
    return values.employeeName && values.fromDate && values.toDate;
  }

  return (
    <div>
      {!complianceReportState.complianceReportPopup.isPopupView && <HeaderSection redirectType={strings.type.continuousEducationReport} />}
      <div className=' overflow-auto h-auto md:max-h-[calc(100vh-4.6rem-3.6rem-3.5rem)] sm:max-h-full'>
        <div className='px-6'>
          <SubHeaderSection subHeader="Continuous Education Report" newComponent={<GenerateSummaryPrintView columns={generateSummary.columns} data={eventManagementReducerState().generateSummary.summaryTable} />} />
          <div className='flex mb-6 md:mb-6 xsm:mb-4' >
            <div className='grid lg:grid-rows-2 md:grid-rows-3 sm:grid-rows-3 gap-x-4 gap-y-1 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-3 w-full'>
              <div><Dropdown placeholder={"Period"} options={periodOptionsWithoutPayroll.filter(val => val.value > 1)} value={watch(strings.continuousEducationReport.period)} onChange={e => onPeriodChange(e)} isLabelView={true} /></div>
              <div><DatePickerElement placeholder='From' disabled={watch(strings.continuousEducationReport.period).label !== strings.filterPeriod.custom} value={watch(strings.continuousEducationReport.fromDate) ? watch(strings.continuousEducationReport.fromDate) : ""} onChange={date => setValue(strings.continuousEducationReport.fromDate, date)} isRequired={true} isLabelView={true} /></div>
              <div><DatePickerElement placeholder='To' disabled={watch(strings.continuousEducationReport.period).label !== strings.filterPeriod.custom} value={watch(strings.continuousEducationReport.toDate) ? watch(strings.continuousEducationReport.toDate) : ""} minDate={watch(strings.continuousEducationReport.period).label === strings.filterPeriod.custom && watch(strings.continuousEducationReport.fromDate)} onChange={date => setValue(strings.continuousEducationReport.toDate, date)} isRequired={true} isLabelView={true} /></div>
              <div><Dropdown placeholder={"Location"} value={location} options={employeeState.location && employeeState.location.length > 0 ? employeeState.location.filter(val => val.value > 0) : []} onChange={data => userReducerState().Role === strings.userRoles.humanResource || onlocationChange(data)} isSearchable={true} isLabelView={true} isDisable={userReducerState().Role !== strings.userRoles.admin} /></div>
              <div><Dropdown placeholder={"Employee Name"} value={employeeName} options={employeeNameOptions} onChange={e => setValue(strings.continuousEducationReport.employeeName, e)} isSearchable={true} isLabelView={true} /></div>
              <div className=' col-span-full flex justify-center self-end gap-x-3'>
                <Button value={strings.Buttons.Search} onClick={onSubmit} disabled={!onDisable()} />
                <Button value={strings.Buttons.Reset} onClick={() => onReset()} />
              </div>
            </div>
          </div>
        </div>
        <GenerateSummaryComponent className={"xsm:h-auto min-h-[55vh]"} filterParams={getValues()} setLoader={setLoader} />
        {!complianceReportState.complianceReportPopup.isPopupView && <ContinuousEducationReportFooter />}
      </div>
      {generateSummaryDocumentViewState.show && <GenerateSummaryDocumentView />}
      {apiResponseState.show && <ApiResponse />}
      {loader && <TransparentLoader isFullWidth={complianceReportState.complianceReportPopup.isPopupView} />}
    </div>
  )
}

export default GenerateSummary

const initialState = {
  location: "",
  reports: "",
  employeeName: "",
  period: "",
  fromDate: "",
  toDate: "",
}