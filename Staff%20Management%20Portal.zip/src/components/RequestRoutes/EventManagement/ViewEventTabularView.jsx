import { useEffect, useState } from 'react';
import { strings } from '../../Constants';
import Dropdown from '../../elements/Dropdown';
import { periodOptionsWithoutPayroll, exportDateFormat, periodDateFormat, searchEventOptions, userReducerState, getNumberOfYears, eventManagementReducerState } from '../../helper';
import { useForm } from 'react-hook-form';
import DatePickerElement from '../../elements/DatePickerElement';
import Button from '../../elements/Button';
import TextField from '../../elements/TextField';
import AgGrid from '../../Grid/AgGrid';
import { eventManagement } from '../../Grid/Columns';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { Views } from 'react-big-calendar';
import moment from 'moment-timezone';
import { year } from './CustomizedCalendar/CalendarView';
import { eventManagementActions } from '../../../redux/eventManagementReducer';
import { eventManagementRequests } from '../../requests';

const ViewEventTabularView = () => {
    const history = useHistory();

    const calendarViewState = useSelector(state => state.eventManagement.calendarView);
    const eventState = useSelector(state => state.eventManagement);
    const loginResponseState = useSelector(state => state.loginResponse);
    const { watch, setValue, handleSubmit, reset, getValues } = useForm({ defaultValues: initialStates });
    const dispatch = useDispatch();
    const [eventOptions, setEventOptions] = useState([{ label: "All", value: 0 }]);

    useEffect(() => {
        const initialLoad = async () => {
            await dispatch(eventManagementActions.setViewEventLoader(true));
            eventState.recordEvents.eventTypes.length <= 0 && await dispatch(eventManagementRequests.recordEvents.getAllEventsTypes());
            await onReset();
            dispatch(eventManagementActions.setViewEventLoader(false));
        }
        initialLoad()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        setEventOptions([{ label: "All", value: 0 }, ...eventState.recordEvents.eventTypes]);
    }, [eventState.recordEvents]);

    const onSubmit = async (data) => {
        await dispatch(eventManagementActions.setViewEventLoader(true));
        let params = {
            employeeId: userReducerState().UserID,
        }
        if (data.period.value !== periodOptionsWithoutPayroll[0].value) {
            params = { ...params, fromdate: exportDateFormat(data.fromDate, true), toDate: exportDateFormat(data.toDate, true) };
        }
        if (data.eventType.value !== 0) {
            params = { ...params, eventTypeId: data.eventType.eventTypeId };
        }
        if (data.searchBy.value !== searchEventOptions[0].value) {
            params = { ...params, eventKeyword: data.searchBy.label, keyword: data.keyword }
        }
        await dispatch(eventManagementActions.setTabularViewFilterParams(params));
        await dispatch(eventManagementRequests.viewEvents.getTabularView(params));
        dispatch(eventManagementActions.setViewEventLoader(false));
    }

    const onPeriodChange = (value) => {
        setValue(strings.leaveRequestQueue.period, value);
        periodDateFormat(value, setValue);
    }

    const dateFormatChange = (date) => {
        let fromDate = "", toDate = "";
        if (calendarViewState.view === Views.DAY) {
            fromDate = moment(date);
            toDate = moment(date);
        }
        else if (calendarViewState.view === Views.WEEK) {
            fromDate = moment(date).startOf("week");
            toDate = moment(date).endOf("week");
        }
        else if (calendarViewState.view === Views.MONTH) {
            fromDate = moment(date).startOf("month");
            toDate = moment(date).endOf("month");
        }
        else if (calendarViewState.view === year) {
            fromDate = moment(date).startOf("year");
            toDate = moment(date).endOf("year");
        }
        return { fromDate, toDate };
    }

    const getValidData = async (fromDate, toDate) => {
        const selectedYears = getNumberOfYears(fromDate, toDate);
        const existingYears = eventManagementReducerState().calendarView.selectedYears;
        const isAvailable = [...new Set([...existingYears, ...selectedYears])].length === existingYears.length;
        if (isAvailable) {
            const existingData = eventManagementReducerState().calendarView.data;
            const fromDateFormatted = new Date(moment(fromDate).set({ hour: 0, minute: 0, second: 0 }));
            const toDateFormatted = new Date(moment(toDate).set({ hours: 23, minutes: 59, seconds: 59 }));
            const filteredData = existingData.filter(val => {
                const startTime = new Date(val.eventStartDate);
                const endTime = new Date(val.eventEndDate);
                return (startTime >= fromDateFormatted && startTime <= toDateFormatted) || (endTime >= fromDateFormatted && endTime <= toDateFormatted);
            });

            await dispatch(eventManagementActions.setTabularViewData(filteredData));
        }
        return isAvailable;
    }

    const onReset = async () => {
        await dispatch(eventManagementActions.setViewEventLoader(true));

        reset();
        const customDate = dateFormatChange(calendarViewState.date);
        await setValue(strings.viewEventTabularView.period, periodOptionsWithoutPayroll[1]);
        await setValue(strings.viewEventTabularView.fromDate, customDate.fromDate);
        await setValue(strings.viewEventTabularView.toDate, customDate.toDate);

        if (Object.keys(eventState.selectedRecord).length > 0) {
            await onSubmit(getValues());
        }
        else {
            await getValidData(customDate.fromDate, customDate.toDate);
        }

        dispatch(eventManagementActions.setTabularViewFilterParams({
            employeeId: userReducerState().UserID,
            fromdate: exportDateFormat(customDate.fromDate, true),
            toDate: exportDateFormat(customDate.toDate, true)
        }));

        dispatch(eventManagementActions.setViewEventLoader(false));
    }

    const onChangeEvent = (data) => {
        setValue(strings.viewEventTabularView.eventType, data);
        if (data.value) {
            setValue(strings.viewEventTabularView.searchBy, searchEventOptions[0]);
            setValue(strings.viewEventTabularView.keyword, "");
        }
    }

    const onChangeSearchEvent = (data) => {
        setValue(strings.viewEventTabularView.searchBy, data);
        if (!data.value) {
            setValue(strings.viewEventTabularView.keyword, "");
        } else {
            setValue(strings.viewEventTabularView.eventType, { label: "All", value: 0 });
        }
    }

    return (
        <div className='h-auto md:max-h-h_body_md sm:max-h-full overflow-auto'>
            <div className='overflow-hidden px-6 bg-white relative'>
                <div className=' mb-6 md:mb-6 xsm:mb-4 ' >
                    <div className='grid xl:grid-rows-1 lg:grid-rows-2 md:grid-rows-2 sm:grid-rows-3 xsm:grid-rows-3 gap-x-4 gap-y-1 xl:grid-cols-4 lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 xsm:grid-cols-1 w-full'>
                        <Dropdown placeholder={"Period"} options={periodOptionsWithoutPayroll} value={watch(strings.viewEventTabularView.period)} onChange={e => onPeriodChange(e)} isLabelView={true} />
                        <DatePickerElement placeholder='From' disabled={watch(strings.viewEventTabularView.period).label !== strings.filterPeriod.custom} value={watch(strings.viewEventTabularView.fromDate)} onChange={date => setValue(strings.viewEventTabularView.fromDate, date)} isRequired={true} isLabelView={true} />
                        <DatePickerElement placeholder='To' disabled={watch(strings.viewEventTabularView.period).label !== strings.filterPeriod.custom} value={watch(strings.viewEventTabularView.toDate)} onChange={date => setValue(strings.viewEventTabularView.toDate, date)} minDate={watch(strings.viewEventTabularView.period).label === strings.filterPeriod.custom && watch(strings.viewEventTabularView.fromDate)} isRequired={true} isLabelView={true} />
                        <Dropdown placeholder={"Event Type"} options={eventOptions} value={watch(strings.viewEventTabularView.eventType)} onChange={data => onChangeEvent(data)} isLabelView={true} isRequired={true} />
                        <Dropdown placeholder={"Search By"} options={searchEventOptions} value={watch(strings.viewEventTabularView.searchBy)} onChange={data => onChangeSearchEvent(data)} isLabelView={true} isRequired={true} isDisable={watch(strings.viewEventTabularView.eventType) ? !!watch(strings.viewEventTabularView.eventType).value : false} />
                        <div><div><TextField value={watch(strings.viewEventTabularView.keyword)} placeholder="Keyword" type="text" onChange={(e) => setValue(strings.viewEventTabularView.keyword, e.target.value)} isLabelView={true} isDisable={(watch(strings.viewEventTabularView.eventType)?.value) || (watch(strings.viewEventTabularView.searchBy) && !watch(strings.viewEventTabularView.searchBy).value)} /></div></div>
                        <div className='xsm:col-span-full lg:col-span-1 flex justify-center self-end'>
                            <Button value={strings.Buttons.Search} onClick={handleSubmit(onSubmit)} disabled={watch(strings.viewEventTabularView.searchBy)?.value ? !watch(strings.viewEventTabularView.keyword) : false} />
                            <span className=' mx-3'> <Button value={strings.Buttons.Reset} onClick={() => onReset()} /></span>
                        </div>
                    </div>
                </div>
                <div>
                    <AgGrid data={eventState.tabularView.data} columns={eventManagement.EventRecordsTableView.column(loginResponseState.isMobileCompatible)} ContextMenuItems={loginResponseState.isMobileCompatible ? false : eventManagement.EventRecordsTableView.contextMenuItems} history={history} height={`h-[calc(94vh-67px-67px-1.5rem-3.5rem-2rem-0.6rem)] lg:h-[calc(94vh-67px-67px-1.5rem-3.5rem-2rem-0.6rem)] md:h-[calc(94vh-67px-67px-67px-1.5rem-3.5rem-2rem-0.6rem)] xsm:h-[62vh]`} />
                </div>
            </div>

        </div>
    );
};

export default ViewEventTabularView;

const initialStates = {
    period: "",
    fromDate: "",
    toDate: "",
    searchBy: searchEventOptions[0],
    keyword: "",
    eventType: { label: "All", value: 0 },
}


