import PropTypes from 'prop-types';
import { Accordion, AccordionDetails, AccordionSummary } from '@mui/material'
import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { routerPath, setDefaultValue, strings } from '../../Constants'
import Label from '../../elements/Label'
import TextField from '../../elements/TextField'
import CheckBox from '../../elements/CheckBox'
import Dropdown from '../../elements/Dropdown'
import { HiChevronUp } from "react-icons/hi";
import { employeeRequests, eventManagementRequests } from '../../requests'
import { useDispatch, useSelector } from 'react-redux'
import { eventManagementActions } from '../../../redux/eventManagementReducer'
import TransparentLoader from '../../loader/TransparentLoader'
import { employeeReducerState, eventManagementReducerState, exportDateFormat, findAllChildCheckedParent, findCheckedKeys, findCheckedValues, findParents, getChildKeys, recordEventsDuration, treeDataFormation, userReducerState } from '../../helper'
import { BiSearch } from "react-icons/bi";
import ApiResponse from '../../Alert/ApiResponse'
import SubHeaderSection from '../../layouts/SubHeaderSection'
import UploadAndDeleteDocument from '../../elements/UploadAndDeleteDocument'
import TextArea from '../../elements/TextArea'
import ImageViewer from '../../ViewDocs/ImageViewer'
import AutoSizeButton from '../../elements/AutoSizeButton'
import CheckboxTree from '../../elements/customCheckbox'
import DateTimePickerElement from '../../elements/DateTimePickerElement'
import dayjs from 'dayjs';
import { useHistory } from 'react-router-dom';

function RecordEvents({ isFullView }) {

  const dispatch = useDispatch();
  const history = useHistory();
  const { loader } = useSelector(state => state.eventManagement);
  const { eventTypes, participationLevel, participants, presenters, recordEventPopup } = useSelector(state => state.eventManagement.recordEvents);
  const { filterParams } = useSelector(state => state.eventManagement.tabularView);
  const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
  const { UserID } = useSelector(state => state.user);
  const employeeState = useSelector(state => state.employee);
  const loginResponseState = useSelector(state => state.loginResponse);
  const { setValue, watch, getValues, handleSubmit } = useForm({ defaultValues: initialState });
  const [expanded, setExpanded] = useState(true);
  const [searchPresenters, setSearchPresenters] = useState("");
  const [searchParticipant, setSearchParticipant] = useState("");

  useEffect(() => {
    const initialLoad = async () => {
      await dispatch(eventManagementActions.setLoader(true))
      await Promise.all([
        dispatch(eventManagementRequests.recordEvents.getAllEventsTypes()),
        dispatch(eventManagementRequests.recordEvents.getAllParticipationLevel()),
        dispatch(eventManagementRequests.recordEvents.getEventEmployeeName(participationStaffTree)),
        employeeState.location.length <= 0 && dispatch(employeeRequests.location())
      ])
      await reset();
      dispatch(eventManagementActions.setLoader(false))
    }
    initialLoad();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const reset = async () => {
    await dispatch(eventManagementActions.setLoader(true))
    let particiPationLevelState = eventManagementReducerState().recordEvents.participationLevel;
    let eventTypestate = eventManagementReducerState().recordEvents.eventTypes;
    await setSearchParticipant("");
    await setSearchPresenters("");
    await setValue(strings.recordEvents.presenter, particiPationLevelState && particiPationLevelState.length > 0 ? particiPationLevelState.find(val => val.value === setDefaultValue.presenterType.value) : []);
    if (recordEventPopup.type === "Edit" || recordEventPopup.type === "View") {
      let editedData = recordEventPopup && Object.hasOwn(recordEventPopup, "data") && recordEventPopup.data;
      // presenters edited data
      let presentersValue = editedData.attendeeDetailsDTO && editedData.attendeeDetailsDTO.length > 0 ? editedData.attendeeDetailsDTO.filter(val => val.participationLevelID === 1 || val.participationLevelID === 2) : [];
      let presenterCheckedKeys = presentersValue && presentersValue.length > 0 && eventManagementReducerState().recordEvents.presenters.treeData.length > 0 ? await findCheckedKeys(eventManagementReducerState().recordEvents.presenters.treeData, presentersValue) : [];
      let presenterParentkeys = eventManagementReducerState().recordEvents.presenters.treeData.length > 0 && await findParents(eventManagementReducerState().recordEvents.presenters.treeData, presenterCheckedKeys);
      let presenterAllChildCheckedParent = eventManagementReducerState().recordEvents.presenters.treeData.length > 0 && await findAllChildCheckedParent(eventManagementReducerState().recordEvents.presenters.treeData, presenterParentkeys, presenterCheckedKeys);
      // participant edited data
      let participantValue = editedData.attendeeDetailsDTO && editedData.attendeeDetailsDTO.length > 0 ? editedData.attendeeDetailsDTO.filter(val => val.participationLevelID === 3) : [];
      let participantCheckedKeys = participantValue && participantValue.length > 0 && eventManagementReducerState().recordEvents.participants.treeData.length > 0 ? await findCheckedKeys(eventManagementReducerState().recordEvents.participants.treeData, participantValue) : [];
      let participantParentKeys = eventManagementReducerState().recordEvents.participants.treeData.length > 0 && await findParents(eventManagementReducerState().recordEvents.participants.treeData, participantCheckedKeys);
      let participantAllChildCheckedParent = eventManagementReducerState().recordEvents.participants.treeData.length > 0 && await findAllChildCheckedParent(eventManagementReducerState().recordEvents.participants.treeData, participantParentKeys, participantCheckedKeys);

      await setValue(strings.recordEvents.startDate, editedData.eventStartDate && dayjs(editedData.eventStartDate));
      await setValue(strings.recordEvents.endDate, editedData.eventEndDate && dayjs(editedData.eventEndDate));
      await setValue(strings.recordEvents.isContinuousEducation, !!(editedData.isPartOfContinuousEducation && editedData.isPartOfContinuousEducation === 'Y'));
      await setValue(strings.recordEvents.type, editedData?.eventTypeID && eventTypestate?.length > 0 ? eventTypestate.find(val => val.value === editedData.eventTypeID) : "");
      await setValue(strings.recordEvents.typeDetails, (editedData.eventTypeDetailID && editedData.eventTypeDetailID !== 0 && await isvaldisPresentTypeDetails(watch(strings.recordEvents.type)) && isValidEventTypeDetails(watch(strings.recordEvents.type)).length > 0 ? await isValidEventTypeDetails(watch(strings.recordEvents.type)).find((val) => val.value === editedData.eventTypeDetailID) : ''));
      await setValue(strings.recordEvents.topic, editedData.eventTopic ? editedData.eventTopic : "");
      await setValue(strings.recordEvents.description, editedData.eventDescription ? editedData.eventDescription : "");
      await setValue(strings.recordEvents.duration, editedData.durationMin ? editedData.durationMin : "");
      await setValue(strings.recordEvents.updloadDocument, (editedData.fileImageBinary && editedData.fileName && editedData.fileImageBinary.length > 0 && editedData.fileName.length > 0) ? [{ 'binary': editedData.fileImageBinary, "name": editedData.fileName }] : [])
      await setValue(strings.recordEvents.guest, editedData.guestName ? editedData.guestName : "");
      await setValue(strings.recordEvents.externalPresenters, editedData.externalUsersDTO && editedData.externalUsersDTO.length > 0 ? editedData.externalUsersDTO.map(val => val.externalUserName).join("\n") : "");
      await dispatch(eventManagementActions.setPresenters({ checkedKeys: [...presenterCheckedKeys, ...presenterAllChildCheckedParent], expandedKeys: presenterParentkeys, presentedValue: presentersValue }));
      await dispatch(eventManagementActions.setparticipants({ checkedKeys: [...participantCheckedKeys, ...participantAllChildCheckedParent], expandedKeys: participantParentKeys, presentedValue: participantValue }));
      await setValue(strings.recordEvents.periodDuration, editedData.duration && editedData.duration.length > 0 && recordEventsDuration.find(val => val.label === editedData.duration));
      await setValue(strings.recordEvents.location, editedData.eventLocationId && employeeReducerState().location.find(val => val.value === editedData.eventLocationId));
    } else {
      await setValue(strings.recordEvents.startDate, "");
      await setValue(strings.recordEvents.endDate, "");
      await setValue(strings.recordEvents.isContinuousEducation, false);
      await setValue(strings.recordEvents.type, eventTypestate && eventTypestate.length > 0 ? eventTypestate.find(val => val.value === setDefaultValue.recordEventType.value) : []);
      await setValue(strings.recordEvents.typeDetails, isvaldisPresentTypeDetails(watch(strings.recordEvents.type)) && isValidEventTypeDetails(watch(strings.recordEvents.type)).length > 0 && isValidEventTypeDetails(watch(strings.recordEvents.type))[0]);
      await setValue(strings.recordEvents.topic, "");
      await setValue(strings.recordEvents.description, "");
      await setValue(strings.recordEvents.duration, "");
      await setValue(strings.recordEvents.updloadDocument, []);
      await setValue(strings.recordEvents.guest, "");
      await setValue(strings.recordEvents.externalPresenters, "");
      await setValue(strings.recordEvents.periodDuration, recordEventsDuration[0]);
      await setValue(strings.recordEvents.location, employeeReducerState().location.find(val => val.value === userReducerState().LocationID));
      await dispatch(eventManagementActions.setparticipants({ checkedKeys: [], expandedKeys: [] }));
      await dispatch(eventManagementActions.setPresenters({ checkedKeys: [], expandedKeys: [] }));
    }
    dispatch(eventManagementActions.setLoader(false))
  }
  const handleDisable = () => {
    let values = getValues();
    let watchedValues = [values[strings.recordEvents.periodDuration], values[strings.recordEvents.location], values[strings.recordEvents.startDate], values[strings.recordEvents.endDate], values[strings.recordEvents.type], values[strings.recordEvents.updloadDocument]];
    return !!(watchedValues.some(value => value === "" || value === null || value === undefined) || (values[strings.recordEvents.type] && Object.hasOwn(values[strings.recordEvents.type], "isPresentTypeDetails") && values[strings.recordEvents.type].isPresentTypeDetails === true ? (values[strings.recordEvents.typeDetails] && values[strings.recordEvents.typeDetails] === '') : false))
    // || ((presenters.checkedKeys && presenters.checkedKeys.length <= 0) && (values[strings.recordEvents.externalPresenters] === "" || values[strings.recordEvents.externalPresenters] === undefined || values[strings.recordEvents.externalPresenters] === null))
    // || (participants.checkedKeys && participants.checkedKeys.length <= 0)

  }
  const onSubmit = async (data) => {
    await dispatch(eventManagementActions.setLoader(true));
    let editedData = recordEventPopup && Object.hasOwn(recordEventPopup, "data") && recordEventPopup.data;
    let payload = {
      attendeeDetailsList: [...await findCheckedValues(presenters.treeData, presenters.checkedKeys, participationLevel && participationLevel.length > 0 && participationLevel.find(val => val.value === setDefaultValue.presenterType.value).value, presenters.presentedValue), ...await findCheckedValues(participants.treeData, participants.checkedKeys, participationLevel && participationLevel.length > 0 && participationLevel.find(val => val.value === setDefaultValue.participantType.value).value, participants.presentedValue)],
      departmentID: 0,
      durationMin: (data.endDate && data.startDate) ? Math.trunc(data.endDate.diff(data.startDate, "minutes", true)) : 0,
      eventDescription: data.description,
      eventStartDate: await exportDateFormat(new Date(data.startDate)),
      eventEndDate: await exportDateFormat(new Date(data.endDate)),
      eventTopic: data.topic,
      eventTypeDetailID: (data.typeDetails && Object.keys(data.typeDetails).length > 0) ? data.typeDetails.eventTypeDetailId : 0,
      eventTypeID: data?.type?.eventTypeId,
      fileImageBinary: (data.updloadDocument && data.updloadDocument.length > 0) ? data.updloadDocument[0].binary : "",
      fileName: (data.updloadDocument && data.updloadDocument.length > 0) ? data.updloadDocument[0].name : "",
      guestName: data.guest,
      isPartOfContinuousEducation: data.isContinuousEducation ? "Y" : "N",
      modifiedBy: UserID,
      modifiedOn: exportDateFormat(new Date()),
      duration: data.periodDuration && Object.keys(data.periodDuration).length > 0 && Object.hasOwn(data.periodDuration, "label") && data.periodDuration.label,
      eventLocationId: data.location && Object.keys(data.location).length > 0 && Object.hasOwn(data.location, "value") && data.location.value,
    }
    if (recordEventPopup.type === "Edit" || recordEventPopup.type === "View") {
      let externalDTO = []
      let currentExternalDto = (data.externalPresenters && data.externalPresenters.length > 0) && data.externalPresenters.split(/[\n,]+/).map((val) => ({ eventId: 0, externalUserID: 0, externalUserName: val.trim() }));
      if ((editedData.externalUsersDTO.length === currentExternalDto.length) || (editedData.externalUsersDTO.length > currentExternalDto.length)) {
        for (let i = 0; i < currentExternalDto.length; i++) {
          externalDTO = [...externalDTO, { eventId: editedData.externalUsersDTO[i].eventId, externalUserID: editedData.externalUsersDTO[i].externalUserID, externalUserName: currentExternalDto[i].externalUserName }]
        }
      }
      else if (editedData.externalUsersDTO.length < currentExternalDto.length) {
        for (let i = 0; i < editedData.externalUsersDTO.length; i++) {
          externalDTO = [...externalDTO, { eventId: editedData.externalUsersDTO[i].eventId, externalUserID: editedData.externalUsersDTO[i].externalUserID, externalUserName: currentExternalDto[i].externalUserName }]
        }
        for (let i = editedData.externalUsersDTO.length; i < currentExternalDto.length; i++) {
          externalDTO = [...externalDTO, { eventId: 0, externalUserID: 0, externalUserName: currentExternalDto[i].externalUserName }]
        }
      }
      payload = { ...payload, eventID: editedData.eventId, externalUsersDTO: externalDTO && externalDTO.length > 0 ? externalDTO : [] }
      await dispatch(eventManagementRequests.recordEvents.editEvent(editedData.eventId, payload, editCallBack))
    }
    else {
      payload = { ...payload, eventID: 0, externalUsersDTO: (data.externalPresenters && data.externalPresenters.length > 0) ? data.externalPresenters.split(/[\n,]+/).map((val) => ({ eventId: 0, externalUserID: 0, externalUserName: val.trim() })) : [], }
      await dispatch(eventManagementRequests.recordEvents.saveEvents(payload, setCallBack))
    }
    await dispatch(eventManagementActions.setLoader(false))
  }
  const onCheck = async (checkedKeysValue) => {
    await dispatch(eventManagementActions.setparticipants({ checkedKeys: checkedKeysValue }))
  };
  const onPresenterCheck = async (checkedKeysValue) => {
    await dispatch(eventManagementActions.setPresenters({ checkedKeys: checkedKeysValue }))
  };
  const setCallBack = async (isValid) => {
    if (isValid) { await reset(); }
  }
  const participationStaffTree = async (treeData) => {
    const treeStructure = async (usIndex, indIndex) => {
      return [{
        key: usIndex,
        title: 'USA',
        children: Object.hasOwn(treeData[0], "departments") && treeData[0].departments.length && await treeDataFormation(treeData[0], usIndex)
      },
      {
        key: indIndex,
        title: 'INDIA',
        children: Object.hasOwn(treeData[1], "departments") && treeData[1].departments.length && await treeDataFormation(treeData[1], indIndex)
      }];
    }
    await dispatch(eventManagementActions.setPresenters({ treeData: await treeStructure(0, 1) }));
    await dispatch(eventManagementActions.setparticipants({ treeData: await treeStructure(2, 3) }));
  }
  useEffect(() => {
    let keysToExpand = [];
    const collectKeys = (nodes, searchValue, treeData) => {
      nodes.forEach((node) => {
        if (node.title.toLowerCase().includes(searchValue.toLowerCase())) {
          if (!node.children) {
            keysToExpand.push(node.key);
            const parentKey = findParents(treeData, [node.key])
            if (parentKey && parentKey.length > 0) {
              const removeDuplicates = [...new Set(parentKey)];
              keysToExpand = [...keysToExpand, ...removeDuplicates];
            }
          }
        }
        if (node.children) {
          collectKeys(node.children, searchValue, treeData);
        }
      });
      return keysToExpand
    };
    if (searchPresenters) {
      let keys = collectKeys(presenters.treeData && presenters.treeData.length > 0 ? presenters.treeData : [], (searchPresenters && searchPresenters.length > 0) ? searchPresenters : "", presenters.treeData && presenters.treeData.length > 0 ? presenters.treeData : []);
      dispatch(eventManagementActions.setPresenters({ expandedKeys: keys, autoExpandParent: true, searchExpandedKeys: keys }));
      keysToExpand = []
    }
    else {
      dispatch(eventManagementActions.setPresenters({ expandedKeys: [], autoExpandParent: false, searchExpandedKeys: [] }));
    }
    if (searchParticipant) {
      let keys = collectKeys(participants.treeData && participants.treeData.length > 0 ? participants.treeData : [], (searchParticipant && searchParticipant.length > 0) ? searchParticipant : '', participants.treeData && participants.treeData.length > 0 ? participants.treeData : []);
      dispatch(eventManagementActions.setparticipants({ expandedKeys: keys, autoExpandParent: true, searchExpandedKeys: keys }));
      keysToExpand = []
    }
    else {
      dispatch(eventManagementActions.setparticipants({ expandedKeys: [], autoExpandParent: false, searchExpandedKeys: [] }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchPresenters, searchParticipant]);
  const filterTreeNode = (node) => {
    if (searchPresenters && searchPresenters.length > 0 && node && node.title.props.children.toLocaleLowerCase().indexOf(searchPresenters.toLocaleLowerCase()) > -1) { return true; }
    return !!(searchParticipant && searchParticipant.length > 0 && node && node.title.props.children.toLocaleLowerCase().indexOf(searchParticipant.toLocaleLowerCase()) > -1);
  };
  const onExpandPresenters = (newExpandedKeys) => {
    dispatch(eventManagementActions.setPresenters({ expandedKeys: newExpandedKeys, autoExpandParent: false }));
  }
  const onExpandParticipants = (newExpandedKeys) => {
    dispatch(eventManagementActions.setparticipants({ expandedKeys: newExpandedKeys, autoExpandParent: false }));
  }
  const editCallBack = async (isValid) => {
    if (isValid) {
      await dispatch(eventManagementActions.setSelectedRecord(recordEventPopup.selectedRow))
      await dispatch(eventManagementActions.setRecordEventPopup({ show: false, data: [], selectedRow: {} }));
      await dispatch(eventManagementRequests.viewEvents.getTabularView(filterParams));
    }
  }
  const handlePresenterTitle = async (key) => {
    let newCheckedKeys = [];
    const childKeys = await getChildKeys(presenters.treeData, key);
    if (presenters.checkedKeys.includes(key)) {
      let parentKey = await findParents(presenters.treeData, [key]);
      newCheckedKeys = presenters.checkedKeys.filter(item => item !== key && !childKeys.includes(item) && !parentKey.includes(item));
    } else {
      let parentKey = await findParents(presenters.treeData, [key]);
      let CheckedKeys = [...presenters.checkedKeys, key, ...childKeys];
      newCheckedKeys = [...CheckedKeys, ...await findAllChildCheckedParent(presenters.treeData, parentKey, CheckedKeys)]
    }
    await dispatch(eventManagementActions.setPresenters({ checkedKeys: newCheckedKeys }));
  };
  const handleParticipantTitle = async (key) => {
    let newCheckedKeys = [];
    const childKeys = await getChildKeys(participants.treeData, key);
    if (participants.checkedKeys.includes(key)) {
      let parentKey = await findParents(participants.treeData, [key]);
      newCheckedKeys = participants.checkedKeys.filter(item => item !== key && !childKeys.includes(item) && !parentKey.includes(item));
    } else {
      let parentKey = await findParents(participants.treeData, [key]);
      let CheckedKeys = [...participants.checkedKeys, key, ...childKeys];
      newCheckedKeys = [...CheckedKeys, ...await findAllChildCheckedParent(participants.treeData, parentKey, CheckedKeys)]
    }
    await dispatch(eventManagementActions.setparticipants({ checkedKeys: newCheckedKeys }))
  };
  const handleTypeChange = async (type) => {
    await setValue(strings.recordEvents.type, type);
    await setValue(strings.recordEvents.typeDetails, (isValidEventTypeDetails(watch(strings.recordEvents.type)) && isValidEventTypeDetails(watch(strings.recordEvents.type)).length > 0) ? isValidEventTypeDetails(watch(strings.recordEvents.type))[0] : []);
    (type.eventTypeId === 1 && watch(strings.recordEvents.isContinuousEducation) === false) && await setValue(strings.recordEvents.isContinuousEducation, true);
    (type.eventTypeId === 1 && watch(strings.recordEvents.topic) === "") && await setValue(strings.recordEvents.topic, strings.recordEvents.workDiscussionTopic)
  }
  return (
    <>
      <div className={(recordEventPopup.type === "Edit" || recordEventPopup.type === "View") ? 'sm:w-[calc(100vw-1.5rem)] h-[calc(100vh-60px)] overflow-y-auto xsm:w-screen px-4 pt-4' : `overflow-hidden `}>
        {(recordEventPopup.type === "Edit" || recordEventPopup.type === "View") || <SubHeaderSection subHeader="Record Events" addtextStyle=" ml-3" headerBorder={false} />}
        <Accordion className='!m-0  !shadow-none !rounded-none' expanded={expanded} onChange={() => setExpanded(!expanded)}>
          <AccordionSummary aria-controls="panel1a-content" id="panel1a-header" expandIcon={<HiChevronUp style={{ fontSize: "28px" }} />} className={`${isFullView ? " !border-2 !rounded-sm " : " !border-y-2"} !border-solid !border-borderThemeColor !bg-themeBgColor !text-darkDarkGrey !font-fontfamily font-bold !h-[3.1rem] !max-h-[3.1rem] !min-h-[3.1rem]`}>Event Details</AccordionSummary>
          <AccordionDetails className=' mt-1 mb-2'>
            <fieldset disabled={recordEventPopup.type === "View"}>
              <div className='grid grid-cols-12 gap-x-5 gap-y-2 lg:gap-y-3 xl:gap-x-3'>
                <div className={labelStyleLeft}><Label label="Duration" required={true} /> <span className=' hidden sm:block' >:</span></div>
                <div className={textFieldLeft}> <Dropdown isRequired={true} options={recordEventsDuration} value={watch(strings.recordEvents.periodDuration)} onChange={duration => setValue(strings.recordEvents.periodDuration, duration)} isViewable={!!(recordEventPopup.type === "View")} /></div>
                <div className={labelStyleRight}><Label label="Location" required={true} /> <span className=' hidden sm:block' >:</span></div>
                <div className={textFieldRight}> <Dropdown isRequired={true} options={employeeState && Object.hasOwn(employeeState, "location") ? employeeState.location.slice(1) : []} value={watch(strings.recordEvents.location)} onChange={location => setValue(strings.recordEvents.location, location)} isViewable={!!(recordEventPopup.type === "View")} /></div>
                <div className={labelStyleLeft}><Label label="Start Date" required={true} /> <span className=' hidden sm:block'>:</span> </div>
                <div className={textFieldLeft}> <DateTimePickerElement isRequired={true} value={watch(strings.recordEvents.startDate)} onChange={date => setValue(strings.recordEvents.startDate, date)} maxDate={watch(strings.recordEvents.endDate)} isViewable={!!(recordEventPopup.type === "View")} /> </div>
                <div className={labelStyleRight}><Label label="End Date" required={true} /> <span className=' hidden sm:block'>:</span> </div>
                <div className={textFieldRight}><DateTimePickerElement isRequired={true} value={watch(strings.recordEvents.endDate)} onChange={date => setValue(strings.recordEvents.endDate, date)} minDate={watch(strings.recordEvents.startDate)} isViewable={!!(recordEventPopup.type === "View")} /> </div>
                <div className={labelStyleLeft}><Label label="Type" required={true} /> <span className=' hidden sm:block'>:</span></div>
                <div className={textFieldLeft}> <Dropdown isRequired={true} options={eventTypes || []} value={watch(strings.recordEvents.type)} onChange={type => handleTypeChange(type)} isViewable={!!(recordEventPopup.type === "View")} /> </div>
                <div className={labelStyleRight}><Label label="Type Details" required={isvaldisPresentTypeDetails(watch(strings.recordEvents.type))} /> <span className=' hidden sm:block'>:</span></div>
                <div className={textFieldRight}> <Dropdown isRequired={true} options={isvaldisPresentTypeDetails(watch(strings.recordEvents.type)) ? isValidEventTypeDetails(watch(strings.recordEvents.type)) : []} value={watch(strings.recordEvents.typeDetails)} onChange={type => setValue(strings.recordEvents.typeDetails, type)} isDisable={!isvaldisPresentTypeDetails(watch(strings.recordEvents.type))} isViewable={!!(recordEventPopup.type === "View")} /> </div>
                <div className={labelStyleLeft}><Label label="Topic" /> <span className=' hidden sm:block'>:</span></div>
                <div className={textFieldLeft}> <TextField value={watch(strings.recordEvents.topic)} onChange={e => setValue(strings.recordEvents.topic, e.target.value)} /></div>
                <div className='col-start-1 col-end-13 sm:col-end-12 lg:col-start-7 xl:col-start-7 lg:col-end-13 xl:col-end-12'> <CheckBox data={[{ label: "Is part of continous education?" }]} value={watch(strings.recordEvents.isContinuousEducation)} onChange={e => setValue(strings.recordEvents.isContinuousEducation, e.target.checked)} /> </div>
                <div className={`${labelStyleLeft} row-span-2`}><Label label="Description" /><span className=' hidden sm:block'>:</span> </div>
                <div className={`${textFieldLeft} row-span-2`}> <TextArea value={watch(strings.recordEvents.description)} onChange={e => setValue(strings.recordEvents.description, e.target.value)} height={` !h-full`} /></div>
                <div className={labelStyleRight}><Label label="Guest(s)" /><span className=' hidden sm:block'>:</span> </div>
                <div className={textFieldRight}> <TextField value={watch(strings.recordEvents.guest)} onChange={e => setValue(strings.recordEvents.guest, e.target.value)} /> </div>
                <div className={labelStyleRight}><Label label="Upload Document" /><span className=' hidden sm:block'>:</span> </div>
                <div className={textFieldRight}> <UploadAndDeleteDocument label="Browse" onChange={file => setValue(strings.recordEvents.updloadDocument, file)} file={watch(strings.recordEvents.updloadDocument)} isViewable={!!(recordEventPopup.type === "View")} /></div>
                {/* <div className={labelStyleLeft}><Label label="Duration(inMins)" required={true} /><span className=' hidden sm:block'>:</span></div>
              <div className='col-start-1 col-end-10 sm:col-start-5 sm:col-end-9 lg:col-start-4 xl:col-start-3 lg:col-end-7 xl:col-end-6 '> <TextField value={watch(strings.recordEvents.duration)} onChange={e => setValue(strings.recordEvents.duration, e.target.value)} type={'number'} isDisable={true} /> </div> */}
              </div>
            </fieldset>
          </AccordionDetails>
        </Accordion>
        <div className='flex justify-center items-center flex-wrap'>
          <div className='w-full md:w-1/2'>
            <div className='grid grid-cols-12 bg-darkDarkGrey px-4 py-1'>
              <span className='col-start-1 col-end-13 lg:col-end-7 xl:col-end-5 flex items-center font-bold text-white'>Participation Level</span>
              <div className='col-start-1 col-end-13 md:col-end-9 lg:col-start-7 lg:col-end-12 xl:col-start-5 xl:col-end-9 darktheme-select'> <Dropdown options={participationLevel && participationLevel.length > 0 ? participationLevel.filter(val => val.isPresenter === "true") : []} value={watch(strings.recordEvents.presenter)} onChange={type => setValue(strings.recordEvents.presenter, type)} /></div>
            </div>
            <div className="sticky top-0 z-[1] max-h-[42px] h-[42px] w-full md:border-r-1 border-coolGray-900 participant_search rounded-none">
              {(watch(strings.recordEvents.presenter) && Object.hasOwn(watch(strings.recordEvents.presenter), "id") && watch(strings.recordEvents.presenter).id === 2) || <><TextField value={searchPresenters} placeholder="search" type="text" onChange={(e) => setSearchPresenters(e.target.value)} /> <BiSearch className=' absolute right-3 top-4' /></>}
              {watch(strings.recordEvents.presenter) && Object.hasOwn(watch(strings.recordEvents.presenter), "id") && watch(strings.recordEvents.presenter).id === 2 && <div className=' bg-gray-200 text-gray-900 py-2 px-4 font-bold font-fontfamily text-[15px] h-[42px]'>External Presenter</div>}
            </div>
            <div className={`flex flex-wrap md:border-r-1 border-b-1 overflow-auto border-coolGray-900  md:min-h-[90px] min-h-[140px] p-3 ${(recordEventPopup.type === "Edit" || recordEventPopup.type === "View") ? "md:h-[calc(100vh-18.2rem)]" : "md:h-[calc(100vh-21.6rem)]"} transition-[0.3s] ${expanded ? ((recordEventPopup.type === "Edit" || recordEventPopup.type === "View") ? 'md:h-[calc(100vh-39.7rem)]' : "md:h-[calc(100vh-43rem)]") : ((recordEventPopup.type === "Edit" || recordEventPopup.type === "View") ? 'md:h-[calc(100vh-18.3rem)] delay-[230ms]' : "md:h-[calc(100vh-21.6rem)] delay-[230ms] ")}`}>
              {(watch(strings.recordEvents.presenter) && Object.hasOwn(watch(strings.recordEvents.presenter), "id") && watch(strings.recordEvents.presenter).id === 2) || (presenters.treeData && presenters.treeData.length > 0 ? <div className={searchPresenters ? 'checkboxSearch' : ''}> <CheckboxTree onCheck={onPresenterCheck} searchValue={searchPresenters} treeData={presenters.treeData} checkedKeys={presenters.checkedKeys} expandedKeys={presenters.expandedKeys} autoExpandParent={presenters.autoExpandParent} filterTreeNode={filterTreeNode} onExpand={onExpandPresenters} handleTitle={handlePresenterTitle} searchExpandedKeys={presenters.searchExpandedKeys} isDisable={!!(recordEventPopup.type === "View")} /> </div> : <p className=' font-fontfamily font-semibold text-base w-full text-center'>No Staffs</p>)}
              {watch(strings.recordEvents.presenter) && Object.hasOwn(watch(strings.recordEvents.presenter), "id") && watch(strings.recordEvents.presenter).id === 2 && <div className='extrn_staff'><TextArea value={watch(strings.recordEvents.externalPresenters)} onChange={e => setValue(strings.recordEvents.externalPresenters, e.target.value)} isDisable={!!(recordEventPopup.type === "View")} height={` !h-full `} /></div>}
            </div>
          </div>
          <div className=' w-full md:w-1/2'>
            <div className=' bg-darkDarkGrey px-4 py-[13px] md:min-h-[4.63rem] lg:min-h-1 flex items-center'><span className='font-bold text-white text-center '>{(participationLevel && Object.keys(participationLevel).length > 0) ? participationLevel.find(val => val.id === 3).participationLevel : "Participants"}</span></div>
            <div className="sticky top-0 z-[1] max-h-[42px] h-[42px] w-full participant_search rounded-none"> <TextField value={searchParticipant} placeholder="search" type="text" onChange={(e) => setSearchParticipant(e.target.value)} /> <BiSearch className=' absolute right-3 top-4' /></div>
            <div className={`flex flex-wrap border-b-1  overflow-auto border-coolGray-900  md:min-h-[90px] min-h-[140px] p-3 ${(recordEventPopup.type === "Edit" || recordEventPopup.type === "View") ? "md:h-[calc(100vh-18.2rem)]" : "md:h-[calc(100vh-21.6rem)]"} transition-[0.3s] ${expanded ? ((recordEventPopup.type === "Edit" || recordEventPopup.type === "View") ? 'md:h-[calc(100vh-39.7rem)]' : "md:h-[calc(100vh-43rem)]") : ((recordEventPopup.type === "Edit" || recordEventPopup.type === "View") ? 'md:h-[calc(100vh-18.3rem)] delay-[230ms]' : "md:h-[calc(100vh-21.6rem)] delay-[230ms] ")}`}>
              {participants.treeData && participants.treeData.length > 0 ? <div className={searchParticipant ? 'checkboxSearch' : ''}><CheckboxTree onCheck={onCheck} searchValue={searchParticipant} treeData={participants.treeData} checkedKeys={participants.checkedKeys} expandedKeys={participants.expandedKeys} autoExpandParent={participants.expandedKeys} filterTreeNode={filterTreeNode} onExpand={onExpandParticipants} handleTitle={handleParticipantTitle} searchExpandedKeys={participants.searchExpandedKeys} isDisable={!!(recordEventPopup.type === "View")} /></div> : <p className=' font-fontfamily font-semibold text-base w-full text-center'>No Staffs</p>}
            </div>
          </div>
        </div>
        <div className={`flex justify-center items-center flex-wrap py-[17px] text-base gap-x-3 md:text-lg ${(recordEventPopup.type === "Edit" || recordEventPopup.type === "View") ? ' sticky z-10 bg-white bottom-0' : ''}`}>
          {recordEventPopup.type === "View" || <span><AutoSizeButton value={(recordEventPopup.type === "Edit" || recordEventPopup.type === "View") ? strings.Buttons.Update : strings.Buttons.Save} onClick={handleSubmit(onSubmit)} disabled={handleDisable()} /></span>}
          {<span><AutoSizeButton value={strings.Buttons.Close} onClick={(recordEventPopup.type === "View" || recordEventPopup.type === "Edit") ? (() => dispatch(eventManagementActions.setRecordEventPopup({ show: false, data: [], selectedRow: {} }))) : () => history.push(routerPath.viewEvents)} /></span>}
          {recordEventPopup.type === "View" || <span><AutoSizeButton value={strings.Buttons.Reset} onClick={() => reset()} /></span>}
        </div>
      </div>
      {loader && <TransparentLoader isFullWidth={!!isFullView} />}
      {apiResponseState.show && <ApiResponse />}
      {loginResponseState.imageViewer.show && <ImageViewer />}
    </>
  )
}

export default RecordEvents

RecordEvents.propTypes = {
  isFullView: PropTypes.bool
}

const labelStyleLeft = "col-start-1 col-end-7 sm:col-end-5 lg:col-end-4 xl:col-end-3  flex items-center justify-between ";
const textFieldLeft = "col-start-1 col-end-13 sm:col-start-5 sm:col-end-12 lg:col-start-4 xl:col-start-3 lg:col-end-7 xl:col-end-6 text-[15px] font-fontfamily";
const labelStyleRight = "col-start-1 col-end-7 sm:col-end-5 lg:col-start-7 xl:col-start-7 lg:col-end-10 xl:col-end-9  flex items-center justify-between";
const textFieldRight = "col-start-1 col-end-13 sm:col-start-5 sm:col-end-12 lg:col-start-10 xl:col-start-9 lg:col-end-13 xl:col-end-12 text-[15px] font-fontfamily";
const initialState = {
  startDate: "",
  endDate: "",
  isContinuousEducation: false,
  type: "",
  typeDetails: "",
  location: "",
  topic: "",
  description: "",
  duration: "",
  presenter: "",
  periodDuration: "",
  guest: "",
  updloadDocument: [],
  externalPresenters: "",
}

const isvaldisPresentTypeDetails = (data) => {
  return !!(data && Object.hasOwn(data, "isPresentTypeDetails") && data["isPresentTypeDetails"] === true);
}

const isValidEventTypeDetails = (data) => {
  if (data && Object.hasOwn(data, "eventTypeDetails") && data.eventTypeDetails && data.eventTypeDetails.length > 0) return data.eventTypeDetails; else return [];
}





// const findParents = (nodes, keys) => {
//   let parentMap = [];
//   const traverse = (node, parentKey) => {
//     if (node.children) {
//       node.children.forEach(child => traverse(child, node.key));
//     }
//     if (keys.includes(node.key)) {
//       if (!parentMap.includes(parentKey) && parentKey!== null) { parentMap = [...parentMap, parentKey] };
//     }
//   };
//   nodes.forEach(node => traverse(node,keys));
//   return parentMap;
// };





