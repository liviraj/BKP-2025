import { useForm } from "react-hook-form";
import { strings } from "../../Constants";
import HeaderSection from "../../layouts/HeaderSection";
import DatePickerElement from "../../elements/DatePickerElement";
import { exportDateFormat, halfDayOptions, getLeaveDetails, holidayReducerState } from "../../helper";
import Button from "../../elements/Button";
import { useDispatch, useSelector } from "react-redux";
import TransparentLoader from "../../loader/TransparentLoader";
import ApiResponse from "../../Alert/ApiResponse";
import AddWFHRequest from "../../Popup_window/AddWFHRequest";
import { wfhActions } from "../../../redux/wfhReducer";
import Label from "../../elements/Label";
import TextArea from "../../elements/TextArea";
import { wfhRequest } from "../../requests";
import { useEffect } from "react";
import Dropdown from "../../elements/Dropdown";
import SubHeaderSection from "../../layouts/SubHeaderSection";


const WFHRequest = () => {
    const dispatch = useDispatch()
    const { watch, setValue, getValues, reset } = useForm({ defaultValues: initialValue });
    const { loader, addWFHRequest } = useSelector(state => state.wfhRequest);
    const { leaveBalance } = useSelector(state => state.wfhRequest.wfhRequest)
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const { UserID } = useSelector(state => state.user)
    useEffect(() => {
        const initialConfig = async () => {
            await dispatch(wfhActions.setLoader(true));
            await dispatch(wfhRequest.getWFHBalanceRequest(UserID));
            holidayReducerState().holidays.length <= 0 && await getLeaveDetails(new Date());
            dispatch(wfhActions.setLoader(false))
        }
        initialConfig();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    const fromDate = watch(strings.addWFHRequest.startDate);

    const handleSearch = async () => {
        await dispatch(wfhActions.setLoader(true));
        const value = getValues();
        const payload = {
            employeeId: UserID,
            enteredBy: UserID,
            enteredOn: exportDateFormat(new Date()),
            fromDate: exportDateFormat(value?.startDate, true),
            remarks: value?.reason,
            requestFromForH: value?.halfDay?.value,
            requestDate: exportDateFormat(new Date()),
            toDate: exportDateFormat(value?.startDate, true),
            requestToForH: value?.halfDay?.value
        }
        await dispatch(wfhRequest.addWFHRequest(payload, setCallBack))
        dispatch(wfhActions.setLoader(false));
    }
    const setCallBack = async (status) => {
        if (status) {
            await dispatch(wfhRequest.getWFHBalanceRequest(UserID));
            await reset();
        }
    }
    return (
        <>
            <HeaderSection redirectType={strings.type.wFHRequest} />
            <div className=" lg:flex-row flex-col-reverse flex h-auto md:h-[calc(100%-3.5rem)] justify-end">
                <div className=" px-6 overflow-hidden mb-5 w-full lg:w-2/3">
                    <div className=" hidden lg:block "> <SubHeaderSection subHeader="Work From Home Request" /></div>
                    <div className=' my-4 w-auto xsm:w-[80%]  lg:w-2/3  xl:w-1/2 grid gap-x-3 gap-y-3 md:gap-y-5'>
                        <div className={classNames.labelClass}> <Label label={"Date"} required={true} /></div>
                        <div className={classNames.dropdownClass}>  <DatePickerElement value={fromDate} onChange={date => { setValue(strings.addWFHRequest.startDate, date) }} isWeekday={true} disableHolidays={holidayReducerState().holidays} isRequired /></div>
                        <div className={classNames.labelClass}><Label label={"Full / Half Day"} required={true} /></div>
                        <div className={classNames.dropdownClass}> <Dropdown value={watch(strings.addWFHRequest.halfDay)} options={halfDayOptions} onChange={data => setValue(strings.addWFHRequest.halfDay, data)} isRequired /></div>

                    </div>
                    <Label label={"Reason"} required={true} />
                    <TextArea height={" !h-40"} isRequired value={watch(strings.addWFHRequest.reason)} onChange={e => setValue(strings.addWFHRequest.reason, e.target.value)} />
                    <div className=' justify-center flex gap-1 mt-7 mb-10'>
                        <Button value={'Apply WFH'} disabled={!(watch(strings.addWFHRequest.startDate) && watch(strings.addWFHRequest.halfDay) && watch(strings.addWFHRequest.reason))} onClick={handleSearch} />
                    </div>
                </div>
                <div className="w-full lg:w-1/3 bg-pink-50 p-7">
                    {
                        leaveBalance && leaveBalance.enteredOn && leaveBalance.lastRequestAvailedDate && leaveBalance.approvalStatus &&
                        <div className=" bg-white border-1 rounded shadow-boxShadow box-shadow border-white p-3 font-fontfamily ">
                            <h3 className=" text-center font-bold text-14px pb-3">Last WFH Availed</h3>
                            <div className={classNames.balanceWrapper}><p className={classNames.balanceLabel}>Last WFH Requested <span className=" font-bold">:</span></p><p className=" font-bold text-14px pl-2">{leaveBalance && (Object.hasOwn(leaveBalance, 'enteredOn') && leaveBalance?.enteredOn.length > 0) ? leaveBalance.enteredOn : ''}</p></div>
                            <div className={classNames.balanceWrapper}><p className={classNames.balanceLabel}>Last WFH Availed <span className=" font-bold">:</span></p><p className=" font-bold text-14px pl-2">{leaveBalance && (Object.hasOwn(leaveBalance, 'lastRequestAvailedDate') && leaveBalance?.lastRequestAvailedDate.length > 0) ? leaveBalance.lastRequestAvailedDate : ''}</p></div>
                            <div className={classNames.balanceWrapper}><p className={classNames.balanceLabel}>Approval Status <span className=" font-bold">:</span></p><p className=" font-bold text-14px pl-2">{leaveBalance && (Object.hasOwn(leaveBalance, 'approvalStatus') && leaveBalance?.approvalStatus.length > 0) ? leaveBalance.approvalStatus : ''}</p></div>
                        </div>
                    }
                </div>
            </div>
            {loader && <TransparentLoader />}
            {(!addWFHRequest.show && apiResponseState.show) && <ApiResponse />}
            {addWFHRequest.show && <AddWFHRequest isEmployeeRequest={true} />}
        </>
    );
};

export default WFHRequest;

const initialValue = {
    startDate: "",
    endDate: "",
    halfDay: "",
    reason: ''
}

const classNames = {
    labelClass: 'col-start-1 sm:col-end-3 col-end-13',
    dropdownClass: 'sm:col-start-3 col-start-1 col-end-13',
    balanceWrapper: 'text-15px justify-center lg:justify-start pb-3 flex',
    balanceLabel: 'lg:min-w-[80px] lg:w-[80px] xl:min-w-[160px] xl:w-[160px] flex justify-between',
    balanceValue: 'font-bold text-14px pl-2'
}