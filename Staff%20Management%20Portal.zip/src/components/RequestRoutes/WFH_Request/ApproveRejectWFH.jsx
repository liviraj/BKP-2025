import { useForm } from "react-hook-form";
import { setDefaultValue, strings } from "../../Constants";
import HeaderSection from "../../layouts/HeaderSection";
import Dropdown from "../../elements/Dropdown";
import DatePickerElement from "../../elements/DatePickerElement";
import Button from "../../elements/Button";
import AgGrid from "../../Grid/AgGrid";
import AddButton from "../../elements/AddButton";
import { dateFormat, exportDateFormat, leaveStatus, periodDateFormat, periodOptionsWithoutPayroll } from "../../helper";
import { wfhColumns } from "../../Grid/Columns";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useMemo } from "react";
import { employeeRequests, wfhRequest } from "../../requests";
import { wfhActions } from "../../../redux/wfhReducer";
import TransparentLoader from "../../loader/TransparentLoader";
import ApiResponse from "../../Alert/ApiResponse";
import AddWFHRequest from "../../Popup_window/AddWFHRequest";
import WFHRequestDetailsPopup from "../../Popup_window/WFHRequestDetailsPopup";
import WFHHistoryPopup from "../../Popup_window/WFHHistoryPopup";
import SubHeaderSection from "../../layouts/SubHeaderSection";

const ApproveRejectWFH = () => {

    const dispatch = useDispatch()

    const employeeState = useSelector(state => state.employee);
    const wfhRequestState = useSelector(state => state.wfhRequest);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);

    const { watch, setValue, getValues } = useForm({ defaultValues: initialValue });
    const employeeName = watch(strings.wfhApproveReject.employeeName);

    useEffect(() => {
        const initialLoad = async () => {
            dispatch(wfhActions.setLoader(true));
            await Promise.all([
                employeeState.employeeName.length <= 0 && dispatch(employeeRequests.employeeName()),
            ]);
            await onReset();
            dispatch(wfhActions.setLoader(false));
        }
        initialLoad()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const onReset = async () => {
        await Promise.all([
            periodDateFormat(periodOptionsWithoutPayroll[0], setValue),
            setValue(strings.wfhApproveReject.status, leaveStatus[4]),
            setValue(strings.wfhApproveReject.employeeName, setDefaultValue.employeeName),
        ]);
        await handleSearch();
    }

    const handleSearch = async () => {
        dispatch(wfhActions.setLoader(true));
        const data = getValues();
        const params = {
            employeeId: data.employeeName?.value,
            startDate: exportDateFormat(data.fromDate, true),
            endDate: exportDateFormat(data.toDate, true),
            status: data.status?.label
        }
        await dispatch(wfhRequest.getWFHRequestDetails(params, async (records) => {
            await dispatch(wfhActions.setApproveRejectRequestData(records));
        }));
        dispatch(wfhActions.setLoader(false));
    }

    const employeeNameOptions = useMemo(() => {
        return employeeState.employeeName.filter(val => val.locationId === 0 || (val.locationId === setDefaultValue.location.value && (val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation)));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [employeeState.employeeName]);

    const handleOpenAddWFHRequest = () => {
        dispatch(wfhActions.addWFHRequest({ show: true, type: 'Add' }));
    }

    return (
        <>
            <HeaderSection redirectType={strings.type.wFHRequest} />
            <div className=" px-6 overflow-hidden h-auto md:max-h-h_body_md sm:max-h-full ">
                <SubHeaderSection subHeader={"Approve / Reject Request"} fileProps={{ columns: wfhColumns.ApproveAndReject.columns, data: wfhRequestState.approveRejectRequest.data?.map((val, idx) => ({ ...val, sno: idx + 1, FromDate: dateFormat(val.FromDate), ToDate: dateFormat(val.ToDate) })), docName: "WFH Approve Or Reject Request" }} />
                <div className="grid lg:grid-rows-2 md:grid-rows-3 sm:grid-rows-3 gap-x-4 gap-y-1 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-3 w-full">
                    <div><Dropdown placeholder={"Period"} options={periodOptionsWithoutPayroll} value={watch(strings.wfhApproveReject.period)} onChange={data => periodDateFormat(data, setValue)} isLabelView={true} /></div>
                    <div><DatePickerElement placeholder='From' disabled={watch(strings.wfhApproveReject.period).label !== strings.filterPeriod.custom} value={watch(strings.wfhApproveReject.fromDate)} onChange={date => setValue(strings.wfhApproveReject.fromDate, date)} isRequired={true} isLabelView={true} /></div>
                    <div><DatePickerElement placeholder='To' disabled={watch(strings.wfhApproveReject.period).label !== strings.filterPeriod.custom} value={watch(strings.wfhApproveReject.toDate)} onChange={date => setValue(strings.wfhApproveReject.toDate, date)} minDate={watch(strings.wfhApproveReject.period).label === strings.filterPeriod.custom && watch(strings.wfhApproveReject.fromDate)} isRequired={true} isLabelView={true} /></div>
                    <div><Dropdown placeholder={"Employee Name"} value={employeeName} onChange={data => setValue(strings.wfhApproveReject.employeeName, data)} options={employeeNameOptions} isLabelView={true} isSearchable={true} /></div>
                    <div><Dropdown placeholder={'Status'} value={watch(strings.wfhApproveReject.status)} onChange={data => setValue(strings.wfhApproveReject.status, data)} options={leaveStatus.filter(val => val.value !== 3 && val.value !== 6)} isRequired={true} isLabelView={true} /></div>
                    <div className='col-span-full flex justify-center self-end gap-3'>
                        <Button value={strings.Buttons.Search} disabled={!(((watch(strings.wfhApproveReject.period)?.label === strings.filterPeriod.custom ? (watch(strings.wfhApproveReject.fromDate) && watch(strings.wfhApproveReject.toDate)) : true)) && watch(strings.wfhApproveReject.permissionType) && watch(strings.wfhApproveReject.status) && watch(strings.wfhApproveReject.employeeName))} onClick={handleSearch} />
                        <Button value={strings.Buttons.Reset} onClick={() => onReset()} />
                    </div>
                </div>
                <AgGrid columns={wfhColumns.ApproveAndReject.columns} height={` lg:h-[calc(94vh-67px-67px-1.5rem-3.5rem-4.6rem-2rem)] md:h-[calc(94vh-67px-67px-67px-1.5rem-3.5rem-4.6rem-2rem)] sm:h-[calc(94vh-67px-67px-67px-1.5rem-3.5rem-4.6rem)] xsm:h-[58vh] `} ContextMenuItems={wfhColumns.ApproveAndReject.ContextMenuItems} data={wfhRequestState.approveRejectRequest.data} />
                <div className="flex items-center mt-3" ><AddButton value={strings.Buttons.addWfh} onClick={handleOpenAddWFHRequest} /> </div>
            </div>
            {wfhRequestState.loader && <TransparentLoader />}
            {!wfhRequestState.approvalViewPopup.show && apiResponseState.show && <ApiResponse />}
            {wfhRequestState.addWFHRequest.show && <AddWFHRequest />}
            {wfhRequestState.approvalViewPopup.show && <WFHRequestDetailsPopup handleRefresh={handleSearch} />}
            {wfhRequestState.wfhHistoryPopup.show && <WFHHistoryPopup />}
        </>
    );
};

export default ApproveRejectWFH;

const initialValue = {
    period: "",
    fromDate: "",
    toDate: "",
    status: "",
    employeeName: ''
}