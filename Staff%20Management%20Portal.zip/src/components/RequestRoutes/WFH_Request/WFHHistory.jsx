import { useForm } from "react-hook-form";
import { strings } from "../../Constants";
import HeaderSection from "../../layouts/HeaderSection";
import Dropdown from "../../elements/Dropdown";
import DatePickerElement from "../../elements/DatePickerElement";
import { periodDateFormat, periodOptionsWithoutPayroll, exportDateFormat, dateFormat, leaveStatus } from "../../helper";
import Button from "../../elements/Button";
import AgGrid from "../../Grid/AgGrid";
import { wfhColumns } from "../../Grid/Columns";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import TransparentLoader from "../../loader/TransparentLoader";
import ApiResponse from "../../Alert/ApiResponse";
import AddWFHRequest from "../../Popup_window/AddWFHRequest";
import { wfhActions } from "../../../redux/wfhReducer";
import { wfhRequest } from "../../requests";
import SubHeaderSection from "../../layouts/SubHeaderSection";


const WFHHistory = () => {
    const dispatch = useDispatch();
    const { watch, setValue, getValues } = useForm({ defaultValues: initialValue });
    const wfhRequestState = useSelector(state => state.wfhRequest);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const { UserID } = useSelector(state => state.user);

    useEffect(() => {
        const initialRender = async () => {
            await dispatch(wfhActions.setLoader(true));
            await handleReset();
            dispatch(wfhActions.setLoader(false));

        }
        initialRender()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onPeriodChange = (value) => {
        setValue(strings.wfhHistory.period, value);
        periodDateFormat(value, setValue);
    }

    const handleReset = async () => {
        await dispatch(wfhActions.setLoader(true));
        await onPeriodChange(periodOptionsWithoutPayroll.find((val) => val.value === 4));
        await setValue(strings.wfhHistory.status, leaveStatus.find((val) => val.value === 4));
        await handleSearch();
        dispatch(wfhActions.setLoader(false));
    }

    const handleSearch = async () => {
        await dispatch(wfhActions.setLoader(true));
        const value = getValues();
        const params = {
            employeeId: UserID,
            startDate: exportDateFormat(value.fromDate, true),
            endDate: exportDateFormat(value.toDate, true),
            status: value?.status.label
        }
        await dispatch(wfhRequest.getWFHRequestDetails(params, async (data) => {
            await dispatch(wfhActions.setWFHRequestData({ data }));
        }));
        dispatch(wfhActions.setLoader(false));
    }
    return (
        <>
            <HeaderSection redirectType={strings.type.wFHRequest} />
            <div className=" px-6 overflow-hidden mb-5">
                <SubHeaderSection subHeader="Work From Home History" fileProps={{ columns: wfhColumns.WFHHistory.columns, data: wfhRequestState.wfhRequest.data.map((val, idx) => ({ ...val, sno: idx + 1, FromDate: val.FromDate ? dateFormat(val.FromDate) : "", ToDate: val.ToDate ? dateFormat(val.ToDate) : "" })), docName: `WFH History` }} />
                <div className="grid grid-rows-1 md:grid-rows-1 sm:grid-rows-2 xsm:grid-rows-3 gap-x-4 gap-y-1 xl:grid-cols-5 md:grid-cols-3 sm:grid-cols-2 w-full mb-5">
                    <div><Dropdown placeholder={"Period"} options={periodOptionsWithoutPayroll} value={watch(strings.wfhHistory.period)} onChange={e => onPeriodChange(e)} isLabelView={true} /></div>
                    <div><DatePickerElement placeholder='From' disabled={watch(strings.wfhHistory.period).label !== strings.filterPeriod.custom} value={watch(strings.wfhHistory.fromDate)} onChange={date => setValue(strings.wfhHistory.fromDate, date)} isRequired={true} isLabelView={true} /></div>
                    <div><DatePickerElement placeholder='To' disabled={watch(strings.wfhHistory.period).label !== strings.filterPeriod.custom} value={watch(strings.wfhHistory.toDate)} onChange={date => setValue(strings.wfhHistory.toDate, date)} minDate={watch(strings.wfhHistory.period).label === strings.filterPeriod.custom && watch(strings.wfhHistory.fromDate)} isRequired={true} isLabelView={true} /></div>
                    <div><Dropdown placeholder={'Status'} value={watch(strings.wfhHistory.status)} onChange={data => setValue(strings.wfhHistory.status, data)} options={leaveStatus.filter(val => val.value !== 3 && val.value !== 6)} isRequired={true} isLabelView={true} /></div>
                    <div className='self-end flex gap-1'>
                        <Button value={strings.Buttons.Search} disabled={!(((watch(strings.wfhHistory.period).label === strings.filterPeriod.custom ? (watch(strings.wfhHistory.fromDate) && watch(strings.wfhHistory.toDate)) : true)) && watch(strings.wfhHistory.permissionType) && watch(strings.wfhHistory.status))} onClick={handleSearch} />
                        <Button value={strings.Buttons.Reset} onClick={() => handleReset()} />
                    </div>
                </div>
                <AgGrid data={wfhRequestState.wfhRequest.data} columns={wfhColumns.WFHHistory.columns} height={` xl:h-[calc(100vh-18.3rem)] md:h-[calc(100vh-22.6rem)] h-[calc(100vh-33rem)]`} />
            </div>
            {wfhRequestState.loader && <TransparentLoader />}
            {(!wfhRequestState.addWFHRequest.show && apiResponseState.show) && <ApiResponse />}
            {wfhRequestState.addWFHRequest.show && <AddWFHRequest isEmployeeRequest={true} />}
        </>
    );
}

export default WFHHistory;

const initialValue = {
    period: "",
    fromDate: "",
    toDate: "",
    status: ""
}