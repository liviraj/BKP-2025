

import HeaderSection from '../../layouts/HeaderSection'
import { setDefaultValue, strings } from '../../Constants'
import { HiMiniCheckCircle, HiMiniExclamationCircle } from "react-icons/hi2";
import Button from '../../elements/Button';
import { useDispatch, useSelector } from 'react-redux';
import { ComplianceAgreementActions } from '../../../redux/ComplianceAgreementReducer';
import { useEffect } from 'react';
import { dateAndTimeFormat, exportYearFormat, userReducerState } from '../../helper';
import { documentPolicyRequest } from '../../requests';
import TransparentLoader from '../../loader/TransparentLoader';
import { useForm } from 'react-hook-form';
import ApiResponse from '../../Alert/ApiResponse';
import LinearProgress from '../../elements/LinearProgress';
import PdfViewerModel from '../../ViewDocs/PdfViewerModel';
import EmployeeAgreementPolicy from '../../Popup_window/EmployeeAgreementPolicy';


export default function PolicyHistory() {
    const { pdfViewerPopup, complianceDocHistory, loader, employeeagreementPolicyPopup } = useSelector(state => state.complianceAgreement);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const dispatch = useDispatch();
    const { watch, setValue, getValues } = useForm({ defaultValues: initialState });
    const completedTasks = watch(strings.policyHistory.completedTasks);
    const totalTasks = watch(strings.policyHistory.totalTasks);
    const progress = watch(strings.policyHistory.progress);
    const userDetails = useSelector(state => state.user);

    useEffect(() => {
        const initialLoad = async () => {
            dispatch(ComplianceAgreementActions.setLoader(true));
            await handleYearChange();
            dispatch(documentPolicyRequest.policyData.getNotificationRequest(userDetails.UserID));
            dispatch(ComplianceAgreementActions.setLoader(false));
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        setValue(strings.policyHistory.totalTasks, complianceDocHistory?.length > 0 ? complianceDocHistory.length : 0);
        setValue(strings.policyHistory.completedTasks, complianceDocHistory?.length > 0 ? complianceDocHistory.filter((item) => item.isReviewed !== setDefaultValue.pendingStatusColor).length : 0);
        const data = getValues();
        setValue(strings.policyHistory.progress, (data.completedTasks > 0 && data.totalTasks > 0) ? ((data.completedTasks / data.totalTasks) * 100) : 0);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [complianceDocHistory]);


    const handleClick = async (data) => {
        if (data.isReviewed === setDefaultValue.pendingStatusColor) {
            dispatch(ComplianceAgreementActions.setLoader(true));
            dispatch(ComplianceAgreementActions.setEmployeeAgreementPolicy({ currentPolicyId: data.policyDetailId }));
            dispatch(ComplianceAgreementActions.setEmployeeagreementPolicyPopup({ show: true }));
            dispatch(ComplianceAgreementActions.setLoader(false));
        } else {
            dispatch(ComplianceAgreementActions.setLoader(true));
            await dispatch(documentPolicyRequest.complianceDocumenyHistory.getPolicyViewDocument(data.policyDetailId));
            dispatch(ComplianceAgreementActions.setLoader(false));
        }
    };

    const handleYearChange = async () => {
        dispatch(ComplianceAgreementActions.setLoader(true));
        const data = getValues();
        let params = {
            dueDate: data.year ? exportYearFormat(data.year) : 0,
            employeeId: userReducerState().UserID
        }
        await dispatch(documentPolicyRequest.complianceDocumenyHistory.getHistoryDocument(params));
        dispatch(ComplianceAgreementActions.setLoader(false));
    };

    return (
        <>
            <HeaderSection redirectType={strings.type.employeePolicy} />
            <div className='px-6  bg-[#f2f2f2]  font-fontfamily tracking-tighter pb-6 md:h-[calc(100vh-8.1rem)] lg:overflow-hidden '>
                <div className='pb-4 flex items-center justify-between flex-wrap'>
                    <div>
                        <h3 className="text-headerColor font-fontfamily font-bold tracking-wide pt-2 sm:pt-4 ">My Compliance Document</h3>
                        <p className=' text-sm font-medium' >Complete policy awareness training by reviewing and accepting your organization&apos;s policies. </p>
                    </div>
                    {/* <div> <DatePickerElement value={watch(strings.policyHistory.year)} isRequired onChange={(date) => (setValue(strings.policyHistory.year, date), handleYearChange())} isLabelView showYearDropdown /></div> */}
                </div>
                <div className="mb-4 bg-white shadow-md border border-gray-300 h-20 flex items-center ">
                    <div className="p-3 w-full">
                        <LinearProgress value={Number(progress)} completedTasks={Number(completedTasks)} totalTasks={Number(totalTasks)} />  <span className="block mt-2 text-sm">   <span className=' font-semibold text-base'> Agreed to :</span> <span className='text-gray-500 text-sm'>  {completedTasks} of {totalTasks}  Policies </span>  </span>
                    </div>
                </div>
                <div className=' px-4 pt-4 pb-2 overflow-auto md:h-[calc(100vh-25rem)] lg:h-[calc(100vh-21rem)] bg-white shadow-md border border-gray-300 grayScollBarCompliance '>
                    {complianceDocHistory && complianceDocHistory.length > 0 ? (complianceDocHistory.map((agreement) => (
                        <div key={agreement.policyDetailId} className={`border-l-4  ${agreement.isReviewed !== setDefaultValue.pendingStatusColor ? "border-l-green-500" : " border-l-red-500"} p-4 mb-3 policy-history-box `} >
                            <div className="flex flex-col md:flex-row gap-2 w-full justify-between font-fontfamily">
                                <div className="flex-1">
                                    <div className="flex items-center gap-2">
                                        {agreement.isReviewed !== setDefaultValue.pendingStatusColor ? <div className=' min-w-6 min-h-6 text-green-600'> <HiMiniCheckCircle className=" w-full h-full" /> </div> : <div className=' min-w-6 min-h-6 text-red-600'> <HiMiniExclamationCircle className=' w-full h-full' /></div>}

                                        <div className="font-semibold"> {`${agreement.documentTitle}, Assigned on : `}<span className=' tracking-wide text-14px '>{dateAndTimeFormat(agreement.assignedDate)}</span> </div>
                                    </div>
                                    {agreement.isReviewed !== setDefaultValue.pendingStatusColor ? <span className="block mt-4 text-gray-500 text-sm"> {`You agreed to this policy ${agreement.completedBefore} days ago`}  </span> : ""}
                                </div>
                                <div className="mt-2 md:mt-0">  <Button value={agreement.isReviewed !== setDefaultValue.pendingStatusColor ? "View" : "Review"} disabled={false} onClick={() => { handleClick(agreement) }} addStyle={agreement.isReviewed !== setDefaultValue.pendingStatusColor ? "!bg-green-600" : ""} /></div>
                            </div>
                        </div>
                    ))) : <div className=" font-fontfamily font-semibold text-base flex justify-center items-center w-full text-center h-full">No Record Found</div>}
                </div>
            </div>
            {loader && <TransparentLoader />}
            {pdfViewerPopup.show && <PdfViewerModel />}
            {apiResponseState.show && <ApiResponse />}
            {employeeagreementPolicyPopup.show && <EmployeeAgreementPolicy />}
        </>
    )
}



const initialState = {
    completedTasks: "",
    totalTasks: "",
    progress: "",
    year: new Date(),
}