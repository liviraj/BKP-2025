import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useForm } from "react-hook-form";
import moment from "moment";
import { strings } from "../../Constants";
import Button from "../../elements/Button";
import Dropdown from "../../elements/Dropdown";
import HeaderSection from "../../layouts/HeaderSection";
import { documentPolicyRequest, employeeRequests } from "../../requests";
import { complianceAgreementReducerState, employeeReducerState, exportYearFormat, userReducerState } from "../../helper";
import { ComplianceAgreementActions } from "../../../redux/ComplianceAgreementReducer";
import TransparentLoader from "../../loader/TransparentLoader";
import DatePickerElement from "../../elements/DatePickerElement";
import ApiResponse from "../../Alert/ApiResponse";
import AgGrid from "../../Grid/AgGrid";
import { ComplianceDocumentColumn } from "../../Grid/Columns";
import NotifyPendingPopup from "../../Popup_window/NotifyPendingPopup";
import AssignmentDocumentPopup from "../../Popup_window/AssignmentDocumentPopup";
import ViewAcceptanceStatusPopup from "../../Popup_window/ViewAcceptanceStatusPopup";

const AssignedDocumentHistory = () => {
    const dispatch = useDispatch();
    const { watch, setValue, getValues } = useForm({ defaultValues: initialState });
    const employeeState = useSelector(state => state.employee);
    const complianceAgreementState = useSelector(state => state.complianceAgreement);
    const loginResponseState = useSelector(state => state.loginResponse);

    useEffect(() => {
        const initialState = async () => {
            dispatch(ComplianceAgreementActions.setLoader(true));
            await Promise.all([
                employeeState.location.length <= 0 && dispatch(employeeRequests.location()),
                complianceAgreementState.agreementPolicyType <= 0 && dispatch(documentPolicyRequest.assignedDocumentHistory.getPolicyType())
            ]);
            await onReset();
            dispatch(ComplianceAgreementActions.setLoader(false));
        }
        initialState();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);


    const onSubmit = async () => {
        dispatch(ComplianceAgreementActions.setLoader(true));
        const data = getValues();
        const params = {
            locationId: data.location?.value,
            documentType: data.policyType?.label,
            year: exportYearFormat(data.year)
        }
        await dispatch(documentPolicyRequest.assignedDocumentHistory.getAssignedDocumentHistoryRequest(params));
        dispatch(ComplianceAgreementActions.setLoader(false));
    }

    const onReset = async () => {
        dispatch(ComplianceAgreementActions.setLoader(true));
        await Promise.all([
            setValue(strings.notifyPendingPolicies.location, employeeReducerState().location.find(val => val.value === userReducerState().LocationID)),
            setValue(strings.notifyPendingPolicies.year, new Date()),
            setValue(strings.notifyPendingPolicies.policyType, complianceAgreementReducerState().agreementPolicyType?.[0])
        ]);
        await onSubmit();
        dispatch(ComplianceAgreementActions.setLoader(false));
    }


    return (
        <>
            <HeaderSection redirectType={strings.type.complianceDocument} />
            <div className="px-6 overflow-auto h-auto md:max-h-h_body_md sm:max-h-full">
                <div className='grid grid-rows-1 md:grid-rows-1 sm:grid-rows-2 xsm:grid-rows-3 gap-x-4 gap-y-1 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-2 w-full mb-6'>
                    <div><Dropdown placeholder={"Location"} value={watch(strings.notifyPendingPolicies.location)} options={employeeState.location} onChange={(data) => setValue(strings.notifyPendingPolicies.location, data)} isLabelView isRequired isDisable={userReducerState().Role === strings.userRoles.humanResource} /></div>
                    <div> <DatePickerElement placeholder={"Select Year"} value={watch(strings.notifyPendingPolicies.year)} onChange={(date) => setValue(strings.notifyPendingPolicies.year, date)} isLabelView showYearDropdown isRequired maxDate={moment(new Date()).add(5, "years")} isRemovable /></div>
                    <div><Dropdown placeholder={"Policy Type"} options={complianceAgreementState.agreementPolicyType} value={watch(strings.notifyPendingPolicies.policyType)} onChange={data => setValue(strings.notifyPendingPolicies.policyType, data)} isLabelView isDisable={watch(strings.notifyPendingPolicies.year).length <= 0} /></div>
                    <div className=' xsm:col-span-full sm:col-span-1 md:col-span-full lg:col-span-2 flex xsm:justify-center lg:justify-start self-end gap-x-3'>
                        <Button value={strings.Buttons.Search} onClick={onSubmit} disabled={!(watch(strings.notifyPendingPolicies.location) && watch(strings.notifyPendingPolicies.policyType))} />
                        <Button value={strings.Buttons.Reset} onClick={onReset} />
                    </div>
                </div>
                <AgGrid columns={ComplianceDocumentColumn.assignedDocumentHistory.columns(loginResponseState.isMobileCompatible)} data={complianceAgreementState.assignedDocumentHistory.data} ContextMenuItems={ComplianceDocumentColumn.assignedDocumentHistory.contextMenuItems} height=" lg:h-[calc(100vh-4.6rem-1.5rem-67px-3.5rem-1.5rem)] md:h-[calc(100vh-4.6rem-1.5rem-119px-3.5rem-1.5rem)] sm:h-[calc(100vh-4.6rem-1.5rem-137px-3.5rem-1.5rem)] xsm:h-[calc(100vh-4.6rem-1.5rem-260px-3.5rem-1.5rem)] " />
            </div>
            {complianceAgreementState.loader && <TransparentLoader />}
            {complianceAgreementState.agreementDocument.agreementDocmentPopup.show && <AssignmentDocumentPopup handleSearch={onSubmit} />}
            {loginResponseState.apiResponse.show && <ApiResponse />}
            {complianceAgreementState.notifyPendingPolicies.isShow && <NotifyPendingPopup />}
            {complianceAgreementState.assignedDocumentHistoryPopup.show && <ViewAcceptanceStatusPopup />}
        </>
    );
};

const initialState = {
    location: '',
    year: '',
    policyType: ''
}


export default AssignedDocumentHistory;



