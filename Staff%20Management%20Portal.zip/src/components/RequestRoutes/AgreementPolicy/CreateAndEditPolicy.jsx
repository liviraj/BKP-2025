import HeaderSection from '../../layouts/HeaderSection'
import { statusOptionsList, strings } from '../../Constants'
import SubHeaderSection from '../../layouts/SubHeaderSection'
import AgGrid from '../../Grid/AgGrid'
import { ComplianceDocumentColumn } from '../../Grid/Columns'
import AddButton from '../../elements/AddButton'
import { useDispatch, useSelector } from 'react-redux'
import { ComplianceAgreementActions } from '../../../redux/ComplianceAgreementReducer'
import ApiResponse from '../../Alert/ApiResponse'
import Dropdown from '../../elements/Dropdown'
import Button from '../../elements/Button'
import { useEffect } from 'react'
import TransparentLoader from '../../loader/TransparentLoader'
import { documentPolicyRequest, employeeRequests } from '../../requests'
import { dateFormat, employeeReducerState, exportDateFormat } from '../../helper'
import { useForm } from 'react-hook-form'
import AssignmentDocumentPopup from '../../Popup_window/AssignmentDocumentPopup'
import PdfViewerModel from '../../ViewDocs/PdfViewerModel'
import CreatePolicyDocumentPopup from '../../Popup_window/CreatePolicyDocumentPopup'

export default function CreateAndEditPolicy() {
    const dispatch = useDispatch();
    const { documentPopup, loader, documentData, pdfViewerPopup, agreementPolicyType } = useSelector(state => state.complianceAgreement);
    const { agreementDocmentPopup } = useSelector(state => state.complianceAgreement.agreementDocument);
    const employeeState = useSelector(state => state.employee);
    const userState = useSelector(state => state.user);
    const { watch, setValue, getValues } = useForm({ defaultValues: initialState });
    const loginResponseState = useSelector(state => state.loginResponse);
    const userDetails = useSelector(state => state.user);

    useEffect(() => {
        const onInitialLoad = async () => {
            dispatch(ComplianceAgreementActions.setLoader(true));
            await Promise.all([
                employeeState.location.length <= 0 && dispatch(employeeRequests.location()),
                employeeState.nysCompliancePeriod.length <= 0 && dispatch(employeeRequests.getCompliancePeriod()),
                employeeState.nysComplianceCategory.length <= 0 && dispatch(employeeRequests.getComplianceCategory()),
                employeeReducerState().documentType.length <= 0 && dispatch(employeeRequests.setDocumentType()),
                agreementPolicyType <= 0 && dispatch(documentPolicyRequest.assignedDocumentHistory.getPolicyType())
            ]);
            await handleReset();
            dispatch(ComplianceAgreementActions.setLoader(false));
        }
        onInitialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const handleSearch = async () => {
        dispatch(ComplianceAgreementActions.setLoader(true));
        const value = getValues();
        const params = {
            locationId: value.location?.value,
            status: value.status?.value
        }
        await dispatch(documentPolicyRequest.complianceAgreement.getDocument(params));
        dispatch(ComplianceAgreementActions.setLoader(false));
    }

    const handleReset = async () => {
        await Promise.all([
            setValue(strings.agreementDocument.status, statusOptionsList.find(val => val.value == 0)),
            setValue(strings.agreementDocument.location, employeeReducerState().location.find(val => val.value === userState.LocationID))
        ]);
        await handleSearch();
    }

    const onDeleteConfirmation = async (isAcceptable) => {
        dispatch(ComplianceAgreementActions.setLoader(true));
        if (isAcceptable) {
            const params = {
                id: documentPopup.selectedRow.documentId,
                locationId: userState.LocationID,
                modifiedBy: userState.UserID,
                modifiedDate: exportDateFormat(new Date())
            }
            await dispatch(documentPolicyRequest.complianceAgreement.deleteDocument(documentPopup.selectedRow.documentId, params, async () => {
                dispatch(ComplianceAgreementActions.setLoader(true));
                await handleSearch();
                dispatch(documentPolicyRequest.policyData.getNotificationRequest(userDetails.UserID));
                dispatch(ComplianceAgreementActions.setLoader(false));
            }));
        }
        dispatch(ComplianceAgreementActions.setLoader(false));
    }

    const handleAssignmentDocumentPopup = async () => {
        dispatch(ComplianceAgreementActions.setLoader(true));
        await dispatch(documentPolicyRequest.complianceAgreement.getViewDocument());
        dispatch(ComplianceAgreementActions.setLoader(false));
    }

    return (
        <div>
            <HeaderSection redirectType={strings.type.complianceDocument} />
            <div className='mx-6 ' >
                <SubHeaderSection subHeader="Document" fileProps={{ columns: ComplianceDocumentColumn.complianceAgreement.column(loginResponseState.isMobileCompatible), data: documentData?.map((val, idx) => ({ ...val, sno: idx + 1, createdOn: dateFormat(val.createdOn) })), docName: 'Policy Document List' }} />
                <div className='grid  gap-x-4 gap-y-1 lg:grid-cols-4 md:grid-cols-2 sm:grid-cols-3 w-full mb-6'>
                    <span><Dropdown options={employeeState.location && employeeState.location.length > 0 ? employeeState.location.filter(val => val.value >= 0) : []} value={watch(strings.agreementDocument.location)} onChange={value => { setValue(strings.agreementDocument.location, value) }} isLabelView={true} placeholder={"Location"} isDisable={userState.Role !== strings.userRoles.admin} isSearchable={true} /> </span>
                    <span><Dropdown options={statusOptionsList} value={watch(strings.agreementDocument.status)} onChange={value => { setValue(strings.agreementDocument.status, value) }} isLabelView={true} placeholder={"Status"} isSearchable={true} /></span>
                    <div className='self-end flex gap-3'>
                        <Button value={strings.Buttons.Submit} onClick={handleSearch} />
                        <Button value={strings.Buttons.Reset} onClick={handleReset} />
                    </div>
                </div>
                <AgGrid data={documentData} columns={ComplianceDocumentColumn.complianceAgreement.column(loginResponseState.isMobileCompatible)} height={'lg:h-[calc(100vh-20rem)] md:h-[calc(100vh-23rem)] sm:h-[calc(100vh-15rem)] xsm:h-[calc(100vh-23rem)]'} isDesignationActiveSelectable ContextMenuItems={loginResponseState.isMobileCompatible ? false : ComplianceDocumentColumn.complianceAgreement.contextMenuItems} />
                <div className="m-2 flex items-center text-14px font-bold "><AddButton value={strings.Buttons.createDocument} onClick={() => dispatch(ComplianceAgreementActions.setDocumentPopup({ show: true, selectedRow: {}, action: 'Add' }))} /></div>
            </div>
            {(!documentPopup.show && loginResponseState.apiResponse.show) && <ApiResponse setResponseCallback={onDeleteConfirmation} />}
            {loader && <TransparentLoader />}
            {documentPopup.show && <CreatePolicyDocumentPopup handleRefresh={handleSearch} handleAssignmentDocument={handleAssignmentDocumentPopup} />}
            {agreementDocmentPopup.show && <AssignmentDocumentPopup />}
            {!documentPopup.show && pdfViewerPopup.show && <PdfViewerModel />}
        </div>
    )
}



const initialState = {
    location: "",
    status: "",
}

