import { useEffect, useMemo } from "react"
import { useDispatch, useSelector } from "react-redux"
import ApiResponse from "../../Alert/ApiResponse"
import { setDefaultValue, strings } from "../../Constants"
import Button from "../../elements/Button"
import DatePickerElement from "../../elements/DatePickerElement"
import Dropdown from "../../elements/Dropdown"
import AgGrid from "../../Grid/AgGrid"
import { dateFormat, employeeReducerState, exportYearFormat } from "../../helper"
import HeaderSection from "../../layouts/HeaderSection"
import SubHeaderSection from "../../layouts/SubHeaderSection"
import TransparentLoader from "../../loader/TransparentLoader"
import { useForm } from "react-hook-form"
import { employeeRequests, holidayRequests } from "../../requests"
import moment from "moment-timezone"
import { holidayActions } from "../../../redux/holidayReducer"
import { holiday } from "../../Grid/Columns"


function ViewFloatingHolidayList() {

    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const employeeState = useSelector(state => state.employee);
    const floatingHolidayListState = useSelector(state => state.holiday.floatingHolidayList);
    const { watch, setValue, reset, getValues } = useForm({ defaultValues: initialState });
    const yearDate = watch(strings.floatingHolidayList.year);
    const dispatch = useDispatch();

    const setYearFloatingHolidayOptions = async (year, data) => {
        let yearlyFloatingHolidays = floatingHolidayListState.yearlyFloatingHolidays;
        if (data && data.length > 0) {
            const validIndex = yearlyFloatingHolidays.length > 0 ? yearlyFloatingHolidays.findIndex(val => val.year === year) : false;
            const customData = [setDefaultValue.floatingHolidayList, ...data.map(val => ({ ...val, label: val.holidayName, value: val.holidayId }))]
            if (typeof (validIndex) === "number" && validIndex >= 0) {
                yearlyFloatingHolidays[validIndex].data = customData;
            } else {
                yearlyFloatingHolidays = [...yearlyFloatingHolidays, { year, data: customData }];
            }
        }
        await dispatch(holidayActions.setYearlyFloatingHolidayOptions(yearlyFloatingHolidays));
    }

    useEffect(() => {
        const initialLoad = async () => {
            dispatch(holidayActions.setFloatingHolidayListLoader(true));
            await Promise.all([
                employeeState.employeeName.length <= 0 && dispatch(employeeRequests.employeeName()),
                floatingHolidayListState.yearlyFloatingHolidays.length <= 0 && dispatch(holidayRequests.floatingHolidayList.getYearlyFloatingHolidays(exportYearFormat(new Date()), setYearFloatingHolidayOptions))
            ]);
            await setInitialValue();
            await callAPIRequest();
            dispatch(holidayActions.setFloatingHolidayListLoader(false));
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const setInitialValue = async () => {
        await Promise.all([
            setValue(strings.floatingHolidayList.employeeName, employeeReducerState().employeeName.find(val => val.value === setDefaultValue.employeeName.value)),
            setValue(strings.floatingHolidayList.year, new Date()),
            setValue(strings.floatingHolidayList.floatingHolidays, setDefaultValue.floatingHolidayList)
        ]);
    }

    const callAPIRequest = async () => {
        const data = getValues();
        const params = {
            employeeId: data.employeeName.value,
            floatingHolidayId: data.floatingHolidays ? data.floatingHolidays.value : 0,
            year: exportYearFormat(data.year)
        }
        await dispatch(holidayRequests.floatingHolidayList.getFloatingHolidayDetails(params));
    }

    const onhandleReset = async () => {
        dispatch(holidayActions.setFloatingHolidayListLoader(true));
        reset();
        await setInitialValue();
        await callAPIRequest();
        dispatch(holidayActions.setFloatingHolidayListLoader(false));
    }

    const onhandleSearch = async () => {
        dispatch(holidayActions.setFloatingHolidayListLoader(true));
        await callAPIRequest();
        dispatch(holidayActions.setFloatingHolidayListLoader(false));
    }

    const floatingHolidayOptions = useMemo(() => {
        if (floatingHolidayListState.yearlyFloatingHolidays.length > 0) {
            const year = exportYearFormat(yearDate);
            if (year) {
                const validData = floatingHolidayListState.yearlyFloatingHolidays.find(val => val.year === year);
                return validData ? validData.data : [];
            }
        }
        return []
    }, [floatingHolidayListState.yearlyFloatingHolidays, yearDate]);

    const onYearChange = async (date) => {
        dispatch(holidayActions.setFloatingHolidayListLoader(true));
        const year = exportYearFormat(date);
        const isValidYear = floatingHolidayListState.yearlyFloatingHolidays.find(val => val.year === year);
        if (!isValidYear) {
            await dispatch(holidayRequests.floatingHolidayList.getYearlyFloatingHolidays(year, async (year, data) => {
                setValue(strings.floatingHolidayList.year, date);
                setValue(strings.floatingHolidayList.floatingHolidays, setDefaultValue.floatingHolidayList);
                await setYearFloatingHolidayOptions(year, data)
            }))
        } else if (exportYearFormat(yearDate) !== exportYearFormat(date)) {
            setValue(strings.floatingHolidayList.floatingHolidays, setDefaultValue.floatingHolidayList);
            setValue(strings.floatingHolidayList.year, date);
        }
        dispatch(holidayActions.setFloatingHolidayListLoader(false));
    }
    return (
        <>
            <HeaderSection redirectType={strings.type.holiday} />
            <div className='mx-6'>
                <SubHeaderSection subHeader="Floating Holiday List of the Organization" fileProps={{ columns: holiday.floatingHolidayList.columns, data: floatingHolidayListState.data.length > 0 ? floatingHolidayListState.data.map((val, idx) => ({ ...val, sno: idx + 1, startDate: dateFormat(val.startDate), endDate: dateFormat(val.endDate) })) : [], docName: "Floating Holiday List of the Organization" }} />
                <div className='grid  gap-x-6 gap-y-1 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-2 w-full mb-6'>
                    <Dropdown options={employeeReducerState().employeeName.length > 0 ? employeeReducerState().employeeName.filter(val => val.value === setDefaultValue.defaultLocation.value || (val.locationId === setDefaultValue.location.value && (val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation))) : []} value={watch(strings.floatingHolidayList.employeeName)} onChange={data => setValue(strings.floatingHolidayList.employeeName, data)} placeholder={strings.dropDowns.Login_Roles.Name} isLabelView />
                    <DatePickerElement showYearDropdown={true} value={yearDate} onChange={onYearChange} maxDate={moment().add(10, "years")} isRequired isLabelView placeholder={strings.dropDowns.ReportCompliance.Year} />
                    <Dropdown options={floatingHolidayOptions} value={watch(strings.floatingHolidayList.floatingHolidays)} onChange={data => setValue(strings.floatingHolidayList.floatingHolidays, data)} placeholder={"Floating Holidays"} isLabelView />
                    <div className=' flex justify-center self-end gap-3'>
                        <Button value={strings.Buttons.Search} onClick={onhandleSearch} />
                        <Button value={strings.Buttons.Reset} onClick={onhandleReset} />
                    </div>
                </div>
                <AgGrid data={floatingHolidayListState.data} columns={holiday.floatingHolidayList.columns} height={'lg:h-[calc(100vh-20rem)] md:h-[calc(100vh-23rem)] sm:h-[calc(100vh-15rem)] xsm:h-[calc(100vh-23rem)]'} isSetFilter />
            </div>
            {floatingHolidayListState.loader && <TransparentLoader />}
            {apiResponseState.show && <ApiResponse />}
        </>
    )
}

export default ViewFloatingHolidayList

const initialState = {
    employeeName: "",
    year: "",
    floatingHolidays: ""
}