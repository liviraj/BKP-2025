import { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { useForm } from "react-hook-form"
import moment from "moment-timezone"
import { setDefaultValue, strings } from "../../Constants"
import HeaderSection from "../../layouts/HeaderSection"
import SubHeaderSection from "../../layouts/SubHeaderSection"
import AgGrid from "../../Grid/AgGrid"
import TransparentLoader from "../../loader/TransparentLoader"
import ApiResponse from "../../Alert/ApiResponse"
import AddButton from "../../elements/AddButton"
import DatePickerElement from "../../elements/DatePickerElement"
import Button from "../../elements/Button"
import { holidayRequests } from "../../requests"
import { dateFormat, exportYearFormat, floatingHolidayColorCodes } from "../../helper"
import { holidayActions } from "../../../redux/holidayReducer"
import { holiday } from "../../Grid/Columns"
import SetFloatingHolidayPopup from "../../Popup_window/SetFloatingHolidayPopup"
import ColorLegend from "../../elements/ColorLegend"


function HolidayListOrganization() {

    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const holidayListState = useSelector(state => state.holiday.holidayList);
    const userState = useSelector(state => state.user);
    const floatingHolidayPopupState = useSelector(state => state.holiday.floatingHolidayOptionsPopup)
    const { watch, setValue, reset, getValues } = useForm({ defaultValues: initialState });
    const dispatch = useDispatch();

    useEffect(() => {
        const initialLoad = async () => {
            await onhandleReset();
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const setInitialValue = async () => {
        reset();
        await Promise.all([
            setValue(strings.holidayList.year, new Date())
        ]);
        await callAPIRequest();
    }

    const callAPIRequest = async () => {
        const data = getValues();
        const params = {
            employeeId: userState.UserID,
            locationId: userState.LocationID,
            year: exportYearFormat(data.year)
        }
        await dispatch(holidayRequests.holidayList.getHolidayLists(params));
    }

    const onhandleReset = async () => {
        dispatch(holidayActions.setHolidayListLoader(true));
        await setInitialValue();
        dispatch(holidayActions.setHolidayListLoader(false));
    }

    const onhandleSearch = async () => {
        dispatch(holidayActions.setHolidayListLoader(true));
        await callAPIRequest();
        dispatch(holidayActions.setHolidayListLoader(false));
    }

    const openFloatingHolidayPopup = async () => {
        dispatch(holidayActions.setHolidayListLoader(true));
        const params = {
            employeeId: userState.UserID,
            locationId: userState.LocationID,
            year: exportYearFormat(new Date())
        }

        await dispatch(holidayRequests.holidayList.getFloatingHolidayDetails(params, async (data) => {
            let validData = data?.length > 0 ? data : [];
            validData = holiday.addFloatingHolidayList.convertFormattedRecords(validData);
            await dispatch(holidayActions.setFloatingHolidayOptionsPopup({ show: true, employeeDetails: validData.data.length > 0 ? validData.data[0] : {} }));
        }));

        dispatch(holidayActions.setHolidayListLoader(false));
    }
    const setRowStyle = params => {
        if (params.data && ("isSetAsFloatingHoliday" in params.data) && params.data.isSetAsFloatingHoliday && params.data.isSetAsFloatingHoliday.toLowerCase().trim() === "true") {
            return { backgroundColor: floatingHolidayColorCodes.selected.color }
        }
        else if (params.data && ("isOptional" in params.data) && params.data.isOptional) {
            const isOptional = params.data.isOptional.toLowerCase().trim() === "true";
            return { backgroundColor: isOptional ? floatingHolidayColorCodes.optional.color : '#ffff' };
        }
        return { backgroundColor: '#ffff' }
    };

    return (
        <>
            <HeaderSection redirectType={strings.type.holiday} />
            <div className='mx-6'>
                <SubHeaderSection subHeader="Holiday List of Histogenetics" fileProps={{ columns: userState.UserID === setDefaultValue.location.value ? holiday.holidayList.columns : holiday.holidayList.USColumns, data: holidayListState.data.length > 0 ? holidayListState.data.map((val, idx) => ({ ...val, sno: idx + 1, startDate: dateFormat(val.startDate), endDate: dateFormat(val.endDate) })) : [], docName: "Holiday List of the Histogenetics" }} />
                <div className='grid  gap-x-6 gap-y-1 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-2 w-full mb-6'>
                    <DatePickerElement showYearDropdown={true} value={watch(strings.holidayList.year)} onChange={data => setValue(strings.holidayList.year, data)} maxDate={moment().add(1, "year")} isRequired isLabelView placeholder={strings.dropDowns.ReportCompliance.Year} />
                    <div className=' flex justify-center self-end gap-3'>
                        <Button value={strings.Buttons.Search} onClick={onhandleSearch} />
                        <Button value={strings.Buttons.Reset} onClick={onhandleReset} />
                    </div>
                </div>
                <AgGrid data={holidayListState.data} columns={userState.LocationID === setDefaultValue.location.value ? holiday.holidayList.columns : holiday.holidayList.USColumns} height={' lg:h-[calc(100vh-20rem)] md:h-[calc(100vh-21rem)] sm:h-[calc(100vh-18rem)] xsm:h-[calc(100vh-22rem)]'} rowStyle={setRowStyle} />
                {userState.LocationID === setDefaultValue.location.value && <div className="m-2 flex flex-wrap items-center justify-between text-14px font-bold ">
                    <div className=" flex items-center"><AddButton value={strings.Buttons.setFloatingHolidays} onClick={openFloatingHolidayPopup} /></div>
                    <ColorLegend legendList={[{ color: floatingHolidayColorCodes.optional.legendColor, name: floatingHolidayColorCodes.optional.name }, { color: floatingHolidayColorCodes.selected.legendColor, name: floatingHolidayColorCodes.selected.name }]} />
                </div>}
            </div>
            {floatingHolidayPopupState.show && <SetFloatingHolidayPopup resetHolidayDetails={onhandleSearch} />}
            {holidayListState.loader && <TransparentLoader />}
            {apiResponseState.show && <ApiResponse />}
        </>
    )
}

export default HolidayListOrganization

const initialState = {
    year: ""
}