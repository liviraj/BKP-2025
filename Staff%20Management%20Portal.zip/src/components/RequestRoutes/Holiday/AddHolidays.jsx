import { useEffect, useMemo, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import ApiResponse from "../../Alert/ApiResponse"
import { setDefaultValue, strings } from "../../Constants"
import HeaderSection from "../../layouts/HeaderSection"
import SubHeaderSection from "../../layouts/SubHeaderSection"
import TransparentLoader from "../../loader/TransparentLoader"
import { useForm } from "react-hook-form"
import Dropdown from "../../elements/Dropdown"
import DatePickerElement from "../../elements/DatePickerElement"
import Button from "../../elements/Button"
import { holiday } from "../../Grid/Columns"
import { dateFormat, employeeReducerState, exportDateFormat, exportYearFormat, numberConversion, floatingHolidayColorCodes } from "../../helper"
import moment from "moment-timezone"
import AgGrid from "../../Grid/AgGrid"
import AddButton from "../../elements/AddButton"
import { holidayActions } from "../../../redux/holidayReducer"
import CreateHolidayPopup from "../../Popup_window/CreateHolidayPopup"
import { employeeRequests, holidayRequests } from "../../requests"
import ColorLegend from "../../elements/ColorLegend"

function AddHolidays() {

    const employeeState = useSelector(state => state.employee);
    const userState = useSelector(state => state.user);
    const loginResposeState = useSelector(state => state.loginResponse);
    const addHolidayState = useSelector(state => state.holiday.addHoliday);

    const dispatch = useDispatch();

    const [loader, setLoader] = useState(false);
    const { reset, watch, setValue, getValues } = useForm({ defaultValues: initialState });
    const location = watch(strings.holidayList.location);
    const year = watch(strings.holidayList.year);

    useEffect(() => {
        const initialLoad = async () => {
            setLoader(true);
            await Promise.all([
                employeeState.location.length <= 0 && dispatch(employeeRequests.location())
            ]);
            await setInitialValue();
            setLoader(false);
        }
        initialLoad();
        return () => {
            dispatch(holidayActions.setAddHolidayPopup({ selectedRow: [] }));
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        const setAddButtonValidation = async () => {
            if (userState.LocationID === setDefaultValue.usLocation.value && addHolidayState.isEnableAddButtonforUSA) {
                if ([10, 11].includes(moment().month())) {
                    setLoader(true);
                    const params = {
                        locationId: setDefaultValue.usLocation.value,
                        year: exportYearFormat(moment().add(1, "year")),
                        employeeId: 0
                    }
                    await dispatch(holidayRequests.addHoliday.getHolidayLists(params, async (data) => {
                        if (data && data.length > 0) {
                            await dispatch(holidayActions.setIsEnableAddButtonforUSA(false));
                        }
                    }));
                    setLoader(false);
                } else if (addHolidayState.data.length > 0) {
                    dispatch(holidayActions.setIsEnableAddButtonforUSA(false));
                }
            }
        }
        setAddButtonValidation();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [addHolidayState.data, addHolidayState.isEnableAddButtonforUSA]);

    const setInitialValue = async () => {
        reset();
        await Promise.all([
            setValue(strings.holidayList.year, new Date()),
            setValue(strings.holidayList.location, employeeReducerState().location.find(val => val.value === userState.LocationID)),
        ]);
        await callAPIRequest();
    }

    const callAPIRequest = async () => {
        await setLoader(true);
        // const value = getValues();
        // if (value?.location?.value === setDefaultValue.usLocation.value) {
        //     const holiday = await usFederalHolidays(exportYearFormat(value.year))
        //     await dispatch(holidayRequests.addHoliday.postUsFederalHolidayDetails(holiday, exportYearFormat(value.year), setCallBack))
        // }
        // else {
        // }
        await setCallBack(true)
        await handleUSAHoliday();
        setLoader(false);
    }
    const setCallBack = async (status) => {
        await setLoader(true);
        const data = getValues();
        if (status && data.location?.value) {
            const params = {
                locationId: data.location.value,
                year: exportYearFormat(data.year),
                employeeId: 0
            }
            await dispatch(holidayRequests.addHoliday.getHolidayLists(params));
        }
        setLoader(false);
    }
    const onhandleReset = async () => {
        setLoader(true);
        await setInitialValue();
        setLoader(false);
    }

    const onhandleSearch = async () => {
        setLoader(true);
        await dispatch(holidayActions.setAddHolidayData([]))
        await dispatch(holidayActions.setAddHolidayPopup({ selectedRow: [] }));
        await callAPIRequest();
        setLoader(false);
    }

    const onDeleteSuccessCallBack = async () => {
        dispatch(holidayActions.setAddHolidayPopup({ show: false, action: "", selectedRecord: {} }));
        await onhandleSearch();
    }

    const openCreateHolidayPopup = () => {
        dispatch(holidayActions.setAddHolidayPopup({ show: true, action: "Add" }));
    }

    const deleteHolidayRecord = async (isAcceptable) => {
        let value = getValues()
        if (isAcceptable) {
            setLoader(true);
            const selectedRecord = addHolidayState.popup.selectedRecord;
            if (Object.keys(selectedRecord).length > 0) {
                const paramsData = {
                    id: numberConversion(selectedRecord.holidayID),
                    isExists: selectedRecord.isExists,
                    modifiedBy: userState.UserID,
                    modifiedDate: exportDateFormat(new Date()),
                    locationId: value?.location?.value
                }

                if (selectedRecord?.alternateHolidayId) {
                    dispatch(holidayActions.setYearlyFloatingHolidayOptions([]));
                }
                dispatch(holidayActions.setAddHolidayPopup({ selectedRecord: { ...selectedRecord, isExists: true } }));
                await dispatch(holidayRequests.addHoliday.deleteHoliday(selectedRecord.holidayID, paramsData, onDeleteSuccessCallBack))

            }
            setLoader(false);
        }
    }

    const setRowStyle = params => {
        if (params.data && ("isOptional" in params.data) && params.data.isOptional) {
            const isOptional = params.data.isOptional.toLowerCase().trim() === "true";
            return { background: isOptional ? floatingHolidayColorCodes.optional.color : '#ffff' };
        }
        return { backgroundColor: '#ffff' }
    };

    const handleUSAHoliday = () => {
        const location = watch(strings.holidayList.location);
        if (location && location?.value === setDefaultValue.usLocation.value) {
            setValue(strings.holidayList.isUSAView, true);
            setValue(strings.holidayList.column, holiday.AddHolidayList.USColumns(loginResposeState.isMobileCompatible));
        }
        else {
            setValue(strings.holidayList.isUSAView, false);
            setValue(strings.holidayList.column, holiday.AddHolidayList.columns(loginResposeState.isMobileCompatible));
        }
    }

    const isAddBtnDisableforUSA = useMemo(() => {
        if (userState.LocationID === setDefaultValue.usLocation.value) {
            return !addHolidayState.isEnableAddButtonforUSA;
        }
        return false;
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [addHolidayState.isEnableAddButtonforUSA]);

    return (
        <>
            <HeaderSection redirectType={strings.type.holiday} />
            <div className='mx-6'>
                <SubHeaderSection subHeader="Add Holidays" fileProps={{ columns: watch(strings.holidayList.column), data: addHolidayState.data.length > 0 ? addHolidayState.data.map((val, idx) => ({ ...val, sno: idx + 1, startDate: dateFormat(val.startDate), endDate: dateFormat(val.endDate), createdDate: dateFormat(val.createdDate), modifiedDate: dateFormat(val.modifiedDate) })) : [], docName: "Add Holidays" }} />
                <div className='grid  gap-x-6 md:gap-y-1 xsm:gap-y-4 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-2 w-full mb-6'>
                    <Dropdown options={employeeReducerState().location ? employeeReducerState().location.filter(val => val.value !== 0) : []} value={location} onChange={data => setValue(strings.holidayList.location, data)} placeholder={strings.dropDowns.Login_Roles.Location} isLabelView isDisable={userState.Role !== strings.userRoles.admin} />
                    <DatePickerElement showYearDropdown={true} value={year} onChange={data => setValue(strings.holidayList.year, data)} maxDate={moment().add(10, "years")} isRequired isLabelView placeholder={strings.dropDowns.ReportCompliance.Year} />
                    <div className=' flex justify-center self-end gap-3 xsm:col-span-full md:col-auto'>
                        <Button value={strings.Buttons.Search} onClick={onhandleSearch} />
                        <Button value={strings.Buttons.Reset} onClick={onhandleReset} />
                    </div>
                </div>
                <AgGrid data={addHolidayState.data} columns={watch(strings.holidayList.column)} height={`${watch(strings.holidayList.isUSAView) ? 'md:h-[calc(100vh-21.1rem)] sm:h-[calc(100vh-22.6rem)]' : 'md:h-[calc(100vh-20rem)] sm:h-[calc(100vh-21.4rem)]'}  xsm:h-[calc(100vh-20rem)]`} ContextMenuItems={(location && location.value === setDefaultValue.location.value && !loginResposeState.isMobileCompatible) ? holiday.AddHolidayList.contextMenuItems : false} rowStyle={setRowStyle} isSetFilter />
                <div className="m-2 flex items-center text-14px font-bold justify-between">
                    <div className=" flex items-center">
                        <AddButton value={strings.Buttons.addHoliday} disabled={isAddBtnDisableforUSA} onClick={openCreateHolidayPopup} />
                    </div>
                    {watch(strings.holidayList.isUSAView) || <ColorLegend legendList={[{ name: floatingHolidayColorCodes.optional.name, color: floatingHolidayColorCodes.optional.legendColor }]} />}
                </div>
            </div>
            {loader && <TransparentLoader />}
            {addHolidayState.popup.show && <CreateHolidayPopup callAPIService={onhandleSearch} selectYear={[10, 11].includes(moment().month()) ? new Date(moment().add(1, "year")) : new Date()} />}
            {loginResposeState.apiResponse.show && !addHolidayState.popup.show && <ApiResponse setResponseCallback={deleteHolidayRecord} />}
        </>
    )
}

export default AddHolidays

const initialState = {
    location: "",
    year: "",
    column: [],
    isUSAView: false,
    multiSelect: false
}
