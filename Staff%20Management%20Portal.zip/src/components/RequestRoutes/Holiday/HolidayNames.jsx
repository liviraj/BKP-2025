import { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import ApiResponse from "../../Alert/ApiResponse"
import { HolidayNameStatus, setDefaultValue, strings } from "../../Constants"
import HeaderSection from "../../layouts/HeaderSection"
import SubHeaderSection from "../../layouts/SubHeaderSection"
import TransparentLoader from "../../loader/TransparentLoader"
import { useForm } from "react-hook-form"
import Dropdown from "../../elements/Dropdown"
import Button from "../../elements/Button"
import AgGrid from "../../Grid/AgGrid"
import { holiday } from "../../Grid/Columns"
import AddButton from "../../elements/AddButton"
import HolidayNamePopup from "../../Popup_window/HolidayNamePopup"
import { holidayActions } from "../../../redux/holidayReducer"
import { employeeRequests, holidayRequests } from "../../requests"
import { dateFormat, employeeReducerState, exportDateFormat, numberConversion } from "../../helper"

function HolidayNames() {

    const employeeState = useSelector(state => state.employee);
    const userState = useSelector(state => state.user);
    const loginResponseState = useSelector(state => state.loginResponse);
    const holidayNameState = useSelector(state => state.holiday.holidayName);

    const dispatch = useDispatch();

    const [loader, setLoader] = useState(false);
    const { reset, watch, setValue, getValues } = useForm({ defaultValues: initialState });
    const location = watch(strings.holidayNames.location);

    useEffect(() => {
        const initialLoad = async () => {
            setLoader(true);
            employeeState.location.length <= 0 && await dispatch(employeeRequests.location());
            await onResetValue();
            setLoader(false);
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onResetValue = async () => {
        reset();
        await setValue(strings.holidayNames.location, employeeReducerState().location.find(val => val.value === userState.LocationID));
        await setValue(strings.holidayNames.status, HolidayNameStatus.find(val => val.label === setDefaultValue.status.label))
        await dispatch(holidayActions.setHolidayNameLists([]))
        await getHolidayNames();
    }

    const getHolidayNames = async () => {
        const data = getValues();
        const params = {
            locationId: data?.location?.value,
            status: data?.status?.value
        }
        await customColum()
        await dispatch(holidayRequests.holidayNameList.getHolidayNameLists(params));
    }

    const onhandleResetValue = async () => {
        setLoader(true);
        await onResetValue();
        setLoader(false);
    }

    const onhandleSearch = async () => {
        setLoader(true);
        await dispatch(holidayActions.setHolidayNameLists([]))
        await getHolidayNames();
        setLoader(false);
    }

    const addHolidayNamePopupVisibale = () => {
        dispatch(holidayActions.setHolidayNamePopup({ show: true, action: "Add" }));
    }

    const onDeleteRequest = async (isAcceptable) => {
        if (isAcceptable) {
            setLoader(true);
            const selectedRecord = holidayNameState.popup.selectedRecord;
            const data = {
                id: numberConversion(selectedRecord.holidayId),
                modifiedBy: userState.UserID,
                modifiedDate: exportDateFormat(new Date())
            }
            await dispatch(holidayRequests.holidayNameList.deleteHolidayName(selectedRecord.holidayId, data, async () => {
                await onhandleSearch();
            }));
            await dispatch(holidayActions.setHolidayNamePopup({ action: "", selectedRecord: {} }));
            dispatch(holidayActions.setAddHolidayNames([]));
            setLoader(false);
        }
    }

    const onRefresh = async () => {
        await onhandleSearch();
        dispatch(holidayActions.setAddHolidayNames([]));
    }
    const customColum = () => {
        const location = watch(strings.holidayNames.location);
        if (location) {
            if (location?.value === setDefaultValue.location.value) {
                setValue(strings.holidayNames.column, holiday.AddHolidayName.columns(loginResponseState.isMobileCompatible))
            }
            else if (location?.value === setDefaultValue.usLocation.value) {
                setValue(strings.holidayNames.column, holiday.AddHolidayName.USColumns(loginResponseState.isMobileCompatible))
            }
        }
        else {
            setValue(strings.holidayNames.column, [])
        }
    }
    return (
        <>
            <HeaderSection redirectType={strings.type.holiday} />
            <div className='px-6 md:overflow-auto h-auto md:max-h-h_body_md sm:max-h-full'>
                <SubHeaderSection subHeader={"Holiday Name List of Histogenetics"} fileProps={{ columns: watch(strings.holidayNames.column), data: holidayNameState.data.length > 0 ? holidayNameState.data.map((val, idx) => ({ ...val, sno: idx + 1, addedOn: dateFormat(val.addedOn), modifiedOn: dateFormat(val.modifiedOn) })) : [], docName: "Holiday Name List of the Histogenetics" }} />
                <div className=" grid  gap-x-6 md:gap-y-1 xsm:gap-y-4 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-2 w-full mb-6">
                    <Dropdown value={location} onChange={data => setValue(strings.holidayNames.location, data)} options={employeeState.location ? employeeState.location.filter(val => val.value != 0) : []} isRequired isDisable={userState.Role === strings.userRoles.humanResource} isLabelView placeholder={"Location"} />
                    <Dropdown value={watch(strings.holidayNames.status)} onChange={data => setValue(strings.holidayNames.status, data)} options={HolidayNameStatus} isLabelView placeholder={"Status"} />
                    <div className=' flex justify-center self-end gap-3 xsm:col-span-full md:col-auto'>
                        <Button value={strings.Buttons.Search} onClick={onhandleSearch} />
                        <Button value={strings.Buttons.Reset} onClick={onhandleResetValue} />
                    </div>
                </div>
                <AgGrid columns={watch(strings.holidayNames.column)} data={holidayNameState.data} height={" md:h-[calc(100vh-20rem)] sm:h-[calc(100vh-21.4rem)] xsm:h-[calc(100vh-20rem)]"} ContextMenuItems={loginResponseState.isMobileCompatible ? false : holiday.AddHolidayName.contextMenuItems} isSetFilter />
                <div className="flex items-center mt-3">
                    <AddButton value={strings.Buttons.addHolidayName} onClick={addHolidayNamePopupVisibale} />
                </div>
            </div>
            <>
                {loader && <TransparentLoader />}
                {loginResponseState.apiResponse.show && <ApiResponse setResponseCallback={onDeleteRequest} />}
                {holidayNameState.popup.show && <HolidayNamePopup setCallBack={onRefresh} />}
            </>
        </>
    )
}

export default HolidayNames

const initialState = {
    location: "",
    column: [],
    status: ''
}