import { useEffect, useState } from "react"
import moment from "moment-timezone"
import { setDefaultValue, strings } from "../../Constants"
import Button from "../../elements/Button"
import DatePickerElement from "../../elements/DatePickerElement"
import Dropdown from "../../elements/Dropdown"
import AgGrid from "../../Grid/AgGrid"
import HeaderSection from "../../layouts/HeaderSection"
import SubHeaderSection from "../../layouts/SubHeaderSection"
import { useDispatch, useSelector } from "react-redux"
import { useForm } from "react-hook-form"
import TransparentLoader from "../../loader/TransparentLoader"
import ApiResponse from "../../Alert/ApiResponse"
import { employeeRequests, holidayRequests } from "../../requests"
import { holidayActions } from "../../../redux/holidayReducer"
import { holiday } from "../../Grid/Columns"
import EditFloatingHolidayPopup from "../../Popup_window/EditFloatingHolidayPopup"
import { employeeReducerState, exportYearFormat } from "../../helper"

function AddFloatingHoliday() {

    const loginResponseState = useSelector(state => state.loginResponse);
    const employeeState = useSelector(state => state.employee);
    const addFloatingHolidayState = useSelector(state => state.holiday.addFloatingHolidayList);
    const dispatch = useDispatch();

    const { watch, setValue, reset, getValues } = useForm({ defaultValues: initialState });
    const [columns, setColumns] = useState(holiday.addFloatingHolidayList.columns(loginResponseState.isMobileCompatible));
    const [floatingHolidayData, setFloatingHolidayData] = useState([]);

    useEffect(() => {
        const initialLoad = async () => {
            await dispatch(holidayActions.setAddFloatingHolidayLoader(true));
            await Promise.all([
                employeeState.location.length <= 0 && dispatch(employeeRequests.location()),
                employeeState.employeeName.length <= 0 && dispatch(employeeRequests.employeeName()),
            ]);
            await setInitialValue();
            dispatch(holidayActions.setAddFloatingHolidayLoader(false));
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);


    useEffect(() => {

        if (addFloatingHolidayState.data && addFloatingHolidayState.data.length >= 0) {
            const formattedRecords = holiday.addFloatingHolidayList.convertFormattedRecords(addFloatingHolidayState.data, loginResponseState.isMobileCompatible);
            setColumns(formattedRecords.columns);
            setFloatingHolidayData(formattedRecords.data);
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [addFloatingHolidayState.data]);



    const setInitialValue = async () => {
        await Promise.all([
            setValue(strings.addFloatingHoliday.location, setDefaultValue.location),
            setValue(strings.addFloatingHoliday.year, new Date()),
            setValue(strings.addFloatingHoliday.employee, setDefaultValue.employee)
        ]);
        await getRequestCall();
    }

    const getRequestCall = async () => {
        const data = getValues();
        const params = {
            employeeId: data.employee.value,
            locationId: data.location?.value,
            year: exportYearFormat(data.year)
        };
        await dispatch(holidayRequests.addFloatingHolidays.getFloatingHolidayRecords(params));
    }

    const onhandleReset = async () => {
        dispatch(holidayActions.setAddFloatingHolidayLoader(true));
        reset();
        await setInitialValue();
        dispatch(holidayActions.setAddFloatingHolidayLoader(false));
    }

    const onhandleSearch = async () => {
        dispatch(holidayActions.setAddFloatingHolidayLoader(true));
        await getRequestCall();
        dispatch(holidayActions.setAddFloatingHolidayLoader(false));
    }

    return (
        <>
            <HeaderSection redirectType={strings.type.holiday} />
            <div className='mx-6'>
                <SubHeaderSection subHeader="Add Floating Holidays" />
                <div className='grid  gap-x-6 md:gap-y-1 xsm:gap-y-4 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-2 w-full mb-6'>
                    <Dropdown options={employeeReducerState().employeeName.length > 0 ? employeeReducerState().employeeName.filter(val => val.value === setDefaultValue.defaultLocation.value || (val.locationId === setDefaultValue.location.value && (val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation))) : []} value={watch(strings.addFloatingHoliday.employee)} onChange={data => setValue(strings.addFloatingHoliday.employee, data)} placeholder={strings.dropDowns.Employees.Name} isLabelView />
                    <DatePickerElement showYearDropdown={true} value={watch(strings.addFloatingHoliday.year)} onChange={data => setValue(strings.addFloatingHoliday.year, data)} minDate={moment("01/01/2000")} maxDate={moment().add(1, "years")} isRequired isLabelView placeholder={strings.dropDowns.ReportCompliance.Year} isRemovable={true} />
                    <div className=' flex justify-center self-end gap-3 xsm:col-span-full md:col-auto'>
                        <Button value={strings.Buttons.Search} onClick={onhandleSearch} />
                        <Button value={strings.Buttons.Reset} onClick={onhandleReset} />
                    </div>
                </div>
                <AgGrid data={floatingHolidayData} columns={columns} ContextMenuItems={loginResponseState.isMobileCompatible ? false : holiday.addFloatingHolidayList.contextMenuItems} height={'md:h-[calc(100vh-20rem)] sm:h-[calc(100vh-22rem)] xsm:h-[calc(100vh-21rem)]'} isSetFilter />
            </div>
            {addFloatingHolidayState.loader && <TransparentLoader />}
            {loginResponseState.apiResponse.show && <ApiResponse />}
            {addFloatingHolidayState.popup.show && <EditFloatingHolidayPopup resetFloatingHolidayDetails={onhandleSearch} />}
        </>
    )
}

export default AddFloatingHoliday

const initialState = {
    location: "",
    year: "",
    employee: ""
}

// Example Data for Floating Holiday Screen logic handles
// const data = [{
//     "employeeName": "Krishnan",
//     "employeeId": 1,
//     "floatingHolidays": [
//         [
//             {
//                 "holidayName": "Ramzan",
//                 "isUsed": true
//             },
//             {
//                 "holidayName": "Krishna Jayanthi",
//                 "isUsed": false
//             }
//         ],
//         [
//             {
//                 "holidayName": "Deepavali",
//                 "isUsed": false
//             },
//             {
//                 "holidayName": "Christmas",
//                 "isUsed": false
//             }
//         ]
//     ]
// }
// ];