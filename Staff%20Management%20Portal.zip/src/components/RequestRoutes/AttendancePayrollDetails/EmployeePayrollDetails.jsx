import { useForm } from "react-hook-form";
import { strings } from "../../Constants";
import HeaderSection from "../../layouts/HeaderSection";
import Dropdown from "../../elements/Dropdown";
import DatePickerElement from "../../elements/DatePickerElement";
import { attendancePayrollState, dateFormat, exportDateFormat, periodDateFormat, periodOptionsWithoutPayroll } from "../../helper";
import Button from "../../elements/Button";
import { Accordion, AccordionDetails, AccordionSummary } from "@mui/material";
import AgGrid from "../../Grid/AgGrid";
import { indiaAttendanceReport } from "../../Grid/Columns";
import SubHeaderSection from "../../layouts/SubHeaderSection";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import TransparentLoader from "../../loader/TransparentLoader";
import { attendancePayrollActions } from "../../../redux/AttendancePayrollReducer";
import { payrollRequest } from "../../requests";
import ApiResponse from "../../Alert/ApiResponse";

const EmployeePayrollDetails = () => {
    const dispatch = useDispatch()
    const { loader } = useSelector(state => state.attendancePayroll)
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const { watch, setValue, getValues } = useForm({ defaultValues: initialState })
    const onPeriodChange = (value) => {
        setValue(strings.employeePayrollDetails.period, value);
        periodDateFormat(value, setValue);
    }
    useEffect(() => {
        const initialLoad = async () => {
            await dispatch(attendancePayrollActions.setLoader(true))
            await handleReset()
            dispatch(attendancePayrollActions.setLoader(false))
        }
        initialLoad()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    const handleSearch = async () => {
        await dispatch(attendancePayrollActions.setLoader(true))
        let value = getValues();
        const params = {
            fromDate: value.fromDate ? exportDateFormat(value.fromDate, true) : "",
            toDate: value.toDate ? exportDateFormat(value.toDate, true) : ""
        }
        await dispatch(payrollRequest.employeePayrollDetailRequest(params, setCallBack));
        dispatch(attendancePayrollActions.setLoader(false))
    }
    const handleReset = async () => {
        await dispatch(attendancePayrollActions.setLoader(true))
        await onPeriodChange(periodOptionsWithoutPayroll.find((val) => val.value === 7));
        await handleSearch()
        dispatch(attendancePayrollActions.setLoader(false))
    }
    const setCallBack = async (isValid) => {
        const NewJoinee = attendancePayrollState().payrollDetail.data.NewJoinee;
        const ConfirmedDetails = attendancePayrollState().payrollDetail.data.ConfirmedDetails;
        const ProbationDetails = attendancePayrollState().payrollDetail.data.ProbationDetails;
        const EmployeeCompletingTwoYears = attendancePayrollState().payrollDetail.data.EmployeeCompletingTwoYears;
        const EmployeeWorkingOnSaturday = attendancePayrollState().payrollDetail.data.EmployeeWorkingOnSaturday;
        const ResignedDetails = attendancePayrollState().payrollDetail.data.ResignedDetails;
        if (isValid) {
            let employeePayroll = [
                { header: "New Joinees:", data: NewJoinee || [], expanded: NewJoinee?.length > 0, column: indiaAttendanceReport.employeePayrollDetails.newJoinees.columns(), height: agGridheight.threeRow },
                { header: "Confirmed Employees:", data: ConfirmedDetails || [], expanded: ConfirmedDetails?.length > 0, column: indiaAttendanceReport.employeePayrollDetails.confirmedEmployees.columns(), height: agGridheight.fiveRow },
                { header: "Probation Employee details:", data: ProbationDetails || [], expanded: ProbationDetails?.length > 0, column: indiaAttendanceReport.employeePayrollDetails.probationEmployee.columns(), height: agGridheight.threeRow },
                { header: "Employees Completing 2 years of experience:", data: EmployeeCompletingTwoYears || [], expanded: EmployeeCompletingTwoYears?.length > 0, column: indiaAttendanceReport.employeePayrollDetails.completed2Years.columns(), height: agGridheight.fiveRow },
                { header: "Employee Working On Saturday:", data: EmployeeWorkingOnSaturday || [], expanded: EmployeeWorkingOnSaturday?.length > 0, column: indiaAttendanceReport.employeePayrollDetails.workingOnSaturday.columns(), height: agGridheight.threeRow },
                { header: "Resigned Employees:", data: ResignedDetails || [], expanded: ResignedDetails?.length > 0, column: indiaAttendanceReport.employeePayrollDetails.resignedEmployee.columns(), height: agGridheight.fiveRow }]
            await dispatch(attendancePayrollActions.setPayrollDetails({ accordionData: employeePayroll }));
        }
    }
    const handleChange = async (i) => {
        const employeePayroll = attendancePayrollState().payrollDetail.accordionData?.map((val, index) => {
            if (index === i) { return { ...val, expanded: !(val.expanded) } }
            return val
        })
        await dispatch(attendancePayrollActions.setPayrollDetails({ accordionData: employeePayroll }));
    }
    return (
        <>
            <HeaderSection redirectType={strings.type.indiaAttendanceReport} />
            <div className="px-6">
                <div className='flex mb-6 md:mb-6 xsm:mb-4' >
                    <div className='grid lg:grid-rows-1 sm:grid-rows-2 xsm:grid-rows-3 gap-x-4 gap-y-1 xl:grid-cols-4 lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 xsm:grid-cols-1 w-full'>
                        <div><Dropdown placeholder={"Period"} options={periodOptionsWithoutPayroll} value={watch(strings.employeePayrollDetails.period)} onChange={e => onPeriodChange(e)} isLabelView={true} /></div>
                        <div><DatePickerElement placeholder='From' disabled={watch(strings.employeePayrollDetails.period).label !== strings.filterPeriod.custom} value={watch(strings.employeePayrollDetails.fromDate)} onChange={date => setValue(strings.employeePayrollDetails.fromDate, date)} isRequired={true} isLabelView={true} /></div>
                        <div><DatePickerElement placeholder='To' disabled={watch(strings.employeePayrollDetails.period).label !== strings.filterPeriod.custom} value={watch(strings.employeePayrollDetails.toDate)} onChange={date => setValue(strings.employeePayrollDetails.toDate, date)} minDate={watch(strings.employeePayrollDetails.period).label === strings.filterPeriod.custom && watch(strings.employeePayrollDetails.fromDate)} isRequired={true} isLabelView={true} /></div>
                        <div className=' self-end flex'>
                            <Button value={strings.Buttons.Search} onClick={handleSearch} disabled={watch(strings.leaveRequestQueue.period).label === strings.filterPeriod.custom && (!watch(strings.leaveRequestQueue.fromDate) || !watch(strings.leaveRequestQueue.toDate))} />
                            <span className=' mx-3'> <Button value={strings.Buttons.Reset} onClick={handleReset} /></span>
                        </div>
                    </div>
                </div>
                <div className=" lg:h-[calc(100vh-14rem)] h-[calc(100vh-18.5rem)] overflow-auto">
                    {
                        attendancePayrollState().payrollDetail.accordionData?.map((value, index) => (
                            <Accordion className='!m-0 !mb-1 !shadow-none !rounded-none' key={index} expanded={value.expanded} onChange={() => handleChange(index)} >
                                <AccordionSummary aria-controls="panel1a-content" id="panel1a-header" className=' !border-0 !bg-lightGrey !text-black !font-fontfamily font-bold !h-10 !max-h-10 !min-h-10'>
                                    {value.header}
                                </AccordionSummary>
                                <AccordionDetails>
                                    <SubHeaderSection subHeader={value.header.replace(":", "")} fileProps={{ columns: value.column, data: value.data.map((val, inx) => ({ ...val, sno: inx + 1, dateOfJoining: val.dateOfJoining ? dateFormat(val.dateOfJoining) : "", completionDate: val.completionDate ? dateFormat(val.completionDate) : "" })), docName: `${value.header.replace(":", '')} Details` }} headerBorder={false} />
                                    <AgGrid height={value.height} data={value.data} columns={value.column} />
                                </AccordionDetails>
                            </Accordion>
                        ))
                    }
                </div>
            </div>
            {loader && <TransparentLoader />}
            {apiResponseState.show && <ApiResponse />}
        </>
    );
};

export default EmployeePayrollDetails;

const initialState = {
    period: "",
    fromDate: "",
    toDate: "",
}

const agGridheight = {
    fiveRow: "h-[17rem] lg:h-[14rem] sm:h-[12rem]",
    threeRow: "h-[17rem] sm:h-[10rem]"
}
