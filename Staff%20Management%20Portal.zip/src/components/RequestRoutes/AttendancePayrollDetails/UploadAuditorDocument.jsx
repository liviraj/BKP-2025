import { useForm } from "react-hook-form";
import { monthOption, setDefaultValue, strings } from "../../Constants";
import HeaderSection from "../../layouts/HeaderSection";
import Dropdown from "../../elements/Dropdown";
import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import TransparentLoader from '../../loader/TransparentLoader'
import { employeeRequests, leaveManagementRequest, payrollRequest } from "../../requests";
import Button from "../../elements/Button";
import moment from "moment-timezone";
import DatePickerElement from "../../elements/DatePickerElement";
import AgGrid from "../../Grid/AgGrid";
import { indiaAttendanceReport } from "../../Grid/Columns";
import SubHeaderSection from "../../layouts/SubHeaderSection";
import ValidateLeaveBalance from "../../Popup_window/ValidateLeaveBalance";
import AddButton from "../../elements/AddButton";
import { TbUpload } from "react-icons/tb";
import { attendancePayrollActions } from "../../../redux/AttendancePayrollReducer";
import UploadAuditDocumentPopup from "../../Popup_window/UploadAuditDocumentPopup";
import ApiResponse from "../../Alert/ApiResponse";

const UploadAuditorDocument = () => {

    const dispatch = useDispatch();

    const employeeState = useSelector(state => state.employee);
    const { validateLeaveBalancePopup, loader, uploadAuditPopup, uploadAuditor } = useSelector(state => state.attendancePayroll);
    const userState = useSelector(state => state.user);
    const leaveManagementState = useSelector(state => state.leaveManagement);
    const loginResponseState = useSelector(state => state.loginResponse);
    const { watch, setValue, getValues } = useForm({ defaultValues: initialValue });
    const employeeName = watch(strings.uploadAuditDocument.employeeName);

    useEffect(() => {
        const onInitialLoad = async () => {
            await dispatch(attendancePayrollActions.setLoader(true))
            await Promise.all([
                employeeState.employeeName.length <= 0 && dispatch(employeeRequests.employeeName()),
                leaveManagementState.leaveType.length <= 0 && dispatch(leaveManagementRequest.leaveRequest.getLeaveType(userState.LocationID)),
            ])
            await onReset()
            dispatch(attendancePayrollActions.setLoader(false))
        }
        onInitialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const handleSubmit = async () => {
        await dispatch(attendancePayrollActions.setLoader(true))
        let value = getValues()
        let params = {
            employeeId: value.employeeName ? value.employeeName.value : 0,
            payRollMonth: value.payrollMonth ? value.payrollMonth.value : '',
            year: value.selectedYear ? value.selectedYear.getFullYear() : '',
            leaveTypeId: value.leaveType ? value.leaveType.value : 0
        }

        await dispatch(payrollRequest.uploadAuditorRequest(params))
        dispatch(attendancePayrollActions.setLoader(false))
    }

    const onReset = async () => {
        await dispatch(attendancePayrollActions.setLoader(true))
        setValue(strings.uploadAuditDocument.employeeName, setDefaultValue.employeeName);
        setValue(strings.uploadAuditDocument.leaveType, "");
        setValue(strings.uploadAuditDocument.payrollMonth, monthOption.find(val => val.value === 'All'));
        setValue(strings.uploadAuditDocument.selectedYear, new Date());
        await dispatch(attendancePayrollActions.setUploadAuditor({ data: [] }));
        dispatch(attendancePayrollActions.setLoader(false))
    }

    const onAuditPopupShow = () => {
        dispatch(attendancePayrollActions.setUploadAuditorDocumentPopup({ show: true, loader: false }));
    }

    return (
        <>
            <HeaderSection redirectType={strings.type.indiaAttendanceReport} />
            <div className="px-6 overflow-hidden h-auto md:max-h-h_body_md sm:max-h-full">
                <SubHeaderSection subHeader={"Auditor Document"} fileProps={{ columns: indiaAttendanceReport.uploadAuditorDocuments.columns(loginResponseState.isMobileCompatible), data: uploadAuditor.data.map((val, inx) => ({ ...val, sno: inx + 1 })), docName: 'Auditor Document' }} />
                <div className='flex mb-6 ' >
                    <div className='grid grid-rows-1 md:grid-rows-1 sm:grid-rows-2 xsm:grid-rows-3 gap-x-4 gap-y-1 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-2 w-full'>
                        <div><Dropdown placeholder={"Employee Name"} value={employeeName} onChange={e => setValue(strings.uploadAuditDocument.employeeName, e)} isSearchable={true} isLabelView={true}
                            options={employeeState.employeeName.filter((val) => ((val.locationId === 1 || val.locationId === 0 || val.label === "All") && (val.employmentStatus !== "" && val.employmentStatus !== strings.complianceReport.relieved && val.employmentStatus !== strings.complianceReport.notApplicable)))} /></div>
                        <div><DatePickerElement showYearDropdown={true} value={watch(strings.uploadAuditDocument.selectedYear)} onChange={data => setValue(strings.uploadAuditDocument.selectedYear, data)} maxDate={moment().add(10, "years")} isRequired={true} isLabelView={true} placeholder={"Select Year"} isRemovable={true} /></div>
                        <div><Dropdown placeholder={"Payroll Month"} value={watch(strings.uploadAuditDocument.payrollMonth)} options={monthOption} onChange={e => setValue(strings.uploadAuditDocument.payrollMonth, e)} isSearchable={true} isLabelView={true} /></div>
                        <div><Dropdown placeholder={"Leave Type"} value={watch(strings.uploadAuditDocument.leaveType)} options={leaveManagementState.leaveType} onChange={e => setValue(strings.uploadAuditDocument.leaveType, e)} isSearchable={true} isLabelView={true} /></div>
                        <div className=' self-end flex gap-x-3'>
                            <Button value={strings.Buttons.Search} onClick={handleSubmit} disabled={!(watch(strings.uploadAuditDocument.employeeName) && watch(strings.uploadAuditDocument.selectedYear) && watch(strings.uploadAuditDocument.payrollMonth) && watch(strings.uploadAuditDocument.leaveType))} />
                            <Button value={strings.Buttons.Reset} onClick={onReset} />
                        </div>
                    </div>
                </div>
                <div className='headerCell-FullBorder'><AgGrid data={uploadAuditor.data} columns={indiaAttendanceReport.uploadAuditorDocuments.columns(loginResponseState.isMobileCompatible)} height="h-[calc(94vh-67px-3.5rem-1.5rem-3.5rem-2rem-3rem)] lg:h-[calc(94vh-67px-3.5rem-1.5rem-3.5rem-2rem-3rem)] md:h-[calc(94vh-67px-67px-3.5rem-1.5rem-3.5rem-2rem-3rem)] xsm:h-[70vh]" ContextMenuItems={loginResponseState.isMobileCompatible ? false : indiaAttendanceReport.uploadAuditorDocuments.contextMenuItems} isUploadAuditDocumentRemoveSelectable /></div>
                <div className="m-2 flex items-center text-14px font-bold "><AddButton icon={<TbUpload size={16} className=" stroke-[2.5px]" />} value={strings.Buttons.uploadAuditDocument} onClick={onAuditPopupShow} /></div>
            </div>
            <>
                {loader && <TransparentLoader />}
                {validateLeaveBalancePopup.show && <ValidateLeaveBalance updateAuditor={handleSubmit} />}
                {uploadAuditPopup.show && <UploadAuditDocumentPopup />}
                {loginResponseState.apiResponse.show && !uploadAuditPopup.show && <ApiResponse />}
            </>
        </>
    );
};

export default UploadAuditorDocument;

const initialValue = {
    employeeName: "",
    payrollMonth: "",
    selectedYear: "",
    leaveType: ""
}
