/* eslint-disable react-hooks/exhaustive-deps */

import { useForm } from "react-hook-form";
import { colors, permissionTypes, popupType, setDefaultValue, strings } from "../../Constants";
import Label from "../../elements/Label";
import HeaderSection from "../../layouts/HeaderSection";
import SubHeaderSection from "../../layouts/SubHeaderSection";
import DatePickerElement from "../../elements/DatePickerElement";
import Dropdown from "../../elements/Dropdown";
import moment from "moment-timezone";
import TextArea from "../../elements/TextArea";
import { dateFormat, exportDateFormat, getLeaveDetails, getMinutesBetweenDates, holidayReducerState, numberConversion } from "../../helper";
import { useDispatch, useSelector } from "react-redux";
import { permissionAction } from "../../../redux/permissionReducer";
import Button from "../../elements/Button";
import { permissionRequests } from "../../requests";
import TransparentLoader from "../../loader/TransparentLoader";
import ApiResponse from "../../Alert/ApiResponse";
import { useEffect, useMemo } from "react";
import SimpleDoughnut from "../../Chart/SimpleDoughnut";

const PermissionRequest = () => {

    const dispatch = useDispatch();
    const { permissionType, loader, addPermissionPopup, permissionRequestDetails } = useSelector(state => state.permission);
    const userState = useSelector(state => state.user);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);

    const { watch, setValue, getValues, reset } = useForm({ defaultValues: initialiState });


    const leftSideStyle = "col-start-1 xl:col-end-3 lg:col-end-4 sm:col-end-6 xsm:col-end-12";
    useEffect(() => {
        const initialLoad = async () => {
            await dispatch(permissionAction.setLoader(true));
            await Promise.all([
                permissionType.length <= 0 && dispatch(permissionRequests.getPermissionType()),
                dispatch(permissionRequests.getCurrentMonthPermission(userState.UserID)),
                holidayReducerState().holidays.length <= 0 && getLeaveDetails(new Date())
            ]);
            dispatch(permissionAction.setLoader(false));
        }
        initialLoad()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onDateChange = async (date) => {
        await dispatch(permissionAction.setLoader(true));
        await getLeaveDetails(date);
        setValue(strings.addPermissionPopup.date, date);
        dispatch(permissionAction.setLoader(false));

    }



    const handleSubmit = async () => {
        await dispatch(permissionAction.setLoader(true));
        let permissionValue = getValues();
        const startTime = permissionValue.startTime && moment(permissionValue.startTime).set({ milliseconds: 0 });
        const endTime = permissionValue.endTime && moment(permissionValue.endTime).set({ milliseconds: 0 });
        let data = {
            enteredBy: userState.UserID,
            fromTime: startTime ? moment(permissionValue.date).format('YYYY-MM-DD') + " " + moment(startTime).format('HH:mm:ss.SSS') : "",
            noofHrs: startTime && endTime ? getMinutesBetweenDates(new Date(startTime), new Date(endTime)) : 0,
            permissionDate: permissionValue.date ? exportDateFormat(permissionValue.date, true) : "",
            permissionType: permissionValue.permissionType ? permissionValue.permissionType.value : "",
            remarks: permissionValue.reason,
            toTime: endTime ? moment(permissionValue.date).format('YYYY-MM-DD') + " " + moment(endTime).format('HH:mm:ss.SSS') : "",
            employeeId: permissionValue.employeeName ? permissionValue.employeeName.value : userState.UserID
        }
        await dispatch(permissionRequests.addPermissionRequest(data, async () => {
            await reset();
            await dispatch(permissionRequests.getCurrentMonthPermission(userState.UserID));
        }));
        dispatch(permissionAction.setLoader(false));
    }



    const getPermissionBalanceBack = useMemo(() => {
        let chartRecord = []
        if (permissionRequestDetails.length > 0) {

            chartRecord = permissionRequestDetails?.map(val =>
            ({
                data: [
                    { requestType: `Available ${val?.permissionAvailable}`, value: numberConversion(val?.permissionAvailable) },
                    { requestType: `Taken ${val?.permissionTaken}`, value: numberConversion(val?.permissionTaken) }
                ],
                title: "Current Month Permission",
                bgColor: colors.mildBlue
            })
            )
        }
        return chartRecord
    }, [permissionRequestDetails]);

    return (
        <>
            <HeaderSection redirectType={strings.type.permissionRequest} />
            <div className=' overflow-auto h-screen md:h-screen xsm:h-auto md:max-h-h_body_md sm:max-h-full grid grid-cols-12'>
                <div className={` col-start-1 col-end-9 lg:col-end-9 md:col-end-13 xsm:col-end-13 my-2 font-fontfamily font-bold`}>
                    <div className='mx-6'>
                        <SubHeaderSection subHeader="Permission Request" />
                        <div className='  grid grid-cols-12 xl:grid-cols-12 items-center text-14px'>
                            <div className={`${leftSideStyle} md:mt-6 xsm:mt-1 `}><Label label={"Date"} required={true} /></div>
                            <div className={`xl:col-start-3 lg:col-start-4 sm:col-start-6 xsm:col-start-1 lg:col-end-7 xl:col-end-6 xsm:col-end-12 md:mt-6 xsm:mt-1 md:mb-0 xsm:mb-3  `}>
                                <DatePickerElement value={watch(strings.addPermissionPopup.date)} onChange={onDateChange} isRequired={true} isWeekday={true} disabled={false} disableHolidays={holidayReducerState().holidays} />
                            </div>
                            <div className=' xl:col-start-6 lg:col-start-7 xsm:col-start-1 xl:col-end-9 lg:col-end-10 sm:col-end-6 xsm:col-end-12 md:mb-0 xsm:mb-3 xsm:ml-0 lg:ml-4'>
                                <DatePickerElement showTimeSelect isRequired={true} isLabelView={true} value={watch(strings.addPermissionPopup.startTime)} onChange={time => setValue(strings.addPermissionPopup.startTime, time)} disabled={false} minTime={moment().set({ hour: 9, minute: 0, seconds: 0, milliseconds: 0 })} maxTime={moment().set({ hours: 21, minutes: 0, seconds: 0, milliseconds: 0 }).toDate()} placeholder={"Start Time"} />
                            </div>
                            <div className=' xl:col-start-9 lg:col-start-10 sm:col-start-6 xsm:col-start-1 xl:col-end-13 lg:col-end-13 sm:col-end-12 xsm:col-end-12 xsm:ml-0 xl:ml-4 lg:ml-4 sm:ml-4 md:mb-0 xsm:mb-3'>
                                <DatePickerElement showTimeSelect isRequired={true} placeholder={"End Time"} isLabelView={true} value={watch(strings.addPermissionPopup.endTime)} onChange={time => setValue(strings.addPermissionPopup.endTime, time)} disabled={false} minTime={moment().set({ hour: 9, minute: 0, seconds: 0, milliseconds: 0 })} maxTime={moment().set({ hours: 21, minutes: 0, seconds: 0, milliseconds: 0 }).toDate()} />
                            </div>
                            <div className={`${leftSideStyle}  md:mt-6 xsm:mt-1`}><Label label={"Permission Type"} required={true} /></div>
                            <div className={`xl:col-start-3 lg:col-start-4 sm:col-start-6 xsm:col-start-1 lg:col-end-7 xl:col-end-6 xsm:col-end-12 md:mt-6 xsm:mt-1 md:mb-0 xsm:mb-3 `}>
                                <Dropdown value={watch(strings.addPermissionPopup.permissionType)} options={permissionType ? permissionType.filter(val => (val.value !== permissionTypes[0].value && (val.value !== permissionTypes[2].value) && (userState.LocationID === setDefaultValue.location.value ? !!(val.value !== permissionTypes[1].value) : true))) : []} onChange={e => setValue(strings.addPermissionPopup.permissionType, e)} isSearchable={true} isRequired={true} isViewable={addPermissionPopup.type === popupType.view} />
                            </div>
                            <div className={`${leftSideStyle}   xsm:mt-1 xl:h-24 lg:h-24 lg:mt-0 md:h-24  md:mt-0 sm:h-24 sm:mt-0  xl:mt-0`}><Label label={"Reason"} required={true} /></div>
                            <div className={` md:mt-6 xsm:mt-1 md:mb-0 xsm:mb-3  xl:col-start-3 lg:col-start-4 sm:col-start-6 xsm:col-start-1 xl:col-end-13 lg:col-end-13 sm:col-end-12 xsm:col-end-12 `}>
                                <TextArea value={watch(strings.addPermissionPopup.reason)} height={" !h-28 text-13px "} onChange={e => setValue(strings.addPermissionPopup.reason, e.target.value)} isRequired={true} />
                            </div>
                            <div className=' flex justify-center md:mt-6 xsm:mt-1 md:mb-0 xsm:mb-3  xl:col-start-1 lg:col-start-4 sm:col-start-1 xsm:col-start-1 xl:col-end-13 lg:col-end-13 sm:col-end-13 xsm:col-end-12  '>
                                <span className=' font-normal flex justify-center my-4 h-10 text-lg w-52 gap-x-2'>
                                    <Button value={"Apply Permission"} onClick={handleSubmit} disabled={!(watch(strings.addPermissionPopup.date) && watch(strings.addPermissionPopup.startTime) && watch(strings.addPermissionPopup.endTime) && watch(strings.addPermissionPopup.permissionType) && watch(strings.addPermissionPopup.reason))} />

                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div className='order-last lg:order-last md:order-first xsm:order-first col-start-9 lg:col-start-9 md:col-start-1 xsm:col-start-1 col-end-13 bg-pink-50 rounded h-full text-14px'>
                    {
                        permissionRequestDetails?.length > 0 && permissionRequestDetails[0]?.PermissionDate && permissionRequestDetails[0]?.ApprovalStatus &&
                        <div className='flex m-7 border-1 rounded shadow-boxShadow box-shadow border-white bg-white p-3 font-fontfamily  flex-col text-center'>
                            <div className='flex justify-center w-full font-bold '> Current Month Permission Availed</div>
                            <div className='flex flex-wrap justify-center w-full py-3 text-16px items-center'> <span className=" whitespace-nowrap"> Permission Date :</span> <span className='font-bold text-14px mx-1 whitespace-nowrap'>{dateFormat(permissionRequestDetails[0]?.PermissionDate)}</span></div>
                            <div className='flex flex-wrap justify-center w-full text-16px items-center'> <span className=" whitespace-nowrap"> Approval Status : </span><span className='font-bold text-14px mx-1 whitespace-nowrap'>{permissionRequestDetails[0]?.ApprovalStatus}</span></div>
                        </div>
                    }
                    {
                        getPermissionBalanceBack?.length > 0 && getPermissionBalanceBack.map((val) =>
                            <div className='flex m-7 border-0 rounded shadow-boxShadow box-shadow border-white bg-white font-fontfamily flex-col min-h-32 h-40 max-h-40 overflow-hidden' key={val.title}>
                                <div className={`flex justify-center w-full font-bold py-2 ${val.bgColor} rounded-t label-shadow tracking-wider`}>{val.title}</div>
                                <SimpleDoughnut data={val.data} />
                            </div>
                        )
                    }
                </div>
            </div>
            {apiResponseState.show && <ApiResponse />}
            {loader && <TransparentLoader />}
        </>
    );
};

const initialiState = {
    date: "",
    startTime: "",
    endTime: "",
    permissionType: "",
    reason: ""
}


export default PermissionRequest;