import { useDispatch, useSelector } from "react-redux";
import ApiResponse from "../../Alert/ApiResponse";
import { permissionTypes, setDefaultValue, strings } from "../../Constants";
import Button from "../../elements/Button";
import DatePickerElement from "../../elements/DatePickerElement";
import Dropdown from "../../elements/Dropdown";
import AgGrid from "../../Grid/AgGrid";
import HeaderSection from "../../layouts/HeaderSection";
import SubHeaderSection from "../../layouts/SubHeaderSection";
import TransparentLoader from "../../loader/TransparentLoader";
import AddNewPermissionPopup from "../../Popup_window/AddNewPermissionPopup";
import { useForm } from "react-hook-form";
import { useEffect, useMemo } from "react";
import { permissionAction } from "../../../redux/permissionReducer";
import { permissionRequests, employeeRequests } from "../../requests";
import { dateFormat, employeeReducerState, exportDateFormat, leaveStatus, periodDateFormat, periodOptionsWithoutPayroll, timeFormat } from "../../helper";
import AddButton from "../../elements/AddButton";
import { permission } from "../../Grid/Columns";
import PermissionRequestApprovalView from "../../Popup_window/PermissionRequestApprovalView";
import PermissionHistoryPopup from "../../Popup_window/PermissionHistoryPopup";

const ApproveRejectPermissionRequest = () => {

    const dispatch = useDispatch();
    const employeeState = useSelector(state => state.employee);
    const loginResponseState = useSelector(state => state.loginResponse);
    const userState = useSelector(state => state.user);
    const { permissionType, loader, addPermissionPopup, permissionRequestdata, requestApprovalPopup, redirectPermissionRequest, permissionHistoryPopup } = useSelector(state => state.permission);

    const { watch, setValue, getValues } = useForm({ defaultValues: initialiState });
    const location = watch(strings.ApproveRejectPermissionRequest.location);
    const period = watch(strings.ApproveRejectPermissionRequest.period);

    useEffect(() => {
        const initialLoad = async () => {
            await dispatch(permissionAction.setLoader(true));
            await Promise.all([
                permissionType.length <= 0 && await dispatch(permissionRequests.getPermissionType()),
                employeeState.employeeName.length <= 0 && dispatch(employeeRequests.employeeName()),
                employeeState.location.length <= 0 && dispatch(employeeRequests.location()),
            ]);

            await onReset();
            if (redirectPermissionRequest.show) {
                await dispatch(permissionRequests.getPermissionDetailRequest({ permissionId: redirectPermissionRequest.permissionId }, redirectPermissionRequest.status));
                await dispatch(permissionAction.setRedirectPermissionRequest({ show: false, permissionId: 0, status: "" }));
            }
            dispatch(permissionAction.setLoader(false));
        }
        initialLoad();
        return () => {
            dispatch(permissionAction.setpermissionRequestdata([]));
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onPeriodChange = (value) => {
        periodDateFormat(value, setValue);
        return value;
    }


    const employeeNameOptions = useMemo(() => {
        const employeeName = employeeState.employeeName && employeeState.employeeName.length > 0 ? employeeState.employeeName : [];
        if (employeeName.length > 0 && location) {
            const locationID = location ? location.value : userState.LocationID;
            if (locationID === setDefaultValue.defaultLocation.value) {
                return employeeName;
            }
            else if (userState.Role === strings.userRoles.superVisor) {
                return employeeName.filter(val =>
                    val.value === 0 ||
                    (val.supervisorId === userState.UserID &&
                        (val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation))
                )
            }
            return employeeName.filter(val =>
                val.value === 0 || (val.locationId === locationID &&
                    (val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation))
            )
        }
        return [];
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [location]);

    const handleLocationChange = (data) => {
        setValue(strings.ApproveRejectPermissionRequest.location, data);
        const employeeName = watch(strings.ApproveRejectPermissionRequest.employeeName);
        const permissionType = watch(strings.ApproveRejectPermissionRequest.permissionType);
        if (data.value !== setDefaultValue.defaultLocation.value && employeeName && ("locationId" in employeeName) && employeeName.locationId !== data.value) {
            setValue(strings.ApproveRejectPermissionRequest.employeeName, setDefaultValue.employeeName);
        }
        if (permissionType && permissionType.value === permissionTypes[1].value && data.value === setDefaultValue.location.value) {
            setValue(strings.permissionRequest.permissionType, setDefaultValue.permissionType);
        }
    }

    const onReset = async () => {
        await Promise.all([
            setValue(strings.ApproveRejectPermissionRequest.employeeName, setDefaultValue.employeeName),
            setValue(strings.ApproveRejectPermissionRequest.location, employeeReducerState().location.find(val => val.value === userState.LocationID)),
            onPeriodChange(periodOptionsWithoutPayroll[4]),
            setValue(strings.ApproveRejectPermissionRequest.status, leaveStatus[4]),
            setValue(strings.permissionRequest.permissionType, setDefaultValue.permissionType),
        ]);
        await onhandleFilterRequest();
    }

    const onhandleFilterRequest = async () => {
        const data = getValues();
        let params = {
            employeeId: data.employeeName ? data.employeeName.value : 0,
            locationId: data.location ? data.location.value : 0,
            permissionTypeId: data.permissionType ? data.permissionType.value : 0
        }
        if (data.status && data.status.label !== leaveStatus[0].label) {
            params = { ...params, status: data.status.Key };
        }
        if (userState.Role === strings.userRoles.superVisor) {
            params = { ...params, supervisorId: userState.UserID }
        }
        if (data.period && data.period.label !== "All") {
            params = { ...params, fromTime: exportDateFormat(data.fromDate, true), toTime: exportDateFormat(data.toDate, true) }
        }
        await dispatch(permissionRequests.getPermissionHistory(params));
    }

    const onhandleReset = async () => {
        await dispatch(permissionAction.setLoader(true));
        await onReset();
        dispatch(permissionAction.setLoader(false));
    }

    const onhandleSearch = async () => {
        await dispatch(permissionAction.setLoader(true));
        await onhandleFilterRequest();
        dispatch(permissionAction.setLoader(false));
    }

    const setCallback = async () => {
        await dispatch(permissionAction.setAddPermissionPopup({ show: false, type: '', selectedRow: [] }));
        await onhandleSearch();
    }

    return (
        <>
            <HeaderSection redirectType={strings.type.permissionRequest} />
            <div className='overflow-hidden px-6'>
                <SubHeaderSection subHeader="Approve / Reject Request" addtextStyle=" ml-3" fileProps={{ columns: permission.ApproveRejectPermissionRequest.columns(loginResponseState.isMobileCompatible), data: permissionRequestdata && permissionRequestdata.length > 0 ? permissionRequestdata.map((val, idx) => ({ ...val, sno: idx + 1, fromTime: val.fromTime ? timeFormat(val.fromTime) : "", toTime: val.toTime ? timeFormat(val.toTime) : "", permissionDate: val.permissionDate ? dateFormat(val.permissionDate) : "" })) : [], docName: "Approve And Reject Permission Request", isPortraitView: true }} />
                <div className='flex mb-6 md:mb-6 xsm:mb-4' >
                    <div className='grid xl:grid-rows-1 lg:grid-rows-2 md:grid-rows-2 sm:grid-rows-3 xsm:grid-rows-3 gap-x-4 gap-y-1 xl:grid-cols-4 lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 xsm:grid-cols-1 w-full'>
                        <div><Dropdown placeholder={"Period"} options={periodOptionsWithoutPayroll} value={period} onChange={e => onPeriodChange(e)} isLabelView={true} /></div>
                        <div><DatePickerElement placeholder='From' disabled={period && period.label !== strings.filterPeriod.custom} value={watch(strings.ApproveRejectPermissionRequest.fromDate)} onChange={date => setValue(strings.ApproveRejectPermissionRequest.fromDate, date)} isRequired={true} isLabelView={true} /></div>
                        <div><DatePickerElement placeholder='To' disabled={period && period.label !== strings.filterPeriod.custom} value={watch(strings.ApproveRejectPermissionRequest.toDate)} onChange={date => setValue(strings.ApproveRejectPermissionRequest.toDate, date)} minDate={watch(strings.ApproveRejectPermissionRequest.period).label === strings.filterPeriod.custom && watch(strings.ApproveRejectPermissionRequest.fromDate)} isRequired={true} isLabelView={true} /></div>
                        <div><Dropdown placeholder={"Location"} value={location} options={employeeState.location} onChange={data => handleLocationChange(data)} isLabelView={true} isDisable={userState.Role !== strings.userRoles.admin} /></div>
                        <div><Dropdown placeholder={"Employee Name"} value={watch(strings.ApproveRejectPermissionRequest.employeeName)} options={employeeNameOptions} onChange={e => setValue(strings.ApproveRejectPermissionRequest.employeeName, e)} isSearchable={true} isLabelView={true} /></div>
                        <div><Dropdown placeholder={"Permission Type"} value={watch(strings.ApproveRejectPermissionRequest.permissionType)} options={permissionType?.length > 0 ? (location && location.value === setDefaultValue.location.value ? permissionType.filter(val => val.value !== permissionTypes[1].value) : permissionType) : []} onChange={e => setValue(strings.ApproveRejectPermissionRequest.permissionType, e)} isLabelView={true} /></div>
                        <div><Dropdown placeholder={"Status"} value={watch(strings.ApproveRejectPermissionRequest.status)} options={leaveStatus.filter(val => val.label !== leaveStatus[3].label)} onChange={status => setValue(strings.ApproveRejectPermissionRequest.status, status)} isLabelView={true} /></div>
                        <div className=' self-end flex'>
                            <Button value={strings.Buttons.Search} disabled={!(((period && period.label === strings.filterPeriod.custom) ? (watch(strings.ApproveRejectPermissionRequest.fromDate) && watch(strings.ApproveRejectPermissionRequest.toDate)) : true)) && location && watch(strings.ApproveRejectPermissionRequest.employeeName) && watch(strings.ApproveRejectPermissionRequest.permissionType) && watch(strings.ApproveRejectPermissionRequest.status)} onClick={onhandleSearch} />
                            <span className=' mx-3'> <Button value={strings.Buttons.Reset} onClick={() => onhandleReset()} /></span>
                        </div>
                    </div>
                </div>
                <AgGrid data={permissionRequestdata || []} columns={permission.ApproveRejectPermissionRequest.columns(loginResponseState.isMobileCompatible)} ContextMenuItems={loginResponseState.isMobileCompatible ? false : permission.ApproveRejectPermissionRequest.contextMenuItems} height={'h-[calc(94vh-67px-67px-3.5rem-1.5rem-3.5rem-4.6rem)] lg:h-[calc(94vh-67px-67px-3.5rem-1.5rem-3.5rem-4.6rem-0.5rem)] md:h-[calc(94vh-67px-67px-67px-3.5rem-1.5rem-3.5rem-4.6rem-0.5rem)] xsm:h-[58vh]'} />
                <div className="mx-2 flex flex-row items-center font-fontfamily text-14px font-bold my-3 text-darkGrey" > <AddButton value={strings.Buttons.addPermission} onClick={() => { dispatch(permissionAction.setAddPermissionPopup({ show: true })) }} /> </div>
            </div>
            {loader && <TransparentLoader />}
            {loginResponseState.apiResponse.show && !requestApprovalPopup.show && <ApiResponse />}
            {addPermissionPopup.show && <AddNewPermissionPopup setCallback={setCallback} />}
            {requestApprovalPopup.show && <PermissionRequestApprovalView onSubmit={onhandleSearch} />}
            {permissionHistoryPopup.show && <PermissionHistoryPopup />}
        </>
    );
};

const initialiState = {
    period: "",
    fromDate: "",
    toDate: "",
    location: setDefaultValue.usLocation,
    employeeName: "",
    permissionType: "",
    status: ""
}
export default ApproveRejectPermissionRequest;