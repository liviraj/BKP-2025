import DatePickerElement from "../../elements/DatePickerElement";
import Dropdown from "../../elements/Dropdown";
import SubHeaderSection from "../../layouts/SubHeaderSection";
import { useForm } from "react-hook-form";
import { permissionTypes, setDefaultValue, strings } from "../../Constants";
import { useDispatch, useSelector } from "react-redux";
import { dateFormat, exportDateFormat, leaveStatus, periodDateFormat, periodOptionsWithoutPayroll, permissionReducerState, timeFormat, userReducerState } from "../../helper";
import { useEffect } from "react";
import AgGrid from "../../Grid/AgGrid";
import { permission } from "../../Grid/Columns";
import Button from "../../elements/Button";
import { leaveManagementRequest, permissionRequests } from "../../requests";
import { permissionAction } from "../../../redux/permissionReducer";
import TransparentLoader from "../../loader/TransparentLoader";
import HeaderSection from "../../layouts/HeaderSection";
import ApiResponse from "../../Alert/ApiResponse";
import AddNewPermissionPopup from "../../Popup_window/AddNewPermissionPopup";
import PermissionRequestApprovalView from "../../Popup_window/PermissionRequestApprovalView";

const PermissionHistory = () => {
    const dispatch = useDispatch();
    const userState = useSelector(state => state.user);
    const leaveManagementState = useSelector(state => state.leaveManagement);
    const { permissionType, loader, addPermissionPopup, permissionRequestdata, requestApprovalPopup } = useSelector(state => state.permission);
    const { watch, setValue, getValues } = useForm({ defaultValues: initialiState });
    const loginResponseState = useSelector(state => state.loginResponse);

    useEffect(() => {
        const initialLoad = async () => {
            await dispatch(permissionAction.setLoader(true));
            permissionType.length <= 0 && await dispatch(permissionRequests.getPermissionType());
            leaveManagementState.leaveStatus.length <= 0 && await dispatch(leaveManagementRequest.leaveStatus.getLeaveStatus());
            await onReset();
            dispatch(permissionAction.setLoader(false));
        }
        initialLoad();
        return () => {
            dispatch(permissionAction.setpermissionRequestdata([]));
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    const onReset = async () => {
        await dispatch(permissionAction.setLoader(true));
        await onPeriodChange(periodOptionsWithoutPayroll.find((val) => val.value === 1));
        await setValue(strings.permissionRequest.permissionType, permissionReducerState().permissionType && permissionReducerState().permissionType.length > 0 ? permissionReducerState().permissionType[0] : []);
        await setValue(strings.permissionRequest.status, leaveStatus[4]);
        await handleSearch();
        dispatch(permissionAction.setLoader(false));
    }
    const onPeriodChange = (value) => {
        setValue(strings.permissionRequest.period, value);
        periodDateFormat(value, setValue);
    }
    const handleSearch = async () => {
        await dispatch(permissionAction.setLoader(true));
        const data = getValues();
        let params = {
            employeeId: userReducerState().UserID,
            locationId: userReducerState().LocationID,
            permissionTypeId: data.permissionType ? data.permissionType.value : 0
        }
        if (data.status && data.status.label !== leaveStatus[0].label) {
            params = { ...params, status: data.status.Key };
        }
        if (data.period && data.period.label !== "All") {
            params = { ...params, fromTime: exportDateFormat(data.fromDate, true), toTime: exportDateFormat(data.toDate, true) }
        }
        await dispatch(permissionRequests.getPermissionHistory(params));
        dispatch(permissionAction.setLoader(false));
    }

    const setCallback = async () => {
        await dispatch(permissionAction.setAddPermissionPopup({ show: false, type: '', selectedRow: [] }));
        await handleSearch();
    }

    return (
        <>
            <HeaderSection redirectType={strings.type.permissionRequest} />
            <div className='overflow-hidden px-6'>
                <SubHeaderSection subHeader="Permission History" addtextStyle=" ml-3" fileProps={{ columns: permission.permissionRequest.columns(loginResponseState.isMobileCompatible), data: permissionRequestdata.map((val, idx) => ({ ...val, sno: idx + 1, fromTime: val.fromTime ? timeFormat(val.fromTime) : "", toTime: val.toTime ? timeFormat(val.toTime) : "", permissionDate: val.permissionDate ? dateFormat(val.permissionDate) : "" })), docName: "Permission History", isPortraitView: true }} />
                <div className='flex mb-5' >
                    <div className='grid lg:grid-rows-2 md:grid-rows-3 sm:grid-rows-3 gap-x-4 gap-y-1 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-3 w-full'>
                        <div><Dropdown placeholder={"Period"} options={periodOptionsWithoutPayroll} value={watch(strings.permissionRequest.period)} onChange={e => onPeriodChange(e)} isLabelView={true} /></div>
                        <div><DatePickerElement placeholder='From' disabled={watch(strings.permissionRequest.period).label !== strings.filterPeriod.custom} value={watch(strings.permissionRequest.fromDate)} onChange={date => setValue(strings.permissionRequest.fromDate, date)} isRequired={true} isLabelView={true} /></div>
                        <div><DatePickerElement placeholder='To' disabled={watch(strings.permissionRequest.period).label !== strings.filterPeriod.custom} value={watch(strings.permissionRequest.toDate)} onChange={date => setValue(strings.permissionRequest.toDate, date)} minDate={watch(strings.permissionRequest.period).label === strings.filterPeriod.custom && watch(strings.permissionRequest.fromDate)} isRequired={true} isLabelView={true} /></div>
                        <div><Dropdown placeholder={"Permission Type"} value={watch(strings.permissionRequest.permissionType)} options={permissionType ? permissionType.filter(val => (userState.LocationID === setDefaultValue.location.value ? (val.value !== permissionTypes[1].value) : true)) : []} onChange={e => setValue(strings.permissionRequest.permissionType, e)} isLabelView={true} /></div>
                        <div><Dropdown placeholder={"Status"} value={watch(strings.permissionRequest.status)} options={leaveStatus.filter(val => val.label !== leaveStatus[3].label)} onChange={status => setValue(strings.permissionRequest.status, status)} isLabelView={true} /></div>
                        <div className=' col-span-full flex justify-center self-end gap-3'>
                            <Button value={strings.Buttons.Search} disabled={!(((watch(strings.permissionRequest.period).label === strings.filterPeriod.custom ? (watch(strings.permissionRequest.fromDate) && watch(strings.permissionRequest.toDate)) : true)) && watch(strings.permissionRequest.permissionType) && watch(strings.permissionRequest.status))} onClick={handleSearch} />
                            <Button value={strings.Buttons.Reset} onClick={() => onReset()} />
                        </div>
                    </div>
                </div>
                <AgGrid data={permissionRequestdata} columns={permission.permissionRequest.columns(loginResponseState.isMobileCompatible)} ContextMenuItems={loginResponseState.isMobileCompatible ? false : permission.permissionRequest.contextMenuItems} height={'h-[calc(94vh-67px-67px-3.5rem-1.5rem-3.5rem-4.6rem)] lg:h-[calc(94vh-67px-67px-3.5rem-1.5rem-3.5rem-4.6rem-0.5rem)] md:h-[calc(94vh-67px-67px-67px-3.5rem-1.5rem-3.5rem-4.6rem-0.5rem)] xsm:h-[58vh]'} />

            </div>
            {loader && <TransparentLoader />}
            {loginResponseState.apiResponse.show && <ApiResponse />}
            {requestApprovalPopup.show && <PermissionRequestApprovalView onSubmit={handleSearch} />}
            {addPermissionPopup.show && <AddNewPermissionPopup isEmployeeRequest={true} setCallback={setCallback} />}
        </>
    );
};

const initialiState = {
    period: "",
    fromDate: "",
    toDate: "",
    permissionType: "",
    status: ""
}

export default PermissionHistory;