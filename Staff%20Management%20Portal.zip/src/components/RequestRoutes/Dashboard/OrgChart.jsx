import { Tooltip } from '@mui/material';
import moment from 'moment-timezone';
import PropTypes from 'prop-types';
import { useEffect } from 'react';
import { ReactHiererchyChart } from 'react-hierarchy-chart';
import { dateFormat } from '../../helper';

const OrgChart = ({ nodes }) => {
    const filteredNodes = nodes.filter((node) => node.reportingTo !== null);
    useEffect(() => {
        const linesContainers = document.querySelectorAll('.children-container .children-container-vertical .lines-container');
        linesContainers.forEach((container) => {
            container.style.display = 'none';
        });
    }, [])

    const getOrgDetail = (node) => {
        return <div className=' bg-[#616872] p-5 text-white border-2 rounded-md text-15px font-normal text-center w-[220px]'>
            <div className='flex justify-center items-center '> {node?.empImg && <div className="w-[150px] h-[160px] overflow-hidden rounded-md " ><img src={`data:image/jpeg/png;base64,${node?.empImg}`} alt='#' className=' w-full h-full' /></div>}</div>
            <p className=' pt-2 pb-1'>{node.employeeName}</p>
            <p>{node.designationName}</p>
            <div className='py-1'><span>Date Of Hire : </span><span>{dateFormat(node.dateOfJoin)}</span></div>
            <p>{calculateExperience(node.dateOfJoin)}</p>
        </div>
    }
    return <ReactHiererchyChart nodes={filteredNodes} direction='vertical'
        randerNode={(node) => {
            return <Tooltip title={getOrgDetail(node)} describeChild disableTouchListener
                componentsProps={{
                    tooltip: {
                        sx: {
                            bgcolor: 'transparent',
                            margin: 0,
                            padding: 0,
                            borderRadius: 5,
                            borderWidth: 2,
                            border: "solid",
                            borderColor: "transparent"
                        },
                    },
                }} >
                <div className="node-template">
                    <div className="title bg-headerColor py-1 px-1 font-bold text-white flex items-center justify-center text-center " >{node.designationName} </div>
                    <div className="flex items-center  py-1 px-1 card-chart" >
                        <div> {node?.empImg && <div className="chart-img rounded-full overflow-hidden mr-2" ><img src={`data:image/jpeg/png;base64,${node?.empImg}`} alt='#' /></div>}</div>
                        <div> {node.employeeName} </div>
                    </div>
                </div>
            </Tooltip>
        }} />
}

const calculateExperience = (date) => {
    if (moment(date).isValid()) {
        const now = moment();
        const startDate = moment(date);
        const years = now.diff(startDate, "years");
        startDate.add(years, "years");
        const months = now.diff(startDate, "months");
        startDate.add(months, "months");
        const days = now.diff(startDate, "days");
        const yearTxt = years === 1 ? " Year " : " Years ";
        const monthTxt = months === 1 ? " Month " : " Months ";
        const dayTxt = days === 1 ? " Day " : " Days ";
        if (years > 0) {
            return years + yearTxt + months + monthTxt;
        } else if (months > 0) {
            return months + monthTxt;
        } else if (days) {
            return days + dayTxt;
        }
    }
    return ""
}
export default OrgChart;

OrgChart.propTypes = {
    nodes: PropTypes.array,
}