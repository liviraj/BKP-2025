import AgGrid from "../../Grid/AgGrid";
import { useForm } from "react-hook-form";
import Button from "../../elements/Button";
import Dropdown from "../../elements/Dropdown";
import ApiResponse from "../../Alert/ApiResponse";
import { EmployeeRequest } from "../../Grid/Columns";
import { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import HeaderSection from "../../layouts/HeaderSection";
import { setDefaultValue, strings } from "../../Constants";
import SubHeaderSection from "../../layouts/SubHeaderSection";
import TransparentLoader from "../../loader/TransparentLoader";
import DatePickerElement from "../../elements/DatePickerElement";
import { employeeRequests, leaveManagementRequest } from "../../requests";
import { periodDateFormat, periodOptions, exportDateFormat, employeeReducerState } from "../../helper";

function DashboardEmployeeRequest() {

    const employeeState = useSelector(state => state.employee);
    const leaveManagementState = useSelector(state => state.leaveManagement);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const { leaveAndPermissionHistory } = useSelector(state => state.employeeDashboard);
    const dispatch = useDispatch()

    const { watch, setValue, getValues } = useForm({ defaultValues: initialState });
    const employeeName = watch(strings.employeeRequest.employeeName);

    const [loader, setLoader] = useState(false);

    useEffect(() => {
        const fetchValues = async () => {
            setLoader(true);
            await Promise.all([
                employeeState.employeeName.length <= 0 && dispatch(employeeRequests.employeeName()),
                Object.keys(leaveManagementState.payroll).length <= 0 && dispatch(leaveManagementRequest.getPayroll())
            ]);
            await onReset();
            setLoader(false);
        }
        fetchValues();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onPeriodChange = (value) => {
        setValue(strings.employeeRequest.period, value);
        periodDateFormat(value, setValue);
        return value
    }

    const onSubmit = async () => {
        const data = getValues()
        await setLoader(true);
        const params = {
            employeeId: data.employeeName.employeeId,
            fromDate: exportDateFormat(data.fromDate, true),
            toDate: exportDateFormat(data.toDate, true),
        }
        await dispatch(employeeRequests.getEmployeeLeaveAndPermissionHistory(params));
        setLoader(false);
    }

    const onReset = async () => {
        setLoader(true);
        await Promise.all([
            setValue(strings.employeeRequest.employeeName, employeeReducerState().employeeName.length > 0 ? employeeReducerState().employeeName.find(val => val.value === setDefaultValue.employeeName.value) : []),
            onPeriodChange(periodOptions.find((val) => val.value === 7))
        ]);
        await onSubmit();
        setLoader(false);
    }

    const employeeNameOptions = useMemo(() => {
        return employeeState.employeeName.filter((val) => (val.value === setDefaultValue.employeeName.value) || ((val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation) && val.locationId === setDefaultValue.location.value));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [employeeState.employeeName]);

    return (
        <div>
            <HeaderSection redirectType={strings.type.dashboard} />
            <div className='px-6 lg:overflow-hidden md:overflow-auto xsm:overflow-hidden h-auto md:max-h-h_body_md sm:max-h-full' >
                <SubHeaderSection subHeader="Employee Request" />
                <div className='flex mb-6 md:mb-6 xsm:mb-4 ' >
                    <div className='grid grid-rows-1 md:grid-rows-1 sm:grid-rows-2 xsm:grid-rows-3 gap-x-4 gap-y-1 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-2 w-full'>
                        <div><Dropdown placeholder={"Period"} options={periodOptions} value={watch(strings.employeeRequest.period)} onChange={e => onPeriodChange(e)} isLabelView={true} /></div>
                        <div><DatePickerElement placeholder='From' disabled={watch(strings.employeeRequest.period).label !== strings.filterPeriod.custom} value={watch(strings.employeeRequest.fromDate) ? watch(strings.employeeRequest.fromDate) : ""} onChange={date => setValue(strings.employeeRequest.fromDate, date)} isRequired={true} isLabelView={true} /></div>
                        <div><DatePickerElement placeholder='To' disabled={watch(strings.employeeRequest.period).label !== strings.filterPeriod.custom} value={watch(strings.employeeRequest.toDate) ? watch(strings.employeeRequest.toDate) : ""} minDate={watch(strings.employeeRequest.period).label === strings.filterPeriod.custom && watch(strings.employeeRequest.fromDate)} onChange={date => setValue(strings.employeeRequest.toDate, date)} isRequired={true} isLabelView={true} /></div>
                        <div><Dropdown placeholder={"Employee Name"} value={employeeName} options={employeeNameOptions} onChange={e => setValue(strings.employeeRequest.employeeName, e)} isSearchable={true} isLabelView={true} /></div>
                        <div className=' self-end flex'>
                            <Button value={strings.Buttons.Search} onClick={() => onSubmit()} disabled={watch(strings.employeeRequest.period).label === strings.filterPeriod.custom && (!watch(strings.employeeRequest.fromDate) || !watch(strings.employeeRequest.toDate))} />
                            <span className=' mx-3'> <Button value={strings.Buttons.Reset} onClick={() => onReset()} /></span>
                        </div>
                    </div>
                </div>
                <div className="headerCell-FullBorder">
                    <AgGrid height="h-[calc(94vh-67px-3.5rem-1.5rem-3.5rem-2rem)] lg:h-[calc(94vh-67px-3.5rem-1.5rem-3.5rem-2rem)] md:h-[calc(94vh-67px-67px-3.5rem-1.5rem-3.5rem-2rem)] xsm:h-[70vh]" data={leaveAndPermissionHistory} columns={EmployeeRequest.EmployeeRequestColumns} />
                </div>
            </div>
            {loader && <TransparentLoader />}
            {apiResponseState.show && <ApiResponse />}
        </div>
    )
}

export default DashboardEmployeeRequest;

const initialState = {
    period: "",
    fromDate: "",
    toDate: "",
    employeeName: ""
}


