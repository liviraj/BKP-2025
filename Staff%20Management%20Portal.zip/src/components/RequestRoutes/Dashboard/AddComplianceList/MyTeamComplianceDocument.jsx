import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { employeeRequests } from "../../../requests";
import { complianceCourseType, setDefaultValue, strings } from "../../../Constants";
import { exportDateFormat, userReducerState } from "../../../helper";
import HeaderSection from "../../../layouts/HeaderSection";
import Label from "../../../elements/Label";
import { addComplianceList } from "../../../Grid/Columns";
import AgGrid from "../../../Grid/AgGrid";
import TransparentLoader from "../../../loader/TransparentLoader";
import ImageViewer from "../../../ViewDocs/ImageViewer";
import MultiImageViewer from "../../../ViewDocs/MultiImageViewer";
import ApiResponse from "../../../Alert/ApiResponse";
import Dropdown from "../../../elements/Dropdown";
import DatePickerElement from "../../../elements/DatePickerElement";
import UploadAndDeleteDocument from "../../../elements/UploadAndDeleteDocument";
import CheckBox from "../../../elements/CheckBox";
import Button from "../../../elements/Button";
import TextField from "../../../elements/TextField";

const MyTeamComplianceDocument = () => {
    const gridSectionLabel = "col-start-1 col-end-4 lg:col-end-3 md:col-end-4 sm:col-end-6 xsm:col-end-6";
    const gridSectionValue = `col-start-5 col-end-10 lg:col-end-6 md:col-end-13 sm:col-end-13 xsm:col-end-13 lg:col-start-3 md:col-start-7 sm:col-start-7 xsm:col-start-7`;
    const loginResponseState = useSelector(state => state.loginResponse);
    const employeeState = useSelector(state => state.employee);
    const userState = useSelector(state => state.user);
    const { handleSubmit, watch, setValue, reset, getValues } = useForm({ defaultValues: initialState });
    const [loader, setLoader] = useState(false);
    const [selectedRecord, setSelectedRecord] = useState({});
    const [disable, setDisable] = useState(true);
    const [employeeOptions, setEmployeeOptions] = useState([])
    const dispatch = useDispatch();

    useEffect(() => {
        const initialState = async () => {
            await setLoader(true);
            await Promise.all([
                employeeState.nysCompliancePeriod.length <= 0 && dispatch(employeeRequests.getCompliancePeriod()),
                employeeState.nysComplianceCategory.length <= 0 && dispatch(employeeRequests.getComplianceCategory()),
                employeeState.employeeName.length <= 0 && dispatch(employeeRequests.employeeName()),
            ]);
            setLoader(false);
        }
        initialState();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        setEmployeeOptions(filterEmployeeName(employeeState.employeeName ? employeeState.employeeName : []));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [employeeState.employeeName]);
    
    const filterEmployeeName = (employeeName) => {
        if (userReducerState().Role === strings.userRoles.superVisor && employeeName.length > 0) {
            return employeeName.filter((val) =>
                (val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation) &&
                (val.supervisorId === userReducerState().UserID || val.employeeId === userReducerState().UserID)
            );
        }
        else if ((userReducerState().Role === strings.userRoles.admin || userReducerState().Role === strings.userRoles.humanResource) && employeeName.length > 0) {
            return employeeName.filter((val) =>
                val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation)
        }
        return [];
    }
    
    const onReset = async () => {
        await setLoader(true);
        const data = watch(strings.myTeamComplianceDocuments.data);
        const employeeName = watch(strings.myTeamComplianceDocuments.employeeName);
        await reset();
        await setValue(strings.myTeamComplianceDocuments.data, data);
        await setValue(strings.myTeamComplianceDocuments.employeeName, employeeName);
        handleDisable()
        setLoader(false);
    }
    
    const onLoad = async () => {
        const value = getValues();
        await setLoader(true);
        await dispatch(employeeRequests.getNysComplianceDetails(value.employeeName.employeeId, async (isValid, data) => {
            if (isValid) {
                handleDisable()
                await setValue(strings.myTeamComplianceDocuments.data, data);
            }
        }));
        setLoader(false);
    }
    const setComplianceCategoryUpdate = (value) => {
        setValue(strings.myTeamComplianceDocuments.complianceCategory, value);
        setValue(strings.myTeamComplianceDocuments.compliancePeriod, {});
        setValue(strings.myTeamComplianceDocuments.compliancePeriodOptions, employeeState?.nysCompliancePeriod?.filter(val => value?.compliancePeriodIds?.some(id => id === val.value)));
    }

    const selectedDataUpdate = async (selectedData) => {
        const complianceCategory = selectedData.complianceCategoryID > 0 ? employeeState?.nysComplianceCategory.find(val => val.value === selectedData.complianceCategoryID) : {};
        await Promise.all([
            setValue(strings.myTeamComplianceDocuments.employeeName, employeeOptions.find(val => val.employeeId === selectedData.employeeID)),
            setValue(strings.myTeamComplianceDocuments.complianceCategory, complianceCategory ? complianceCategory : {}),
            setValue(strings.myTeamComplianceDocuments.compliancePeriod, selectedData.compliancePeriod.length > 0 ? employeeState?.nysCompliancePeriod.find(val => val.label === selectedData.compliancePeriod) : {}),
            setValue(strings.myTeamComplianceDocuments.complianceDate, selectedData.complianceDate.length > 0 ? new Date(selectedData.complianceDate) : ""),
            setValue(strings.myTeamComplianceDocuments.description, selectedData.description),
            setValue(strings.myTeamComplianceDocuments.expiryDate, selectedData?.expiryDate?.length > 0 ? new Date(selectedData.expiryDate) : ""),
            setValue(strings.myTeamComplianceDocuments.documentImage, selectedData.documentDetails && selectedData.documentDetails.length > 0 ? selectedData.documentDetails.map(val => {
                const { documentName, documentBinary, ...rest } = val;
                return { ...rest, name: documentName, binary: documentBinary };
            }) : []),
            setValue(strings.myTeamComplianceDocuments.data, watch(strings.myTeamComplianceDocuments.data)),
            setValue(strings.myTeamComplianceDocuments.selectedData, { ...selectedData }),
            setValue(strings.myTeamComplianceDocuments.compliancePeriodOptions, employeeState?.nysCompliancePeriod?.filter(val => complianceCategory?.compliancePeriodIds?.some(id => id === val.value))),
            setValue(strings.myTeamComplianceDocuments.noExpiry, !(selectedData?.expiryDate && selectedData.expiryDate?.length > 0))
        ]);
        if (Object.values(watch(strings.myTeamComplianceDocuments.employeeName)).length > 0) {
            handleDisable()
        }
    }

    const onSubmit = async (data) => {
        const selectedData = watch(strings.myTeamComplianceDocuments.selectedData);
        await setLoader(true);
        let complianceRequestRecords = {
            complianceCategoryID: Object.keys(data.complianceCategory).length > 0 ? data.complianceCategory.value : 0,
            complianceDate: exportDateFormat(data.complianceDate, true),
            compliancePeriod: Object.keys(data.compliancePeriod).length > 0 ? data.compliancePeriod.label : "",
            createdBy: userState.UserID,
            description: data.description,
            documentImage: "",
            documentName: "",
            employeeID: Object.keys(data.employeeName).length > 0 ? data.employeeName.employeeId : 0,
            expiryDate: exportDateFormat(data.expiryDate, true),
            authenticateUserRole: userState.Role
        }
        if (Object.keys(selectedData).length <= 0) {
            complianceRequestRecords = { ...complianceRequestRecords, documentDetails: data.documentImage?.length > 0 ? data.documentImage.map(val => ({ documentName: val.name, documentBinary: val.binary, recordStatus: "A" })) : [] }
            await dispatch(employeeRequests.createNysComplianceRecords(complianceRequestRecords, setCallBack));
        } else {
            let documentLists = data.documentImage.length > 0 ? data.documentImage.filter(val => Object.keys(val).length <= 2).map(val => ({ documentName: val.name, documentBinary: val.binary, recordStatus: "A" })) : [];
            if (selectedData?.documentDetails?.length > 0) {
                const documentId = data.documentImage.map(val => ("id" in val) ? val.id : 0)
                let deletedDocs = selectedData.documentDetails.filter(val => !documentId.includes(val.id));
                if (deletedDocs?.length > 0) {
                    deletedDocs = deletedDocs.map(val => {
                        // eslint-disable-next-line no-unused-vars
                        const { documentName, documentBinary, ...rest } = val;
                        return { ...rest, recordStatus: "D" }
                    })
                    documentLists = [...documentLists, ...deletedDocs];
                }
            }
            complianceRequestRecords = { ...complianceRequestRecords, documentDetails: documentLists }
            await dispatch(employeeRequests.updateNysComplianceRecords(selectedData.employeeComplianceId, complianceRequestRecords, setCallBack));
        }
        setLoader(false);
    }
    
    const setAction = async (selectedData) => {
        await setLoader(true);
        await dispatch(employeeRequests.getNysComplianceData(selectedData.employeeComplianceId, async (isValid, data) => {
            if (isValid) {
                await selectedDataUpdate({ ...data, employeeComplianceId: selectedData.employeeComplianceId });
                await onLoad();
            }
        }));
        setLoader(false);
    }

    const setCallBack = async (isValid) => {
        if (isValid) await onLoad(); await onReset();
    }

    const handleDeleteConfirmation = async (isAccepted) => {
        if (isAccepted) {
            setLoader(true);
            const userInfo = {
                modifiedBy: userState.UserID,
                modifiedDate: exportDateFormat(new Date())
            }
            await dispatch(employeeRequests.deleteNysComplianceRecord(selectedRecord.employeeComplianceId, userInfo, setCallBack));
            setLoader(false);
        }
        setSelectedRecord({});
    }

    const handleReset = () => {
        reset();
        handleDisable();
    }

    const handleDisable = () => {
        Object.values(watch(strings.myTeamComplianceDocuments.employeeName)).length > 0 ? setDisable(false) : setDisable(true);
    }

    const handleEmployeeName = (value) => {
        reset();
        setValue(strings.myTeamComplianceDocuments.employeeName, value);
        setValue(strings.myTeamComplianceDocuments.data, []);
    }
    
    return (
        <div>
            <HeaderSection redirectType={strings.type.addComplianceList} />
            <div>
                <div className='pt-4  overflow-auto h-auto md:max-h-h_body_md sm:max-h-full'>
                    <div className={"font-fontfamily font-bold text-14px grid grid-cols-2 lg:grid-cols-1 md:grid-cols-1 sm:grid-cols-1 xsm:grid-cols-1"}>
                        <div className="grid grid-cols-12 my-2 gap-y-3 items-center pb-5 border-b-1 border-gray-400 px-6">
                            <span className={gridSectionLabel}> <Label label="Employee Name" required={true} /></span>
                            <span className={gridSectionValue} > <Dropdown value={watch(strings.myTeamComplianceDocuments.employeeName)} onChange={value => handleEmployeeName(value)} options={employeeOptions} isRequired={true} /></span>
                            <div className="lg:ml-5 lg:col-start-6 col-end-13 col-start-1 ">
                                <div className=" flex gap-3"><Button value={strings.Buttons.Submit} onClick={() => onLoad()} disabled={!watch(strings.myTeamComplianceDocuments.employeeName)} /> <Button value={strings.Buttons.CustomClear} onClick={() => handleReset()} /></div>
                            </div>
                        </div>
                        <fieldset className={`grid grid-cols-12 my-2 gap-y-3 items-center px-6`} disabled={disable}>
                            <span className={gridSectionLabel}> <Label label="Compliance Category" required={true} isDisable={disable} /></span> <span className={gridSectionValue} ><Dropdown value={watch(strings.myTeamComplianceDocuments.complianceCategory)} onChange={value => setComplianceCategoryUpdate(value)} options={employeeState?.nysComplianceCategory.filter(val => val.complianceType === complianceCourseType.Course || val.complianceType === complianceCourseType.Training)} isRequired={true} isDisable={disable} /></span>
                            <span className={gridSectionLabel}> <Label label="Compliance Period" required={true} isDisable={disable} /></span> <span className={gridSectionValue} ><Dropdown isDisable={Object.keys(watch(strings.myTeamComplianceDocuments.complianceCategory)).length <= 0 || disable} value={watch(strings.myTeamComplianceDocuments.compliancePeriod)} onChange={value => setValue(strings.myTeamComplianceDocuments.compliancePeriod, value)} options={watch(strings.myTeamComplianceDocuments.compliancePeriodOptions)} isRequired={true} /></span>
                            <span className={gridSectionLabel}> <Label label="Compliance Date" required={true} isDisable={disable} /></span> <span className={gridSectionValue} ><DatePickerElement value={watch(strings.myTeamComplianceDocuments.complianceDate)} onChange={date => setValue(strings.myTeamComplianceDocuments.complianceDate, date)} maxDate={watch(strings.myTeamComplianceDocuments.expiryDate)} isRequired={true} disabled={disable} /></span>
                            <span className={gridSectionLabel}> <Label label="Description" required={true} isDisable={disable} /></span> <span className={gridSectionValue} ><TextField value={watch(strings.myTeamComplianceDocuments.description)} onChange={e => setValue(strings.myTeamComplianceDocuments.description, e.target.value)} isRequired={true} disabled={disable} /></span>
                            <span className={gridSectionLabel}> <Label label="Expiry Date" required={!watch(strings.myTeamComplianceDocuments.noExpiry)} isDisable={disable} /></span> <span className={gridSectionValue} ><DatePickerElement value={watch(strings.myTeamComplianceDocuments.expiryDate)} onChange={date => setValue(strings.myTeamComplianceDocuments.expiryDate, date)} minDate={watch(strings.myTeamComplianceDocuments.complianceDate)} isRequired={true} disabled={!!watch(strings.myTeamComplianceDocuments.noExpiry) || disable} /></span>
                            <span className='col-end-6 sm:col-end-4 lg:col-start-6 lg:col-end-9 xl:col-end-8 col-start-1 lg:ml-10'> <CheckBox data={[{ label: "No Expiry" }]} value={watch(strings.myTeamComplianceDocuments.noExpiry)} onChange={e => { setValue(strings.myTeamComplianceDocuments.noExpiry, e.target.checked); setValue(strings.myTeamComplianceDocuments.expiryDate, '') }} isDisable={disable} /></span>
                            <span className={gridSectionLabel}> <Label label="Certificate Image" isDisable={disable} /></span> <span className={gridSectionValue} ><UploadAndDeleteDocument label={"Choose File"} file={watch(strings.myTeamComplianceDocuments.documentImage)} onChange={file => setValue(strings.myTeamComplianceDocuments.documentImage, file)} isMultiDocument isDisable={disable} /></span>
                        </fieldset>
                    </div>
                    <div className=' flex justify-center items-center gap-x-3 my-3 lg:my-3 md:my-1 sm:my-0 xsm:my-0 px-6'>
                        <Button value={Object.keys(watch(strings.myTeamComplianceDocuments.selectedData)).length > 0 ? strings.Buttons.Update : strings.Buttons.Save} disabled={!(watch(strings.myTeamComplianceDocuments.complianceCategory) && Object.keys(watch(strings.myTeamComplianceDocuments.compliancePeriod)).length > 0 && watch(strings.myTeamComplianceDocuments.complianceDate) && watch(strings.myTeamComplianceDocuments.description) && (watch(strings.myTeamComplianceDocuments.noExpiry) ? true : watch(strings.myTeamComplianceDocuments.expiryDate)))} onClick={handleSubmit(onSubmit)} />
                        <Button value={strings.Buttons.Reset} onClick={() => onReset()} disabled={disable} />
                    </div>
                    <div className=" px-6"><AgGrid data={watch(strings.myTeamComplianceDocuments.data)} columns={addComplianceList.myTeamComplianceList(setLoader, loginResponseState.isMobileCompatible, setAction)} height=" md:h-[calc(93vh-41rem)] xsm:h-[21.5rem]" ContextMenuItems={loginResponseState.isMobileCompatible ? false : addComplianceList.complianceRequest_contextMenuItems} callBack={setAction} maxScrollCount={4} /></div>
                </div>
            </div>
            {loader && <TransparentLoader />}
            {!loginResponseState.multiDocumentViewer.show && loginResponseState.imageViewer.show && <ImageViewer />}
            {loginResponseState.multiDocumentViewer.show && <MultiImageViewer />}
            {loginResponseState.apiResponse.show && <ApiResponse setResponseCallback={handleDeleteConfirmation} />}
        </div>
    );
};

export default MyTeamComplianceDocument;

const initialState = {
    employeeName: "",
    complianceCategory: {},
    compliancePeriod: {},
    complianceDate: "",
    expiryDate: "",
    description: "",
    documentImage: [],
    data: [],
    selectedData: {},
    compliancePeriodOptions: [],
    noExpiry: false
}