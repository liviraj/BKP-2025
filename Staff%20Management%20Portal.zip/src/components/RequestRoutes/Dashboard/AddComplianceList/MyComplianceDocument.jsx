import HeaderSection from '../../../layouts/HeaderSection';
import { complianceCourseType, strings } from '../../../Constants';
import { useForm } from 'react-hook-form';
import Label from '../../../elements/Label';
import Dropdown from '../../../elements/Dropdown';
import DatePickerElement from '../../../elements/DatePickerElement';
import TextField from '../../../elements/TextField';
import CheckBox from '../../../elements/CheckBox';
import UploadAndDeleteDocument from '../../../elements/UploadAndDeleteDocument';
import { useDispatch, useSelector } from 'react-redux';
import Button from '../../../elements/Button';
import AgGrid from '../../../Grid/AgGrid';
import { addComplianceList } from '../../../Grid/Columns';
import { useEffect, useState } from 'react';
import { employeeRequests } from '../../../requests';
import { exportDateFormat } from '../../../helper';
import TransparentLoader from '../../../loader/TransparentLoader';
import MultiImageViewer from '../../../ViewDocs/MultiImageViewer';
import ApiResponse from '../../../Alert/ApiResponse';
import ImageViewer from '../../../ViewDocs/ImageViewer';
export default function MyComplianceDocument() {

    const gridSectionLabel = "col-start-1 col-end-4 lg:col-end-3 md:col-end-4 sm:col-end-6 xsm:col-end-6";
    const gridSectionValue = `col-start-5 col-end-10 lg:col-end-6 md:col-end-13 sm:col-end-13 xsm:col-end-13 lg:col-start-3 md:col-start-7 sm:col-start-7 xsm:col-start-7`;
    const loginResponseState = useSelector(state => state.loginResponse);
    const employeeState = useSelector(state => state.employee);
    const userState = useSelector(state => state.user);
    const { handleSubmit, watch, setValue, reset } = useForm({ defaultValues: initialState });
    const [loader, setLoader] = useState(false);
    const dispatch = useDispatch();

    useEffect(() => {
        const initialState = async () => {
            await setLoader(true);
            await Promise.all([
                employeeState.nysCompliancePeriod.length <= 0 && dispatch(employeeRequests.getCompliancePeriod()),
                employeeState.nysComplianceCategory.length <= 0 && dispatch(employeeRequests.getComplianceCategory())
            ]);
            await onLoad();
            setLoader(false);
        }
        initialState();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onLoad = async () => {
        await dispatch(employeeRequests.getNysComplianceDetails(userState.UserID, async (isValid, data) => {
            if (isValid) {
                await setValue(strings.complianceRequest.data, data);
            }
        }));
    }

    const setComplianceCategoryUpdate = (value) => {
        setValue(strings.complianceRequest.complianceCategory, value);
        setValue(strings.complianceRequest.compliancePeriod, {});
        setValue(strings.complianceRequest.compliancePeriodOptions, employeeState?.nysCompliancePeriod?.filter(val => value?.compliancePeriodIds?.some(id => id === val.value)));
    }

    const resetRecords = async () => {
        const data = watch(strings.complianceRequest.data);
        await reset();
        await setValue(strings.complianceRequest.data, data);
    }

    const onSubmit = async (data) => {
        const selectedData = watch(strings.complianceRequest.selectedData);
        await setLoader(true);
        let complianceRequestRecords = {
            complianceCategoryID: Object.keys(data.complianceCategory).length > 0 ? data.complianceCategory.value : 0,
            complianceDate: exportDateFormat(data.complianceDate, true),
            compliancePeriod: Object.keys(data.compliancePeriod).length > 0 ? data.compliancePeriod.label : "",
            createdBy: userState.UserID,
            description: data.description,
            documentImage: "",
            documentName: "",
            employeeID: userState.UserID,
            expiryDate: exportDateFormat(data.expiryDate, true),
            authenticateUserRole: userState.Role
        }
        if (Object.keys(selectedData).length <= 0) {
            complianceRequestRecords = { ...complianceRequestRecords, documentDetails: data.documentImage?.length > 0 ? data.documentImage.map(val => ({ documentName: val.name, documentBinary: val.binary, recordStatus: "A" })) : [] }
            await dispatch(employeeRequests.createNysComplianceRecords(complianceRequestRecords, setCallBack));
        } else {
            let documentLists = data.documentImage.length > 0 ? data.documentImage.filter(val => Object.keys(val).length <= 2).map(val => ({ documentName: val.name, documentBinary: val.binary, recordStatus: "A" })) : [];
            if (selectedData?.documentDetails?.length > 0) {
                const documentId = data.documentImage.map(val => ("id" in val) ? val.id : 0)
                let deletedDocs = selectedData.documentDetails.filter(val => !documentId.includes(val.id));
                if (deletedDocs?.length > 0) {
                    deletedDocs = deletedDocs.map(val => {
                        // eslint-disable-next-line no-unused-vars
                        const { documentName, documentBinary, ...rest } = val;
                        return { ...rest, recordStatus: "D" }
                    })
                    documentLists = [...documentLists, ...deletedDocs];
                }
            }
            complianceRequestRecords = { ...complianceRequestRecords, documentDetails: documentLists }
            await dispatch(employeeRequests.updateNysComplianceRecords(selectedData.employeeComplianceId, complianceRequestRecords, setCallBack));
        }
        setLoader(false);
    }

    const setCallBack = async (isValid) => {
        if (isValid) {
            await resetRecords();
            await onLoad();
        }
    }

    return (
        <div>
            <HeaderSection redirectType={strings.type.addComplianceList} />
            <div>
                <div className='pt-4 px-6 overflow-auto h-auto md:max-h-h_body_md sm:max-h-full'>
                    <div className={"font-fontfamily font-bold text-14px grid grid-cols-2 lg:grid-cols-1 md:grid-cols-1 sm:grid-cols-1 xsm:grid-cols-1"}>
                        <fieldset className={`grid grid-cols-12 my-2 gap-y-3 items-center`}>
                            <span className={gridSectionLabel}> <Label label="Compliance Category" required={true} /></span> <span className={gridSectionValue} ><Dropdown value={watch(strings.complianceRequest.complianceCategory)} onChange={value => setComplianceCategoryUpdate(value)} options={employeeState?.nysComplianceCategory.filter(val => val.complianceType === complianceCourseType.Course)} isRequired={true} /></span>
                            <span className={gridSectionLabel}> <Label label="Compliance Period" required={true} /></span> <span className={gridSectionValue} ><Dropdown isDisable={Object.keys(watch(strings.complianceRequest.complianceCategory)).length <= 0} value={watch(strings.complianceRequest.compliancePeriod)} onChange={value => setValue(strings.complianceRequest.compliancePeriod, value)} options={watch(strings.complianceRequest.compliancePeriodOptions)} isRequired={true} /></span>
                            <span className={gridSectionLabel}> <Label label="Compliance Date" required={true} /></span> <span className={gridSectionValue} ><DatePickerElement value={watch(strings.complianceRequest.complianceDate)} onChange={date => setValue(strings.complianceRequest.complianceDate, date)} maxDate={watch(strings.complianceRequest.expiryDate)} isRequired={true} /></span>
                            <span className={gridSectionLabel}> <Label label="Description" required={true} /></span> <span className={gridSectionValue} ><TextField value={watch(strings.complianceRequest.description)} onChange={e => setValue(strings.complianceRequest.description, e.target.value)} isRequired={true} /></span>
                            <span className={gridSectionLabel}> <Label label="Expiry Date" required={!watch(strings.complianceRequest.noExpiry)} /></span> <span className={gridSectionValue} ><DatePickerElement value={watch(strings.complianceRequest.expiryDate)} onChange={date => setValue(strings.complianceRequest.expiryDate, date)} minDate={watch(strings.complianceRequest.complianceDate)} isRequired={true} disabled={!!watch(strings.complianceRequest.noExpiry)} /></span>
                            <span className='col-end-6 sm:col-end-4 lg:col-start-6 lg:col-end-9 xl:col-end-8 col-start-1 lg:ml-10'> <CheckBox data={[{ label: "No Expiry" }]} value={watch(strings.complianceRequest.noExpiry)} onChange={e => { setValue(strings.complianceRequest.noExpiry, e.target.checked); setValue(strings.complianceRequest.expiryDate, '') }} /></span>
                            <span className={gridSectionLabel}> <Label label="Certificate Image" /></span> <span className={gridSectionValue} ><UploadAndDeleteDocument label={"Choose File"} file={watch(strings.complianceRequest.documentImage)} onChange={file => setValue(strings.complianceRequest.documentImage, file)} isMultiDocument /></span>
                        </fieldset>
                    </div>
                    <div className=' flex justify-center items-center gap-x-3 my-3 lg:my-3 md:my-1 sm:my-0 xsm:my-0'>
                        <Button value={Object.keys(watch(strings.complianceRequest.selectedData)).length > 0 ? strings.Buttons.Update : strings.Buttons.Save} disabled={!(watch(strings.complianceRequest.complianceCategory) && Object.keys(watch(strings.complianceRequest.compliancePeriod)).length > 0 && watch(strings.complianceRequest.complianceDate) && watch(strings.complianceRequest.description) && (watch(strings.complianceRequest.noExpiry) ? true : watch(strings.complianceRequest.expiryDate)))} onClick={handleSubmit(onSubmit)} />
                        <Button value={strings.Buttons.Reset} onClick={() => resetRecords()} />
                    </div>
                    <AgGrid data={watch(strings.complianceRequest.data)} columns={addComplianceList.addComplianceList(setLoader, loginResponseState.isMobileCompatible)} height=" md:h-[calc(93vh-36rem)] xsm:h-[21.5rem]" maxScrollCount={4} />
                </div>
            </div>
            {loader && <TransparentLoader />}
            {!loginResponseState.multiDocumentViewer.show && loginResponseState.imageViewer.show && <ImageViewer />}
            {loginResponseState.multiDocumentViewer.show && <MultiImageViewer />}
            {loginResponseState.apiResponse.show && <ApiResponse />}
        </div>
    )
}

const initialState = {
    complianceCategory: {},
    compliancePeriod: {},
    complianceDate: "",
    expiryDate: "",
    description: "",
    documentImage: [],
    data: [],
    selectedData: {},
    compliancePeriodOptions: [],
    noExpiry: false
}