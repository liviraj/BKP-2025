
import HeaderSection from "../../layouts/HeaderSection"
import { classNames, setDefaultValue, strings } from "../../Constants";
import { BsPersonSquare } from "react-icons/bs";
import AgGrid from "../../Grid/AgGrid";
import { employeeDetails } from "../../Grid/Columns";
import ViewEmployeeChart from "../../Popup_window/ViewEmployeeChart";
import { useEffect, useMemo, useState } from "react";
import { employeeServices } from "../../services";
import { useDispatch, useSelector } from "react-redux";
import TransparentLoader from "../../loader/TransparentLoader";
import { dateFormat } from "../../helper";
import { employeeRequests, userRequest } from "../../requests";
import ImageViewer from "../../ViewDocs/ImageViewer";
import ApiResponse from "../../Alert/ApiResponse";
import moment from "moment-timezone";


function EmployeeDashboard() {

    const dispatch = useDispatch();
    const loginResponseState = useSelector(state => state.loginResponse);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const userState = useSelector(state => state.user);
    const { employeeDashboardDetails, employeeLeaveDetails, birthDayDetails } = useSelector(state => state.employeeDashboard);
    const empSelector = useSelector(state => state.user)

    const [openChart, setOpenChart] = useState(false);
    const [empData, setEmpData] = useState(initialEmployeeDetails(userState.LocationID === setDefaultValue.usLocation.value));
    const [chartData, setChartData] = useState([]);
    const [loader, setLoader] = useState(false);

    const labelClass = classNames.grid.gridSplitFirst_4Cols;
    const valueClass = classNames.grid.gridSplitLast_7Cols;

    useEffect(() => {
        const initialState = async () => {
            await setLoader(true);

            await Promise.all([
                (userState.Role === strings.userRoles.admin || userState.Role === strings.userRoles.humanResource ? true : employeeDashboardDetails?.length <= 0) && dispatch(employeeRequests.getEmployeeDashboardInfo(empSelector.UserID)),
                birthDayDetails?.length <= 0 && dispatch(employeeRequests.getEmployeeBirthdayDetails(empSelector.LocationID)),
                employeeLeaveDetails?.length <= 0 && dispatch(employeeRequests.getEmployeeleaveDetails(empSelector.LocationID)),
            ])
            setLoader(false);
        }
        initialState();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const formattedEmployee = (employeeDetails) => {
        const employeeRecordDetails = [
            { label: strings.employeeDashboard.name, value: employeeDetails?.employeeName || '', id: employeeDetails?.employeeId || '' },
            { label: strings.employeeDashboard.designation, value: employeeDetails?.designationName || '' },
            { label: strings.employeeDashboard.department, value: employeeDetails?.departmentName || '' },
            { label: strings.employeeDashboard.dateofJoining, value: employeeDetails?.dateOfJoining ? dateFormat(employeeDetails.dateOfJoining) : '' },
            { label: strings.employeeDashboard.reportingTo, value: employeeDetails?.reportingToEmpName || '', id: employeeDetails?.reportingToEmpId || '' }
        ];
        const usReportDetails = [{ label: strings.employeeDashboard.supervisor, value: employeeDetails?.departmentSupervisorEmpName || '', id: employeeDetails?.reportingToEmpId || '' }];
        return userState.LocationID === setDefaultValue.usLocation.value ? [...employeeRecordDetails, ...usReportDetails] : [...employeeRecordDetails];
    };

    useEffect(() => {
        if (employeeDashboardDetails?.length > 0) {
            const employeeDetails = employeeDashboardDetails[0];
            setEmpData(formattedEmployee(employeeDetails));
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [employeeDashboardDetails])

    const employeeData = [
        { header: "Employee Birthday Details", columns: employeeDetails.Birthday_Details(), data: birthDayDetails?.length > 0 ? birthDayDetails : [] },
        { header: "Employee Leave Details", columns: employeeDetails.Leave_Details(), data: employeeLeaveDetails?.length > 0 ? employeeLeaveDetails : [] },
    ];

    // eslint-disable-next-line no-unused-vars
    const handleViewChart = async (data) => {
        await setLoader(true);
        await employeeServices.getEmpChartData(data?.id).then(res => {
            const data = modifiedData(res?.data?.data);
            if (data && data.length > 0) {
                setChartData(data);
                setOpenChart(true);
            }
        })
        setLoader(false);
    }

    const modifiedData = (datas) => {
        datas.supervisorDetails.forEach((sup) => {
            sup.childs = [];
            datas.employeeDetails.forEach((empVal) => {
                empVal.childs = [];
                if (sup.employeeId == empVal.reportingTo) {
                    sup?.childs?.push(empVal);
                }
                datas.teamMember.forEach((teamVal) => {
                    if (empVal.employeeId == teamVal.reportingTo) {
                        empVal?.childs?.push(teamVal);
                    }
                });
                if (empVal.childs.length === 0) {
                    delete empVal.childs;
                }
            });
            if (sup.childs.length === 0) {
                delete sup.childs;
            }
        });
        return datas.supervisorDetails;
    }
    const handleClickImage = () => {
        dispatch(userRequest.imageViewer({ show: true, data: employeeDashboardDetails && employeeDashboardDetails.length > 0 ? employeeDashboardDetails[0]?.employeeImage : "", imageName: employeeDashboardDetails && employeeDashboardDetails.length > 0 ? employeeDashboardDetails[0]?.employeeImageName : "" }))
    }

    const employeeRequestSummary = useMemo(() => {
        if (employeeDashboardDetails.length > 0) {
            const employeeLeaveDetails = employeeDashboardDetails[0]
            if (userState?.LocationID === setDefaultValue.usLocation.value) {
                return [
                    { label: "Sick Leaves Taken", value: employeeLeaveDetails?.totalSlCount },
                    { label: "Vacation Leaves Taken", value: employeeLeaveDetails?.totalVlCount },
                    { label: "Permissions Taken", value: employeeLeaveDetails?.totalPermissionCount },
                ];
            } else {
                return [
                    { label: "Sick Leaves Taken", value: employeeLeaveDetails?.totalSlCount },
                    { label: "Privilege Leaves Taken", value: employeeLeaveDetails?.totalplCount },
                    { label: "Casual Leaves Taken", value: employeeLeaveDetails?.totalClCount },
                    { label: "Permissions Taken", value: employeeLeaveDetails?.totalPermissionCount },
                    { label: "WFH Taken", value: employeeLeaveDetails?.totalWfhCount },
                ];
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [employeeDashboardDetails]);


    return (

        <> <div>
            <HeaderSection redirectType={strings.type.dashboard} />
            <div className='overflow-auto h-screen md:h-screen xsm:h-auto md:max-h-h_body_md sm:max-h-full text-14px  '>
                <div className='px-6  h-auto md:max-h-h_body_md sm:max-h-full'>
                    <div className="font-fontfamily pt-3 pb-2 text-14px ">
                        <div className="grid grid-cols-12 gap-2 lg:gap-4 ">
                            <div className="grid col-start-1 lg:col-end-4 md:col-end-13 sm:col-end-5 col-end-13 gap-y-2 items-center">
                                <span className='flex w-full h-full justify-center items-center mt-4 pb-6'> {employeeDashboardDetails?.length > 0 && employeeDashboardDetails[0]?.employeeImage && employeeDashboardDetails[0]?.employeeImageName ?
                                    <span className=" cursor-pointer" onClick={handleClickImage}><img className=' h-40 w-40 rounded mx-auto' src={`data:image/jpeg/png;base64,${employeeDashboardDetails[0]?.employeeImage}`} alt='#' /></span>
                                    : <BsPersonSquare size={160} color='#c6362e' />}</span>
                            </div>

                            <div className={`grid lg:col-start-4 xl:col-end-9 lg:col-end-11 md:col-start-1 sm:col-start-5 col-start-1 col-end-13  items-center font-fontfamily ${userState.LocationID === setDefaultValue.location.value ? " md:my-5" : ""}  text-14px`}>
                                {empData.map((val) => {
                                    return <div key={val.label} className={classNames.grid.gridCols12}>
                                        <span className={labelClass}>{val.label} <span >: </span></span>
                                        <span className={`${valueClass}`}>  <span className={` font-bold ${(val.label == strings.employeeDashboard.name || val.label == strings.employeeDashboard.reportingTo || val.label == strings.employeeDashboard.supervisor) ? 'text-blue-600 underline cursor-pointer' : ''}  `} onClick={() => val.label == strings.employeeDashboard.name || val.label == strings.employeeDashboard.supervisor || val.label == strings.employeeDashboard.reportingTo ? handleViewChart(val) : {}} >{val.value}</span></span>
                                    </div>
                                })
                                }
                            </div>
                            <div className='order-last xl:order-last xsm:order-last col-start-9 xl:col-start-9 md:col-start-1 xsm:col-start-1 col-end-13 bg-pink-50 rounded h-full'>
                                <div className='flex m-7 border-1 rounded shadow-boxShadow box-shadow border-white bg-white p-3 font-fontfamily flex-col min-h-36  '>
                                    <div className='flex justify-center w-full font-bold mb-1'>{`Employee Request Summary  ( ${moment().year()} )`}</div>
                                    {
                                        employeeRequestSummary?.map((val) => {
                                            return <div key={val.label} className={`${classNames.grid.gridCols12} leading-7`}>
                                                <span className='col-start-1 col-end-4 md:col-start-1 md:col-end-8 sm:col-end-6 xsm:col-end-8 flex justify-between'>{val.label} <span >: </span></span>
                                                <span className='col-start-5 xl:col-start-8  col-end-13 md:col-start-8 sm:col-start-6 xsm:col-start-8 pl-2'>  <span className={` font-bold  `} >{val.value}</span></span>
                                            </div>
                                        })
                                    }
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="font-fontfamily text-14px grid grid-cols-1  lg:grid-cols-1 md:grid-cols-1 sm:grid-cols-1">
                        <div className="grid grid-cols-1 ">
                            <div className="grid grid-cols-1  items-center font-fontfamily  text-14px">
                                {
                                    employeeData.map((value) => (
                                        <div className='!m-0 !mb-3 !shadow-none !rounded-none' key={value.header} >
                                            <div aria-controls="panel1a-content" id="panel1a-header" className='flex items-center px-3 !border-0 !bg-lightGrey !text-black !font-fontfamily font-bold !h-10 !max-h-10 !min-h-10'>
                                                {value.header}
                                            </div>
                                            <AgGrid columns={value.columns} data={value.data} isAutoHeight height="mt-2 h-[10rem] min-h-[12rem] max-h-[13rem] " />
                                        </div>
                                    ))
                                }
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div >

            <ViewEmployeeChart open={openChart} setOpenChart={setOpenChart} nodes={chartData} />
            {loader && <TransparentLoader />}
            {loginResponseState.imageViewer.show && <ImageViewer />}
            {apiResponseState.show && <ApiResponse />}
        </>
    )
}

export default EmployeeDashboard;

const initialEmployeeDetails = (isUSA) => {
    const employeeRecordDetails = [
        { label: strings.employeeDashboard.name, value: '', id: '' },
        { label: strings.employeeDashboard.designation, value: '' },
        { label: strings.employeeDashboard.department, value: '' },
        { label: strings.employeeDashboard.dateofJoining, value: '' },
        { label: strings.employeeDashboard.reportingTo, value: '', id: '' }
    ];
    const usReportDetails = [{ label: strings.employeeDashboard.supervisor, value: '', id: '' }];
    return isUSA ? [...employeeRecordDetails, ...usReportDetails] : [...employeeRecordDetails];
}

