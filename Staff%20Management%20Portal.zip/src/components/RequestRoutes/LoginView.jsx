import { useEffect, useReducer } from 'react';
import SubHeaderSection from '../layouts/SubHeaderSection';
import Dropdown from '../elements/Dropdown';
import Button from '../elements/Button';
import { routerPath, setDefaultValue, strings } from '../Constants';
import AgGrid from '../Grid/AgGrid';
import { loginDetails } from '../Grid/Columns';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { loginRequest, loginUserRequest } from '../requests';
import TransparentLoader from '../loader/TransparentLoader';
import ApiResponse from '../Alert/ApiResponse';
import { exportDateFormat, loginFilterInitialState, loginInitialState, loginReducerState } from '../helper';
import AddButton from '../elements/AddButton';

function LoginView() {

  const history = useHistory();
  const reduxDispatch = useDispatch();
  let currentState = JSON.parse(sessionStorage.getItem("loginState"));
  const [state, dispatch] = useReducer(reducer, currentState);
  const loginState = useSelector(state => state.login);
  const userState = useSelector(state => state.user);
  const loginResponseState = useSelector(state => state.loginResponse);

  useEffect(() => {
    const fetchData = async () => {
      await reduxDispatch(loginRequest.loader(true));
      await Promise.all([
        loginState.status.length <= 0 && reduxDispatch(loginRequest.status()),
        loginState.location.length <= 0 && reduxDispatch(loginRequest.location()),
        loginState.loginID.length <= 0 && reduxDispatch(loginRequest.loginId()),
        loginState.roles.length <= 0 && reduxDispatch(loginRequest.roles()),
        loginState.employeeName.length <= 0 && reduxDispatch(loginRequest.employeeName())
      ]);
      await sessionStorage.setItem("loginFilterState", sessionStorage.getItem("loginModifyFilterState"));
      await Promise.all([
        state.login === "" && dispatch({ type: strings.Login_Roles.login, data: loginReducerState().employeeName.length > 0 && loginReducerState().employeeName.find(val => val.employeeId === setDefaultValue.employee.value) }),
        state.status === "" && dispatch({ type: strings.Login_Roles.status, data: loginReducerState().status.length > 0 && loginReducerState().status.find(val => val.value === setDefaultValue.status.value) }),
        state.location === "" && dispatch({ type: strings.Login_Roles.location, data: loginReducerState().location.length > 0 && loginReducerState().location.find(val => val.value === userState.LocationID) }),
        state.mappingStatus === "" && dispatch({ type: strings.Login_Roles.mappingStatus, data: loginReducerState().loginID.length > 0 && loginReducerState().loginID.find(val => val.label === setDefaultValue.mappingStatus.label) }),
        state.role === "" && dispatch({ type: strings.Login_Roles.role, data: loginReducerState().roles.length > 0 && loginReducerState().roles.find(val => val.value === setDefaultValue.roles.value) }),
      ]);
      await reduxDispatch(loginRequest.tableDatas());
      await reduxDispatch(loginRequest.loader(false));
    };
    fetchData();
    return () => { sessionStorage.setItem("loginModifyFilterState", sessionStorage.getItem("loginFilterState")) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onClick = async () => {
    await reduxDispatch(loginRequest.loader(true));
    sessionStorage.setItem("loginFilterState", sessionStorage.getItem("loginModifyFilterState"));
    await reduxDispatch(loginRequest.tableDatas());
    sessionStorage.setItem("loginState", JSON.stringify(state));
    await reduxDispatch(loginRequest.loader(false));
  }
  const onReset = async () => {
    await reduxDispatch(loginRequest.loader(true));
    await sessionStorage.setItem("loginState", JSON.stringify(loginInitialState));
    await sessionStorage.setItem("loginModifyFilterState", JSON.stringify(loginFilterInitialState));
    await Promise.all([
      dispatch({ type: strings.Buttons.Reset }),
      dispatch({ type: strings.Login_Roles.login, data: loginReducerState().employeeName.length > 0 && loginReducerState().employeeName.find(val => val.employeeId === setDefaultValue.employee.value) }),
      dispatch({ type: strings.Login_Roles.status, data: loginReducerState().status.length > 0 && loginReducerState().status.find(val => val.value === setDefaultValue.status.value) }),
      dispatch({ type: strings.Login_Roles.location, data: loginReducerState().location.length > 0 && loginReducerState().location.find(val => val.value === userState.LocationID) }),
      dispatch({ type: strings.Login_Roles.mappingStatus, data: loginReducerState().loginID.length > 0 && loginReducerState().loginID.find(val => val.label === setDefaultValue.mappingStatus.label) }),
      dispatch({ type: strings.Login_Roles.role, data: loginReducerState().roles.length > 0 && loginReducerState().roles.find(val => val.value === setDefaultValue.roles.value) }),
    ]);
    await sessionStorage.setItem("loginFilterState", sessionStorage.getItem("loginModifyFilterState"));
    await reduxDispatch(loginRequest.tableDatas());
    reduxDispatch(loginRequest.loader(false));
  }

  const filterEmployeeName = () => {
    let arr = [];
    if (state.mappingStatusId === 3) { // New Employee
      arr = loginState.employeeName.filter(val => ((val.locationId === state.locationId || val.locationId === 0 || state.locationId === 0) && (val.employeeId === 0 || val.value === "All")));
    } else if (state.mappingStatusId === 2) { // Existing Employee
      arr = loginState.employeeName.filter(val => val.value === 0 || ((val.locationId === state.locationId || val.locationId === 0 || state.locationId === 0) && (val.employeeId !== 0 || val.value === "All")));
    } else { // All Employee
      arr = loginState.employeeName.filter(val => (val.locationId === state.locationId || val.locationId === 0 || state.locationId === 0 || val.value === 0));
    }
    if (state.mappingStatusId !== 3 && state.statusId && state.status !== "All") {
      const confirmed = setDefaultValue.employmentStatus.confirmed;
      const probation = setDefaultValue.employmentStatus.probation;
      const relieved = setDefaultValue.employmentStatus.relieved;
      switch (state.status) {
        case setDefaultValue.employmentStatus.active:
          arr = arr.filter(val => val.employmentStatus === confirmed || val.employmentStatus === probation || val.value === 0);
          break;
        case confirmed:
          arr = arr.filter(val => val.employmentStatus === confirmed || val.value === 0);
          break;
        case probation:
          arr = arr.filter(val => val.employmentStatus === probation || val.value === 0);
          break;
        case relieved:
          arr = arr.filter(val => val.employmentStatus === relieved || val.value === 0);
          break;
        default:
          console.error("Employee Status mismatched.")
      }
    }
    state.login && state.loginId && !arr.find(val => val.value === state.loginId) && dispatch({ type: strings.Login_Roles.login, data: loginState.employeeName[0] })
    return arr;
  }

  const onDeleteConfirmation = async (isAcceptable) => {
    if (isAcceptable) {
      await reduxDispatch(loginRequest.loader(true));
      const selectedRow = loginReducerState().selectedRow;
      const data = {
        modifiedBy: userState.UserID,
        modifiedDate: exportDateFormat(new Date())
      }
      await reduxDispatch(loginUserRequest.deleteLoginRecord(selectedRow.loginid, data));
      reduxDispatch(loginRequest.loader(false));
    }
  }

  return (
    <>
      <div className='mx-6'>
        <SubHeaderSection subHeader="User Credentials" fileProps={{ columns: loginDetails.columns(history), data: loginState.tableRecords.map((val, idx) => ({ ...val, sno: idx + 1 })), docName: "Employee Login Details", isPortraitView: true }} />
        <div className='flex mb-5'>
          <div className='grid lg:grid-rows-2 md:grid-rows-3 sm:grid-rows-3 gap-x-4 gap-y-1 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-3 w-full'>
            <div><Dropdown value={state.login === "" ? null : { label: state.login, value: state.loginId }} onChange={(newValue) => dispatch({ type: strings.Login_Roles.login, data: newValue })}
              options={
                state.locationId >= 0 ?
                  filterEmployeeName()
                  : loginState.employeeName
              } placeholder={strings.dropDowns.Login_Roles.Name}
              isSearchable={true} isLabelView={true}
            /></div>
            <div><Dropdown value={state.location === "" ? null : { label: state.location, value: state.locationId }} onChange={(newValue) => userState.Role === strings.userRoles.humanResource || dispatch({ type: strings.Login_Roles.location, data: newValue })} options={loginState.location} placeholder={strings.dropDowns.Login_Roles.Location} isLabelView={true} isDisable={userState.Role === strings.userRoles.humanResource} /></div>
            <div><Dropdown value={state.mappingStatus === "" ? null : { label: state.mappingStatus, value: state.mappingStatusId }} onChange={(newValue) => dispatch({ type: strings.Login_Roles.mappingStatus, data: newValue })} options={loginState.loginID} placeholder={strings.dropDowns.Login_Roles.Id} isLabelView={true} /></div>
            <div><Dropdown value={state.role === "" ? null : { label: state.role, value: state.roleId }} onChange={(newValue) => dispatch({ type: strings.Login_Roles.role, data: newValue })} options={loginState.roles} placeholder={strings.dropDowns.Login_Roles.Role} isLabelView={true} /></div>
            <div><Dropdown value={state.status === "" ? null : { label: state.status, value: state.statusId }} onChange={(newValue) => dispatch({ type: strings.Login_Roles.status, data: newValue })} options={loginState.status} placeholder={strings.dropDowns.Login_Roles.Status} isLabelView={true} /></div>
            <div className='col-span-full flex justify-center self-end'><Button value={strings.Buttons.Search} onClick={onClick} /> <span className=' mx-3'> <Button value={strings.Buttons.Reset} onClick={() => onReset()} /></span></div>
          </div>
        </div>
        <AgGrid data={loginState.tableRecords} columns={loginDetails.columns(history, loginResponseState.isMobileCompatible)} history={history} ContextMenuItems={loginResponseState.isMobileCompatible ? false : loginDetails.ContextMenuItems} height="h-[calc(94vh-67px-67px-1.5rem-3.5rem-4.6rem)] lg:h-[calc(94vh-67px-67px-1.5rem-3.5rem-4.6rem)] md:h-[calc(94vh-67px-67px-67px-1.5rem-3.5rem-4.6rem)] xsm:h-[58vh]" isSetFilter={true} />
        <div className="flex items-center mt-3">
          <AddButton value={strings.Buttons.CreateLogin} onClick={() => history.push(routerPath.loginUserForm)} />
        </div>
      </div>
      {loginState.loader && <TransparentLoader />}
      {loginResponseState.apiResponse.show && <ApiResponse setResponseCallback={onDeleteConfirmation} />}
    </>
  )
}

export default LoginView

const reducer = (state, action) => {
  setSessionStorage(action, state);
  if (action.type === strings.Buttons.Reset) {
    return { ...loginInitialState };
  }
  else if (action.type && action.data && action.type === strings.Login_Roles.login) {
    return { ...state, [action.type]: action.data.label, [`${action.type}Id`]: action.data.value, employeeId: action.data.employeeId };
  }
  else if (action.type && action.data) {
    if (action.type === strings.Login_Roles.location && state.login !== "" && state.loginId > 0) {
      let data = loginReducerState().employeeName.find(val => val.value === state.loginId && (val.locationId !== action.data.value && action.data.value !== 0));
      if (data && Object.keys(data).length > 0) {
        return { ...state, [action.type]: action.data.label, [`${action.type}Id`]: action.data.value, [strings.Login_Roles.login]: "", [`${strings.Login_Roles.login}Id`]: 0, employeeId: 0 };
      }
    }
    return { ...state, [action.type]: action.data.label, [`${action.type}Id`]: action.data.value };
  }
  else {
    return { ...state };
  }
};

const setSessionStorage = (action, state) => {
  let loginState = JSON.parse(sessionStorage.getItem("loginModifyFilterState"));
  if (action?.data) {
    switch (action.type) {
      case strings.Login_Roles.login:
        loginState = { ...loginState, employeeId: action.data.employeeId, loginId: action.data.value }
        break;
      case strings.Login_Roles.location:
        if (state.login !== "" && state.loginId > 0) {
          let data = loginReducerState().employeeName.find(val => val.value === state.loginId && (val.locationId !== action.data.value && action.data.value !== 0));
          if (data && Object.keys(data).length > 0) {
            loginState = { ...loginState, employeeId: 0, loginId: 0 }
          }
        }
        loginState = { ...loginState, location: action.data.value }
        break;
      case strings.Login_Roles.mappingStatus:
        loginState = { ...loginState, mappingStatus: action.data.label }
        break;
      case strings.Login_Roles.role:
        loginState = { ...loginState, role: action.data.value }
        break;
      case strings.Login_Roles.status:
        loginState = { ...loginState, status: action.data.label }
        break;
      case strings.Buttons.Reset:
        return loginState;
      default:
        console.error("Type Mismatch Error");
    }
  }
  sessionStorage.setItem("loginModifyFilterState", JSON.stringify(loginState));
}

