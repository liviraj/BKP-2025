import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { setDefaultValue, strings } from '../../Constants';
import { myRequests } from '../../Grid/Columns';
import { useDispatch, useSelector } from 'react-redux';
import { myRequestActions } from '../../../redux/myRequestReducer';
import { myRequestRequests } from '../../requests';
import { dateFormat, userReducerState } from '../../helper';
import Dropdown from '../../elements/Dropdown';
import SubHeaderSection from '../../layouts/SubHeaderSection';
import Button from '../../elements/Button';
import AgGrid from '../../Grid/AgGrid';
import AddButton from '../../elements/AddButton';
import MyRequestPopup from '../../Popup_window/MyRequestPopup';
import TransparentLoader from '../../loader/TransparentLoader';
import ApiResponse from '../../Alert/ApiResponse';
import HeaderSection from '../../layouts/HeaderSection';
import ImageViewer from '../../ViewDocs/ImageViewer';

const MyRequests = () => {
    const dispatch = useDispatch()
    const { requestData, typeofRequest, loader, status } = useSelector(state => state.myRequest);
    const loginResponseState = useSelector(state => state.loginResponse);
    const { UserID, LocationID } = useSelector(state => state.user)
    const { popup } = useSelector(state => state.myRequest);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const { watch, setValue, getValues, handleSubmit } = useForm({ defaultValues: initialState });

    useEffect(() => {
        const initialLoad = async () => {
            await dispatch(myRequestActions.setLoader(true));
            await Promise.all([
                typeofRequest.length <= 0 && dispatch(myRequestRequests.getRequestType()),
                status.length <= 0 && dispatch(myRequestRequests.getStatusTypes())
            ])
            await handleReset()
            dispatch(myRequestActions.setLoader(false));
        }
        initialLoad()
        return () => {
            dispatch(myRequestActions.setRequestData([]))
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    const onSubmit = async (data) => {
        await dispatch(myRequestActions.setLoader(true));
        const params = {
            employeeId: UserID,
            requestTypeId: data.typeOfRequest.value,
            status: data.status.value,
            locationId: LocationID
        }
        await Promise.resolve(dispatch(myRequestRequests.getRequest(params)))
        dispatch(myRequestActions.setLoader(false))
    }
    const handleReset = async () => {
        await dispatch(myRequestActions.setLoader(true))
        await Promise.all([
            setValue(strings.myRequest.status, setDefaultValue.requestStatus),
            setValue(strings.myRequest.typeOfRequest, setDefaultValue.requestType)
        ]);
        await onSubmit(getValues());
        dispatch(myRequestActions.setLoader(false))
    }
    const setCallBack = async (isSuccess) => {
        if (isSuccess) {
            await dispatch(myRequestActions.resetPopup());
            await onSubmit(getValues())
        }
    }

    return (
        <>
            <HeaderSection redirectType={strings.type.myRequest} />
            <div className='mx-6'>
                <SubHeaderSection subHeader="My Request (s)" fileProps={{ columns: myRequests.myRequest.column(loginResponseState.isMobileCompatible), data: requestData.map((val, idx) => ({ ...val, sno: idx + 1, createdDate: val.createdDate ? dateFormat(val.createdDate) : "" })), docName: `My Request (s)` }} />
                <div className='grid  gap-x-4 gap-y-1 lg:grid-cols-4 md:grid-cols-2 sm:grid-cols-3 w-full mb-6'>
                    <Dropdown options={status} value={watch(strings.myRequest.status)} onChange={value => setValue(strings.myRequest.status, value)} isLabelView={true} placeholder={"Status"} />
                    <Dropdown options={typeofRequest && typeofRequest.length > 0 ? typeofRequest.filter(val => val.locationId === userReducerState().LocationID || val.locationId <= 0) : []} value={watch(strings.myRequest.typeOfRequest)} onChange={value => setValue(strings.myRequest.typeOfRequest, value)} isLabelView={true} placeholder={"Types of Request"} isSearchable={true} />
                    <div className='self-end flex gap-3'>
                        <Button value={strings.Buttons.Submit} onClick={handleSubmit(onSubmit)} />
                        <Button value={strings.Buttons.Reset} onClick={handleReset} />
                    </div>
                </div>
                <AgGrid data={requestData || []} columns={myRequests.myRequest.column(loginResponseState.isMobileCompatible)} height={'lg:h-[calc(100vh-20rem)] md:h-[calc(100vh-23rem)] sm:h-[calc(100vh-15rem)] xsm:h-[calc(100vh-23rem)]'} ContextMenuItems={loginResponseState.isMobileCompatible ? false : myRequests.myRequest.contextMenuItems} />
                <div className="m-2 flex items-center text-14px font-bold "><AddButton value={strings.Buttons.addMyRequest} onClick={() => dispatch(myRequestActions.showPopup({ show: true, selectedRow: {}, actions: "Add" }))} /></div>
            </div>
            {popup.show && <MyRequestPopup setCallBack={setCallBack} />}
            {loader && <TransparentLoader />}
            {loginResponseState.imageViewer.show && <ImageViewer />}
            {apiResponseState.show && <ApiResponse />}
        </>
    );
};

export default MyRequests;

const initialState = {
    status: "",
    typeOfRequest: ""
}