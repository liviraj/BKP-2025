import PropTypes from 'prop-types';
import { useEffect, useMemo, useState } from 'react'
import HeaderSection from '../../layouts/HeaderSection'
import { setDefaultValue, strings, trackingStatusList } from '../../Constants'
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { FaCheckSquare } from "react-icons/fa";
import { Avatar, Tooltip } from '@mui/material';
import { FcCheckmark, FcSynchronize, FcClock } from "react-icons/fc";
import { exportDateFormat, periodOptionsWithoutPayroll, onSelectSearchformatOptionLabel, periodDateFormat, TooltipSlotProps, userReducerState, dateFormat, employeeReducerState, dragReorder } from '../../helper';
import Dropdown from '../../elements/Dropdown';
import DatePickerElement from '../../elements/DatePickerElement';
import { useForm } from 'react-hook-form';
import Button from '../../elements/Button';
import { useDispatch, useSelector } from 'react-redux';
import { employeeRequests, myRequestRequests } from '../../requests';
import TransparentLoader from '../../loader/TransparentLoader';
import ApiResponse from '../../Alert/ApiResponse';
import { myRequestActions } from '../../../redux/myRequestReducer';
import EditPopupRequestView from '../../Popup_window/EditPopupRequestView';
import SelectableSearchComponent from '../../elements/SelectableSearchComponent';
import FooterLoader from '../../loader/FooterLoader';
import ExportFiles from '../../elements/ExportFiles';
import { myRequests } from '../../Grid/Columns';

function TrackingRequest() {

    const employeeState = useSelector(state => state.employee);
    const myRequestState = useSelector(state => state.myRequest);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);

    const dispatch = useDispatch();

    const [loader, setLoader] = useState(false);
    const [footerLoader, setFooterLoader] = useState(false);
    const [state, setState] = useState({ inProgress: [], done: [], open: [] });

    const { watch, setValue, getValues } = useForm({ defaultValues: initialState });
    const location = watch(strings.trackingRequest.location);
    const empName = watch(strings.trackingRequest.employeeName);
    const typeOfRequest = watch(strings.trackingRequest.typeOfRequest);

    useEffect(() => {
        const initialLoad = async () => {
            setLoader(true);
            await Promise.all([
                employeeState.employeeName.length <= 0 && dispatch(employeeRequests.employeeName()),
                employeeState.location.length <= 0 && dispatch(employeeRequests.location()),
                myRequestState.typeofRequest.length <= 0 && dispatch(myRequestRequests.getRequestType()),
                myRequestState.assigneeList <= 0 && dispatch(myRequestRequests.trackingRequest.getAssigneeList()),
                myRequestState.trackingStatus.length <= 0 && dispatch(myRequestRequests.getTrackingStatus())
            ]);

            await onReset();
            setLoader(false);
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    useEffect(() => {
        if (myRequestState.trackingRequest.data.length > 0) {
            const alteredRecords = splitItems(myRequestState.trackingRequest.data);
            setState({ inProgress: alteredRecords.inProgress, done: alteredRecords.done, open: alteredRecords.open });
        }
        else {
            setState({ inProgress: [], done: [], open: [] });
        }
    }, [myRequestState.trackingRequest.data]);

    const idList = {
        open: 'open',
        inProgress: 'inProgress',
        done: 'done'
    };

    const getList = (id) => state[idList[id]];

    const onDragEnd = (result) => {
        const { source, destination } = result;

        // dropped outside the list
        if (!destination) {
            return;
        }

        let stateValue = { ...state };

        if (source.droppableId === destination.droppableId) {
            const reorderedLists = dragReorder(
                getList(source.droppableId),
                source.index,
                destination.index
            );

            if (source.droppableId === idList.done) {
                stateValue = { ...stateValue, done: reorderedLists };
            }
            else if (source.droppableId === idList.inProgress) {
                stateValue = { ...stateValue, inProgress: reorderedLists };
            }
            else {
                stateValue = { ...stateValue, open: reorderedLists };
            }

            setState(stateValue);
        } else {
            setFooterLoader(true);
            let result = move(
                getList(source.droppableId),
                getList(destination.droppableId),
                source,
                destination
            );

            setState({ ...stateValue, ...result });

            const selectedRecords = result[destination.droppableId][destination.index];
            if (selectedRecords && Object.keys(selectedRecords).length > 0) {
                const trackingStatus = myRequestState.trackingStatus.find(val => val.label === trackingStatusList.find(val => val.key === destination.droppableId).label) ? myRequestState.trackingStatus.find(val => val.label === trackingStatusList.find(val => val.key === destination.droppableId).label) : trackingStatusList.find(val => val.key === destination.droppableId);

                const params = {
                    assignedTo: Number(selectedRecords.assignedToEmpId),
                    description: selectedRecords.description ? selectedRecords.description : "",
                    modifiedBy: userReducerState().UserID,
                    modifiedDate: exportDateFormat(new Date()),
                    requestStatusId: Number(trackingStatus.value)
                }

                dispatch(myRequestRequests.trackingRequest.updateTrackingRequestDetails(selectedRecords.autoId, params, async (isValid) => {
                    if (isValid) {
                        result[destination.droppableId][destination.index] = { ...selectedRecords, status: trackingStatus.label, statusId: trackingStatus.value };
                        setState({ ...stateValue, ...result });
                    }
                    else {
                        setState({ ...stateValue });
                    }
                    setFooterLoader(false);
                }));
            }
        }
    };

    const onSubmit = async () => {
        setLoader(true);
        const data = getValues();
        await dispatch(myRequestRequests.trackingRequest.getTrackingRequest({ employeeId: data.employeeName.value, locationId: data.location?.value, requestStatusId: 0, requestTypeId: data.typeOfRequest.value, fromDate: exportDateFormat(data.fromDate, true), toDate: exportDateFormat(data.toDate, true) }));
        setLoader(false);
    }

    const onReset = async () => {
        setLoader(true);
        await Promise.all([
            onPeriodChange(periodOptionsWithoutPayroll[2]),
            setValue(strings.trackingRequest.location, employeeReducerState().location.find(val => val.value === userReducerState().LocationID)),
            setValue(strings.trackingRequest.employeeName, setDefaultValue.employeeName),
            setValue(strings.trackingRequest.typeOfRequest, setDefaultValue.requestType)
        ]);
        await onSubmit();
        setLoader(false);
    }

    const onPeriodChange = (value) => {
        setValue(strings.trackingRequest.period, value);
        periodDateFormat(value, setValue);
        return value;
    }

    const onlocationChange = (data) => {
        setValue(strings.trackingRequest.location, data);
    }

    const employeeNameOptions = useMemo(() => {
        if (employeeState.employeeName && location) {
            const filterValue = employeeState.employeeName.filter(val => val.locationId === location.value || val.locationId <= 0);
            if (empName && !filterValue.find(val => val.value === empName.value)) {
                setValue(strings.trackingRequest.employeeName, setDefaultValue.employeeName);
            }
            if (typeOfRequest && !myRequestState.typeofRequest.filter(val => val.locationId <= 0 || val.locationId === location.value).find(val => val.value === typeOfRequest.value)) {
                setValue(strings.trackingRequest.typeOfRequest, setDefaultValue.requestType);
            }
            return filterValue;
        }
        return [];
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [employeeState.employeeName, location, empName, myRequestState.typeofRequest]);

    const setOpenRequestView = (selectedRecord) => {
        dispatch(myRequestActions.setTrackingRequest({ requestView: { show: true, selectedRecord } }));
    }

    const onAssigneeChange = (newData, type, idx) => {
        setFooterLoader(true);
        let tempStateValue = state;
        const selectedRecords = tempStateValue[type][idx];
        tempStateValue[type][idx] = { ...selectedRecords, AssignedTo: newData.label, imageBinary: newData.image, assignedToEmpId: newData.value };
        setState(tempStateValue);

        const params = {
            assignedTo: newData.value,
            autoId: selectedRecords.autoId,
            employeeId: selectedRecords.empId,
            modifiedBy: userReducerState().UserID,
            modifiedDate: exportDateFormat(new Date()),
            requestId: selectedRecords.requestId,
            requestStatusId: selectedRecords.statusId
        }

        dispatch(myRequestRequests.trackingRequest.updateTrackingRequestDetails(selectedRecords.autoId, params, async (isValid) => {
            if (!isValid) {
                tempStateValue[type][idx] = { ...selectedRecords, AssignedTo: selectedRecords.AssignedTo, imageBinary: selectedRecords.imageBinary };
                setState(tempStateValue);
            }
            setFooterLoader(false);
        }));
    }

    const DraggableComponent = ({ item, index, icon, iconTitle, type }) => {
        return <Draggable
            key={item.id}
            draggableId={item.id}
            index={index}
        >
            {(provided, snapshot) => (
                <div
                    ref={provided.innerRef}
                    {...provided.draggableProps}
                    {...provided.dragHandleProps}
                    style={{ ...provided.draggableProps.style }}
                    onClick={() => setOpenRequestView(item)}
                    className={` h-auto min-h-20 flex flex-col justify-between p-2 my-2  rounded ${snapshot.isDragging ? "bg-[#f0fff0] box-drag-shadow " : " bg-white box-highlight-shadow "}`}
                >
                    <div className='text-12px'><Tooltip title={item.task} slotProps={TooltipSlotProps} ><span>{item.task}</span></Tooltip></div>
                    <div className=' flex flex-row justify-between items-center'>
                        <span className=' text-darkDarkGrey gap-1 flex text-[11px] font-bold items-center leading-none'><FaCheckSquare size={12} color='#4cade5' /><Tooltip title={item.taskID} slotProps={TooltipSlotProps} ><span>{item.taskID}</span></Tooltip></span>
                        <span className=' text-darkDarkGrey gap-1 flex text-[11px] font-bold items-center'><Tooltip title={iconTitle} slotProps={TooltipSlotProps} ><span>{icon}</span></Tooltip>
                            <span>
                                <SelectableSearchComponent options={myRequestState.assigneeList} placeholder={item.AssignedTo} value={""} onChange={data => onAssigneeChange(data, type, index)} formatOptionLabel={onSelectSearchformatOptionLabel} >
                                    <Tooltip title={item.AssignedTo} slotProps={TooltipSlotProps} >
                                        {item?.imageBinary?.length > 0 ? <img className=' h-8 w-8 rounded-full mx-auto' src={`data:image/jpeg/png;base64,${item?.imageBinary}`} alt='#' /> : <Avatar className=' max-h-8 max-w-[2rem] !text-13px !bg-[#b1b1b1]' >{item.AssignedTo && item.AssignedTo.length > 0 ? item.AssignedTo.split(" ").map(val => (val[0] ? val[0].toUpperCase() : val[0])).join("") : ""}</Avatar>}
                                    </Tooltip>
                                </SelectableSearchComponent>
                            </span>
                        </span>
                    </div>
                </div>
            )}
        </Draggable>

    }

    DraggableComponent.propTypes = {
        item: PropTypes.object,
        index: PropTypes.number,
        icon: PropTypes.any,
        iconTitle: PropTypes.string,
        type: PropTypes.string
    }

    return (
        <div>
            <HeaderSection redirectType={strings.type.myRequest} />
            <div className='overflow-hidden h-auto md:max-h-h_body_md sm:max-h-full'>
                <div className='px-4 grid xl:grid-rows-1 lg:grid-rows-2 md:grid-rows-2 sm:grid-rows-3 xsm:grid-rows-3 gap-x-4 gap-y-1 xl:grid-cols-4 lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 xsm:grid-cols-1 w-full'>
                    <div><Dropdown placeholder={"Period"} options={periodOptionsWithoutPayroll} value={watch(strings.trackingRequest.period)} onChange={onPeriodChange} isLabelView={true} /></div>
                    <div><DatePickerElement placeholder='From' disabled={watch(strings.trackingRequest.period).label !== strings.filterPeriod.custom} value={watch(strings.trackingRequest.fromDate)} onChange={date => setValue(strings.trackingRequest.fromDate, date)} maxDate={watch(strings.trackingRequest.toDate)} isRequired={true} isLabelView={true} /></div>
                    <div><DatePickerElement placeholder='To' disabled={watch(strings.trackingRequest.period).label !== strings.filterPeriod.custom} value={watch(strings.trackingRequest.toDate)} onChange={date => setValue(strings.trackingRequest.toDate, date)} minDate={watch(strings.trackingRequest.fromDate)} isRequired={true} isLabelView={true} /></div>
                    <div><Dropdown placeholder={"Location"} value={location} options={employeeState.location?.length > 0 ? employeeState.location.filter(val => val.value > 0) : []} onChange={data => onlocationChange(data)} isSearchable={true} isLabelView={true} isDisable={userReducerState().Role !== strings.userRoles.admin} /></div>
                    <div><Dropdown placeholder={"Employee Name"} value={empName} options={employeeNameOptions} onChange={e => setValue(strings.trackingRequest.employeeName, e)} isSearchable={true} isLabelView={true} /></div>
                    <div><Dropdown placeholder={"Types of Request"} value={typeOfRequest} onChange={data => setValue(strings.trackingRequest.typeOfRequest, data)} options={myRequestState.typeofRequest && location && myRequestState.typeofRequest.length > 0 ? myRequestState.typeofRequest.filter(val => val.locationId <= 0 || val.locationId === location.value) : []} isLabelView={true} isSearchable={true} /></div>
                    <div className=' self-end flex'><Button value={strings.Buttons.Search} onClick={onSubmit} /> <span className=' mx-3'> <Button value={strings.Buttons.Reset} onClick={onReset} /></span></div>
                    <div className=' flex justify-end md:col-span-2 lg:col-span-1 order-[-1] sm:order-1'><ExportFiles columns={myRequests.TrackingRequest.columns} data={myRequestState.trackingRequest.data.map((val, idx) => ({ ...val, sno: idx + 1, requestDate: val.requestDate ? dateFormat(val.requestDate) : "", approvedOn: val.approvedOn ? dateFormat(val.approvedOn) : "" }))} docName={"Tracking Request"} /></div>
                </div>
                <div className=' flex my-3 px-4 lg:h-[calc(94vh-67px-67px-1.5rem-3.5rem-2rem)] md:h-[calc(94vh-67px-67px-67px-1.5rem-3.5rem-2rem)] xsm:h-[62vh] md:overflow-auto xsm:overflow-hidden sm:max-h-full flex-wrap'>
                    <DragDropContext onDragEnd={onDragEnd}>
                        <Droppable droppableId={idList.open}>
                            {(provided, snapshot) => (
                                <div
                                    ref={provided.innerRef}
                                    className={` p-3 w-80 m-3 font-fontfamily bg-[#e4f6ff] rounded ${snapshot.isDraggingOver ? "" : "  "}`}
                                >
                                    <div className=' text-darkDarkGrey text-12px font-bold mb-3 flex gap-3'>OPEN {state.open?.length ? state.open.length : ""}<FcClock size={16} /></div>
                                    {state.open.map((item, index) => (
                                        <div key={index}>
                                            <DraggableComponent item={item} index={index} icon={<FcClock size={16} />} iconTitle={"OPEN"} type={idList.open} />
                                        </div>
                                    ))}
                                    {provided.placeholder}
                                </div>
                            )}
                        </Droppable>
                        <Droppable droppableId={idList.inProgress}>
                            {(provided, snapshot) => (
                                <div
                                    ref={provided.innerRef}
                                    className={` p-3 w-80 m-3 font-fontfamily bg-[#ffe4ce] rounded ${snapshot.isDraggingOver ? "" : "  "}`}
                                >
                                    <div className=' text-darkDarkGrey text-12px font-bold mb-3 flex gap-3'>IN PROGRESS {state.inProgress?.length ? state.inProgress?.length : ""} <FcSynchronize size={16} /></div>
                                    {state.inProgress.map((item, index) => (
                                        <div key={index}>
                                            <DraggableComponent item={item} index={index} icon={<FcSynchronize size={16} />} iconTitle={"IN PROGRESS"} type={idList.inProgress} />
                                        </div>
                                    ))}
                                    {provided.placeholder}
                                </div>
                            )}
                        </Droppable>
                        <Droppable droppableId={idList.done}>
                            {(provided, snapshot) => (
                                <div
                                    ref={provided.innerRef}
                                    className={` p-3 w-80 m-3 font-fontfamily bg-[#c9ebc9] rounded ${snapshot.isDraggingOver ? "" : "  "}`}
                                >
                                    <div className=' text-darkDarkGrey text-12px font-bold mb-3 flex gap-3'>DONE {state.done.length ? state.done.length : ""}<FcCheckmark size={18} /></div>
                                    {state.done.map((item, index) => (
                                        <div key={index}>
                                            <DraggableComponent item={item} index={index} icon={<FcCheckmark size={18} />} iconTitle={"DONE"} type={idList.done} />
                                        </div>
                                    ))}
                                    {provided.placeholder}
                                </div>
                            )}
                        </Droppable>
                    </DragDropContext>
                </div>
            </div>
            <>
                {loader && <TransparentLoader />}
                {apiResponseState.show && <ApiResponse />}
                {footerLoader && <FooterLoader label={"Updating the records"} />}
                {myRequestState.trackingRequest.requestView.show && <EditPopupRequestView setReloadRecords={onSubmit} />}
            </>
        </div>
    )
}

export default TrackingRequest

const splitItems = (data) => {
    const tempData = data.map((val, idx) => ({ ...val, id: `item-${idx}`, task: val.requestType, AssignedTo: val.assignedTo, imageBinary: val.assigneeImageBinary, taskID: `TRK ${val.autoId}` }));
    return {
        inProgress: tempData.filter(val => Object.hasOwn(val, "status") && val.status === trackingStatusList[1].label),
        done: tempData.filter(val => Object.hasOwn(val, "status") && val.status === trackingStatusList[2].label),
        open: tempData.filter(val => Object.hasOwn(val, "status") && val.status === trackingStatusList[0].label)
    };
}

const initialState = {
    location: "",
    employeeName: "",
    period: "",
    fromDate: "",
    toDate: "",
    typeOfRequest: ""
}

/**
 * Moves an item from one list to another list.
 */
const move = (source, destination, droppableSource, droppableDestination) => {
    const sourceClone = Array.from(source);
    const destClone = Array.from(destination);
    const [removed] = sourceClone.splice(droppableSource.index, 1);

    destClone.splice(droppableDestination.index, 0, removed);

    const result = {};
    result[droppableSource.droppableId] = sourceClone;
    result[droppableDestination.droppableId] = destClone;

    return result;
};