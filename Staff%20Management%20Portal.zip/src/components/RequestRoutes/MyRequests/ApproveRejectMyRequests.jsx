import { useEffect, useMemo } from 'react'
import HeaderSection from '../../layouts/HeaderSection'
import { setDefaultValue, strings } from '../../Constants'
import SubHeaderSection from '../../layouts/SubHeaderSection'
import Dropdown from '../../elements/Dropdown'
import Button from '../../elements/Button'
import AgGrid from '../../Grid/AgGrid'
import { myRequests } from '../../Grid/Columns'
import { useDispatch, useSelector } from 'react-redux'
import { employeeRequests, myRequestRequests } from '../../requests'
import { dateFormat, employeeReducerState, leaveStatus, userReducerState } from '../../helper'
import { myRequestActions } from '../../../redux/myRequestReducer'
import TransparentLoader from '../../loader/TransparentLoader'
import ApiResponse from '../../Alert/ApiResponse'
import { useForm } from 'react-hook-form'
import MyRequestApprovePopup from '../../Popup_window/MyRequestApprovePopup'
import ImageViewer from '../../ViewDocs/ImageViewer'

function ApproveRejectMyRequests() {

    const myRequestState = useSelector(state => state.myRequest);
    const employeeState = useSelector(state => state.employee);
    const loginResponseState = useSelector(state => state.loginResponse);
    const dispatch = useDispatch();
    const { watch, setValue, getValues } = useForm({ defaultValues: initialState });
    const location = watch(strings.myRequest.location);
    const empName = watch(strings.myRequest.employeeName);
    const typeOfRequest = watch(strings.myRequest.typeOfRequest);

    useEffect(() => {
        const initialLoad = async () => {
            await dispatch(myRequestActions.setLoader(true));
            await Promise.all([
                myRequestState.status && myRequestState.status.length <= 0 && dispatch(myRequestRequests.getStatusTypes()),
                employeeState.employeeName.length <= 0 && dispatch(employeeRequests.employeeName()),
                employeeState.location.length <= 0 && dispatch(employeeRequests.location()),
                myRequestState.typeofRequest && myRequestState.typeofRequest.length <= 0 && dispatch(myRequestRequests.getRequestType())
            ]);
            await onReset()
            dispatch(myRequestActions.setLoader(false));
        }
        initialLoad();
        return () => dispatch(myRequestActions.setRequestData([]));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onReset = async () => {
        await dispatch(myRequestActions.setLoader(true));
        await Promise.all([
            setValue(strings.myRequest.location, employeeReducerState().location.find(val => val.value === userReducerState().LocationID)),
            setValue(strings.myRequest.employeeName, setDefaultValue.employeeName),
            setValue(strings.myRequest.status, myRequestState.status.find(val => val.value === leaveStatus[4].Key)),
            setValue(strings.myRequest.typeOfRequest, setDefaultValue.requestType)
        ]);
        await onSubmit();
    }

    const employeeNameOptions = useMemo(() => {
        if (employeeState.employeeName && location) {
            const filterValue = employeeState.employeeName.filter(val => val.locationId === location.value || val.locationId <= 0);
            if (empName && !filterValue.find(val => val.value === empName.value)) {
                setValue(strings.myRequest.employeeName, setDefaultValue.employeeName);
            }
            if (typeOfRequest && !myRequestState.typeofRequest.filter(val => val.locationId <= 0 || val.locationId === location.value).find(val => val.value === typeOfRequest.value)) {
                setValue(strings.myRequest.typeOfRequest, setDefaultValue.requestType);
            }
            return filterValue;
        }
        return [];
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [employeeState.employeeName, location, empName, myRequestState.typeofRequest]);

    const onSubmit = async () => {
        const data = getValues();
        await dispatch(myRequestActions.setLoader(true));
        const filterParams = {
            employeeId: data.employeeName ? data.employeeName.value : "",
            requestTypeId: data.typeOfRequest ? data.typeOfRequest.value : "",
            status: data.status ? data.status.value : "",
            locationId: data.location ? data.location.value : ""
        }
        await dispatch(myRequestRequests.getRequest(filterParams));
        dispatch(myRequestActions.setLoader(false));
    }

    return (
        <div>
            <HeaderSection redirectType={strings.type.myRequest} />
            <div className='px-6 overflow-hidden h-auto md:max-h-h_body_md sm:max-h-full'>
                <SubHeaderSection subHeader="Approve / Reject Request" fileProps={{ columns: myRequests.approveRejectRequest.columns(loginResponseState.isMobileCompatible), data: myRequestState.requestData.map((val, idx) => ({ ...val, sno: idx + 1, createdDate: val.createdDate ? dateFormat(val.createdDate) : "", reviewedOn: val.reviewedOn ? dateFormat(val.reviewedOn) : "" })), docName: `Approve And Reject Request` }} />
                <div className='flex mb-6 md:mb-6 xsm:mb-4'>
                    <div className='grid grid-rows-1 md:grid-rows-1 sm:grid-rows-2 xsm:grid-rows-3 gap-x-4 gap-y-1 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-2 w-full'>
                        <div><Dropdown placeholder={"Employee Name"} value={empName} onChange={data => setValue(strings.myRequest.employeeName, data)} options={employeeNameOptions} isLabelView={true} isSearchable={true} /></div>
                        <div><Dropdown placeholder={"Status"} value={watch(strings.myRequest.status)} onChange={data => setValue(strings.myRequest.status, data)} options={myRequestState.status} isLabelView={true} /></div>
                        <div><Dropdown placeholder={"Types of Request"} value={typeOfRequest} onChange={data => setValue(strings.myRequest.typeOfRequest, data)} options={myRequestState.typeofRequest && location && myRequestState.typeofRequest.length > 0 ? myRequestState.typeofRequest.filter(val => val.locationId <= 0 || val.locationId === location.value) : []} isLabelView={true} isSearchable={true} /></div>
                        <div><Dropdown placeholder={"Location"} value={location} onChange={data => setValue(strings.myRequest.location, data)} options={employeeState.location && employeeState.location.length > 0 ? employeeState.location : []} isLabelView={true} isDisable={userReducerState().Role === strings.userRoles.humanResource} /></div>
                        <div className=' self-end flex'><Button value={strings.Buttons.Search} onClick={onSubmit} /> <span className=' mx-3'> <Button value={strings.Buttons.Reset} onClick={onReset} /></span></div>
                    </div>
                </div>
                <AgGrid data={myRequestState.requestData} columns={myRequests.approveRejectRequest.columns(loginResponseState.isMobileCompatible)} ContextMenuItems={loginResponseState.isMobileCompatible ? false : myRequests.approveRejectRequest.contextMenuItems} height="h-[calc(94vh-67px-3.5rem-1.5rem-3.5rem-2rem)] lg:h-[calc(94vh-67px-3.5rem-1.5rem-3.5rem-2rem)] md:h-[calc(94vh-67px-67px-3.5rem-1.5rem-3.5rem-2rem)] xsm:h-[70vh] " />
            </div>
            {loginResponseState.imageViewer.show && <ImageViewer />}
            {myRequestState.approvePopup.show && <MyRequestApprovePopup onSubmit={onSubmit} />}
            {myRequestState.loader && <TransparentLoader />}
            {loginResponseState.apiResponse.show && <ApiResponse />}
        </div>
    )
}

export default ApproveRejectMyRequests

const initialState = {
    employeeName: "",
    status: "",
    typeOfRequest: "",
    location: ""
}