import { useForm } from "react-hook-form";
import { Designation } from "../../Grid/Columns";
import SubHeaderSection from "../../layouts/SubHeaderSection";
import Dropdown from "../../elements/Dropdown";
import { HolidayNameStatus, strings } from "../../Constants";
import { useDispatch, useSelector } from "react-redux";
import { employeeReducerState, exportDateFormat, userReducerState } from "../../helper";
import Button from "../../elements/Button";
import { useEffect } from "react";
import AgGrid from "../../Grid/AgGrid";
import AddButton from "../../elements/AddButton";
import { designationActions } from "../../../redux/DesignationReducer";
import DesignationPopup from "../../Popup_window/DesignationPopup";
import TransparentLoader from "../../loader/TransparentLoader";
import ApiResponse from "../../Alert/ApiResponse";
import { designationRequest, employeeRequests } from "../../requests";
import MultiImageViewer from "../../ViewDocs/MultiImageViewer";
import ImageViewer from "../../ViewDocs/ImageViewer";

const DesignationList = () => {
    const dispatch = useDispatch()
    const employeeState = useSelector(state => state.employee);
    const { designationPopup, loader, designationDetails } = useSelector(state => state.designation);
    const { watch, setValue, getValues } = useForm({ defaultValues: initialState });
    const loginResponseState = useSelector(state => state.loginResponse);
    const userState = useSelector(state => state.user);

    useEffect(() => {
        const initialState = async () => {
            await dispatch(designationActions.setLoader(true))
            employeeState.location.length <= 0 && await dispatch(employeeRequests.location());
            await handleReset();
            dispatch(designationActions.setLoader(false));
        }
        initialState();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    const onlocationChange = async (data) => {
        await setValue(strings.designation.location, data);
    }
    const handleSubmit = async () => {
        const data = getValues();
        await dispatch(designationActions.setLoader(true))
        const params = {
            locationId: data.location?.value,
            status: data.status?.value
        }
        await dispatch(designationRequest.getDesignation(params));
        dispatch(designationActions.setLoader(false))
    }

    const handleReset = async () => {
        await dispatch(designationActions.setLoader(true))
        await setValue(strings.designation.status, HolidayNameStatus.find(val => val.value == "A"));
        await setValue(strings.designation.location, employeeReducerState().location.find(val => val.value === userReducerState().LocationID));
        await handleSubmit();
        dispatch(designationActions.setLoader(false))
    }

    const onDeleteConfirmation = async (isAcceptable) => {
        await dispatch(designationActions.setLoader(true));
        if (isAcceptable) {
            const params = {
                id: designationPopup.selectedRow.designationId,
                locationId: 1,
                modifiedBy: userState.UserID,
                modifiedDate: exportDateFormat(new Date())
            }
            await dispatch(designationRequest.deleteDesignationRequest(params, setCallBack))

        }
        dispatch(designationActions.setLoader(false));
    }

    const setCallBack = async (isAccepted) => {
        if (isAccepted) {
            await dispatch(designationActions.setLoader(true));
            await handleSubmit();
            dispatch(designationActions.setLoader(false));
        }
    }
    return (
        <>
            <div className="px-6 overflow-hidden h-auto  sm:max-h-full">
                <SubHeaderSection subHeader={"Designations"} fileProps={{ columns: Designation.designationList.columns(loginResponseState.isMobileCompatible), data: designationDetails?.map((val, idx) => ({ ...val, sno: idx + 1 })), docName: 'Designations' }} />
                <div className='grid grid-rows-1 md:grid-rows-1 sm:grid-rows-2 xsm:grid-rows-3 gap-x-4 gap-y-1 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-2 w-full'>
                    <div><Dropdown placeholder={"Status"} value={watch(strings.designation.status)} options={HolidayNameStatus} onChange={e => setValue(strings.designation.status, e)} isLabelView={true} /></div>
                    <div><Dropdown placeholder={"Location"} value={watch(strings.designation.location)} options={employeeState.location && employeeState.location.length > 0 ? employeeState.location.filter(val => val.value >= 0) : []} onChange={data => userReducerState().Role === strings.userRoles.humanResource || onlocationChange(data)} isSearchable={true} isLabelView={true} isDisable={userReducerState().Role !== strings.userRoles.admin} /></div>
                    <div className=' self-end flex gap-x-3'>
                        <Button value={strings.Buttons.Search} onClick={handleSubmit} />
                        <Button value={strings.Buttons.Reset} onClick={handleReset} />
                    </div>
                </div>
                <div className='headerCell-FullBorder mt-5'><AgGrid data={designationDetails} columns={Designation.designationList.columns(loginResponseState.isMobileCompatible)} height="h-[calc(100vh-16.6rem)] md:h-[calc(100vh-16.6rem)] xsm:h-[70vh]" ContextMenuItems={loginResponseState.isMobileCompatible ? false : Designation.designationList.contextMenuItems} isDesignationActiveSelectable isSetFilter={true} /></div>
                <div className="flex items-center mt-3 mb-3">
                    <AddButton value={strings.Buttons.createDesignation} onClick={() => dispatch(designationActions.setDesignationPopup({ show: true }))} />
                </div>
            </div>
            {designationPopup.show && <DesignationPopup handleSubmit={handleSubmit} />}
            {loginResponseState.apiResponse.show && <ApiResponse setResponseCallback={onDeleteConfirmation} />}
            {loginResponseState.multiDocumentViewer.show && <MultiImageViewer />}
            {!loginResponseState.multiDocumentViewer.show && loginResponseState.imageViewer.show && <ImageViewer />}
            {loader && <TransparentLoader />}
        </>
    );
};

export default DesignationList;

const initialState = {
    location: "",
    status: "",
}
