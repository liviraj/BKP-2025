import { useEffect, useState } from 'react'
import SubHeaderSection from '../../layouts/SubHeaderSection'
import Label from '../../elements/Label'
import Dropdown from '../../elements/Dropdown'
import DatePickerElement from '../../elements/DatePickerElement'
import AutoSizeButton from '../../elements/AutoSizeButton'
import { RiFileExcel2Line } from 'react-icons/ri'
import { useForm } from 'react-hook-form'
import { strings } from '../../Constants'
import { LeaveReportOptions, exportDateFormat, periodDateFormat, periodOptions, userReducerState } from '../../helper'
import TransparentLoader from '../../loader/TransparentLoader'
import { useDispatch, useSelector } from 'react-redux'
import { leaveManagementRequest, reportRequest } from '../../requests'
import ApiResponse from '../../Alert/ApiResponse'
import HeaderSection from '../../layouts/HeaderSection'
import { attendancePayrollActions } from '../../../redux/AttendancePayrollReducer'
import AttendanceReportView from '../../Popup_window/AttendanceReportView'
import { indiaLeaveReportColumns } from '../../Grid/Columns'
import moment from 'moment'

function IndiaLeaveReports() {

    const leaveManagementState = useSelector(state => state.leaveManagement);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const attendanceReportState = useSelector(state => state.attendancePayroll.attendanceReportView);
    const dispatch = useDispatch();

    const { watch, setValue, handleSubmit, reset } = useForm({ defaultValues: initialValues });
    const [loader, setLoader] = useState(false);
    const leftSideStyle = "col-start-1 xl:col-end-3 lg:col-end-4 sm:col-end-6 xsm:col-end-12";
    const rightSideStyle = "xl:col-start-3 lg:col-start-4 sm:col-start-6 xsm:col-start-1 lg:col-end-7 xl:col-end-5 xsm:col-end-12";


    useEffect(() => {
        const initialLoad = async () => {
            await setLoader(true);
            Object.keys(leaveManagementState.payroll).length <= 0 && await dispatch(leaveManagementRequest.getPayroll());
            setLoader(false);
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onSubmit = async (formData) => {


        await setLoader(true);
        const params = {
            fromDate: exportDateFormat(formData.fromDate, true),
            locationId: userReducerState().LocationID,
            toDate: exportDateFormat(formData.toDate, true),
            employeetype: 1
        }
        if (formData.leaveReport.value === LeaveReportOptions[0].value) {
            await dispatch(reportRequest.leaveReports.getEmployeeAttendanceReport(params, async (data) => {
                await dispatch(attendancePayrollActions.setAttendanceReportView({
                    show: true, data, columns: indiaLeaveReportColumns.employeeAttendance(data), type: LeaveReportOptions[0], header: `Employee Attendance Report of INDIA between ${moment(formData.fromDate).format("MM/DD/YYYY")} - ${moment(formData.toDate).format("MM/DD/YYYY")}`, excelParams: { ...formData }
                }));
                reset();
            }));
        }
        else if (formData.leaveReport.value === LeaveReportOptions[1].value) {
            await dispatch(reportRequest.leaveReports.getTotalHoursReport(params, async (data) => {
                await dispatch(attendancePayrollActions.setAttendanceReportView({
                    show: true, data, columns: indiaLeaveReportColumns.totalHoursWorked(data), type: LeaveReportOptions[1], header: `Employee Monthly Attendance Report - Hours Worked`, excelParams: { ...formData }
                }));
                reset();
            }));
        }
        else if (formData.leaveReport.value === LeaveReportOptions[2].value) {
            await dispatch(reportRequest.leaveReports.getLeaveAvailedReport(params, async (res) => {
                if (res && ("attendanceAndLeaveReportsDate" in res) && ("attendanceReports" in res)) {
                    dispatch(attendancePayrollActions.setAttendanceReportView({ show: true, data: res.attendanceReports, columns: indiaLeaveReportColumns.leaveAvailedDetailReport, type: LeaveReportOptions[2], header: `Leaves Availed Detailed Report  from ${moment(formData.fromDate).format("MM/DD/YYYY")} to ${moment(formData.toDate).format("MM/DD/YYYY")}`, excelParams: { ...formData, ...res.attendanceAndLeaveReportsDate } }));
                    reset();
                }
            }));
        }
        setLoader(false);

    }

    return (
        <>
            <HeaderSection redirectType={strings.type.indiaAttendanceReport} />
            <div className='mx-6'>
                <SubHeaderSection subHeader="India Attendance Report " />
                <div className=' my-5 grid grid-cols-12 xl:grid-cols-12 items-center'>

                    <div className={leftSideStyle}><Label label={"Date"} required={true} /></div>
                    <div className={rightSideStyle}>
                        <DatePickerElement isRequired={true} value={watch(strings.leaveReports.date)} onChange={(date) => setValue(strings.leaveReports.date, date)} />
                    </div>

                    <div className={`${leftSideStyle}  mt-6`}><Label label={"Period"} required={true} /></div>
                    <div className={`${rightSideStyle} mt-6 `}>
                        <Dropdown isRequired={true} value={watch(strings.leaveReports.period)} onChange={data => periodDateFormat(data, setValue)} options={periodOptions.filter(val => (val.value !== 1 && val.value !== 7 && val.value !== 5))} />
                    </div>
                    <div className=' xl:col-start-5 lg:col-start-7 xsm:col-start-1 xl:col-end-7 lg:col-end-10 sm:col-end-6 xsm:col-end-12 ml-4'>
                        <DatePickerElement placeholder="From" value={watch(strings.leaveReports.fromDate)} onChange={data => setValue(strings.leaveReports.fromDate, data)} disabled={watch(strings.leaveReports.period).label !== strings.filterPeriod.custom} isLabelView={true} isRequired={true} />
                    </div>
                    <div className=' xl:col-start-7 lg:col-start-10 sm:col-start-6 xsm:col-start-1 xl:col-end-9 lg:col-end-13 sm:col-end-12 xsm:col-end-12 ml-4'>
                        <DatePickerElement placeholder="To" isRequired={true} isLabelView={true} value={watch(strings.leaveReports.toDate)} onChange={data => setValue(strings.leaveReports.toDate, data)} disabled={watch(strings.leaveReports.period).label !== strings.filterPeriod.custom} minDate={watch(strings.leaveReports.period).label === strings.filterPeriod.custom && watch(strings.leaveReports.fromDate)} />
                    </div>

                    <div className={`${leftSideStyle}  mt-6`}><Label label={"Select Attendance Report"} required={true} /></div>
                    <div className={`${rightSideStyle} mt-6 `}>
                        <Dropdown value={watch(strings.leaveReports.leaveReport)} onChange={data => setValue(strings.leaveReports.leaveReport, data)} options={LeaveReportOptions} isRequired={true} />
                    </div>

                </div>
                <div className='flex justify-center xsm:w-full xl:w-2/3'>
                    <span className=' font-normal flex justify-center my-4 h-10 text-lg w-52 '>
                        <AutoSizeButton value={"View Excel"} onClick={handleSubmit(onSubmit)} disabled={!(watch(strings.leaveReports.date) && watch(strings.leaveReports.fromDate) && watch(strings.leaveReports.toDate) && watch(strings.leaveReports.leaveReport))} icon={<RiFileExcel2Line size={22} />} />
                    </span>
                </div>
            </div>
            <>
                {loader && <TransparentLoader />}
                {apiResponseState.show && <ApiResponse />}
                {attendanceReportState.show && <AttendanceReportView />}
            </>
        </>
    )
}

export default IndiaLeaveReports

const initialValues = {
    date: new Date(),
    period: "",
    fromDate: "",
    toDate: "",
    leaveReport: ""
}
