
const ComplianceFooter = () => {

    const complianceLabel = [
        { color: 'bg-[#008000]', text: "Valid" },
        { color: 'bg-[#ff0000]', text: "Expired" },
        { color: 'bg-blue-600', text: "No Expiry" },
    ]

    return (
        <div className='flex items-center justify-end h-[2.5rem]'>
            {complianceLabel.map((val, key) => {
                return <div className=' flex items-center mr-4 gap-1.5' key={key}><span className={`w-4 h-4  block rounded-sm ${val.color}`}></span> <span className=' font-fontfamily text-13px font-bold leading-loose'>{val.text}</span> </div>
            })}
        </div>
    );
};

export default ComplianceFooter;