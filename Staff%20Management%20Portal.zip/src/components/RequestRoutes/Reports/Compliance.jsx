import { useEffect } from 'react'
import SubHeaderSection from '../../layouts/SubHeaderSection'
import { reportFields, setDefaultValue, strings } from '../../Constants'
import AgGrid from '../../Grid/AgGrid'
import { complianceReport } from '../../Grid/Columns'
import { useDispatch, useSelector } from 'react-redux'
import { employeeRequests, reportRequest } from '../../requests'
import ComplianceView from '../../Popup_window/ComplianceView'
import TransparentLoader from '../../loader/TransparentLoader'
import ApiResponse from '../../Alert/ApiResponse'
import ImageViewer from '../../ViewDocs/ImageViewer'
import { complianceReportDateFormat } from '../../helper'
import ComplianceFilter from '../../Filter/ComplianceFilter'
import { complianceReportActions } from '../../../redux/complianceReportReducer'
import MultiImageViewer from '../../ViewDocs/MultiImageViewer'
import ComplianceNotify from '../../Popup_window/ComplianceNotify'
import ComplianceFooter from './ComplianceFooter'
import ContinuousEducationReportPopup from '../../Popup_window/ContinuousEducationReportPopup'
import ComplianceNotifyMailPopup from '../../Popup_window/ComplianceNotifyMailPopup'

function Compliance() {
    const complianceReportState = useSelector(state => state.complianceReport);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const loginResponseState = useSelector(state => state.loginResponse);
    const employeeState = useSelector(state => state.employee);
    const userState = useSelector(state => state.user);
    const dispatch = useDispatch();
    useEffect(() => {
        const componentDidMount = async () => {
            await dispatch(reportRequest.setComplianceLoader(true));
            await Promise.all([
                complianceReportState.employeeType.length <= 0 && dispatch(reportRequest.getEmployeeType()),
                employeeState.employeeName.length <= 0 && dispatch(employeeRequests.employeeName()),
                employeeState.designation.length <= 0 && dispatch(employeeRequests.employeeDesignation()),
                dispatch(reportRequest.getComplianceReports({ employeeId: (userState.Role === strings.userRoles.admin || userState.Role === strings.userRoles.humanResource || userState.Role === strings.userRoles.superVisor) ? setDefaultValue.employeeName.value : userState.UserID, filter: userState.Role === strings.userRoles.superVisor ? setDefaultValue.complianceReportSupervisorType.label : setDefaultValue.complianceReportEmployeeType.label, supervisorEmpId: userState.Role === strings.userRoles.superVisor ? userState.UserID : 0 })),
                dispatch(complianceReportActions.setComplianceFilterValues({ employeeType: userState.Role === strings.userRoles.superVisor ? setDefaultValue.complianceReportSupervisorType : setDefaultValue.complianceReportEmployeeType, employeeName: setDefaultValue.employeeName, selectionYear: "", dateOfJoin: "", designation: "" }))
            ]);
            await dispatch(reportRequest.setComplianceView({ show: true }));
            dispatch(reportRequest.setComplianceLoader(false));
        }
        componentDidMount();
        // eslint-disable-next-line react-hooks/exhaustive-deps   
    }, []);

    return (
        <>
            <div className='mx-6'>
                <SubHeaderSection subHeader="Compliance Report - All Employees" fileProps={{ columns: complianceReport.columns(), data: complianceReportState.data.map((val, idx) => ({ ...val, sno: idx + 1, [reportFields.doj.label]: complianceReportDateFormat(val[reportFields.doj.label]), [reportFields.employeeEligibilityVerification.label]: complianceReportDateFormat(val[reportFields.employeeEligibilityVerification.label]), [reportFields.every3yearNyStateClinicalLicense.label]: complianceReportDateFormat(val[reportFields.every3yearNyStateClinicalLicense.label]), [reportFields.yearNyStateClinicalLicense.label]: complianceReportDateFormat(val[reportFields.yearNyStateClinicalLicense.label]), [reportFields.oneTimeEmployeeTraining.label]: complianceReportDateFormat(val[reportFields.oneTimeEmployeeTraining.label]), [reportFields.everyYearCompetencyAssessmentTest.label]: complianceReportDateFormat(val[reportFields.everyYearCompetencyAssessmentTest.label]), [reportFields.thirdMonthCompetencyAssessmentTest.label]: complianceReportDateFormat(val[reportFields.thirdMonthCompetencyAssessmentTest.label]), [reportFields.sixthMonthCompetencyAssessmentTest.label]: complianceReportDateFormat(val[reportFields.sixthMonthCompetencyAssessmentTest.label]), [reportFields.everyYearHippaPatientConfidentiality.label]: complianceReportDateFormat(val[reportFields.everyYearHippaPatientConfidentiality.label]), [reportFields.yearFireEducationTraining.label]: complianceReportDateFormat(val[reportFields.yearFireEducationTraining.label]), [reportFields.yearBiohazardWasteTraining.label]: complianceReportDateFormat(val[reportFields.yearBiohazardWasteTraining.label]), [reportFields.everyYearBloodbornPathogensTraining.label]: complianceReportDateFormat(val[reportFields.everyYearBloodbornPathogensTraining.label]), [reportFields.yearPPETraining.label]: complianceReportDateFormat(val[reportFields.yearPPETraining.label]), [reportFields.every3yearsDotTraining.label]: complianceReportDateFormat(val[reportFields.every3yearsDotTraining.label]), [reportFields.yearSexualHarassmentTraining.label]: complianceReportDateFormat(val[reportFields.yearSexualHarassmentTraining.label]), [reportFields.everyYearSupervisorPerformanceReview.label]: complianceReportDateFormat(val[reportFields.everyYearSupervisorPerformanceReview.label]), [reportFields.oneYearCovid19.label]: complianceReportDateFormat(val[reportFields.oneYearCovid19.label]), [reportFields.yearHandHygiene.label]: complianceReportDateFormat(val[reportFields.yearHandHygiene.label]) })), docName: "Compliance Report - All Employees", isPageBreak: true }} />
                <ComplianceFilter isModalView={true} />
                <div>
                    <AgGrid data={complianceReportState.data} columns={complianceReport.columns()} height="h-[calc(94vh-67px-1.5rem-3.5rem-2rem-1.6rem)] lg:h-[calc(94vh-67px-1.5rem-3.5rem-2rem-1.6rem)] md:h-[calc(94vh-67px-67px-1.5rem-3.5rem-2rem-1rem)] xsm:h-[70vh]" />
                </div>
                <ComplianceFooter />
            </div>
            {complianceReportState.loader && <TransparentLoader />}
            {apiResponseState.show && <ApiResponse />}
            {complianceReportState.complianceReportPopup.show && <ContinuousEducationReportPopup />}
            {complianceReportState.complianceView.show && <ComplianceView />}
            {!loginResponseState.multiDocumentViewer.show && loginResponseState.imageViewer.show && <ImageViewer />}
            {loginResponseState.multiDocumentViewer.show && <MultiImageViewer />}
            {complianceReportState.complianceNotify.show && <ComplianceNotify />}
            {complianceReportState.complianceNotifyMailDetails.show && <ComplianceNotifyMailPopup />}
        </>
    )
}

export default Compliance
