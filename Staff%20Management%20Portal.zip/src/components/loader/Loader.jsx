import PropTypes from 'prop-types';
import { useEffect } from 'react';
import { PuffLoader, PulseLoader } from 'react-spinners';
import { warningMessage } from '../Constants';

function Loader({ message, isFullHeight }) {

  useEffect(() => {
    let isValidInterVal;
    if (message === warningMessage.handlePopup_In_BlockState) {
      isValidInterVal = setInterval(() => {
        window.location.reload();
      }, 10000);
    }
    return () => {
      isValidInterVal && clearInterval(isValidInterVal);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [message]);

  return (
    <div className={` ${isFullHeight ? " h-full " : " h-screen "} w-full flex flex-col gap-4 justify-center items-center`}> <PuffLoader size={80} speedMultiplier={.5} color="#ef4641" className='loader' /><div className=' text-headerColor text-18px font-bold font-[cursive] flex flex-row items-end'>{message || <>loading please wait<PulseLoader size={4} speedMultiplier={.3} color="#ef4641" className=' mb-1' /></>}</div></div>
  )
}

export default Loader

Loader.propTypes = {
  message: PropTypes.string,
  isFullHeight: PropTypes.bool
}
