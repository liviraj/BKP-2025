import PropTypes from 'prop-types';
import { RingLoader } from 'react-spinners';

function TransparentLoader({ isFullWidth }) {
  return (
    <div className={` z-10 flex justify-center items-center absolute xsm:w-full h-employeeCalc_xsm md:h-employeeCalc_xsm xsm:h-full xsm:overflow-auto md:w-widthCalc top-[4.6rem] md:top-[4.6rem] xsm:top-0 bg-blurColor ${isFullWidth ? " !w-full !h-full !top-0" : ""}`}> <RingLoader size={80} speedMultiplier={2.5} color="#ef4641" className={isFullWidth ? "loader" : " loader"} /></div>
  )
}

export default TransparentLoader

TransparentLoader.propTypes = {
  isFullWidth: PropTypes.bool
}