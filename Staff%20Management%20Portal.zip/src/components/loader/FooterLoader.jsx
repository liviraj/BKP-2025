import PropTypes from 'prop-types';
import { FadeLoader, PulseLoader } from 'react-spinners'

function FooterLoader({ label }) {
  return (
    <div className=' fixed bottom-0 right-0 bg-[#fbe2e1] px-2 py-1  '>
      <div className=' flex justify-start items-center gap-1'>
        <FadeLoader height={6} width={3} margin={-12} radius={8} speedMultiplier={.3} color="#ef4641" className=' !top-[19px] -bottom-5 !left-5' />
        <span className='text-headerColor text-12px font-bold font-fontfamily flex flex-row items-end' >
          {label || "loading please wait"}
          <PulseLoader size={2} speedMultiplier={.3} color="#ef4641" className=' mb-1' />
        </span>
      </div>
    </div>
  )
}

export default FooterLoader

FooterLoader.propTypes = {
  label: PropTypes.string
}