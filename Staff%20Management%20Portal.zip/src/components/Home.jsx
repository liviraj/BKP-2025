/* eslint-disable react-refresh/only-export-components */
import { useCallback, useEffect, useRef, useState } from 'react'
import { useIsAuthenticated, useMsal } from '@azure/msal-react';
import { loginScopes, msalConfig } from '../config';
import { useDispatch, useSelector } from 'react-redux';
import Loader from './loader/Loader';
import AllRoutes from '../Router/router';
import { useHistory, withRouter } from 'react-router-dom';
import ProtectedRoutes from '../Router/ProtectedRoute';
import { IdleTimerProvider } from 'react-idle-timer';
import Sidebar from './layouts/Sidebar';
import { InitializeSessionStorage } from './helper';
import { documentPolicyRequest, loginRequest, userRequest } from './requests';
import { devices, routerPath, storageConstants, strings, warningMessage } from './Constants';
import { Dock } from 'react-dock';
import HeaderMenu from './layouts/HeaderMenu';
import ErrorBoundary from '../ErrorBoundary';
import { leaveManagementActions } from '../redux/leaveManagementReducer';
import { permissionAction } from '../redux/permissionReducer';
import Bowser from 'bowser';
import { loginResponseActions } from '../redux/loginResponseReducer';
import Notification from './layouts/Notification';

function Home() {

  const { instance, accounts } = useMsal();
  const isAuthenticated = useIsAuthenticated();
  const dispatch = useDispatch();
  const history = useHistory();
  const [time, setTime] = useState(1000 * 60 * 20);
  const [loader, setLoader] = useState(true);
  const userRole = useSelector(state => state.user.Role);
  const [isSidebarVisible, setIsSidebarVisible] = useState(false);
  const [message, setMessage] = useState("");
  const [notification, setNotification] = useState(false);
  const interval = useRef(null);
  const REFRESH_TOKEN_INTERVAL = 1200000; // 20 minute in milliseconds

  const mailRequestRedirect = async () => {

    let routerParams = sessionStorage.getItem(storageConstants.routerParams);
    routerParams = JSON.parse(routerParams);
    const data = await JSON.parse(decodeURIComponent(routerParams.params));

    if (routerParams.path.includes(routerPath.leaveRequestQueue)) {
      await dispatch(leaveManagementActions.setApproveLeaveRequest({ show: true, requestId: data.requestId, status: data.status }));
      setLoader(false);
      await history.push(routerPath.leaveRequestQueue);
    }
    else if (routerParams.path.includes(routerPath.permissionApproveRejectRequest)) {
      await dispatch(permissionAction.setRedirectPermissionRequest({ ...data, show: true }));
      setLoader(false);
      await history.push(routerPath.permissionApproveRejectRequest);
    }
    sessionStorage.removeItem(storageConstants.routerParams);

  }

  const updateUserdetails = async (params, role) => {
    await dispatch(userRequest.updateUserDetails({ UserCode: params.employeeCode, UserID: params.employeeId, ImageBinary: params.imageBinary, ImageName: params.imageName, Role: role, LocationID: params.locationId, FName: params.firstName, LName: params.lastName, MName: params.middleName }));
  }

  const loginResponseCallback = async (isValidUser, params) => {
    if (isValidUser) {
      dispatch(documentPolicyRequest.policyData.getNotificationRequest(params.employeeId));
      const routerParams = sessionStorage.getItem(storageConstants.routerParams);
      if (params.roleName === strings.userRoles.admin || params.roleName === strings.userRoles.humanResource) {
        await updateUserdetails(params, params.roleName === strings.userRoles.humanResource ? strings.userRoles.humanResource : strings.userRoles.admin);
        if (routerParams && routerParams.length > 0) {
          await mailRequestRedirect();
        }
        else {
          await history.push(routerPath.employeeDashboard);
        }
        await InitializeSessionStorage();
      }
      else if (params.roleName === strings.userRoles.superVisor) {
        await updateUserdetails(params, strings.userRoles.superVisor);
        if (routerParams && routerParams.length > 0) {
          await mailRequestRedirect();
        }
        else {
          await history.push(routerPath.employeeDashboard);
        }
      }
      else if (params.roleName === strings.userRoles.employee) {
        await updateUserdetails(params, strings.userRoles.employee);
        await history.push(routerPath.employeeDashboard);

      }
      else {
        await history.push(routerPath.unAuthorized);
      }
    }
    else {
      await history.push(routerPath.unAuthorized);
    }
    await setLoader(false);
  }

  useEffect(() => {
    const UserCredentials = async () => {
      setLoader(true);
      let userDetails = window.location.hash && window.location.hash.split('#/?').length > 1 && decodeURIComponent(window.location.hash.split('#/?')[1]).length > 0 && Object.keys(JSON.parse(decodeURIComponent(window.location.hash.split('#/?')[1]))).length > 0 && JSON.parse(decodeURIComponent(window.location.hash.split('#/?')[1]));
      const routerParams = sessionStorage.getItem(storageConstants.routerParams);
      const isValidLeaveRequestPath = (window.location.hash.includes(`#${routerPath.leaveRequestQueue}`) && window.location.hash.split("?")[0] === `#${routerPath.leaveRequestQueue}` && window.location.hash.split("?").length > 1);
      const isValidPermissionRequestPath = (window.location.hash.includes(`#${routerPath.permissionApproveRejectRequest}`) && window.location.hash.split("?")[0] === `#${routerPath.permissionApproveRejectRequest}` && window.location.hash.split("?").length > 1);
      if (Object.keys(userDetails).length <= 0) {
        if (!isAuthenticated && loader && (isValidLeaveRequestPath || routerParams || isValidPermissionRequestPath)) {
          const routerParams = { params: window.location.hash.split("?")[1], path: window.location.hash.split("?")[0] };
          (isValidLeaveRequestPath || isValidPermissionRequestPath) && sessionStorage.setItem(storageConstants.routerParams, JSON.stringify(routerParams));
        }
        try {
          await instance.ssoSilent(msalConfig);
        }
        catch (err) {
          await instance.loginPopup(msalConfig).catch(err => {
            if (err.toString().includes("Error opening popup window")) {
              setMessage(warningMessage.handlePopup_In_BlockState) // handle Popup Block
            }
            console.error(err)
          });
        }
      }
    }
    const checkIsMobileView = () => {
      const browser = Bowser.getParser(window.navigator.userAgent);
      const deviceType = browser.getPlatformType();
      if (deviceType === devices.mobile || deviceType === devices.tablet) {
        dispatch(loginResponseActions.setIsMobileCompatible(true));
      }
    }
    checkIsMobileView();
    UserCredentials();
    interval.current = setInterval(acquireTokenWithRefreshToken, REFRESH_TOKEN_INTERVAL);
    setLoader(false);
    return () => clearInterval(interval.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const request = {
    ...loginScopes,
    account: accounts[0]
  };

  useEffect(() => {
    setLoader(true);
    const UserCredentials = async () => {
      let userDetails = window.location.hash && window.location.hash.split('#/?').length > 1 && decodeURIComponent(window.location.hash.split('#/?')[1]).length > 0 && Object.keys(JSON.parse(decodeURIComponent(window.location.hash.split('#/?')[1]))).length > 0 && JSON.parse(decodeURIComponent(window.location.hash.split('#/?')[1]));
      userDetails = Object.keys(userDetails).length > 0 ? { ...userDetails } : {};
      if (Object.keys(userDetails).length > 0) {
        await dispatch(userRequest.updateUserDetails({ Name: userDetails.Name, Email: userDetails.Email, token: userDetails.token }));
        await dispatch(loginRequest.userInformation(loginResponseCallback));
      }
      else if (isAuthenticated) {
        await instance.acquireTokenSilent(request).then(async (response) => {
          await dispatch(userRequest.updateUserDetails({ Name: accounts[0].name, Email: accounts[0].username, token: response.accessToken }));
          await dispatch(loginRequest.userInformation(loginResponseCallback));

        }).catch(async (e) => {
          history.push(routerPath.unAuthorized);
          return e;
        });
      }

    };
    UserCredentials();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated]);

  const acquireTokenWithRefreshToken = async () => {
    try {
      if (accounts.length && instance) {
        const response = await instance.acquireTokenSilent(request);
        await dispatch(userRequest.updateUserDetails({ Name: accounts[0].name, Email: accounts[0].username, token: response.accessToken }));
      }
    } catch (error) {
      console.error('Error refreshing token', error);  // Handle token refresh error
    }
  }

  const onIdle = async () => {
    if (isAuthenticated) {
      acquireTokenWithRefreshToken();
      setTime(1000 * 60 * 20);
    }
  }

  const onAction = () => {
    setTime(1000 * 60 * 20);
  }

  const toggleSidebar = useCallback(() => {
    setIsSidebarVisible(prev => !prev);
  }, []);

  if (loader) {
    return <Loader message={message} />
  }
  else {
    return <ErrorBoundary>
      <IdleTimerProvider timeout={time} onIdle={onIdle} onAction={onAction} >
        <div className={` h-screen w-screen overflow-hidden `} >
          {(userRole === strings.userRoles.humanResource || userRole === strings.userRoles.admin || userRole === strings.userRoles.employee || userRole === strings.userRoles.superVisor) && (
            <div>
              <div><HeaderMenu onMenuUpdate={toggleSidebar} notificationMenu={() => setNotification(!notification)} /></div>
              <div className='dockStyle'>
                <Dock
                  position="right"
                  fluid={false}
                  dimStyle={{ opacity: 5 }}
                  size={300}
                  dimMode="opaque"
                  duration={100}
                  dockStyle={{ backgroundColor: "#c6362e" }}
                  isVisible={isSidebarVisible}
                  onVisibleChange={toggleSidebar}
                >
                  <Sidebar isDockable={true} onMenuUpdate={toggleSidebar} />
                </Dock>
              </div>
            </div>
          )}
          <div className='dockStyle w-[90vw] sm:w-[350]'>
            <Dock
              position="right"
              fluid={false}
              dimStyle={{ opacity: 5 }}
              dimMode="opaque"
              duration={400}
              isVisible={notification}
              size={window.innerWidth < 640 ? 300 : 370}
              onVisibleChange={() => setNotification(false)}
            >
              <Notification notificationMenu={() => setNotification(false)} />
            </Dock>
          </div>
          <div className='flex'>
            {(userRole === strings.userRoles.humanResource || userRole === strings.userRoles.admin || userRole === strings.userRoles.employee || userRole === strings.userRoles.superVisor) && <div className='xsm:hidden md:flex min-w-[17.7rem]'><Sidebar isDockable={false} onMenuUpdate={toggleSidebar} /></div>}
            <div className={(userRole === strings.userRoles.humanResource || userRole === strings.userRoles.admin || userRole === strings.userRoles.employee) ? ' xsm:w-full xsm:h-employeeCalc_xsm xsm:overflow-auto md:w-widthCalc md:h-employeeCalc_xsm md:overflow-auto' : 'w-full h-employeeCalc_xsm overflow-auto'}>
              <ProtectedRoutes Component={AllRoutes} />
            </div>
          </div>
        </div>
      </IdleTimerProvider>
    </ErrorBoundary>
  }
}

export default withRouter(Home)