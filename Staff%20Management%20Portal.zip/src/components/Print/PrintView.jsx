/* eslint-disable react/prop-types */
/* eslint-disable react-refresh/only-export-components */
import autoTable from 'jspdf-autotable';
import jsPDF from 'jspdf';
import { FcPrint } from "react-icons/fc";
import { useSelector } from 'react-redux';
import { useEffect, useState } from 'react';
import { dateFormat } from '../helper';
import PropTypes from 'prop-types';

export const headerComponent = (doc, head, startY) => {
    return autoTable(doc, {
        head,
        theme: "plain",
        styles: { fontSize: 13 },
        startY: startY || null,
        useCss: true,
        bodyStyles: { minCellHeight: 0, cellPadding: 0 },
        pageBreak: "auto",
        rowPageBreak: "avoid",
        showFoot: "never",
        didDrawPage: (data) => data.settings.margin.top = 100,
        horizontalPageBreak: false,
        horizontalPageBreakRepeat: 0,
        headStyles: { fontStyle: "normal", fillColor: "#b7b5b6", textColor: "black", lineWidth: 0, cellWidth: "auto", cellPadding: 3, valign: "middle" },
        margin: { left: 10, top: 10, right: 10, bottom: 0 },
        tableWidth: "auto",

    });
}

export const bodyComponent = (doc, body, startY) => {
    return autoTable(doc, {
        // head: [],
        body,
        theme: "plain",
        styles: { fontStyle: 11, overflow: "linebreak" },
        startY: startY || null,
        useCss: true,
        pageBreak: "auto",
        rowPageBreak: "avoid",
        horizontalPageBreak: false,
        horizontalPageBreakRepeat: 0,
        // headStyles: { fontStyle: "bold", fillColor: "#fff", textColor: "black", lineWidth: 0, cellWidth: "auto" },
        bodyStyles: { textColor: "black", cellWidth: "wrap", valign: "top", minCellHeight: 0, cellPadding: 1 },
        columnStyles: {
            0: { cellWidth: 70 },
            1: { fontStyle: "bold", cellWidth: 6, halign: "right" },
            2: { cellWidth: 110 }
        },
        didDrawPage: (data) => data.settings.margin.top = 100,
        margin: { left: 12, right: 20, top: 0 },
        showHead: "never",
        showFoot: "never",
        tableWidth: "auto",
    });
}

export const autoTableComponent = (doc, headers, data, startY, headStyles, bodyStyles, multiHeader) => {
    return autoTable(doc, {
        head: multiHeader || [headers],
        body: data,
        theme: "grid",
        styles: { fontSize: 9 },
        startY: startY || null,
        useCss: true,
        pageBreak: "auto",
        rowPageBreak: "avoid",
        horizontalPageBreak: false,
        horizontalPageBreakRepeat: 0,
        headStyles: headStyles || { fontStyle: "bold", fillColor: "#fff", textColor: "black", lineWidth: { bottom: 1, left: 0, right: 0, top: 0.5 }, cellWidth: "auto" },
        // alternateRowStyles: { lineWidth: { bottom: 0.5, left: 0, right: 0 } },
        bodyStyles: bodyStyles || { lineWidth: { bottom: 0.7, left: 0, right: 0 }, cellPadding: { left: 2, top: 2, bottom: 2, right: 0 } },
        didDrawPage: (data) => data.settings.margin.top = 10,
        tableLineColor: "#9d9d9d",
        margin: { left: 14, right: 14, top: 0 },
        tableWidth: "auto",
    });
}


export default function TablePrintView({ header, columns, data, orientation }) {
    const onhandlePrint = () => {
        const headers = columns.map(columnDef => columnDef.headerName);

        let printTableData = data.map(rowData => columns.map(columnDef => rowData[columnDef.field]));
        printTableData = printTableData.length <= 0 ? [[
            {
                content: "No Records Found!",
                colSpan: headers.length,
                styles: { halign: 'center' },
            },
        ]] : printTableData;

        const doc = new jsPDF({ orientation: orientation || "portrait" });
        doc.setFontSize(14);
        doc.setFont("helvetica", "bold");
        doc.setTextColor("#ef4641");
        doc.text(header, 7, 10);
        doc.setLineWidth(0.5);
        doc.setDrawColor("#ef4641");
        (orientation && orientation === 'landscape' ? doc.line(5, 13, 290, 13) : doc.line(5, 13, 205, 13))

        autoTableComponent(doc, headers, printTableData, 18);
        doc.autoPrint();
        printPreview(doc);
    }
    return <span className=' cursor-pointer inline-flex' onClick={onhandlePrint}><FcPrint size={24} /></span>
}
TablePrintView.propTypes = {
    header: PropTypes.string,
    columns: PropTypes.any,
    data: PropTypes.array,
    orientation: PropTypes.string
}

export function GenerateSummaryPrintView({ columns, data }) {
    const generateSummaryState = useSelector(state => state.eventManagement.generateSummary);
    const [employeeDetails, setEmployeeDetails] = useState({ name: "", position: "", description: "", period: "" })

    useEffect(() => {
        const onload = () => {
            let name = "", position = "", description = "", period = "";
            if (generateSummaryState.employeeDetails.length > 0) {
                const employeeDetailsState = generateSummaryState.employeeDetails[0];
                if ("Ename" in employeeDetailsState) {
                    name = employeeDetailsState.Ename;
                }
                if ("Description" in employeeDetailsState) {
                    description = employeeDetailsState.Description;
                }
                if ("Designation" in employeeDetailsState) {
                    position = employeeDetailsState.Designation;
                }
                period = `${dateFormat(generateSummaryState.selectedParams.fromDate)} - ${dateFormat(generateSummaryState.selectedParams.toDate)}`;
            }
            setEmployeeDetails({ name, position, description, period });
        }
        onload();

    }, [generateSummaryState]);

    const singleLineDoc = (doc, label, value, yPos) => {
        let x = 15, y = yPos;
        doc.text(label, x, y);
        doc.setFont("helvetica", "bold");
        x = x + 45;
        doc.text(":", x, y);
        doc.setFont("helvetica", "normal");
        doc.setTextColor("#818181");
        doc.text(value, x + 6, y);
        doc.setLineWidth(0.1);
        doc.line(x + 5, y + 1, 194, y + 1);
        doc.setTextColor("#000000");
    }

    const tripleLineDoc = (doc, yPos, program, participationHours, participationLevel, approvedByAbhi, content) => {
        let x = 15, y = yPos;
        const xTextPos = 60;

        singleLineDoc(doc, "Program", program, y);

        y += 5;
        doc.text("Participation Hours", x, y);
        doc.setFont("helvetica", "bold");
        doc.text(":", xTextPos, y);
        doc.setFont("helvetica", "normal");
        doc.setTextColor("#818181");
        doc.text(participationHours, xTextPos + 6, y);
        doc.setLineWidth(0.1);
        doc.line(xTextPos + 5, y + 1, xTextPos + 37, y + 1);

        doc.setTextColor("#000000");
        doc.text("Participation Level", xTextPos + 42, y);
        doc.setFont("helvetica", "bold");
        doc.text(":", xTextPos + 72, y);
        doc.setFont("helvetica", "normal");
        doc.setTextColor("#818181");
        doc.text(participationLevel, xTextPos + 76, y);
        doc.setLineWidth(0.1);
        doc.line(xTextPos + 75, y + 1, xTextPos + 134, y + 1);

        y += 5;
        doc.setTextColor("#000000");
        doc.text("Approved by ABHI?", x, y);
        doc.setFont("helvetica", "bold");
        doc.text(":", xTextPos, y);
        doc.setFont("helvetica", "normal");
        doc.setTextColor("#818181");
        doc.text(approvedByAbhi, xTextPos + 6, y);
        doc.setLineWidth(0.1);
        doc.line(xTextPos + 5, y + 1, xTextPos + 37, y + 1);

        doc.setTextColor("#000000");
        doc.text("Content", xTextPos + 42, y);
        doc.setFont("helvetica", "bold");
        doc.text(":", xTextPos + 72, y);
        doc.setFont("helvetica", "normal");
        doc.setTextColor("#818181");
        doc.text(content, xTextPos + 76, y);
        doc.setLineWidth(0.1);
        doc.line(xTextPos + 75, y + 1, xTextPos + 134, y + 1);
        doc.setTextColor("#000000");
    }

    const onhandlePrint = () => {
        const headers = columns.map(columnDef => columnDef.headerName);

        let printTableData = data.map(rowData => columns.map(columnDef => rowData[columnDef.field]));
        printTableData = printTableData.length <= 0 ? [[
            {
                content: "No Records Found!",
                colSpan: headers.length,
                styles: { halign: 'center' },
            },
        ]] : printTableData;
        // W   x H
        // 210 x 297

        const doc = new jsPDF({ orientation: "portrait" });
        doc.setFontSize(10);
        doc.setFont("helvetica", "bold");

        let yPos = 14;
        doc.text("ASHI #03-1-NY-26-2", 160, yPos);
        yPos += 4;
        doc.text("CLIA #33D0985173", 161.5, yPos);
        yPos += 4;
        doc.text("UNOS #", 179.5, yPos);
        yPos += 4;
        doc.text(`Date : 06/06/2024`, 15, yPos);
        yPos += 4;
        doc.text("G. CONTINUING EDUCATION SUMMARY FORM", 70, yPos);
        doc.setFontSize(8);
        yPos += 6;
        doc.text("The minimum hours of continuing education will be met if the individual is ABHI certified and has maintained continued certification.", 15, yPos);
        yPos += 4;
        doc.text("For directors/technical supervisors not maintaining continued certification, a minimum of 50 hours/year is required. For general", 15, yPos);
        yPos += 4;
        doc.text("supervisors not maintaining contiued certification, a minimum of 27 hours/year is required. For those testing personnel not maintaining", 15, yPos);
        yPos += 4;
        doc.text("continued certification, a minimum of 12 hours/year is required. ", 15, yPos);
        doc.setFont("helvetica", "normal");
        doc.setFontSize(9);
        yPos += 8;
        singleLineDoc(doc, "Name", employeeDetails.name, yPos);
        yPos += 5;
        singleLineDoc(doc, "Position", employeeDetails.position, yPos);
        yPos += 5;
        singleLineDoc(doc, "Description", employeeDetails.description, yPos);
        yPos += 5;
        singleLineDoc(doc, "Period", employeeDetails.period, yPos);
        yPos += 5;
        generateSummaryState.summary && generateSummaryState.summary.length > 0 ?
            generateSummaryState.summary.map(val => {
                yPos += 1;
                tripleLineDoc(doc, yPos, ("Program" in val) && val.Program ? val.Program : "", ("PartHrs" in val) && val.PartHrs ? val.PartHrs : "", ("PartLevel" in val) && val.PartLevel ? val.PartLevel : "", ("AbhiApproval" in val) && val.AbhiApproval ? val.AbhiApproval : "", ("Contents" in val) && val.Contents ? val.Contents : "");
                yPos += 15;
                return doc;
            }) : tripleLineDoc(doc, yPos, "", "", "", "", "");

        yPos += generateSummaryState.summary && generateSummaryState.summary.length > 0 ? 5 : 20;
        doc.setFont("helvetica", "bold");
        doc.text("Summary of contact hours by type :", 15, yPos);
        yPos += 3;
        doc.setFont("helvetica", "normal");
        autoTableComponent(doc, headers, printTableData, yPos);
        yPos = doc.lastAutoTable.finalY + 6;
        doc.setTextColor("#ef4641");
        doc.text("Copyright(c) 2001 by the American Society of Histocompatibility and immunogenetics, Lenexa, Kansas.", 105, yPos, null, null, "center");
        yPos += 4;
        doc.text("All Rights Reserved. No part of the contents of this document may be reproduced or transmitted in any form or by any means", 105, yPos, null, null, "center");
        yPos += 4;
        doc.text("without the written permission of the publisher.", 105, yPos, null, null, "center");
        yPos += 3;
        doc.text("Rev. 12/9", 196, yPos, null, null, "right");

        doc.autoPrint();
        printPreview(doc);
    }

    return <span className=' cursor-pointer inline-flex' onClick={onhandlePrint}><FcPrint size={24} /></span>
}

GenerateSummaryPrintView.propTypes = {
    columns: PropTypes.array,
    data: PropTypes.array
}

export const printPreview = (doc) => {
    const hiddFrame = document.createElement('iframe');
    hiddFrame.style.position = 'fixed';
    hiddFrame.style.width = '1px';
    hiddFrame.style.height = '1px';
    hiddFrame.style.opacity = '0.01';
    const isSafari = /^((?!chrome|android).)*safari/i.test(window.navigator.userAgent);
    if (isSafari) {
        // fallback in safari
        hiddFrame.onload = () => {
            try {
                if (hiddFrame.contentWindow) {
                    hiddFrame.contentWindow.focus();
                    hiddFrame.contentWindow.print();
                }
            } catch (e) {
                hiddFrame.contentWindow.print();
            }
        };
    }
    hiddFrame.src = doc.output('bloburl');
    document.body.appendChild(hiddFrame);
}

export function FacilityPersonalPritView({ columns, data }) {
    const onhandlePrint = () => {
        const header = columns.fieldHeader.map(columnDef => columnDef.headerName);
        let printTableData = data && columns.fieldHeader && data.map(rowData => columns.fieldHeader.map(columnDef => rowData[columnDef.field]));
        printTableData = printTableData.length <= 0 ? [[
            {
                content: "No Records Found!",
                colSpan: header.length,
                styles: { halign: 'center' },
            },
        ]] : printTableData;
        const doc = new jsPDF({ orientation: "landscape" });
        doc.setFontSize(10);
        let yPos = 14;
        doc.text("New York State Department", 15, yPos);
        yPos += 4;
        doc.text("Wadsworth center", 15, yPos);
        yPos += 4;
        doc.text("Clinical Laboratory Evaluation program", 15, yPos);
        yPos += 4;
        doc.text("Empire state plaza", 15, yPos);
        yPos += 4;
        doc.text("p.o Box 509", 15, yPos);
        yPos += 4;
        doc.text("Albany", 15, yPos);
        yPos += 4;
        doc.text("New york 12201 - 0509", 15, yPos);
        yPos += 4;
        doc.setFont("helvetica", "bold");
        doc.text("Telephone:", 15, yPos);
        doc.setFont("helvetica", "normal");
        doc.text("(518) 485 5378", 35, yPos);
        yPos += 4;
        doc.setFont("helvetica", "bold");
        doc.text("FAX:", 15, yPos);
        doc.setFont("helvetica", "normal");
        doc.text("(518) 485 5414", 25, yPos);
        yPos += 4;
        doc.setFont("helvetica", "bold");
        doc.text("Email:", 15, yPos);
        doc.setFont("helvetica", "normal");
        doc.text("CLEP@health.state.ny.us", 27, yPos);
        yPos += 4;
        doc.setFont("helvetica", "bold");
        doc.text("web:", 15, yPos);
        doc.setFont("helvetica", "normal");
        doc.text("www.wadsworth.org/labcert/clep/clep.html", 25, yPos);
        yPos = 14;
        doc.setFont("helvetica", "bold");
        doc.text("Laboratory :", 230, yPos);
        doc.setFont("helvetica", "normal");
        doc.text("7962", 255, yPos);
        yPos += 4;
        doc.setFont("helvetica", "bold");
        doc.text("Name and Adress of Laboratory :", 195, yPos);
        doc.setFont("helvetica", "normal");
        doc.text("HistoGenetics Inc", 255, yPos);
        yPos += 4;
        doc.text("300 Executive BLVD", 255, yPos);
        yPos += 4;
        doc.text("Ground FL", 255, yPos);
        yPos += 4;
        doc.text("Ossining", 255, yPos);
        yPos += 4;
        doc.text("NY 10562", 255, yPos);
        yPos += 4;
        doc.setFont("helvetica", "bold");
        doc.text("Consultant :", 230, yPos);
        yPos = 65
        doc.text("FACILITY PERSONNEL", 130, yPos);
        yPos += 5;
        doc.setFont("helvetica", "normal");
        const headStyles = { fontStyle: "bold", fillColor: "#fff", textColor: "black", lineWidth: { bottom: 0.3, left: 0.3, right: 0.3, top: 0.3 }, cellWidth: "auto" };
        const bodyStyles = { lineWidth: { bottom: 0.3, left: 0.3, right: 0.3, top: 0.3 }, cellPadding: { left: 2, top: 2, bottom: 2, right: 0 } };
        autoTableComponent(doc, [], printTableData, yPos, headStyles, bodyStyles, columns.multiLineHeader);
        doc.setFont("helvetica", "bold");
        yPos = doc.lastAutoTable.finalY + 5;
        doc.text("S=Supervisor; MT=Medical Technologist; MLT=Medical Laboratory Technician; CT=Cytotechnologist; HT=Histotechnologist", 15, yPos);
        doc.autoPrint();
        printPreview(doc);
    }

    return <span className=' cursor-pointer inline-flex' onClick={onhandlePrint}><FcPrint size={24} /></span>
}
FacilityPersonalPritView.propTypes = {
    columns: PropTypes.array,
    data: PropTypes.array
}