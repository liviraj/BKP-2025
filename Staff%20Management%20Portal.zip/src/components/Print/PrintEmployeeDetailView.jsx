import Button from '../elements/Button';
import 'react-responsive-modal/styles.css';
import { useSelector } from 'react-redux';
import { dateFormat } from '../helper';
import jsPDF from 'jspdf';
import { employeeDetails } from '../Grid/Columns';
import { autoTableComponent, bodyComponent, headerComponent, printPreview } from './PrintView';
import { strings } from '../Constants';

function PrintEmployeeDetailView() {
    const employeeDetailState = useSelector(state => state.employee.employeeDetailView);

    const onCustomPrint = () => {

        const personalDetailsdata = employeeDetailState.data.personalDetail;
        const personalDetails = [
            ["Employee Code", ":", personalDetailsdata.employeeCode],
            ["Employee Name", ":", personalDetailsdata.employeeName],
            ["Date Of Birth", ":", dateFormat(personalDetailsdata.dob)],
            ["Marital Status", ":", personalDetailsdata.maritalstatus],
            ["Gender", ":", personalDetailsdata.gender],
            ["Passport Number", ":", personalDetailsdata.passportNo]
        ];
        let workDetailsData = employeeDetailState.data.workDetail;
        workDetailsData = workDetailsData && typeof (workDetailsData) === "object" && workDetailsData.length > 0 ? workDetailsData[0] : {};
        const workDetails = [
            ["Designation", ":", workDetailsData.designationName],
            ["Section", ":", workDetailsData.departmentName],
            ["Date Of Join", ":", dateFormat(workDetailsData.doj)],
            ["Employee Type", ":", workDetailsData.employeeType],
            ["Work Location", ":", workDetailsData.locationCountry],
            ["Employment Status", ":", workDetailsData.employmentStatus],
            ["Confirmation Date", ":", dateFormat(workDetailsData.confirmationDate)],
            ["Relieving Date", ":", dateFormat(workDetailsData.relievingDate)]
        ];
        const communicationDetailState = employeeDetailState.data.communicationDetail;
        const communicationDetails = [
            ["Email ID", ":", communicationDetailState.emailID],
            ["Mobile No", ":", communicationDetailState.mobileNo],
            ["Land Line No", ":", communicationDetailState.phoneno],
            ["Address", ":", communicationDetailState.address1],
            ["Emergency Contact Name", ":", communicationDetailState.emergencyContactName],
            ["Relation", ":", communicationDetailState.emergencyContactRelation],
            ["Emergency Phone No", ":", communicationDetailState.emergencyContactNumber],
            ["Emergency Address", ":", communicationDetailState.emergencyAddress]
        ];
        const printQualificationColumns = employeeDetails.qualificationColumns().filter((val, idx) => idx !== (employeeDetails.qualificationColumns().length - 1));
        const qualificationHeaders = printQualificationColumns.map(columnDef => columnDef.headerName);
        let printQualificationData = employeeDetailState.data.qualification.map(rowData => printQualificationColumns.map(columnDef => columnDef.field === "courseEndDate" ? dateFormat(rowData[columnDef.field]) : rowData[columnDef.field]));
        printQualificationData = printQualificationData.length <= 0 ? [[
            {
                content: "No Records Found!",
                colSpan: qualificationHeaders.length,
                styles: { halign: 'center' },
            },
        ]] : printQualificationData;
        const printContinuousEducationColumns = employeeDetails.continuousEducationDetailViewColumns().filter((val, idx) => idx !== (employeeDetails.continuousEducationDetailViewColumns().length - 1));
        const continousEducationHeaders = printContinuousEducationColumns.map(columnDef => columnDef.headerName);
        let printContinousEducationData = employeeDetailState.data.continuousEducation.map(rowData => printContinuousEducationColumns.map(columnDef => rowData[columnDef.field]));
        printContinousEducationData = printContinousEducationData.length <= 0 ? [[
            {
                content: "No Records Found!",
                colSpan: continousEducationHeaders.length,
                styles: { halign: 'center' },
            },
        ]] : printContinousEducationData;
        const printWorkHistoryColumns = employeeDetails.workHistory_columns().filter((val, idx) => idx !== 0 && idx !== (employeeDetails.workHistory_columns().length - 1));
        const workHistoryHeaders = printWorkHistoryColumns.map(columnDef => columnDef.headerName);
        let printWorkHistoryData = employeeDetailState.data.workHistory.map(rowData => printWorkHistoryColumns.map(columnDef => columnDef.field === "dateOfJoin" || columnDef.field === "relievingDate" ? dateFormat(rowData[columnDef.field]) : rowData[columnDef.field]));
        printWorkHistoryData = printWorkHistoryData.length <= 0 ? [[
            {
                content: "No Records Found!",
                colSpan: workHistoryHeaders.length,
                styles: { halign: 'center' },
            },
        ]] : printWorkHistoryData;

        const doc = new jsPDF({ orientation: "portrait" });
        doc.setFontSize(14);
        doc.setFont("helvetica", "bold");
        doc.setTextColor("#ef4641");
        doc.text("Employee Details", 7, 10);
        doc.setLineWidth(0.5);
        doc.setDrawColor("#ef4641");
        doc.line(5, 13, 205, 13);

        headerComponent(doc, [["Personal"]], 18);
        bodyComponent(doc, personalDetails, 32);
        headerComponent(doc, [["Work"]], doc.lastAutoTable.finalY + 4);
        bodyComponent(doc, workDetails, doc.lastAutoTable.finalY + 2);
        headerComponent(doc, [["Communication"]], doc.lastAutoTable.finalY + 4);
        bodyComponent(doc, communicationDetails, doc.lastAutoTable.finalY + 2);
        headerComponent(doc, [["Qualification"]], doc.lastAutoTable.finalY + 4);
        autoTableComponent(doc, qualificationHeaders, printQualificationData, doc.lastAutoTable.finalY + 3);

        if (doc.lastAutoTable.finalY > 250 && doc.lastAutoTable.finalY < 300) {
            doc.lastAutoTable.finalY = 310;
        }
        headerComponent(doc, [["Continuous Education"]], doc.lastAutoTable.finalY + 4);
        autoTableComponent(doc, continousEducationHeaders, printContinousEducationData, doc.lastAutoTable.finalY + 3);

        if (doc.lastAutoTable.finalY > 250 && doc.lastAutoTable.finalY < 300) {
            doc.lastAutoTable.finalY = 310;
        }
        headerComponent(doc, [["Work History"]], doc.lastAutoTable.finalY + 4);
        autoTableComponent(doc, workHistoryHeaders, printWorkHistoryData, doc.lastAutoTable.finalY + 3);

        doc.autoPrint();
        printPreview(doc);

    }


    return (
        <div className=' h-full'>
            <Button value={strings.Buttons.Print} onClick={() => onCustomPrint()} />
        </div>
    )
}

export default PrintEmployeeDetailView