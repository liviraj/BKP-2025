import PropTypes from 'prop-types'
import { SiTicktick } from "react-icons/si";
import { LinearProgress as ProgressBar } from '@mui/material';


export default function LinearProgress({ value, completedTasks, totalTasks }) {
    return (
        <div className="flex items-center gap-2">
            <div className="flex-1"> <ProgressBar variant="determinate" value={Number(value)} sx={{
                height: '10px', borderRadius: '5px', backgroundColor: '#e0e0e0', '& .MuiLinearProgress-bar': { backgroundColor: (completedTasks && totalTasks && completedTasks === totalTasks) ? "#4CAF50" : "#dca225" }
            }} />  </div>
            {(completedTasks && totalTasks && completedTasks === totalTasks) ? (<div className="w-5 h-5 text-[#4CAF50]">  <SiTicktick className="w-full h-full" />  </div>) : ((totalTasks <= 0 && completedTasks <= 0) ? (<div className="w-5 h-5 text-[#e0e0e0]"> <SiTicktick className="w-full h-full" /> </div>) : (<div className="w-5 h-5 text-[#dca225]"> <SiTicktick className="w-full h-full" />  </div>))}
        </div>
    )
}

LinearProgress.propTypes = {
    value: PropTypes.number,
    completedTasks: PropTypes.number,
    totalTasks: PropTypes.number
}