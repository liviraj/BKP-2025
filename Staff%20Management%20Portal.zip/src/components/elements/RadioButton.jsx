import PropTypes from 'prop-types';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';

function RadioButton({ value, onChange, options, disabled, customColor }) {
    return (
        <RadioGroup row value={value} onChange={onChange} className={`font-fontfamily text-12px`}  >
            {
                options.map((val, index) => <FormControlLabel key={index} disabled={disabled} value={val} control={<Radio disabled={disabled} style={customColor ? { color: customColor } : {}} className={`${disabled ? ' opacity-60' : ''}`} sx={{ color: "grey", '&.Mui-checked': { color: customColor || "#ef4641", }, }} />} label={val} />)
            }
        </RadioGroup>
    )
}

export default RadioButton

RadioButton.propTypes = {
    value: PropTypes.string,
    onChange: PropTypes.func,
    options: PropTypes.array,
    disabled: PropTypes.bool,
    customColor: PropTypes.string
}