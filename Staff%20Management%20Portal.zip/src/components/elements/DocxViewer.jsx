import { useEffect, useRef } from 'react'
import PropTypes from "prop-types";
import { renderAsync } from "docx-preview";

export default function DocxViewer({ docxViewerData }) {
    const containerRef = useRef(null);
    useEffect(() => {
        if (docxViewerData) {
            // Convert Base64 to a Blob
            const binaryData = atob(docxViewerData);
            const byteArray = new Uint8Array(binaryData.length);
            for (let i = 0; i < binaryData.length; i++) {
                byteArray[i] = binaryData.charCodeAt(i);
            }
            const blob = new Blob([byteArray], { type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" });

            // Render the DOCX file inside the div
            renderAsync(blob, containerRef.current);
            // For pdf
            // renderAsync(blob, containerRef.current, null, {
            //     ignoreWidth: true,
            //     ignoreHeight: true,
            //     ignoreFonts: true,
            //     breakPages: true,
            //     useBase64URL: false,
            //     inWrapper: true
            // });
        }
    }, [docxViewerData]);

    return <div ref={containerRef} />;
}
DocxViewer.propTypes = {
    docxViewerData: PropTypes.string
}