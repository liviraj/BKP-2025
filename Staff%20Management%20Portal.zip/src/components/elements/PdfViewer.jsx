import { useEffect, useState } from "react";
import PropTypes from "prop-types";

export default function PdfViewer({ PdfViewerData, isRemoveHeader }) {

    const [pdfUrl, setPdfUrl] = useState("");

    useEffect(() => {
        if (PdfViewerData) {
            try {
                let base64String = PdfViewerData;

                // Ensure Base64 starts with proper metadata
                if (!base64String.startsWith("data:application/pdf;base64,")) {
                    base64String = "data:application/pdf;base64," + base64String;
                }

                // Convert Base64 to Blob
                const byteCharacters = atob(base64String.split(",")[1]); // Remove metadata
                const byteNumbers = new Array(byteCharacters.length);
                for (let i = 0; i < byteCharacters.length; i++) {
                    byteNumbers[i] = byteCharacters.charCodeAt(i);
                }
                const byteArray = new Uint8Array(byteNumbers);
                const blob = new Blob([byteArray], { type: "application/pdf" });

                // Create Blob URL and set state immediately
                const url = URL.createObjectURL(blob);
                setPdfUrl(url);
            } catch (error) {
                console.error("Error loading PDF:", error);
            }
        }
    }, [PdfViewerData]);

    return <iframe src={pdfUrl + (isRemoveHeader ? "#toolbar=0&navpanes=0&scrollbar=0&view=FitH" : "")} title="PDF Viewer" className=" h-full w-full bg-white border-none" />;
}

PdfViewer.propTypes = {
    PdfViewerData: PropTypes.string,
    isRemoveHeader: PropTypes.bool
}