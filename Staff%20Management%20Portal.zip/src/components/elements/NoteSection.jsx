import PropTypes from "prop-types"

function NoteSection({ notes }) {
    return (
        <footer className=" bg-themeBgColor border-l-4 border-borderThemeColor border-solid text-[#3f3e3e] font-medium text-12px sm:mx-8 xsm:mx-4 flex flex-row mt-4 p-3 gap-1">
            <span className=" flex whitespace-nowrap">Note :</span>
            <span className=" flex">{notes}</span>
        </footer>
    )
}

export default NoteSection

NoteSection.propTypes = {
    notes: PropTypes.string.isRequired
}