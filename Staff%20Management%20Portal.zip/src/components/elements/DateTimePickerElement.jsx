import PropTypes from 'prop-types';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';
import { userReducerState } from '../helper';
import { setDefaultValue } from '../Constants';
import { FcPlanner } from 'react-icons/fc';
import { DesktopDateTimePicker } from '@mui/x-date-pickers';

const DateTimePickerElement = ({ value, onChange, maxDate, minDate, isRequired, disabled }) => {

    const onhandleBlur = (e) => {
        const date = e.target.value;
        if (!date || isNaN(new Date(date))) {
            onChange("");
        }
    }

    return (
        <div className={`flex items-end min-h-[38px] py-[2px] ${disabled ? 'opacity-50' : ''}`}>
            <span className={'Custom-datePicker custom-datetimepicker'}>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <DemoContainer components={['DateTimePicker', 'DateTimePicker']}>
                        <DesktopDateTimePicker
                            views={['year', 'month', 'day', 'hours', 'minutes', 'seconds']}
                            value={value || null}
                            onChange={onChange}
                            className={isRequired ? "date-picker datetimerequired" : "date-picker datetimenormal font-normal label-shadow "}
                            maxDateTime={maxDate ? dayjs(maxDate) : null}
                            minDateTime={minDate ? dayjs(minDate) : dayjs("01/01/1100")}
                            disabled={disabled}
                            format={userReducerState().LocationID === setDefaultValue.location.value ? "DD/MM/YYYY HH:mm:ss" : "MM/DD/YYYY HH:mm:ss"}
                            slots={{ openPickerIcon: FcPlanner }}
                            ampm={false}
                            slotProps={{
                                textField: {
                                    onBlur: onhandleBlur
                                },
                            }}
                        />
                    </DemoContainer>
                </LocalizationProvider>
            </span>
        </div>
    );
};

export default DateTimePickerElement;

DateTimePickerElement.propTypes = {
    value: PropTypes.any,
    onChange: PropTypes.func,
    maxDate: PropTypes.any,
    minDate: PropTypes.any,
    isRequired: PropTypes.bool,
    disabled: PropTypes.bool
}