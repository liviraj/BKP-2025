import PropTypes from 'prop-types';
import CreatableSelect from 'react-select/creatable';

function Dropdown({ placeholder, value, onChange, options, isSearchable, isDisable, isLabelView, isMenuTopPlacement, isRequired, isViewable, addStyle, isPopupView, isClearable, isMultiSelect }) {
    return (
        <div>
            {isLabelView && <label className={` relative top-2 font-fontfamily text-14px tracking-wide font-extrabold text-darkCustomGrey ${!(placeholder && value && Object.keys(value).length > 0) && "invisible"}`}>{placeholder && value && Object.keys(value).length > 0 ? placeholder : "Select"}</label>}
            <CreatableSelect
                isSearchable={isSearchable || !!(options && options.length >= 10)}
                isValidNewOption={() => false}
                formatCreateLabel={() => "Not Found"}
                placeholder={placeholder || "Select"}
                className={`w-full font-fontfamily MySelect ${isDisable ? "opacity-60" : ""} ${isRequired || isLabelView ? "font-bold" : "font-normal label-shadow"} ${addStyle || ""} ${isPopupView ? "setMaxPopupHeight" : ""} `}
                classNamePrefix="MySelect"
                isDisabled={isViewable || (isDisable || false)}
                isClearable={!!isClearable}
                value={value}
                onChange={onChange}
                options={options}
                menuPlacement={isMenuTopPlacement ? "top" : "auto"}
                isMulti={!!isMultiSelect}
            />
        </div>
    )
}

export default Dropdown

Dropdown.propTypes = {
    placeholder: PropTypes.string,
    value: PropTypes.any,
    onChange: PropTypes.func,
    options: PropTypes.array,
    isSearchable: PropTypes.bool,
    isDisable: PropTypes.bool,
    isLabelView: PropTypes.bool,
    isMenuTopPlacement: PropTypes.bool,
    isRequired: PropTypes.bool,
    isViewable: PropTypes.bool,
    addStyle: PropTypes.string,
    isPopupView: PropTypes.bool,
    isClearable: PropTypes.bool,
    isMultiSelect: PropTypes.bool
}
