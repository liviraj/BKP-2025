import { useState } from 'react';
import PropTypes from 'prop-types';
import Select from 'react-select';
import { FcSearch } from "react-icons/fc";

function SelectableSearchComponent({ children, onChange, options, placeholder, value, formatOptionLabel }) {

  const [isOpen, setIsOpen] = useState(false);

  const selectStyles = {
    control: (provided) => ({
      ...provided,
      minWidth: 240,
      margin: 8,
    }),
    menu: () => ({ boxShadow: 'inset 0 1px 0 rgba(0, 0, 0, 0.1)' }),
  };

  return (
    <div onClick={e => e.stopPropagation()}>
      <Dropdown
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        target={<button onClick={() => setIsOpen(!isOpen)}>{children}</button>}
      >
        <Select
          autoFocus
          backspaceRemovesValue={false}
          components={{ DropdownIndicator, IndicatorSeparator: null }}
          formatOptionLabel={formatOptionLabel}
          controlShouldRenderValue={false}
          hideSelectedOptions={false}
          isClearable={false}
          classNamePrefix={"MyPopupSelect"}
          menuIsOpen
          onChange={(newValue) => {
            onChange(newValue);
            setIsOpen(false);
          }}
          options={options}
          placeholder={placeholder}
          styles={selectStyles}
          tabSelectsValue={false}
          value={value}
        />
      </Dropdown>
    </div>
  )
}

export default SelectableSearchComponent

SelectableSearchComponent.propTypes = {
  children: PropTypes.element,
  onChange: PropTypes.func,
  options: PropTypes.array,
  placeholder: PropTypes.string,
  value: PropTypes.any,
  formatOptionLabel: PropTypes.any
}

const Menu = (props) => <div className=' bg-[#f9f9f9] rounded box-highlight-shadow mt-2 absolute z-[2]'  {...props} />;

const Blanket = (props) => <div className=' bottom-0 left-0 top-0 right-0 fixed z-[1]' {...props} />;

const Dropdown = ({ children, isOpen, target, onClose }) => (
  <div className=' relative'>
    {target}
    {isOpen ? <Menu>{children}</Menu> : <></>}
    {isOpen ? <Blanket onClick={onClose} /> : <></>}
  </div>
);

Dropdown.propTypes = {
  children: PropTypes.element,
  isOpen: PropTypes.bool,
  target: PropTypes.element,
  onClose: PropTypes.func
}

const DropdownIndicator = () => (
  <div className=' h-6 w-6 flex items-center' >
    <FcSearch size={18} />
  </div>
);
