
import PropTypes from 'prop-types';
import Draggable from 'react-draggable';
import { IoClose } from "react-icons/io5";
import { useEffect, useRef, useState } from 'react';

const DraggableModal = ({ onClose, Component, headerTitle }) => {
    const boxRef = useRef();
    const [positionn, setPositionn] = useState({ x: 0, y: 0 });

    useEffect(() => {
        const calculatePosition = () => {
            if (boxRef) {
                const { width, height } = boxRef.current.getBoundingClientRect();
                const viewportWidth = window.innerWidth;
                const viewportHeight = window.innerHeight;
                setPositionn({ x: (viewportWidth - (width)) / 2, y: (viewportHeight - height) / 2, });
            }
        }
        calculatePosition();
        window.addEventListener("resize", calculatePosition);
        return () => {
            window.removeEventListener("resize", calculatePosition);
            onClose();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const handleDrag = (_, data) => {
        setPositionn({ x: data.x, y: data.y });
    };

    return (
        <>
            <Draggable
                position={positionn}
                onDrag={handleDrag}
            >
                <div className={`absolute top-0 left-0 bg-white rounded-md z-10 border-1 border-t-0 max-w-[95vw] overflow-auto top-draggable-shadow  `} ref={boxRef}>
                    <div className=' flex font-fontfamily font-bold text-base justify-between px-2 tracking-wider py-2 bg-headerColor text-white h-[2.4rem] rounded-t-md mr-[1px] '>
                        <p>{headerTitle}</p> <div onClick={onClose} className=' cursor-pointer'><IoClose className=' text-[1.6rem]' /></div>
                    </div>
                    <div className=' overflow-y-auto'>{Component}</div>
                </div>
            </Draggable>
        </>
    );
};

export default DraggableModal;

DraggableModal.propTypes = {
    Component: PropTypes.element,
    onClose: PropTypes.func,
    headerTitle: PropTypes.string
}