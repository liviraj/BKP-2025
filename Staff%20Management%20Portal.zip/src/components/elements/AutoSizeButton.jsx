import PropTypes from 'prop-types';

function AutoSizeButton({ value, onClick, disabled, icon, isIconLastPos }) {
  return (
    <button disabled={disabled} className={`${disabled ? ' opacity-70 !cursor-not-allowed' : ""} bg-headerColor font-fontfamily cursor-pointer text-white px-5 py-1 rounded-sm h-full w-full flex justify-center items-center gap-2`} onClick={onClick}>{(!isIconLastPos && icon) || ""}{value}{(isIconLastPos && icon) || ""}</button>
  )
}

export default AutoSizeButton

AutoSizeButton.propTypes = {
  value: PropTypes.string,
  onClick: PropTypes.func,
  disabled: PropTypes.bool,
  icon: PropTypes.any,
  isIconLastPos: PropTypes.bool
}