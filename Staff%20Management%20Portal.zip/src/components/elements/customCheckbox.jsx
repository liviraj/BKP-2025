import PropTypes from 'prop-types';
import Tree from 'rc-tree';
import 'rc-tree/assets/index.css';

const CheckboxTree = ({ onCheck, treeData, checkedKeys, expandedKeys, autoExpandParent, filterTreeNode, onExpand, handleTitle, searchExpandedKeys, isDisable, disableCheckedKeys }) => {
  const onhandleChange = (item) => {
    if(!isDisable){ handleTitle(item.key)}
  }
  const renderTreeNodes = (data) =>
    data.map((item) => {
      const isParent = item.children && item.children.length > 0;
      let searchClass = searchExpandedKeys.includes(item.key) ? "checkboxSearchHilight" : "";
      const isDisableclass = disableCheckedKeys?.length > 0 && disableCheckedKeys.includes(item.key) ? "disable-rc-record" : "";
      const nodeClass = ` ${isParent ? "rc-parent" : "rc-child"} ${searchClass} ${isDisableclass}`;
      const newNode = {
        ...item, className: nodeClass, title: (<span onClick={() => onhandleChange(item)} >{item.title}</span>), ...(item.children ? { children: renderTreeNodes(item.children) } : {}),
      };
      return newNode;
    });


  return (
    <Tree checkable
      onCheck={onCheck}
      checkedKeys={checkedKeys}
      itemHeight={20}
      filterTreeNode={filterTreeNode}
      treeData={renderTreeNodes(treeData)}
      expandedKeys={expandedKeys}
      autoExpandParent={autoExpandParent}
      onExpand={onExpand}
      disabled={isDisable || false}
    >
    </Tree>
  );
};

export default CheckboxTree;

CheckboxTree.propTypes = {
  onCheck: PropTypes.func,
  treeData: PropTypes.any,
  checkedKeys: PropTypes.any,
  expandedKeys: PropTypes.any,
  autoExpandParent: PropTypes.any,
  filterTreeNode: PropTypes.any,
  onExpand: PropTypes.any,
  handleTitle: PropTypes.any,
  searchExpandedKeys: PropTypes.any,
  isDisable: PropTypes.bool,
  disableCheckedKeys: PropTypes.any,
}


