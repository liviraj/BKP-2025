import { Menu, MenuItem, SubMenu } from '@szhsin/react-menu';
import '@szhsin/react-menu/dist/index.css';
import { classNames } from '../Constants';
import { CiMenuKebab } from "react-icons/ci";
import PropTypes from 'prop-types';

function MenuView({ menuHeader, menuData }) {
    const menuView = (menuRecords, idx) => {
        const labelElement = <div className=' flex gap-2'>{menuRecords?.icon && menuRecords.icon} {menuRecords.label} </div>;
        if ("subMenu" in menuRecords && menuRecords?.subMenu.length > 0) {
            return <SubMenu key={`subMenu ${idx}`} className={`${classNames.contextMenuItem} !p-0 text-13px`} menuClassName={"headerMenu border border-solid border-white text-headerColor"} label={labelElement}>
                {menuRecords.subMenu.map((subMenuRecords, subIndex) => menuView(subMenuRecords, ((subIndex + idx) * 100)))}
            </SubMenu>
        } else {
            return <MenuItem key={`menu ${idx}`} className={`${menuRecords?.isDisable ? "p-2 !bg-white" : classNames.contextMenuItem} text-13px`} disabled={menuRecords?.isDisable} onClick={menuRecords.onClick}>{labelElement}</MenuItem>
        }
    }
    return (
        <Menu
            menuButton={<span className='flex justify-center items-center text-headerColor cursor-pointer '>{menuHeader || <CiMenuKebab size={17} style={{ strokeWidth: "1.5px" }} />}</span>}
            arrow={true}
            className={`${classNames.contextMenu} border-0`}
            gap={0}
            position="auto"
            overflow="visible"
            align='end'
            portal
            menuClassName={"headerMenu border border-solid border-white text-headerColor z-20"}
        >
            {menuData.map((data, idx) => menuView(data, idx))}
        </Menu>
    )
}

export default MenuView

MenuView.propTypes = {
    menuHeader: PropTypes.any,
    menuData: PropTypes.array
}