import PropTypes from 'prop-types';
import { useRef } from 'react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { FcPlanner, FcClock } from 'react-icons/fc';
import { dateFormat, exportYearFormat, userReducerState } from '../helper';
import { setDefaultValue } from '../Constants';
import moment from 'moment-timezone';

function DatePickerElement({ value, onChange, maxDate, minDate, isRequired, showYearDropdown, isLabelView, placeholder, disabled, isWeekday, isRemovable, isViewable, showTimeSelect, minTime, maxTime, disableHolidays, ismonthYear, setTimeInterval, onFocusOut, isDisableSunday }) {
  let _ref = useRef(null);
  
  const setWeekday = (date) => {
    const day = moment(date).get("day");
    if (disableHolidays && disableHolidays.length > 0) {
      const getDates = disableHolidays.find(val => val.year === exportYearFormat(date));
      if (getDates && ("holidayDates" in getDates) && getDates.holidayDates.length > 0) {
        if (isDisableSunday) {
          return !!(day !== 0 && !getDates.holidayDates.includes(dateFormat(date)));
        } else if (isWeekday) {
          return !!(day !== 0 && day !== 6 && !getDates.holidayDates.includes(dateFormat(date)));
        }
        return !(getDates.holidayDates.includes(dateFormat(date)));
      } else {
        if (isDisableSunday) {
          return day !== 0;
        }
        return day !== 0 && day !== 6;
      }
    }
    if (isWeekday) {
      return day !== 0 && day !== 6;
    } else if (isDisableSunday) {
      return day !== 0;
    }
    return true;
  };

  const onDateChange = (date) => {   
        if (date && moment(date).isValid()) {
      onChange(date);
          }
    else if (isRemovable) {
      onChange("");
    }
  }

  const onhandleFocusout = () => {
    if (moment(value).isValid() && showTimeSelect) {
      const validDate = moment(value).set({ date: 1, month: 1, year: 2024, seconds: 0, milliseconds: 0 });
      const validMinTime = minTime ? moment(minTime).set({ date: 1, month: 1, year: 2024, seconds: 0, milliseconds: 0 }) : false;
      const validMaxTime = maxTime ? moment(maxTime).set({ date: 1, month: 1, year: 2024, seconds: 0, milliseconds: 0 }) : false;
      if ((validMinTime && validMinTime.toDate().getTime() > validDate.toDate().getTime()) || (validMaxTime && validMaxTime.toDate().getTime() < validDate.toDate().getTime())) {
        onChange("");
      }
    }
    if (onFocusOut) {
      onFocusOut();
    }
  }

  return (
    <div>
      {isLabelView && <label className={` relative top-2 font-fontfamily text-14px w-full tracking-wide font-extrabold text-darkCustomGrey ${!(placeholder && value && new Date(value)) && "invisible"}`}>{placeholder && value && new Date(value) ? placeholder : "Select"}</label>}
      <div className={`flex items-end min-h-[38px] py-[2px] ${disabled ? 'opacity-50' : ''}`}>
        <span className={`Custom-datePicker ${showTimeSelect ? "custom-timePickerStyle" : ""}`}>
          <DatePicker
            disabledKeyboardNavigation
            dateFormat={showTimeSelect ? "h:mm aa" : (showYearDropdown ? "yyyy" : ismonthYear ? "MM/yyyy" : (userReducerState().LocationID === setDefaultValue.location.value ? "dd/MM/yyyy" : "MM/dd/yyyy"))}
            placeholderText={placeholder || (showTimeSelect ? "HH:MM AM/PM" : (showYearDropdown ? "YYYY" : ismonthYear ? "MM/YYYY" : (userReducerState().LocationID === setDefaultValue.location.value ? "DD/MM/YYYY" : "MM/DD/YYYY")))}
            ref={_ref}
            className={isRequired ? "date-picker font-bold" : "date-picker font-normal label-shadow "}
            disabled={disabled}
            // value={isNaN(new Date(value)) ? "" : !!showYearDropdown ? new Date(value) : dateFormat(value)}
            selected={isNaN(new Date(value)) ? null : new Date(value)}
            onChange={date => onDateChange(date)}
            maxDate={maxDate ? new Date(maxDate) : null}
            minDate={minDate ? new Date(minDate) : new Date("01/01/1100")}
            filterDate={setWeekday}
            dropdownMode="scroll"
            showYearPicker={!!showYearDropdown}
            showMonthDropdown
            showYearDropdown
            adjustDateOnChange={!!showTimeSelect}
            showTimeSelect={!!showTimeSelect}
            showTimeSelectOnly={!!showTimeSelect}
            timeIntervals={setTimeInterval || 15}
            timeCaption="Time"
            minTime={minTime && new Date(minTime)}
            maxTime={maxTime && new Date(maxTime)}
            onBlur={onhandleFocusout}
            showMonthYearPicker={!!ismonthYear}
          />
          {showTimeSelect
            ? <FcClock className={`calender-icon ${isViewable ? "!cursor-default" : ""}`} onClick={() => isViewable || _ref.current.setOpen(true)} />
            : <FcPlanner className={`calender-icon ${isViewable ? "!cursor-default" : ""}`} onClick={() => isViewable || _ref.current.setOpen(true)} />
          }
        </span>
      </div>
    </div>
  )
}

export default DatePickerElement

DatePickerElement.propTypes = {
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.object]).isRequired,
  onChange: PropTypes.func,
  maxDate: PropTypes.any,
  minDate: PropTypes.any,
  isRequired: PropTypes.bool,
  showYearDropdown: PropTypes.bool,
  isLabelView: PropTypes.bool,
  placeholder: PropTypes.string,
  disabled: PropTypes.bool,
  isWeekday: PropTypes.bool,
  isRemovable: PropTypes.bool,
  isViewable: PropTypes.bool,
  showTimeSelect: PropTypes.bool,
  minTime: PropTypes.any,
  maxTime: PropTypes.any,
  disableHolidays: PropTypes.array,
  ismonthYear: PropTypes.bool,
  setTimeInterval: PropTypes.number,
  onFocusOut: PropTypes.func,
  isDisableSunday: PropTypes.bool
}