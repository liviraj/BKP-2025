import PropTypes from 'prop-types';

function TextArea({ value, onChange, placeholder, isDisable, isRequired, height, isViewable }) {
    return (
        <textarea
            className={`bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full h-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-purple-500 ${isDisable ? "opacity-60" : ""} ${isRequired ? "font-bold" : "font-normal label-shadow"} ${height || " h-10"}  resize-none`}
            placeholder={placeholder || ""}
            rows={3}
            disabled={isDisable || isViewable}
            value={value || ""}
            onChange={onChange}
        />
    )
}

export default TextArea

TextArea.propTypes = {
    value: PropTypes.any,
    onChange: PropTypes.func,
    placeholder: PropTypes.string,
    isDisable: PropTypes.bool,
    isRequired: PropTypes.bool,
    height: PropTypes.string,
    isViewable: PropTypes.bool
}