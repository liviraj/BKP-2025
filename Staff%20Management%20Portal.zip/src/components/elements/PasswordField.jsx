import { useState } from 'react';
import PropTypes from 'prop-types';
import { VscEyeClosed, VscEye } from "react-icons/vsc";

function PasswordField({ value, onChange, placeholder, maxLength, isDisable, isSpacer }) {
    const [visibility, setVisibility] = useState(false);
    return (
        <div className="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full leading-tight flex focus:outline-purple-500 focus:border-purple-500 ">
            <input
                className={`bg-gray-200 flex appearance-none w-full py-2 ${isSpacer ? "pl-1" : "px-4"} text-gray-700 border-none focus:bg-white focus:border-solid focus:outline-none`}
                value={value}
                maxLength={maxLength || undefined}
                max={maxLength || undefined}
                disabled={isDisable || false}
                onChange={onChange}
                placeholder={placeholder || ""}
                type={visibility ? "text" : "password"}
            />
            <div className={` ${isSpacer ? "px-1" : "px-3"} flex items-center text-sm leading-5`}>
                <span className=' cursor-pointer text-darkCustomGrey' onClick={() => setVisibility(!visibility)}>{visibility ? <VscEyeClosed size={18} /> : <VscEye size={18} />}</span>
            </div>
        </div>
    )
}

export default PasswordField

PasswordField.propTypes = {
    value: PropTypes.string,
    onChange: PropTypes.func,
    placeholder: PropTypes.string,
    maxLength: PropTypes.number,
    isDisable: PropTypes.bool,
    isSpacer: PropTypes.bool
}