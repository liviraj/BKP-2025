import { FaPlus } from 'react-icons/fa6';
import PropTypes from 'prop-types';

function AddButton({ value, onClick, disabled = false, icon = <FaPlus size={16} /> }) {
  return (
    <>
      <div className={` ${disabled ? 'z-[1] opacity-70' : ''} border-[1.5px] border-solid border-white border-l-0 relative left-[23px] h-6`} />
      <div className={`${disabled ? ' opacity-70 !cursor-not-allowed' : ""} cursor-pointer flex flex-row items-center bg-green-600 border border-green-600 text-white rounded  hover:text-green-600 hover:border-green-600 hover:bg-white hover:z-[1]`} onClick={disabled ? () => { } : onClick}> <span className=' p-[2.5px] bg-green-600 text-white'> {icon}</span><span className=' font-fontfamily text-14px font-bold ml-[1px] px-1 tracking-wider '>{value}</span></div>
    </>
  )
}

export default AddButton

AddButton.propTypes = {
  value: PropTypes.string,
  onClick: PropTypes.func,
  disabled: PropTypes.bool,
  icon: PropTypes.any
}