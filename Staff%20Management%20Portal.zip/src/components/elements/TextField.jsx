import PropTypes from 'prop-types';

function TextField({ value, onChange, placeholder, isDisable, type, maxLength, isRequired, isNumField, isLabelView, addStyle, isReadOnly }) {
    const numberFieldSymbolException = ["e", "E", "+", "-", "."];
    return (
        <>
            {isLabelView && <label className={` relative top-2 font-fontfamily text-14px tracking-wide font-extrabold text-darkCustomGrey ${!(placeholder && value && Object.keys(value).length > 0) && "invisible"}`}>{placeholder && value && Object.keys(value).length > 0 ? placeholder : "Select"}</label>}
            <input
                className={` ${isLabelView ? ' border-b-2 border-gray-500 labelviewtext text-black text-[14px] font-semibold' : 'border-2 bg-gray-200 border-gray-200 rounded'} appearance-none   w-full h-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-purple-500 ${isDisable ? "opacity-60" : ""} ${isRequired || isLabelView ? "font-bold" : "font-normal label-shadow"} ${addStyle || ""} `}
                value={type && type.toLowerCase() === "number" && Number(value) === 0 ? "" : value}
                onChange={onChange}
                placeholder={placeholder || ""}
                disabled={isDisable || false}
                maxLength={maxLength || undefined}
                min={type && type.toLowerCase() === "number" ? 0 : undefined}
                max={maxLength || undefined}
                type={type || "text"}
                readOnly={!!isReadOnly}
                onKeyDown={e => type && type.toLowerCase() === "number" && !isNumField ? numberFieldSymbolException.includes(e.key) && e.preventDefault() : undefined}
            />
        </>
    )
}

export default TextField

TextField.propTypes = {
    value: PropTypes.any,
    onChange: PropTypes.func,
    placeholder: PropTypes.string,
    isDisable: PropTypes.bool,
    type: PropTypes.string,
    maxLength: PropTypes.number,
    isRequired: PropTypes.bool,
    isNumField: PropTypes.bool,
    isLabelView: PropTypes.bool,
    addStyle: PropTypes.string,
    isReadOnly: PropTypes.bool
}