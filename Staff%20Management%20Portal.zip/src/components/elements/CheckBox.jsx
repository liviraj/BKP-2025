import PropTypes from 'prop-types';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';

function CheckBox({ data, value, height, onChange, isDisable }) {
    return (
        <FormGroup style={{ height: height }}>
            {
                data?.map((val, idx) =>
                    <FormControlLabel
                        key={idx}
                        checked={!!value}
                        disabled={val.disabled || isDisable}
                        control={<Checkbox
                            //defaultChecked={val.defaultChecked}
                            //disabled={val.disabled}
                            onChange={onChange}
                            sx={{ zIndex: 0 }} // '&.Mui-checked': { color: "#ef4641", }
                        />}
                        label={val.label}
                        className={isDisable ? "opacity-60" : ""}
                    />
                )
            }
        </FormGroup>
    )
}

export default CheckBox

CheckBox.propTypes = {
    data: PropTypes.array,
    value: PropTypes.any,
    height: PropTypes.string,
    onChange: PropTypes.func,
    isDisable: PropTypes.bool
}
