import PropTypes from 'prop-types';
import { useDispatch } from 'react-redux'
import { userRequest, employeeRequests } from '../requests'

function LinkView({ value, type, imageId, onClick, addStyle }) {
    const dispatch = useDispatch();
    const onHandleClick = async () => {
        if (onClick) {
            onClick();
        }
        else {
            await dispatch(employeeRequests.loader(true));
            await dispatch(userRequest.getImageData(type, imageId));
            dispatch(employeeRequests.loader(false));
        }
    }
    return (
        <button className={` bg-transparent font-fontfamily cursor-pointer text-blue-600 underline ${addStyle || ""}`} onClick={() => onHandleClick()}>{value}</button>
    )
}

export default LinkView

LinkView.propTypes = {
    value: PropTypes.string,
    type: PropTypes.string,
    imageId: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
    onClick: PropTypes.func,
    addStyle: PropTypes.string
}