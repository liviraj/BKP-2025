import PropTypes from 'prop-types';
import { TimePicker } from '@mui/x-date-pickers/TimePicker';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import moment from 'moment-timezone';

const TimePickerElement = ({ value, onChange, minTime, maxTime, isRequired, disabled, isHourMinView, isViewable }) => {

  const onhandleBlur = (e) => {
    const date = e.target.value;
    if (!moment(date, 'HH:mm A', true).isValid()) {
      onChange("");
    }
  }

  return (
    <div className={`flex items-end min-h-[42px] py-[2px] ${disabled ? 'opacity-50' : ''}`}>
      <div className='Custom-timepicker'>
        <LocalizationProvider dateAdapter={AdapterDateFns}>
          <DemoContainer components={['TimePicker', 'TimePicker']}>
            <TimePicker
              views={isHourMinView ? ['hours', 'minutes'] : ['hours', 'minutes', 'seconds']}
              value={value || null}
              onChange={!isViewable && onChange}
              minTime={minTime || null}
              maxTime={maxTime || null}
              className={isRequired ? "requiredTimepicker date-picker" : "date-picker"}
              disabled={disabled || isViewable}
              autoFocus
              slotProps={{
                textField: {
                  placeholder: "HH:MM AM/PM",
                  onBlur: onhandleBlur
                },
              }}
            />
          </DemoContainer>
        </LocalizationProvider>
      </div>
    </div>
  );
};

export default TimePickerElement;

TimePickerElement.propTypes = {
  value: PropTypes.any,
  onChange: PropTypes.func,
  minTime: PropTypes.string,
  maxTime: PropTypes.string,
  isRequired: PropTypes.bool,
  disabled: PropTypes.bool,
  isHourMinView: PropTypes.bool,
  isViewable: PropTypes.bool
}