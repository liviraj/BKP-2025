import { useCallback } from "react";
import PropTypes from 'prop-types';
import { useDropzone } from "react-dropzone";
import { IoIosCloseCircle } from "react-icons/io";
import { fileToBase64Conversion, localFileDownload } from "../helper";
import { useDispatch } from "react-redux";
import { userRequest } from "../requests";


function UploadAndDeleteDocument({ label, onChange, file, isImageView, isViewable, isMultiDocument, fileType, isDisable }) {
    const dispatch = useDispatch();

    const viewDocument = (index) => {
        if (!isDisable) {
            ("path" in file[index]) ? localFileDownload(file[index]) : dispatch(userRequest.imageViewer({ show: true, data: file[index].binary, imageName: file[index].name }));
        }
    }

    const setCallBack = (file) => {
        onChange([file]);
    }

    const updateMultiDocument = (acceptedFiles, initialFiles) => {
        let tempFiles = structuredClone(initialFiles);
        for (const val of acceptedFiles) {
            fileToBase64Conversion(val, (convertedFile) => {
                tempFiles = [...tempFiles, convertedFile];
                onChange(tempFiles);
            });
        }
    }

    const onDrop = useCallback((acceptedFiles) => {
        if (acceptedFiles) {
            if (isMultiDocument) {
                updateMultiDocument(acceptedFiles, file);
            } else {
                fileToBase64Conversion(acceptedFiles[0], setCallBack);
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [file]);

    const setAcceptFileType = () => {
        if (isImageView) {
            return {
                'image/*': []
            };
        } else if (fileType) {
            return fileType;
        }
        return {};
    }

    const { getRootProps, getInputProps } = useDropzone({
        disabled: isViewable || isDisable,
        onDrop,
        accept: setAcceptFileType(),
        maxFiles: isMultiDocument ? 15 : 1,
        multiple: !!isMultiDocument
    });

    const handleDocumentRemove = (idx) => {
        onChange(file.filter((_val, index) => index !== idx));
    };

    if (!isMultiDocument && file && file.length > 0) {
        return <div className="flex items-center border-2 rounded bg-gray-400 border-solid border-darkGrey text-white font-bold h-full min-h-[38px] max-h-[38px]">
            {!(isViewable || isDisable) && <span className=" ml-3" onClick={() => handleDocumentRemove(0)}> <IoIosCloseCircle className=" text-darkGrey bg-white rounded-lg cursor-pointer text-lg hover:stroke-30px stroke-white stroke-2" /></span>}
            {<div className={`text-12px ${isDisable ? ' cursor-not-allowed' : 'cursor-pointer hover:underline '} whitespace-nowrap overflow-hidden text-ellipsis ml-3`} onClick={() => viewDocument(0)}>{file ? file[0].name : ""}</div>}
        </div>
    }
    return (
        <div className={`${isMultiDocument ? 'flex justify-center flex-col min-h-[8.6rem]' : ""} ${isDisable ? " opacity-50" : ""} `}>
            <div className=" flex">
                <div className={` flex justify-center items-center border-2 rounded  ${(isViewable || isDisable) ? "cursor-default" : "cursor-pointer"} bg-gray-200 border-solid border-darkGrey text-sidebarBgColor font-bold h-full min-h-[38px] max-h-[38px] w-full`}>
                    <div className=" h-full w-full " {...getRootProps({ onClick: evt => evt.stopPropagation() })}>
                        {
                            <div className=" h-full w-full flex justify-center items-center" {...getRootProps()}>
                                <input {...getInputProps()} />
                                <p className="m-0"> {label}</p>
                            </div>
                        }
                    </div>
                </div>
            </div>
            {isMultiDocument &&
                <div className=" mt-1 gap-1 flex flex-col max-h-24 overflow-auto grayScollBar px-1" >
                    {file && file.length > 0 && file.map((val, idx) =>
                        <div key={val.name + idx} className="flex items-center border-2 rounded bg-gray-400 border-solid border-darkGrey text-white font-bold h-full min-h-[38px] max-h-[38px]">
                            {!(isViewable || isDisable) && <span className=" ml-3" onClick={() => handleDocumentRemove(idx)}> <IoIosCloseCircle className=" text-darkGrey bg-white rounded-lg cursor-pointer text-lg hover:stroke-30px stroke-white stroke-2" /></span>}
                            <div className={` text-12px ${(isViewable || isDisable) ? "cursor-not-allowed" : "cursor-pointer"} whitespace-nowrap overflow-hidden text-ellipsis ml-3`} onClick={() => viewDocument(idx)}>{file ? file[idx].name : ""}</div>
                        </div>
                    )}
                </div>
            }
        </div>
    );
}

export default UploadAndDeleteDocument;

UploadAndDeleteDocument.propTypes = {
    label: PropTypes.string,
    onChange: PropTypes.func,
    file: PropTypes.array,
    isImageView: PropTypes.bool,
    isViewable: PropTypes.bool,
    fileType: PropTypes.object,
    isMultiDocument: PropTypes.bool,
    isDisable: PropTypes.bool,
}
