import PropTypes from 'prop-types';
import { Modal } from 'react-responsive-modal';
import { IoClose } from 'react-icons/io5';


const ModelBox = ({ Component, open, onClose, headerTitle, isHideHeader }) => {
    return (
        <Modal open={open} classNames={{ modal: 'p-0 !m-0 overflow-hidden  w-auto !rounded-md' }} showCloseIcon={false} onClose={onClose} onEscKeyDown={onClose}>
            <div className=' bg-white rounded-md' >
                {!isHideHeader &&
                    <div className={"flex font-fontfamily font-bold text-base rounded-t justify-between px-2 tracking-wider py-2 bg-headerColor text-white h-[2.4rem] absolute w-full z-20"}>
                        <span className='tracking-widest'>{headerTitle}</span><span className={' cursor-pointer'} >
                            <IoClose size={22} style={{ strokeWidth: "10px" }} onClick={onClose} />
                        </span>
                    </div>
                }
                <div className={isHideHeader ? "" : " pt-[2.4rem]"}>
                    {Component}
                </div>
            </div>
        </Modal>
    )

}

export default ModelBox;

ModelBox.propTypes = {
    Component: PropTypes.element,
    open: PropTypes.bool,
    isHideHeader: PropTypes.bool,
    onClose: PropTypes.func,
    headerTitle: PropTypes.string,
}