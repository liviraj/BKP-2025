import PropTypes from 'prop-types';

function Label({ label, required, setBold, addStyle, isDisable }) {
  return (
    <label className={`${required ? "required font-bold" : setBold ? "!font-bold" : "label-shadow font-normal"} block ${isDisable ? " opacity-50" : ""} text-14px font-fontfamily md:text-left ${addStyle || ""}`}>{label}</label>
  )
}

export default Label

Label.propTypes = {
  label: PropTypes.string,
  required: PropTypes.bool,
  setBold: PropTypes.bool,
  addStyle: PropTypes.string,
  isDisable: PropTypes.bool
}