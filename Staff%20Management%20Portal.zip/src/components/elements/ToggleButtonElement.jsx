import PropTypes from 'prop-types';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';

function ToggleButtonElement({ value, onChange, options }) {
    return (
        <ToggleButtonGroup
            color="primary"
            value={value}
            exclusive
            onChange={onChange}
            aria-label="Platform"
            className=' bg-[#EDF2F7] text-calendarTextColor text-15px font-[inherit] font-semibold calendarbtn-shadow customTogglebtn'
        >
            {options && options.length > 0 && options.map((val, idx) => <ToggleButton className=' !border-none hover:bg-[#E2E8F0] !py-0 h-[35px] !leading-normal' key={idx} value={val.id}>{val.label}</ToggleButton>)}
        </ToggleButtonGroup>
    )
}

export default ToggleButtonElement

ToggleButtonElement.propTypes = {
    value: PropTypes.string,
    onChange: PropTypes.func,
    options: PropTypes.array
}