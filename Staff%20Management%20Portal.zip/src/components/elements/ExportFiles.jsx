import PropTypes from 'prop-types';
import { TiDownload } from "react-icons/ti";
import ExcelJS from 'exceljs';
import moment from 'moment-timezone';
// for future predict PDF + Excel download option
//import { Button, Menu, MenuItem } from '@mui/material';
// import jsPDF from 'jspdf';
// import autoTable from 'jspdf-autotable';

function ExportFiles({ columns, data, docName, fileName, isuploadAuditor }) {
    // Add params for both exports PDF and Excel [isPortraitView, isPageBreak]
    // const [anchorEl, setAnchorEl] = React.useState(null);
    // const open = Boolean(anchorEl);
    // const handleClick = (event) => {
    //     setAnchorEl(event.currentTarget);
    // };

    // const handleClose = (type) => {
    //     if (type && columns && data && docName) {
    //         const headerNames = columns.map(columnDef => columnDef.headerName);
    //         const columnData = data.map(rowData => columns.map(columnDef => rowData[columnDef.field]));
    //         if (type === "pdf") {
    //             const doc = new jsPDF({ orientation: isPortraitView ? "portrait" : "landscape" })
    //             autoTable(doc, { html: '#my-table' })
    //             autoTable(doc, {
    //                 head: [headerNames],
    //                 body: columnData,
    //                 theme: "grid",
    //                 styles: { fontSize: 9 },
    //                 startY: 35,
    //                 useCss: true,
    //                 pageBreak: "auto",
    //                 rowPageBreak: "avoid",
    //                 horizontalPageBreak: isPageBreak ? true : false,
    //                 horizontalPageBreakRepeat: 0,
    //                 headStyles: { fontStyle: "bold", fillColor: "#fff", textColor: "black", lineWidth: .5, cellWidth: isPageBreak ? "wrap" : "auto" },
    //                 margin: 5,
    //                 tableWidth: isPageBreak ? "wrap" : "auto",

    //             });
    //             doc.save(`${docName}.pdf`);
    //         }
    //         else {
    //             exportToExcel();
    //         }
    //     }
    //     setAnchorEl(null);
    // };

    const exportToExcel = async () => {
        const filterColumns = columns.filter(val => val.headerName !== "Actions");
        const customdata = data.map(rowData => filterColumns.map(columnDef => rowData[columnDef.field]));
        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet(docName);
        // for reference
        // await worksheet.mergeCellsWithoutStyle('A1:k1');
        // const titleRow = worksheet.addRow([`Histogenetics - ${docName}`]);
        // titleRow.font = { bold: true, size: 16, color: { argb: "ef4641" } };
        // worksheet.addRow([]);
        worksheet.addRow(filterColumns.map(val => val.headerName));
        worksheet.addRows(customdata);
        worksheet.columns = filterColumns.map((val) => ({ header: val.headerName, key: val.field, width: val.excelWidth ? val.excelWidth : 12 }));
        const headerRow = worksheet.getRow(1);
        headerRow.font = { bold: true };
        const buffer = await workbook.xlsx.writeBuffer();
        const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${fileName || docName}.xlsx`;
        link.click();
    }

    const auditorDocumentExportToExcel = async () => {
        const customdata = data.map(rowData => columns.map(columnDef => rowData[columnDef.field]));
        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet(docName);
        worksheet.addRow(columns.map(val => val.headerName));
        worksheet.columns = columns.map((val) => ({ header: val.headerName, key: val.field, width: val.excelWidth ? val.excelWidth : 12 }));
        worksheet.mergeCells('E1:G1');
        worksheet.getCell('E1').value = 'Auditor Document Leave Balance';
        worksheet.getCell('E2').value = 'SL';
        worksheet.getCell('F2').value = 'PL';
        worksheet.getCell('G2').value = 'CL';
        worksheet.mergeCells('H1:J1');
        worksheet.getCell('H1').value = 'System Document Leave Balance';
        worksheet.getCell('H2').value = 'SL';
        worksheet.getCell('I2').value = 'PL';
        worksheet.getCell('J2').value = 'CL';
        worksheet.addRows(customdata);
        const headerRow = worksheet.getRow(1);
        headerRow.font = { bold: true };
        const subHeaderRow = worksheet.getRow(2);
        subHeaderRow.font = { bold: true };
        const buffer = await workbook.xlsx.writeBuffer();
        const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${fileName || docName}.xlsx`;
        link.click();
    }

    return (
        <div>
            <span className=' mx-8 cursor-pointer' onClick={isuploadAuditor ? auditorDocumentExportToExcel : exportToExcel}><TiDownload color='#ef4641' size={22} /></span>
            {/* <Button
                id="demo-positioned-button"
                aria-controls={open ? 'demo-positioned-menu' : undefined}
                aria-haspopup="true"
                aria-expanded={open ? 'true' : undefined}
                onClick={handleClick}
            >
                <TiDownload color='#ef4641' size={22} />
            </Button>
            <Menu
                id="demo-positioned-menu"
                aria-labelledby="demo-positioned-button"
                anchorEl={anchorEl}
                open={open}
                onClose={() => handleClose(null)}
                anchorOrigin={{
                    vertical: 'top',
                    horizontal: 'left',
                }}
                transformOrigin={{
                    vertical: 'top',
                    horizontal: 'left',
                }}
            >
                <MenuItem onClick={() => handleClose("pdf")}>PDF</MenuItem>
                <MenuItem onClick={() => handleClose("excel")}>Excel</MenuItem>
            </Menu> */}
        </div>
    )
}

export default ExportFiles

ExportFiles.propTypes = {
    columns: PropTypes.array,
    data: PropTypes.array,
    docName: PropTypes.string,
    fileName: PropTypes.string,
    isuploadAuditor: PropTypes.bool
    // isPortraitView: PropTypes.bool,
    // isPageBreak: PropTypes.bool
}

// eslint-disable-next-line react-refresh/only-export-components
export const hoursWorkedReport = async (excelData, date) => {

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("TotalHoursWorkedReportByPeriod", { views: [{ showGridLines: false, state: "frozen", ySplit: 4 }] });

    const HistoLogo = await workbook.addImage({
        base64: `iVBORw0KGgoAAAANSUhEUgAAAKAAAAA2CAMAAAB3LmJBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAA5UExURf////8zM//l5f+Zmf/MzP+ysv/y8v+/v/+lpf8/P//Z2f9/f/9lZf9ZWf9ycv+MjP80M/9MTAAAAIB/z/IAAAATdFJOU////////////////////////wCyfdwIAAAACXBIWXMAAA7DAAAOwwHHb6hkAAACLklEQVRoQ+2U25KsIAxFTUFxK9D//9vZuYg62va8UecU60EiibgkTS+TyWQymUwm/zP0CcsPx3TuWH44pnPH8sPpKmetIxqPaD1h+eF0lbPWEY1HtJ6w/HC6ylnriMYjWk8gF5xfFu8QcYBblzgWgtxH3HPJngeIZJovOlN0wDpJ6iOHIMkq31AVDS4xBk9YyXHEgbcCGcgvhYcVycgBXq0FqCTCi6ntM14HPForyhvHYQkyVzDxjpQ9gdxVsNJaEm8hIrnmVCq/gZp3XC/lDLEcQcbjOxRRk2uiisdWjK3ETZKvHDqGTdwFV94lQQXVIGlV4R9DF8wo/SQo6/kCQd797xw6hk2oYK4174LoZF6lJSaIz2cnlqy1FS1nEdoaBW1xq1V26ZcgCJly2z/5hUPHsAkVrM6JjeyNx3v514VfES4nwYh2Y6+knAvJeVp1B1c9WA+CS8HSvSmfMZ07yF1bzGzSs2uLi1axoFVh3Ohzi3FA0GIm7k+8oCoaXGIMV8Hakl9PgittKcshoYTuyn557/kAOz6j6o8ZLj4EcUhSw+67vOFs/UnwGeR+CfKsvkcES8Y9vyAiyP1vBo3nWfR7n2HD1gV5c6kFGSh//yNEVQ8uMYbA2xF4fQ6WEOX/WI8sE5N2KqQoeeyW7KA0kC99ZilSaVdbxtv4jmg9YfnhdJWz1hGNR7SesPxwuspZ64jGI1pPWH44pnPH8sMxnTuWn0wmk8lkMpn80yzLD11PDeWP0xSJAAAAAElFTkSuQmCC`,
        extension: "png"
    });

    await worksheet.addImage(HistoLogo, {
        tl: { col: 0.5, row: 0.5 }, // top left
        br: { col: 3, row: 3 } // bottom right
    });

    worksheet.mergeCells("E2", "O3");
    worksheet.getCell("E2").value = "Employee Monthly Attendance Report - Hours Worked";
    worksheet.getCell("E2").style = ExcelFontStyle({ color: "FF0000", alignment: centerAlignment, isHideBorder: true, fontFamily: 'Arial' });
    worksheet.mergeCells("Q2", "W3");
    worksheet.getCell("Q2").value = `Date: ${moment(date).format("MM/DD/YYYY")}`
    worksheet.getCell("Q2").style = ExcelFontStyle({ alignment: centerAlignment, isHideBorder: true, fontFamily: 'Arial' });
    // eslint-disable-next-line no-unused-vars
    const filterData = excelData.map(val => { const { EmployeeID, ...rest } = val; return rest });
    const excelHeaders = Object.keys(filterData[0]);
    let headers = excelHeaders.filter(val => val !== "EmployeeName").map(val => {
        const splitDate = val.split("_");
        const date = moment(splitDate[0]);
        return {
            month: moment(date).format("MMMM"),
            date: date.get("date"),
            day: splitDate[1],
            sortDate: new Date(date),
            header: val
        }
    });

    headers = headers.sort((a, b) => Date.parse(new Date(a.sortDate)) - Date.parse(new Date(b.sortDate)));
    let months = headers.reduce((result, val) => {
        if (typeof (result) === "number") {
            return [{ month: val.month, mergeCells: 1 }];
        }
        const isValidIdx = result.findIndex(val2 => val2.month === val.month);
        if (isValidIdx < 0) {
            result = [...result, { month: val.month, mergeCells: 1 }]
        }
        else {
            result[isValidIdx].mergeCells = result[isValidIdx].mergeCells + 1;
        }
        return result;
    }, 0);

    worksheet.mergeCells("A6", "D8");
    let dynamicHeader = ["Employee Name", "", "", ""];
    for (const val of months) {
        dynamicHeader = [...dynamicHeader, val.month];
        for (let i = 1; i < val.mergeCells; i++) {
            dynamicHeader = [...dynamicHeader, ""];
        }
    }
    worksheet.getRow(6).values = dynamicHeader;
    worksheet.getCell("A6").style = ExcelFontStyle({ alignment: centerAlignment, isHideBorder: false });
    worksheet.getCell("B6").border = borderStyle;
    worksheet.getCell("C6").border = borderStyle;
    worksheet.getCell("D6").border = borderStyle;

    let startCell = 5;
    let endCell = 4;
    for (const val of months) {
        endCell += val.mergeCells;
        worksheet.getRow(6).getCell(startCell).style = ExcelFontStyle({ bgColor: '6e9eca', color: "ffffff", size: 8, alignment: centerAlignment });
        worksheet.mergeCells(6, startCell, 6, endCell);
        startCell += val.mergeCells;
    }


    let initialCol = 5;
    for (let val of headers) {
        worksheet.getRow(7).getCell(initialCol).value = val.date;
        worksheet.getRow(7).getCell(initialCol).style = ExcelFontStyle({ bgColor: '6e9eca', color: "ffffff", size: 8, alignment: rightAlignment });
        worksheet.getRow(8).getCell(initialCol).value = val.day;
        worksheet.getRow(8).getCell(initialCol).style = ExcelFontStyle({ bgColor: '6e9eca', color: "ffffff", size: 8 });
        initialCol += 1;
    }

    worksheet.columns = [...employeeNameHeaderWidth, ...headers.map(val => ({ "key": val.header, "width": 5 }))];
    const sortedHeaders = ["EmployeeName", ...headers.map(val => val.header)];
    let i = 9;
    for (let rowData of filterData) {
        let j = 4;
        for (let header of sortedHeaders) {
            let value = rowData[header];
            value = value || "";
            if (j === 4) {
                worksheet.getCell(`A${i}`).border = borderStyle;
                worksheet.mergeCells(`A${i}`, `D${i}`);
                worksheet.getRow(i).getCell(j).value = value;
                worksheet.getCell(`A${i}`).style = ExcelFontStyle({ bgColor: '60759b', color: "ffffff" });
            }
            else {
                value = value && !isNaN(value) ? Number(value) : value;
                worksheet.getRow(i).getCell(j).value = value;
                worksheet.getRow(i).getCell(j).style = (!value && value !== 0) || typeof (value) === "string" ?
                    ExcelFontStyle({ size: 8, isfontBold: false }) : ExcelFontStyle({ bgColor: value < 8 ? '808080' : 'ffffff', size: 8, alignment: rightAlignment, isfontBold: false });
            }
            j += 1;
        }
        i += 1;
    }

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `TotalHoursWorkedReportByPeriod(${moment().format("DD-MM-YYYY hh_mm_ss")}).xlsx`;
    link.click();

}

// eslint-disable-next-line react-refresh/only-export-components
export const employeeAttendanceReport = async (excelData, date, fromDate, toDate) => {

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("GetEmployeeAttendanceReportbyPeriod", { views: [{ showGridLines: false, state: "frozen", ySplit: 4 }] });

    const HistoLogo = await workbook.addImage({
        base64: `iVBORw0KGgoAAAANSUhEUgAAAKAAAAA2CAMAAAB3LmJBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAA5UExURf////8zM//l5f+Zmf/MzP+ysv/y8v+/v/+lpf8/P//Z2f9/f/9lZf9ZWf9ycv+MjP80M/9MTAAAAIB/z/IAAAATdFJOU////////////////////////wCyfdwIAAAACXBIWXMAAA7DAAAOwwHHb6hkAAACLklEQVRoQ+2U25KsIAxFTUFxK9D//9vZuYg62va8UecU60EiibgkTS+TyWQymUwm/zP0CcsPx3TuWH44pnPH8sPpKmetIxqPaD1h+eF0lbPWEY1HtJ6w/HC6ylnriMYjWk8gF5xfFu8QcYBblzgWgtxH3HPJngeIZJovOlN0wDpJ6iOHIMkq31AVDS4xBk9YyXHEgbcCGcgvhYcVycgBXq0FqCTCi6ntM14HPForyhvHYQkyVzDxjpQ9gdxVsNJaEm8hIrnmVCq/gZp3XC/lDLEcQcbjOxRRk2uiisdWjK3ETZKvHDqGTdwFV94lQQXVIGlV4R9DF8wo/SQo6/kCQd797xw6hk2oYK4174LoZF6lJSaIz2cnlqy1FS1nEdoaBW1xq1V26ZcgCJly2z/5hUPHsAkVrM6JjeyNx3v514VfES4nwYh2Y6+knAvJeVp1B1c9WA+CS8HSvSmfMZ07yF1bzGzSs2uLi1axoFVh3Ohzi3FA0GIm7k+8oCoaXGIMV8Hakl9PgittKcshoYTuyn557/kAOz6j6o8ZLj4EcUhSw+67vOFs/UnwGeR+CfKsvkcES8Y9vyAiyP1vBo3nWfR7n2HD1gV5c6kFGSh//yNEVQ8uMYbA2xF4fQ6WEOX/WI8sE5N2KqQoeeyW7KA0kC99ZilSaVdbxtv4jmg9YfnhdJWz1hGNR7SesPxwuspZ64jGI1pPWH44pnPH8sMxnTuWn0wmk8lkMpn80yzLD11PDeWP0xSJAAAAAElFTkSuQmCC`,
        extension: "png"
    });

    await worksheet.addImage(HistoLogo, {
        tl: { col: 0.5, row: 0.5 }, // top left
        br: { col: 3, row: 3 } // bottom right
    });

    worksheet.mergeCells("E2", "P3");
    worksheet.getCell("E2").value = `Employee Attendance Report of INDIA between ${moment(fromDate).format("MM/DD/YYYY")} - ${moment(toDate).format("MM/DD/YYYY")}`;
    worksheet.getCell("E2").style = ExcelFontStyle({ color: "FF0000", alignment: centerAlignment, isHideBorder: true, fontFamily: 'Arial' });
    worksheet.mergeCells("Q2", "W3");
    worksheet.getCell("Q2").value = `Date: ${moment(date).format("MM/DD/YYYY")}`
    worksheet.getCell("Q2").style = ExcelFontStyle({ alignment: centerAlignment, isHideBorder: true, fontFamily: 'Arial' });
    // eslint-disable-next-line no-unused-vars
    const filterData = excelData.map(val => { const { EmployeeID, ...rest } = val; return rest });
    const excelHeaders = Object.keys(filterData[0]);
    let headers = excelHeaders.filter(val => val !== "EmployeeName" && val !== "EmployeeCode").map(val => {
        const splitDate = val.split("_");
        const date = moment(splitDate[0]);
        return {
            month: moment(date).format("MMMM"),
            date: date.get("date"),
            day: splitDate[1],
            sortDate: new Date(date),
            header: val
        }
    });

    headers = headers.sort((a, b) => Date.parse(new Date(a.sortDate)) - Date.parse(new Date(b.sortDate)));
    let months = headers.reduce((result, val) => {
        if (typeof (result) === "number") {
            return [{ month: val.month, mergeCells: 1 }];
        }
        const isValidIdx = result.findIndex(val2 => val2.month === val.month);
        if (isValidIdx < 0) {
            result = [...result, { month: val.month, mergeCells: 1 }]
        }
        else {
            result[isValidIdx].mergeCells = result[isValidIdx].mergeCells + 1;
        }
        return result;
    }, 0);

    worksheet.mergeCells("A6", "B8");
    worksheet.mergeCells("C6", "F8");

    let dynamicHeader = ["Employee Code", "", "Employee Name", "", "", ""];
    for (const val of months) {
        dynamicHeader = [...dynamicHeader, val.month];
        for (let i = 1; i < val.mergeCells; i++) {
            dynamicHeader = [...dynamicHeader, ""];
        }
    }
    worksheet.getRow(6).values = dynamicHeader;
    worksheet.getCell("A6").style = ExcelFontStyle({ bgColor: '6e9eca', color: "ffffff", alignment: centerAlignment });
    worksheet.getCell("B6").border = borderStyle;
    worksheet.getCell("C6").style = ExcelFontStyle({ bgColor: '6e9eca', color: "ffffff", alignment: centerAlignment });
    worksheet.getCell("D6").border = borderStyle;
    worksheet.getCell("E6").border = borderStyle;
    worksheet.getCell("F6").border = borderStyle;
    worksheet.getCell("C7").border = borderStyle;
    worksheet.getCell("C8").border = borderStyle;

    let startCell = 7;
    let endCell = 6;
    for (const val of months) {
        endCell += val.mergeCells;
        worksheet.getRow(6).getCell(startCell).style = ExcelFontStyle({ bgColor: '6e9eca', color: "ffffff", alignment: centerAlignment });
        worksheet.mergeCells(6, startCell, 6, endCell);
        startCell += val.mergeCells;
    }


    let initialCol = 7;
    for (let val of headers) {
        worksheet.getRow(7).getCell(initialCol).value = val.date;
        worksheet.getRow(7).getCell(initialCol).style = ExcelFontStyle({ bgColor: '6e9eca', color: "ffffff", alignment: centerAlignment });
        worksheet.getRow(8).getCell(initialCol).value = val.day;
        worksheet.getRow(8).getCell(initialCol).style = ExcelFontStyle({ bgColor: '6e9eca', color: "ffffff", alignment: centerAlignment });
        initialCol += 1;
    }

    worksheet.columns = [...employeeNameHeaderWidth, { width: 9 }, { width: 9 }, ...headers.map(val => ({ "key": val.header, "width": 5 }))];
    const sortedHeaders = ["EmployeeCode", "EmployeeName", ...headers.map(val => val.header)];
    let i = 9;
    for (let rowData of filterData) {
        let j = 2;
        for (let header of sortedHeaders) {
            let value = rowData[header];
            value = value || "";
            if (j === 2) {
                worksheet.getCell(`A${i}`).border = borderStyle;
                worksheet.mergeCells(`A${i}`, `B${i}`);
                worksheet.getRow(i).getCell(j).value = value;
                worksheet.getCell(`A${i}`).style = ExcelFontStyle({ isfontBold: false });
                j += 3;
            }
            else if (j === 6) {
                worksheet.getCell(`C${i}`).border = borderStyle;
                worksheet.mergeCells(`C${i}`, `F${i}`);
                worksheet.getRow(i).getCell(j).value = value;
                worksheet.getCell(`C${i}`).style = ExcelFontStyle({ isfontBold: false });
            }
            else {
                value = value && !isNaN(value) ? Number(value) : (value ? value.trim() : value);
                const fontColor = getColorCode(value);
                worksheet.getRow(i).getCell(j).value = value;
                worksheet.getRow(i).getCell(j).style = ExcelFontStyle({ isfontBold: fontColor !== "000000", fontFamily: 'Arial', color: fontColor });
            }
            j += 1;
        }
        i += 1;
    }

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `GetEmployeeAttendanceReportbyPeriod(${moment().format("DD-MM-YYYY hh_mm_ss")}).xlsx`;
    link.click();

}

const getColorCode = (value) => {
    switch (value) {
        case 'H':
            return "00B050";
        case 'L':
            return "FF0000";
        case 0.5:
            return "E2AC00";
        default:
            return "000000"
    }
}

// eslint-disable-next-line react-refresh/only-export-components
export const leaveAvailedDetailReport = async (excelData, date, fromDate, toDate, attendanceDate, ledgerRunDate) => {

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("LeavesAvailedDetailedReport", { views: [{ showGridLines: false, state: "frozen", ySplit: 4 }] });

    const HistoLogo = await workbook.addImage({
        base64: `iVBORw0KGgoAAAANSUhEUgAAAKAAAAA2CAMAAAB3LmJBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAA5UExURf////8zM//l5f+Zmf/MzP+ysv/y8v+/v/+lpf8/P//Z2f9/f/9lZf9ZWf9ycv+MjP80M/9MTAAAAIB/z/IAAAATdFJOU////////////////////////wCyfdwIAAAACXBIWXMAAA7DAAAOwwHHb6hkAAACLklEQVRoQ+2U25KsIAxFTUFxK9D//9vZuYg62va8UecU60EiibgkTS+TyWQymUwm/zP0CcsPx3TuWH44pnPH8sPpKmetIxqPaD1h+eF0lbPWEY1HtJ6w/HC6ylnriMYjWk8gF5xfFu8QcYBblzgWgtxH3HPJngeIZJovOlN0wDpJ6iOHIMkq31AVDS4xBk9YyXHEgbcCGcgvhYcVycgBXq0FqCTCi6ntM14HPForyhvHYQkyVzDxjpQ9gdxVsNJaEm8hIrnmVCq/gZp3XC/lDLEcQcbjOxRRk2uiisdWjK3ETZKvHDqGTdwFV94lQQXVIGlV4R9DF8wo/SQo6/kCQd797xw6hk2oYK4174LoZF6lJSaIz2cnlqy1FS1nEdoaBW1xq1V26ZcgCJly2z/5hUPHsAkVrM6JjeyNx3v514VfES4nwYh2Y6+knAvJeVp1B1c9WA+CS8HSvSmfMZ07yF1bzGzSs2uLi1axoFVh3Ohzi3FA0GIm7k+8oCoaXGIMV8Hakl9PgittKcshoYTuyn557/kAOz6j6o8ZLj4EcUhSw+67vOFs/UnwGeR+CfKsvkcES8Y9vyAiyP1vBo3nWfR7n2HD1gV5c6kFGSh//yNEVQ8uMYbA2xF4fQ6WEOX/WI8sE5N2KqQoeeyW7KA0kC99ZilSaVdbxtv4jmg9YfnhdJWz1hGNR7SesPxwuspZ64jGI1pPWH44pnPH8sMxnTuWn0wmk8lkMpn80yzLD11PDeWP0xSJAAAAAElFTkSuQmCC`,
        extension: "png"
    });

    await worksheet.addImage(HistoLogo, {
        tl: { col: 0.1, row: 0.5 }, // top left
        br: { col: 2.99, row: 3.2 } // bottom right
    });

    worksheet.mergeCells("D2", "H3");
    worksheet.getCell("D2").value = `Leaves Availed Detailed Report  from ${moment(fromDate).format("MM/DD/YYYY")} to ${moment(toDate).format("MM/DD/YYYY")}`;
    worksheet.getCell("D2").style = ExcelFontStyle({ color: "FF0000", alignment: centerAlignment, isHideBorder: true, fontFamily: 'Arial' });
    worksheet.mergeCells("I2", "L3");
    worksheet.getCell("I2").value = `Date: ${moment(date).format("MM/DD/YYYY")}`
    worksheet.getCell("I2").style = ExcelFontStyle({ alignment: centerAlignment, isHideBorder: true, fontFamily: 'Arial' });

    worksheet.mergeCells("B5", "E5");
    worksheet.getCell("B5").value = `Last Attendance Reviewed Date: ${attendanceDate}`;
    worksheet.getCell("B5").style = ExcelFontStyle({ fontFamily: 'Arial', isHideBorder: true });

    worksheet.mergeCells("G5", "K5");
    worksheet.getCell("G5").value = `Last Ledger Run Date: ${ledgerRunDate}`
    worksheet.getCell("G5").style = ExcelFontStyle({ fontFamily: 'Arial', isHideBorder: true });

    leaveAvailedDetailReportHeader.forEach((val, idx) => {
        worksheet.getRow(7).getCell(idx + 1).value = val.label;
        worksheet.getRow(7).getCell(idx + 1).style = ExcelFontStyle({ bgColor: idx !== 0 ? '6e9eca' : 'ffffff', color: "ffffff", isHideBorder: idx === 0 });
        worksheet.getColumn(idx + 1).width = val.excelWidth;
    });

    const customdata = excelData.map(rowData => leaveAvailedDetailReportHeader.map(columnDef => rowData[columnDef.value]));

    customdata.forEach((col, idx) => {
        col.forEach((val, cellIdx) => {
            worksheet.getRow(8 + idx).getCell(cellIdx + 1).value = val;
            worksheet.getRow(8 + idx).getCell(cellIdx + 1).style = ExcelFontStyle({ isfontBold: false, isHideBorder: cellIdx === 0 });
        });
    });

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `LeavesAvailedDetailedReport(${moment().format("DD-MM-YYYY hh_mm_ss")}).xlsx`;
    link.click();
}

const employeeNameHeaderWidth = [{ width: 9 }, { width: 9 }, { width: 9 }, { width: 9 }];
const centerAlignment = {
    vertical: "middle", horizontal: "center"
}
const rightAlignment = {
    vertical: "top", horizontal: "right"
}

const borderStyle = {
    top: { style: "thin", color: { argb: 'd3d3d3' } },
    left: { style: 'thin', color: { argb: 'd3d3d3' } },
    bottom: { style: 'thin', color: { argb: 'd3d3d3' } },
    right: { style: 'thin', color: { argb: 'd3d3d3' } }
}

const ExcelFontStyle = ({ bgColor = "ffffff", color = "000000", alignment, size = 10, isHideBorder, isfontBold = true, fontFamily = 'Tahoma' }) => ({
    font: {
        name: fontFamily,
        color: { argb: color },
        family: 2,
        size: size,
        bold: isfontBold,
        italic: false
    },
    fill: {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: bgColor }
    },
    alignment: alignment || {
        vertical: "top", horizontal: "left"
    },
    border: isHideBorder ? {} : borderStyle

});

const leaveAvailedDetailReportHeader = [
    { label: "", value: "", excelWidth: 5 },
    { label: "Location", value: "Location", excelWidth: 10 },
    { label: "Employee Name", value: "EmployeeName", excelWidth: 28 },
    { label: "Leave Date", value: "LeaveDate", excelWidth: 15 },
    { label: "Full/Half Day", value: "ForH", excelWidth: 15 },
    { label: "Leave Type", value: "LeaveType", excelWidth: 17 },
    { label: "Approval Status", value: "Status", excelWidth: 18 },
    { label: "TotalHrsWorked", value: "TotalHrsWorked", excelWidth: 20 }
];

// for Reference
// const hoursWorkedReport_sample_data = [
//     {
//         "EmployeeID": 755,
//         "EmployeeName": "Krishnan Shivakumar",
//         "EmployeeCode": "HISTIND0025",
//         "04/07/2024_Su": "H",
//         "04/08/2024_Mo": 9.48,
//         "04/09/2024_Tu": 8.18,
//         "04/10/2024_We": 6.24,
//         "04/11/2024_Th": "L",
//         "04/12/2024_Fr": "L",
//         "04/13/2024_Sa": "H",
//         "04/14/2024_Su": "H",
//         "04/01/2024_Mo": 7,
//         "04/02/2024_Tu": 8.25,
//         "04/03/2024_We": 8.23,
//         "04/04/2024_Th": 8.26,
//         "04/05/2024_Fr": 8.6,
//         "04/06/2024_Sa": "H",
//     }]
// const employeeAttendanceReport_sample_data = [
//     {
//         "EmployeeID": 755,
//         "EmployeeName": "Krishnan Shivakumar",
//         "04/07/2024_Su": "H",
//         "04/08/2024_Mo": 9.48,
//         "04/09/2024_Tu": 8.18,
//         "04/10/2024_We": 6.24,
//         "04/11/2024_Th": "L",
//         "04/12/2024_Fr": "L",
//         "04/13/2024_Sa": "H",
//         "04/14/2024_Su": "H",
//         "04/01/2024_Mo": 7,
//         "04/02/2024_Tu": 8.25,
//         "04/03/2024_We": 8.23,
//         "04/04/2024_Th": 8.26,
//         "04/05/2024_Fr": 8.6,
//         "04/06/2024_Sa": "H",
//     }]
// const leaveAvailedDetailReport_sample_data = [
//     {
//         "Status": "Approved",
//         "empId": "903",
//         "TotalHrsWorked": null,
//         "Remarks": "test",
//         "LeaveType": "Vacation",
//         "LeaveDate": "02 May 2024",
//         "EmployeeName": "Krishnan Shivakumar",
//         "ForH": "Half Day",
//         "Location": "INDIA"
//     }];
