import { RiCheckboxBlankFill } from "react-icons/ri";
import PropTypes from "prop-types";

function ColorLegend({ legendList }) {
  return (
    <div className=" flex flex-wrap gap-4">
      {legendList.map((val) =>
        <div key={val.color} className=" flex justify-center items-center gap-1 font-fontfamily">
          <RiCheckboxBlankFill size={20} color={val.color} />
          <span className=" text-14px">{val.name}</span>
        </div>)}
    </div>
  )
}

export default ColorLegend

ColorLegend.propTypes = {
  legendList: PropTypes.arrayOf(
    PropTypes.shape({
      color: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired
    })
  )
}
