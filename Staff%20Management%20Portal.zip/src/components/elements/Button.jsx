import PropTypes from 'prop-types';

function Button({ value, onClick, disabled, isRemovePaddingStyle, addStyle }) {
  return (
    <div className={`h-full flex items-center ${isRemovePaddingStyle ? "" : "py-2"} `} ><button disabled={disabled} className={`${disabled ? ' opacity-70 !cursor-not-allowed' : ""} bg-headerColor  ${addStyle || ""}  font-fontfamily cursor-pointer text-white px-5 py-1 rounded-sm`} onClick={onClick}>{value}</button></div>
  )
}

export default Button

Button.propTypes = {
  value: PropTypes.string,
  onClick: PropTypes.func,
  disabled: PropTypes.bool,
  addStyle: PropTypes.string,
  isRemovePaddingStyle: PropTypes.bool
}