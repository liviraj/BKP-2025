import PropTypes from 'prop-types';
import { ReactMultiEmail, isEmail } from 'react-multi-email';
import 'react-multi-email/dist/style.css';
import { RiCloseFill } from 'react-icons/ri';

function Mail({ value, onChange, isViewable }) {

    const getCustomLabel = (email, index, removeEmail) => {
        return <div className=' !m-0 !bg-transparent !px-1 !py-0 !text-gray-700 flex items-center h-full' data-tag key={index}>  {email} {isViewable || <span data-tag-handle onClick={() => removeEmail(index)}> <RiCloseFill className='logoutPointer' size={18} /> </span>}  </div>
    }

    return (
        <div className='h-full flex items-center py-2'>
            <ReactMultiEmail
                className='CustomMultiEmail max-w-full p-1 overflow-hidden max-h-full h-full min-h-9 text-gray-700 leading-tight focus:outline-none focus:!bg-white  bg-gray-200 appearance-none border-2 border-gray-200 rounded'
                emails={value}
                onChange={_emails => onChange(_emails)}
                validateEmail={email => isEmail(email)}
                getLabel={getCustomLabel}
            />
        </div>
    )
}

export default Mail

Mail.propTypes = {
    value: PropTypes.any,
    onChange: PropTypes.func,
    isViewable: PropTypes.bool
}