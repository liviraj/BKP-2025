import PropTypes from 'prop-types';
import Dropdown from '../elements/Dropdown';
import DatePickerElement from '../elements/DatePickerElement';
import { reportFields, setDefaultValue, strings } from '../Constants';
import { useDispatch, useSelector } from 'react-redux';
import { reportRequest } from '../requests';
import Button from '../elements/Button';
import { FiExternalLink } from 'react-icons/fi';
import moment from 'moment-timezone'
import { complianceReportActions } from '../../redux/complianceReportReducer';
import { complianceReport } from '../Grid/Columns';
import ExportFiles from '../elements/ExportFiles';
import { Tooltip } from '@mui/material';
import { useEffect, useState } from 'react';
import { userReducerState } from '../helper';

const ComplianceFilter = ({ isModalView, fileProps }) => {
    const employeeState = useSelector(state => state.employee);
    const complianceReportState = useSelector(state => state.complianceReport);
    const userState = useSelector(state => state.user);
    const dispatch = useDispatch();
    const [employeeOptions, setEmployeeOptions] = useState([]);
    const GridClassName = `grid lg:grid-rows-1 md:grid-rows-1  gap-x-6 gap-y-1 w-full ${(userState.Role === strings.userRoles.admin || userState.Role === strings.userRoles.humanResource || userState.Role === strings.userRoles.superVisor) ? ' grid-cols-5 xl:grid-cols-6 lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-3 xsm:grid-cols-1 sm:grid-rows-2' : 'grid-cols-5 sm:grid-cols-3 xsm:grid-cols-1 sm:grid-rows-1'}`

    const handleSubmit = async () => {
        await dispatch(reportRequest.setComplianceLoader(true));
        const { complianceFilterValues } = complianceReportState;
        let filterRecords = {};
        if (complianceFilterValues.employeeName) {
            filterRecords = { ...filterRecords, employeeId: (userState.Role === strings.userRoles.admin || userState.Role === strings.userRoles.humanResource || userState.Role === strings.userRoles.superVisor) ? complianceFilterValues.employeeName.value : userState.UserID };
        }
        if (complianceFilterValues.employeeType) {
            filterRecords = { ...filterRecords, filter: userState.Role === strings.userRoles.superVisor ? setDefaultValue.complianceReportSupervisorType.label : complianceFilterValues.employeeType.label };
        }
        if (complianceFilterValues.dateOfJoin) {
            filterRecords = { ...filterRecords, doj: complianceFilterValues.dateOfJoin };
        }
        if (complianceFilterValues.designation) {
            filterRecords = { ...filterRecords, designationId: complianceFilterValues.designation.value };
        }
        if (complianceFilterValues.selectionYear) {
            filterRecords = { ...filterRecords, year: Number(moment(complianceFilterValues.selectionYear).format("YYYY")) };
        }
        filterRecords = { ...filterRecords, supervisorEmpId: userState.Role === strings.userRoles.superVisor ? userState.UserID : 0 }
        await dispatch(reportRequest.getComplianceReports(filterRecords));
        dispatch(reportRequest.setComplianceLoader(false));
    }

    const onReset = async () => {
        await dispatch(reportRequest.setComplianceLoader(true));
        await Promise.all([
            dispatch(reportRequest.getComplianceReports({ employeeId: (userState.Role === strings.userRoles.admin || userState.Role === strings.userRoles.humanResource || userState.Role === strings.userRoles.superVisor) ? setDefaultValue.employeeName.value : userState.UserID, filter: userState.Role === strings.userRoles.superVisor ? setDefaultValue.complianceReportSupervisorType.label : setDefaultValue.complianceReportEmployeeType.label, supervisorEmpId: userState.Role === strings.userRoles.superVisor ? userState.UserID : 0 })),
            dispatch(complianceReportActions.setComplianceFilterValues({ employeeType: userState.Role === strings.userRoles.superVisor ? setDefaultValue.complianceReportSupervisorType : setDefaultValue.complianceReportEmployeeType, employeeName: setDefaultValue.employeeName, selectionYear: "", dateOfJoin: "", designation: "" }))
        ]);
        dispatch(reportRequest.setComplianceLoader(false));
    }

    const handleNotify = () => {
        const tempData = complianceReportState.data;
        const filteredReportdetails = Object.entries(reportFields).filter(val => Object.keys(val[1]).length > 1 && val[1].label !== reportFields.oneTimeEmployeeTraining.label);

        let expiryDateColumns = [...complianceReport.complianceNotifyColumns];
        let expiryDateDatas = [];
        for (let tempRecord of tempData) {
            let data = { ...tempRecord };
            let isValid = false;
            for (const tempReport of filteredReportdetails) {
                const colorCode = tempReport[1].colorCode;
                const columnLabel = tempReport[1].label;
                const value = data[columnLabel];
                const isBlueCode = isNaN(new Date(value));

                const competencyAssessmentTestValidation = () => {

                    const getValidDate = (isExecute) => {
                        if (isExecute) {
                            const isValid = data[colorCode] && !Number(data[colorCode]); // 
                            return !!isValid;
                        }
                        data[columnLabel] = null;
                        return false;
                    }

                    if ((data[reportFields.everyYearCompetencyAssessmentTest.colorCode] && Number(data[reportFields.everyYearCompetencyAssessmentTest.colorCode]) && data[reportFields.everyYearCompetencyAssessmentTest.label] !== setDefaultValue.complianceReports.noExpiry) ||
                        (data[reportFields.sixthMonthCompetencyAssessmentTest.colorCode] && Number(data[reportFields.sixthMonthCompetencyAssessmentTest.colorCode]) && data[reportFields.sixthMonthCompetencyAssessmentTest.label] !== setDefaultValue.complianceReports.noExpiry) ||
                        (data[reportFields.thirdMonthCompetencyAssessmentTest.colorCode] && Number(data[reportFields.thirdMonthCompetencyAssessmentTest.colorCode]) && data[reportFields.thirdMonthCompetencyAssessmentTest.label] !== setDefaultValue.complianceReports.noExpiry)) {
                        return getValidDate(false);
                    }
                    else if (reportFields.everyYearCompetencyAssessmentTest.label === columnLabel) {
                        return getValidDate(true);
                    } else if (reportFields.sixthMonthCompetencyAssessmentTest.label === columnLabel) {
                        return getValidDate(!data[reportFields.everyYearCompetencyAssessmentTest.label]);
                    } else if (reportFields.thirdMonthCompetencyAssessmentTest.label === columnLabel) {
                        return getValidDate(!data[reportFields.sixthMonthCompetencyAssessmentTest.label] && !data[reportFields.everyYearCompetencyAssessmentTest.label]);
                    }
                    return false;
                }

                if (value && colorCode && colorCode.length > 0 && (reportFields.everyYearCompetencyAssessmentTest.label === columnLabel || reportFields.sixthMonthCompetencyAssessmentTest.label === columnLabel || reportFields.thirdMonthCompetencyAssessmentTest.label === columnLabel ? competencyAssessmentTestValidation() : (data[colorCode] && !Number(data[colorCode]) && !isBlueCode)) && (tempReport[0] === reportFields.yearNyStateClinicalLicense.label ? data[reportFields.every3yearNyStateClinicalLicense.label] : true)) {
                    isValid = true;
                    if (!expiryDateColumns.find(val => val?.field === columnLabel)) {
                        const index = complianceReport.complianceViewColumns().findIndex(val => val.field === columnLabel)
                        expiryDateColumns = [...expiryDateColumns, { ...complianceReport.complianceViewColumns(true)[index], excelWidth: index }];
                    }
                }
            }
            if (isValid) {
                expiryDateDatas = [...expiryDateDatas, data];
            }
        }
        dispatch(complianceReportActions.setComplianceNotify({ show: true, data: expiryDateDatas, columns: expiryDateColumns.toSorted((a, b) => a.excelWidth - b.excelWidth) }));
    }
    useEffect(() => {
        setEmployeeOptions(filterEmployeeName(employeeState.employeeName));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [employeeState.employeeName]);

    const filterEmployeeName = (employeeName) => {
        if (userReducerState().Role === strings.userRoles.superVisor && employeeName.length > 0) {
            return employeeName.filter(val => val.value === setDefaultValue.employeeName.value ||
                ((val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation) &&
                    (val.supervisorId === userReducerState().UserID || val.employeeId === userReducerState().UserID))
            );
        }
        else if ((userReducerState().Role === strings.userRoles.admin || userReducerState().Role === strings.userRoles.humanResource) && employeeName.length > 0) {
            return employeeName.filter((val) =>
                val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation || val.employmentStatus === "All")
        }
        return [];
    }

    return (
        <div className='flex mb-5'>
            <div className={GridClassName}>
                {(userState.Role === strings.userRoles.admin || userState.Role === strings.userRoles.humanResource || userState.Role === strings.userRoles.superVisor) ?
                    <> <div><Dropdown placeholder={strings.dropDowns.ReportCompliance.EmployeeName} value={complianceReportState.complianceFilterValues.employeeName} onChange={(data) => dispatch(complianceReportActions.setComplianceFilterValues({ employeeName: data }))} isLabelView={true}
                        options={employeeOptions}
                        isSearchable={true} /></div>
                        <div><Dropdown placeholder={strings.dropDowns.ReportCompliance.EmployeeType} value={complianceReportState.complianceFilterValues.employeeType} onChange={(data) => dispatch(complianceReportActions.setComplianceFilterValues({ employeeType: data }))} isLabelView={true} options={complianceReportState.employeeType} isDisable={userState.Role === strings.userRoles.superVisor} /></div>
                    </> : <></>}
                {/* <div><DatePickerElement value={watch(strings.complianceReport.dateOfJoin) ? watch(strings.complianceReport.dateOfJoin) : ""} onChange={date => setValue(strings.complianceReport.dateOfJoin, date)} maxDate={new Date()}  isRequired={true} isLabelView={true} placeholder={strings.dropDowns.ReportCompliance.DOJ} /></div>
                        <div><Dropdown placeholder={strings.dropDowns.ReportCompliance.Designation} value={watch(strings.complianceReport.designation) ? watch(strings.complianceReport.designation) : ""} onChange={data => setValue(strings.complianceReport.designation, data)} isLabelView={true} options={employeeState.designation} /></div> */}
                <div><DatePickerElement showYearDropdown={true} value={complianceReportState.complianceFilterValues.selectionYear ? complianceReportState.complianceFilterValues.selectionYear : ""} onChange={data => dispatch(complianceReportActions.setComplianceFilterValues({ selectionYear: data }))} maxDate={moment().add(10, "years")} isRequired={true} isLabelView={true} placeholder={strings.dropDowns.ReportCompliance.Year} isRemovable={true} /></div>
                <div className=' flex justify-center self-end'><Button value="Submit" onClick={handleSubmit} /><span className=' flex mx-2'><Button value="Reset" onClick={() => onReset()} /></span></div>
                <div className={`${(userState.Role === strings.userRoles.admin || userState.Role === strings.userRoles.humanResource || userState.Role === strings.userRoles.superVisor) ? 'col-span-2' : ''} col-span-1 flex items-end ${(isModalView || fileProps) ? "justify-between" : " justify-center"} `}>
                    <div className='flex justify-center self-end'>
                        {(userState.Role === strings.userRoles.admin || userState.Role === strings.userRoles.humanResource || userState.Role === strings.userRoles.superVisor) && <Button value={"Notify"} onClick={handleNotify} />}
                    </div>
                    {isModalView &&
                        <Tooltip title={"Compliance Report Full View"} placement="top">
                            <span className=' cursor-pointer pb-2' onClick={() => dispatch(reportRequest.setComplianceView({ show: true }))}><FiExternalLink size={22} /></span>
                        </Tooltip >
                    }
                    {fileProps && <div className=' leading-3 ' ><ExportFiles {...fileProps} /></div>}
                </div>
            </div>
        </div>
    );
};

export default ComplianceFilter;

ComplianceFilter.propTypes = {
    isModalView: PropTypes.bool,
    fileProps: PropTypes.object,
}