import { useDispatch, useSelector } from "react-redux";
import ModelBox from "../elements/ModelBox";
import AgGrid from "../Grid/AgGrid";
import ImageViewer from "./ImageViewer";
import { loginResponseActions } from "../../redux/loginResponseReducer";
import { multiImageViewer } from "../Grid/Columns";
import { useEffect } from "react";
import { userRequest } from "../requests";



function MultiImageViewer() {

    const multiDocumentViewerState = useSelector(state => state.loginResponse.multiDocumentViewer);
    const loginResponseState = useSelector(state => state.loginResponse);

    const dispatch = useDispatch();

    useEffect(() => {
        if (multiDocumentViewerState.docs.length <= 1) {
            dispatch(userRequest.imageViewer({ show: true, data: multiDocumentViewerState.docs.length <= 0 ? "" : multiDocumentViewerState.docs[0].binary, imageName: multiDocumentViewerState.docs.length <= 0 ? "" : multiDocumentViewerState.docs[0].name }));
            handleClose();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [multiDocumentViewerState.docs])

    const handleClose = () => {
        dispatch(loginResponseActions.setMultiDocumentViewer({ show: false, docs: [], header: "" }));
    }

    return (
        <ModelBox
            open={multiDocumentViewerState.show}
            onClose={handleClose}
            headerTitle={`${multiDocumentViewerState.header} Document Viewer`}
            Component={
                <div className=" lg:w-[50rem] xsm:w-screen/90 m-6">
                    <AgGrid columns={multiImageViewer.columns} data={multiDocumentViewerState.docs} height={" h-50vh "} />
                    {loginResponseState.imageViewer.show && <ImageViewer />}
                </div>
            }
        />
    )
}

export default MultiImageViewer