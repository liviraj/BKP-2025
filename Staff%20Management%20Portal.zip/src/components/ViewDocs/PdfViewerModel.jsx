
import ModelBox from '../elements/ModelBox';
import { useDispatch, useSelector } from 'react-redux';
import { ComplianceAgreementActions } from '../../redux/ComplianceAgreementReducer';
import PdfViewer from '../elements/PdfViewer';
import PropTypes from 'prop-types';

export default function PdfViewerModel({ hideDocViewer }) {

    const { pdfViewerPopup } = useSelector(state => state.complianceAgreement);
    const dispatch = useDispatch();
    const onClose = () => {
        dispatch(ComplianceAgreementActions.resetPdfViewerPopup());
        if(hideDocViewer) hideDocViewer();
    }

    return (
        <div>
            <ModelBox Component={
                <div className='px-3'>
                    <div className=' flex justify-between my-3'>
                        {
                            pdfViewerPopup.docxName &&
                            <div className=' font-semibold	text-gray-500 text-base	'> {pdfViewerPopup.docxName}</div>
                        }
                    </div>
                    <div className={`  overflow-y-auto   ${pdfViewerPopup?.data?.length <= 0 ? "h-[15vh] w-[30vw] bg-[#ffffff]" : " min-w-[50vw] h-[calc(100vh-8rem)] sm:w-[90vw] md:w-[45rem] lg:w-[60rem] xsm:w-[90vw] pb-2 bg-[#f2f2f2] "}   grayScollBarCompliance `}>
                        {
                            pdfViewerPopup?.data?.length > 0 ? (
                                <div className='h-full'>
                                    <PdfViewer PdfViewerData={pdfViewerPopup?.data} />
                                </div>
                            ) : <p className=' font-fontfamily font-semibold text-base flex justify-center items-center w-full text-center min-h-[10vh]'>Document not found.</p>}
                    </div>
                </div>
            } headerTitle={"Preview PDF Document"} open={pdfViewerPopup.show} onClose={onClose} />
        </div>
    )
}

PdfViewerModel.propTypes = {
    hideDocViewer: PropTypes.func,
}