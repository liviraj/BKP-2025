import { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { IoClose } from 'react-icons/io5';
import { userRequest } from '../requests';
import 'react-responsive-modal/styles.css';
import { Modal } from 'react-responsive-modal';
import { downloadFiles, imageViewer } from '../helper';
import { PiWarningDuotone } from 'react-icons/pi'
import { ComplianceAgreementActions } from '../../redux/ComplianceAgreementReducer';
import PdfViewerModel from './PdfViewerModel';


function ImageViewer() {

    const { pdfViewerPopup } = useSelector(state => state.complianceAgreement);
    const loginResponseState = useSelector(state => state.loginResponse);
    const dispatch = useDispatch();
    const [warnMsg, setWarnMsg] = useState("File not found")

    const handleClose = () => {
        dispatch(userRequest.hideImageViewer());
    }

    useEffect(() => {
        const imageName = loginResponseState.imageViewer.imageName;
        if (imageName && imageName.length > 0 && loginResponseState.imageViewer.data && loginResponseState.imageViewer.data.length > 0) {
            let typeName = imageName.split(".");
            typeName = typeName[typeName.length - 1].trim().toLowerCase();
            if (typeName !== "jpg" && typeName !== "jpeg" && typeName !== "png" && typeName !== "psd") {
                if (typeName === "pdf") {
                    dispatch(ComplianceAgreementActions.setPdfViewerPopup({ show: true, data: loginResponseState.imageViewer.data, docxName: loginResponseState.imageViewer.imageName }))
                } else {
                    downloadFiles(loginResponseState.imageViewer.data, imageName);
                    handleClose();
                }
            }
        } else if (imageName && imageName.length > 0 && !(loginResponseState.imageViewer.data && loginResponseState.imageViewer.data.length > 0)) {
            setWarnMsg(`The file '${imageName}' is missing!`);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const showImageViewer = () => {
        imageViewer(loginResponseState.imageViewer.data);
    }

    if (pdfViewerPopup?.show) {
        return <PdfViewerModel hideDocViewer={handleClose} />;
    }

    return (
        <div>
            <Modal open={loginResponseState.imageViewer.show} onClose={handleClose} closeIcon={<IoClose size={25} />}>
                <div className='flex font-fontfamily text-14px text-darkGrey mr-6'><span className=' hover:underline hover:text-blue-500 cursor-pointer' onClick={showImageViewer}>{loginResponseState.imageViewer.imageName && loginResponseState.imageViewer.data ? loginResponseState.imageViewer.imageName : ""}</span></div>
                <div className='flex mt-2 flex-col'>
                    {!(loginResponseState.imageViewer.imageName && loginResponseState.imageViewer.imageName.length > 0 && loginResponseState.imageViewer.data && loginResponseState.imageViewer.data.length > 0) && <div className=' flex justify-center mt-4'><PiWarningDuotone size={40} color={"#d38f24"} /></div>}
                    {loginResponseState.imageViewer.data && loginResponseState.imageViewer.data?.length > 0 ? <img className='h-72 w-full' alt='#' src={`data:image/jpeg;base64,${loginResponseState.imageViewer.data}`} /> : <div className=' font-fontfamily text-18px flex justify-center items-center m-6 mt-2 text-yellow-600 tracking-wider font-bold'>{warnMsg}</div>}
                </div>
            </Modal>
        </div>
    )
}

export default ImageViewer