import ModelBox from '../elements/ModelBox'
import { useDispatch, useSelector } from 'react-redux';
import { ComplianceAgreementActions } from '../../redux/ComplianceAgreementReducer';
import SubHeaderSection from '../layouts/SubHeaderSection';
import { ComplianceDocumentColumn } from '../Grid/Columns';
import AgGrid from '../Grid/AgGrid';
import AssignmentDocumentPopup from './AssignmentDocumentPopup';
import TransparentLoader from '../loader/TransparentLoader';
import { dateFormat } from '../helper';
import AutoSizeButton from '../elements/AutoSizeButton';
import { MdOutlineNotificationsActive } from "react-icons/md";
import { useState } from 'react';
import { documentPolicyRequest } from '../requests';

export default function ViewAcceptanceStatusPopup() {

    const complianceAgreementState = useSelector(state => state.complianceAgreement);
    const userDetails = useSelector(state => state.user);

    const [loader, setLoader] = useState(false);
    const dispatch = useDispatch();

    const onClose = async () => {
        await dispatch(ComplianceAgreementActions.reSetAssignedDocumentHistoryPopup());
    }

    const onhandleNotify = async () => {
        setLoader(true);
        const params = {
            documentId: complianceAgreementState.assignedDocumentHistoryPopup.selectedRow.documentId,
            isNotify: true
        }
        await dispatch(documentPolicyRequest.policyData.getPolicyDataRequest(true, params, async () => {
            await dispatch(documentPolicyRequest.policyData.getNotificationRequest(userDetails.UserID));
            onClose();
        }));
        setLoader(false);
    }

    return (
        <ModelBox Component={
            <>
                <div className={` w-[60vw] xsm:w-screen sm:w-[97vw] lg:w-[75vw] max-h-[90vh] overflow-y-auto  sm:px-8 xsm:px-4 bg-white `}>
                    <SubHeaderSection subHeader={complianceAgreementState.assignedDocumentHistoryPopup.selectedRow.documentTitle} addtextStyle={"!text-black !mb-2"} headerBorder={false} fileProps={{ columns: ComplianceDocumentColumn.viewAcceptanceStatus.columns(), data: complianceAgreementState.employeeAcceptanceStatusData.employeeDetails?.map((val, idx) => ({ ...val, sno: idx + 1, assignedDate: dateFormat(val.assignedDate), completedDate: dateFormat(val.completedDate) })), docName: "Employee Acceptance Status", isPortraitView: true }}
                        newComponent={Object.keys(complianceAgreementState.employeeAcceptanceStatusData.totalCount).length > 0 ? <div className=" absolute right-24 h-8 w-24 rounded-full border border-solid border-[#f3d0a6] font-fontfamily text-gray-600 circleView-shadow text-12px font-bold xsm:hidden sm:flex items-center justify-center">
                            <span className='  text-greenColor mr-1'>{("completedEmpCount" in complianceAgreementState.employeeAcceptanceStatusData.totalCount) ? complianceAgreementState.employeeAcceptanceStatusData.totalCount?.completedEmpCount : ''}</span> / <span className=' ml-1'>{("allEmpCount" in complianceAgreementState.employeeAcceptanceStatusData.totalCount) ? complianceAgreementState.employeeAcceptanceStatusData.totalCount?.allEmpCount : ''}</span>
                        </div> : <></>}
                    />

                    {/* height=" lg:h-[calc(100vh-4.6rem-1.5rem-67px-3.5rem-1.5rem)] md:h-[calc(100vh-4.6rem-1.5rem-119px-3.5rem-1.5rem)] sm:h-[calc(100vh-4.6rem-1.5rem-137px-3.5rem-1.5rem)] xsm:h-[calc(100vh-4.6rem-1.5rem-260px-3.5rem-1.5rem)] " */}
                    <AgGrid columns={ComplianceDocumentColumn.viewAcceptanceStatus.columns()} data={complianceAgreementState.employeeAcceptanceStatusData.employeeDetails} height=" xsm:h-[calc(100vh-19rem)]" isSetFilter />
                    <div className=' flex items-center justify-center p-4'>
                        <div>  <AutoSizeButton value={"Notify"} icon={<MdOutlineNotificationsActive size={20} />} onClick={onhandleNotify} /></div>
                    </div>
                    {complianceAgreementState.agreementDocument.agreementDocmentPopup.show && <AssignmentDocumentPopup />}
                </div>
                {loader && <TransparentLoader isFullWidth />}
            </>
        } headerTitle={"Employee Acceptance Status"} open={complianceAgreementState.assignedDocumentHistoryPopup.show} onClose={onClose} />
    )
}