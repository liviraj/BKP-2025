import { useDispatch, useSelector } from "react-redux"
import ModelBox from "../elements/ModelBox"
import { timeInTimeOutActions } from "../../redux/TimeInTimeOutReducer";
import Label from "../elements/Label";
import DatePickerElement from "../elements/DatePickerElement";
import Button from "../elements/Button";
import { setDefaultValue, strings } from "../Constants";
import moment from "moment";
import { useEffect, useMemo, useState } from "react";
import TransparentLoader from "../loader/TransparentLoader";
import { useForm } from "react-hook-form";
import { exportDateFormat, getLeaveDetails, holidayReducerState, leaveManagementReducerState, timeFormat } from "../helper";
import { employeeRequests, leaveManagementRequest, timeInTimeOutRequest, userRequest } from "../requests";
import ApiResponse from "../Alert/ApiResponse";
import PropTypes from "prop-types";
import Dropdown from "../elements/Dropdown";
import { BsFillCheckCircleFill } from "react-icons/bs";

function AddTimeINTimeOutPopup({ handleRefresh }) {
    const dispatch = useDispatch();
    const timeInTimeOutPopupState = useSelector(state => state.timeInTimeOut.addTimeInTimeOutPopup);
    const userState = useSelector(state => state.user);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const employeeState = useSelector(state => state.employee);
    const leaveManagementState = useSelector(state => state.leaveManagement);

    const { watch, setValue, getValues } = useForm({ defaultValues: initialValue });
    const [loader, setLoader] = useState(false);
    const [isNewRecord, setIsNewRecord] = useState(true);
    const [successMessage, setSuccessMessage] = useState("");
    const data = watch(strings.timeInTimeOutRequest.data);
    const userRecords = watch(strings.timeInTimeOutRequest.userRecords);

    const onClose = () => {
        dispatch(timeInTimeOutActions.addTimeInTimeOutPopup({ show: false, action: "" }));
    }

    useEffect(() => {
        const initialLoad = async () => {
            setLoader(true);
            await Promise.all([
                Object.keys(leaveManagementState.payroll).length <= 0 && dispatch(leaveManagementRequest.getPayroll()),
                employeeState.employeeName.length <= 0 && dispatch(employeeRequests.employeeName()),
                holidayReducerState().holidays.length <= 0 && getLeaveDetails(new Date())
            ]);
            await handleResetData();
            setLoader(false);
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const handleUpdateUserRecords = async () => {
        const getUserRecords = watch(strings.timeInTimeOutRequest.userRecords);
        if (getUserRecords.length > 0) {
            let tempData = [...timeInTimeOutFormat];
            const recordsUpdate = (idx, val) => {
                tempData[idx] = { ...tempData[idx], ...val, value: val?.logTime || "" };
            }
            await getUserRecords.forEach(async (val, index) => {
                await recordsUpdate(index, val);
            });
            setValue(strings.timeInTimeOutRequest.data, tempData);
        }
    }

    const handleResetData = async () => {
        await setLoader(true);
        await setValue(strings.timeInTimeOutRequest.userRecords, timeInTimeOutFormat);
        await setValue(strings.timeInTimeOutRequest.employeeName, '');
        await setValue(strings.timeInTimeOutRequest.date, '');
        await handleUpdateUserRecords();
        await setSuccessMessage('')
        setLoader(false);
    }

    const handleUpdateData = (index, value) => {
        let tempData = [...data];
        if (("logId" in tempData[index]) ? value : true) {
            tempData[index].value = value || "";
            setValue(strings.timeInTimeOutRequest.data, tempData);
        }
    }

    const handleSumbit = async () => {
        await setLoader(true);
        const isValid = handleValidate();
        let timeValue = ''
        if (isValid) {
            const records = getValues();
            const responseData = records.data.filter((val, idx) => {
                if ("logId" in val) {
                    return timeFormat(val.value) !== timeFormat(userRecords[idx].logTime);
                }
                return !!val.value;
            }).map(val => {
                timeValue = moment(val.value);
                let payload = {
                    logId: Object.keys(val).length > 0 && Object.hasOwn(val, 'logId') ? val?.logId : 0,
                    employeeId: records?.employeeName?.value,
                    workDate: exportDateFormat(records.date, true),
                    logType: val.type,
                    logTime: exportDateFormat(moment(records.date).set({ hours: timeValue.hours(), minutes: timeValue.minutes() }), false, true),
                }
                if (isNewRecord) { payload = { ...payload, createdBy: userState.UserID, createdOn: exportDateFormat(new Date()), } }
                else { payload = { ...payload, lastModifiedBy: userState.UserID, lastModifiedOn: exportDateFormat(new Date()), } }
                return payload
            });
            if (isNewRecord) {
                await dispatch(timeInTimeOutRequest.addTimeInTimeOutRequest(responseData, setCallBack));
            }
            else {
                await dispatch(timeInTimeOutRequest.updateTimeInTimeOutDetails(responseData, setCallBack, true));
            }

        }
        setLoader(false);
    }
    const setCallBack = async () => {
        await handleUpdateUserRecords();
        await Promise.all([
            handleReloadRequest(),
            handleRefresh()
        ])
        const records = getValues();
        const userrecord = records?.userRecords && records.userRecords.length > 0 ? records.userRecords[(records.userRecords.length) - 1] : '';
        await setSuccessMessage(`${records.employeeName.empName} record has been successfully saved till the latest entry. Time ${userrecord?.logType} : ${moment(userrecord?.logTime).format("hh:mm A")} `);
    }

    const handleValidate = () => {
        let dateValidation = {}
        let isBetweenValue = false;
        data.forEach((val, idx) => {
            if (data.length > idx && data[idx + 1]?.value) {
                const nextDate = moment(data[idx + 1].value).set({ month: 1, date: 1, year: 2000 });
                const currentDate = moment(val.value).set({ month: 1, date: 1, year: 2000 });
                const datediff = moment(nextDate).diff(currentDate);
                if (datediff <= 0) {
                    dateValidation = { current: val, next: data[idx + 1] };
                }
            }
            if (val.value && idx > 0 && !data[idx - 1]?.value) {
                isBetweenValue = true;
                if (Object.keys(dateValidation).length <= 0) {
                    dateValidation = { current: val, prev: data[idx - 1] };
                }
            }
            return false;
        });
        if (isBetweenValue) {
            dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Alert", message: `Time ${dateValidation?.prev?.type} must be recorded before entering Time ${dateValidation?.current?.type} (${moment(dateValidation?.current?.value).format("hh:mm A")}) field`, isOptional: false }));
        } else if (Object.keys(dateValidation).length > 0) {
            dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Alert", message: `Time ${dateValidation?.current?.type} (${moment(dateValidation?.current?.value).format("hh:mm A")}) must be earlier than Time ${dateValidation?.next?.type} (${moment(dateValidation?.next?.value).format("hh:mm A")})`, isOptional: false }));
        }
        return Object.keys(dateValidation).length <= 0;
    }

    const handleDisableButton = useMemo(() => {
        const value = getValues();
        if (!value?.date && !value?.employeeName) return true
        if (isNewRecord) {
            return !data.some(val => !!val?.value);
        }
        if (userRecords.length > 0) {
            let isValid = userRecords.every((val, idx) => timeFormat(val.logTime) === timeFormat(data[idx].value));
            if (isValid) {
                for (let i = userRecords.length; i < data.length; i++) {
                    if (data[i].value) {
                        isValid = false;
                        break;
                    }
                }
            }
            return isValid;
        }
        return true;
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [data, userRecords, isNewRecord]);

    const handleDateChange = async (updatedDate) => {
        setLoader(true);
        await setValue(strings.timeInTimeOutRequest.date, updatedDate);
        await setValue(strings.timeInTimeOutRequest.data, timeInTimeOutFormat);
        await handleReloadRequest();
        await setSuccessMessage('');
    }

    const handleReloadRequest = async () => {
        setLoader(true);
        const data = getValues();
        const payload = {
            employeeId: data.employeeName.value,
            fromDate: exportDateFormat(data.date, true)
        }
        await dispatch(timeInTimeOutRequest.getTimeInTimeOutDetails(payload, async (data) => {
            await setValue(strings.timeInTimeOutRequest.userRecords, data);
            if (data.length > 0) setIsNewRecord(false);
            else setIsNewRecord(true);
        }))
        await handleUpdateUserRecords();
        setLoader(false);
    }

    const employeeNameOptions = useMemo(() => {
        if (employeeState.employeeName?.length > 0) {
            return employeeState.employeeName.filter(val => val.locationId === setDefaultValue.usLocation.value && (val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation))
        }
        return [];

    }, [employeeState.employeeName]);

    const previousPayrollEndDateValidation = useMemo(() => {
        const usPayroll = leaveManagementReducerState().payroll?.usPayRoll || false;
        if (usPayroll) {
            const currentDifference = moment(new Date(usPayroll?.previous?.payRollEndDate)).diff(new Date(), "days");
            if (currentDifference >= 0) {
                return usPayroll?.previous?.startDate;
            }
            return usPayroll?.current?.startDate;
        }
        return "";
    }, []);


    return (
        <ModelBox
            onClose={onClose}
            open={timeInTimeOutPopupState.show}
            headerTitle={`Add Time In / Out`}
            Component={<div className=" h-screen/90 w-screen/90  ">
                <div className=" px-6">
                    <div className=" grid grid-cols-12 items-center sm:gap-y-4 gap-x-2 my-8 sm:w-[30rem] md:w-[35rem]" >
                        <div className=" col-start-1 sm:col-end-5 xsm:col-end-12 text-15px flex justify-between"><Label label={`Employee Name`} required /><span className=" font-bold">:</span></div>
                        <div className=" sm:col-start-5 xsm:col-start-1 col-end-12">
                            <Dropdown value={watch(strings.timeInTimeOutRequest.employeeName)} options={employeeNameOptions} onChange={(data) => setValue(strings.timeInTimeOutRequest.employeeName, data)} isSearchable={true} isRequired={true} />
                        </div>
                        <div className=" col-start-1 sm:col-end-5 xsm:col-end-12 text-15px flex justify-between"><Label label={`Date`} required /><span className=" font-bold">:</span></div>
                        <div className=" sm:col-start-5 xsm:col-start-1 col-end-12"><DatePickerElement isRequired value={watch(strings.timeInTimeOutRequest.date)} onChange={handleDateChange} disableHolidays={holidayReducerState().holidays} minDate={previousPayrollEndDateValidation} maxDate={new Date()} isDisableSunday disabled={!watch(strings.timeInTimeOutRequest.employeeName)} /> </div>
                    </div>
                    <div className=" grid xl:grid-cols-8 lg:grid-cols-4 sm:grid-cols-2 my-4 border-collapse border border-r-0 border-darkDarkGrey border-solid text-14px">
                        {
                            data?.map((val, idx) =>
                                <div key={val.id} className={`flex flex-col border-r-1 border-darkDarkGrey border-solid divide-y-1 divide-darkDarkGrey border-collapse ${val.addStyle}`}>
                                    <span className=" px-2 py-1"><Label label={val.label} setBold addStyle={"!text-center"} isDisable={val.isLabelView} /></span>
                                    <span className=" px-2 xl:py-1 xsm:py-2"><DatePickerElement isRequired value={val.value} onChange={date => { handleUpdateData(idx, date); setSuccessMessage('') }} showTimeSelect minTime={val.minTime || moment().set({ hours: 0, minutes: 0, seconds: 0 })} maxTime={moment().set({ hours: 23, minutes: 59, seconds: 0 })} setTimeInterval={1} isRemovable={!("logId" in val)} /></span>
                                </div>)
                        }
                    </div>
                    <div className=" flex justify-center items-center my-6 gap-4">
                        <Button value={strings.Buttons.Save} disabled={handleDisableButton} onClick={handleSumbit} />
                        <Button value={strings.Buttons.Reset} onClick={handleResetData} />
                        <Button value={strings.Buttons.Close} onClick={onClose} />
                    </div>
                    {successMessage && <div className=" flex justify-center items-center mt-16 text-greenColor font-medium text-14px p-2 text-center gap-2 leading-3"><BsFillCheckCircleFill size={18} />{successMessage}</div>}
                </div>
                {loader && <TransparentLoader isFullWidth />}
                {apiResponseState.show && <ApiResponse />}
            </div>}
        />
    )
}

export default AddTimeINTimeOutPopup

AddTimeINTimeOutPopup.propTypes = {
    handleRefresh: PropTypes.func
}

const timeInTimeOutFormat = [
    {
        label: "IN",
        value: "",
        addStyle: "",
        isLabelView: false,
        minTime: "",
        type: "In",
        id: "In1"
    },
    {
        label: "OUT",
        value: "",
        addStyle: "sm:border-t-0 xsm:border-t-1",
        isLabelView: false,
        minTime: "",
        type: "Out",
        id: "out1"
    },
    {
        label: "IN",
        value: "",
        addStyle: "lg:border-t-0 xsm:border-t-1",
        isLabelView: false,
        minTime: "",
        type: "In",
        id: "In2"
    },
    {
        label: "OUT",
        value: "",
        addStyle: "lg:border-t-0 xsm:border-t-1",
        isLabelView: false,
        minTime: "",
        type: "Out",
        id: "out2"
    },
    {
        label: "IN",
        value: "",
        addStyle: "xl:border-t-0 xsm:border-t-1",
        isLabelView: false,
        minTime: "",
        type: "In",
        id: "In3"
    },
    {
        label: "OUT",
        value: "",
        addStyle: "xl:border-t-0 xsm:border-t-1",
        isLabelView: false,
        minTime: "",
        type: "Out",
        id: "out3"
    },
    {
        label: "IN",
        value: "",
        addStyle: "xl:border-t-0 xsm:border-t-1",
        isLabelView: false,
        minTime: "",
        type: "In",
        id: "In4"
    },
    {
        label: "OUT",
        value: "",
        addStyle: "xl:border-t-0 xsm:border-t-1",
        isLabelView: false,
        minTime: "",
        type: "Out",
        id: "out4"
    },
];

const initialValue = {
    data: timeInTimeOutFormat,
    date: '',
    userRecords: [],
    employeeName: ''
}