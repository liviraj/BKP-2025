import { useEffect } from 'react';
import ModelBox from '../elements/ModelBox';
import AgGrid from '../Grid/AgGrid';
import { useSelector, useDispatch } from 'react-redux';
import { leaveManagementActions } from '../../redux/leaveManagementReducer';
import { leaveManagement } from '../Grid/Columns';
import Dropdown from '../elements/Dropdown';
import DatePickerElement from '../elements/DatePickerElement';
import Button from '../elements/Button';
import { periodOptionsWithoutPayroll, exportDateFormat, leaveStatus as leaveStatusValue, periodDateFormat } from '../helper';
import { strings } from '../Constants';
import { leaveManagementRequest } from '../requests';
import { useForm } from 'react-hook-form';
import TransparentLoader from '../loader/TransparentLoader';


function LeaveHistoryPopup() {
    const dispatch = useDispatch();
    const leaveHistoryPopup = useSelector(state => state.leaveManagement.leaveRequestQueue.leaveHistoryPopup);
    const { leaveStatus } = useSelector(state => state.leaveManagement);
    const { watch, setValue, getValues } = useForm({ defaultValues: initialState });
    const onClose = () => {
        dispatch(leaveManagementActions.setLeaveHistoryPopup({ data: [], show: false }));
    }

    useEffect(() => {
        const componentDidMount = async () => {
            await dispatch(leaveManagementActions.setLeaveHistoryPopup({ loader: true }))
            await dispatch(leaveManagementActions.setLeaveHistoryPopup({ employeeName: (leaveHistoryPopup.rowData && Object.hasOwn(leaveHistoryPopup.rowData, "employeeName") && leaveHistoryPopup.rowData.employeeName) }))
            await onReset();
            dispatch(leaveManagementActions.setLeaveHistoryPopup({ loader: false }))
        }
        componentDidMount();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const filterLeaveReqQueue = async () => {
        await dispatch(leaveManagementActions.setLeaveHistoryPopup({ loader: true }))
        const data = getValues();
        let filterRecords = { employeeId: leaveHistoryPopup.rowData && Object.hasOwn(leaveHistoryPopup.rowData, "employeeId") && leaveHistoryPopup.rowData.employeeId };
        const period = data.period;
        const employeeStatus = data.status;
        if (employeeStatus) {
            filterRecords = { ...filterRecords, approvalStatus: employeeStatus.label }
        }
        if (period && period.label !== "All") {
            filterRecords = { ...filterRecords, fromDate: exportDateFormat(data.fromDate, true), toDate: exportDateFormat(data.toDate, true) }
        }
        await dispatch(leaveManagementRequest.leaveRequestQueue.getLeaveHistoryPopupData(filterRecords));
        dispatch(leaveManagementActions.setLeaveHistoryPopup({ loader: false }))
    }

    const onReset = async () => {
        await dispatch(leaveManagementActions.setLeaveHistoryPopup({ loader: true }))
        const rowdata = leaveHistoryPopup.rowData;
        await setValue(strings.leaveHistory.status, rowdata && Object.hasOwn(rowdata, "cancelApprovalStatus") ? leaveStatus.find(val => rowdata.cancelApprovalStatus === leaveStatusValue[3].label ? val.label === leaveStatusValue[4].label : val.label === rowdata.cancelApprovalStatus) : leaveStatusValue[4]);
        await onPeriodChange(periodOptionsWithoutPayroll.find((val) => val.value === 4));
        await filterLeaveReqQueue();
        dispatch(leaveManagementActions.setLeaveHistoryPopup({ loader: false }))
    }

    const onPeriodChange = (value) => {
        setValue(strings.leaveRequestQueue.period, value);
        periodDateFormat(value, setValue);
    }

    return (
        <ModelBox Component={
            <>
                <div className=' w-[80vw] md:w-[95vw] h-[calc(100vh-75px)] overflow-y-auto sm:w-screen xsm:w-screen p-4'>
                    <div className='font-fontfamily font-bold text-headerColor tracking-wide'><span className='text-blackColor  text-15px'>Employee Name : </span><span className=' text-headerColor text-14px uppercase pl-1'>{leaveHistoryPopup.employeeName ? leaveHistoryPopup.employeeName : ''}</span></div>
                    <div className='flex mb-6 md:mb-6 xsm:mb-4' >
                        <div className='grid grid-rows-1 md:grid-rows-1 sm:grid-rows-2 xsm:grid-rows-3 gap-x-4 gap-y-1 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-2 w-full'>
                            <div><Dropdown placeholder={"Period"} options={periodOptionsWithoutPayroll} value={watch(strings.leaveHistory.period)} onChange={e => onPeriodChange(e)} isLabelView={true} /></div>
                            <div><DatePickerElement placeholder='From' disabled={watch(strings.leaveHistory.period).label !== strings.filterPeriod.custom} value={watch(strings.leaveHistory.fromDate)} onChange={date => setValue(strings.leaveHistory.fromDate, date)} isRequired={true} isLabelView={true} /></div>
                            <div><DatePickerElement placeholder='To' disabled={watch(strings.leaveHistory.period).label !== strings.filterPeriod.custom} value={watch(strings.leaveHistory.toDate)} onChange={date => setValue(strings.leaveHistory.toDate, date)} minDate={watch(strings.leaveHistory.period).label === strings.filterPeriod.custom && watch(strings.leaveHistory.fromDate)} isRequired={true} isLabelView={true} /></div>
                            <div><Dropdown placeholder={"Status"} value={watch(strings.leaveHistory.status)} options={leaveStatus && leaveStatus.length > 0 ? leaveStatus.filter(val => val.label !== leaveStatusValue[3].label) : []} onChange={e => setValue(strings.leaveHistory.status, e)} isSearchable={true} isLabelView={true} /></div>
                            <div className=' self-end flex'>
                                <Button value={strings.Buttons.Search} onClick={() => filterLeaveReqQueue()} disabled={watch(strings.leaveHistory.period).label === strings.filterPeriod.custom && (!watch(strings.leaveHistory.fromDate) || !watch(strings.leaveHistory.toDate))} />
                                <span className=' mx-3'> <Button value={strings.Buttons.Reset} onClick={() => onReset()} /></span>
                            </div>
                        </div>
                    </div>
                    <div>
                        <AgGrid data={leaveHistoryPopup.data} height="h-[calc(94vh-67px-1.5rem-3.5rem-2rem)] lg:h-[calc(94vh-67px-1.5rem-3.5rem-2rem)] md:h-[calc(94vh-67px-67px-1.5rem-3.5rem-2rem)] xsm:h-[70vh]" columns={leaveManagement.leaveHistory.column()} rowSelection={false} />
                    </div>
                </div>
                {leaveHistoryPopup.loader && <TransparentLoader isFullWidth={true} />}
            </>
        } headerTitle={`Leave History`} open={leaveHistoryPopup.show} onClose={onClose} />
    )
}

const initialState = {
    period: "",
    fromDate: "",
    toDate: "",
    status: leaveStatusValue[4],
}
export default LeaveHistoryPopup;