
import { strings } from "../Constants";
import { useContext, useState } from "react";
import ModelBox from "../elements/ModelBox";
import { useDispatch, useSelector } from "react-redux";
import { complianceReportActions } from "../../redux/complianceReportReducer";
import GenerateReport from "../RequestRoutes/EventManagement/ContinuousEducationReport/GenerateReport";
import GenerateSummary from "../RequestRoutes/EventManagement/ContinuousEducationReport/GenerateSummary";
import GenerateDetails from "../RequestRoutes/EventManagement/ContinuousEducationReport/GenerateDetails";
import { ContinuousEducationReportFooter } from "../RequestRoutes/EventManagement/ContinuousEducationReport";
import { ScrollMenu, VisibilityContext } from 'react-horizontal-scrolling-menu';
import 'react-horizontal-scrolling-menu/dist/styles.css';
import { BsCaretLeftSquare, BsCaretRightSquare } from 'react-icons/bs';
import PropTypes from "prop-types";

export default function ContinuousEducationReportPopup() {

    const dispatch = useDispatch()
    const complianceReportState = useSelector(state => state.complianceReport);
    const [isComplianceTap, setIsComplianceTap] = useState(strings.compliance.generateReport);
    const [isArrowVisible, setIsArrowVisible] = useState(false);

    const handleClose = async () => {
        await dispatch(complianceReportActions.setComplianceReportPopup({ show: false }))
    }

    const complianceTap = [
        { name: strings.compliance.generateReport },
        { name: strings.compliance.generateSummary },
        { name: strings.compliance.generateDetails },
    ];

    const leftArrowIcon = (params) => {
        return <LeftArrow {...params} isArrowVisible={isArrowVisible} />;
    }

    const rightArrowIcon = (params) => {
        return <RightArrow {...params} isArrowVisible={isArrowVisible} />
    }

    return (
        <ModelBox open={complianceReportState.complianceReportPopup.show} headerTitle={"Continuous Education Report"}
            onClose={handleClose} Component={
                <div className=" w-[calc(100vw-10px)]">
                    <div className="  bg-themeBgColor w-screen h-14 min-h-12 md:min-h-12 xsm:min-h-10 md:h-[3rem] sm:h-10 xsm:h-10  items-center font-fontfamily px-4 border-b-2 border-solid border-b-borderThemeColor">
                        <ScrollMenu LeftArrow={leftArrowIcon} RightArrow={rightArrowIcon} onUpdate={(VisibilityContext) => {
                            const { isFirstItemVisible, isLastItemVisible } = VisibilityContext;
                            setIsArrowVisible(!(isFirstItemVisible && isLastItemVisible))
                        }}>
                            {complianceTap.map((val) => (
                                <div key={val.name} className={`${isComplianceTap === val.name ? "bg-white text-headerColor border-borderThemeColor " : "text-darkDarkGrey border-transparent hover:bg-themeHighlightColor hover:border-borderThemeColor "} flex items-center border-2 border-solid md:mt-4 xsm:mt-[0.4rem] md:h-[36px] xsm:h-[36px] w-auto px-4 font-fontfamily text-12px font-bold uppercase tracking-wider text-shadow-sm  whitespace-nowrap rounded-t-xl  hover:!text-headerColor cursor-pointer  `} onClick={() => setIsComplianceTap(val.name)}>{val.name}</div>
                            ))}
                        </ScrollMenu>
                    </div>
                    <div className='rounded-md w-full md:h-auto h-[calc(100vh-5rem)]  overflow-auto ' >
                        <div className=" relative bg-white ">
                            {isComplianceTap === strings.compliance.generateReport && <><GenerateReport /><div className=" mt-5"><ContinuousEducationReportFooter isPopup={true} /></div></>}
                            {isComplianceTap === strings.compliance.generateSummary && <> <GenerateSummary />  <div className=" mt-5">  <ContinuousEducationReportFooter isPopup={true} /> </div> </>}
                            {isComplianceTap === strings.compliance.generateDetails && <> <GenerateDetails />  <div className=" mt-5">  <ContinuousEducationReportFooter isPopup={true} /> </div> </>}
                        </div>
                    </div>
                </div>
            } />
    )
}




const LeftArrow = ({ isArrowVisible }) => {
    const { isFirstItemVisible, isLastItemVisible, scrollPrev } = useContext(VisibilityContext);
    return (
        <span className={` cursor-pointer ${((isFirstItemVisible && isLastItemVisible) || !isArrowVisible) ? 'hidden' : isFirstItemVisible ? " opacity-60 !cursor-default" : ""} mr-2`} onClick={() => scrollPrev()}>
            <BsCaretLeftSquare className={`text-headerColor h-full w-full text-2xl`} />
        </span>
    );
}
LeftArrow.propTypes = {
    isArrowVisible: PropTypes.bool
}

const RightArrow = ({ isArrowVisible }) => {
    const { isLastItemVisible, isFirstItemVisible, scrollNext } = useContext(VisibilityContext);
    return (
        <span className={` cursor-pointer ${((isFirstItemVisible && isLastItemVisible) || !isArrowVisible) ? 'hidden' : isLastItemVisible ? 'opacity-60 !cursor-default' : ''} mx-2`} onClick={() => scrollNext()}>
            <BsCaretRightSquare className={`text-headerColor h-full w-full text-2xl`} />
        </span>
    );
}

RightArrow.propTypes = {
    isArrowVisible: PropTypes.bool
}