import { useEffect, useMemo } from "react";
import { useDispatch, useSelector } from "react-redux"
import { useForm } from "react-hook-form";
import ModelBox from "../elements/ModelBox"
import Label from "../elements/Label";
import Button from "../elements/Button";
import { setDefaultValue, strings } from "../Constants";
import TransparentLoader from "../loader/TransparentLoader";
import ApiResponse from "../Alert/ApiResponse";
import Dropdown from "../elements/Dropdown";
import { departmentRequest, employeeRequests } from "../requests";
import { departmentActions } from "../../redux/departmentReducer";
import { employeeReducerState, exportDateFormat, userReducerState } from "../helper";
import PropTypes from 'prop-types';

function SupervisorPopup({ setCallBack }) {

    const dispatch = useDispatch();
    const employeeModuleState = useSelector(state => state.employee.employeeModule);
    const employeeState = useSelector(state => state.employee);
    const { departmentSupervisorPopup } = useSelector(state => state.department.departmentSupervisor);
    const departmentName = useSelector(state => state.department.departmentName);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const { loader } = useSelector(state => state.department);
    const { UserID, Role } = useSelector(state => state.user);
    const { reset, watch, setValue, handleSubmit, getValues } = useForm({ defaultValues: initialState });
    const location = watch(strings.supervisorNamePopup.location);

    useEffect(() => {
        const initialLoad = async () => {
            await dispatch(departmentActions.setLoader(true));
            departmentName.data?.length <= 0 && await dispatch(departmentRequest.departmentScreenRequest.getFilterDepartmentRequest({ status: 'Active' }));
            employeeState.employeeName.length <= 0 && await dispatch(employeeRequests.employeeName());
            await onResetValue();
            dispatch(departmentActions.setLoader(false));
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onResetValue = async () => {
        await dispatch(departmentActions.setLoader(true));
        await reset();
        const selectedRecord = departmentSupervisorPopup.selectedRow;
        if ((departmentSupervisorPopup.action === "Edit" || departmentSupervisorPopup.action === "View") && Object.keys(selectedRecord).length > 0) {
            await setValue(strings.supervisorNamePopup.department, departmentName?.data?.find(val => val.value === selectedRecord.departmentID));
            await setValue(strings.supervisorNamePopup.location, employeeReducerState().location.find(val => val.label === selectedRecord.location));
            await setValue(strings.supervisorNamePopup.supervisorName, await employeeReducerState().employeeName.find(val => val.value === selectedRecord.employeeId));
        }
        else {
            await setValue(strings.supervisorNamePopup.location, employeeReducerState().location.find(val => val.value === userReducerState().LocationID));
        }
        dispatch(departmentActions.setLoader(false));
    }

    const setValidation = (isReset) => {
        const value = getValues();
        if (departmentSupervisorPopup.action === 'Edit') {
            let isValid = false;
            const data = departmentSupervisorPopup.selectedRow;
            if (value[strings.supervisorNamePopup.supervisorName] && value[strings.supervisorNamePopup.location] && value[strings.supervisorNamePopup.department]) {
                if (!(
                    value[strings.supervisorNamePopup.supervisorName]?.value === data.employeeId && value[strings.supervisorNamePopup.location]?.label === data.location && value[strings.supervisorNamePopup.department]?.value === data.departmentID
                )) { isValid = true }
            }
            return isValid;
        }
        else {
            if (isReset) { return value[strings.supervisorNamePopup.supervisorName] || value[strings.supervisorNamePopup.location] || value[strings.supervisorNamePopup.department] }
            return value[strings.supervisorNamePopup.supervisorName] && value[strings.supervisorNamePopup.location] && value[strings.supervisorNamePopup.department]
        }
    }

    const onClose = () => {
        dispatch(departmentActions.setSupervisorPopup({ show: false, action: "", selectedRecord: {} }));
    }

    const onhandleSubmit = async ({ isNewSupervisor }) => {
        await dispatch(departmentActions.setLoader(true));
        const value = getValues();
        const data = departmentSupervisorPopup.selectedRow;
        let payload = {
            departmentId: value?.department ? value.department.value : 0,
            lastModifiedOn: exportDateFormat(new Date()),
            lastModifiedby: UserID,
            locationId: value?.location ? value.location.value : 0,
            supervisorId: value?.supervisorName ? value.supervisorName.value : 0,
            isNewSupervisor: isNewSupervisor || false
        }
        if (departmentSupervisorPopup.action === 'Edit') {
            await dispatch(departmentRequest.departmentSupervisor.editDepartmentSupervisorRequest(data?.autoId, payload, setCallBack));
        }
        else {
            await dispatch(departmentRequest.departmentSupervisor.addDepartmentSupervisorRequest(payload, setCallBack))
        }
        await dispatch(departmentActions.setLoader(false));
    }

    const supervisorManagerOptions = useMemo(() => {
        return employeeState.employeeName.filter(val => location && location?.value === val.locationId && (val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [employeeState, location]);

    const setResponseCallback = async (status) => {
        if (status) {
            await onhandleSubmit({ isNewSupervisor: true });
        }
    }

    const onlocationChange = (data) => {
        if (!location || location?.value !== data.value) {
            setValue(strings.supervisorNamePopup.location, data);
            setValue(strings.supervisorNamePopup.supervisorName, "");
        }
    }

    return (
        <ModelBox Component={
            <>
                <div className="xsm:w-[90vw] sm:w-[40rem] max-h-[85vh] overflow-auto  p-6 bg-white">
                    <fieldset disabled={departmentSupervisorPopup.action === 'View'}>
                        <Label label="Location" required={true} />
                        <div className=" mb-4"> <Dropdown placeholder={"Location"} value={location} options={employeeState?.location?.filter(val => val.value !== 0)} onChange={onlocationChange} isSearchable={true} isDisable={Role === strings.userRoles.humanResource} isRequired={true} /></div>
                        <Label label="Supervisor Name" required={true} />
                        <div className=" mb-4"><Dropdown value={watch(strings.supervisorNamePopup.supervisorName)} options={supervisorManagerOptions} onChange={data => setValue(strings.supervisorNamePopup.supervisorName, data)} isSearchable={true} isRequired={true} isViewable={employeeModuleState.isDisable} isPopupView /></div>
                        <Label label="Department" required={true} />
                        <div className=" mb-4"><Dropdown value={watch(strings.supervisorNamePopup.department)} options={departmentName.data?.filter(val => val.value !== 0)} onChange={data => setValue(strings.supervisorNamePopup.department, data)} isSearchable={true} isRequired={true} isPopupView /></div>
                    </fieldset>
                    <footer className={`flex flex-wrap xsm:gap-2 sm:gap-4 justify-center sticky z-0 bottom-0 bg-white ${departmentSupervisorPopup.action == 'View' ? ' my-5' : " mt-12 mb-10"}`}>
                        {departmentSupervisorPopup.action != 'View' && <Button value={departmentSupervisorPopup.action === 'Add' ? strings.Buttons.Save : strings.Buttons.Update} disabled={!setValidation()} onClick={handleSubmit(onhandleSubmit)} />}
                        {departmentSupervisorPopup.action != 'View' && <Button value={strings.Buttons.Reset} disabled={!setValidation(true)} onClick={onResetValue} />}
                        <Button value={strings.Buttons.Close} onClick={onClose} />
                    </footer>
                </div>
                <>
                    {loader && <TransparentLoader isFullWidth />}
                    {apiResponseState.show && <ApiResponse setResponseCallback={setResponseCallback} />}
                </>
            </>
        } headerTitle={`${departmentSupervisorPopup.action} Supervisor`} open={departmentSupervisorPopup.show} onClose={onClose} />
    )
}

export default SupervisorPopup
SupervisorPopup.propTypes = {
    setCallBack: PropTypes.func,
}
const initialState = {
    supervisorName: "",
    department: "",
    location: ""
}