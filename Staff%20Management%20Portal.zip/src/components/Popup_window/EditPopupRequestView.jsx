import PropTypes from 'prop-types';
import { useEffect, useMemo, useState } from 'react'
import ModelBox from '../elements/ModelBox'
import { useDispatch, useSelector } from 'react-redux'
import { myRequestActions } from '../../redux/myRequestReducer';
import TextField from '../elements/TextField';
import { useForm } from 'react-hook-form';
import { strings } from '../Constants';
import Label from '../elements/Label';
import TextArea from '../elements/TextArea';
import Dropdown from '../elements/Dropdown';
import { myRequestRequests } from '../requests';
import { dateFormat, exportDateFormat, myRequestReducerState, onSelectSearchformatOptionLabel, userReducerState } from '../helper';
import TransparentLoader from '../loader/TransparentLoader';
import { Avatar } from '@mui/material';
import Button from '../elements/Button';
import SelectableSearchComponent from '../elements/SelectableSearchComponent';

function EditPopupRequestView({ setReloadRecords }) {
    const requestViewState = useSelector(state => state.myRequest.trackingRequest.requestView);
    const myRequestState = useSelector(state => state.myRequest);

    const [loader, setLoader] = useState(false);

    const { watch, setValue, reset, handleSubmit } = useForm({ defaultValues: initialValues })
    const dispatch = useDispatch();
    const imageBinary = watch(strings.trackingRequestView.imageBinary);
    const assignedTo = watch(strings.trackingRequestView.assignedTo);
    const topic = watch(strings.trackingRequestView.topic);
    const status = watch(strings.trackingRequestView.status);
    const description = watch(strings.trackingRequestView.description);

    useEffect(() => {
        const initialLoad = async () => {
            setLoader(true);
            myRequestReducerState().trackingStatus.length <= 0 && await dispatch(myRequestRequests.getTrackingStatus());
            await onReset();
            setLoader(false);
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onReset = async () => {
        await reset();
        await Promise.all([
            setValue(strings.trackingRequestView.topic, requestViewState.selectedRecord.task),
            setValue(strings.trackingRequestView.description, requestViewState.selectedRecord.description),
            setValue(strings.trackingRequestView.status, myRequestReducerState().trackingStatus.length > 0 && requestViewState.selectedRecord?.status ? myRequestReducerState().trackingStatus.find(val => val.label === requestViewState.selectedRecord.status) : ""),
            setValue(strings.trackingRequestView.assignedTo, { label: requestViewState.selectedRecord.AssignedTo, value: requestViewState.selectedRecord.assignedToEmpId }),
            setValue(strings.trackingRequestView.imageBinary, requestViewState.selectedRecord?.imageBinary)
        ]);
    }

    const onClose = async () => {
        await dispatch(myRequestActions.setTrackingRequest({ requestView: { show: false, selectedRecord: {} } }));
    }

    const onValidate = useMemo(() => {
        let isValid = true;
        if (topic && topic !== requestViewState.selectedRecord.task) {
            isValid = false;
        }
        if (status && status.label !== (myRequestState.trackingStatus?.length > 0 && requestViewState.selectedRecord?.status ? myRequestState.trackingStatus.find(val => val.label === requestViewState.selectedRecord.status)?.label : "")) {
            isValid = false;
        }
        if (description && description !== requestViewState.selectedRecord.comments) {
            isValid = false;
        }
        if (assignedTo && assignedTo.label !== requestViewState.selectedRecord.AssignedTo) {
            isValid = false;
        }
        return isValid;
    }, [topic, requestViewState, status, myRequestState, description, assignedTo]);

    const onAssigneeChange = (data) => {
        setValue(strings.trackingRequestView.assignedTo, data);
        setValue(strings.trackingRequestView.imageBinary, data?.imageBinary ? data?.imageBinary : "");
    }

    const onSubmit = async (data) => {
        setLoader(true);
        const selectedRecords = requestViewState.selectedRecord;
        const params = {
            assignedTo: data.assignedTo.value,
            modifiedBy: userReducerState().UserID,
            modifiedDate: exportDateFormat(new Date()),
            requestId: selectedRecords.requestId,
            description: data.description,
            requestStatusId: data.status?.value ? data.status?.value : 0
        }
        await dispatch(myRequestRequests.trackingRequest.updateTrackingRequestDetails(selectedRecords.autoId, params, async (isValid) => {
            if (isValid) {
                setLoader(false);
                await onClose();
                await setReloadRecords();
            }
        }));
        setLoader(false);
    }

    return (
        <div>
            <ModelBox
                onClose={onClose}
                open={requestViewState.show}
                headerTitle={`View Request ${requestViewState.selectedRecord?.taskID ? "- " + requestViewState.selectedRecord?.taskID : ""}`}
                Component={
                    <div>
                        <div className=' md:w-[40rem] xsm:w-[90vw] min-h-[19rem] m-4'>
                            <div>
                                <div className=' grid md:grid-cols-10 xsm:grid-cols-1 md:gap-4 md:order-last xsm:order-first md:mb-0 xsm:mb-4'>
                                    <div className=' md:col-start-1 md:col-end-8'>
                                        <TextField value={topic} onChange={e => setValue(strings.trackingRequestView.topic, e.target.value)} isRequired={true} isDisable={true} addStyle={" h-12 font-fontfamily mb-4 !bg-white !rounded-none !border-x-0 !border-t-0 !opacity-100  "} />
                                    </div>
                                    <div className=' md:col-start-8 md:col-end-12 '>
                                        <Dropdown value={status} onChange={data => setValue(strings.trackingRequestView.status, data)} options={myRequestState.trackingStatus} addStyle={" newHeightwithBorder "} isRequired={true} />
                                    </div>
                                </div>
                                <div className='grid grid-cols-10 items-center pb-3 mt-2 border-b-2 border-gray-200 mb-3     '>
                                    <div className='col-start-1 md:col-end-3 xsm:col-end-5'>  <Label label={"Requested By"} /></div>
                                    <div className='md:col-start-3 xsm:col-start-5 col-end-8 flex gap-2 items-center'><span>:</span>
                                        <span>{requestViewState.selectedRecord ? requestViewState.selectedRecord.employeeName : ""}</span>
                                    </div>
                                    <div className='col-start-1 md:col-end-3 xsm:col-end-5'>  <Label label={"Request Date"} /></div>
                                    <div className='md:col-start-3 xsm:col-start-5 col-end-8 flex gap-2 items-center'><span>:</span>
                                        <span>{requestViewState.selectedRecord ? dateFormat(requestViewState.selectedRecord.requestDate) : ""}</span>
                                    </div>
                                    <div className='col-start-1 md:col-end-3 xsm:col-end-5'>  <Label label={"Assigned By"} /></div>
                                    <div className='md:col-start-3 xsm:col-start-5 col-end-8 flex gap-2 items-center'><span>:</span>
                                        <span>{requestViewState.selectedRecord ? requestViewState.selectedRecord.approvedBy : ""}</span>
                                    </div>
                                    <div className='col-start-1 md:col-end-3 xsm:col-end-5'>  <Label label={"Approved On"} /></div>
                                    <div className='md:col-start-3 xsm:col-start-5 col-end-8 flex gap-2 items-center'><span>:</span>
                                        <span>{requestViewState.selectedRecord ? dateFormat(requestViewState.selectedRecord.approvedOn) : ""}</span>
                                    </div>
                                </div>
                                <div className='  grid grid-cols-7 items-center'>
                                    <div className=' col-start-1 md:col-end-2 xsm:col-end-3'>  <Label label={"Assignee"} /></div>
                                    <div className=' md:col-start-2 xsm:col-start-3 col-end-8 flex gap-2'>
                                        <span>:</span>
                                        <SelectableSearchComponent options={myRequestState.assigneeList} placeholder={assignedTo?.label} value={assignedTo} onChange={data => onAssigneeChange(data)} formatOptionLabel={onSelectSearchformatOptionLabel} >
                                            <span className=' gap-2 flex'>
                                                {imageBinary?.length > 0 ? <img className=' h-8 w-8 rounded-full mx-auto' src={`data:image/jpeg/png;base64,${imageBinary}`} alt='#' /> : <Avatar className=' max-h-8 max-w-[2rem] !text-13px !bg-[#b1b1b1]' >{assignedTo?.label?.length > 0 ? assignedTo.label.split(" ").map(val => val[0]).join("") : ""}</Avatar>}
                                                {assignedTo?.label ? assignedTo.label : ""}
                                            </span>
                                        </SelectableSearchComponent>
                                    </div>
                                    {requestViewState.selectedRecord?.modifiedBy && requestViewState.selectedRecord?.modifiedBy.length > 0 && <>
                                        <div className=' col-start-1 md:col-end-2 xsm:col-end-3'><Label label={"Modified By"} /></div>
                                        <div className=' md:col-start-2 xsm:col-start-3 col-end-8 flex gap-2'>
                                            <span>:</span>
                                            <span>{requestViewState.selectedRecord?.modifiedBy}</span>
                                        </div>
                                    </>}
                                </div>
                                <Label label={"Description"} />
                                <TextArea value={description} onChange={e => setValue(strings.trackingRequestView.description, e.target.value)} height={" h-48 text-12px "} placeholder={"Add a description..."} />
                                <div className=' flex gap-2 justify-center'>
                                    <Button value={strings.Buttons.Save} onClick={handleSubmit(onSubmit)} disabled={onValidate} />
                                    <Button value={strings.Buttons.Close} onClick={onClose} />
                                    <Button value={strings.Buttons.Reset} onClick={onReset} disabled={onValidate} />
                                </div>
                            </div>
                        </div>
                        {loader && <TransparentLoader isFullWidth={true} />}
                    </div>
                }
            />
        </div>
    )
}

export default EditPopupRequestView

EditPopupRequestView.propTypes = {
    setReloadRecords: PropTypes.func
}

const initialValues = {
    topic: "",
    description: "",
    status: "",
    imageBinary: "",
    assignedTo: ""
}