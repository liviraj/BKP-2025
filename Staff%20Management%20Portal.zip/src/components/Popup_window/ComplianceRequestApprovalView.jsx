import { useDispatch, useSelector } from "react-redux";
import ModelBox from "../elements/ModelBox";
import { AddComplianceRequestAction } from "../../redux/AddComplianceRequest";
import Label from "../elements/Label";
import Dropdown from "../elements/Dropdown";
import DatePickerElement from "../elements/DatePickerElement";
import TextField from "../elements/TextField";
import UploadAndDeleteDocument from "../elements/UploadAndDeleteDocument";
import CheckBox from "../elements/CheckBox";
import Button from "../elements/Button";
import { strings } from "../Constants";


export default function ComplianceRequestApprovalView() {
    const complianceRequestApprove = useSelector((state) => state.AddComplianceRequest.complianceRequestApprovePopup);
    const gridSectionLabel = "col-start-1 col-end-4 lg:col-end-4 md:col-end-4 sm:col-end-6 xsm:col-end-6";
    const gridSectionValue = `col-start-5 col-end-10 lg:col-end-9 md:col-end-11 sm:col-end-13 xsm:col-end-13 lg:col-start-4 md:col-start-4 sm:col-start-6 xsm:col-start-7`;
    const dispatch = useDispatch();

    const handleColse = () => {
        dispatch(AddComplianceRequestAction.setComplianceRequestApprovePopup({ show: false, selectedRow: {} }));
    }

    return (
        <ModelBox onClose={handleColse} open={complianceRequestApprove.show}
            headerTitle={`Compliance Request Details`} Component={
                <>
                    <div className=' w-[28rem] lg:w-[50rem] md:w-[45rem] sm:w-[90vw] xsm:w-[90vw] m-4 tracking-wide'>
                        <div className={"font-fontfamily font-bold text-14px grid grid-cols-2 lg:grid-cols-1 md:grid-cols-1 sm:grid-cols-1 xsm:grid-cols-1 m-4"}>
                            <fieldset className={`grid grid-cols-12 my-2 gap-y-3 items-center`}>
                                <span className={gridSectionLabel}> <Label label="Compliance Category" /></span> <span className={gridSectionValue} ><Dropdown value={""} onChange={() => { }} options={[]} isViewable={true} /></span>
                                <span className={gridSectionLabel}> <Label label="Compliance Period" /></span> <span className={gridSectionValue} ><Dropdown isDisable={true} value={""} onChange={() => { }} options={[]} isViewable={true} /></span>
                                <span className={gridSectionLabel}> <Label label="Compliance Date" /></span> <span className={gridSectionValue} ><DatePickerElement value={""} onChange={() => { }} isViewable={true} disabled={true} /></span>
                                <span className={gridSectionLabel}> <Label label="Description" /></span> <span className={gridSectionValue} ><TextField value={""} onChange={() => { }} isDisable={true} /></span>
                                <span className={gridSectionLabel}> <Label label="Expiry Date" /></span> <span className={gridSectionValue} ><DatePickerElement value={""} onChange={() => { }} disabled={true} isViewable={true} /></span>
                                <span className='col-end-6  lg:col-start-9 lg:col-end-12 xl:col-end-12 col-start-1 lg:ml-10  md:col-start-4 md:col-end-10 sm:col-start-6 sm:col-end-13  xsm:col-start-7  xsm:col-end-13'> <CheckBox data={[{ label: "No Expiry" }]} value={""} onChange={() => { }} /></span>
                                <span className={gridSectionLabel}> <Label label="Certificate Image" /></span> <span className={gridSectionValue} ><UploadAndDeleteDocument label={"Choose File"} file={""} onChange={() => { }} isViewable={true} isMultiDocument /></span>
                            </fieldset>
                        </div>
                        <div className="justify-center flex flex-row gap-3 sm:flex-row mb-3" >
                            <div className=' gap-x-3 flex'>
                                <Button value={strings.Buttons.approve} disabled={false} onClick={() => { }} />
                                <Button value={strings.Buttons.reject} disabled={false} onClick={() => { }} />
                            </div>
                            <Button value={strings.Buttons.Close} onClick={() => { handleColse() }} />
                        </div>
                    </div>
                </>
            }

        />
    )
}
