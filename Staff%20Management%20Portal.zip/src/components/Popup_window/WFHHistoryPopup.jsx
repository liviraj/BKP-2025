import { useEffect, useState } from 'react';
import ModelBox from '../elements/ModelBox';
import AgGrid from '../Grid/AgGrid';
import { useSelector, useDispatch } from 'react-redux';
import { wfhColumns } from '../Grid/Columns';
import Dropdown from '../elements/Dropdown';
import DatePickerElement from '../elements/DatePickerElement';
import Button from '../elements/Button';
import { periodOptionsWithoutPayroll, exportDateFormat, leaveStatus, periodDateFormat } from '../helper';
import { strings } from '../Constants';
import { useForm } from 'react-hook-form';
import TransparentLoader from '../loader/TransparentLoader';
import { wfhActions } from '../../redux/wfhReducer';
import { wfhRequest } from '../requests';


function WFHHistoryPopup() {

    const dispatch = useDispatch();

    const wfhHistoryState = useSelector(state => state.wfhRequest.wfhHistoryPopup);

    const { watch, setValue, getValues } = useForm({ defaultValues: initialState });
    const [loader, setLoader] = useState(false);

    useEffect(() => {
        const componentDidMount = async () => {
            setLoader(true);
            await onReset();
            setLoader(false);
        }
        componentDidMount();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const onhandleSearch = async () => {
        setLoader(true);
        const data = getValues();
        const params = {
            employeeId: wfhHistoryState.selectedRecord.employeeId,
            startDate: exportDateFormat(data.fromDate, true),
            endDate: exportDateFormat(data.toDate, true),
            status: data.status?.label
        }

        await dispatch(wfhRequest.ApproveRejectRequest.employeeHistoryRequest(params));
        setLoader(false);
    }

    const onReset = async () => {
        setLoader(true);
        await Promise.all([
            setValue(strings.wfhHistory.status, wfhHistoryState?.status ? leaveStatus.find(val => val.label === wfhHistoryState?.status) : leaveStatus[4]),
            periodDateFormat(periodOptionsWithoutPayroll.find((val) => val.value === 4), setValue)
        ]);
        await onhandleSearch();
        setLoader(false);
    }


    const onClose = () => {
        setLoader(true);
        dispatch(wfhActions.setWFHHistoryPopup({
            data: [],
            show: false,
            selectedRecord: {},
            status: ""
        }));
        setLoader(false);
    }

    return (
        <ModelBox Component={
            <>
                <div className=' w-[80vw] md:w-[95vw] h-[calc(100vh-75px)] overflow-y-auto sm:w-screen xsm:w-screen p-4'>
                    <div className='font-fontfamily font-bold text-headerColor tracking-wide'><span className='text-blackColor  text-15px'>Employee Name : </span><span className=' text-headerColor text-14px uppercase pl-1'>{wfhHistoryState.selectedRecord?.employeeName ? wfhHistoryState.selectedRecord?.employeeName : ''}</span></div>
                    <div className='flex mb-6 md:mb-6 xsm:mb-4' >
                        <div className='grid grid-rows-1 md:grid-rows-1 sm:grid-rows-2 xsm:grid-rows-3 gap-x-4 gap-y-1 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-2 w-full'>
                            <div><Dropdown placeholder={"Period"} options={periodOptionsWithoutPayroll} value={watch(strings.wfhHistory.period)} onChange={value => periodDateFormat(value, setValue)} isLabelView={true} /></div>
                            <div><DatePickerElement placeholder='From' disabled={watch(strings.wfhHistory.period).label !== strings.filterPeriod.custom} value={watch(strings.wfhHistory.fromDate)} onChange={date => setValue(strings.wfhHistory.fromDate, date)} isRequired={true} isLabelView={true} /></div>
                            <div><DatePickerElement placeholder='To' disabled={watch(strings.wfhHistory.period).label !== strings.filterPeriod.custom} value={watch(strings.wfhHistory.toDate)} onChange={date => setValue(strings.wfhHistory.toDate, date)} minDate={watch(strings.wfhHistory.period).label === strings.filterPeriod.custom && watch(strings.wfhHistory.fromDate)} isRequired={true} isLabelView={true} /></div>
                            <div><Dropdown placeholder={"Status"} value={watch(strings.wfhHistory.status)} options={leaveStatus && leaveStatus.length > 0 ? leaveStatus.filter(val => val.label !== leaveStatus[3].label) : []} onChange={e => setValue(strings.wfhHistory.status, e)} isSearchable={true} isLabelView={true} /></div>
                            <div className=' self-end flex'>
                                <Button value={strings.Buttons.Search} onClick={() => onhandleSearch()} disabled={watch(strings.wfhHistory.period).label === strings.filterPeriod.custom && (!watch(strings.wfhHistory.fromDate) || !watch(strings.wfhHistory.toDate))} />
                                <span className=' mx-3'> <Button value={strings.Buttons.Reset} onClick={() => onReset()} /></span>
                            </div>
                        </div>
                    </div>
                    <AgGrid data={wfhHistoryState.data} height="h-[calc(94vh-67px-1.5rem-3.5rem-2rem)] lg:h-[calc(94vh-67px-1.5rem-3.5rem-2rem)] md:h-[calc(94vh-67px-67px-1.5rem-3.5rem-2rem)] xsm:h-[70vh]" columns={wfhColumns.WFHHistory.columns} rowSelection={false} />
                </div>
                {loader && <TransparentLoader isFullWidth />}
            </>
        } headerTitle={`Work From Home(WFH) History`} open={wfhHistoryState.show} onClose={onClose} />
    )
}

const initialState = {
    period: "",
    fromDate: "",
    toDate: "",
    status: leaveStatus[4],
}
export default WFHHistoryPopup;