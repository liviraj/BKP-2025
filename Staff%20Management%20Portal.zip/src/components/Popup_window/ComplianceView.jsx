import { useDispatch, useSelector } from 'react-redux';
import { Modal } from 'react-responsive-modal';
import { reportFields, strings } from '../Constants';
import { IoClose } from 'react-icons/io5';
import { reportRequest } from '../requests';
import AgGrid from '../Grid/AgGrid';
import { complianceReport } from '../Grid/Columns';
import ApiResponse from '../Alert/ApiResponse';
import TransparentLoader from '../loader/TransparentLoader';
import ComplianceFilter from '../Filter/ComplianceFilter';
import ComplianceFooter from '../RequestRoutes/Reports/ComplianceFooter';
import { complianceReportDateFormat } from '../helper';


function ComplianceView() {

    const dispatch = useDispatch();
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const complianceReportState = useSelector(state => state.complianceReport);

    const handleClose = async () => {
        await dispatch(reportRequest.setComplianceView({ show: false }));
    }

    return (
        <Modal open={complianceReportState.complianceView.show} classNames={{ modal: ' p-0 h-screen w-screen !m-0 overflow-hidden bg-transparent min-w-[100%]' }} showCloseIcon={false}>
            <div className=' m-1 bg-white rounded-md' >
                <div className='flex font-fontfamily font-bold text-base rounded-t justify-between px-2 tracking-wider py-2 bg-headerColor text-white '><span className='tracking-widest'>{strings.header.complianceReports}</span><span className=' cursor-pointer' onClick={handleClose}><IoClose size={22} style={{ strokeWidth: "10px" }} /></span></div>
                <div className=' mx-6'><ComplianceFilter isModalView={false} fileProps={{ columns: complianceReport.columns(), data: complianceReportState.data.map((val, idx) => ({ ...val, sno: idx + 1, [reportFields.doj.label]: complianceReportDateFormat(val[reportFields.doj.label]), [reportFields.employeeEligibilityVerification.label]: complianceReportDateFormat(val[reportFields.employeeEligibilityVerification.label]), [reportFields.every3yearNyStateClinicalLicense.label]: complianceReportDateFormat(val[reportFields.every3yearNyStateClinicalLicense.label]), [reportFields.yearNyStateClinicalLicense.label]: complianceReportDateFormat(val[reportFields.yearNyStateClinicalLicense.label]), [reportFields.oneTimeEmployeeTraining.label]: complianceReportDateFormat(val[reportFields.oneTimeEmployeeTraining.label]), [reportFields.everyYearCompetencyAssessmentTest.label]: complianceReportDateFormat(val[reportFields.everyYearCompetencyAssessmentTest.label]), [reportFields.thirdMonthCompetencyAssessmentTest.label]: complianceReportDateFormat(val[reportFields.thirdMonthCompetencyAssessmentTest.label]), [reportFields.sixthMonthCompetencyAssessmentTest.label]: complianceReportDateFormat(val[reportFields.sixthMonthCompetencyAssessmentTest.label]), [reportFields.everyYearHippaPatientConfidentiality.label]: complianceReportDateFormat(val[reportFields.everyYearHippaPatientConfidentiality.label]), [reportFields.yearFireEducationTraining.label]: complianceReportDateFormat(val[reportFields.yearFireEducationTraining.label]), [reportFields.yearBiohazardWasteTraining.label]: complianceReportDateFormat(val[reportFields.yearBiohazardWasteTraining.label]), [reportFields.everyYearBloodbornPathogensTraining.label]: complianceReportDateFormat(val[reportFields.everyYearBloodbornPathogensTraining.label]), [reportFields.yearPPETraining.label]: complianceReportDateFormat(val[reportFields.yearPPETraining.label]), [reportFields.every3yearsDotTraining.label]: complianceReportDateFormat(val[reportFields.every3yearsDotTraining.label]), [reportFields.yearSexualHarassmentTraining.label]: complianceReportDateFormat(val[reportFields.yearSexualHarassmentTraining.label]), [reportFields.everyYearSupervisorPerformanceReview.label]: complianceReportDateFormat(val[reportFields.everyYearSupervisorPerformanceReview.label]), [reportFields.oneYearCovid19.label]: complianceReportDateFormat(val[reportFields.oneYearCovid19.label]), [reportFields.yearHandHygiene.label]: complianceReportDateFormat(val[reportFields.yearHandHygiene.label]) })), docName: "Compliance Report - All Employees", isPageBreak: true }} /></div>
                <AgGrid data={complianceReportState.data} columns={complianceReport.complianceViewColumns()} height="h-[calc(93vh-67px-24px-2.5rem)] lg:h-[calc(93vh-67px-24px-2.5rem)] sm:h-[calc(93vh-134px-24px-2.5rem)] xsm:h-[calc(93vh-268px-24px-2.5rem)]" />
                <ComplianceFooter />
            </div>
            {apiResponseState.show && <ApiResponse />}
            {complianceReportState.loader && <TransparentLoader isFullWidth={true} />}
        </Modal>
    )
}

export default ComplianceView