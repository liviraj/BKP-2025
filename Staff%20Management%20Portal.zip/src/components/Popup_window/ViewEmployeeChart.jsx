import ModelBox from "../elements/ModelBox"
import PropTypes from 'prop-types';
import OrgChart from "../RequestRoutes/Dashboard/OrgChart";

function ViewEmployeeChart({ open, setOpenChart, nodes }) {
    const close = () => {
        setOpenChart(false)
    }
    return (
        <ModelBox Component={
            <div className="w-auto min-h-[30rem] max-h-[93vh] overflow-auto bg-white py-5">
                <div className="py-5" > <OrgChart nodes={nodes} /></div>
            </div>} headerTitle={`Employee Organization Chart`} open={open} onClose={close} />
    )
}

export default ViewEmployeeChart

ViewEmployeeChart.propTypes = {
    open: PropTypes.bool,
    setOpenChart: PropTypes.func,
    nodes: PropTypes.array,
    // setCallBack: PropTypes.func
}


