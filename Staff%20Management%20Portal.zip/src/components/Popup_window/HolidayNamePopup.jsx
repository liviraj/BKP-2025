import { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux"
import { useForm } from "react-hook-form";
import ModelBox from "../elements/ModelBox"
import { holidayActions } from "../../redux/holidayReducer";
import Label from "../elements/Label";
import Button from "../elements/Button";
import { strings } from "../Constants";
import TransparentLoader from "../loader/TransparentLoader";
import ApiResponse from "../Alert/ApiResponse";
import TextField from "../elements/TextField";
import Dropdown from "../elements/Dropdown";
import { holidayRequests } from "../requests";
import { exportDateFormat } from "../helper";
import PropTypes from 'prop-types';

function HolidayNamePopup({ setCallBack }) {

    const holidayPopupState = useSelector(state => state.holiday.holidayName.popup);
    const userState = useSelector(state => state.user);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const employeeState = useSelector(state => state.employee);

    const dispatch = useDispatch();

    const [loader, setLoader] = useState(false);
    const { reset, watch, setValue, handleSubmit } = useForm({ defaultValues: initialState });
    const holidayName = watch(strings.holidayNamePopup.holidayName);
    const location = watch(strings.holidayNamePopup.location);

    useEffect(() => {
        const initialLoad = async () => {
            setLoader(true);
            await onResetValue();
            setLoader(false);
        }
        initialLoad();

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onResetValue = async () => {
        reset();
        const selectedRecord = holidayPopupState.selectedRecord;
        if (holidayPopupState.action === "Edit" && Object.keys(selectedRecord).length > 0) {
            if ("locationId" in selectedRecord && "holidayName" in selectedRecord) {
                setValue(strings.holidayNamePopup.holidayName, selectedRecord.holidayName);
                setValue(strings.holidayNamePopup.location, employeeState.location.find(val => val.value === selectedRecord.locationId));
            }
        } else {
            setValue(strings.holidayNamePopup.location, employeeState.location.find(val => val.value === userState.LocationID))
        }
    }

    const isDisable = useMemo(() => {
        let isValid = false;
        if (holidayPopupState.action === "Edit") {
            const selectedRecord = holidayPopupState.selectedRecord;
            if (("locationId" in selectedRecord && "holidayName" in selectedRecord) && (location.value !== selectedRecord.locationId || holidayName.trim() !== selectedRecord.holidayName?.trim())) {
                isValid = true;
            }

        } else if (location && holidayName?.trim()) {
            isValid = true
        }
        return isValid;

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [location, holidayName]);

    const onClose = () => {
        dispatch(holidayActions.setHolidayNamePopup({ show: false, action: "", selectedRecord: {} }));
    }

    const onhandleSubmit = async (data) => {
        setLoader(true);
        let requiredParams = {
            holidayName: data.holidayName,
            locationId: data.location.value
        }
        if (holidayPopupState.action === "Edit") {
            requiredParams = {
                ...requiredParams,
                modifiedByEmpId: userState.UserID,
                modifiedOn: exportDateFormat(new Date()),
            }
            await dispatch(holidayRequests.holidayNameList.editHolidayName(("holidayId" in holidayPopupState.selectedRecord) ? holidayPopupState.selectedRecord?.holidayId : 0, requiredParams, async () => {
                await onClose();
                await setCallBack();
            }));
        } else {
            requiredParams = {
                ...requiredParams,
                addedByEmpId: userState.UserID,
                addedOn: exportDateFormat(new Date())
            }
            await dispatch(holidayRequests.holidayNameList.addHolidayName(requiredParams, async () => {
                await onClose();
                await setCallBack();
            }));
        }
        setLoader(false);
    }

    return (
        <ModelBox Component={
            <>
                <div className="xsm:w-[90vw] sm:w-[30rem] max-h-[85vh] overflow-auto sm:px-8 xsm:px-4 sm:pb-4 sm:pt-2 xsm:py-2 bg-white">
                    <div className=" grid grid-cols-12 gap-2">
                        <div className=" col-start-1 col-end-13 flex items-center gap-2 flex-wrap">
                            <div className=" flex gap-1 items-end font-bold relative -bottom-2"> <Label label={"Location"} setBold />:</div>
                        </div>
                        <div className=" col-start-1 col-end-13"><Dropdown isRequired value={location} isDisable={userState.Role === strings.userRoles.humanResource} onChange={data => setValue(strings.holidayNamePopup.location, data)} options={employeeState.location ? employeeState.location.filter(val => val.value > 0) : []} /></div>
                        <div className=" col-start-1 col-end-13 flex items-center gap-2 flex-wrap mt-3">
                            <div className=" flex gap-1 items-end font-bold"> <Label label={"Holiday Name"} setBold />:</div>
                        </div>
                        <div className=" col-start-1 col-end-13"><TextField value={holidayName} onChange={e => setValue(strings.holidayNamePopup.holidayName, e.target.value)} /></div>
                    </div>
                    <footer className="flex flex-wrap xsm:gap-2 sm:gap-4 justify-center mt-4 sticky z-0 bottom-0 bg-white">
                        <Button value={holidayPopupState.action === 'Add' ? strings.Buttons.Save : strings.Buttons.Update} disabled={!isDisable} onClick={handleSubmit(onhandleSubmit)} />
                        {holidayPopupState.action === 'Edit' && <Button value={strings.Buttons.Reset} disabled={!isDisable} onClick={onResetValue} />}
                        <Button value={strings.Buttons.Close} onClick={onClose} />
                    </footer>
                </div>
                <>
                    {loader && <TransparentLoader isFullWidth />}
                    {apiResponseState.show && <ApiResponse />}
                </>
            </>
        } headerTitle={`${holidayPopupState.action} Holiday Name`} open={holidayPopupState.show} onClose={onClose} />
    )
}

export default HolidayNamePopup

HolidayNamePopup.propTypes = {
    setCallBack: PropTypes.func
}

const initialState = {
    holidayName: "",
    location: ""
}
