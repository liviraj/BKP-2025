import PropTypes from 'prop-types';
import ModelBox from '../elements/ModelBox';
import TextField from '../elements/TextField';
import TextArea from '../elements/TextArea';
import Label from '../elements/Label';
import Button from '../elements/Button';
import { useSelector, useDispatch } from 'react-redux';
import { leaveManagementActions } from '../../redux/leaveManagementReducer';
import { useState, useEffect } from 'react';
import TransparentLoader from '../loader/TransparentLoader';
import DatePickerElement from '../elements/DatePickerElement';
import Dropdown from '../elements/Dropdown';
import { userReducerState } from '../helper';
import { setDefaultValue, strings } from '../Constants';

const gridFirstSectionLabel = "col-start-1 col-end-4 md:col-end-4 sm:col-end-4 xsm:col-end-13";
const gridSectionValue = `col-start-5 col-end-13 lg:col-end-13 md:col-end-13 sm:col-end-13 xsm:col-end-13 lg:col-start-5 md:col-start-5 sm:col-start-5 xsm:col-start-1`;

function LeaveLedgerEditScreen({ onConfirmedValue }) {
    const dispatch = useDispatch();
    const leaveLedgerState = useSelector(state => state.leaveManagement.leaveLedger);
    const leaveManagementState = useSelector(state => state.leaveManagement);
    const employeeState = useSelector(state => state.employee);
    const [ledgerData, setLedgerData] = useState(initialState);
    const [loader, setLoader] = useState(false);
    let { showPopUp, selectedRow, type } = leaveLedgerState;

    const onClose = () => {
        dispatch(dispatch(leaveManagementActions.setLeaveLedgerPopUp(false)));
    }

    useEffect(() => {
        const creditDays = selectedRow?.creditDays && (Number(selectedRow.creditDays) <= 0);
        const debitDays = selectedRow?.debitDays && (Number(selectedRow.debitDays) <= 0);
        if (!(type && (type === "Add" || type === "setCommonPopup"))) {
            setLedgerData({
                ...ledgerData,
                balanceDays: selectedRow.balanceDays,
                comments: selectedRow.comments,
                creditDays: selectedRow.creditDays.toString(),
                debitDays: selectedRow.debitDays.toString(),
                employeeId: selectedRow.employeeId,
                isUpdated: "No Changes",
                isCreditDisable: type && (type === "Add" || type === "setCommonPopup")
                    ? false
                    : isNaN(selectedRow.creditDays)
                        ? false
                        : !!(creditDays),
                isDebitDisable: isNaN(selectedRow.debitDays)
                    ? false
                    : !!(debitDays)
            });
        }
        if (type === "setCommonPopup") {
            setLedgerData({
                ...ledgerData,
                location: employeeState.location.find(val => val.value === userReducerState().LocationID),
                isCreditDisable: type && (type === "Add" || type === "setCommonPopup")
                    ? false
                    : isNaN(selectedRow.creditDays)
                        ? false
                        : !!(creditDays),
                isDebitDisable: isNaN(selectedRow.debitDays)
                    ? false
                    : !!(debitDays)
            });
        }
        return () => dispatch(leaveManagementActions.resetLeaveLedgerEditPopup());
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onSubmit = async () => {
        setLoader(true);
        onClose();
        onConfirmedValue(ledgerData, type && (type === "Add" || type === "setCommonPopup") ? type : false);
        setLoader(false);
    }

    return (
        <ModelBox Component={
            <div>
                <div className={` w-[30rem] md:w-[30rem] sm:w-[90vw] xsm:w-[90vw] overflow-auto p-4 h-auto `}>
                    <div className={`grid grid-cols-12 gap-y-2 items-center`}>
                        {type && (type === "Add" || type === "setCommonPopup") && <>
                            {type === "setCommonPopup" && <>
                                <span className={gridFirstSectionLabel}>
                                    <Label label="Location " required={true} /></span>
                                <span className={gridSectionValue} >
                                    <Dropdown value={ledgerData.location} onChange={value => value !== ledgerData.location && setLedgerData({ ...ledgerData, location: value, employeeName: "", leaveType: ledgerData.leaveType ? leaveManagementState.allLeaveTypes.find(val => val.locationId === value.value && val.label === ledgerData.leaveType.label) ? ledgerData.leaveType : "" : [] })} options={employeeState.location ? employeeState.location.filter(val => val.value > 0) : []} isRequired={true} isSearchable={false} isDisable={userReducerState().Role === strings.userRoles.humanResource} />
                                </span>
                                <span className={gridFirstSectionLabel}>
                                    <Label label="Employee Name " required={true} /></span>
                                <span className={gridSectionValue} >
                                    <Dropdown value={ledgerData.employeeName} onChange={value => setLedgerData({ ...ledgerData, employeeName: value })} options={("employeeName" in employeeState) && employeeState.employeeName.length > 0 && ledgerData.location ? employeeState.employeeName.filter(val => val.locationId === ledgerData.location.value && (val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation)) : []} isRequired={true} isSearchable={true} isPopupView={true} />
                                </span>
                            </>}
                            <span className={gridFirstSectionLabel}>
                                <Label label="Entry Date " required={true} /></span>
                            <span className={gridSectionValue} >
                                <DatePickerElement value={ledgerData.entryDate} onChange={date => setLedgerData({ ...ledgerData, entryDate: date })} isRequired={true} />
                            </span>
                            <span className={gridFirstSectionLabel}>
                                <Label label="Leave Type " required={true} /></span>
                            <span className={gridSectionValue} >
                                <Dropdown value={ledgerData.leaveType} options={leaveManagementState.allLeaveTypes ? type === "setCommonPopup" && ledgerData.location ? leaveManagementState.allLeaveTypes.filter(val => val.locationId === ledgerData.location.value) : leaveManagementState.allLeaveTypes.filter(val => val.locationId === selectedRow.locationId) : []} onChange={e => setLedgerData({ ...ledgerData, leaveType: e })} isRequired={true} />
                            </span>
                        </>}
                        <span className={gridFirstSectionLabel}>
                            <Label label="Credit Days " required={!!(type && (type === "Add" || type === "setCommonPopup"))} /></span>
                        <span className={gridSectionValue} >
                            <TextField
                                value={ledgerData.creditDays}
                                isDisable={ledgerData.isCreditDisable}
                                onChange={(e) => setLedgerData({ ...ledgerData, creditDays: e.target.value })}
                                isRequired={!!(type && (type === "Add" || type === "setCommonPopup"))}
                            />
                        </span>
                        {!(type && (type === "Add" || type === "setCommonPopup")) && <>
                            <span className={gridFirstSectionLabel}>
                                <Label label="Debit Days " /></span>
                            <span className={gridSectionValue} >
                                <TextField
                                    value={ledgerData.debitDays}
                                    isDisable={ledgerData.isDebitDisable}
                                    onChange={(e) => setLedgerData({ ...ledgerData, debitDays: e.target.value })}
                                />
                            </span>
                        </>}
                        <span className={gridFirstSectionLabel}>
                            <Label label="Description " /></span>
                        <span className={gridSectionValue} >
                            <TextArea
                                value={ledgerData.comments}
                                isDisable={!(type && (type === "Add" || type === "setCommonPopup"))}
                                onChange={(e) => setLedgerData({ ...ledgerData, comments: e.target.value })}
                                height={" h-32 text-13px tracking-normal"}
                            />
                        </span>
                    </div>
                    <div className={`justify-center flex flex-row gap-3 sm:flex-row ${type && (type === "Add" || type === "setCommonPopup") ? " my-4 py-4" : " mb-3"} `}  >
                        <Button
                            value={type && (type === "Add" || type === "setCommonPopup") ? strings.Buttons.Save : strings.Buttons.Update}
                            disabled={type && type === "setCommonPopup"
                                ? !(ledgerData.employeeName && ledgerData.location && ledgerData.entryDate && ledgerData.creditDays && ledgerData.leaveType)
                                : type === "Add"
                                    ? !(ledgerData.entryDate && ledgerData.creditDays && ledgerData.leaveType)
                                    : false
                            }
                            onClick={onSubmit} />
                        {/* <Button value={strings.Buttons.Close} onClick={onClose} /> */}
                    </div>

                </div>
                {loader && <TransparentLoader isFullWidth={true} />}
            </div>
        } headerTitle={type && (type === "Add" || type === "setCommonPopup") ? `Add Credit Days` : `Edit Leave Ledger`} open={showPopUp} onClose={onClose} />
    )
}

const initialState = {
    "balanceDays": "",
    "comments": "",
    "creditDays": "",
    "debitDays": "",
    "employeeId": 0,
    "isUpdated": "",
    entryDate: "",
    leaveType: "",
    employeeName: "",
    location: "",
    isCreditDisable: false,
    isDebitDisable: false
}

export default LeaveLedgerEditScreen;

LeaveLedgerEditScreen.propTypes = {
    onConfirmedValue: PropTypes.func
}