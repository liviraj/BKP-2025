import ModelBox from '../elements/ModelBox';
import { useDispatch, useSelector } from 'react-redux';
import { eventManagementActions } from '../../redux/eventManagementReducer';
import AgGrid from '../Grid/AgGrid';
import { eventManagement } from '../Grid/Columns';

const LogViewPopup = () => {
    const dispatch = useDispatch()
    const { show, data } = useSelector(state => state.eventManagement.tabularView.logViewPopup)
    return (
        <ModelBox Component={
            <div className='w-[90vw] px-5 py-2'><AgGrid data={data || []} columns={eventManagement.EventRecordsTableView.LogViewPopupcolumn()} height={'h-[90vh]'} /></div>
        } headerTitle="Log Detail View" open={show} onClose={() => dispatch(eventManagementActions.setLogViewPopup({ show: false }))} />
    );
};

export default LogViewPopup;