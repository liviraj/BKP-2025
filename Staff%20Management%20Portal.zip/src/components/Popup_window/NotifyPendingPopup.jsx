import { useDispatch, useSelector } from "react-redux";
import ModelBox from "../elements/ModelBox";
import { ComplianceAgreementActions } from "../../redux/ComplianceAgreementReducer";
import TextField from "../elements/TextField";
import CheckboxTree from "../elements/customCheckbox";
import { useEffect, useState } from "react";
import { BiSearch } from 'react-icons/bi'
import Button from "../elements/Button";
import { strings } from "../Constants";
import { complianceAgreementReducerState, exportDateFormat, getCheckedValues, findCheckedKeys, findParents, treeDataFormation } from "../helper";
import { documentPolicyRequest, employeeRequests, eventManagementRequests } from "../requests";
import TransparentLoader from "../loader/TransparentLoader";

const NotifyPendingPopup = () => {
    const dispatch = useDispatch();
    const employeeState = useSelector(state => state.employee);
    const { pendingPolicyUser, completedPolicyUser, isShow, filterData, selectedRow, loader } = useSelector(state => state.complianceAgreement.notifyPendingPolicies);
    const [pendingUser, setPendingUser] = useState("");
    const [completedUser, setCompletedUser] = useState("");

    useEffect(() => {
        const initialLoad = async () => {
            dispatch(ComplianceAgreementActions.setNotifyPendingLoader(true));
            employeeState.department.length <= 0 && await dispatch(employeeRequests.employeeDepartment());
            await dispatch(eventManagementRequests.recordEvents.getEventEmployeeName((data) => dispatch(ComplianceAgreementActions.setUserData(data))));
            const pendingEmployeeId = filterData?.pendingEmployeeId?.length > 0 ? filterData.pendingEmployeeId : [];
            const completedEmployeeId = filterData?.completedEmployeeId?.length > 0 ? filterData.completedEmployeeId : [];
            const pendingTreeData = await treeStructuredUserData(complianceAgreementReducerState().notifyPendingPolicies.userData);

            //pending User
            if (pendingTreeData?.length > 0 && pendingEmployeeId && pendingEmployeeId.length > 0) {
                const pendingCheckedKeys = findCheckedKeys(pendingTreeData, pendingEmployeeId.map(val => ({ employeeId: val })));
                const pendingCheckedParent = findParents(pendingTreeData, pendingCheckedKeys)
                const pendingModifiedData = pendingCheckedKeys && pendingCheckedKeys.length > 0 ? getCheckedValues(pendingTreeData, pendingCheckedKeys) : [];
                dispatch(ComplianceAgreementActions.setPendingPolicyUser({ treeData: pendingModifiedData, checkedKeys: [...pendingCheckedKeys], expandedKeys: pendingCheckedParent }));
            }
            const completedTreeData = await treeStructuredUserData(complianceAgreementReducerState().notifyPendingPolicies.userData);
            // completed User
            if (completedTreeData?.length > 0 && completedEmployeeId && completedEmployeeId.length > 0) {
                const completedCheckedKeys = findCheckedKeys(completedTreeData, completedEmployeeId.map(val => ({ employeeId: val })))
                const completedCheckedParent = findParents(completedTreeData, completedCheckedKeys)
                const completedModifiedData = completedCheckedKeys && completedCheckedKeys.length > 0 ? getCheckedValues(completedTreeData, completedCheckedKeys) : [];
                dispatch(ComplianceAgreementActions.setCompletedPolicyUser({ treeData: completedModifiedData, checkedKeys: [...completedCheckedKeys], expandedKeys: completedCheckedParent }));
            }
            dispatch(ComplianceAgreementActions.setNotifyPendingLoader(false));
        }
        initialLoad();
        return () => {
            dispatch(ComplianceAgreementActions.resetPendingPolicyUser());
            dispatch(ComplianceAgreementActions.resetCompletePolicyUser());
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    useEffect(() => {
        let keysToExpand = [];
        const collectKeys = (nodes, searchValue, treeData) => {
            nodes.forEach((node) => {
                if (node.title.toLowerCase().includes(searchValue.toLowerCase())) {
                    if (!node.children) {
                        keysToExpand.push(node.key);
                        const parentKey = findParents(treeData, [node.key])
                        if (parentKey && parentKey.length > 0) { parentKey.map(val => (!keysToExpand.includes(val)) && keysToExpand.push(val)) }
                    }
                }
                if (node.children) {
                    collectKeys(node.children, searchValue, treeData);
                }
            });
            return keysToExpand;
        };
        if (pendingUser) {
            let keys = collectKeys(pendingPolicyUser.treeData && pendingPolicyUser.treeData.length > 0 ? pendingPolicyUser.treeData : [], (pendingUser && pendingUser.length > 0) ? pendingUser : "", pendingPolicyUser.treeData && pendingPolicyUser.treeData.length > 0 ? pendingPolicyUser.treeData : []);
            dispatch(ComplianceAgreementActions.setPendingPolicyUser({ expandedKeys: keys, autoExpandParent: true, searchExpandedKeys: keys }));
            keysToExpand = [];
        }
        if (completedUser) {
            let keys = collectKeys(completedPolicyUser.treeData && completedPolicyUser.treeData.length > 0 ? completedPolicyUser.treeData : [], (completedUser && completedUser.length > 0) ? completedUser : '', completedPolicyUser.treeData && completedPolicyUser.treeData.length > 0 ? completedPolicyUser.treeData : []);
            dispatch(ComplianceAgreementActions.setCompletedPolicyUser({ expandedKeys: keys, autoExpandParent: true, searchExpandedKeys: keys }));
            keysToExpand = [];
        }
        if (!pendingUser) {
            dispatch(ComplianceAgreementActions.setPendingPolicyUser({ expandedKeys: [], autoExpandParent: false, searchExpandedKeys: [] }));
        }
        if (!completedUser) {
            dispatch(ComplianceAgreementActions.setCompletedPolicyUser({ expandedKeys: [], autoExpandParent: false, searchExpandedKeys: [] }));
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [pendingUser, completedUser]);
    const treeStructuredUserData = async (treeData) => {
        if (treeData && selectedRow) {
            const child = treeData.find(val => val.country === selectedRow.location);
            const treeStructure = async (index) => {
                return [{
                    key: index,
                    title: selectedRow.location,
                    children: Object.hasOwn(child, "departments") && child.departments.length && await treeDataFormation(child, index)
                }];
            }
            return treeStructure(selectedRow?.locationId > 0 ? Number(selectedRow?.locationId) - 1 : 0)
        }
    }
    const handleClose = () => {
        dispatch(ComplianceAgreementActions.setNotifyPolicyShow(false))
    }
    const onExpandPendingPolicyUser = async (newExpandedKeys) => {
        dispatch(ComplianceAgreementActions.setPendingPolicyUser({ expandedKeys: newExpandedKeys }));
    }

    const onExpandCompletedPolicyUser = async (newExpandedKeys) => {
        dispatch(ComplianceAgreementActions.setCompletedPolicyUser({ expandedKeys: newExpandedKeys }));
    };
    const onSubmit = async () => {
        dispatch(ComplianceAgreementActions.setNotifyPendingLoader(true));
        const params = {
            documentId: selectedRow.documentId ? selectedRow.documentId : 0,
            dueDate: selectedRow.dueDate ? exportDateFormat(selectedRow.dueDate) : ''
        }
        await dispatch(documentPolicyRequest.policyData.getPolicyDataRequest(true, params));
        dispatch(ComplianceAgreementActions.setNotifyPendingLoader(false));
    }
    return (
        <ModelBox Component={<>
            <div className=' w-[80vw] md:w-[95vw] h-[calc(100vh-75px)] overflow-hidden sm:w-screen xsm:w-screen p-4'>
                <div className=" w-full h-[calc(100%-3rem)]  justify-center gap-1 lg:gap-5 block lg:flex  lg:border-t lg:border-b border-[#808080] max-w-full overflow-auto">
                    <div className={policiesClass.treeParentClass}>
                        <div className={policiesClass.usersClass}>Pending Employees</div>
                        <div className={policiesClass.searchBoxParentClass}>
                            <TextField value={pendingUser} placeholder="search" type="text" onChange={(e) => setPendingUser(e.target.value)} /> <BiSearch className=' absolute right-3 top-4' />
                        </div>
                        <div className={policiesClass.treeClass}>
                            {pendingPolicyUser.treeData && pendingPolicyUser.treeData.length > 0 ?
                                <div className={pendingUser ? "checkboxSearch" : ""}> <CheckboxTree treeData={pendingPolicyUser.treeData} checkedKeys={pendingPolicyUser.checkedKeys} expandedKeys={pendingPolicyUser.expandedKeys} searchExpandedKeys={pendingPolicyUser.searchExpandedKeys} onExpand={onExpandPendingPolicyUser} searchValue={pendingUser} isDisable /></div> : <p className=' font-fontfamily font-semibold text-base  w-full text-center'>No Pending User</p>}
                        </div>
                    </div>
                    <div className="w-[1px] bg-[#808080]  xsm:hidden sm:block "></div>
                    <div className={policiesClass.treeParentClass} >
                        <div className={policiesClass.usersClass}>Completed Employees</div>
                        <div className={policiesClass.searchBoxParentClass}>
                            <TextField value={completedUser} placeholder="search" type="text" onChange={(e) => setCompletedUser(e.target.value)} /> <BiSearch className=' absolute right-3 top-4' />
                        </div>
                        <div className={policiesClass.treeClass} >
                            {completedPolicyUser.treeData && completedPolicyUser.treeData.length > 0 ?
                                <div className={completedUser ? "checkboxSearch" : ""}> <CheckboxTree treeData={completedPolicyUser.treeData} checkedKeys={completedPolicyUser.checkedKeys} expandedKeys={completedPolicyUser.expandedKeys} searchExpandedKeys={completedPolicyUser.searchExpandedKeys} onExpand={onExpandCompletedPolicyUser} searchValue={completedUser} isDisable /></div> : <p className=' font-fontfamily font-semibold text-base  w-full text-center'>No Completed User</p>}
                        </div>
                    </div>
                </div>
                <div className=" flex items-center justify-center"> <Button value={strings.Buttons.Notify} onClick={onSubmit} disabled={pendingPolicyUser.treeData.length === 0} /></div>
            </div>
            {loader && <TransparentLoader isFullWidth />}
        </>
        } headerTitle={"View Pending Notify"} open={isShow} onClose={handleClose} />
    );
};
const policiesClass = {
    usersClass: "!border-borderThemeColor !bg-themeBgColor mb-2 rounded font-semibold px-3 py-1 flex items-center",
    treeClass: "flex flex-wrap overflow-auto border-coolGray-900 p-3 selected-user h-full sm:max-h-[calc(100%-4.9rem)]",
    treeParentClass: "w-full  lg:w-1/2 my-2",
    searchBoxParentClass: "sticky top-0 z-[1] w-full border-coolGray-900 participant_search rounded-none"
}
export default NotifyPendingPopup;