import { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux"
import { useForm } from "react-hook-form";
import ModelBox from "../elements/ModelBox"
import { holidayActions } from "../../redux/holidayReducer";
import Label from "../elements/Label";
import Dropdown from "../elements/Dropdown";
import DatePickerElement from "../elements/DatePickerElement";
import RadioButton from "../elements/RadioButton";
import Button from "../elements/Button";
import { addHolidayRecordStatus, setDefaultValue, strings } from "../Constants";
import TransparentLoader from "../loader/TransparentLoader";
import ApiResponse from "../Alert/ApiResponse";
import { holidayRequests, userRequest } from "../requests";
import TextField from "../elements/TextField";
import { dateFormat, exportDateFormat, exportYearFormat, getDateDifference, holidayReducerState, usFederalHolidays } from "../helper";
import propTypes from 'prop-types';
import moment from "moment-timezone";
import AgGrid from "../Grid/AgGrid";
import { holiday } from "../Grid/Columns";
import NoteSection from "../elements/NoteSection";


function CreateHolidayPopup({ callAPIService, selectYear }) {

    const gridCol1 = " col-start-1 md:col-end-3 sm:col-end-5 xsm:col-end-12 xsm:mt-3 sm:mt-0";
    const gridCol2 = " md:col-start-3 sm:col-start-5 xsm:col-start-1 md:col-end-6 xsm:col-end-12";
    const gridCol3 = " md:col-start-7 xsm:col-start-1 md:col-end-9 sm:col-end-5 xsm:col-end-12 md:pl-5 md:ml-2 xsm:mt-3 sm:mt-0";
    const gridCol4 = " md:col-start-10 sm:col-start-5 xsm:col-start-1 md:col-end-13 xsm:col-end-12";

    const holidayPopupState = useSelector(state => state.holiday.addHoliday.popup);
    const addholidayState = useSelector(state => state.holiday.addHoliday);
    const employeeState = useSelector(state => state.employee);
    const userState = useSelector(state => state.user);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);

    const dispatch = useDispatch();

    const [loader, setLoader] = useState(false);
    const [selectedRecord, setSelectedRecord] = useState([]);
    const [isUSFederalHolidays, setIsUSFederalHolidays] = useState(holidayPopupState.action === "Add");
    const { reset, watch, setValue, getValues } = useForm({ defaultValues: { ...initialState, year: selectYear || new Date() } });
    const exchangeable = watch(strings.addHolidayPopup.exchangeable);
    const location = watch(strings.addHolidayPopup.location);
    const holidayName = watch(strings.addHolidayPopup.holidayName);
    const fromDate = watch(strings.addHolidayPopup.fromDate);
    const toDate = watch(strings.addHolidayPopup.toDate);
    const alternateHoliday = watch(strings.addHolidayPopup.alternateHoliday);
    const alternateHolidayOptions = watch(strings.addHolidayPopup.alternateHolidayOptions);
    const year = watch(strings.addHolidayPopup.year);
    const federalHolidays = watch(strings.addHolidayPopup.federalHolidayDatas);
    const dateValue = watch(strings.addHolidayPopup.date);

    const federalHolidayRender = async () => {
        setLoader(true);
        const holiday = await usFederalHolidays(exportYearFormat(year));
        setValue(strings.addHolidayPopup.federalHolidayDatas, []);
        await dispatch(holidayRequests.addHoliday.postUsFederalHolidayDetails(holiday, exportYearFormat(year), (data) => {
            setValue(strings.addHolidayPopup.federalHolidayDatas, data.length > 0 ? data : []);
            if (data.length <= 0) {
                setSelectedRecord([]);
            }
        }));
        setLoader(false);
    }

    useEffect(() => {
        const initialLoad = async () => {
            setLoader(true);
            await Promise.all([
                setValue(strings.addHolidayPopup.location, employeeState.location.find(val => val.value === userState.LocationID)),
                addholidayState.holidayNames <= 0 && dispatch(holidayRequests.addHoliday.getAllHolidayNames())
            ]);
            setLoader(false);
            await onResetValue();
        }
        initialLoad();

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        if (year && location && isUSFederalHolidays && location.value === setDefaultValue.usLocation.value) {
            federalHolidayRender();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [year, location, isUSFederalHolidays])

    const onResetValue = async () => {
        reset();
        if (holidayPopupState.action === "Add") {
            await setValue(strings.addHolidayPopup.location, employeeState.location.find(val => val.value === userState.LocationID));
        } else {
            const selectedRecord = holidayPopupState.selectedRecord;
            const isAlternateHoliday = selectedRecord.alternateHolidayId && selectedRecord.alternateHolidayId !== "0";
            const tempLocationVal = employeeState.location.find(val => val.value === +selectedRecord.locationId);
            await Promise.all([
                setValue(strings.addHolidayPopup.location, tempLocationVal),
                setValue(strings.addHolidayPopup.holidayName, selectedRecord.holidayMasterId ? holidayReducerState().addHoliday.holidayNames.find(val => val.value === +selectedRecord.holidayMasterId) : ""),
                setValue(strings.addHolidayPopup.fromDate, selectedRecord.startDate),
                setValue(strings.addHolidayPopup.toDate, selectedRecord.endDate),
                setValue(strings.addHolidayPopup.exchangeable, isAlternateHoliday ? exchangeableOptions[0] : exchangeableOptions[1]),
                setValue(strings.addHolidayPopup.alternateHoliday, isAlternateHoliday ? holidayReducerState().addHoliday.holidayNames.find(val => val.value === +selectedRecord.alternateHolidayId) : ""),
                tempLocationVal && tempLocationVal.value === setDefaultValue.usLocation.value && setValue(strings.addHolidayPopup.date, selectedRecord.startDate)
            ])
        }
    }

    const onClose = () => {
        dispatch(holidayActions.setAddHolidayPopup({ show: false, action: "", selectedRecord: {} }));
    }

    const onlocationChange = (data) => {
        setValue(strings.addHolidayPopup.location, data);
    }

    const setCallBack = async () => {
        await onClose();
        await callAPIService();
    }

    const onSubmit = async () => {
        setLoader(true);
        const data = getValues();
        let params = {
            startDate: exportDateFormat(data.fromDate, true),
            endDate: exportDateFormat(data.toDate, true),
            holidayMasterId: data.holidayName.value,
            isOptional: false,
            locationId: data.location.value,
            alternateHolidayId: 0
        }
        if (data.exchangeable && data.exchangeable === exchangeableOptions[0]) {
            params = { ...params, isOptional: true, alternateHolidayId: data.alternateHoliday.value }
            dispatch(holidayActions.setYearlyFloatingHolidayOptions([]));
        }
        if (holidayPopupState.action === "Add") {
            if (isUSFederalHolidays && location?.value === setDefaultValue.usLocation.value) {
                params = selectedRecord.map(data => {
                    return ({
                        addedByEmpId: userState.UserID,
                        addedOn: exportDateFormat(new Date()),
                        alternateHolidayId: 0,
                        endDate: exportDateFormat(data.endDate, true),
                        holidayID: 0,
                        holidayMasterId: data.holidayMasterId || 0,
                        isOptional: false,
                        locationId: location?.value,
                        startDate: exportDateFormat(data.startDate, true),
                        name: data.name
                    });
                });
            } else {
                params = [{
                    ...params,
                    addedByEmpId: userState.UserID,
                    addedOn: exportDateFormat(new Date()),
                    name: data?.holidayName?.holidayName,
                }];
                if (location?.value === setDefaultValue.usLocation.value) {
                    params[0] = { ...params[0], startDate: exportDateFormat(data.date, true), endDate: exportDateFormat(data.date, true) }
                }

            }
            await dispatch(holidayRequests.addHoliday.addHoliday(params, setCallBack));
        } else {

            const selectedRecord = holidayPopupState.selectedRecord;
            params = {
                ...params,
                modifiedOn: exportDateFormat(new Date()),
                modifiedByEmpId: userState.UserID,
            }
            if (location?.value === setDefaultValue.usLocation.value) {
                params = { ...params, startDate: exportDateFormat(data.date, true), endDate: exportDateFormat(data.date, true) }
            }
            await dispatch(holidayRequests.addHoliday.editHoliday(selectedRecord.holidayID, params, setCallBack));
        }
        setLoader(false);
    }

    const isIndiaButtonDisable = useMemo(() => {
        let isValid = false;
        if (location && holidayName && fromDate && (location?.value === setDefaultValue.usLocation.value ? true : toDate) && (exchangeable && exchangeable === exchangeableOptions[0] ? alternateHoliday : exchangeable)) {
            isValid = true;
        }
        if (holidayPopupState.action !== "Add") {
            const holidaySelectedRecord = holidayPopupState.selectedRecord;
            const isAlternateHoliday = holidaySelectedRecord.alternateHolidayId && holidaySelectedRecord.alternateHolidayId !== "0";
            if (isValid && Number(holidaySelectedRecord.locationId) === location.value && Number(holidaySelectedRecord.holidayMasterId) === holidayName.value && dateFormat(fromDate) === dateFormat(holidaySelectedRecord.startDate) && dateFormat(toDate) === dateFormat(holidaySelectedRecord.endDate) && ((isAlternateHoliday ? exchangeableOptions[0] : exchangeableOptions[1]) === exchangeable) && (isAlternateHoliday ? Number(holidaySelectedRecord.alternateHolidayId) === alternateHoliday.value : true)) {
                isValid = false;
            }
        }
        return isValid;
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [location, holidayName, fromDate, toDate, exchangeable, alternateHoliday]);

    const isIndiaResetDisable = useMemo(() => {
        let isValid = false;
        if (holidayPopupState.action === "Add") {
            isValid = holidayName || fromDate || toDate || exchangeable;
        } else {
            const holidaySelectedRecord = holidayPopupState.selectedRecord;
            const isAlternateHoliday = holidaySelectedRecord.alternateHolidayId && holidaySelectedRecord.alternateHolidayId !== "0";
            isValid = Number(holidaySelectedRecord.holidayMasterId) !== holidayName.value || dateFormat(fromDate) !== dateFormat(holidaySelectedRecord.startDate) || dateFormat(toDate) !== dateFormat(holidaySelectedRecord.endDate) || ((isAlternateHoliday ? exchangeableOptions[0] : exchangeableOptions[1]) !== exchangeable) || (isAlternateHoliday ? Number(holidaySelectedRecord.alternateHolidayId) !== alternateHoliday.value : false);
        }
        return !isValid;
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [location, holidayName, fromDate, toDate, exchangeable, alternateHoliday]);

    const isUSButtonDisable = useMemo(() => {
        if (isUSFederalHolidays) {
            return selectedRecord.length <= 0;
        }
        if (holidayPopupState.action === "Add") {
            return !(location && holidayName && dateValue)
        }
        const holidaySelectedRecord = holidayPopupState.selectedRecord;
        return (Number(holidaySelectedRecord.locationId) === location.value && Number(holidaySelectedRecord.holidayMasterId) === holidayName.value && dateFormat(dateValue) === dateFormat(holidaySelectedRecord.startDate))
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [location, holidayName, dateValue, selectedRecord, isUSFederalHolidays]);

    const isUSResetDisable = useMemo(() => {
        if (isUSFederalHolidays) {
            return !(exportYearFormat(year) !== exportYearFormat(selectYear) || (federalHolidays.length > 0 && federalHolidays?.filter(val => !!val.holidayMasterId)?.length !== selectedRecord.length));
        }
        if (holidayPopupState.action === "Add") {
            return !(holidayName || dateValue);
        }
        const holidaySelectedRecord = holidayPopupState.selectedRecord;
        return !(Number(holidaySelectedRecord.locationId) !== location.value || Number(holidaySelectedRecord.holidayMasterId) !== holidayName.value || dateFormat(dateValue) !== dateFormat(holidaySelectedRecord.startDate))
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [location, holidayName, dateValue, selectedRecord, isUSFederalHolidays, year]);

    const setNumberOfDays = useMemo(() => {
        return getDateDifference(fromDate, toDate, true).toString();
    }, [fromDate, toDate]);

    const onExchangeableUpdate = (value) => {
        setValue(strings.addHolidayPopup.exchangeable, value);
        if (value === exchangeableOptions[1]) {
            setValue(strings.addHolidayPopup.alternateHoliday, "");
        }
    }
    const holidayNameOptions = useMemo(() => {

        let holidayNameLists = addholidayState.holidayNames;
        if (holidayNameLists.length > 0 && location && Object.hasOwn(location, "value")) {
            holidayNameLists = holidayNameLists.filter(val => val.locationId === location.value && val.recordStatus === addHolidayRecordStatus.active);
            if (holidayName && !holidayNameLists.find(val => val.value === holidayName.value)) {
                setValue(strings.addHolidayPopup.holidayName, "");
            }
        }
        return holidayNameLists;
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [addholidayState, location]);

    const onDisableField = () => {
        return !!(holidayPopupState.action === "Edit" && Object.keys(holidayPopupState.selectedRecord).length > 0 && holidayPopupState.selectedRecord.alternateHolidayId && holidayPopupState.selectedRecord.alternateHolidayId > 0);
    }

    useEffect(() => {
        const alternateOptions = async () => {
            if (exchangeable === exchangeableOptions[0] && holidayName && fromDate) {
                let tempOptions = holidayNameOptions && holidayNameOptions.length > 0 ? holidayNameOptions.filter(val => val.value !== holidayName.value) : [];
                setValue(strings.addHolidayPopup.alternateHoliday, "");
                const holidayOptionTypes = watch(strings.addHolidayPopup.holidayOptionTypes);
                if (holidayOptionTypes && holidayOptionTypes.length > 0 && holidayOptionTypes.find(val => (val.holidayId === holidayName.value && val.year === exportYearFormat(fromDate)))) {
                    const tempHolidayOptionTypes = holidayOptionTypes.find(val => (val.holidayId === holidayName.value && val.year === exportYearFormat(fromDate)));
                    const alternateHolidayValues = holidayNameOptions.filter(val => val.value !== holidayName.value)
                    tempOptions = tempHolidayOptionTypes.alternateHolidayOptions.length > 0 ? tempHolidayOptionTypes.alternateHolidayOptions : alternateHolidayValues;
                    setValue(strings.addHolidayPopup.alternateHoliday, tempOptions[0]);
                } else {
                    setLoader(true);
                    await dispatch(holidayRequests.addHoliday.getAlternateHolidayDetails(holidayName.value, exportYearFormat(fromDate), (alternateOptions) => {
                        if (alternateOptions) {
                            const data = [...holidayOptionTypes, { ...holidayName, holidayId: holidayName.value, alternateHolidayOptions: alternateOptions, year: exportYearFormat(fromDate) }];
                            setValue(strings.addHolidayPopup.holidayOptionTypes, data);
                            if (alternateOptions.length > 0) {
                                tempOptions = alternateOptions;
                                setValue(strings.addHolidayPopup.alternateHoliday, alternateOptions[0]);
                            }
                        }
                    }));
                    setLoader(false);
                }
                if (tempOptions.length > 1) {
                    setValue(strings.addHolidayPopup.alternateHoliday, '')
                }
                setValue(strings.addHolidayPopup.alternateHolidayOptions, tempOptions)
            }
        }

        if (!onDisableField()) {
            alternateOptions();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [exchangeable, holidayName, fromDate]);

    const LocationComponent = ({ labelStyle, valueStyle }) => {
        return <>
            <span className={labelStyle}><Label label={"Location"} setBold isDisable={true} /></span>
            <span className={valueStyle}><Dropdown value={location} onChange={onlocationChange} options={employeeState.location ? employeeState.location.filter(val => val.value > 0) : []} isRequired isDisable={true} /></span>
        </>
    }
    LocationComponent.propTypes = {
        labelStyle: propTypes.string.isRequired,
        valueStyle: propTypes.string.isRequired
    }

    const HolidayNameComponent = ({ labelStyle, valueStyle }) => {
        return <>
            <span className={labelStyle}><Label label={"Holiday Name"} required isDisable={onDisableField()} /></span>
            <span className={valueStyle}><Dropdown value={holidayName} onChange={value => setValue(strings.addHolidayPopup.holidayName, value)} isRequired options={holidayNameOptions} isDisable={onDisableField()} /></span>
        </>
    }
    HolidayNameComponent.propTypes = {
        labelStyle: propTypes.string.isRequired,
        valueStyle: propTypes.string.isRequired
    }

    const onhandleValidate = async () => {
        const extendedHoliday = selectedRecord.filter(val => !val?.holidayMasterId);
        if (extendedHoliday.length > 0) {
            return dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `You have selected one or more holidays(${extendedHoliday.map(val => val.name).join(", ")}) that Histogenetics not offered. Are you sure you want to add those holidays?`, isOptional: true }));
        }
        onSubmit();
    }

    const onhandleUSFederalHoliday = async (isConfirm) => {
        if (isConfirm) {
            onSubmit();
        }
    }


    return (
        <ModelBox Component={
            <>
                {location && location.value === setDefaultValue.location.value
                    ? <div className={`xsm:w-[90vw] lg:w-[60rem] w-[90vw] max-h-[85vh] overflow-auto sm:px-8 xsm:px-4 sm:pb-4 xsm:pb-2 bg-white`}>
                        <div className=" grid grid-cols-13 items-center sm:gap-y-9 xsm:gap-y-1 md:mt-2">
                            <LocationComponent labelStyle={gridCol1} valueStyle={gridCol2} />
                            <HolidayNameComponent labelStyle={gridCol3} valueStyle={gridCol4} />
                            <span className={gridCol1}><Label label={"From Date"} required /></span>
                            <span className={gridCol2}><DatePickerElement value={fromDate} onChange={date => setValue(strings.addHolidayPopup.fromDate, date)} minDate={onDisableField() && moment(holidayPopupState.selectedRecord.startDate).set({ month: 0, date: 1, milliseconds: 0, minute: 0 }).toDate()} isRequired maxDate={toDate} isWeekday /></span>
                            <span className={gridCol3}><Label label={"To Date"} required /></span>
                            <span className={gridCol4}><DatePickerElement value={toDate} onChange={date => setValue(strings.addHolidayPopup.toDate, date)} isRequired minDate={fromDate} maxDate={onDisableField() && moment(holidayPopupState.selectedRecord.endDate).set({ month: 11, date: 31, milliseconds: 0, minute: 0 }).toDate()} isWeekday /></span>
                            <span className={gridCol1}><Label label={"Exchangeable"} setBold required={true} isDisable={onDisableField()} /></span>
                            <span className={gridCol2}><RadioButton options={exchangeableOptions} value={exchangeable} onChange={e => { onExchangeableUpdate(e.target.value) }} disabled={onDisableField()} /></span>
                            <span className={gridCol3}><Label label={"Alternate Holiday"} isDisable={!!(alternateHolidayOptions?.length <= 1 || (exchangeable && exchangeable === exchangeableOptions[1]) || onDisableField())} required={!!(exchangeable && exchangeable === exchangeableOptions[0])} setBold /></span>
                            <span className={gridCol4}><Dropdown value={alternateHoliday} onChange={value => { setValue(strings.addHolidayPopup.alternateHoliday, value) }} options={alternateHolidayOptions} isDisable={(alternateHolidayOptions?.length <= 1 || (exchangeable && exchangeable === exchangeableOptions[1]) || onDisableField())} isRequired isPopupView /></span>
                            <span className={gridCol1}><Label label={"Number Of Days"} setBold /></span>
                            <fieldset disabled className={gridCol2}><TextField value={setNumberOfDays} isReadOnly /></fieldset>
                        </div>
                        <footer className={`flex flex-wrap gap-4 justify-center mt-16 mb-14 sticky z-0 bottom-0 bg-white`}>
                            <Button value={holidayPopupState.action === "Add" ? strings.Buttons.Save : strings.Buttons.Update} onClick={onSubmit} disabled={!isIndiaButtonDisable} />
                            <Button value={strings.Buttons.Reset} onClick={() => onResetValue()} disabled={isIndiaResetDisable} />
                            <Button value={strings.Buttons.Close} onClick={onClose} />
                        </footer>
                    </div>
                    : <div className={`xsm:w-[90vw] lg:w-[40rem]  md:w-[90vw] max-h-[93vh] overflow-auto sm:pb-4 xsm:pb-2 bg-white`}>
                        {holidayPopupState.action === "Add" && <div className=' bg-themeBgColor w-full h-14 min-h-14 md:min-h-14 xsm:min-h-10 md:h-14 sm:h-10 xsm:h-10 flex items-center font-fontfamily px-4 border-b-2 border-solid border-b-borderThemeColor' >
                            <button className={` ${isUSFederalHolidays ? " bg-white text-headerColor border-borderThemeColor " : "text-darkDarkGrey border-transparent hover:bg-themeHighlightColor hover:border-borderThemeColor "} border-2 border-solid md:mt-6 xsm:mt-4 md:h-4/5 xsm:h-full w-auto px-4 font-fontfamily text-12px font-bold uppercase tracking-wider text-shadow-sm  whitespace-nowrap rounded-t-xl  hover:!text-headerColor  `} onClick={() => setIsUSFederalHolidays(true)} >US Federal Holidays</button>
                            <button className={` ${!isUSFederalHolidays ? "bg-white text-headerColor border-borderThemeColor " : "text-darkDarkGrey border-transparent hover:bg-themeHighlightColor hover:border-borderThemeColor "} border-2 border-solid md:mt-6 xsm:mt-4 md:h-4/5 xsm:h-full w-auto px-4 font-fontfamily text-12px font-bold uppercase tracking-wider text-shadow-sm  whitespace-nowrap rounded-t-xl  hover:!text-headerColor `} onClick={() => setIsUSFederalHolidays(false)} >Add Custom Holiday</button>
                        </div>}
                        {isUSFederalHolidays ? <>
                            <div className=" grid-cols-12 bg-white inline-grid items-center md:gap-y-2 xsm:gap-y-1 pt-2 mb-4 sm:px-8 xsm:px-4 xsm:w-full md:w-auto">
                                <LocationComponent labelStyle={"col-start-1 md:col-end-6 xsm:col-end-12"} valueStyle={"md:col-start-6 xsm:col-start-1 col-end-12"} />
                                <span className={"col-start-1 md:col-end-6 xsm:col-end-12"}><Label label={"Select Year"} isDisable setBold /></span>
                                <span className={"md:col-start-6 xsm:col-start-1 col-end-12"}><DatePickerElement value={year} disabled onChange={date => setValue(strings.addHolidayPopup.year, date)} isRequired showYearDropdown={true} maxDate={moment().add(10, "years")} /></span>
                            </div>
                            <AgGrid data={federalHolidays} columns={holiday.AddHolidayList.USPopupViewColumns()} getSelectedRow={setSelectedRecord} multiRowSelection height={" xsm:h-[45vh] sm:h-[51vh] sm:px-8 xsm:px-4 "} defaultAllRowselection initialAllRowSelection selectedKeyRowSelection={"holidayMasterId"} />
                        </> : <>
                            <div className=" inline-grid grid-cols-12 items-center bg-white md:gap-y-5 xsm:gap-y-2 md:pt-8 mb-3 sm:px-8 xsm:px-4 w-full">
                                <LocationComponent labelStyle={"col-start-1 md:col-end-6 xsm:col-end-12"} valueStyle={"md:col-start-6 xsm:col-start-1 col-end-12"} />
                                <HolidayNameComponent labelStyle={"col-start-1 md:col-end-6 xsm:col-end-12"} valueStyle={"md:col-start-6 xsm:col-start-1 col-end-12"} />
                                <span className={"col-start-1 md:col-end-6 xsm:col-end-12"}><Label label={"Date"} required /></span>
                                <span className={"md:col-start-6 xsm:col-start-1 col-end-12"}><DatePickerElement value={dateValue} onChange={date => setValue(strings.addHolidayPopup.date, date)} isRequired isWeekday /></span>
                            </div>
                        </>}
                        <footer className={`flex flex-wrap gap-4 justify-center items-center ${isUSFederalHolidays ? "sm:mt-4 xsm:mt-2" : " mt-36 mb-28"}  sticky z-0 bottom-0 bg-white`}>
                            <Button value={holidayPopupState.action === "Add" ? strings.Buttons.Save : strings.Buttons.Update} onClick={onhandleValidate} disabled={isUSButtonDisable} />
                            <Button value={strings.Buttons.Reset} onClick={() => onResetValue()} disabled={isUSResetDisable} />
                            <Button value={strings.Buttons.Close} onClick={onClose} />
                        </footer>
                        {isUSFederalHolidays && <NoteSection notes={`Saving Holidays is a one-time activity for the year. We don't allow the user to add holidays multiple times if any holiday saved for the year already.  Please ensure that you select all the declared holidays of the year once, and click "Save" button`} />}
                    </div>
                }
                <>
                    {loader && <TransparentLoader isFullWidth />}
                    {apiResponseState.show && <ApiResponse setResponseCallback={onhandleUSFederalHoliday} />}
                </>
            </>
        } headerTitle={`${holidayPopupState.action} Holiday`} open={holidayPopupState.show} onClose={onClose} />
    )
}

export default CreateHolidayPopup

CreateHolidayPopup.propTypes = {
    callAPIService: propTypes.func,
    selectYear: propTypes.any
}

const initialState = {
    location: "",
    holidayName: "",
    fromDate: "",
    toDate: "",
    exchangeable: "",
    alternateHoliday: "",
    alternateHolidayOptions: [],
    holidayType: "",
    holidayOptionTypes: [],
    year: new Date(),
    date: "",
    federalHolidayDatas: []
}

const exchangeableOptions = ["Yes", "No"];


