
import ModelBox from '../elements/ModelBox'
import { ComplianceAgreementActions } from '../../redux/ComplianceAgreementReducer';
import { useDispatch, useSelector } from 'react-redux';
import Label from '../elements/Label';
import TextField from '../elements/TextField';
import Dropdown from '../elements/Dropdown';
import Button from '../elements/Button';
import { useForm } from 'react-hook-form';
import { setDefaultValue, strings } from '../Constants';
import { documentPolicyRequest } from '../requests';
import TransparentLoader from '../loader/TransparentLoader';
import { complianceAgreementReducerState, dateFormat, employeeReducerState, exportDateFormat, userReducerState } from '../helper';
import PropTypes from 'prop-types';
import { useEffect, useMemo, useState } from 'react';
import ApiResponse from '../Alert/ApiResponse';
import UploadAndDeleteDocument from '../elements/UploadAndDeleteDocument';
import ImageViewer from '../ViewDocs/ImageViewer';
import DatePickerElement from '../elements/DatePickerElement';

export default function CreatePolicyDocumentPopup({ handleRefresh }) {
    const documentPopup = useSelector(state => state.complianceAgreement.documentPopup);
    const loginResponseState = useSelector(state => state.loginResponse);
    const employeeState = useSelector(state => state.employee);
    const { agreementPolicyType } = useSelector(state => state.complianceAgreement);
    const userDetails = useSelector(state => state.user);

    const { watch, setValue, getValues, reset } = useForm({ defaultValues: initialState });
    const dispatch = useDispatch();
    const [loader, setLoader] = useState(false);
    const documentType = watch(strings.agreementDocument.documentType)
    const localStateValue = getValues();
    const selectedRowData = documentPopup.selectedRow;
    const [isDocumentChange, setIsDocumentChange] = useState(false);

    const gridCol1 = "col-span-12 sm:col-span-5 md:col-span-4 xsm:mt-3 sm:mt-0";
    const gridCol2 = "col-span-12 sm:col-span-7 md:col-span-8";

    useEffect(() => {
        const initialLoad = async () => {
            setLoader(true);
            await dispatch(documentPolicyRequest.complianceAgreement.getPreloadDetailsRequest());
            await handleReset();
            setLoader(false)
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const handleCustomTitle = () => {
        const title = `${watch(strings.agreementDocument.complianceCategory)?.label || ""} ${watch(strings.agreementDocument.compliancePeriod)?.label || ""}`;
        setValue(strings.agreementDocument.documentTitle, title);
    }

    const onClose = () => {
        dispatch(ComplianceAgreementActions.reSetDocumentPopup());
    }

    const handleSave = async () => {
        setLoader(true);
        let params = {
            documentCategoryName: localStateValue.compliancePeriod.label,
            documentImage: localStateValue.policyDocument?.length > 0 ? localStateValue.policyDocument[0]?.binary : '',
            documentName: localStateValue.policyDocument?.length > 0 ? localStateValue.policyDocument[0]?.name : '',
            documentTitle: localStateValue.documentTitle,
            documentType: localStateValue.documentType?.value,
            documentTypeId: localStateValue.complianceCategory?.value,
            locationId: localStateValue.createDoclocation.value,
            documentId: documentPopup.selectedRow?.documentId,
            version: localStateValue.currentVersion,
            documentNumber: localStateValue.documentNumber,
            revisionFrequency: localStateValue.revisionFrequency?.value,
            authorId: localStateValue.authors?.value,
            validFromDate: localStateValue.validityFrom ? exportDateFormat(localStateValue.validityFrom) : '',
            validityDate: localStateValue.validityTo ? exportDateFormat(localStateValue.validityTo) : ''
        }
        if (documentPopup.action === "Edit") {
            params = { ...params, modifiedBy: userDetails.UserID, modifiedOn: exportDateFormat(new Date()) }
            await dispatch(documentPolicyRequest.complianceAgreement.updateDocument(documentPopup.selectedRow?.documentId, params, () => {
                onClose();
                handleRefresh();
            }));
        } else {
            params = { ...params, createdBy: userDetails.UserID, createdOn: exportDateFormat(new Date()), documentId: 0 }
            await dispatch(documentPolicyRequest.complianceAgreement.addDocument(params, async (res) => {
                onClose();
                dispatch(ComplianceAgreementActions.setAgreementDocmentPopup({
                    show: true, selectedRow: res.data.data, action: 'add'
                }))
                handleRefresh();
            }));
        }
        setLoader(false)
    }

    const handleReset = async () => {
        setLoader(true);
        reset();
        const complianceCategory = selectedRowData.documentTypeId > 0 ? employeeState?.nysComplianceCategory.find(val => val.value === selectedRowData.documentTypeId) : {};
        const preloadDetails = complianceAgreementReducerState().documentPopup.preloadDetails;
        setValue(strings.agreementDocument.revisionFrequencyOption, preloadDetails?.revisionFrequencyList.map(val => ({ label: val, value: val })));
        setValue(strings.agreementDocument.authorsOption, preloadDetails?.policyDocAuthors.map(val => ({ ...val, label: val.authorName, value: val.employeeId })));
        if (documentPopup.action === "Edit") {
            selectedRowData.locationId && setValue(strings.agreementDocument.createDoclocation, employeeReducerState().location.find(val => val.value === selectedRowData.locationId));
            setValue(strings.agreementDocument.policyDocument, (selectedRowData.documentName?.length > 0 && selectedRowData.documentImage?.length > 0) ? [{ binary: selectedRowData.documentImage, name: selectedRowData.documentName }] : '');
            agreementPolicyType.length > 0 && selectedRowData?.documentType && setValue(strings.agreementDocument.documentType, agreementPolicyType.find(val => val.value === selectedRowData.documentType));
            if (agreementPolicyType.length > 0 && selectedRowData?.documentType && selectedRowData.documentType === agreementPolicyType[0].value) {
                employeeReducerState().nysComplianceCategory.length > 0 && setValue(strings.agreementDocument.complianceCategoryOptions, employeeReducerState().nysComplianceCategory.filter(val => val.isPolicyAgreement === "true"));
                employeeReducerState().nysComplianceCategory.length > 0 && selectedRowData.documentTypeId && setValue(strings.agreementDocument.complianceCategory, employeeReducerState().nysComplianceCategory.find(val => val.value === selectedRowData.documentTypeId));
                employeeState?.nysCompliancePeriod && complianceCategory?.compliancePeriodIds && setValue(strings.agreementDocument.compliancePeriodOptions, employeeState?.nysCompliancePeriod.filter(val => complianceCategory.compliancePeriodIds?.some(id => id === val.value)));
            } else if (employeeReducerState().documentType?.length > 0) {
                setValue(strings.agreementDocument.complianceCategoryOptions, employeeReducerState().documentType);
                selectedRowData.documentTypeId && setValue(strings.agreementDocument.complianceCategory, employeeReducerState().documentType.find(val => val.value === selectedRowData.documentTypeId));
            }
            setValue(strings.agreementDocument.compliancePeriod, selectedRowData.documentCategoryName?.length > 0 ? employeeState?.nysCompliancePeriod.find(val => val.label === selectedRowData.documentCategoryName) : '');
            setValue(strings.agreementDocument.documentTitle, selectedRowData.documentTitle ? selectedRowData.documentTitle : "");
            setValue(strings.agreementDocument.documentNumber, selectedRowData?.documentNumber || "");
            setValue(strings.agreementDocument.currentVersion, selectedRowData?.version || "");
            watch(strings.agreementDocument.authorsOption)?.length > 0 && setValue(strings.agreementDocument.authors, watch(strings.agreementDocument.authorsOption).find(val => val.value === selectedRowData?.author));
            watch(strings.agreementDocument.revisionFrequencyOption)?.length > 0 && setValue(strings.agreementDocument.revisionFrequency, watch(strings.agreementDocument.revisionFrequencyOption).find(val => val.value === selectedRowData?.revisionFrequency));
            setValue(strings.agreementDocument.validityFrom, selectedRowData?.validFromDate || "");
            setValue(strings.agreementDocument.validityTo, selectedRowData?.validityDate || "");
        } else {
            setValue(strings.agreementDocument.documentNumber, preloadDetails?.documentNumber || "");
            setValue(strings.agreementDocument.currentVersion, preloadDetails?.currentVersion || "");
            employeeReducerState().location?.length > 0 && userDetails?.LocationID && setValue(strings.agreementDocument.createDoclocation, employeeReducerState().location.find(val => val.value === userDetails?.LocationID));
        }
        setLoader(false)
    }

    const isFormDisable = useMemo(() => {
        const isValid =
            localStateValue.documentTitle
            && localStateValue.createDoclocation
            && localStateValue.documentType
            && localStateValue.complianceCategory
            && (localStateValue.documentType?.value === agreementPolicyType[0].value ? localStateValue.compliancePeriod : true)
            && localStateValue.policyDocument.length > 0
            && localStateValue.currentVersion
            && localStateValue.documentNumber
            && localStateValue.revisionFrequency
            && localStateValue.authors
            && localStateValue.validityFrom
            && localStateValue.validityTo
        if (documentPopup.action === 'Edit' && isValid) {
            return !(
                localStateValue.documentTitle === selectedRowData?.documentTitle
                && localStateValue.createDoclocation?.value === selectedRowData.locationId
                && localStateValue.documentType?.value === selectedRowData.documentType
                && localStateValue.complianceCategory?.value === selectedRowData.documentTypeId
                && (localStateValue.documentType?.value === agreementPolicyType[0].value ? localStateValue.compliancePeriod?.label === selectedRowData.documentCategoryName : true)
                && !isDocumentChange
                && localStateValue.currentVersion === selectedRowData.version
                && localStateValue.documentNumber === selectedRowData.documentNumber
                && localStateValue.revisionFrequency.value === selectedRowData.revisionFrequency
                && localStateValue.authors.value === selectedRowData.author
                && dateFormat(localStateValue.validityFrom) === dateFormat(selectedRowData.validFromDate)
                && dateFormat(localStateValue.validityTo) === dateFormat(selectedRowData.validityDate)
            )
        }
        return isValid;
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [documentPopup.action, localStateValue]);

    const isResetDisable = useMemo(() => {
        const isValid = !(localStateValue.documentTitle || localStateValue.createDoclocation || localStateValue.documentType || localStateValue.complianceCategory || (localStateValue.documentType?.value === agreementPolicyType[0].value ? localStateValue.compliancePeriod : true)
            || localStateValue.currentVersion
            || localStateValue.documentNumber
            || localStateValue.revisionFrequency
            || localStateValue.authors
            || localStateValue.validityFrom
            || localStateValue.validityTo
        );

        if (documentPopup.action === 'Edit') {
            return (localStateValue.documentTitle === selectedRowData?.documentTitle && localStateValue.createDoclocation?.value === selectedRowData.locationId && localStateValue.documentType?.value === selectedRowData.documentType && localStateValue.complianceCategory?.value === selectedRowData.documentTypeId && (localStateValue.documentType?.value === agreementPolicyType[0].value ? localStateValue.compliancePeriod?.label === selectedRowData.documentCategoryName : true) && (localStateValue.policyDocument?.length > 0 ? localStateValue.policyDocument[0]?.binary.length === selectedRowData.documentImage.length : !(selectedRowData.documentImage && selectedRowData.documentName))
                && localStateValue.currentVersion === selectedRowData.version
                && localStateValue.documentNumber === selectedRowData.documentNumber
                && localStateValue.revisionFrequency.value === selectedRowData.revisionFrequency
                && localStateValue.authors.value === selectedRowData.author
                && dateFormat(localStateValue.validityFrom) === dateFormat(selectedRowData.validFromDate)
                && dateFormat(localStateValue.validityTo) === dateFormat(selectedRowData.validityDate)
            );
        }
        return isValid;
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [documentPopup.action, localStateValue]);

    const handleDocumentType = (value) => {
        if (localStateValue.documentType?.value !== value.value) {
            setValue(strings.agreementDocument.documentType, value);
            setValue(strings.agreementDocument.complianceCategory, '');
            setValue(strings.agreementDocument.compliancePeriod, '');

            if (value.value === agreementPolicyType[0].value) {
                setValue(strings.agreementDocument.complianceCategoryOptions, employeeReducerState().nysComplianceCategory.filter(val => val.isPolicyAgreement === "true"));
            } else {
                setValue(strings.agreementDocument.complianceCategoryOptions, employeeReducerState().documentType)
                setValue(strings.agreementDocument.compliancePeriodOptions, []);
            }
        }
    }

    const handleComplianceCategory = (value) => {
        setValue(strings.agreementDocument.complianceCategory, value);
        if (localStateValue.complianceCategory?.value !== value.value) {
            const periodOptions = ("compliancePeriodIds" in value) && value?.compliancePeriodIds?.length > 0 ? employeeState?.nysCompliancePeriod.filter(val => value.compliancePeriodIds.includes(val.value)) : [];
            setValue(strings.agreementDocument.compliancePeriodOptions, periodOptions);
            setValue(strings.nysCompliance.compliancePeriod, periodOptions.length > 0 ? periodOptions[0] : '');
        }
    }

    const onhandleDocumentChange = (file) => {
        setValue(strings.agreementDocument.policyDocument, file);
        if (documentPopup.action === 'Edit') {
            setIsDocumentChange(true);
        }
    }

    return (
        <div>
            <ModelBox Component={
                <div>
                    <div className={`xsm:w-[90vw] lg:w-[45rem] w-[90vw] max-h-[88vh] overflow-auto sm:px-8 xsm:px-4 sm:pb-4 xsm:pb-2 bg-white`}>
                        <div className=" grid grid-cols-12 items-center sm:gap-y-4 xsm:gap-y-1 md:mt-2 md:w-[100%]">
                            <span className={gridCol1}><Label label={"Document Type"} required /></span>
                            <span className={gridCol2}> <Dropdown value={watch(strings.agreementDocument.documentType)} onChange={value => { handleDocumentType(value) }} options={agreementPolicyType?.filter(val => val.value !== setDefaultValue.agreementPolicyType.label)} isDisable={false} isRequired isPopupView /></span>
                            <span className={gridCol1}><Label label={documentType?.value === agreementPolicyType[0].value ? "Compliance Category" : "Document  Category"} isDisable={watch(strings.agreementDocument.complianceCategoryOptions).length <= 0} required /></span>
                            <span className={gridCol2}> <Dropdown value={watch(strings.agreementDocument.complianceCategory)} onChange={async (data) => { handleComplianceCategory(data); handleCustomTitle() }} options={watch(strings.agreementDocument.complianceCategoryOptions)} isDisable={watch(strings.agreementDocument.complianceCategoryOptions).length <= 0} isRequired isPopupView /></span>
                            <span className={gridCol1}><Label label={"Compliance Period"} required={!watch(strings.agreementDocument.compliancePeriodOptions).length <= 0} isDisable={watch(strings.agreementDocument.compliancePeriodOptions).length <= 0} /></span>
                            <span className={gridCol2}> <Dropdown value={watch(strings.agreementDocument.compliancePeriod)} onChange={value => { setValue(strings.agreementDocument.compliancePeriod, value); handleCustomTitle() }} options={watch(strings.agreementDocument.compliancePeriodOptions)} isRequired isPopupView isDisable={watch(strings.agreementDocument.compliancePeriodOptions).length <= 0} /></span>
                            <span className={gridCol1}><Label label={"Document Title"} required /></span>
                            <span className={gridCol2}> <TextField value={watch(strings.agreementDocument.documentTitle)} onChange={e => setValue(strings.agreementDocument.documentTitle, e.target.value)} /></span>
                            <span className={gridCol1}><Label label={"Document Number"} required /></span>
                            <span className={gridCol2}> <TextField value={watch(strings.agreementDocument.documentNumber)} onChange={e => setValue(strings.agreementDocument.documentNumber, e.target.value)} /></span>
                            <span className={gridCol1}><Label label={"Revision Frequency"} required /></span>
                            <span className={gridCol2}> <Dropdown value={watch(strings.agreementDocument.revisionFrequency)} onChange={value => { setValue(strings.agreementDocument.revisionFrequency, value) }} options={watch(strings.agreementDocument.revisionFrequencyOption)} isRequired isPopupView /></span>
                            <span className={gridCol1}><Label label={"Authors"} required /></span>
                            <span className={gridCol2}> <Dropdown value={watch(strings.agreementDocument.authors)} onChange={value => { setValue(strings.agreementDocument.authors, value) }} options={watch(strings.agreementDocument.authorsOption)} isRequired isPopupView isSearchable /></span>
                            <span className={gridCol1}><Label label={"Validity From"} required /></span>
                            <span className={gridCol2}> <DatePickerElement value={watch(strings.agreementDocument.validityFrom)} onChange={date => setValue(strings.agreementDocument.validityFrom, date)} isRequired /></span>
                            <span className={gridCol1}><Label label={"Validity To"} required /></span>
                            <span className={gridCol2}> <DatePickerElement value={watch(strings.agreementDocument.validityTo)} onChange={date => setValue(strings.agreementDocument.validityTo, date)} isRequired /></span>
                            <span className={gridCol1}><Label label={"Location"} isDisable={userReducerState().Role !== strings.userRoles.admin || documentPopup.action === "Edit"} required /></span>
                            <span className={gridCol2}> <Dropdown value={watch(strings.agreementDocument.createDoclocation)} onChange={value => { setValue(strings.agreementDocument.createDoclocation, value) }} options={employeeState.location && employeeState.location.length > 0 ? employeeState.location.filter(val => val.value > 0) : []} isDisable={userReducerState().Role !== strings.userRoles.admin || documentPopup.action === "Edit"} isRequired isPopupView /></span>
                            <span className={gridCol1}><Label label={"Current Version"} required /></span>
                            <span className={gridCol2}> <TextField value={watch(strings.agreementDocument.currentVersion)} onChange={e => setValue(strings.agreementDocument.currentVersion, e.target.value)} /></span>
                            <div className="col-span-12 sm:col-span-5 md:col-span-4 flex flex-col">
                                <Label label={"Document"} required />
                                <Label label={"(Only PDF Allowed)"} className="text-sm text-gray-500" />
                            </div>
                            <span className={gridCol2}><UploadAndDeleteDocument label="Browse" onChange={onhandleDocumentChange} file={watch(strings.agreementDocument.policyDocument)} fileType={{ 'application/pdf': [] }} /></span>
                        </div>
                        <footer className={`flex flex-wrap gap-4 justify-center mt-7 `}>
                            <Button value={documentPopup.action === "Add" ? strings.Buttons.Save : strings.Buttons.Update} disabled={!isFormDisable} onClick={handleSave} />
                            <Button value={strings.Buttons.Reset} onClick={handleReset} disabled={isResetDisable} />
                            <Button value={strings.Buttons.Close} onClick={onClose} />
                        </footer>
                    </div>
                    {loader && <TransparentLoader isFullWidth />}
                    {loginResponseState.apiResponse.show && <ApiResponse />}
                    {loginResponseState.imageViewer.show && <ImageViewer />}
                </div>
            } headerTitle={documentPopup.action === 'Edit' ? 'Edit Document' : 'Create Document'} open={documentPopup.show} onClose={onClose} />
        </div>
    )
}

CreatePolicyDocumentPopup.propTypes = {
    handleRefresh: PropTypes.func
}

const initialState = {
    createDoclocation: '',
    documentTitle: "",
    documentType: "",
    complianceCategory: "",
    compliancePeriod: "",
    compliancePeriodOptions: [],
    complianceCategoryOptions: [],
    policyDocument: [],
    currentVersion: '',
    documentNumber: '',
    revisionFrequency: '',
    revisionFrequencyOption: [],
    authors: '',
    authorsOption: [],
    validityFrom: '',
    validityTo: ''
}