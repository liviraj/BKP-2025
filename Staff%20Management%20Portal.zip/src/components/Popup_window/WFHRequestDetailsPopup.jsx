import { useDispatch, useSelector } from "react-redux";
import ModelBox from "../elements/ModelBox";
import TransparentLoader from "../loader/TransparentLoader";
import { wfhActions } from "../../redux/wfhReducer";
import TextArea from "../elements/TextArea";
import { dateFormat, exportDateFormat, leaveStatus } from "../helper";
import AgGrid from "../Grid/AgGrid";
import { wfhColumns } from "../Grid/Columns";
import Button from '../elements/Button';
import { status, strings } from "../Constants";
import { useForm } from "react-hook-form";
import { useEffect, useState } from "react";
import { wfhRequest } from "../requests";
import PropTypes from "prop-types";
import ApiResponse from "../Alert/ApiResponse";


const WFHRequestDetailsPopup = ({ handleRefresh }) => {

    const dispatch = useDispatch();
    const { approvalViewPopup } = useSelector(state => state.wfhRequest);
    const userState = useSelector(state => state.user);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);

    const { watch, setValue, getValues } = useForm({ defaultValues: initialValues });
    const fromData = watch(strings.wfhApproveRejectPopup.fromDate);
    const toData = watch(strings.wfhApproveRejectPopup.toDate);
    const tableData = watch(strings.wfhApproveRejectPopup.data);

    const [loader, setLoader] = useState(false);

    useEffect(() => {
        const initialLoad = async () => {
            const selectedRecord = approvalViewPopup.selectedRecord;
            if (selectedRecord && Object.keys(selectedRecord).length > 0 && selectedRecord?.FromDate && selectedRecord?.ToDate) {
                setLoader(true);
                await Promise.all([
                    setValue(strings.wfhApproveRejectPopup.employeeName, selectedRecord?.employeeName),
                    setValue(strings.wfhApproveRejectPopup.fromDate, selectedRecord?.FromDate),
                    setValue(strings.wfhApproveRejectPopup.toDate, selectedRecord?.ToDate),
                    setValue(strings.wfhApproveRejectPopup.data, approvalViewPopup.data)
                ])
                setLoader(false);
            }
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const handleClose = async () => {
        await dispatch(wfhActions.setApprovalViewPopup({ show: false, selectedRecord: {}, data: [], statusType: "" }));
    }

    const onConfirm = async (status, isAdditionalWfh = false) => {
        setLoader(true);
        const data = getValues();
        const params = {
            approvedBy: userState.UserID,
            approvedOn: exportDateFormat(new Date()),
            approverComments: data.comments,
            requestId: approvalViewPopup.selectedRecord?.workRequestId,
            status,
            isAdditionalWfh,
            workRequestDetailId: approvalViewPopup.data?.length > 0 ? approvalViewPopup.data.map(val => Object.hasOwn(val, "requestDetailsId") ? val?.requestDetailsId : 0) : []
        }
        await dispatch(wfhRequest.ApproveRejectRequest.approvalRequest(params, async () => {
            await handleClose();
            await handleRefresh();
        }));
        setLoader(false);
    }

    const handleConfirmation = (isConfirmed) => {
        if (isConfirmed) {
            onConfirm(status.approved, true);
        }
    }

    return (
        <>
            <ModelBox
                Component={
                    <>
                        <div className=" w-[28rem] md:w-[28rem] sm:w-[90vw] xsm:w-[90vw] m-4 tracking-wide font-fontfamily">
                            <div className="pb-1 font-bold text-blackColor">
                                <span className="  text-15px ">Employee Name :</span>
                                <span className=" text-14px ml-2 text-headerColor uppercase">{watch(strings.wfhApproveRejectPopup.employeeName)}</span>
                            </div>
                            <div className="pb-1">
                                <span className=" font-bold text-15px ">WFH Date :</span>
                                <span className=" text-14px ml-2 ">{`${dateFormat(fromData)} - ${dateFormat(toData)}`}</span>
                            </div>
                            <div className="pb-1">
                                <div className=" font-bold text-15px ">Comments :</div>
                                <TextArea height={" h-20 text-14px tracking-normal"} value={watch(strings.wfhApproveRejectPopup.comments)} onChange={(e) => setValue(strings.wfhApproveRejectPopup.comments, e.target.value)} />
                            </div>

                            <AgGrid height="h-[15rem]" columns={wfhColumns.wfhApprovalView.column} data={tableData} />

                            <div className="flex flex-wrap justify-center gap-3 " >
                                {
                                    approvalViewPopup.statusType === leaveStatus[4].Key
                                        ? <>
                                            <Button value={strings.Buttons.approve} disabled={tableData.length <= 0} onClick={() => onConfirm(status.approved)} />
                                            <Button value={strings.Buttons.reject} disabled={tableData.length <= 0} onClick={() => onConfirm(status.reject)} />
                                        </>
                                        : <Button value={strings.Buttons.cancelWFHRequest} disabled={tableData.length <= 0} onClick={() => onConfirm(status.cancel)} />
                                }
                                <Button value={strings.Buttons.Close} onClick={handleClose} />
                            </div>
                        </div>
                        {loader && <TransparentLoader isFullWidth={true} />}
                        {apiResponseState.show && <ApiResponse setResponseCallback={handleConfirmation} />}
                    </>
                }
                headerTitle={`WFH Request Details`}
                open={approvalViewPopup.show}
                onClose={handleClose}
            />
        </>
    );
};

export default WFHRequestDetailsPopup;

WFHRequestDetailsPopup.propTypes = {
    handleRefresh: PropTypes.func
}

const initialValues = {
    employeeName: "",
    fromDate: "",
    toDate: "",
    comments: "",
    data: []
}

