import PropTypes from 'prop-types';
import ModelBox from "../elements/ModelBox";
import AgGrid from '../Grid/AgGrid';
import { dateFormat, exportYearFormat } from '../helper';
import Button from '../elements/Button';
import moment from 'moment-timezone';
import { useEffect } from 'react';
import { useForm } from "react-hook-form";
import { classNames, strings } from '../Constants';

function LeaveConfirmationView({ onConfirm, onClose, show, onSubmit, titleName, data }) {

    const { watch, setValue, reset } = useForm({ defaultValues: initialState });

    useEffect(() => {
        if (show) {
            let { fromDate, toDate, firstHalf, secondHalf, disableHolidays } = data;

            const FromDate = moment(new Date(fromDate)).startOf('day');
            const ToDate = moment(new Date(toDate)).startOf('day');
            const fromDay = moment(new Date(fromDate)).format("dddd");
            const toDay = moment(new Date(toDate)).format("dddd");

            let formattedData = [];
            if (new Date(FromDate).getTime() === new Date(ToDate).getTime()) {
                formattedData = [{ date: FromDate, type: firstHalf || secondHalf ? "Half Day" : "Full Day", day: fromDay }]
            }
            else {
                formattedData = [{ date: FromDate, type: firstHalf ? "Half Day" : "Full Day", day: fromDay }];

                const isValidHoliday = (selectedDate) => {
                    const day = moment(selectedDate).get("day");
                    const getDates = disableHolidays.find(val => val.year === exportYearFormat(selectedDate));
                    if (getDates && ("holidayDates" in getDates) && getDates.holidayDates.length > 0) {
                        return !!(day !== 0 && day !== 6 && !getDates.holidayDates.includes(dateFormat(selectedDate)));
                    } else {
                        return day !== 0 && day !== 6;
                    }
                }

                let timeDifferenceMs = Math.abs(new Date(ToDate) - new Date(FromDate));
                let dayDifference = Math.floor(timeDifferenceMs / (1000 * 60 * 60 * 24));
                let dateCounter = 1;
                while (dayDifference > 1) {
                    let selectedDate = moment(new Date(FromDate).setDate(new Date(FromDate).getDate() + dateCounter));
                    formattedData = isValidHoliday(selectedDate) ? [...formattedData, { date: selectedDate, type: "Full Day", day: selectedDate.format("dddd") }] : [...formattedData];
                    dateCounter++;
                    dayDifference--;
                }
                formattedData = [...formattedData, { date: ToDate, type: secondHalf ? "Half Day" : "Full Day", day: toDay }];
            }
            setValue('gridData', formattedData);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [show])

    return (
        <div>
            <ModelBox onClose={onClose} onConfirm={onConfirm} open={show} okayBtnLabel={"Confirm"} cancelBtnLabel={"Cancel"} headerTitle={`Leave Request`} Component={
                <div className=' xsm:min-w-[80vw] md:min-w-[27rem] m-4'>
                    {titleName && <div className='font-fontfamily font-bold text-16px text-headerColor pb-3'><span className='text-blackColor'>Employee Name : </span><span className='text-greenColor'>{titleName}</span></div>}
                    <div className='font-fontfamily font-bold text-16px text-headerColor pb-3'>
                        Please confirm the dates below for the applied leave
                    </div>
                    <AgGrid height="h-[15rem]" columns={columns} data={watch('gridData')} rowSelection={false} />
                    <div className="justify-center flex flex-row gap-3 sm:flex-row mb-3">
                        <Button value={strings.Buttons.confirm} onClick={() => { onSubmit(); reset() }} />
                        <Button value={strings.Buttons.Close} onClick={() => { onClose(); reset() }} />
                    </div>
                </div>
            } />
        </div>
    )
}

export default LeaveConfirmationView;

LeaveConfirmationView.propTypes = {
    onConfirm: PropTypes.func,
    onClose: PropTypes.func,
    show: PropTypes.bool,
    onSubmit: PropTypes.func,
    titleName: PropTypes.string,
    data: PropTypes.object
}

const initialState = {
    gridData: []
}

const columns = [
    {
        headerName: "S.No",
        field: "sno",
        // eslint-disable-next-line no-unused-vars
        comparator: (valueA, valueB, nodeA, nodeB, isDescending) => Number(nodeA.id) - Number(nodeB.id),
        cellRenderer: params => (<div className={`h-full w-full flex items-center ml-6`}>{Number(params.node.id) + 1}</div>), //holdToDisplay={0}
        lockPosition: 'left',
        checkboxSelection: false,
        minWidth: 70,
        maxWidth: 70,
    },
    {
        headerName: "Leave Date",
        field: "date",
        minWidth: 120,
        cellRenderer: params => (<div className={classNames.contextMenuValue}>{dateFormat(params.value)}</div>),
    },
    {
        headerName: "Day",
        field: "day",
        minWidth: 110,
        cellRenderer: params => (<div className={classNames.contextMenuValue}>{params.value}</div>),
    },
    {
        headerName: "F/H Day",
        field: "type",
        minWidth: 90,
        maxWidth: 95,
        cellRenderer: params => (<div className={classNames.contextMenuValue}>{params.value}</div>),
    }
]