import { useDispatch, useSelector } from "react-redux";
import ModelBox from "../elements/ModelBox";
import Dropdown from "../elements/Dropdown";
import AgGrid from "../Grid/AgGrid";
import Button from "../elements/Button";
import TransparentLoader from "../loader/TransparentLoader";
import ApiResponse from "../Alert/ApiResponse";
import ImageViewer from "../ViewDocs/ImageViewer";
import Label from "../elements/Label";
import { useEffect, useState } from "react";
import UploadAndDeleteDocument from "../elements/UploadAndDeleteDocument";
import { timeInTimeOutActions } from "../../redux/TimeInTimeOutReducer";
import { dateFormat, exportDateFormat, periodDateFormat, periodOptions, timeInOutReducerState } from "../helper";
import { timeInAndTimeOut } from "../Grid/Columns";
import * as XLSX from 'xlsx';
import { timeInTimeOutRequest, userRequest } from "../requests";
import DatePickerElement from "../elements/DatePickerElement";
import { strings, timeInTimeOutUploadDocumentValidation } from "../Constants";
import { useForm } from "react-hook-form";
import moment from "moment";
import ColorLegend from "../elements/ColorLegend";

const TimeInOutUploadDocumentPopup = () => {
    const dispatch = useDispatch();
    const loginResponseState = useSelector(state => state.loginResponse);
    const { show } = useSelector(state => state.timeInTimeOut.timeInOutUploadDocument);
    const userState = useSelector(state => state.user);

    const { watch, setValue, getValues } = useForm({ defaultValues: initialvalue });
    const toDate = watch(strings.timeInOUtUPloadDocument.toDate);
    const fromDate = watch(strings.timeInOUtUPloadDocument.fromDate);
    const period = watch(strings.timeInOUtUPloadDocument.period);

    const [uploadDocument, setUploadDocument] = useState([]);
    const [excelData, setExcelData] = useState({ columns: [], data: [] });
    // const [excelSheets, setExcelSheets] = useState({ selected: "", options: [] });
    const [loader, setLoader] = useState(false);

    useEffect(() => {
        try {
            setLoader(true)
            if (uploadDocument.length > 0) {
                const value = getValues();
                const fileObj = uploadDocument[0];
                const workbook = XLSX.read(fileObj.binary, { type: "base64" });
                // const excelSheetNames = workbook.SheetNames.map((val, idx) => ({ value: idx, label: val }))
                // setExcelSheets({ selected: excelSheetNames[0], options: excelSheetNames });
                const sheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[sheetName];
                const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
                const data = timeInAndTimeOut.timeInAndTimeOutEmployeeHistory.uploadAuditPopup.convertFormattedRecords(jsonData);
                const convertedData = data?.data?.map((val) => {
                    const isHighlight = !timeInOutReducerState().timeInOutUploadDocument.employeeCodes.includes(val["Employee Number"]);
                    if (isHighlight) {
                        dispatch(timeInTimeOutActions.setTimeInOutUploadDocument({ isValidRecord: false }));
                    }
                    return { ...val, Date: excelSerialToDate(val.Date), In: excelSerialToDate(val.In, true), Out: excelSerialToDate(val.Out, true), isHighlight }
                });
                const currentFromDate = moment(value.fromDate);
                const currentToDate = moment(value.toDate);
                const isValidDates = convertedData?.every(val => {
                    if (!val.Date) {
                        return true
                    }
                    const insideDate = moment(new Date(val.Date));
                    return insideDate.diff(currentFromDate, "days") >= 0 && currentToDate.diff(insideDate, "days") >= 0;
                })
                if (isValidDates) {
                    setExcelData({ ...data, data: convertedData ? convertedData : [] });
                }
                else {
                    handleCleardocument();
                    dispatch(userRequest.apiResponse({ show: true, status: 99999, header: "Warning", message: "Please ensure that all records are within the given period." }));
                }
            } else {
                setExcelData({ data: [], columns: timeInAndTimeOut.timeInAndTimeOutEmployeeHistory.uploadAuditPopup.columns });
                // setExcelSheets({ selected: "", options: [] });
            }
            setLoader(false);
        }
        catch (err) {
            console.error("Uploaded File Conversion failed, please check the uploaded file template", err);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [uploadDocument]);

    useEffect(() => {
        const getEmployeeCodes = async () => {
            if (fromDate && toDate && moment(fromDate).isValid() && moment(toDate).isValid()) {
                setLoader(true);
                await dispatch(timeInTimeOutRequest.getEmployeeCodeRequest({ fromDate: exportDateFormat(fromDate, true), toDate: exportDateFormat(toDate, true) }));
                setLoader(false);
            }
        }
        getEmployeeCodes();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [fromDate, toDate]);

    const excelSerialToDate = (serial, isTimeView) => {

        if (typeof serial !== 'number') {
            return serial && moment(serial).isValid() ? serial : '';
        } else {

            if (serial >= 60) serial -= 1; // Excel's leap year bug

            const days = Math.floor(serial);
            const timeFraction = serial - days;

            // Excel's base date: 1899-12-31
            const base = new Date(Date.UTC(1899, 11, 31));
            base.setUTCDate(base.getUTCDate() + days);

            // Manually add time
            const totalSeconds = Math.round(timeFraction * 86400); // seconds in the day
            const hours = String(Math.floor(totalSeconds / 3600)).padStart(2, '0');
            const minutes = String(Math.floor((totalSeconds % 3600) / 60)).padStart(2, '0');

            const year = base.getUTCFullYear();
            const month = String(base.getUTCMonth() + 1).padStart(2, '0');
            const day = String(base.getUTCDate()).padStart(2, '0');

            return isTimeView ? `${month}/${day}/${year} ${hours}:${minutes}` : `${month}/${day}/${year}`;
        }

    };

    // const onSheetChange = (params) => {
    //     const fileObj = uploadDocument[0];
    //     const workbook = XLSX.read(fileObj.binary, { type: "base64" });
    //     const excelSheetNames = workbook.SheetNames.map((val, idx) => ({ value: idx, label: val }))
    //     setExcelSheets({ selected: params, options: excelSheetNames });
    //     const sheetName = params.label;
    //     const worksheet = workbook.Sheets[sheetName];
    //     const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
    //     const data = timeInAndTimeOut.timeInAndTimeOutEmployeeHistory.uploadAuditPopup.convertFormattedRecords(jsonData);
    //     setExcelData({ ...data });
    // }

    const handleUpload = async () => {
        setLoader(true)
        const values = getValues();
        const payload = {
            fileImageBinary: uploadDocument && uploadDocument.length > 0 ? uploadDocument[0].binary : '',
            fileName: uploadDocument && uploadDocument.length > 0 ? uploadDocument[0].name : '',
            uploadedDate: exportDateFormat(new Date()),
            uploadedBy: userState.UserID,
            fromDate: values.fromDate ? exportDateFormat(values.fromDate) : '',
            toDate: values.toDate ? exportDateFormat(values.toDate) : '',
        }
        await dispatch(timeInTimeOutRequest.uploadTimeInOutRequest(setCallBack, payload));
        setLoader(false)
    }

    const setCallBack = (isValid) => {
        if (isValid) handleClose();
    }

    const handleClose = () => {
        dispatch(timeInTimeOutActions.setTimeInOutUploadDocument({ show: false }));
    }

    const onPeriodChange = (periodValue) => {
        if ((period && periodValue.value !== period.value) || !period) {
            setValue(strings.leaveRequestQueue.period, periodValue);
            periodDateFormat(periodValue, setValue);
            handleCleardocument();
        }
    }

    const fromDateChange = (date) => {
        if (!fromDate || (dateFormat(date) !== dateFormat(fromDate))) {
            if (period && period.label === strings.filterPeriod.custom && uploadDocument.length > 0) {
                handleCleardocument();
            }
            setValue(strings.timeInOutEmployeeHistory.fromDate, date);
        }
    }

    const toDateChange = (date) => {
        if (!toDate || (dateFormat(date) !== dateFormat(toDate))) {
            if (period && period.label === strings.filterPeriod.custom && uploadDocument.length > 0) {
                handleCleardocument();
            }
            setValue(strings.timeInOUtUPloadDocument.toDate, date);
        }
    }

    const handleCleardocument = () => {
        setExcelData({ data: [], columns: timeInAndTimeOut.timeInAndTimeOutEmployeeHistory.uploadAuditPopup.columns });
        dispatch(timeInTimeOutActions.setTimeInOutUploadDocument({ isValidRecord: true }));
        setUploadDocument([]);
    }

    useEffect(() => {
        return () => handleCleardocument();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const setRowStyle = params => {
        return { backgroundColor: ("isHighlight" in params.data) && params.data?.isHighlight ? timeInTimeOutUploadDocumentValidation.color : '#ffff' }
    };

    const handleUploadDocumentChange = (file) => {
        dispatch(timeInTimeOutActions.setTimeInOutUploadDocument({ isValidRecord: true }));
        setUploadDocument(file);
    }

    return (
        <ModelBox
            Component={
                <>
                    <div className=' max-h-93vh overflow-y-auto pb-4 overflow-x-hidden'>
                        <div className=" grid grid-cols-12 items-center gap-x-2 gap-y-5 mx-4 my-4">
                            <div className=" col-start-1 xl:col-end-3 lg:col-end-4 sm:col-end-5 xsm:col-end-12"> <Label label={"Period"} required /></div>
                            <div className=" xl:col-start-3 xl:col-end-5 lg:col-start-4 lg:col-end-7 sm:col-start-5 sm:col-end-9 xsm:col-start-1 xsm:col-end-13"><Dropdown placeholder={"Period"} isRequired options={periodOptions.filter(val => [2, 11, 0, 12].includes(val.value))} value={period} onChange={e => onPeriodChange(e)} /></div>
                            <div className=" xl:col-start-5 xl:col-end-7 lg:col-start-7 lg:col-end-10 sm:col-start-9 sm:col-end-13 xsm:col-start-1 xsm:col-end-13"><DatePickerElement placeholder='From' disabled={!(period && period.label === strings.filterPeriod.custom)} value={fromDate || ""} onChange={fromDateChange} isRequired={true} /></div>
                            <div className=" xl:col-start-7 xl:col-end-9 lg:col-start-10 lg:col-end-13 sm:col-start-5 sm:col-end-9 xsm:col-start-1 xsm:col-end-13"><DatePickerElement placeholder='To' disabled={!(period && period.label === strings.filterPeriod.custom)} value={toDate || ""} minDate={period && period.label === strings.filterPeriod.custom && watch(strings.timeInOUtUPloadDocument.fromDate)} onChange={toDateChange} isRequired={true} /></div>
                            <div className=" col-start-1 xl:col-end-3 lg:col-end-4 sm:col-end-5 xsm:col-end-12"> <Label label={"Upload Auditor Document"} required isDisable={watch(strings.timeInOUtUPloadDocument.fromDate) === '' || toDate === ''} /></div>
                            <div className=" xl:col-start-3 lg:col-start-4 sm:col-start-5 xsm:col-start-1 xl:col-end-7 lg:col-end-9 sm:col-end-10 xsm:col-end-13"><UploadAndDeleteDocument label={"Browse"} file={uploadDocument} onChange={handleUploadDocumentChange} fileType={{ 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': [], 'text/csv': [] }} isDisable={!(fromDate && toDate)} /></div>
                            {/* <div className=" lg:col-start-10 xsm:col-start-1  lg:col-end-13 sm:col-end-5 xsm:col-end-13">
                                <Dropdown isLabelView placeholder="Excel Sheets" value={excelSheets.selected} options={excelSheets.options} onChange={onSheetChange} isDisable={uploadDocument.length <= 0} />
                            </div> */}
                        </div>
                        <div className=" md:m-4 xsm:m-2 md:w-[95vw] sm:w-[97vw] xsm:w-[95vw] ">
                            <AgGrid columns={excelData.columns} data={excelData.data} height={" lg:h-72vh md:h-[63vh] xsm:h-[63vh]"} rowStyle={setRowStyle} />
                        </div>
                        <div className=' flex lg:justify-center xsm:justify-evenly items-center h-10 bg-white sticky z-10 bottom-0'>
                            <div className=" flex items-center justify-center">
                                <Button value={"Upload"} disabled={uploadDocument.length <= 0 || !timeInOutReducerState().timeInOutUploadDocument.isValidRecord} onClick={handleUpload} />
                                <span className=' mx-2 overflow-hidden h-full'><Button value="Close" onClick={handleClose} /></span>
                            </div>
                            {timeInOutReducerState().timeInOutUploadDocument.isValidRecord || <div className=" xsm:flex lg:absolute right-3 bottom-3 font-semibold">
                                <ColorLegend legendList={[{ color: timeInTimeOutUploadDocumentValidation.legendColor, name: timeInTimeOutUploadDocumentValidation.name }]} />
                            </div>}
                        </div>
                    </div>
                    {loader && <TransparentLoader isFullWidth={true} />}
                    {loginResponseState.apiResponse.show && <ApiResponse />}
                    {loginResponseState.imageViewer.show && <ImageViewer />}
                </>
            }
            headerTitle={'Time In / Out Upload Document'}
            open={show}
            onClose={handleClose}
        />
    );
};

const initialvalue = {
    period: '',
    fromDate: '',
    toDate: '',
}
export default TimeInOutUploadDocumentPopup;