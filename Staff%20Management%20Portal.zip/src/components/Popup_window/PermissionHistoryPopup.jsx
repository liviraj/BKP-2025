import { useDispatch, useSelector } from "react-redux";
import ModelBox from "../elements/ModelBox";
import { useForm } from "react-hook-form";
import { exportDateFormat, periodDateFormat, periodOptionsWithoutPayroll, leaveStatus } from "../helper";
import Dropdown from "../elements/Dropdown";
import DatePickerElement from "../elements/DatePickerElement";
import { strings } from "../Constants";
import { permissionAction } from "../../redux/permissionReducer";
import { useEffect } from "react";
import { permissionRequests } from "../requests";
import AgGrid from "../Grid/AgGrid";
import { permission } from "../Grid/Columns";
import Button from "../elements/Button";
import TransparentLoader from "../loader/TransparentLoader";

const PermissionHistoryPopup = () => {

    const dispatch = useDispatch()
    const { permissionHistoryPopup } = useSelector(state => state.permission);
    const { watch, setValue, getValues } = useForm({ defaultValues: initialValue });

    useEffect(() => {
        const componentDidMount = async () => {
            await dispatch(permissionAction.setPermissionHistoryPopup({ loader: true }))
            await dispatch(permissionAction.setPermissionHistoryPopup({ employeeName: (permissionHistoryPopup.rowData && Object.hasOwn(permissionHistoryPopup.rowData, "employeeName") && permissionHistoryPopup.rowData.employeeName) }))
            await onReset();
            dispatch(permissionAction.setPermissionHistoryPopup({ loader: false }))
        }
        componentDidMount();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const onReset = async () => {
        await dispatch(permissionAction.setPermissionHistoryPopup({ loader: true }));
        const rowdata = permissionHistoryPopup.rowData;
        await setValue(strings.leaveHistory.status, rowdata && Object.hasOwn(rowdata, "approvalStatus") ? leaveStatus.find(val => rowdata.approvalStatus === val.label) : leaveStatus[3]);
        await onPeriodChange(periodOptionsWithoutPayroll.find((val) => val.value === 4));
        await handleSearch();
        dispatch(permissionAction.setPermissionHistoryPopup({ loader: false }))
    }
    const handleSearch = async () => {
        await dispatch(permissionAction.setPermissionHistoryPopup({ loader: true }))
        const data = getValues();
        let filterRecords = { employeeId: permissionHistoryPopup.rowData && Object.hasOwn(permissionHistoryPopup.rowData, "employeeId") && permissionHistoryPopup.rowData.employeeId };
        const period = data.period;
        const employeeStatus = data.status;
        if (employeeStatus) {
            filterRecords = { ...filterRecords, status: employeeStatus.Key === leaveStatus[0].Key ? "All" : employeeStatus.Key }
        }
        if (period && period.label !== "All") {
            filterRecords = { ...filterRecords, fromTime: exportDateFormat(data.fromDate, true), toTime: exportDateFormat(data.toDate, true) }
        }
        await dispatch(permissionRequests.viewPermissionHistoryRequest(filterRecords));
        dispatch(permissionAction.setPermissionHistoryPopup({ loader: false }))
    }
    const onPeriodChange = (value) => {
        setValue(strings.permissionHistory.period, value);
        periodDateFormat(value, setValue);
    }
    const handleClose = () => {
        dispatch(permissionAction.setPermissionHistoryPopup({ data: [], show: false, rowData: [], loader: false, employeeName: "" }))
    }

    return (
        <ModelBox Component={<>
            <div className=' w-[80vw] md:w-[95vw] h-[calc(100vh-75px)] overflow-y-auto sm:w-screen xsm:w-screen p-4'>
                <div className='font-fontfamily font-bold text-headerColor tracking-wide'><span className='text-blackColor  text-15px'>Employee Name : </span><span className=' text-headerColor text-14px uppercase pl-1'>{permissionHistoryPopup.employeeName ? permissionHistoryPopup.employeeName : ''}</span></div>
                <div className='flex mb-6 md:mb-6 xsm:mb-4' >
                    <div className='grid grid-rows-1 md:grid-rows-1 sm:grid-rows-2 xsm:grid-rows-3 gap-x-4 gap-y-1 lg:grid-cols-5 md:grid-cols-3 sm:grid-cols-2 w-full'>
                        <div><Dropdown placeholder={"Period"} options={periodOptionsWithoutPayroll} value={watch(strings.permissionHistory.period)} onChange={e => onPeriodChange(e)} isLabelView={true} /></div>
                        <div><DatePickerElement placeholder='From' disabled={watch(strings.permissionHistory.period).label !== strings.filterPeriod.custom} value={watch(strings.permissionHistory.fromDate)} onChange={date => setValue(strings.permissionHistory.fromDate, date)} isRequired={true} isLabelView={true} /></div>
                        <div><DatePickerElement placeholder='To' disabled={watch(strings.permissionHistory.period).label !== strings.filterPeriod.custom} value={watch(strings.permissionHistory.toDate)} onChange={date => setValue(strings.permissionHistory.toDate, date)} minDate={watch(strings.permissionHistory.period).label === strings.filterPeriod.custom && watch(strings.permissionHistory.fromDate)} isRequired={true} isLabelView={true} /></div>
                        <div><Dropdown placeholder={"Status"} value={watch(strings.permissionHistory.status)} options={leaveStatus.filter(val => val.label !== leaveStatus[3].label)} onChange={e => setValue(strings.permissionHistory.status, e)} isLabelView={true} /></div>
                        <div className=' self-end flex'>
                            <Button value={strings.Buttons.Search} onClick={() => handleSearch()} disabled={watch(strings.permissionHistory.period).label === strings.filterPeriod.custom && (!watch(strings.permissionHistory.fromDate) || !watch(strings.permissionHistory.toDate))} />
                            <span className=' mx-3'> <Button value={strings.Buttons.Reset} onClick={() => onReset()} /></span>
                        </div>
                    </div>
                </div>
                <div>
                    <AgGrid data={permissionHistoryPopup.data} columns={permission.permissionHistory.columns()} height="h-[calc(94vh-67px-1.5rem-3.5rem-2rem)] lg:h-[calc(94vh-67px-1.5rem-3.5rem-2rem)] md:h-[calc(94vh-67px-67px-1.5rem-3.5rem-2rem)] xsm:h-[70vh]" />
                </div>
            </div>
            {permissionHistoryPopup.loader && <TransparentLoader isFullWidth={true} />}
        </>
        } headerTitle={"View Permission History"} open={permissionHistoryPopup.show} onClose={handleClose} />
    );
};

const initialValue = {
    period: "",
    fromDate: "",
    toDate: "",
    status: ""
}

export default PermissionHistoryPopup;