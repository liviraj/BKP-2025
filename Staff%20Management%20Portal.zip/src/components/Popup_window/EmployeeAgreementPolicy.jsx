import ModelBox from '../elements/ModelBox';
import { useDispatch, useSelector } from 'react-redux';
import { ComplianceAgreementActions } from '../../redux/ComplianceAgreementReducer';
import { complianceAgreementReducerState, dateFormat, exportDateFormat, exportYearFormat } from '../helper';
import CheckBox from '../elements/CheckBox';
import Button from '../elements/Button';
import { useEffect, useState } from 'react';
import TransparentLoader from '../loader/TransparentLoader';
import ApiResponse from '../Alert/ApiResponse';
import { strings } from '../Constants';
import { documentPolicyRequest } from '../requests';
import { BiSave } from 'react-icons/bi';
import { SiTicktick } from 'react-icons/si';
import { IoClose } from 'react-icons/io5';
import Loader from '../loader/Loader';
import PdfViewer from '../elements/PdfViewer';

export default function EmployeeAgreementPolicy() {

    const { employeeagreementPolicyPopup, loader, employeeAgreementPolicy } = useSelector(state => state.complianceAgreement);
    const dispatch = useDispatch();
    const userState = useSelector(state => state.user);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const [agree, setAgree] = useState(false);
    const [employeeName, setEmployeeName] = useState("");

    const onClose = () => {
        dispatch(ComplianceAgreementActions.reSetEmployeeagreementPolicyPopup());
    }

    useEffect(() => {
        const initialState = async () => {
            dispatch(ComplianceAgreementActions.setLoader(true));
            setEmployeeName(`${userState.FName}${userState.MName ? " " + userState.MName : ""}${userState.LName ? " " + userState.LName : ""}`);
            const params = {
                documentId: employeeAgreementPolicy.currentPolicyId,
                employeeId: userState.UserID
            }
            await dispatch(documentPolicyRequest.employeeAgreementPolicyRequest.getEmployeeAgreementPolicyRequest(params));
            dispatch(ComplianceAgreementActions.setLoader(false));
        }
        initialState();
        return () => {
            dispatch(ComplianceAgreementActions.resetEmployeeAgreementPolicy());
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const handleSubmit = async () => {
        dispatch(ComplianceAgreementActions.setLoader(true));
        const params = {
            date: exportDateFormat(new Date()),
            employeeSignature: employeeName || '',
            documentId: employeeAgreementPolicy.currentPolicyData ? employeeAgreementPolicy.currentPolicyData.policyDetailId : 0,
            reviewedEmpId: userState.UserID
        }
        await dispatch(documentPolicyRequest.sendEmployeeAgreementPolicyRequest(params, setCallBack));
        dispatch(ComplianceAgreementActions.setLoader(false));
    }

    const setCallBack = async () => {
        dispatch(ComplianceAgreementActions.setLoader(true));
        setAgree(false);
        const data = employeeAgreementPolicy.policyData;
        dispatch(ComplianceAgreementActions.setEmployeeAgreementPolicy({ policyData: data.length > 0 ? data.slice(1, 2) : [], currentPolicyData: data.length > 1 ? data.slice(1, 3)[0] : {} }));
        dispatch(documentPolicyRequest.policyData.getNotificationRequest(userState.UserID));
        let params = {
            dueDate: exportYearFormat(new Date()),
            employeeId: userState.UserID
        }
        await dispatch(documentPolicyRequest.complianceDocumenyHistory.getHistoryDocument(params));
        onClose();
        dispatch(ComplianceAgreementActions.setLoader(false));
    }

    return (
        <div>
            <ModelBox Component={
                <>
                    <div className=" px-6 bg-[#f2f2f2]  font-fontfamily tracking-tighter pb-5 w-screen   h-[98vh]  overflow-auto">
                        <div className=" flex sm:items-center items-start justify-between sm:flex-row flex-row py-2 sm:py-4 ">
                            <h3 className="text-headerColor font-fontfamily font-bold tracking-wide flex justify-between">{complianceAgreementReducerState().employeeAgreementPolicy.currentPolicyData?.documentTitle}</h3>
                            <span className={' cursor-pointer'} >
                                <IoClose size={22} style={{ strokeWidth: "10px" }} onClick={onClose} />
                            </span>
                        </div>
                        <div className=" grid">

                            <div className="col-start-1 xl:col-end-11 lg:col-end-8 col-end-13 lg:mr-3 bg-white shadow-md border border-gray-300 xl:p-5 xl:pb-3 p-4 overflow-auto rounded-md  h-full order-2 lg:order-1">
                                {complianceAgreementReducerState().employeeAgreementPolicy.currentPolicyData && Object.keys(complianceAgreementReducerState().employeeAgreementPolicy.currentPolicyData).length > 0 ? (
                                    <>
                                        <div className=" xsm:h-[40vh] lg:h-[calc(100vh-20rem)] xl:h-[calc(100vh-17rem)] max-w-full overflow-auto"><PdfViewer PdfViewerData={complianceAgreementReducerState().employeeAgreementPolicy.currentPolicyData.documentImage} isRemoveHeader /></div>
                                        <div className=" mt-3 flex justify-between xl:items-center items-baseline xl:flex-row flex-col">
                                            <CheckBox data={[{ label: "I read, acknowledge and accept to the terms and conditions or information in the document" }]} value={agree} onChange={e => setAgree(e.target.checked)} />
                                            <div className=" text-15px font-bold tracking-wide ">  <span>Confirmed by : </span><span className=' text-textOrangeHighlight'>{employeeName}</span></div>
                                        </div>
                                        <div className=" flex justify-center items-center">
                                            <div className={`${!agree || employeeName.length <= 0 ? ' opacity-70 !cursor-not-allowed' : ''} bg-headerColor text-white py-2 pl-3 rounded-l-sm pr-0 text-md`}><BiSave /></div>
                                            <Button value={strings.Buttons.Save} disabled={!agree || employeeName.length <= 0} addStyle={' rounded-l-none pl-2'} onClick={handleSubmit} />
                                        </div>
                                    </>
                                ) : <p className=' font-fontfamily font-semibold text-base flex justify-center items-center w-full text-center h-full'><Loader isFullHeight /></p>}
                            </div>
                            <div className="xl:col-start-11 lg:col-start-8 col-start-1 col-end-13 order-1 lg:order-2 mb-3 ">
                                <div className=" min-w-[14.5rem]"> {complianceAgreementReducerState().employeeAgreementPolicy.currentPolicyData && Object.keys(complianceAgreementReducerState().employeeAgreementPolicy.currentPolicyData).length > 0 && <div className=" flex justify-start px-5 py-2 bg-white items-center  rounded-md shadow-md border border-gray-300"><div className=" w-7 h-7"><SiTicktick className={` w-full h-full  ${Object.keys(complianceAgreementReducerState().employeeAgreementPolicy.currentPolicyData).length > 0 ? 'text-orange-400' : 'text-green-400'}`} /></div><div className=" pl-5"> <p className=" font-semibold">Status</p><p className=" font-bold text-[20px]">{Object.keys(complianceAgreementReducerState().employeeAgreementPolicy.currentPolicyData).length > 0 ? 'Pending' : 'Completed'}</p></div></div>}
                                    {complianceAgreementReducerState().employeeAgreementPolicy.currentPolicyData && Object.keys(complianceAgreementReducerState().employeeAgreementPolicy.currentPolicyData).length > 0 && <div className="  px-5 py-2 bg-white   rounded-md shadow-md mt-4 text-16px border border-gray-300"><h3 className=" font-extrabold text-[20px]">Details</h3>
                                        <p className=" text-14px">Assignees</p>
                                        <p className=" mb-2 text-17px font-bold text-gray-700">{complianceAgreementReducerState().employeeAgreementPolicy.currentPolicyData.assigneeName}</p>
                                        <p className=" text-14px">Assigned Date</p>
                                        <p className=" text-17px font-bold text-gray-700 mb-2 ">{dateFormat(complianceAgreementReducerState().employeeAgreementPolicy.currentPolicyData.assignedDate)}</p>
                                        {/* <p className=" text-14px">Due Date</p>
                                        <p className="text-17px font-bold text-gray-700">{dateFormat(complianceAgreementReducerState().employeeAgreementPolicy.currentPolicyData.dueDate)}</p> */}
                                    </div>}</div>
                            </div>
                        </div>
                    </div>
                    {loader && <TransparentLoader isFullWidth />}
                    {apiResponseState.show && <ApiResponse />}
                </>
            } open={employeeagreementPolicyPopup.show} onClose={onClose} isHideHeader />
        </div>
    )
}
