import { useEffect, useMemo, useState } from 'react'
import ModelBox from '../elements/ModelBox'
import { useDispatch, useSelector } from 'react-redux'
import TextField from '../elements/TextField'
import { BiSearch } from 'react-icons/bi'
import CheckboxTree from '../elements/customCheckbox'
import { documentPolicyRequest, eventManagementRequests } from '../requests'
import { collectKeys, exportDateFormat, getCheckedValues, findAllChildCheckedParent, findCheckedKeys, findCheckedValues, findParents, getChildKeys, policyOptions, treeDataFormation, userReducerState, getTreeKeys } from '../helper'
import TransparentLoader from '../loader/TransparentLoader'
import Button from '../elements/Button'
import { ComplianceAgreementActions } from '../../redux/ComplianceAgreementReducer'
import moment from 'moment-timezone'
import { useForm } from 'react-hook-form'
import { setDefaultValue, strings } from '../Constants'
import SubHeaderSection from '../layouts/SubHeaderSection'
import PropTypes from 'prop-types'

export default function AssignmentDocumentPopup({ handleSearch }) {
    const { selectedUser, availableUser, agreementDocmentPopup } = useSelector(state => state.complianceAgreement.agreementDocument);
    const { setValue } = useForm({ defaultValues: initialState });
    const userDetails = useSelector(state => state.user);
    const dispatch = useDispatch();
    const [searchAvailableUser, setSearchAvailableUser] = useState("");
    const getSelectedRow = agreementDocmentPopup.selectedRow;
    const [disableCheckedKeys, setDisableCheckedKeys] = useState([]);
    const [previousCheckedKeys, setPreviousCheckedKeys] = useState({
        parentCheckedKeys: [],
        childCheckedKeys: []
    });
    const [currentCheckedKeys, setCurrentCheckedKeys] = useState({
        parentCheckedKeys: [],
        childCheckedKeys: []
    });
    const [loader, setLoader] = useState(true);

    useEffect(() => {
        const initialLoad = async () => {
            setLoader(true);
            await dispatch(eventManagementRequests.recordEvents.getEventEmployeeName(availableUserStaffTree));
            setLoader(false);
        };
        initialLoad();
        return () => {
            dispatch(ComplianceAgreementActions.reSetAgreementDocument());
        };

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        const fetchData = async () => {
            if (agreementDocmentPopup.action === "edit") {
                setValue(strings.assignDocument.dueDate, getSelectedRow.dueDate);
                setValue(strings.assignDocument.period, policyOptions.find((val) => val.value === getSelectedRow?.documentPeriod));
                setValue(strings.assignDocument.documentFromDate, getSelectedRow.documentValidityStartDate);
                setValue(strings.assignDocument.documentToDate, getSelectedRow.documentValidityEndDate);
                if (availableUser.treeData?.length > 0) {
                    //pendingEmployee
                    const pendingEmployeeCheckedKeys = getSelectedRow.pendingEmployeeId && getSelectedRow.pendingEmployeeId.length > 0 && availableUser.treeData.length > 0 ? findCheckedKeys(availableUser.treeData, getSelectedRow.pendingEmployeeId.map(val => ({ employeeId: val }))) : [];
                    const pendingEmployeeParentkeys = availableUser.treeData?.length > 0 && findParents(availableUser.treeData, pendingEmployeeCheckedKeys);
                    //completedEmployee
                    const completedEmployeeKeys = getSelectedRow.completedEmployeeId && getSelectedRow.completedEmployeeId.length > 0 && availableUser.treeData.length > 0 ? findCheckedKeys(availableUser.treeData, getSelectedRow.completedEmployeeId.map(val => ({ employeeId: val }))) : [];
                    const completedEmployeeKeysParentkeys = availableUser.treeData?.length > 0 && findParents(availableUser.treeData, completedEmployeeKeys);
                    setDisableCheckedKeys(completedEmployeeKeys);
                    const overAllEmployeeCheckedKeys = [...completedEmployeeKeys, ...pendingEmployeeCheckedKeys];
                    const overAllParentEmployeeCheckedKeys = [...completedEmployeeKeysParentkeys, ...pendingEmployeeParentkeys];
                    setPreviousCheckedKeys({
                        ...previousCheckedKeys,
                        parentCheckedKeys: overAllParentEmployeeCheckedKeys,
                        childCheckedKeys: overAllEmployeeCheckedKeys
                    });
                    setCurrentCheckedKeys({
                        ...currentCheckedKeys,
                        parentCheckedKeys: overAllParentEmployeeCheckedKeys,
                        childCheckedKeys: overAllEmployeeCheckedKeys
                    })
                    dispatch(ComplianceAgreementActions.setAvailableUser({ checkedKeys: overAllEmployeeCheckedKeys, expandedKeys: overAllParentEmployeeCheckedKeys }));
                    if (availableUser?.treeData.length > 0 && overAllEmployeeCheckedKeys?.length > 0) {

                        dispatch(ComplianceAgreementActions.setSelectedUser({ treeData: getCheckedValues(availableUser.treeData, overAllEmployeeCheckedKeys), checkedKeys: overAllEmployeeCheckedKeys, expandedKeys: overAllParentEmployeeCheckedKeys }));
                    } else {
                        setDisableCheckedKeys([]);
                        dispatch(ComplianceAgreementActions.setSelectedUser({ treeData: [], checkedKeys: [], expandedKeys: [] }));
                    }
                }
            } else {
                const { allKeys, parentKeys } = getTreeKeys(availableUser.treeData);
                setPreviousCheckedKeys({
                    ...previousCheckedKeys,
                    parentCheckedKeys: parentKeys,
                    childCheckedKeys: allKeys
                });
                setCurrentCheckedKeys({
                    ...currentCheckedKeys,
                    parentCheckedKeys: parentKeys,
                    childCheckedKeys: allKeys
                })
                dispatch(ComplianceAgreementActions.setAvailableUser({ checkedKeys: allKeys, expandedKeys: parentKeys }));
                dispatch(ComplianceAgreementActions.setSelectedUser({ treeData: availableUser.treeData, checkedKeys: allKeys, expandedKeys: parentKeys }));
                setValue(strings.assignDocument.dueDate, new Date(moment().add(10, 'days').startOf('day')))
            }
        }
        fetchData();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [availableUser.treeData, agreementDocmentPopup.action])

    useEffect(() => {
        if (searchAvailableUser) {
            let keys = collectKeys(availableUser.treeData && availableUser.treeData.length > 0 ? availableUser.treeData : [], (searchAvailableUser && searchAvailableUser.length > 0) ? searchAvailableUser : "", availableUser.treeData && availableUser.treeData.length > 0 ? availableUser.treeData : []);
            dispatch(ComplianceAgreementActions.setAvailableUser({ expandedKeys: keys, autoExpandParent: true, searchExpandedKeys: keys }));
        }
        else {
            dispatch(ComplianceAgreementActions.setAvailableUser({ expandedKeys: [], autoExpandParent: false, searchExpandedKeys: [] }));
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [searchAvailableUser]);


    const availableUserStaffTree = async (treeData) => {
        const getLocationName = getSelectedRow.locationId === setDefaultValue.location.value ? setDefaultValue.location.label : setDefaultValue.usLocation.label;
        const filteredData = getLocationName && treeData?.length > 0 ? treeData.find(item => item.country === getLocationName) : {};
        const treeStructure = async (usIndex) => {
            return [{
                key: usIndex,
                title: getLocationName,
                children: Object.hasOwn(filteredData, "departments") && filteredData?.departments?.length && await treeDataFormation(filteredData, usIndex)
            }];
        }
        dispatch(ComplianceAgreementActions.setAvailableUser({ treeData: await treeStructure(0), }));
    }

    const handleSaveAndNotify = async () => {
        setLoader(true);
        const selectesUser = findCheckedValues(availableUser.treeData, availableUser.checkedKeys, '', [])
        const params = {
            assignedBy: userReducerState().UserID,
            assignedDate: exportDateFormat(new Date()),
            documentId: agreementDocmentPopup.selectedRow.documentId,
            employeeId: selectesUser?.length > 0 ? selectesUser.map(item => item.employeeId) : [],
            isNotify: false,
            isReviewed: false
            // dueDate: exportDateFormat(localState.dueDate, true),
            // documentValidFromDate: exportDateFormat(localState.documentFromDate, true),
            // documentValidToDate: exportDateFormat(localState.documentToDate, true),
        }
        if (agreementDocmentPopup.action === "edit" && !isButtonEnable) {
            // eslint-disable-next-line no-unused-vars
            const { documentId, ...updatedParams } = params;
            const modifiedParams = { ...updatedParams, modifiedBy: userDetails.UserID, modifiedDate: exportDateFormat(new Date()), documentId: getSelectedRow.documentId }
            await dispatch(documentPolicyRequest.complianceAgreement.updatePolicyAssignDocument(modifiedParams, setCallBack));
        } else if (agreementDocmentPopup.action === "add") {
            await dispatch(documentPolicyRequest.complianceAgreement.policyAssignDocument(params, setCallBack));
        }
        // else {
        //     const params = {
        //         documentId: agreementDocmentPopup.selectedRow.documentId,
        //         dueDate: exportDateFormat(localState.dueDate)
        //     }
        //     await dispatch(documentPolicyRequest.policyData.getPolicyDataRequest(true, params, setCallBack));
        // }
        setLoader(false);
    }

    const setCallBack = async () => {
        setLoader(true);
        onClose();
        handleSearch && await handleSearch();
        dispatch(documentPolicyRequest.policyData.getNotificationRequest(userDetails.UserID));
        setLoader(false);
    }

    const onAvailableUserCheck = async (checkedKeysValue) => {
        const overAllCheckedValue = [...checkedKeysValue, ...disableCheckedKeys];
        dispatch(ComplianceAgreementActions.setAvailableUser({ checkedKeys: overAllCheckedValue }));
        const selecteData = findCheckedValues(availableUser.treeData, overAllCheckedValue, "", []);
        const availableUserCheckedKeys = selecteData && selecteData.length > 0 && availableUser.treeData.length > 0 ? findCheckedKeys(availableUser.treeData, selecteData) : [];
        const availableUserParentkeys = availableUser.treeData?.length > 0 && findParents(availableUser.treeData, availableUserCheckedKeys);
        setCurrentCheckedKeys({
            ...currentCheckedKeys,
            parentCheckedKeys: availableUserParentkeys,
            childCheckedKeys: availableUserCheckedKeys
        })
        if (availableUser?.treeData.length > 0 && overAllCheckedValue?.length > 0) {
            dispatch(ComplianceAgreementActions.setSelectedUser({ treeData: getCheckedValues(availableUser.treeData, overAllCheckedValue), checkedKeys: overAllCheckedValue, expandedKeys: availableUserParentkeys }));
        } else {
            dispatch(ComplianceAgreementActions.setSelectedUser({ treeData: [], checkedKeys: [], expandedKeys: [] }));
        }
    };

    const filterTreeNode = (node) => {
        if (searchAvailableUser && searchAvailableUser.length > 0 && node && node.title.props.children.toLocaleLowerCase().indexOf(searchAvailableUser.toLocaleLowerCase()) > -1) { return true; }
    };


    const onExpandAvailableUser = (newExpandedKeys) => {
        dispatch(ComplianceAgreementActions.setAvailableUser({ expandedKeys: newExpandedKeys, autoExpandParent: false }));
    }
    const onExpandSelectedUsers = (newExpandedKeys) => {
        dispatch(ComplianceAgreementActions.setSelectedUser({ expandedKeys: newExpandedKeys }));
    }

    const onClose = () => {
        dispatch(ComplianceAgreementActions.reSetAgreementDocument());
    }

    const handleAvailableUserTitle = async (key) => {
        const { treeData, checkedKeys } = availableUser;
        let newCheckedKeys = [];
        const childKeys = getChildKeys(treeData, key);
        if (checkedKeys.includes(key)) {
            let parentKey = findParents(treeData, [key]);
            newCheckedKeys = checkedKeys.filter(item => item !== key && !childKeys.includes(item) && !parentKey.includes(item));
        } else {
            let parentKey = findParents(treeData, [key]);
            let CheckedKeys = [...checkedKeys, key, ...childKeys];
            newCheckedKeys = [...CheckedKeys, ...findAllChildCheckedParent(treeData, parentKey, CheckedKeys)];
        }
        const overAllLabelCheckedValue = [...newCheckedKeys, ...disableCheckedKeys]
        dispatch(ComplianceAgreementActions.setAvailableUser({ checkedKeys: overAllLabelCheckedValue }));
        const selecteData = [...findCheckedValues(treeData, overAllLabelCheckedValue, "", [])];
        const availableUserCheckedKeys = selecteData?.length > 0 && treeData?.length > 0 ? findCheckedKeys(treeData, selecteData) : [];
        const availableUserParentKeys = treeData?.length > 0 ? findParents(treeData, availableUserCheckedKeys) : [];
        setCurrentCheckedKeys({
            ...currentCheckedKeys,
            parentCheckedKeys: availableUserParentKeys,
            childCheckedKeys: availableUserCheckedKeys
        })
        if (treeData?.length > 0) {
            dispatch(ComplianceAgreementActions.setSelectedUser({ treeData: getCheckedValues(treeData, overAllLabelCheckedValue), checkedKeys: overAllLabelCheckedValue, expandedKeys: availableUserParentKeys }));
        } else {
            dispatch(ComplianceAgreementActions.setSelectedUser({ treeData: [], checkedKeys: [], expandedKeys: [] }));
        }
    };

    const isButtonEnable = useMemo(() => {
        const isValid = false;
        if (agreementDocmentPopup.action === 'edit') {
            return JSON.stringify(currentCheckedKeys.childCheckedKeys) === JSON.stringify(previousCheckedKeys.childCheckedKeys);
        }
        return isValid;
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [agreementDocmentPopup.action, previousCheckedKeys.childCheckedKeys, currentCheckedKeys.childCheckedKeys]);


    return (
        <ModelBox headerTitle={"Assignment "} open={agreementDocmentPopup.show}
            Component={
                <>
                    <div className={` xsm:w-[90vw] lg:w-[65rem] w-[90vw] h-[calc(100vh-75px)] overflow-y-auto  sm:px-8 xsm:px-4 bg-white `}>
                        <SubHeaderSection subHeader={`${agreementDocmentPopup.selectedRow.documentTitle}`} addtextStyle={"!text-black"} />
                        {/* <div className='grid grid-cols-12 gap-x-5 gap-y-2 lg:gap-y-3 xl:gap-x-3'>
                            <span className={"col-start-1 col-end-7 sm:col-end-4 lg:col-end-3 xl:col-end-3  flex items-center justify-between "}><Label label={"Due Date"} required /></span>
                            <span className={"col-start-1 col-end-13 sm:col-start-4 sm:col-end-8 lg:col-start-3 xl:col-start-3 lg:col-end-6 xl:col-end-6 "}><DatePickerElement value={dueDate} isRequired onChange={(e) => setValue(strings.assignDocument.dueDate, e)} isWeekday /></span>
                            <span className={"col-start-1 col-end-7 sm:col-end-4  lg:col-start-7 lg:col-end-9  xl:col-start-7 xl:col-end-9  flex items-center justify-between "}><Label label={"Period"} required /></span>
                            <span className={"col-start-1 col-end-13  sm:col-start-4 sm:col-end-8 lg:col-start-9 lg:col-end-12 xl:col-start-9 xl:col-end-12 "}> <Dropdown options={policyOptions} value={period} onChange={e => onPolicyPeriodChange(e, dueDate)} isRequired />
                            </span>
                        </div> */}
                        <div className=" w-full  justify-center gap-1 lg:gap-5 block lg:flex  lg:border-t lg:border-b border-[#808080] max-w-full mt-5   lg:h-[calc(100vh-18rem)]  lg:overflow-hidden">
                            <div className={AssignClass.treeParentClass}>
                                <div className={AssignClass.usersClass}>Available Employees</div>
                                <div className={AssignClass.searchBoxParentClass}>
                                    <TextField value={searchAvailableUser} placeholder="search" type="text" onChange={(e) => setSearchAvailableUser(e.target.value)} /> <BiSearch className=' absolute right-3 top-4' />
                                </div>
                                <div className={AssignClass.treeClass}>
                                    {availableUser.treeData && availableUser.treeData.length > 0 ?
                                        <div className={searchAvailableUser ? "checkboxSearch" : ""}> <CheckboxTree disableCheckedKeys={disableCheckedKeys} className={"disable"} onCheck={onAvailableUserCheck} searchValue={searchAvailableUser} treeData={availableUser.treeData} checkedKeys={availableUser.checkedKeys} expandedKeys={availableUser.expandedKeys} autoExpandParent={availableUser.autoExpandParent} filterTreeNode={filterTreeNode} onExpand={onExpandAvailableUser} searchExpandedKeys={availableUser.searchExpandedKeys} handleTitle={handleAvailableUserTitle} /></div> : <p className=' font-fontfamily font-semibold text-base  w-full text-center'>No Staff</p>}
                                </div>
                            </div>
                            <div className="w-[1px] bg-[#808080]  xsm:hidden sm:block "></div>
                            <div className={AssignClass.treeParentClass} >
                                <div className={AssignClass.usersClass}>Selected Employees</div>
                                <div className={`flex flex-wrap overflow-auto border-coolGray-900 p-3 h-full sm:max-h-[calc(100%-2.5rem)] selected-user`} >
                                    {selectedUser.treeData && selectedUser.treeData.length > 0 ?
                                        <CheckboxTree treeData={selectedUser.treeData} checkedKeys={selectedUser.checkedKeys} expandedKeys={selectedUser.expandedKeys} searchExpandedKeys={[]} onExpand={onExpandSelectedUsers} isDisable /> : <p className=' font-fontfamily font-semibold text-base  w-full text-center'>No Selected User</p>}
                                </div>
                            </div>
                        </div>
                        <footer className={`flex flex-wrap gap-4 justify-center mt-7  sticky z-0 bottom-0 bg-white  sm:pb-4 md:pb-0 xsm:pb-2`}>
                            <Button value={`Save & Notify`} disabled={(selectedUser.treeData.length <= 0 || isButtonEnable)} onClick={() => handleSaveAndNotify()} />
                            <Button value={"Close"} onClick={onClose} />
                        </footer>
                    </div>
                    {loader && <TransparentLoader isFullWidth />}
                </>
            } onClose={onClose} />
    )
}

const AssignClass = {
    usersClass: "!border-borderThemeColor !bg-themeBgColor mb-2 rounded font-semibold px-3 py-1 flex items-center",
    treeClass: "flex flex-wrap overflow-auto border-coolGray-900 p-3 h-full sm:max-h-[calc(100%-4.9rem)]",
    treeParentClass: "w-full  lg:w-1/2 my-2",
    searchBoxParentClass: "sticky top-0 z-[1] w-full border-coolGray-900 participant_search rounded-none"
}



const initialState = {
    dueDate: "",
    documentFromDate: "",
    documentToDate: "",
    period: "",
    isNoExpiry: "",
}

AssignmentDocumentPopup.propTypes = {
    handleSearch: PropTypes.func
}