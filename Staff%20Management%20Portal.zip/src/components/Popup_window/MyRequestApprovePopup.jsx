import PropTypes from 'prop-types';
import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { myRequestActions } from '../../redux/myRequestReducer';
import Label from '../elements/Label';
import ModelBox from '../elements/ModelBox';
import { useForm } from 'react-hook-form';
import { ViewComponentDesign, dateFormat, exportDateFormat, leaveStatus, userReducerState } from '../helper';
import TextArea from '../elements/TextArea';
import Button from '../elements/Button';
import { employeeRequests, myRequestRequests } from '../requests';
import { strings } from '../Constants';
import LinkView from '../elements/LinkView';
import TransparentLoader from '../loader/TransparentLoader';

function MyRequestApprovePopup({ onSubmit }) {
    const approvepopupState = useSelector(state => state.myRequest.approvePopup);
    const dispatch = useDispatch();
    const { watch, setValue, getValues } = useForm({ defaultValues });

    useEffect(() => {
        const selectedRow = approvepopupState.selectedRow;
        if (Object.keys(selectedRow).length > 0) {
            if ("employeeName" in selectedRow) {
                setValue("empName", selectedRow.employeeName);
            }
            if ("createdDate" in selectedRow) {
                setValue("date", selectedRow.createdDate);
            }
            if ("request" in selectedRow) {
                setValue("requestType", selectedRow.request);
            }
            if ("comments" in selectedRow) {
                setValue("comments", selectedRow.comments ? selectedRow.comments : "");
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const onClose = async () => {
        await dispatch(myRequestActions.setApprovePopup({ show: false, selectedRow: {}, actions: "", loader: false }));
    }
    const onConfirm = async (type) => {
        await onClose();
        await dispatch(myRequestActions.setLoader(true));
        const data = getValues();
        const selectedRow = approvepopupState.selectedRow;
        const params = {
            comments: data.comments,
            requestId: ("requestId" in selectedRow) ? selectedRow.requestId : 0,
            requestStatus: type === "Approve" ? leaveStatus[1].Key : leaveStatus[2].Key,
            reviewedBy: userReducerState().UserID,
            reviewedOn: exportDateFormat(new Date())
        }
        await dispatch(myRequestRequests.approveRequests(params));
        await onSubmit();
        dispatch(myRequestActions.setLoader(false));
    }

    const onhandleDocument = async () => {
        await dispatch(myRequestActions.setApprovePopup({ ...approvepopupState, loader: true }));
        await dispatch(employeeRequests.getEmployeeDocument("employeeDetails/requestDocument", ("requestId" in approvepopupState.selectedRow) ? approvepopupState.selectedRow.requestId : 0));
        dispatch(myRequestActions.setApprovePopup({ ...approvepopupState, loader: false }));
    }

    return (
        <div>
            <ModelBox onClose={onClose}
                open={approvepopupState.show}
                headerTitle={`${approvepopupState.actions} Request`} Component={
                    <div>
                        <div className=' w-96 md:w-96 sm:w-[90vw] xsm:w-[90vw] mx-4 my-3 tracking-wide'>
                            <div className=' grid grid-cols-12'>
                                <ViewComponentDesign label={"Employee Name"} value={watch("empName")} valueAddStyle="text-headerColor" />
                                <ViewComponentDesign label={"Date of Request"} value={dateFormat(watch("date"))} />
                                <ViewComponentDesign label={"Type of Request"} value={watch("requestType")} />
                                {approvepopupState.actions === "View" && <ViewComponentDesign label={"Status"} value={"requestStatus" in approvepopupState.selectedRow ? approvepopupState.selectedRow.requestStatus : ""} />}
                                {("imageName" in approvepopupState.selectedRow) && approvepopupState.selectedRow.imageName && approvepopupState.selectedRow.imageName.length > 0 && <>
                                    <div className=' col-start-1 col-end-5 md:col-end-5 xms:col-end-6 mt-[2.5px]'>
                                        <Label label={"Uploaded File"} setBold={true} />
                                    </div>
                                    <div className=' col-start-5 md:col-start-5 xsm:col-start-6 col-end-13'>
                                        <div className=' flex gap-x-2'>:<span className=' mt-[2.5px] text-14px'><LinkView addStyle={"text-left"} value={approvepopupState.selectedRow.imageName} onClick={onhandleDocument} /></span></div>
                                    </div>
                                </>}
                                <ViewComponentDesign label={"Comments"} value={approvepopupState.actions === "View" ? watch("comments") : ""} />
                                {approvepopupState.actions !== "View" && <div className='col-start-1 col-end-13'><TextArea value={watch("comments")} onChange={e => setValue("comments", e.target.value)} height={"h-20 text-13px tracking-normal"} /></div>}
                            </div>
                            <div className=' flex justify-center gap-x-3'>
                                {approvepopupState.actions !== "View" && <Button value={approvepopupState.actions} onClick={() => onConfirm(approvepopupState.actions)} />}
                                <Button value={strings.Buttons.Close} onClick={onClose} />
                            </div>
                        </div>
                        {approvepopupState.loader && <TransparentLoader isFullWidth={true} />}
                    </div>
                }
            />
        </div>
    )
}

export default MyRequestApprovePopup

MyRequestApprovePopup.propTypes = {
    onSubmit: PropTypes.func
}



const defaultValues = {
    empName: "",
    date: "",
    requestType: "",
    comments: ""
}