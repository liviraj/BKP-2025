import { useDispatch, useSelector } from "react-redux";
import { timeInTimeOutActions } from "../../redux/TimeInTimeOutReducer";
import Label from "../elements/Label";
import GreySubHeader from "../layouts/GreySubHeader";
import AgGrid from "../Grid/AgGrid";
import { timeInAndTimeOut } from "../Grid/Columns";
import { useEffect, useState } from "react";
import { dateFormat } from "../helper";
import DraggableModal from "../elements/DraggableModal";
import Button from "../elements/Button";
import { strings } from "../Constants";


function ViewMissOutPunches() {

    const dispatch = useDispatch();
    const viewMissOutPunchesState = useSelector(state => state.timeInTimeOut.viewMissOutPunches);
    const [leaveHistoryData, setLeaveHistoryData] = useState([]);
    const [timeinOut, setTimeinOut] = useState([]);
    const [pinnedData, setPinnedData] = useState([]);

    useEffect(() => {
        const initialLoad = async () => {
            if (Object.keys(viewMissOutPunchesState.data).length > 0) {
                if ("timeInOutDetails" in viewMissOutPunchesState.data) {
                    setTimeinOut(viewMissOutPunchesState.data["timeInOutDetails"]);
                }
                if ('totalHours' in viewMissOutPunchesState.data && viewMissOutPunchesState.data.totalHours.length > 0) {
                    await setPinnedData([{ ...viewMissOutPunchesState.data.totalHours[0], timeIn1: 'Total' }]);
                }
                if ("leaveHistory" in viewMissOutPunchesState.data) {
                    setLeaveHistoryData(viewMissOutPunchesState.data["leaveHistory"]);
                }
            }
        }
        initialLoad();
    }, [viewMissOutPunchesState]);

    const onClose = () => {
        dispatch(timeInTimeOutActions.viewMissOutPunches({ show: false, selectedRow: {}, data: {} }));
    }

    const setRowStyle = params => {
        if (params.node?.rowPinned || params.data?.workDate) {
            return { backgroundColor: params.data?.dateCategory === strings.type.holiday ? "#edffeb" : '#ffff' };
        }
        return { backgroundColor: "#ffe9df" };
    };

    return (
        <DraggableModal
            onClose={onClose}
            headerTitle={`View`}
            Component={<div className=" h-auto max-h-[92vh] sm:w-[93rem] xsm:w-screen/90 ">
                <div className=" px-6">
                    <div className=" grid grid-cols-12 items-center sm:gap-y-1 gap-x-2 lg:w-[50rem] xsm:w-full" >
                        <div className=" col-start-1 sm:col-end-3 xsm:col-end-12 text-15px flex justify-between"><Label label={`Employee Name`} setBold /><span className=" font-bold">:</span></div>
                        <div className=" sm:col-start-3 xsm:col-start-1 col-end-12">  <span className='font-bold text-headerColor text-14px uppercase ml-1'>{viewMissOutPunchesState.selectedRow?.employeeName || ""}</span></div>
                        <div className=" col-start-1 sm:col-end-3 xsm:col-end-12 text-15px flex justify-between"><Label label={`Payroll Period`} setBold /><span className=" font-bold">:</span></div>
                        <div className=" sm:col-start-3 xsm:col-start-1 col-end-12"><Label label={viewMissOutPunchesState.selectedRow?.fromDate && viewMissOutPunchesState.selectedRow?.toDate ? `${dateFormat(viewMissOutPunchesState.selectedRow?.fromDate)}  -  ${dateFormat(viewMissOutPunchesState.selectedRow?.toDate)}` : ""} setBold /> </div>
                    </div>
                    <GreySubHeader subHeader="Time In / Out Details" />
                    <div>
                        <div className=" bottomPinned_grid"><AgGrid columns={timeInAndTimeOut.viewMissOutPunches.timeInOutDetailsColumn} data={timeinOut} pinnedBottomRowData={pinnedData} height={" h-[33.7rem] "} rowStyle={setRowStyle} /> </div>
                    </div>
                    <GreySubHeader subHeader="Leave History" />
                    <div>
                        <AgGrid columns={timeInAndTimeOut.viewMissOutPunches.leaveHistoryColumns} data={leaveHistoryData} height={" h-52 "} isAutoHeight />
                    </div>
                    <div className=" flex justify-center py-[2px]" > <Button value={strings.Buttons.Close} onClick={onClose} isRemovePaddingStyle /></div>
                </div>
            </div>} />
    )
}

export default ViewMissOutPunches