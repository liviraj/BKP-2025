import { useDispatch, useSelector } from "react-redux";
import ModelBox from "../elements/ModelBox"
import TransparentLoader from "../loader/TransparentLoader"
import ApiResponse from "../Alert/ApiResponse";
import { strings } from "../Constants";
import Button from "../elements/Button";
import { attendancePayrollActions } from "../../redux/AttendancePayrollReducer";
import Label from "../elements/Label";
import UploadAndDeleteDocument from "../elements/UploadAndDeleteDocument";
import { useEffect, useState } from "react";
import * as XLSX from 'xlsx';
import AgGrid from "../Grid/AgGrid";
import { indiaAttendanceReport } from "../Grid/Columns";
import Dropdown from "../elements/Dropdown";
import ImageViewer from "../ViewDocs/ImageViewer";
import DatePickerElement from "../elements/DatePickerElement";
import { leaveManagementRequest, payrollRequest, userRequest } from "../requests";
import { exportDateFormat } from "../helper";
import { useForm } from "react-hook-form";

function UploadAuditDocumentPopup() {

    const dispatch = useDispatch();
    const loginResponseState = useSelector(state => state.loginResponse);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const auditDocumentState = useSelector(state => state.attendancePayroll.uploadAuditPopup);
    const userState = useSelector(state => state.user);
    const leaveManagementState = useSelector(state => state.leaveManagement);

    const [uploadDocument, setUploadDocument] = useState([]);
    const [excelData, setExcelData] = useState({ columns: [], data: [] });
    const [excelSheets, setExcelSheets] = useState({ selected: "", options: [] });
    const [payrollPeriod, setPayrollPeriod] = useState("")
    const { watch, setValue, getValues } = useForm({ defaultValues: initialValue });
    const handleClose = async () => {
        dispatch(attendancePayrollActions.setUploadAuditorDocumentPopup({ show: false, loader: false }));
    }


    useEffect(() => {

        const onInitialLoad = async () => {
            await dispatch(attendancePayrollActions.setUploadAuditorDocumentLoader(true));
            await Promise.all([
                leaveManagementState.leaveType.length <= 0 && dispatch(leaveManagementRequest.leaveRequest.getLeaveType(userState.LocationID)),
            ])
            dispatch(attendancePayrollActions.setUploadAuditorDocumentLoader(false));

        }
        onInitialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    useEffect(() => {
        try {
            dispatch(attendancePayrollActions.setUploadAuditorDocumentLoader(true));
            if (uploadDocument.length > 0) {
                const fileObj = uploadDocument[0];
                const workbook = XLSX.read(fileObj.binary, { type: "base64" });
                const excelSheetNames = workbook.SheetNames.map((val, idx) => ({ value: idx, label: val }))
                setExcelSheets({ selected: excelSheetNames[0], options: excelSheetNames });
                const sheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[sheetName];
                const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

                const data = indiaAttendanceReport.uploadAuditPopup.convertFormattedRecords(jsonData);
                setExcelData({ ...data });
            } else {
                setExcelData({ data: [], columns: indiaAttendanceReport.uploadAuditPopup.columns });
                setExcelSheets({ selected: "", options: [] });
            }
            dispatch(attendancePayrollActions.setUploadAuditorDocumentLoader(false))
        }
        catch (err) {
            console.error("Uploaded File Conversion failed, please check the uploaded file template", err);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [uploadDocument]);

    const onSheetChange = (params) => {
        const fileObj = uploadDocument[0];
        const workbook = XLSX.read(fileObj.binary, { type: "base64" });
        const excelSheetNames = workbook.SheetNames.map((val, idx) => ({ value: idx, label: val }))
        setExcelSheets({ selected: params, options: excelSheetNames });
        const sheetName = params.label;
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

        const data = indiaAttendanceReport.uploadAuditPopup.convertFormattedRecords(jsonData);
        setExcelData({ ...data });
    }

    const handleUpload = async () => {
        await dispatch(attendancePayrollActions.setUploadAuditorDocumentLoader(true));
        const value = getValues()
        let data = {
            monthName: payrollPeriod ? new Date(payrollPeriod).toLocaleString('default', { month: 'long' }) : '',
            forYear: payrollPeriod ? payrollPeriod.getFullYear() : '',
            imageName: uploadDocument && uploadDocument.length > 0 ? uploadDocument[0].name : '',
            imageBinary: uploadDocument && uploadDocument.length > 0 ? uploadDocument[0].binary : '',
            addedOn: exportDateFormat(new Date()),
            addedBy: userState.UserID,
            leaveTypeId: value.leaveType.value
        }
        await dispatch(payrollRequest.payrollUploadRequest(data, setCallBack))
        dispatch(attendancePayrollActions.setUploadAuditorDocumentLoader(false));
    }

    const handleValidate = async () => {
        await dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Confirmation", message: `Are you sure you want to save the details for the uploaded Auditor document?`, isOptional: true }))
    }

    const setCallBack = (status) => {
        if (status) {
            handleClose()
        }
    }

    const handleConfirmation = (isAcceptable) => {
        if (isAcceptable) {
            handleUpload();
        }
    }

    return (
        <ModelBox
            Component={
                <>
                    <div className=' pb-3 bg-white rounded-md' >
                        <div className=' max-h-90vh overflow-y-auto w-[95vw]'>
                            <div className=" grid grid-cols-12 mx-4 my-4 items-center gap-2">
                                <div className=" col-start-1 xl:col-end-3 lg:col-end-4 sm:col-end-5 xsm:col-end-12"> <Label label={"Payroll Period"} required /></div>
                                <div className=" xl:col-start-3 lg:col-start-4 sm:col-start-5 xsm:col-start-1 xl:col-end-5 lg:col-end-9 sm:col-end-10 xsm:col-end-13">
                                    <DatePickerElement ismonthYear={true} value={payrollPeriod} onChange={data => setPayrollPeriod(data)} isRequired={true} placeholder={"Payroll Period"} isRemovable={true} /></div>
                                <div className=" col-start-1 xl:col-end-3 lg:col-end-4 sm:col-end-5 xsm:col-end-12"> <Label label={"Leave Type"} required /></div>
                                <div className=" xl:col-start-3 lg:col-start-4 sm:col-start-5 xsm:col-start-1 xl:col-end-5 lg:col-end-9 sm:col-end-10 xsm:col-end-13">
                                    <Dropdown value={watch(strings.UploadAuditDocumentPopup.leaveType)} options={leaveManagementState.leaveType} onChange={e => setValue(strings.UploadAuditDocumentPopup.leaveType, e)} isSearchable={true} /></div>
                                <div className=" col-start-1 xl:col-end-3 lg:col-end-4 sm:col-end-5 xsm:col-end-12"> <Label label={"Upload Auditor Document"} required /></div>
                                <div className=" xl:col-start-3 lg:col-start-4 sm:col-start-5 xsm:col-start-1 xl:col-end-7 lg:col-end-9 sm:col-end-10 xsm:col-end-13"><UploadAndDeleteDocument label={"Browse"} file={uploadDocument} onChange={file => setUploadDocument(file)} fileType={{ 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': [], 'text/csv': [] }} /></div>
                                <div className=" lg:col-start-10 xsm:col-start-1  lg:col-end-13 sm:col-end-5 xsm:col-end-13">
                                    <Dropdown isLabelView placeholder="Excel Sheets" value={excelSheets.selected} options={excelSheets.options} onChange={onSheetChange} isDisable={uploadDocument.length <= 0} />
                                </div>
                                {/* fileType={{ 'application/vnd.ms-excel': [] }} */}
                            </div>
                            <div className=" md:m-4 xsm:m-2 ">
                                <AgGrid columns={excelData.columns} data={excelData.data} height={" lg:h-[calc(80vh-170px-5vh)] sm:h-[calc(80vh-220px-5vh)] xsm:h-[65vh]"} />
                            </div>
                            <div className=' flex justify-center items-center h-10 bg-white sticky z-10 bottom-0'>
                                <Button value={strings.Buttons.upload} disabled={uploadDocument.length <= 0 || payrollPeriod.length <= 0 || !watch(strings.UploadAuditDocumentPopup.leaveType)} onClick={handleValidate} />
                                <span className=' mx-2 overflow-hidden h-full'><Button value={strings.Buttons.Close} onClick={handleClose} /></span>
                            </div>
                        </div>
                    </div>
                    {auditDocumentState.loader && <TransparentLoader isFullWidth={true} />}
                    {apiResponseState.show && <ApiResponse setResponseCallback={handleConfirmation} />}
                    {loginResponseState.imageViewer.show && <ImageViewer />}
                </>
            }
            headerTitle={strings.Buttons.uploadAuditDocument}
            open={auditDocumentState.show}
            onClose={handleClose}
        />
    )
}

export default UploadAuditDocumentPopup

const initialValue = {
    leaveType: ""
}