
import { useDispatch, useSelector } from "react-redux";
import Button from "../elements/Button";
import Dropdown from "../elements/Dropdown";
import Label from "../elements/Label";
import ModelBox from "../elements/ModelBox";
import { useForm } from "react-hook-form";
import { setDefaultValue, strings } from "../Constants";
import { useEffect, useMemo } from "react";
import { employeeReducerState, exportDateFormat, userReducerState } from "../helper";
import TextField from "../elements/TextField";
import DatePickerElement from "../elements/DatePickerElement";
import UploadAndDeleteDocument from "../elements/UploadAndDeleteDocument";
import TextArea from "../elements/TextArea";
import { deputationActions } from "../../redux/DeputationReducer";
import { deputationRequest, employeeRequests } from "../requests";
import PropTypes from 'prop-types';
import TransparentLoader from "../loader/TransparentLoader";
import GreySubHeader from "../layouts/GreySubHeader";
import ImageViewer from "../ViewDocs/ImageViewer";
import ApiResponse from "../Alert/ApiResponse";

const DeputationPopup = ({ setCallBack }) => {

    const dispatch = useDispatch()
    const { deputationPopup, loader } = useSelector(state => state.deputation);
    const employeeState = useSelector(state => state.employee);
    const { LocationID } = useSelector(state => state.user);
    const loginResponseState = useSelector(state => state.loginResponse);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);

    const { watch, setValue, reset, getValues } = useForm({ defaultValues: initialState });
    const location = watch(strings.deputationPopup.workLocation);
    const employeeName = watch(strings.deputationPopup.employeeName);

    const labelClassName = " sm:mt-0 xsm:mt-4 col-start-1 sm:col-end-5 xsm:col-end-12 ";
    const valueClassName = " sm:col-start-5 xsm:col-start-1 col-end-13";

    useEffect(() => {
        const initialLoad = async () => {
            await dispatch(deputationActions.setLoader(true));
            employeeState.location.length <= 0 && await dispatch(employeeRequests.location());
            await handleReset();
            dispatch(deputationActions.setLoader(false));
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);


    const employeeNameOptions = useMemo(() => {
        let employeeOptions = employeeState.employeeName;
        employeeOptions = employeeOptions.filter(val => ((val.employmentStatus !== "Relieved" && val.employmentStatus !== "" && val.employmentStatus !== "All")));
        if (location && employeeOptions.length > 0) {
            employeeOptions = employeeOptions.filter(val => (val.locationId === location.value && val.locationId !== 0));
        }
        if (employeeName?.locationId !== location?.value) {
            setValue(strings.deputationPopup.employeeName, '')
        }
        return employeeOptions;
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [employeeState, location]);

    const handleReset = async () => {
        await dispatch(deputationActions.setLoader(true))
        if (deputationPopup.action === 'Edit') {
            const data = deputationPopup.selectedRow;
            setValue(strings.deputationPopup.workLocation, employeeReducerState()?.location.find(val => Number(val.value) === Number(data.locationId)));
            setValue(strings.deputationPopup.employeeName, employeeNameOptions && employeeNameOptions.length > 0 ? employeeNameOptions.find(val => Number(val.value) === Number(data.employeeId)) : "");
            setValue(strings.deputationPopup.deputationLocation, employeeReducerState()?.location.find(val => (val.label)?.toUpperCase() === (data.deputationLocation)?.toUpperCase()));
            setValue(strings.deputationPopup.deputationSite, data?.deputationSite ? data.deputationSite : '');
            setValue(strings.deputationPopup.deputationFrom, data?.deputationFrom ? data.deputationFrom : '');
            setValue(strings.deputationPopup.deputationTo, data?.deputationTo ? data.deputationTo : '');
            setValue(strings.deputationPopup.depatureDate, data?.departureDate ? data.departureDate : '');
            setValue(strings.deputationPopup.arrivalDate, data?.arrivalDate ? data.arrivalDate : '');
            setValue(strings.deputationPopup.visaValidityFrom, data?.visaValidityFrom ? data.visaValidityFrom : '');
            setValue(strings.deputationPopup.visaValidityTo, data?.visaValidityTo ? data.visaValidityTo : '');
            setValue(strings.deputationPopup.remarks, data?.remarks ? data.remarks : '');
            setValue(strings.deputationPopup.travelDocument, (data.travelDocument?.length > 0 && data.travelDocumentName?.length > 0) ? [{ binary: data.travelDocument, name: data.travelDocumentName }] : '')
        }
        else {
            await reset();
            if (employeeReducerState().location.length > 0 && LocationID) {
                await setValue(strings.deputationPopup.workLocation, employeeReducerState().location.find(val => Number(val.value) === LocationID));
                await setValue(strings.deputationPopup.deputationLocation, employeeReducerState().location.find(val => val.value === (LocationID === setDefaultValue.location.value ? setDefaultValue.usLocation.value : setDefaultValue.location.value)));
            }
        }
        dispatch(deputationActions.setLoader(false));
    }

    const handleSave = async () => {
        await dispatch(deputationActions.setLoader(true));
        const data = getValues();
        let params = {
            arrivalDate: exportDateFormat(data.arrivalDate),
            departureDate: exportDateFormat(data.depatureDate),
            deputationFrom: exportDateFormat(data.deputationFrom),
            deputationLocation: data.deputationLocation.label,
            deputationLocationId: data.deputationLocation.value,
            deputationSite: data.deputationSite,
            deputationTo: exportDateFormat(data.deputationTo),
            employeeId: data.employeeName.employeeId,
            locationId: data.workLocation.value,
            remarks: data.remarks,
            travelDocumentName: data.travelDocument?.length > 0 ? data.travelDocument[0]?.name : '',
            travelDocument: data.travelDocument?.length > 0 ? data.travelDocument[0]?.binary : '',
            visaValidityFrom: exportDateFormat(data.visaValidityFrom),
            visaValidityTo: exportDateFormat(data.visaValidityTo)
        }

        if (deputationPopup.action === 'Edit') {
            params = { ...params, modifiedBy: userReducerState().UserID, modifiedOn: exportDateFormat(new Date()), deputationId: deputationPopup.selectedRow?.deputationId }
            await dispatch(deputationRequest.editDeputationRequest(deputationPopup.selectedRow?.deputationId, params, setCallBack));
        }
        else {
            params = { ...params, addedBy: userReducerState().UserID, addedOn: exportDateFormat(new Date()), deputationId: 0 }
            await dispatch(deputationRequest.addDeputation(params, setCallBack));
        }
        dispatch(deputationActions.setLoader(false));
    }

    const onClose = async () => {
        await dispatch(deputationActions.reSetDeputationPoup());
    }

    const handleLocationValidation = (data, value) => {
        if (Object.keys(watch(value)).length > 0) {
            if (data.value === setDefaultValue.location.value) {
                setValue(value, setDefaultValue.usLocation);
            }
            else {
                setValue(value, setDefaultValue.location);
            }
        }
    }
    const setValidation = (isReset) => {
        const value = getValues();
        if (deputationPopup.action === 'Edit') {
            let isValid = false;
            const data = deputationPopup.selectedRow;
            if (value[strings.deputationPopup.employeeName] && value[strings.deputationPopup.workLocation] && value[strings.deputationPopup.deputationSite] && value[strings.deputationPopup.deputationLocation] && value[strings.deputationPopup.deputationFrom] && value[strings.deputationPopup.deputationTo]) {
                if (!(
                    (value[strings.deputationPopup.employeeName]?.value) === data.employeeId
                    && value[strings.deputationPopup.workLocation]?.value === data.locationId
                    && value[strings.deputationPopup.deputationSite] === data.deputationSite
                    && value[strings.deputationPopup.deputationLocation]?.label === data.deputationLocation
                    && exportDateFormat(value[strings.deputationPopup.deputationFrom]) === exportDateFormat(data.deputationFrom)
                    && exportDateFormat(value[strings.deputationPopup.deputationTo]) === exportDateFormat(data.deputationTo)
                    && exportDateFormat(value[strings.deputationPopup.depatureDate]) === exportDateFormat(data.departureDate)
                    && exportDateFormat(value[strings.deputationPopup.arrivalDate]) === exportDateFormat(data.arrivalDate)
                    && exportDateFormat(value[strings.deputationPopup.visaValidityFrom]) === exportDateFormat(data.visaValidityFrom)
                    && exportDateFormat(value[strings.deputationPopup.visaValidityTo]) === exportDateFormat(data.visaValidityTo)
                    && value[strings.deputationPopup.remarks] === data.remarks
                    && (value[strings.deputationPopup.travelDocument]?.length > 0 ? (value[strings.deputationPopup.travelDocument][0].name === data.travelDocumentName && value[strings.deputationPopup.travelDocument][0].binary === data.travelDocument) : !(data.travelDocumentName && data.travelDocument))
                )) { isValid = true }
            }
            return isValid;
        }
        else {
            if (isReset) {
                return value[strings.deputationPopup.employeeName] || value[strings.deputationPopup.workLocation] || value[strings.deputationPopup.deputationSite] || value[strings.deputationPopup.deputationLocation] || value[strings.deputationPopup.deputationFrom] || value[strings.deputationPopup.deputationTo]
                    || value[strings.deputationPopup.depatureDate] || value[strings.deputationPopup.arrivalDate] || value[strings.deputationPopup.visaValidityFrom] || value[strings.deputationPopup.visaValidityTo] || value[strings.deputationPopup.remarks] || value[strings.deputationPopup.travelDocument].length > 0
            }
            return value[strings.deputationPopup.employeeName] && value[strings.deputationPopup.workLocation] && value[strings.deputationPopup.deputationSite] && value[strings.deputationPopup.deputationLocation] && value[strings.deputationPopup.deputationFrom] && value[strings.deputationPopup.deputationTo]
        }
    }

    return (
        <ModelBox Component={
            <>
                <div className="xsm:w-screen/90 md:w-[95vw] xl:w-[65rem] max-h-[85vh] overflow-auto sm:px-8 xsm:px-4 bg-white">
                    <div className=" grid lg:grid-cols-2 xsm:grid-cols-1 lg:gap-8 sm:gap-4 sm:my-4">
                        <div className=" grid grid-cols-12 sm:gap-4 items-center ">
                            <div className={labelClassName}><Label label="Employee Name" required={true} />  </div>
                            <div className={valueClassName}><Dropdown value={employeeName} options={employeeNameOptions} onChange={e => setValue(strings.deputationPopup.employeeName, e)} isRequired={true} isDisable={!watch(strings.deputationPopup.workLocation)} /></div>
                        </div>
                        <div className=" grid grid-cols-12 sm:gap-4 items-center ">
                            <div className={labelClassName}><Label label="Work Location" required={true} /> </div>
                            <div className={valueClassName}> <Dropdown onChange={data => { handleLocationValidation(data, strings.deputationPopup.deputationLocation); setValue(strings.deputationPopup.workLocation, data) }} value={watch(strings.deputationPopup.workLocation)} options={employeeState.location && employeeState.location.length > 0 ? employeeState.location.filter(val => val.value > 0) : []} isSearchable={true} isRequired={true} /></div>
                        </div>
                    </div>
                    <div className=" grid lg:grid-cols-2 xsm:grid-cols-1 gap-4 xsm:my-4">
                        <div className=" grid grid-cols-12 sm:gap-4 items-center ">
                            <div className=" col-start-1 col-end-13 "> <GreySubHeader subHeader="Deputation Details" addStyles={"!justify-center"} /></div>
                            <div className={labelClassName}><Label label="Deputation Site" required={true} />  </div>
                            <div className={valueClassName}> <TextField value={watch(strings.deputationPopup.deputationSite)} onChange={e => setValue(strings.deputationPopup.deputationSite, e.target.value)} isRequired={true} /> </div>
                            <div className={labelClassName}><Label label="Deputation Location" required={true} />  </div>
                            <div className={valueClassName}> <Dropdown onChange={data => { handleLocationValidation(data, strings.deputationPopup.workLocation); setValue(strings.deputationPopup.deputationLocation, data) }} value={watch(strings.deputationPopup.deputationLocation)} options={employeeState.location && employeeState.location.length > 0 ? employeeState.location.filter(val => val.value > 0) : []} isSearchable={true} isRequired={true} /> </div>
                            <div className={labelClassName}><Label label="Deputation From" required={true} />  </div>
                            <div className={valueClassName}><DatePickerElement value={watch(strings.deputationPopup.deputationFrom)} onChange={date => setValue(strings.deputationPopup.deputationFrom, date)} isRequired={true} /></div>
                            <div className={labelClassName}><Label label="Deputation To" required={true} />  </div>
                            <div className={valueClassName}><DatePickerElement value={watch(strings.deputationPopup.deputationTo)} onChange={date => setValue(strings.deputationPopup.deputationTo, date)} isRequired={true} /></div>
                        </div>
                        <div className=" grid grid-cols-12 sm:gap-4 items-center lg:h-52 ">
                            <div className=" col-start-1 col-end-13 "> <GreySubHeader subHeader="Travel Details" addStyles={"!justify-center"} /></div>
                            <div className={labelClassName}><Label label="Travel Depature Date" />  </div>
                            <div className={valueClassName}><DatePickerElement value={watch(strings.deputationPopup.depatureDate)} onChange={date => setValue(strings.deputationPopup.depatureDate, date)} /></div>
                            <div className={labelClassName}><Label label="Travel Arrival Date" />  </div>
                            <div className={valueClassName}><DatePickerElement value={watch(strings.deputationPopup.arrivalDate)} onChange={date => setValue(strings.deputationPopup.arrivalDate, date)} /></div>
                            <div className={labelClassName}><Label label="Travel Document" />  </div>
                            <div className={valueClassName}><UploadAndDeleteDocument label="Browse" onChange={file => setValue(strings.deputationPopup.travelDocument, file)} file={watch(strings.deputationPopup.travelDocument)} /></div>
                        </div>
                    </div>
                    <GreySubHeader subHeader="Visa Details" addStyles={"!justify-center "} />
                    <div className=" grid lg:grid-cols-2 xsm:grid-cols-1 lg:gap-8 sm:gap-4 sm:my-4">
                        <div className=" grid grid-cols-12 sm:gap-4 items-center ">
                            <div className={labelClassName}><Label label="Visa Validity From " />  </div>
                            <div className={valueClassName}><DatePickerElement value={watch(strings.deputationPopup.visaValidityFrom)} onChange={date => setValue(strings.deputationPopup.visaValidityFrom, date)} /></div>
                        </div>
                        <div className=" grid grid-cols-12 sm:gap-4 items-center ">
                            <div className={labelClassName}><Label label="Visa Validity To" />  </div>
                            <div className={valueClassName}><DatePickerElement value={watch(strings.deputationPopup.visaValidityTo)} onChange={date => setValue(strings.deputationPopup.visaValidityTo, date)} /></div>
                        </div>
                    </div>
                    <div className=" flex items-center mt-5"><Label label="Remarks" />  </div>
                    <TextArea value={watch(strings.deputationPopup.remarks)} onChange={e => setValue(strings.deputationPopup.remarks, e.target.value)} height={" !h-28 text-13px "} />
                    <footer className="flex flex-wrap gap-4 justify-center mt-7 mb-2 sticky z-0 bottom-0 bg-white">
                        <Button value={deputationPopup.action === 'Edit' ? strings.Buttons.Update : strings.Buttons.Save} onClick={handleSave} disabled={!setValidation()} />
                        <Button value={strings.Buttons.Reset} onClick={handleReset} disabled={!setValidation(true)} />
                        <Button value={strings.Buttons.Close} onClick={onClose} />
                    </footer>
                </div>
                {loader && <TransparentLoader isFullWidth />}
                {loginResponseState.imageViewer.show && <ImageViewer />}
                {apiResponseState.show && <ApiResponse />}
            </>
        } headerTitle={deputationPopup.action === 'Edit' ? 'Edit Deputation' : 'Add Deputation'} open={deputationPopup.show} onClose={onClose} />
    );
};

export default DeputationPopup;

DeputationPopup.propTypes = {
    setCallBack: PropTypes.func,
}

const initialState = {
    workLocation: "",
    employeeName: "",
    deputationLocation: "",
    deputationSite: "",
    deputationFrom: "",
    deputationTo: "",
    depatureDate: "",
    arrivalDate: "",
    travelDocument: [],
    visaValidityFrom: "",
    visaValidityTo: "",
    remarks: ""
}