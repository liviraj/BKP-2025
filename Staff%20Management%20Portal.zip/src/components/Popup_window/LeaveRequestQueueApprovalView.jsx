import PropTypes from 'prop-types';
import ModelBox from "../elements/ModelBox";
import AgGrid from '../Grid/AgGrid';
import { dateFormat, exportDateFormat, leaveManagementReducerState, leaveRequestApprovalValidation } from '../helper';
import Button from '../elements/Button';
import { useSelector, useDispatch } from 'react-redux';
import { classNames, status, strings } from '../Constants';
import { leaveManagementActions } from '../../redux/leaveManagementReducer';
import TextArea from '../elements/TextArea';
import Label from '../elements/Label';


function LeaveRequestQueueApprovalView({ onSubmit, isCancel }) {
    const dispatch = useDispatch();
    const leaveReqData = useSelector((state) => state.leaveManagement.leaveRequestQueue.leaveReqDetailsScreen);
    const resetReduxStore = () => dispatch(leaveManagementActions.setLeaveReqDetails({ view: false, reqId: 0, empName: '', status: '', rowData: [], selectedRowData: [], comments: "", requestStatus: '' }));

    const updateSelectedRow = async (data) => {
        await dispatch(leaveManagementActions.setLeaveReqDetails({ ...leaveManagementReducerState().leaveRequestQueue.leaveReqDetailsScreen, selectedRowData: data }));
    };

    const setRowStyle = params => {
        if (params.data) {
            const isHided = leaveRequestApprovalValidation(params.data.status, leaveManagementReducerState().leaveRequestQueue.selectedRow.action);
            return { background: isHided ? "#bcddf8" : '#ffff', opacity: isHided ? '0.5' : '1.0' };
        }
        return { backgroundColor: '#ffff' }
    };

    const onConfirm = async (status) => {
        await dispatch(leaveManagementActions.setLeaveReqDetails({ ...leaveReqData, requestStatus: status, selectedRowData: leaveReqData.selectedRowData.map(val => ({ ...val, date: exportDateFormat(val.date, true) })), view: false }));
        await onSubmit(false);
    }


    return (
        <div>
            <ModelBox onClose={resetReduxStore}
                open={leaveReqData.view} okayBtnLabel={"Confirm"} cancelBtnLabel={"Cancel"}
                headerTitle={`Leave Request Details`} Component={
                    <div>
                        <div className=' w-[28rem] md:w-[28rem] sm:w-[90vw] xsm:w-[90vw] m-4 tracking-wide'>
                            {isCancel || <div className='font-fontfamily font-bold pb-1'>
                                <span className=' text-15px'>Employee Name : </span>
                                <span className=' text-headerColor text-14px uppercase'>{leaveReqData?.empName}</span>
                            </div>}
                            <div className='font-fontfamily font-bold pb-1'><span className='text-blackColor text-15px'>Leave Date : </span>
                                <span className='font-normal text-14px'>
                                    {leaveReqData.rowData.length > 0 && Object.hasOwn(leaveReqData.rowData[0], "date") ? isCancel ? `${dateFormat(leaveReqData.rowData[0].date)}` : `${dateFormat(leaveReqData.rowData[0].date)} - ${dateFormat(leaveReqData.rowData[leaveReqData.rowData.length - 1].date)}` : ""}
                                </span>
                            </div>
                            {
                                leaveReqData.rowData.length > 0 &&
                                <div className='mb-3'>
                                    <Label label={isCancel ? "Reason" : "Comments :"} required={isCancel} addStyle={'font-bold text-15px'} setBold={true} />
                                    <TextArea height={" h-20 text-13px tracking-normal"} isRequired={isCancel} value={leaveReqData.comments} onChange={(e) => dispatch(leaveManagementActions.setLeaveReqDetails({ ...leaveReqData, comments: e.target.value }))} />
                                </div>
                            }
                            <AgGrid height="h-[15rem]" columns={columns} data={leaveReqData.rowData} rowSelection={true} multiRowSelection={true} getSelectedRow={updateSelectedRow} defaultAllRowselection={true} rowStyle={setRowStyle} />
                            <div className="justify-center flex flex-row gap-3 sm:flex-row mb-3" >
                                {
                                    leaveReqData.status === status.tobeApproved ?
                                        <div className=' gap-x-3 flex'>
                                            <Button value={strings.Buttons.approve} disabled={leaveReqData.selectedRowData.length <= 0} onClick={() => onConfirm(status.approved)} />
                                            <Button value={strings.Buttons.reject} disabled={leaveReqData.selectedRowData.length <= 0} onClick={() => onConfirm(status.reject)} />
                                        </div>
                                        :
                                        <Button value={leaveReqData.status === status.approved ? strings.Buttons.approve : leaveReqData.status === status.reject ? strings.Buttons.reject : leaveReqData.status === status.cancel ? strings.Buttons.cancelLeaveRequest : ''} onClick={() => {
                                            onSubmit(false);
                                            dispatch(leaveManagementActions.setLeaveReqDetails({ ...leaveReqData, selectedRowData: leaveReqData.selectedRowData.map(val => ({ ...val, date: exportDateFormat(val.date, true) })), view: false }));
                                        }} disabled={leaveReqData.selectedRowData.length === 0 || (isCancel ? leaveReqData.comments === "" : false)} />
                                }
                                <Button value={strings.Buttons.Close} onClick={() => { resetReduxStore(); }} />
                            </div>
                        </div>
                    </div>
                } />
        </div>
    )
}

export default LeaveRequestQueueApprovalView;

LeaveRequestQueueApprovalView.propTypes = {
    onSubmit: PropTypes.func,
    isCancel: PropTypes.bool
}

const columns = [
    {
        headerName: "S.No",
        field: "sno",
        comparator: (valueA, valueB, nodeA, nodeB) => Number(nodeA.id) - Number(nodeB.id),
        cellRenderer: params => (<div className={"h-full m-0 !ml-4 w-full flex items-center"}>{Number(params.node.id) + 1}</div>), //holdToDisplay={0}
        lockPosition: 'left',
        minWidth: 70,
        maxWidth: 70,
        checkboxSelection: params => !leaveRequestApprovalValidation(params.data.status, leaveManagementReducerState().leaveRequestQueue.selectedRow.action),
    },
    {
        headerName: "Leave Date",
        field: "date",
        minWidth: 120,
        maxWidth: 120,
        cellRenderer: params => (<div className={classNames.contextMenuValue}>{dateFormat(params.value)}</div>),
    },
    {
        headerName: "F/H Day",
        field: "leavePeriod",
        minWidth: 100,
        maxWidth: 100,
        cellRenderer: params => (<div className={classNames.contextMenuValue}>{params.value}</div>)
    },
    {
        headerName: "Status",
        field: "approvalStatus",
        minWidth: 100,
        cellRenderer: params => (<div className={classNames.contextMenuValue}>{params.value}</div>),
    }
]
