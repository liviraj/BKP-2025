import { useDispatch, useSelector } from "react-redux";
import Button from "../elements/Button"
import ModelBox from "../elements/ModelBox"
import TransparentLoader from "../loader/TransparentLoader"
import { useEffect, useMemo, useState } from "react";
import ApiResponse from "../Alert/ApiResponse";
import { holidayActions } from "../../redux/holidayReducer";
import { useForm } from "react-hook-form";
import { floatingHolidayTypes, strings } from "../Constants";
import RadioButton from "../elements/RadioButton";
import { compareFloatingHolidayList, exportDateFormat, exportYearFormat } from "../helper";
import { holidayRequests } from "../requests";
import propTypes from 'prop-types';

function SetFloatingHolidayPopup({ resetHolidayDetails }) {

    const [loader, setLoader] = useState(false);
    const { watch, setValue, handleSubmit } = useForm({ defaultValues: initialState });
    const floatingHoliday = watch(strings.setFloatingHolidayPopup.floatingHolidayList);

    const userState = useSelector(state => state.user);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const floatingHolidayPopupState = useSelector(state => state.holiday.floatingHolidayOptionsPopup)
    const dispatch = useDispatch();

    useEffect(() => {
        const initialLoad = async () => {
            setLoader(true);
            await onResetValue();
            setLoader(false);
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onResetValue = () => {
        const selectedRow = floatingHolidayPopupState.employeeDetails;
        if (selectedRow && typeof (selectedRow) === "object" && Object.keys(selectedRow).length > 0) {
            setValue(strings.setFloatingHolidayPopup.floatingHolidayList, selectedRow.floatingHolidays);
        }
    }

    const onClose = () => {
        dispatch(holidayActions.setFloatingHolidayOptionsPopup({ show: false, employeeDetails: {} }));
    }

    const onRadioBtnUpdate = (idx, value) => {
        let tempFloatingHoliday = [...floatingHoliday];
        tempFloatingHoliday[idx] = tempFloatingHoliday[idx].map(val => {
            if (val.holidayName === value) {
                return { ...val, isUsed: true }
            }
            return { ...val, isUsed: false }
        });
        setValue(strings.setFloatingHolidayPopup.floatingHolidayList, tempFloatingHoliday);
    }

    const disableButton = useMemo(() => {
        if (Object.keys(floatingHolidayPopupState.employeeDetails).length > 0) {
            const getFloatingHolidayDetails = floatingHolidayPopupState.employeeDetails && typeof (floatingHolidayPopupState.employeeDetails) === "object" && ("floatingHolidays" in floatingHolidayPopupState.employeeDetails) ? floatingHolidayPopupState.employeeDetails.floatingHolidays : {};
            return compareFloatingHolidayList(getFloatingHolidayDetails, floatingHoliday);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [floatingHoliday]);

    const onSubmit = async (data) => {
        setLoader(true);
        let tempData = [];
        for (let holidayList of data.floatingHolidayList) {
            if (holidayList.length > 0 && Object.keys(floatingHolidayPopupState.employeeDetails).length > 0 && floatingHolidayPopupState.employeeDetails[`${holidayList[0].holidayName}CheckboxType`] === floatingHolidayTypes.empty) {
                const checkedValues = holidayList.find(val => val.isUsed);
                if (checkedValues) {
                    tempData = [...tempData, checkedValues];
                }
            }
        }
        const params = {
            addedByEmpId: userState.UserID,
            addedOn: exportDateFormat(new Date()),
            employeeId: userState.UserID,
            holidayIdDetailsList: tempData,
        }
        await dispatch(holidayRequests.setFloatingHolidayPopup.saveFloatingHolidayDetails(params, async () => {
            await onClose();
            await resetHolidayDetails();
        }))
        setLoader(false);
    }

    return (
        <ModelBox Component={
            <>
                <div className="xsm:w-[90vw] lg:w-[30rem] sm:w-[70vw] max-h-[85vh] overflow-auto sm:px-8 xsm:px-4 bg-white">
                    <header className=" flex flex-wrap font-fontfamily font-bold tracking-wide mt-4">  Floating Holidays Are :</header>
                    <div className=" ml-8 flex flex-wrap font-fontfamily">
                        {
                            floatingHoliday?.length > 0 && floatingHoliday.map((list, idx) =>
                                <div key={idx} className="flex flex-wrap w-full">
                                    <RadioButton options={list.map(val => val.holidayName)} disabled={list.length > 0 && Object.keys(floatingHolidayPopupState.employeeDetails).length > 0 ? (("isDisabled" in list[0]) && list[0].isDisabled || !(floatingHolidayPopupState.employeeDetails[`${list[0].holidayName}CheckboxType`] === floatingHolidayTypes.empty)) : false} value={list.find(val => val.isUsed) ? list.find(val => val.isUsed).holidayName : ""} onChange={e => onRadioBtnUpdate(idx, e.target.value)} customColor={floatingHolidayPopupState.employeeDetails[`${list[0].holidayName}Color`]} />
                                </div>
                            )
                        }
                    </div>
                    <footer className="flex flex-wrap gap-4 justify-center mt-7 sticky z-0 bottom-0 bg-white">
                        <Button value={strings.Buttons.Save} disabled={disableButton} onClick={handleSubmit(onSubmit)} />
                        <Button value={strings.Buttons.Reset} onClick={onResetValue} disabled={disableButton} />
                        <Button value={strings.Buttons.Close} onClick={onClose} />
                    </footer>
                </div>
                <>
                    {loader && <TransparentLoader isFullWidth />}
                    {apiResponseState.show && <ApiResponse />}
                </>
            </>
        } headerTitle={`Set Floating Holidays(${exportYearFormat(new Date())})`} open={floatingHolidayPopupState.show} onClose={onClose} />
    )
}

export default SetFloatingHolidayPopup

SetFloatingHolidayPopup.propTypes = {
    resetHolidayDetails: propTypes.func
}

const initialState = {
    employeeName: "",
    floatingHolidayList: []
}