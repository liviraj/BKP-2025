import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Personal from '../employeeDetail_modules/Personal';
import Work from '../employeeDetail_modules/Work';
import Communication from '../employeeDetail_modules/Communication';
import Qualification from '../employeeDetail_modules/Qualification';
import Button from '../elements/Button';
import { useDispatch, useSelector } from 'react-redux';
import TransparentLoader from '../loader/TransparentLoader';
import ImageViewer from '../ViewDocs/ImageViewer';
import ApiResponse from '../Alert/ApiResponse';
import { strings } from '../Constants';
import { employeeRequests } from '../requests';
import PrintEmployeeDetailView from '../Print/PrintEmployeeDetailView';
import ContinuousEducation from '../employeeDetail_modules/ContinuousEducation';
import WorkHistory from '../employeeDetail_modules/WorkHistory';
import ModelBox from '../elements/ModelBox';
import MultiImageViewer from '../ViewDocs/MultiImageViewer';


function EmployeeDetailView() {

    const dispatch = useDispatch();
    const employeeState = useSelector(state => state.employee);
    const loginResponseState = useSelector(state => state.loginResponse);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);

    const employeeDetails = [
        { header: "Personal", component: <Personal /> },
        { header: "Work", component: <Work /> },
        { header: "Communication", component: <Communication /> },
        { header: "Qualification", component: <Qualification /> },
        { header: "Continuous Education", component: <ContinuousEducation /> },
        { header: "Work History", component: <WorkHistory /> }
    ];

    const handleClose = async () => {
        await dispatch(employeeRequests.updateEmployeeDetailView({ show: false, data: {} }));
    }

    return (
        <ModelBox
            Component={
                <>
                    <div className=' pb-3 bg-white rounded-md' >
                        <div className=' max-h-85vh lg:max-h-85vh md:max-h-85vh xsm:max-h-90vh overflow-auto'>
                            <div className=' w-auto my-4 px-4' >
                                {
                                    employeeDetails.map((val, index) => (
                                        <Accordion className='!m-0 !mb-1 !shadow-none !rounded-none' key={index} defaultExpanded={index <= 3}>
                                            <AccordionSummary
                                                aria-controls="panel1a-content"
                                                id="panel1a-header"
                                                className=' !border-0 !bg-lightGrey !text-black !font-fontfamily font-bold !h-10 !max-h-10 !min-h-10'
                                            >
                                                {val.header}
                                            </AccordionSummary>
                                            <AccordionDetails>{val.component}</AccordionDetails>
                                        </Accordion>
                                    ))
                                }
                            </div>
                            <div className=' flex justify-center items-center h-10 bg-white sticky z-10 bottom-0'>
                                <PrintEmployeeDetailView />
                                <span className=' mx-2 overflow-hidden h-full'><Button value={strings.Buttons.Close} onClick={handleClose} /></span>
                            </div>
                        </div>
                    </div>
                    {employeeState.loader && <TransparentLoader isFullWidth={true} />}
                    {!loginResponseState.multiDocumentViewer.show && loginResponseState.imageViewer.show && <ImageViewer />}
                    {loginResponseState.multiDocumentViewer.show && <MultiImageViewer />}
                    {apiResponseState.show && <ApiResponse />}
                </>
            }
            headerTitle={strings.header.employeeDetails}
            open={employeeState.employeeDetailView.show}
            onClose={handleClose}
        />
    )
}

export default EmployeeDetailView