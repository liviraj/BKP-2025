import PropTypes from 'prop-types';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { myRequestActions } from '../../redux/myRequestReducer';
import { useForm } from 'react-hook-form';
import { strings } from '../Constants';
import { exportDateFormat, userReducerState } from '../helper';
import { myRequestRequests } from '../requests';
import ModelBox from '../elements/ModelBox';
import Dropdown from '../elements/Dropdown';
import Label from '../elements/Label';
import TextArea from '../elements/TextArea';
import UploadAndDeleteDocument from '../elements/UploadAndDeleteDocument';
import Button from '../elements/Button';
import TransparentLoader from '../loader/TransparentLoader';
import ApiResponse from '../Alert/ApiResponse';


const MyRequestPopup = ({ setCallBack }) => {
    const dispatch = useDispatch()
    const { typeofRequest } = useSelector(state => state.myRequest);
    const { show, actions, loader, selectedRow } = useSelector(state => state.myRequest.popup)
    const { UserID } = useSelector(state => state.user)
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const { watch, setValue, handleSubmit, getValues, reset } = useForm({ defaultValues: initialValue })
    useEffect(() => {
        const initlaLoad = () => {
            reset();
            if (actions === 'Edit') {
                selectedRow.requestTypeId && setValue(strings.myRequest.typeOfRequest, typeofRequest.find(val => val.requestTypeId === selectedRow.requestTypeId));
                selectedRow.description.length && setValue(strings.myRequest.description, selectedRow.description);
                (selectedRow.imageBinary && selectedRow.imageName) && setValue(strings.myRequest.uploadFile, [{ binary: selectedRow.imageBinary, name: selectedRow.imageName }]);
            }
        }
        initlaLoad()
        return () => {
            handleClose();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    const handleClose = () => {
        dispatch(myRequestActions.resetPopup())
    }
    const onSubmit = async () => {
        await dispatch(myRequestActions.showPopup({ loader: true }))
        let data = getValues();
        const params = {
            description: data.description,
            employeeId: UserID,
            imageBinary: data.uploadFile.length ? data.uploadFile[0].binary : "",
            imageName: data.uploadFile.length ? data.uploadFile[0].name : "",
            requestTypeId: data.typeOfRequest.value
        }
        if (actions === "Add") { await dispatch(myRequestRequests.addRequest({ ...params, createdBy: UserID, createdOn: exportDateFormat(new Date()) }, setCallBack)) }
        else { await dispatch(myRequestRequests.editRequest(selectedRow?.requestId, { ...params, modifiedBy: UserID, modifiedOn: exportDateFormat(new Date()) }, setCallBack)) }
        dispatch(myRequestActions.showPopup({ loader: false }))
    }

    return (
        <div>
            <ModelBox Component={
                <>
                    <div className='xsm:min-w-[90vw] sm:min-w-[29rem] max-w-[90vw] max-h-[80vh] overflow-auto px-4 py-2'>
                        <div className='grid grid-col-12 gap-y-4 gap-x-2 items-center'>
                            <div className={`${gridFirstSectionLabel}`}><Label label={"Types of Request"} required={true} /></div>
                            <div className={gridSectionValue}><Dropdown options={typeofRequest && typeofRequest.length > 0 ? typeofRequest.filter(val => val.locationId === userReducerState().LocationID) : []} value={watch(strings.myRequest.typeOfRequest)} onChange={value => setValue(strings.myRequest.typeOfRequest, value)} isPopupView={true} /></div>
                            <div className={gridFirstSectionLabel}><Label label={"Upload File (If any)"} /></div>
                            <div className={gridSectionValue}><UploadAndDeleteDocument label="Browse" onChange={file => setValue(strings.myRequest.uploadFile, file)} file={watch(strings.myRequest.uploadFile)} /></div>
                        </div>
                        <div className=" mt-2 mb-1"><Label label={"Description"} /></div>
                        <TextArea value={watch(strings.myRequest.description)} onChange={e => setValue(strings.myRequest.description, e.target.value)} height={" h-32 text-13px tracking-normal"} />
                        <div className=' justify-center flex gap-3 mt-2'>
                            <Button value={actions === "Add" ? strings.Buttons.Submit : strings.Buttons.Update} onClick={handleSubmit(onSubmit)} disabled={!watch(strings.myRequest.typeOfRequest)} />
                            <Button value={strings.Buttons.Close} onClick={handleClose} />
                        </div>
                    </div>
                    {loader && <TransparentLoader isFullWidth={true} />}
                    {apiResponseState.show && <ApiResponse />}
                </>
            } headerTitle={actions === "Add" ? "New Request" : "Edit Request"} open={show} onClose={handleClose} />
        </div>
    );
};

export default MyRequestPopup;

MyRequestPopup.propTypes = {
    setCallBack: PropTypes.func
}

const initialValue = {
    typeOfRequest: "",
    description: "",
    uploadFile: [],
}

const gridFirstSectionLabel = "col-start-1 sm:col-end-3 xsm:col-end-13";
const gridSectionValue = "col-end-13  sm:col-start-3 xsm:col-start-1 sm:w-[300px] xsm:w-[80vw] ";