import { useDispatch, useSelector } from "react-redux"
import ModelBox from "../elements/ModelBox"
import { attendancePayrollActions } from "../../redux/AttendancePayrollReducer";
import AgGrid from "../Grid/AgGrid";
import { LeaveReportOptions } from "../helper";
import moment from "moment";
import attendanceReportImage from '../../assets/Attendance/HistoLogo.png';
import AutoSizeButton from "../elements/AutoSizeButton";
import { employeeAttendanceReport, hoursWorkedReport, leaveAvailedDetailReport } from "../elements/ExportFiles";
import { RiFileExcel2Line } from "react-icons/ri";
import Button from "../elements/Button";
import { strings } from "../Constants";


function AttendanceReportView() {

    const AttendanceReportState = useSelector(state => state.attendancePayroll.attendanceReportView)
    const dispatch = useDispatch();

    const handleClose = () => {
        dispatch(attendancePayrollActions.setAttendanceReportView({ show: false, data: [], columns: [], type: {}, header: "", excelParams: {} }));
    }

    const onhandleDownload = () => {
        if (AttendanceReportState.type.value === LeaveReportOptions[0].value) {
            employeeAttendanceReport(AttendanceReportState.data, AttendanceReportState?.excelParams?.date, AttendanceReportState?.excelParams?.fromDate, AttendanceReportState?.excelParams?.toDate);
        } else if (AttendanceReportState.type.value === LeaveReportOptions[1].value) {
            hoursWorkedReport(AttendanceReportState.data, AttendanceReportState?.excelParams?.date);
        } else {
            leaveAvailedDetailReport(AttendanceReportState.data, AttendanceReportState?.excelParams?.date, AttendanceReportState?.excelParams?.fromDate, AttendanceReportState?.excelParams?.toDate, AttendanceReportState?.excelParams?.AttendanceRunDate, AttendanceReportState?.excelParams?.LedgerRunDate);
        }
    }

    return (
        <ModelBox
            open={AttendanceReportState.show}
            headerTitle={"Attendance Report View"}
            onClose={handleClose}
            Component={
                <div className={` w-screen px-4 font-fontfamily ${AttendanceReportState.type.value !== LeaveReportOptions[2].value ? "headerCell-FullBorder gridFullBorder" : ""}`}>
                    <div className=" flex lg:flex-row xsm:flex-col flex-wrap lg:h-14 sm:h-28 items-center border-b-1 border-darkGreyBorder md:justify-between xsm:justify-center">
                        <img src={attendanceReportImage} alt='#' className="" />
                        <div className="text-headerColor tracking-wide font-bold text-center">{AttendanceReportState.header}</div>
                        <div className=" font-bold px-4">Date: {moment().format("MM/DD/YYYY")}</div>
                    </div>
                    {
                        AttendanceReportState.type.value === LeaveReportOptions[2].value && <div className=" flex items-center sm:justify-between xsm:justify-center font-bold flex-wrap py-4">
                            <span className=" text-center">Last Attendance Reviewed Date: {AttendanceReportState.excelParams?.AttendanceRunDate}</span>
                            <span className=" text-center">Last Ledger Run Date: {AttendanceReportState.excelParams?.LedgerRunDate}</span>
                        </div>
                    }
                    <AgGrid data={AttendanceReportState.data} columns={AttendanceReportState.columns} height={` ${AttendanceReportState.type.value !== LeaveReportOptions[2].value ? " lg:h-[calc(90vh-67px-24px)] sm:h-[calc(90vh-67px-6rem)] " : " lg:h-[calc(90vh-67px-24px-4rem)] sm:h-[calc(90vh-67px-6rem-4rem)] "}  xsm:h-[calc(93vh-268px-24px)]`} />
                    <div className=" flex justify-center items-center gap-4 my-2">
                        <div className=" w-52"><AutoSizeButton value={"Download Excel"} onClick={onhandleDownload} icon={<RiFileExcel2Line size={22} />} /></div>
                        <Button value={strings.Buttons.Close} onClick={handleClose} />
                    </div>
                </div>
            }
        />
    )
}

export default AttendanceReportView