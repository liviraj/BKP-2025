import PropTypes from 'prop-types';
import { useEffect, useMemo, useState } from 'react';
import DatePickerElement from '../elements/DatePickerElement';
import Label from '../elements/Label';
import TextArea from '../elements/TextArea';
import RadioButton from '../elements/RadioButton';
import CheckBox from '../elements/CheckBox';
import Dropdown from '../elements/Dropdown';
import { useForm } from "react-hook-form";
import { leaveDetails, setDefaultValue, strings, leaveType } from '../Constants';
import ModelBox from '../elements/ModelBox';
import { useDispatch, useSelector } from 'react-redux';
import { employeeRequests, leaveManagementRequest } from '../requests';
import Button from '../elements/Button';
import LeaveConfirmationView from './LeaveConfirmationView';
import { exportDateFormat, getEmployeeBasedLeaveDetails, holidayReducerState } from '../helper';
import TransparentLoader from '../loader/TransparentLoader';
import moment from 'moment-timezone';
import ApiResponse from '../Alert/ApiResponse';

function AddLeaveRequestPopup({ openAddScreen, setOpenAddScreen, filterLeaveReqQueue, type, isEditable }) {

    const userState = useSelector(state => state.user);
    const leaveManagementState = useSelector(state => state.leaveManagement);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const employeeState = useSelector(state => state.employee);

    const { watch, setValue, reset, getValues } = useForm({ defaultValues: initialState });
    let fromDate = watch(strings.leaveRequest.fromDate);
    let toDate = watch(strings.leaveRequest.toDate);
    const employeeName = watch(strings.leaveRequest.employeeName);
    const location = watch(strings.leaveRequest.location);

    const dispatch = useDispatch();
    const [loader, setLoader] = useState(false);
    const [leaveBalance, setLeaveBalance] = useState([]);

    const setCallBack = async (isSuccess) => {
        if (isSuccess) {
            await onClose();
            filterLeaveReqQueue && await filterLeaveReqQueue();
        }
    }
    const filterEmployeeNameOptn = () => {
        const locationID = location ? location.value : userState.LocationID;
        if (employeeState.employeeName.length > 0 && locationID) {
            return employeeState.employeeName.filter((val) =>
            (val.locationId === locationID &&
                (val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation))
            );
        }
        return [];
    }
    useEffect(() => {
        const componentDidMount = async () => {
            await setLoader(true);
            await Promise.all([
                setValue(strings.leaveRequest.location, isEditable ? { value: userState.LocationID } : employeeState.location.find(val => val.value === userState.LocationID)),
                leaveManagementState.leaveType.length <= 0 && dispatch(leaveManagementRequest.leaveRequest.getLeaveType(userState.LocationID)),
                !isEditable && employeeState.employeeName.length <= 0 && dispatch(employeeRequests.employeeName()),
                type && type === "sickLeave" && setValue(strings.leaveRequest.leaveType, leaveDetails[0].title),
            ]);
            if (isEditable) {
                let data = leaveManagementState?.leaveRequestQueue?.selectedRow;
                setValue(strings.leaveRequest.leaveType, Object.hasOwn(data, "leaveType") ? data.leaveType : "")
                setValue(strings.leaveRequest.fromDate, Object.hasOwn(data, "fromDate") ? data.fromDate : "")
                leaveType.halfDay === data?.leaveFromForH && setValue(strings.leaveRequest.firstHalf, data.leaveFromForH)
                setValue(strings.leaveRequest.toDate, Object.hasOwn(data, "toDate") ? data.toDate : "")
                leaveType.halfDay === data?.leaveToForH && setValue(strings.leaveRequest.secondHalf, data.leaveToForH)
                setValue(strings.leaveRequest.reason, Object.hasOwn(data, "remarks") ? data.remarks : "")
                setValue(strings.leaveRequest.employeeName, { employeeId: userState.UserID });
            }
            setLoader(false);
        }
        componentDidMount();

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onClose = () => {
        setOpenAddScreen(false);
        reset();
    }

    const onSubmitRequest = async (isLossOfPay) => {
        if (!isEditable) {
            const formatData = {
                employeeId: employeeName.value,
                isCompensatory: "",
                leaveEnteredBy: userState.UserID,
                leaveFrom: exportDateFormat(fromDate, true),
                leaveFromForH: watch(strings.leaveRequest.firstHalf) ? leaveType.halfDay : leaveType.fullDay,
                leaveTo: exportDateFormat(toDate, true),
                leaveToForH: watch(strings.leaveRequest.secondHalf) ? leaveType.halfDay : leaveType.fullDay,
                remarks: watch(strings.leaveRequest.reason),
                typeofLeave: leaveManagementState.allLeaveTypes.find(val => val.label === watch(strings.leaveRequest.leaveType)).value,
                leaveEnteredOn: exportDateFormat(new Date())
            }
            await dispatch(leaveManagementRequest.leaveRequest.addLeaveRequest(userState.UserID, { ...formatData }, isLossOfPay, setCallBack));
        }
        else {
            let data = leaveManagementState?.leaveRequestQueue?.selectedRow;
            const formatData = {
                employeeId: userState.UserID,
                isCompensatory: "",
                leaveEnteredBy: userState.UserID,
                leaveEnteredOn: exportDateFormat(new Date()),
                leaveFrom: exportDateFormat(fromDate, true),
                leaveFromForH: watch(strings.leaveRequest.firstHalf) ? leaveType.halfDay : leaveType.fullDay,
                leaveModifiedBy: userState.UserID,
                leaveRequestDetailId: data.leaveRequestId,
                leaveTo: exportDateFormat(toDate, true),
                leaveToForH: watch(strings.leaveRequest.secondHalf) ? leaveType.halfDay : leaveType.fullDay,
                modifiedOn: exportDateFormat(new Date()),
                remarks: watch(strings.leaveRequest.reason),
                status: data.approvalStatus,
                typeofLeave: leaveManagementState.allLeaveTypes.find(val => val.label === watch(strings.leaveRequest.leaveType)).value,
            }
            await dispatch(leaveManagementRequest.leaveHistory.editLeaveHistoryData(data.leaveRequestId, formatData, isLossOfPay, setCallBack))
        }
    }

    const submit = async () => {
        await setLoader(true);
        await onSubmitRequest(false);
        setLoader(false);
    }

    const setResponseCallback = async (isAcceptable) => {
        await setLoader(true);
        if (isAcceptable) {
            await onSubmitRequest(true);
        }
        setLoader(false);
    }

    const onlocationChange = (value) => {
        if (location && location.value !== value.value) {
            setValue(strings.leaveRequest.location, value);
            setValue(strings.leaveRequest.employeeName, "");
            setValue(strings.leaveRequest.leaveType, "");
            setValue(strings.leaveRequest.fromDate, "");
            setValue(strings.leaveRequest.toDate, "");
            setLeaveBalance([]);
        }
    }

    const setValidation = () => {
        let values = getValues();
        if (isEditable) {
            let isValid = false;
            let data = leaveManagementState.leaveRequestQueue.selectedRow;
            if (values[strings.leaveRequest.fromDate] && values[strings.leaveRequest.toDate] && values[strings.leaveRequest.reason] && values[strings.leaveRequest.leaveType]) {
                if (!(values[strings.leaveRequest.leaveType] === data.leaveType && exportDateFormat(values[strings.leaveRequest.fromDate], true) === exportDateFormat(data.fromDate, true) && (leaveType.halfDay === data?.leaveFromForH ? (values[strings.leaveRequest.firstHalf] === data.leaveFromForH || values[strings.leaveRequest.firstHalf] === true) : !values[strings.leaveRequest.firstHalf])
                    && exportDateFormat(values[strings.leaveRequest.toDate], true) === exportDateFormat(data.toDate, true) && (leaveType.halfDay === data?.leaveToForH ? (values[strings.leaveRequest.secondHalf] === data.leaveToForH || values[strings.leaveRequest.secondHalf] === true) : !values[strings.leaveRequest.secondHalf]) && values[strings.leaveRequest.reason] === data.remarks)) {
                    isValid = true;
                }
            }
            return isValid;
        }
        else {
            return values[strings.leaveRequest.fromDate] && values[strings.leaveRequest.toDate] && values[strings.leaveRequest.reason] && values[strings.leaveRequest.employeeName] && values[strings.leaveRequest.leaveType];
        }
    }

    const getLeaveBalanceBack = async (data) => {

        if (location.value === setDefaultValue.location.value) {
            data.privilegeLeaveDetails = data.vacationLeaveDetails;
            delete data.vacationLeaveDetails;
        }
        const keys = Object.keys(data).length > 0 ? Object.keys(data) : [];
        let chartRecord = [];
        for (const i in keys) {
            const detailKeys = leaveDetails.find(val => val.typeId === keys[i]);
            if (detailKeys) {
                let balanceDetails = data[detailKeys.typeId];
                if (balanceDetails && Object.keys(balanceDetails).length > 1) {
                    const balance = ("balance" in balanceDetails) ? balanceDetails.balance : 0;
                    const taken = ("totalDebit" in balanceDetails) ? balanceDetails.totalDebit : 0;
                    chartRecord = [...chartRecord, { ...detailKeys, data: [{ requestType: `Available ${balance}`, value: balance }, { requestType: `Taken ${taken}`, value: taken }] }]
                }
            }
        }
        await setLeaveBalance(chartRecord);

    }
    const handleEmployeeName = async (e) => {
        if (!employeeName || employeeName.employeeId !== e.employeeId) {
            setLoader(true);
            setValue(strings.leaveRequest.employeeName, e);
            await Promise.all([
                dispatch(leaveManagementRequest.leaveRequest.getLeaveBalance(e.employeeId, getLeaveBalanceBack)),
                getEmployeeBasedLeaveDetails(e.employeeId, location.value, new Date())
            ]);
            setValue(strings.leaveRequest.fromDate, "");
            setValue(strings.leaveRequest.toDate, "");
            setLoader(false);
        }
    }

    const onDateChange = async (date, type) => {
        setLoader(true);
        await getEmployeeBasedLeaveDetails(employeeName.employeeId, location.value, date);
        setValue(type, date);
        setLoader(false);
    }

    const disableHolidays = useMemo(() => {
        if (employeeName && holidayReducerState().employeeBasedHolidays.length > 0) {
            let employeeHolidays = holidayReducerState().employeeBasedHolidays;
            if (employeeHolidays && employeeHolidays.length > 0) {
                const validData = employeeHolidays.find(val => val.empId === employeeName.employeeId);
                if (validData) {
                    return validData.holidays;
                }
            }
        }
        return [];
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [holidayReducerState().employeeBasedHolidays, employeeName, location, toDate, fromDate]);

    return (
        <div>
            <ModelBox Component={
                <>
                    <div className="px-6 font-fontfamily font-bold tracking-wide text-14px grid grid-cols-12 h-[calc(100vh-150px)] lg:h-auto overflow-auto">
                        <div className={` col-start-1 col-end-13 lg:col-end-13 md:col-end-13 xsm:col-end-13 my-2 font-fontfamily font-bold`}>
                            <div className=' my-5'>
                                <div className='grid lg:grid-flow-col gap-x-10 my-2'>
                                    <div className='grid lg:col-start-1 lg:col-span-6 order-2 lg:w-[19rem] w-full' >
                                        {isEditable || <>
                                            {userState.Role === strings.userRoles.humanResource || <>
                                                <Label label={"Location"} required={true} />
                                                <div className=' grid lg:grid-cols-1 md:grid-cols-1 sm:grid-cols-1 xsm:grid-cols-1 mb-4 mt-2 gap-x-10 gap-y-2'>
                                                    <Dropdown value={location} onChange={onlocationChange} options={employeeState.location ? employeeState.location.filter(val => val.value > 0) : []} isRequired={true} />
                                                </div>
                                            </>
                                            }
                                            <Label label={"Employee Name"} required={true} />
                                            <div className=' grid lg:grid-cols-1 md:grid-cols-1 sm:grid-cols-1 xsm:grid-cols-1 mb-4 mt-2 gap-x-10 gap-y-2'>
                                                <Dropdown value={employeeName} onChange={(e) => handleEmployeeName(e)} options={filterEmployeeNameOptn()} isSearchable={true} isRequired={true} />
                                            </div>
                                        </>}
                                    </div>
                                    <div className='grid lg:col-start-7 lg:col-span-6 order-1 mb-4 lg:mb-0 w-full items-start justify-center'>
                                        {(!isEditable && leaveBalance.length) ? <div className='p-3 shadow-boxShadow shadow-md box-shadow border-white bg-white  border-1 rounded font-medium text-[15px] flex items-center justify-center flex-col gap-1 w-fit h-fit'>
                                            <h3 className='text-[16px] font-bold mb-3'>Leave Balance</h3>
                                            {leaveBalance?.length > 0 && leaveBalance.map((val, key) => {
                                                return (
                                                    <p className='flex justify-center w-full' key={key}><span className={`${location && location.value === setDefaultValue.location.value ? "w-[135px]" : "w-[100px]"} text-right`}>{val.title} : </span><span className='font-bold w-[55px] pl-1'>{(val.data[0].value) % 1 === 0 ? val.data[0].value : (val.data[0].value).toFixed(2)}</span></p>
                                                )
                                            })}
                                        </div> : ""}
                                    </div>
                                </div>
                                <Label label={"Leave Type"} required={true} addStyle={type && type === "sickLeave" ? "opacity-60" : ""} />
                                <RadioButton options={isEditable ? leaveManagementState.allLeaveTypes.filter(val => val.locationId === userState.LocationID).map(val => val.label) : location ? leaveManagementState.allLeaveTypes.filter(val => val.locationId === location.value).map(val => val.label) : []} value={watch(strings.leaveRequest.leaveType)} onChange={e => setValue(strings.leaveRequest.leaveType, e.target.value)} disabled={type && type === "sickLeave"} />
                                <div className=' grid lg:grid-cols-3 md:grid-cols-2 sm:grid-cols-1 xsm:grid-cols-1 my-4 gap-x-10 gap-y-2'>
                                    <div>
                                        <Label label={"From"} required={true} />
                                        <DatePickerElement value={fromDate} onChange={date => { onDateChange(date, strings.leaveRequest.fromDate); if (date && toDate && moment(date).format("MM/DD/YYYY") === moment(toDate).format("MM/DD/YYYY") && watch(strings.leaveRequest.secondHalf) && watch(strings.leaveRequest.firstHalf)) { setValue(strings.leaveRequest.secondHalf, false); setValue(strings.leaveRequest.firstHalf, false) } }} isWeekday={true} maxDate={toDate} disableHolidays={disableHolidays} />
                                        <CheckBox data={[{ label: "Half Day" }]} value={watch(strings.leaveRequest.firstHalf)} onChange={e => { setValue(strings.leaveRequest.firstHalf, e.target.checked); if (fromDate && toDate && moment(fromDate).format("MM/DD/YYYY") === moment(toDate).format("MM/DD/YYYY") && watch(strings.leaveRequest.secondHalf)) { setValue(strings.leaveRequest.secondHalf, false) } }} />
                                    </div>
                                    <div>
                                        <Label label={"To"} required={true} />
                                        <DatePickerElement value={toDate} onChange={date => { onDateChange(date, strings.leaveRequest.toDate); if (fromDate && date && moment(fromDate).format("MM/DD/YYYY") === moment(date).format("MM/DD/YYYY") && watch(strings.leaveRequest.secondHalf) && watch(strings.leaveRequest.firstHalf)) { setValue(strings.leaveRequest.secondHalf, false); setValue(strings.leaveRequest.firstHalf, false) } }} minDate={fromDate} isWeekday={true} disableHolidays={disableHolidays} />
                                        <CheckBox data={[{ label: "Half Day" }]} value={watch(strings.leaveRequest.secondHalf)} onChange={e => { setValue(strings.leaveRequest.secondHalf, e.target.checked); if (fromDate && toDate && moment(fromDate).format("MM/DD/YYYY") === moment(toDate).format("MM/DD/YYYY") && watch(strings.leaveRequest.firstHalf)) { setValue(strings.leaveRequest.firstHalf, false) } }} />
                                    </div>
                                </div>
                                <Label label={"Reason"} required={true} />
                                <TextArea height={" h-40"} isRequired={true} value={watch(strings.leaveRequest.reason)} onChange={e => setValue(strings.leaveRequest.reason, e.target.value)} />
                            </div>
                        </div>
                    </div>
                    <div className="justify-center flex flex-row gap-3 sm:flex-row mb-3">
                        <Button value={isEditable ? 'Update Leave Request' : 'Apply Leave'} disabled={!setValidation()} onClick={() => setValue(strings.leaveRequest.showConfirmPopup, true)} />
                        <Button value={strings.Buttons.Close} onClick={onClose} />
                    </div>
                    <LeaveConfirmationView titleName={employeeName.label} onSubmit={() => { setValue(strings.leaveRequest.showConfirmPopup, false); submit(); }} show={watch(strings.leaveRequest.showConfirmPopup)} onClose={() => setValue(strings.leaveRequest.showConfirmPopup, false)}
                        data={{
                            fromDate: watch(strings.leaveRequest.fromDate),
                            toDate: watch(strings.leaveRequest.toDate),
                            firstHalf: watch(strings.leaveRequest.firstHalf),
                            secondHalf: watch(strings.leaveRequest.secondHalf),
                            disableHolidays: disableHolidays
                        }}
                    />
                    {loader && <TransparentLoader isFullWidth={true} />}
                    {apiResponseState.show && <ApiResponse setResponseCallback={setResponseCallback} />}
                </>
            } headerTitle={type && type === "sickLeave" ? 'Add Sick Leave Request' : (isEditable ? 'Edit Leave Request' : 'Add Leave Request')} open={openAddScreen} onClose={onClose} />
        </div>
    )
}

const initialState = {
    employeeName: "",
    leaveType: "",
    fromDate: "",
    toDate: "",
    firstHalf: "",
    secondHalf: "",
    reason: "",
    location: "",
    showConfirmPopup: false,
}


export default AddLeaveRequestPopup;

AddLeaveRequestPopup.propTypes = {
    openAddScreen: PropTypes.bool,
    setOpenAddScreen: PropTypes.func,
    filterLeaveReqQueue: PropTypes.func,
    type: PropTypes.string,
    isEditable: PropTypes.bool
}