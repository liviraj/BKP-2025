import { useDispatch, useSelector } from "react-redux";
import ModelBox from "../elements/ModelBox";
import Button from "../elements/Button";
import TransparentLoader from "../loader/TransparentLoader";
import { attendancePayrollActions } from "../../redux/AttendancePayrollReducer";
import { useForm } from "react-hook-form";
import { routerPath, strings } from "../Constants";
import TextField from "../elements/TextField";
import Label from "../elements/Label";
import { useEffect, useState } from "react";
import { exportDateFormat } from "../helper";
import { payrollRequest } from "../requests";
import PropTypes from "prop-types";
import { useHistory } from 'react-router-dom';
import { leaveManagementActions } from "../../redux/leaveManagementReducer";
import { userActions } from "../../redux/userReducer";


const ValidateLeaveBalance = ({ updateAuditor }) => {
    const history = useHistory();
    const dispatch = useDispatch()
    const { validateLeaveBalancePopup, loader } = useSelector(state => state.attendancePayroll);
    const userState = useSelector(state => state.user);
    const [isEdited, setIsEdited] = useState(false)

    const { watch, setValue, getValues } = useForm({ defaultValues: initialState })
    const handleClose = () => {
        dispatch(attendancePayrollActions.setValidateLeaveBalance({ show: false, data: [] }))
    }

    useEffect(() => {
        handleReset()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    const handleReset = () => {
        const data = validateLeaveBalancePopup.popupData
        setValue(strings.validateLeaveBalacePopup.employeeName, data.employeeName)
        setValue(strings.validateLeaveBalacePopup.auditorPrivilegeLeaveBalance, data.auditorDocLeaveBalance)
        setValue(strings.validateLeaveBalacePopup.systemPrivilegeLeaveBalance, data.ledgerLeaveBalance)
    }
    const handleSave = async () => {
        await dispatch(attendancePayrollActions.setLoader(true));
        let data = validateLeaveBalancePopup.popupData;
        let value = getValues()
        let params = {
            "closing": value.auditorPrivilegeLeaveBalance ? value.auditorPrivilegeLeaveBalance : data.auditorDocLeaveBalance,
            "documentId": data.documentId,
            "modifiedBy": userState.UserID,
            "modifiedOn": exportDateFormat(new Date())
        }
        await dispatch(payrollRequest.editUploadAuditor(data.documentId, params, setCallBack))
        dispatch(attendancePayrollActions.setLoader(false));
    }
    const setCallBack = async (status) => {
        if (status) {
            await handleClose();
            await updateAuditor()
        }
    }
    const handleNavigate = async () => {
        let data = validateLeaveBalancePopup.popupData;
        await handleClose();
        await dispatch(leaveManagementActions.setLeaveLedgerIsUPloadAuditorEdit({ show: true, employeeId: data.employeeId, fromDate: data.fromDate, toDate: data.toDate, leaveType: data.leaveTypeId }))
        history.push(routerPath.leaveLedger);
        await dispatch(userActions.setSidebarExpand({ isExpand: true, type: "leaveManagement" }));
    }
    return (
        <ModelBox Component={
            <>
                <div className="xsm:w-[90vw] md:w-[47rem] max-h-[85vh] overflow-auto sm:px-8 xsm:px-4 bg-white">
                    <div className=" grid md:grid-cols-2 pt-4 gap-3 grid-cols-1 text-14px">
                        <div className=" flex items-center"><Label label="Employee Name" required={true} /> </div>
                        <div> <TextField value={watch(strings.validateLeaveBalacePopup.employeeName)} onChange={e => setValue(strings.validateLeaveBalacePopup.employeeName, e.target.value)} placeholder="Enter Employee Name" isRequired={true} isDisable={true} /> </div>
                        <div className=" flex items-center"><Label label={`Auditor Document ${validateLeaveBalancePopup.popupData?.leaveTypeName ? validateLeaveBalancePopup.popupData.leaveTypeName : ''} Balance`} required={true} />  </div>
                        <div> <TextField value={watch(strings.validateLeaveBalacePopup.auditorPrivilegeLeaveBalance)} onChange={e => { setValue(strings.validateLeaveBalacePopup.auditorPrivilegeLeaveBalance, e.target.value); setIsEdited(true); }} placeholder="Enter Auditor Priviledge Leave Balance" isRequired={true} isNumField={true} /> </div>
                        <div className=" flex items-center"><Label label={`System ${validateLeaveBalancePopup.popupData?.leaveTypeName ? validateLeaveBalancePopup.popupData.leaveTypeName : ''} Balance`} required={true} />  </div>
                        <div> <TextField value={watch(strings.validateLeaveBalacePopup.systemPrivilegeLeaveBalance)} onChange={e => setValue(strings.validateLeaveBalacePopup.systemPrivilegeLeaveBalance, e.target.value)} placeholder="Enter System Priviledge Leave Balance" isRequired={true} isNumField={true} isDisable={true} /> </div>
                    </div>
                    <div className="  text-15px mt-3 text-center sm:text-right">
                        Unable to edit the <span className=" font-bold">System {validateLeaveBalancePopup.popupData?.leaveTypeName} Balance </span>
                        <div className="text-blue-600 underline mt-1 cursor-pointer" onClick={handleNavigate}>Click here to navigate to the <span className=" font-bold">View & Edit Leave Ledger screen</span> to update the details</div>
                    </div>
                    <footer className="flex flex-wrap gap-4 justify-center mt-7 mb-2 sticky z-0 bottom-0 bg-white gap-y-0">
                        <Button value={strings.Buttons.Save} onClick={handleSave} disabled={!(watch(strings.validateLeaveBalacePopup.auditorPrivilegeLeaveBalance) && isEdited)} />
                        <Button value={strings.Buttons.Reset} onClick={handleReset} disabled={!isEdited} />
                        <Button value={strings.Buttons.Close} onClick={handleClose} />
                    </footer>
                </div>
                {loader && <TransparentLoader isFullWidth />}
            </>
        } headerTitle={'Validate Leave Balance'} open={validateLeaveBalancePopup.show} onClose={handleClose} />
    );
};

export default ValidateLeaveBalance;

const initialState = {
    employeeName: "",
    auditorPrivilegeLeaveBalance: "",
    systemPrivilegeLeaveBalance: "",
}
ValidateLeaveBalance.propTypes = {
    updateAuditor: PropTypes.func
}