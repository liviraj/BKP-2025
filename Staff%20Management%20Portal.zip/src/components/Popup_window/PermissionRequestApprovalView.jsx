import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import ModelBox from "../elements/ModelBox";
import Label from "../elements/Label";
import TextArea from "../elements/TextArea";
import Button from "../elements/Button";
import { permissionAction } from "../../redux/permissionReducer";
import { dateFormat, exportDateFormat, permissionReducerState, timeFormat } from "../helper";
import PropTypes from 'prop-types';
import { status, strings } from "../Constants";
import TransparentLoader from "../loader/TransparentLoader";
import { permissionRequests } from "../requests";
import ApiResponse from "../Alert/ApiResponse";

const PermissionRequestApprovalView = ({ onSubmit }) => {

    const userState = useSelector(state => state.user);
    const [loader, setLoader] = useState(false);
    const [comments, setComments] = useState("");
    const dispatch = useDispatch()

    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const { show, selectedRowData, requestStatus } = useSelector(state => state.permission.requestApprovalPopup);

    const handleClose = async () => {
        await dispatch(permissionAction.setRequestApprovalPopup({ show: false, requestStatus: '', selectedRowData: {} }))
    }

    const setResponseBack = async () => {
        await handleClose();
        await onSubmit();
    }

    const onConfirm = async (type) => {
        await setLoader(true);
        await dispatch(permissionAction.setRequestApprovalPopup({ requestStatus: type }));
        await onRequestAPIService(false);
        setLoader(false);
    }
    const onRequestAPIService = async (isAdditionalPermission) => {
        let params = {
            comments: comments,
            permissionId: selectedRowData && Object.hasOwn(selectedRowData, "permissionID") ? selectedRowData.permissionID : '',
            status: permissionReducerState().requestApprovalPopup.requestStatus,
            isAdditionalPermission
        }
        if (permissionReducerState().requestApprovalPopup.requestStatus === status.tobeCancelled) {
            params = { ...params, modifiedBy: userState.UserID, modifiedOn: exportDateFormat(new Date()) }
        } else {
            params = { ...params, reviewedBy: userState.UserID, reviewedOn: exportDateFormat(new Date()) }
        }
        await dispatch(permissionRequests.permissionApproveOrRejectRequest(params, setResponseBack));
    }

    const reConfirmRequest = async (isAcceptable) => {
        setLoader(true);
        if (isAcceptable) {
            await onRequestAPIService(true);
        }
        setLoader(false);
    }

    return (
        <ModelBox open={show} onClose={handleClose} Component={<>
            <div>
                <div className=' w-[28rem] md:w-[28rem] sm:w-[90vw] xsm:w-[90vw] m-4 tracking-wide'>
                    {requestStatus !== status.tobeCancelled && <div className='font-fontfamily font-bold pb-1'>
                        <span className=' text-15px'>Employee Name : </span>
                        <span className=' text-headerColor text-14px uppercase'>{selectedRowData?.employeeName}</span>
                    </div>}
                    <div className='font-fontfamily font-bold pb-1'><span className='text-blackColor text-15px'>Permission Type   <span>:</span></span>
                        <span className='font-normal text-14px'>  {selectedRowData?.permissionType ? selectedRowData?.permissionType : ""}</span>
                    </div>
                    <div className='font-fontfamily font-bold pb-1'><span className='text-blackColor text-15px'>Permission Date : </span>
                        <span className='font-normal text-14px'> {dateFormat(selectedRowData.fromTime)} </span>
                    </div>
                    <div className='font-fontfamily font-bold pb-1'><span className='text-blackColor text-15px'>Start Time  : </span>
                        <span className='font-normal text-14px'> {timeFormat(selectedRowData.fromTime)} </span>
                    </div>
                    <div className='font-fontfamily font-bold pb-1'><span className='text-blackColor text-15px inline-flex w-[89px] justify-between pr-[3px]'>End Time    <span>:</span></span>
                        <span className='font-normal text-14px'>  {timeFormat(selectedRowData.toTime)}</span>
                    </div>
                    <div className='mb-3'>
                        <Label label={requestStatus === status.tobeCancelled ? "Reason" : "Comments :"} addStyle={'font-bold text-15px'} setBold={true} required={requestStatus === status.tobeCancelled} />
                        <TextArea height={" h-20 text-13px tracking-normal"} value={comments} onChange={e => setComments(e.target.value)} />
                    </div>

                    <div className="justify-center flex flex-row gap-3 sm:flex-row mb-3" >
                        {(requestStatus === status.tobeCancelled || requestStatus === status.cancel)
                            ? <div className=' gap-x-3 flex'>
                                {requestStatus !== status.tobeCancelled
                                    ? <Button value={'Cancel Permission Request'} onClick={async () => onConfirm(status.cancel)} />
                                    : <Button value={'Cancel Permission Request'} disabled={!comments} onClick={async () => onConfirm(status.tobeCancelled)} />
                                }
                            </div>
                            : <div className=' gap-x-3 flex'>
                                <Button value={strings.Buttons.approve} onClick={() => onConfirm(status.approved)} />
                                <Button value={strings.Buttons.reject} onClick={() => onConfirm(status.reject)} />
                            </div>
                        }
                        <Button value={strings.Buttons.Close} onClick={() => { handleClose() }} />
                    </div>
                </div>
            </div>
            <>
                {loader && <TransparentLoader isFullWidth={true} />}
                {apiResponseState.show && <ApiResponse setResponseCallback={reConfirmRequest} />}
            </>
        </>} headerTitle={"Permission Request Details"} />
    );
};

export default PermissionRequestApprovalView;

PermissionRequestApprovalView.propTypes = {
    onSubmit: PropTypes.func
}