import ModelBox from '../elements/ModelBox'
import { useDispatch, useSelector } from 'react-redux'
import { eventManagementActions } from '../../redux/eventManagementReducer';
import { ViewComponentDesign } from '../helper';
import { generateSummary } from '../Grid/Columns'
import AgGrid from '../Grid/AgGrid';
import ImageViewer from '../ViewDocs/ImageViewer';

function GenerateSummaryDocumentView() {
    const generateSummaryDocumentViewState = useSelector(state => state.eventManagement.generateSummaryDocumentView);
    const loginResponseState = useSelector(state => state.loginResponse);
    const generateSummaryState = useSelector(state => state.eventManagement.generateSummary);
    const dispatch = useDispatch();

    const onClose = () => {
        dispatch(eventManagementActions.setGenerateSummaryDocumentView({ show: false, selectedRow: {}, filterParams: {}, data: [] }));
    }

    return (
        <ModelBox
            Component={<>
                <div className='  mx-4 my-3 md:w-[90vw] xsm:w-[90vw] tracking-wide'>
                    <div className=' md:w-[30rem] xsm:w-[90vw] grid grid-cols-12'>
                        <ViewComponentDesign label={"Name"} value={("Ename" in generateSummaryState.employeeDetails[0]) && generateSummaryState.employeeDetails[0].Ename ? generateSummaryState.employeeDetails[0].Ename : ""} setValueBold={true} />
                        <ViewComponentDesign label={"Position"} value={("Designation" in generateSummaryState.employeeDetails[0]) && generateSummaryState.employeeDetails[0].Designation ? generateSummaryState.employeeDetails[0].Designation : ""} />
                        <ViewComponentDesign label={"Program"} value={("Program" in generateSummaryDocumentViewState.selectedRow) && generateSummaryDocumentViewState.selectedRow.Program ? generateSummaryDocumentViewState.selectedRow.Program : ""} />
                        <ViewComponentDesign label={"Participation Hours"} value={("PartHrs" in generateSummaryDocumentViewState.selectedRow) && generateSummaryDocumentViewState.selectedRow.PartHrs ? generateSummaryDocumentViewState.selectedRow.PartHrs : ""} />
                        <ViewComponentDesign label={"Approved by ASHI?"} value={("AbhiApproval" in generateSummaryDocumentViewState.selectedRow) && generateSummaryDocumentViewState.selectedRow.AbhiApproval ? (generateSummaryDocumentViewState.selectedRow.AbhiApproval === "Y" ? "Yes" : generateSummaryDocumentViewState.selectedRow.AbhiApproval) : ""} />
                        <ViewComponentDesign label={"Participation Level"} value={("PartLevel" in generateSummaryDocumentViewState.selectedRow) && generateSummaryDocumentViewState.selectedRow.PartLevel ? generateSummaryDocumentViewState.selectedRow.PartLevel : ""} />
                        <ViewComponentDesign label={"Content"} value={""} />
                    </div>
                    <div>
                        <AgGrid columns={generateSummary.documentView} data={generateSummaryDocumentViewState.data} height={" h-[55vh] "} />
                    </div>
                </div>
                <>
                    {loginResponseState.imageViewer.show && <ImageViewer />}
                </>
            </>}
            headerTitle={`Document View`} open={generateSummaryDocumentViewState.show} onClose={onClose} />
    )
}

export default GenerateSummaryDocumentView