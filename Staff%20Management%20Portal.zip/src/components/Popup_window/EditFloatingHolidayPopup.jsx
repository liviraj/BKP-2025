import { useDispatch, useSelector } from "react-redux";
import Button from "../elements/Button"
import ModelBox from "../elements/ModelBox"
import TransparentLoader from "../loader/TransparentLoader"
import { useEffect, useMemo, useState } from "react";
import ApiResponse from "../Alert/ApiResponse";
import { holidayActions } from "../../redux/holidayReducer";
import { useForm } from "react-hook-form";
import { strings } from "../Constants";
import RadioButton from "../elements/RadioButton";
import { compareFloatingHolidayList, exportDateFormat } from "../helper";
import { holidayRequests } from "../requests";
import propTypes from 'prop-types';

function EditFloatingHolidayPopup({ resetFloatingHolidayDetails }) {

    const [loader, setLoader] = useState(false);
    const { watch, setValue, reset, handleSubmit } = useForm({ defaultValues: initialState });
    const floatingHoliday = watch(strings.editFloatingHolidayPopup.floatingHolidayList);

    const userState = useSelector(state => state.user);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const editFloatingHolidayPopupState = useSelector(state => state.holiday.addFloatingHolidayList.popup);
    const dispatch = useDispatch();

    useEffect(() => {
        const initialLoad = () => {
            setLoader(true);
            onResetValue();
            setLoader(false);
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const sortRecord = (record) => {
        return record && record.length > 0 && record.every(val => val.length > 0) ? record.sort((a, b) => a[0].sortIndex - b[0].sortIndex) : record;
    }

    const onResetValue = () => {
        const selectedRow = editFloatingHolidayPopupState.selectedRecord;
        if (selectedRow && Object.keys(selectedRow).length > 0) {
            reset();
            setValue(strings.editFloatingHolidayPopup.employeeName, { label: selectedRow.employeeName, value: selectedRow.employeeId });
            setValue(strings.editFloatingHolidayPopup.floatingHolidayList, sortRecord(structuredClone(selectedRow.floatingHolidays)));
        }
    }

    const onClose = () => {
        dispatch(holidayActions.setAddFloatingHolidayPopup({ show: false, action: "", selectedRecord: {} }));
    }

    const onSubmit = async (data) => {
        setLoader(true);
        let tempData = [];
        const selectedFloatingHolidays = sortRecord(structuredClone(editFloatingHolidayPopupState.selectedRecord.floatingHolidays));
        if (selectedFloatingHolidays.length > 0) {
            for (const firstIndex in data.floatingHolidayList) {
                for (const secondIndex in data.floatingHolidayList[firstIndex]) {
                    const firstObj = data.floatingHolidayList[firstIndex][secondIndex];
                    const secondObj = selectedFloatingHolidays[firstIndex][secondIndex];
                    if (!!(firstObj.isUsed) !== !!(secondObj.isUsed) && firstObj.isUsed) {
                        tempData = [...tempData, { ...firstObj, isUsed: !!(firstObj.isUsed) }];
                    }
                }
            }
        }
        const params = {
            modifiedByEmpId: userState.UserID,
            modifiedOn: exportDateFormat(new Date()),
            employeeId: data.employeeName.value,
            holidayIdDetailsList: tempData,
        }
        await dispatch(holidayRequests.setFloatingHolidayPopup.saveFloatingHolidayDetails(params, async () => {
            await onClose();
            await resetFloatingHolidayDetails();
        }))
        setLoader(false);
    }

    const onRadioBtnUpdate = (idx, value) => {
        let tempFloatingHoliday = [...floatingHoliday];
        tempFloatingHoliday[idx] = tempFloatingHoliday[idx].map(val => {
            if (val.holidayName === value) {
                return { ...val, isUsed: true }
            }
            return { ...val, isUsed: false }
        });
        setValue(strings.editFloatingHolidayPopup.floatingHolidayList, tempFloatingHoliday);
    }

    const disableButton = useMemo(() => {
        return compareFloatingHolidayList(sortRecord(structuredClone(editFloatingHolidayPopupState.selectedRecord.floatingHolidays)), floatingHoliday)
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [floatingHoliday]);

    return (
        <ModelBox Component={
            <>
                <div className="xsm:w-[90vw] lg:w-[40rem] w-[90vw] max-h-[85vh] overflow-auto sm:px-8 xsm:px-4 sm:py-4 xsm:py-2 bg-white">
                    <div className=" grid grid-cols-12 font-fontfamily gap-x-2">
                        <div className=" col-start-1 md:col-end-4 sm:col-end-5 xsm:col-end-12 flex md:justify-evenly"><span className=' text-15px font-bold xsm:mr-2 md:mr-2'>Employee Name  </span>:</div>
                        <div className=" md:col-start-4 sm:col-start-5 xsm:col-start-3 col-end-12"><span className=' text-14px uppercase font-bold'>{watch(strings.editFloatingHolidayPopup.employeeName)?.label}</span></div>
                        <div className=" col-start-1 md:col-end-4 xsm:col-end-12 flex md:justify-evenly mt-2"><span className=' text-15px font-bold xsm:mr-2 md:mr-0'>Floating Holidays  </span>:</div>
                        <div className=" md:col-start-4 xsm:col-start-2 col-end-12">
                            {
                                floatingHoliday?.length > 0 && floatingHoliday.map((list, idx) =>
                                    <div key={idx} className="flex flex-wrap w-full">
                                        <RadioButton options={list.map(val => val.holidayName)} value={list.find(val => val.isUsed) ? list.find(val => val.isUsed).holidayName : ""} onChange={e => onRadioBtnUpdate(idx, e.target.value)} customColor={editFloatingHolidayPopupState.selectedRecord[`${list[0].holidayName}Color`]} />
                                    </div>
                                )
                            }
                        </div>
                    </div>
                    <footer className="flex flex-wrap gap-4 justify-center mt-7 sticky z-0 bottom-0 bg-white">
                        <Button value={strings.Buttons.Update} onClick={handleSubmit(onSubmit)} disabled={disableButton} />
                        <Button value={strings.Buttons.Reset} onClick={onResetValue} disabled={disableButton} />
                        <Button value={strings.Buttons.Close} onClick={onClose} />
                    </footer>
                </div>
                <>
                    {loader && <TransparentLoader isFullWidth />}
                    {apiResponseState.show && <ApiResponse />}
                </>
            </>
        } headerTitle={`Edit Floating Holidays`} open={editFloatingHolidayPopupState.show} onClose={onClose} />
    )
}

export default EditFloatingHolidayPopup

EditFloatingHolidayPopup.propTypes = {
    resetFloatingHolidayDetails: propTypes.func
}

const initialState = {
    employeeName: "",
    floatingHolidayList: []
}