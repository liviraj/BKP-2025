import { useEffect, useState, useMemo } from "react";
import { useDispatch, useSelector } from "react-redux"
import { useForm } from "react-hook-form";
import ModelBox from "../elements/ModelBox"
import Label from "../elements/Label";
import Button from "../elements/Button";
import { strings } from "../Constants";
import TransparentLoader from "../loader/TransparentLoader";
import ApiResponse from "../Alert/ApiResponse";
import TextField from "../elements/TextField";
import { departmentActions } from "../../redux/departmentReducer";
import { exportDateFormat, userReducerState } from "../helper";
import { departmentRequest } from "../requests";
import PropTypes from "prop-types";
import TextArea from "../elements/TextArea";

function DepartmentPopup({ setCallBack }) {

    const departmentPopupState = useSelector(state => state.department?.departmentNamePopup);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const dispatch = useDispatch();
    const [loader, setLoader] = useState(false);
    const { watch, setValue, getValues, reset } = useForm({ defaultValues: initialState });
    const departmentName = watch(strings.departmentNamePopup.departmentName);
    const description = watch(strings.departmentNamePopup.description);
    const value = getValues();
    const data = departmentPopupState.selectedRow;

    useEffect(() => {
        const initialLoad = async () => {
            setLoader(true);
            await onResetValue();
            setLoader(false);
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onResetValue = async () => {
        setLoader(true);
        if (departmentPopupState.action !== "Add") {
            setValue(strings.departmentNamePopup.departmentName, data?.departmentName ? data.departmentName : '');
            setValue(strings.departmentNamePopup.description, data?.description ? data.description : '');
        } else {
            await reset();
        }
        setLoader(false);
    }

    const handleSave = async () => {
        setLoader(true);
        const data = getValues();
        let params = {
            departmentName: data.departmentName,
            description: data.description,
            departmentId: 0
        }
        if (departmentPopupState.action === "Edit") {
            params = { ...params, modifiedBy: userReducerState().UserID, modifiedDate: exportDateFormat(new Date()), departmentId: departmentPopupState.selectedRow?.id }
            await dispatch(departmentRequest.departmentScreenRequest.getEditDepartmentRequest(departmentPopupState.selectedRow?.id, params, setCallBack));
        } else {
            params = { ...params, createdBy: userReducerState().UserID, createdDate: exportDateFormat(new Date()) }
            await dispatch(departmentRequest.departmentScreenRequest.addDepartmentRequest(params, setCallBack));
        }
        setLoader(false);
    }

    const onClose = () => {
        dispatch(departmentActions.setDepartmentNamePopup({ show: false, action: "", selectedRecord: {} }));
    }

    const isFormDisable = useMemo(() => {
        if (departmentPopupState.action === 'Edit') {
            return !(value[strings.departmentNamePopup.departmentName] === data?.departmentName && value[strings.departmentNamePopup.description] === data?.description);
        }
        return !!(value[strings.departmentNamePopup.departmentName] && value[strings.departmentNamePopup.description]);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [departmentPopupState.action, value]);

    const isResetDisable = useMemo(() => {
        if (departmentPopupState.action === 'Edit') {
            return value[strings.departmentNamePopup.departmentName] === data?.departmentName && value[strings.departmentNamePopup.description] === data?.description;
        }
        return !(value[strings.departmentNamePopup.departmentName] || value[strings.departmentNamePopup.description]);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [departmentPopupState.action, value]);

    return (
        <ModelBox Component={
            <>
                <div className="xsm:w-[90vw] sm:w-[30rem] max-h-[85vh] overflow-auto sm:px-8 xsm:px-4 sm:pb-4 sm:pt-2 xsm:py-2 bg-white">
                    <div className=" grid grid-cols-12 gap-2">
                        <div className=" col-start-1 col-end-13 flex items-center gap-2 flex-wrap ">
                            <div className=" flex gap-1 items-end font-bold relative "> <Label label={"Department Name"} setBold />:</div>
                        </div>
                        <div className=" col-start-1 col-end-13">
                            <TextField value={departmentName} onChange={e => setValue(strings.departmentNamePopup.departmentName, e.target.value)} isDisable={departmentPopupState.action === "View"} />
                        </div>
                        <div className=" col-start-1 col-end-13 flex items-center gap-2 flex-wrap mt-3">
                            <div className=" flex gap-1 items-end font-bold"> <Label label={"Description"} setBold />:</div>
                        </div>
                        <div className=" col-start-1 col-end-13">
                            <TextArea height={" h-40"} value={description} onChange={e => setValue(strings.departmentNamePopup.description, e.target.value)} isDisable={departmentPopupState.action === "View"} /></div>
                    </div>
                    <footer className="flex flex-wrap xsm:gap-2 sm:gap-4 justify-center mt-4 sticky z-0 bottom-0 bg-white">
                        {departmentPopupState.action !== 'View' && <Button value={departmentPopupState.action === 'Add' ? strings.Buttons.Save : strings.Buttons.Update} disabled={!isFormDisable} onClick={handleSave} />}
                        {departmentPopupState.action !== 'View' && <Button value={strings.Buttons.Reset} disabled={isResetDisable} onClick={onResetValue} />}
                        <Button value={strings.Buttons.Close} onClick={onClose} />
                    </footer>
                </div>
                <>
                    {loader && <TransparentLoader isFullWidth />}
                    {apiResponseState.show && <ApiResponse />}
                </>
            </>
        } headerTitle={`${departmentPopupState.action} Department`} open={departmentPopupState.show} onClose={onClose} />
    )
}

export default DepartmentPopup

DepartmentPopup.propTypes = {
    setCallBack: PropTypes.func
}

const initialState = {
    departmentName: "",
    description: ""
}
