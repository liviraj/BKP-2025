import { useDispatch, useSelector } from "react-redux";
import ModelBox from "../elements/ModelBox";
import Button from "../elements/Button";

import { complianceReportActions } from "../../redux/complianceReportReducer";
import { complianceReport } from "../Grid/Columns";
import AgGrid from "../Grid/AgGrid";
import { reportRequest } from "../requests";
import { useState } from "react";
import TransparentLoader from "../loader/TransparentLoader";
import { complainceReportReducerState } from "../helper";
import moment from "moment-timezone";
import { strings } from "../Constants";


const ComplianceNotifyMailPopup = () => {
    const dispatch = useDispatch()
    const complianceNotifyMail = useSelector(state => state.complianceReport.complianceNotifyMailDetails);
    const [loader, setLoader] = useState(false);
    const labelClass = 'col-start-1 col-end-5 xl:col-end-2 lg:col-end-3 md:col-end-4 sm:col-end-5 flex justify-between items-center font-bold';
    const valueClass = 'col-start-5 col-end-13 xl:col-start-2 lg:col-start-3 md:col-start-5 sm:col-start-5 w-full overflow-hidden text-ellipsis font-[500]';

    const handleClose = () => {
        dispatch(complianceReportActions.setComplianceNotifyMailDetails({ show: false, data: [], selectedRow: [] }));
    }
    const handleSend = async () => {
        setLoader(true);
        let year = complainceReportReducerState().complianceFilterValues.selectionYear;
        year = year ? Number(moment(year).format("YYYY")) : 0;
        const payload = {
            empId: complianceNotifyMail.selectedRow && complianceNotifyMail.selectedRow.length > 0 ? complianceNotifyMail.selectedRow.map(val => val.EmployeeID) : '',
            year: year
        }
        await dispatch(reportRequest.sendComplianceMailRequest(payload, () => {
            handleClose();
        }));
        setLoader(false);
    }

    return (
        <ModelBox
            open={complianceNotifyMail.show}
            headerTitle={"Compliance Expiry Email Details"}
            onClose={handleClose}
            Component={
                <>
                    <div className=" w-screen px-4 pt-4 custom-floating-filter font-fontfamily  ">
                        <div className="h-[calc(95vh-8rem)] overflow-auto">
                            {complianceNotifyMail.data && complianceNotifyMail.data.length > 0 ? complianceNotifyMail.data.map(value => {
                                return (
                                    <>
                                        <div className=' mb-4 grid sm:w-[70vw] md:w-[55vw] xl:w-[45vw] items-center gap-x-3 xsm:gap-x-5 gap-y-1 text-14px'>
                                            <div className={labelClass}><span > Employee Name </span><span className=" pl-1">:</span></div>
                                            <span className={valueClass}>{value.employeeName} </span>
                                            <div className={labelClass}><span > To </span><span className=" pl-1">:</span></div>
                                            {value.emailId && value.emailId.split(";").length > 0 ? value.emailId.split(";").map((val, key) => { return (<span key={key} className={valueClass}>{val} </span>) }) : ""}
                                            <div className={labelClass}><span > CC </span><span className=" pl-1">:</span></div>
                                            {value.ccEmailId && value.ccEmailId.split(";").length > 0 ? value.ccEmailId.split(";").map((val, key) => { return (<span key={key} className={valueClass}>{val} </span>) }) : ""}
                                            <div className={labelClass}><span > Subject </span><span className=" pl-1">:</span></div>
                                            <span className={valueClass}>{value.subject} </span>
                                        </div>
                                        <div className=" mb-4"> <AgGrid data={value.data && value.data.length > 0 ? value.data : []} columns={complianceReport.complianceNotifyMailDetails()} height="h-[15rem]" /></div>
                                    </>
                                )
                            })
                                : <div className=" flex items-center justify-center h-full font-bold">No Record Found</div>
                            }
                        </div>
                        <div className=" flex justify-center items-center gap-4 my-2 ">
                            <Button value={strings.Buttons.send} onClick={handleSend} disabled={complianceNotifyMail.data && complianceNotifyMail.data.length <= 0} />
                            <Button value={strings.Buttons.cancel} onClick={handleClose} />
                        </div>


                    </div>
                    {loader && <TransparentLoader isFullWidth />}
                </>

            }
        />
    );
};

export default ComplianceNotifyMailPopup;