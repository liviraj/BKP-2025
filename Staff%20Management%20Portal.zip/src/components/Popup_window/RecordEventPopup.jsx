import ModelBox from '../elements/ModelBox';
import { useDispatch, useSelector } from 'react-redux';
import { eventManagementActions } from '../../redux/eventManagementReducer';
import RecordEvents from '../RequestRoutes/EventManagement/RecordEvents';

const RecordEventPopup = () => {
    const dispatch = useDispatch()
    const { recordEventPopup } = useSelector(state => state.eventManagement.recordEvents);
    const handleClose = () => {
        dispatch(eventManagementActions.setRecordEventPopup({ show: false, data: [], selectedRow: {} }))
    }

    return (
        <ModelBox Component={
            <RecordEvents isFullView={true} />
        } headerTitle={recordEventPopup.type === "Edit" ? "Edit Record Events" : "View Record Events"} open={recordEventPopup.show} onClose={handleClose} />
    );
};

export default RecordEventPopup;