import { useDispatch, useSelector } from "react-redux";
import ModelBox from "../elements/ModelBox"
import { complianceReportActions } from "../../redux/complianceReportReducer";
import AgGrid from "../Grid/AgGrid";
import { useState } from "react";
import Button from "../elements/Button";
import { complainceReportReducerState } from "../helper";
import moment from "moment";
import TransparentLoader from "../loader/TransparentLoader";
import { reportRequest } from "../requests";
import { BiSolidCheckbox } from "react-icons/bi";
import { strings } from "../Constants";


function ComplianceNotify() {
    const complianceNotifyState = useSelector(state => state.complianceReport.complianceNotify);
    const dispatch = useDispatch();
    const [selectedRow, setSelectedRow] = useState([]);
    const [loader, setLoader] = useState(false);

    const handleClose = () => {
        dispatch(complianceReportActions.setComplianceNotify({ show: false, columns: [], data: [] }));
    }

    const handleSendMail = async () => {
        setLoader(true);
        let year = complainceReportReducerState().complianceFilterValues.selectionYear;
        year = year ? Number(moment(year).format("YYYY")) : 0;

        const payload = {
            employeeId: `${selectedRow.map(val => val.EmployeeID).join(',').replaceAll(',', '~')}`,
            year: year
        }
        dispatch(complianceReportActions.setComplianceNotifyMailDetails({ selectedRow: selectedRow }));
        await dispatch(reportRequest.getComplianceEmailTemplateRequest(payload));
        setLoader(false);
    }

    return (
        <ModelBox
            open={complianceNotifyState.show}
            headerTitle={"Notify Expired Compliance via Email"}
            onClose={handleClose}
            Component={
                <div className=" w-screen px-4 pt-4 custom-floating-filter">
                    <AgGrid data={complianceNotifyState.data} columns={complianceNotifyState.columns} height="h-[calc(93vh-67px-24px)] lg:h-[calc(93vh-67px-24px)] sm:h-[calc(93vh-134px-24px)] xsm:h-[calc(93vh-268px-24px)]" multiRowSelection={true} getSelectedRow={setSelectedRow} isSetFilter />
                    <div className=" flex justify-center items-center gap-4">
                        <Button value={strings.Buttons.Verify} disabled={selectedRow.length <= 0} onClick={handleSendMail} />
                        <Button value={strings.Buttons.cancel} onClick={handleClose} />
                    </div>
                    <div className=" xsm:relative md:absolute bottom-2.5 right-6 text-13px font-bold font-fontfamily gap-4 flex justify-end">
                        <div className=" flex justify-center items-center leading-loose"><BiSolidCheckbox size={25} color="#ff0000" /> Expired</div>
                        <div className=" flex justify-center items-center leading-loose"><BiSolidCheckbox size={25} color="#2d64e6" /> No Expiry</div>
                    </div>
                    {loader && <TransparentLoader isFullWidth />}
                </div>
            }
        />
    )
}

export default ComplianceNotify