import { useDispatch, useSelector } from "react-redux";
import ApiResponse from "../Alert/ApiResponse";
import TransparentLoader from "../loader/TransparentLoader";
import ModelBox from "../elements/ModelBox";
import { permissionAction } from "../../redux/permissionReducer";
import Dropdown from "../elements/Dropdown";
import { useForm } from "react-hook-form";
import { permissionTypes, popupType, setDefaultValue, strings } from "../Constants";
import { useEffect, useMemo } from "react";
import { exportDateFormat, getEmployeeBasedLeaveDetails, getLeaveDetails, getMinutesBetweenDates, holidayReducerState, leaveStatus } from "../helper";
import DatePickerElement from "../elements/DatePickerElement";
import TextArea from "../elements/TextArea";
import Label from "../elements/Label";
import Button from "../elements/Button";
import PropTypes from 'prop-types';
import { permissionRequests } from "../requests";
import moment from "moment-timezone";

const AddNewPermissionPopup = ({ isEmployeeRequest, setCallback }) => {

    const dispatch = useDispatch();
    const employeeState = useSelector(state => state.employee);
    const userState = useSelector(state => state.user);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const { permissionType, loader, addPermissionPopup } = useSelector(state => state.permission);

    const { watch, setValue, getValues } = useForm({ defaultValues: initialiState });
    const employeeName = watch(strings.addPermissionPopup.employeeName);
    const location = watch(strings.addPermissionPopup.location);
    const date = watch(strings.addPermissionPopup.date);
    const startTime = watch(strings.addPermissionPopup.startTime);
    const endTime = watch(strings.addPermissionPopup.endTime);
    const permission = watch(strings.addPermissionPopup.permissionType);
    const reason = watch(strings.addPermissionPopup.reason);
    const handleClose = () => {
        dispatch(permissionAction.setAddPermissionPopup({ show: false, type: '', selectedRow: [] }));
    }

    useEffect(() => {
        const initialLoad = async () => {
            await dispatch(permissionAction.setLoader(true));
            await Promise.all([
                permissionType.length <= 0 && dispatch(permissionRequests.getPermissionType()),
                isEmployeeRequest && holidayReducerState().holidays.length <= 0 && getLeaveDetails(new Date())
            ]);
            if (addPermissionPopup.type === popupType.edit || addPermissionPopup.type === popupType.view) {
                let selectedRecord = addPermissionPopup.selectedRow;
                await Promise.all([
                    setValue(strings.addPermissionPopup.location, employeeState.location.find(val => val.value === userState.LocationID)),
                    setValue(strings.addPermissionPopup.employeeName, selectedRecord.employeeId && employeeState.employeeName && employeeState.employeeName.length > 0 ? employeeState.employeeName.find(val => val.value === selectedRecord.employeeId) : ""),
                    setValue(strings.addPermissionPopup.date, selectedRecord.permissionDate ? new Date(selectedRecord.permissionDate) : ""),
                    setValue(strings.addPermissionPopup.startTime, selectedRecord.fromTime ? new Date(selectedRecord.fromTime) : ""),
                    setValue(strings.addPermissionPopup.endTime, selectedRecord.toTime ? new Date(selectedRecord.toTime) : ""),
                    setValue(strings.addPermissionPopup.permissionType, selectedRecord.permissionTypeID && permissionType.find(val => (val.value).toString() === (selectedRecord.permissionTypeID).toString())),
                    setValue(strings.addPermissionPopup.reason, selectedRecord.remarks),
                ]);
            } else {
                setValue(strings.addPermissionPopup.location, employeeState.location.find(val => val.value === userState.LocationID));
            }
            dispatch(permissionAction.setLoader(false));
        }
        initialLoad()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const filterEmployeeNameOptn = useMemo(() => {
        const locationID = location ? location.value : userState.LocationID;
        if (employeeState.employeeName.length > 0 && locationID) {
            if (userState.Role === strings.userRoles.superVisor) {
                return employeeState.employeeName.filter(val =>
                    val.supervisorId === userState.UserID &&
                    (val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation)
                );
            }
            return employeeState.employeeName.filter((val) =>
            (val.locationId === locationID &&
                (val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation))
            );
        }
        return [];
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [location]);

    const handleSubmit = async () => {
        await dispatch(permissionAction.setLoader(true));
        let permissionValue = getValues();
        const startTime = permissionValue.startTime && moment(permissionValue.startTime).set({ milliseconds: 0 });
        const endTime = permissionValue.endTime && moment(permissionValue.endTime).set({ milliseconds: 0 });
        let data = {
            enteredBy: userState.UserID,
            fromTime: startTime ? moment(permissionValue.date).format('YYYY-MM-DD') + " " + moment(startTime).format('HH:mm:ss.SSS') : "",
            noofHrs: startTime && endTime ? getMinutesBetweenDates(new Date(startTime), new Date(endTime)) : 0,
            permissionDate: permissionValue.date ? exportDateFormat(permissionValue.date, true) : "",
            permissionType: permissionValue.permissionType ? permissionValue.permissionType.value : "",
            remarks: permissionValue.reason,
            toTime: endTime ? moment(permissionValue.date).format('YYYY-MM-DD') + " " + moment(endTime).format('HH:mm:ss.SSS') : "",
            employeeId: permissionValue.employeeName ? permissionValue.employeeName.value : userState.UserID
        }

        if (addPermissionPopup.type == popupType.edit) {
            let selectedRecord = addPermissionPopup.selectedRow;
            data = {
                ...data,
                approvalStatus: selectedRecord && ("approvalStatus" in selectedRecord) && selectedRecord.approvalStatus && leaveStatus.find(val => val.label === selectedRecord.approvalStatus) ? leaveStatus.find(val => val.label === selectedRecord.approvalStatus).Key : "",
                lastModifiedBy: userState.UserID,
                lastModifiedOn: exportDateFormat(new Date())
            }
            await dispatch(permissionRequests.editPermissionRequest(selectedRecord.permissionID, data, setCallback));
        }
        else {
            await dispatch(permissionRequests.addPermissionRequest(data, setCallback));
        }
        dispatch(permissionAction.setLoader(false));
    }

    const onlocationChange = (data) => {
        setValue(strings.addPermissionPopup.location, data);
        if (employeeName && Object.keys(employeeName).length > 0 && employeeName.locationId !== data.value) {
            setValue(strings.addPermissionPopup.employeeName, "");
            setValue(strings.addPermissionPopup.date, "");
        }
    }

    const onDateChange = async (date) => {
        dispatch(permissionAction.setLoader(true));
        if (isEmployeeRequest) {
            await getLeaveDetails(date);
        } else {
            await getEmployeeBasedLeaveDetails(employeeName.employeeId, location.value, date);
        }
        setValue(strings.addPermissionPopup.date, date);
        dispatch(permissionAction.setLoader(false));
    }

    const onEmployeeChange = async (data) => {
        dispatch(permissionAction.setLoader(true));
        if (!employeeName || data.employeeId !== employeeName.employeeId) {
            await getEmployeeBasedLeaveDetails(data.employeeId, location.value, new Date())
            setValue(strings.addPermissionPopup.date, "");
        }
        setValue(strings.addPermissionPopup.employeeName, data)
        dispatch(permissionAction.setLoader(false));
    }

    const disableHolidays = useMemo(() => {
        if (employeeName && holidayReducerState().employeeBasedHolidays.length > 0) {
            let employeeHolidays = holidayReducerState().employeeBasedHolidays;
            if (employeeHolidays && employeeHolidays.length > 0) {
                const validData = employeeHolidays.find(val => val.empId === employeeName.employeeId);
                if (validData) {
                    return validData.holidays;
                }
            }
        }
        return [];
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [holidayReducerState().employeeBasedHolidays, employeeName, location, date]);


    const handleDisable = useMemo(() => {
        let values = getValues();
        if (addPermissionPopup.type !== popupType.edit) {
            return !!(date && startTime && endTime && permission && reason)
        }
        else {
            const data = addPermissionPopup.selectedRow;
            if (values[strings.addPermissionPopup.date] && values[strings.addPermissionPopup.startTime] && values[strings.addPermissionPopup.endTime] && values[strings.addPermissionPopup.permissionType] && values[strings.addPermissionPopup.reason]) {
                return (!(exportDateFormat(values[strings.addPermissionPopup.date], true) === exportDateFormat(data.permissionDate, true) && new Date(values[strings.addPermissionPopup.startTime]).getTime() === new Date(data.fromTime).getTime() && new Date(values[strings.addPermissionPopup.endTime]).getTime() === new Date(data.toTime).getTime()
                    && values[strings.addPermissionPopup.reason] === data.remarks && values[strings.addPermissionPopup.permissionType]?.value === data?.permissionTypeID));
            }
        }
        return false;
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [date, startTime, endTime, permission, reason]);

    return (
        <ModelBox Component={
            <>
                <div className='xsm:min-w-[90vw] sm:min-w-[30rem] max-w-[90vw] max-h-[85vh] overflow-auto px-4 py-2'>
                    <fieldset className="grid grid-cols-1 sm:grid-cols-1 md:grid-cols-6 gap-x-3 gap-y-6 mt-3 max-w-[80vw]" disabled={addPermissionPopup.type === popupType.view} >
                        {!isEmployeeRequest && <>
                            <div className="col-span-1 md:col-start-1 md:col-end-4 w-full md:w-[15.5rem]"><Label label={"Location"} required={true} /><Dropdown value={location} options={employeeState.location ? employeeState.location.filter(val => val.value !== setDefaultValue.defaultLocation.value) : []} onChange={data => onlocationChange(data)} isRequired={true} isViewable={addPermissionPopup.type === popupType.view} isDisable={userState.Role !== strings.userRoles.admin} /></div>
                            <div className="col-span-1 md:col-start-4 md:col-end-8 w-full md:w-[15.5rem]"><Label label={"Employee Name"} required={true} /><Dropdown value={employeeName} options={filterEmployeeNameOptn} onChange={onEmployeeChange} isSearchable={true} isRequired={true} isViewable={addPermissionPopup.type === popupType.view} /></div>
                        </>}
                        <div className="col-span-1 md:col-start-1 md:col-end-13">
                            <div className="grid grid-cols-1 sm:grid-cols-1 md:grid-cols-12 gap-x-3">
                                <div className="col-span-1 md:col-start-1 md:col-end-5 "><Label label={"Date"} required={true} isDisable={!!(isEmployeeRequest ? false : (!employeeName))} /><DatePickerElement value={date} onChange={onDateChange} isRequired={true} isViewable={addPermissionPopup.type === popupType.view} isWeekday disableHolidays={isEmployeeRequest ? holidayReducerState().holidays : disableHolidays} disabled={!!(isEmployeeRequest ? false : (!employeeName))} /></div>
                                <div className="col-span-1 md:col-start-5 md:col-end-9"><Label label={"Start Time"} required={true} /><DatePickerElement value={startTime} onChange={(time) => { setValue(strings.addPermissionPopup.startTime, time) }} showTimeSelect isRequired minTime={moment().set({ hour: 9, minute: 0, seconds: 0, milliseconds: 0 })} maxTime={moment().set({ hours: 21, minutes: 0, seconds: 0, milliseconds: 0 }).toDate()} isViewable={addPermissionPopup.type === popupType.view} /></div>
                                <div className="col-span-1 md:col-start-9 md:col-end-13"><Label label={"End Time"} required={true} /><DatePickerElement value={endTime} onChange={(time) => { setValue(strings.addPermissionPopup.endTime, time) }} showTimeSelect isRequired minTime={moment().set({ hour: 9, minute: 0, seconds: 0, milliseconds: 0 })} maxTime={moment().set({ hours: 21, minutes: 0, seconds: 0, milliseconds: 0 }).toDate()} isViewable={addPermissionPopup.type === popupType.view} /></div>
                            </div>
                        </div>
                        <div className={`${isEmployeeRequest ? "col-span-1 md:col-start-1 md:col-end-5 w-full md:w-[19rem]" : "col-span-1 md:col-start-1 md:col-end-7"} `}><Label label={"Permission Type"} required={true} /><Dropdown value={permission} options={permissionType ? permissionType.filter(val => (val.value !== permissionTypes[0].value && (isEmployeeRequest ? val.value !== permissionTypes[2].value : true) && (userState.LocationID === setDefaultValue.location.value ? (val.value !== permissionTypes[1].value) : true))) : []} onChange={(e) => { setValue(strings.addPermissionPopup.permissionType, e) }} isSearchable={true} isRequired={true} isViewable={addPermissionPopup.type === popupType.view} /></div>
                        <div className="col-span-1 md:col-start-1 md:col-end-13"><Label label={"Reason"} required={true} /><TextArea value={reason} height={" !h-28 text-13px "} onChange={(e) => { setValue(strings.addPermissionPopup.reason, e.target.value) }} isRequired={true} /></div>
                    </fieldset>
                    <div className="justify-center flex flex-row gap-3 sm:flex-row mb-3">
                        {addPermissionPopup.type === popupType.view || <Button value={addPermissionPopup.type === popupType.edit ? strings.Buttons.Update : strings.Buttons.Save} onClick={handleSubmit} disabled={!handleDisable} />}
                        <Button value={strings.Buttons.Close} onClick={handleClose} />
                    </div>
                </div>
                {loader && <TransparentLoader isFullWidth={true} />}
                {apiResponseState.show && <ApiResponse />}
            </>
        } headerTitle={`${addPermissionPopup.type === popupType.view ? 'View' : (addPermissionPopup.type === popupType.edit ? 'Edit' : 'Add New')} Permission`} open={addPermissionPopup.show} onClose={handleClose} />
    );
};

const initialiState = {
    location: "",
    employeeName: "",
    date: "",
    startTime: "",
    endTime: "",
    permissionType: "",
    reason: ""
}


export default AddNewPermissionPopup;

AddNewPermissionPopup.propTypes = {
    isEmployeeRequest: PropTypes.bool,
    setCallback: PropTypes.func
}

