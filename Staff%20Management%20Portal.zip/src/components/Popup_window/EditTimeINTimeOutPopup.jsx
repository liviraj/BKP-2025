import { useDispatch, useSelector } from "react-redux"
import ModelBox from "../elements/ModelBox"
import { timeInTimeOutActions } from "../../redux/TimeInTimeOutReducer";
import Label from "../elements/Label";
import DatePickerElement from "../elements/DatePickerElement";
import Button from "../elements/Button";
import { strings } from "../Constants";
import moment from "moment";
import { useEffect, useMemo, useState } from "react";
import TransparentLoader from "../loader/TransparentLoader";
import { useForm } from "react-hook-form";
import { dateFormat, exportDateFormat, timeFormat } from "../helper";
import { timeInTimeOutRequest, userRequest } from "../requests";
import ApiResponse from "../Alert/ApiResponse";
import PropTypes from "prop-types";


function EditTimeINTimeOutPopup({ handleRefresh }) {

    const dispatch = useDispatch();
    const timeInTimeOutPopupState = useSelector(state => state.timeInTimeOut.timeInTimeOutPopup);
    const userState = useSelector(state => state.user);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);

    const { watch, setValue, getValues } = useForm({ defaultValues: initialValue });
    const data = watch(strings.timeInTimeOutRequest.data);
    const userRecords = watch(strings.timeInTimeOutRequest.userRecords);

    const [loader, setLoader] = useState(false);

    const onClose = () => {
        dispatch(timeInTimeOutActions.setTimeInTimeOutPopup({ show: false, action: "Edit", selectedRow: {} }));
    }

    useEffect(() => {
        const initialLoad = async () => {
            setLoader(true);
            const payload = {
                employeeId: timeInTimeOutPopupState.selectedRow?.employeeId,
                fromDate: exportDateFormat(timeInTimeOutPopupState.selectedRow?.workDate, true)
            }
            await dispatch(timeInTimeOutRequest.getTimeInTimeOutDetails(payload, async (data) => {
                await setValue(strings.timeInTimeOutRequest.userRecords, data);
            }))
            await handleResetData();
            setLoader(false);
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const handleUpdateUserRecords = async () => {
        const getUserRecords = watch(strings.timeInTimeOutRequest.userRecords);
        if (getUserRecords.length > 0) {
            let tempData = [...timeInTimeOutFormat];
            const recordsUpdate = (idx, val) => {
                tempData[idx] = { ...tempData[idx], ...val, value: val.logTime };
            }
            await getUserRecords.forEach(async (val, index) => {
                await recordsUpdate(index, val);
            });
            setValue(strings.timeInTimeOutRequest.data, tempData);
        }
    }

    const handleResetData = async () => {
        setLoader(true);
        handleUpdateUserRecords();
        setLoader(false);
    }

    const handleUpdateData = (index, value) => {
        let tempData = [...data];
        if (("logId" in tempData[index]) ? value : true) {
            tempData[index].value = value || "";
            setValue(strings.timeInTimeOutRequest.data, tempData);
        }
    }

    const handleSumbit = async () => {
        setLoader(true);
        const isValid = handleValidate();
        if (isValid) {
            const records = getValues();
            const responseData = records.data.filter((val, idx) => {
                if ("logId" in val) {
                    return timeFormat(val.value) !== timeFormat(userRecords[idx].logTime);
                }
                return !!val.value;
            }).map(val => {
                const timeValue = moment(val.value);
                return {
                    logId: ("logId" in val) ? val.logId : 0,
                    employeeId: timeInTimeOutPopupState.selectedRow?.employeeId,
                    workDate: exportDateFormat(timeInTimeOutPopupState.selectedRow?.workDate, true),
                    logType: val.type,
                    logTime: exportDateFormat(moment(timeInTimeOutPopupState.selectedRow?.workDate).set({ hours: timeValue.hours(), minutes: timeValue.minutes() }), false, true),
                    lastModifiedBy: userState.UserID,
                    lastModifiedOn: exportDateFormat(new Date()),
                }
            });
            await dispatch(timeInTimeOutRequest.updateTimeInTimeOutDetails(responseData, async () => {
                await onClose();
                await handleRefresh();
            }));
        }
        setLoader(false);
    }

    const handleValidate = () => {
        let dateValidation = {}
        let isBetweenValue = false;
        data.forEach((val, idx) => {
            if (data.length > idx && data[idx + 1]?.value) {
                const nextDate = moment(data[idx + 1].value).set({ month: 1, date: 1, year: 2000 });
                const currentDate = moment(val.value).set({ month: 1, date: 1, year: 2000 });
                const datediff = moment(nextDate).diff(currentDate);
                if (datediff <= 0) {
                    dateValidation = { current: val, next: data[idx + 1] };
                }
            }
            if (val.value && idx > 0 && !data[idx - 1]?.value) {
                isBetweenValue = true;
                if (Object.keys(dateValidation).length <= 0) {
                    dateValidation = { current: val, prev: data[idx - 1] };
                }
            }
            return false;
        });
        if (isBetweenValue) {
            dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Alert", message: `Time ${dateValidation.prev.type} must be recorded before entering Time ${dateValidation.current.type} (${moment(dateValidation.current.value).format("hh:mm A")}) field`, isOptional: false }));
        } else if (Object.keys(dateValidation).length > 0) {
            dispatch(userRequest.apiResponse({ show: true, status: 0, header: "Alert", message: `Time ${dateValidation.current.type} (${moment(dateValidation.current.value).format("hh:mm A")}) must be earlier than Time ${dateValidation.next.type} (${moment(dateValidation.next.value).format("hh:mm A")})`, isOptional: false }));
        }
        return Object.keys(dateValidation).length <= 0;
    }

    const handleDisableButton = useMemo(() => {
        if (userRecords.length > 0) {
            let isValid = userRecords.every((val, idx) => timeFormat(val.logTime) === timeFormat(data[idx].value));
            if (isValid) {
                for (let i = userRecords.length; i < data.length; i++) {
                    if (data[i].value) {
                        isValid = false;
                        break;
                    }
                }
            }
            return isValid;
        }
        return true;
    }, [data, userRecords]);

    return (
        <ModelBox
            onClose={onClose}
            open={timeInTimeOutPopupState.show}
            headerTitle={`Edit Time In / Out Records`}
            Component={<div className=" h-screen/90 w-screen/90  ">
                <div className=" px-6">
                    <div className=" grid grid-cols-12 items-center sm:gap-y-4 gap-x-2 my-8 sm:w-[30rem]" >
                        <div className=" col-start-1 sm:col-end-5 xsm:col-end-12 text-15px flex justify-between"><Label label={`Employee Name`} setBold /><span className=" font-bold">:</span></div>
                        <div className=" sm:col-start-5 xsm:col-start-1 col-end-12">  <span className='font-bold text-headerColor text-14px uppercase ml-1'>{timeInTimeOutPopupState.selectedRow?.employeeName}</span></div>
                        <div className=" col-start-1 sm:col-end-5 xsm:col-end-12 text-15px flex justify-between"><Label label={`Date`} setBold /><span className=" font-bold">:</span></div>
                        <div className=" sm:col-start-5 xsm:col-start-1 col-end-12"><Label label={dateFormat(timeInTimeOutPopupState.selectedRow?.workDate)} setBold /> </div>
                    </div>
                    <div className=" grid xl:grid-cols-8 lg:grid-cols-4 sm:grid-cols-2 my-4 border-collapse border border-r-0 border-darkDarkGrey border-solid text-14px">
                        {
                            data?.map((val, idx) =>
                                <div key={val.id} className={`flex flex-col border-r-1 border-darkDarkGrey border-solid divide-y-1 divide-darkDarkGrey border-collapse ${val.addStyle}`}>
                                    <span className=" px-2 py-1"><Label label={val.label} setBold addStyle={"!text-center"} isDisable={val.isLabelView} /></span>
                                    <span className=" px-2 xl:py-1 xsm:py-2"><DatePickerElement isRequired value={val.value} onChange={date => handleUpdateData(idx, date)} showTimeSelect minTime={val.minTime || moment().set({ hours: 0, minutes: 0, seconds: 0 })} maxTime={moment().set({ hours: 23, minutes: 59, seconds: 0 })} setTimeInterval={1} isRemovable={!("logId" in val)} /></span>
                                </div>)
                        }
                    </div>
                    <div className=" flex justify-center items-center my-6 gap-4">
                        <Button value={strings.Buttons.Update} disabled={handleDisableButton} onClick={handleSumbit} />
                        <Button value={strings.Buttons.Reset} onClick={handleResetData} />
                    </div>
                </div>
                {loader && <TransparentLoader isFullWidth />}
                {apiResponseState.show && <ApiResponse />}
            </div>}
        />
    )
}

export default EditTimeINTimeOutPopup

EditTimeINTimeOutPopup.propTypes = {
    handleRefresh: PropTypes.func
}

const timeInTimeOutFormat = [
    {
        label: "IN",
        value: "",
        addStyle: "",
        isLabelView: false,
        minTime: "",
        type: "In",
        id: "In1"
    },
    {
        label: "OUT",
        value: "",
        addStyle: "sm:border-t-0 xsm:border-t-1",
        isLabelView: false,
        minTime: "",
        type: "Out",
        id: "out1"
    },
    {
        label: "IN",
        value: "",
        addStyle: "lg:border-t-0 xsm:border-t-1",
        isLabelView: false,
        minTime: "",
        type: "In",
        id: "In2"
    },
    {
        label: "OUT",
        value: "",
        addStyle: "lg:border-t-0 xsm:border-t-1",
        isLabelView: false,
        minTime: "",
        type: "Out",
        id: "out2"
    },
    {
        label: "IN",
        value: "",
        addStyle: "xl:border-t-0 xsm:border-t-1",
        isLabelView: false,
        minTime: "",
        type: "In",
        id: "In3"
    },
    {
        label: "OUT",
        value: "",
        addStyle: "xl:border-t-0 xsm:border-t-1",
        isLabelView: false,
        minTime: "",
        type: "Out",
        id: "out3"
    },
    {
        label: "IN",
        value: "",
        addStyle: "xl:border-t-0 xsm:border-t-1",
        isLabelView: false,
        minTime: "",
        type: "In",
        id: "In4"
    },
    {
        label: "OUT",
        value: "",
        addStyle: "xl:border-t-0 xsm:border-t-1",
        isLabelView: false,
        minTime: "",
        type: "Out",
        id: "out4"
    },
];

const initialValue = {
    data: timeInTimeOutFormat,
    date: new Date(),
    userRecords: []
}