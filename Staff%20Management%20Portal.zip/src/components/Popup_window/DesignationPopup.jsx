import ModelBox from "../elements/ModelBox";
import { useDispatch, useSelector } from "react-redux";
import { designationActions } from "../../redux/DesignationReducer";
import { useForm } from "react-hook-form";
import TextField from "../elements/TextField";
import Label from "../elements/Label";
import { statusOptionsList, strings } from "../Constants";
import Dropdown from "../elements/Dropdown";
import { employeeReducerState, exportDateFormat, userReducerState } from "../helper";
import Button from "../elements/Button";
import { useEffect } from "react";
import { designationRequest, employeeRequests } from "../requests";
import TransparentLoader from "../loader/TransparentLoader";
import PropTypes from 'prop-types';
import ApiResponse from "../Alert/ApiResponse";
import TextArea from "../elements/TextArea";
import UploadAndDeleteDocument from '../elements/UploadAndDeleteDocument';


const DesignationPopup = ({ handleSubmit }) => {
    const dispatch = useDispatch();
    const { designationPopup, loader } = useSelector(state => state.designation);
    const employeeState = useSelector(state => state.employee);
    const userState = useSelector(state => state.user);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);
    const { reset, watch, setValue, getValues } = useForm({ defaultValues: initialState })
    const designationName = watch(strings.designationPopup.designationName);
    const description = watch(strings.designationPopup.description);
    const location = watch(strings.designationPopup.location);

    useEffect(() => {
        const initialLoad = async () => {
            await dispatch(designationActions.setLoader(true));
            employeeState.location.length <= 0 && await dispatch(employeeRequests.location());
            await handleReset();
            dispatch(designationActions.setLoader(false));
        }
        initialLoad()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    const onClose = () => {
        dispatch(designationActions.reSetDesignationPopup())
        reset();
    }
    const onlocationChange = async (data) => {
        await setValue(strings.designationPopup.location, data);
    }
    const handleSave = async () => {
        await dispatch(designationActions.setLoader(true))
        const value = getValues();
        let payload = {
            description: value.description,
            designationName: value.designationName,
            displayOrder: 3,
            documentName: value.uploadFile.length ? value.uploadFile[0].name : "",
            documentImage: value.uploadFile.length ? value.uploadFile[0].binary : "",
            isFileView: true,
            locationID: value.location.value,
            roleAndResponsibilities: '',
        }
        if (designationPopup.isEditable) {
            payload = {
                ...payload,
                modifiedBy: userState.UserID,
                modifiedDate: exportDateFormat(new Date())
            }
            await dispatch(designationRequest.editDesignationRequest(designationPopup.selectedRow.designationID, payload, setCallBack));
        }
        else {
            payload = {
                ...payload,
                createdBy: userState.UserID,
                createdDate: exportDateFormat(new Date()),
            }
            await dispatch(designationRequest.addDesignationRequest(payload, setCallBack));
        }
        dispatch(designationActions.setLoader(false));
    }
    const setCallBack = async (isValid) => {
        if (isValid) {
            await dispatch(designationActions.setLoader(true))
            await onClose();
            await handleSubmit();
            dispatch(designationActions.setLoader(false))
        }
    }
    const handleReset = () => {
        reset();
        setValue(strings.designationPopup.location, employeeReducerState().location.find(val => val.value === userReducerState().LocationID));
        if (designationPopup.isEditable) {
            const data = designationPopup.selectedRow;
            setValue(strings.designationPopup.designationName, data.designationName);
            setValue(strings.designationPopup.description, data.description);
            setValue(strings.designationPopup.location, employeeReducerState().location.find(val => val.value === data.locationID));
            setValue(strings.designationPopup.rolesAndResponsibilities, data.roleAndRespons);
            setValue(strings.designationPopup.status, statusOptionsList.find(val => val.label == data.status));
            if (data?.documentImage && data?.documentName) setValue(strings.designationPopup.uploadFile, [{ name: data?.documentName, binary: data?.documentImage }]);
        }
    }


    const handleDisable = (isDisable) => {
        const values = getValues();
        const data = designationPopup.selectedRow;
        if (designationPopup.isEditable && designationName && description && location) {
            if (values[strings.designationPopup.designationName] && values[strings.designationPopup.description] && values[strings.designationPopup.location] && designationPopup.isEditable) {
                return !(((values[strings.designationPopup.uploadFile] && values[strings.designationPopup.uploadFile].length > 0) ? (data.documentName === (values[strings.designationPopup.uploadFile][0]?.name) && data.documentImage === values[strings.designationPopup.uploadFile][0]?.binary) : !(data.documentName && data.documentImage))
                    && data.designationName === values[strings.designationPopup.designationName] && data.description === values[strings.designationPopup.description] && data.locationID === values[strings.designationPopup.location].value);
            }
        } else {
            if (isDisable) {
                return designationName || description || location;
            }
            return (designationName && description && location);
        }
        return false;
    }
    return (
        <ModelBox Component={
            <>
                <div className="xsm:w-[90vw] md:w-[40rem] max-h-[85vh] overflow-auto sm:px-8 xsm:px-4 bg-white">
                    <div className=" grid md:grid-cols-2 pt-4 gap-3 grid-cols-1 text-14px">
                        <div className=" flex items-center"><Label label="Designation Name" required={true} /> </div>
                        <div> <TextField value={designationName} onChange={e => setValue(strings.designationPopup.designationName, e.target.value)} isRequired={true} /> </div>
                        <div className=" flex items-center"><Label label="Location" required={true} />  </div>
                        <div> <Dropdown placeholder={"Location"} value={location} options={employeeState.location && employeeState.location.length > 0 ? employeeState.location.filter(val => val.value > 0) : []} onChange={data => userReducerState().Role === strings.userRoles.humanResource || onlocationChange(data)} isSearchable={true} isDisable={userReducerState().Role !== strings.userRoles.admin} isRequired={true} /> </div>
                        <div className=" flex items-center"><Label label="Upload Document" /></div>
                        <div><UploadAndDeleteDocument label="Browse" onChange={file => setValue(strings.designationPopup.uploadFile, file)} file={watch(strings.designationPopup.uploadFile)} /></div>
                    </div>
                    <div className=" flex items-center mt-5"><Label label="Description" required={true} />  </div>
                    <TextArea value={description} onChange={e => setValue(strings.designationPopup.description, e.target.value)} isRequired={true} height={" !h-28 text-13px "} />
                    <footer className="flex flex-wrap gap-4 justify-center mt-7 mb-2 sticky z-0 bottom-0 bg-white">
                        <Button value={designationPopup.isEditable ? strings.Buttons.Update : strings.Buttons.Save} onClick={handleSave} disabled={!handleDisable()} />
                        <Button value={strings.Buttons.Reset} disabled={!handleDisable(true)} onClick={handleReset} />
                        <Button value={strings.Buttons.cancel} onClick={onClose} />
                    </footer>
                </div>
                {loader && <TransparentLoader isFullWidth={true} />}
                {apiResponseState.show && <ApiResponse />}
            </>

        } headerTitle={designationPopup.isEditable ? 'Edit Designation' : 'Add Designation'} open={designationPopup.show} onClose={onClose} />
    );
};

export default DesignationPopup;
DesignationPopup.propTypes = {
    handleSubmit: PropTypes.func,
}

const initialState = {
    designationName: "",
    description: "",
    department: "",
    location: "",
    rolesAndResponsibilities: "",
    status: "",
    uploadFile: []
}

// const departmentList = [
//     { label: "Bio", value: 0 },
//     { label: "IT", value: 1 },
//     { label: "Marketing", value: 2 },
//     { label: "Reporting", value: 3 }
// ]l