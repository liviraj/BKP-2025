import { useDispatch, useSelector } from "react-redux";
import ModelBox from "../elements/ModelBox";
import { wfhActions } from "../../redux/wfhReducer";
import Label from "../elements/Label";
import DatePickerElement from "../elements/DatePickerElement";
import TextArea from "../elements/TextArea";
import { useForm } from "react-hook-form";
import { popupType, setDefaultValue, strings } from "../Constants";
import Button from "../elements/Button";
import TransparentLoader from "../loader/TransparentLoader";
import { useEffect, useMemo, useState } from "react";
import Dropdown from "../elements/Dropdown";
import { employeeRequests, wfhRequest } from "../requests";
import { exportDateFormat, getDateDifference, getEmployeeBasedLeaveDetails, halfDayOptions, holidayReducerState } from "../helper";
import ApiResponse from "../Alert/ApiResponse";

const AddWFHRequest = () => {

    const [loader, setLoader] = useState(false);

    const dispatch = useDispatch();
    const employeeState = useSelector(state => state.employee);
    const { addWFHRequest } = useSelector(state => state.wfhRequest);
    const userState = useSelector(state => state.user);
    const apiResponseState = useSelector(state => state.loginResponse.apiResponse);

    const { watch, setValue, reset, getValues } = useForm({ defaultValues: initialValue });
    const fromDate = watch(strings.addWFHRequest.startDate);
    const toDate = watch(strings.addWFHRequest.endDate);
    const employeeName = watch(strings.addWFHRequest.employeeName);
    const halfDay = watch(strings.addWFHRequest.halfDay);
    const reason = watch(strings.addWFHRequest.reason);

    useEffect(() => {
        const initialLoad = async () => {
            setLoader(true);
            await Promise.all([
                employeeState.employeeName.length <= 0 && dispatch(employeeRequests.employeeName()),
            ])
            await onReset();
            setLoader(false);
        }
        initialLoad()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])



    const handleClose = async () => {
        await dispatch(wfhActions.addWFHRequest({ show: false, data: [] }))
    }

    const employeeNameOptions = useMemo(() => {
        return employeeState.employeeName.length > 0 ? employeeState.employeeName.filter(val => (val.locationId === setDefaultValue.location.value && (val.employmentStatus === setDefaultValue.employmentStatus.confirmed || val.employmentStatus === setDefaultValue.employmentStatus.probation))) : [];
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [employeeState.employeeName]);

    const onReset = () => {
        if (addWFHRequest.type === popupType.edit) {
            let data = addWFHRequest.data;
            setValue(strings.addWFHRequest.startDate, data.startDate);
            setValue(strings.addWFHRequest.endDate, data.endDate);
            setValue(strings.addWFHRequest.reason, data.reason);
        }
        else {
            reset();
        }
    }

    const disableHolidays = useMemo(() => {
        if (employeeName && holidayReducerState().employeeBasedHolidays.length > 0) {
            let employeeHolidays = holidayReducerState().employeeBasedHolidays;
            if (employeeHolidays && employeeHolidays.length > 0) {
                const validData = employeeHolidays.find(val => val.empId === employeeName.employeeId);
                if (validData) {
                    return validData.holidays;
                }
            }
        }
        return [];
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [holidayReducerState().employeeBasedHolidays, employeeName, toDate, fromDate]);

    const handleEmployeeName = async (e) => {
        if (!employeeName || employeeName.employeeId !== e.employeeId) {
            setLoader(true);
            setValue(strings.addWFHRequest.employeeName, e);
            await getEmployeeBasedLeaveDetails(e.employeeId, setDefaultValue.location.value, new Date());
            setValue(strings.addWFHRequest.startDate, "");
            setValue(strings.addWFHRequest.endDate, "");
            setLoader(false);
        }
    }

    const handleFHDayDisable = useMemo(() => {
        if (fromDate && toDate && getDateDifference(fromDate, toDate, true) !== 1) {
            setValue(strings.addWFHRequest.halfDay, halfDayOptions[0]);
            return true;
        }
        return false
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [fromDate, toDate]);

    const isResetDisable = useMemo(() => {
        return !(employeeName || fromDate || toDate || halfDay?.value !== halfDayOptions[0].value || reason);
    }, [employeeName, fromDate, toDate, halfDay, reason])

    const handleSubmit = async () => {
        setLoader(true);
        const data = getValues();

        const payload = {
            employeeId: data.employeeName?.value,
            enteredBy: userState.UserID,
            enteredOn: exportDateFormat(new Date()),
            fromDate: exportDateFormat(data.startDate, true),
            remarks: data.reason,
            requestFromForH: data.halfDay.value,
            toDate: exportDateFormat(data.endDate, true),
            requestToForH: data.halfDay.value
        }

        await dispatch(wfhRequest.addWFHRequest(payload, async () => {
            await handleClose();
        }));

        setLoader(false);
    }

    return (
        <>
            <ModelBox
                Component={
                    <>
                        <div className=" xsm:w-full sm:w-[35rem] my-5">
                            <div className=" grid grid-cols-12 gap-x-4 sm:gap-y-6 items-center ">
                                <div className=" col-start-2 sm:col-end-5 xsm:col-end-12 xsm:mt-4 sm:mt-0">
                                    <Label label={'Employee Name'} required={true} />
                                </div>
                                <div className=" sm:col-start-5 xsm:col-start-2 col-end-12">
                                    <Dropdown value={employeeName} isRequired onChange={handleEmployeeName} options={employeeNameOptions} />
                                </div>
                                <div className=" col-start-2 sm:col-end-5 xsm:col-end-12 xsm:mt-4 sm:mt-0">
                                    <Label label={"From"} required={true} isDisable={!employeeName} />
                                </div>
                                <div className=" sm:col-start-5 xsm:col-start-2 col-end-12">
                                    <DatePickerElement value={fromDate} onChange={date => setValue(strings.addWFHRequest.startDate, date)} isWeekday={true} disableHolidays={disableHolidays} maxDate={toDate} disabled={!employeeName} />
                                </div>
                                <div className=" col-start-2 sm:col-end-5 xsm:col-end-12 xsm:mt-4 sm:mt-0">
                                    <Label label={"To"} required={true} isDisable={!employeeName} />
                                </div>
                                <div className=" sm:col-start-5 xsm:col-start-2 col-end-12">
                                    <DatePickerElement value={toDate} onChange={date => setValue(strings.addWFHRequest.endDate, date)} minDate={fromDate} disableHolidays={disableHolidays} isWeekday={true} disabled={!employeeName} />
                                </div>
                                <div className=" col-start-2 sm:col-end-5 xsm:col-end-12 xsm:mt-4 sm:mt-0">
                                    <Label label={"F/H Day"} required={true} isDisable={handleFHDayDisable} />
                                </div>
                                <div className=" sm:col-start-5 xsm:col-start-2 col-end-12">
                                    <Dropdown value={halfDay} isRequired onChange={data => setValue(strings.addWFHRequest.halfDay, data)} options={halfDayOptions} isPopupView isDisable={handleFHDayDisable} />
                                </div>
                                <div className=" col-start-2 sm:col-end-5 xsm:col-end-12 xsm:mt-4 sm:mt-0">
                                    <Label label={"Reason"} required={true} />
                                </div>
                            </div>
                            <div className="grid grid-cols-12 items-center">
                                <div className=" col-start-2 col-end-12 ">
                                    <TextArea height={" !h-24 text-14px"} isRequired={true} value={reason} onChange={e => setValue(strings.addWFHRequest.reason, e.target.value)} />
                                </div>
                            </div>
                            <div className=' flex flex-wrap gap-4 justify-center items-center my-10'>
                                <Button value={strings.Buttons.Save} disabled={!(fromDate && toDate && reason)} onClick={handleSubmit} />
                                <Button value={strings.Buttons.Reset} disabled={isResetDisable} onClick={() => onReset()} />
                                <Button value={strings.Buttons.Close} onClick={handleClose} />
                            </div>
                        </div>
                        {loader && <TransparentLoader isFullWidth={true} />}
                        {apiResponseState.show && <ApiResponse />}
                    </>
                }
                headerTitle={`${addWFHRequest.type === popupType.edit ? 'Edit ' : 'Add '} WFH Request`}
                open={addWFHRequest.show}
                onClose={handleClose}
            />
        </>
    );
};

export default AddWFHRequest;

const initialValue = {
    employeeName: "",
    startDate: "",
    endDate: "",
    reason: '',
    halfDay: halfDayOptions[0]
}