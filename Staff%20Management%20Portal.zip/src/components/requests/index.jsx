import { employeeServices, loginService, communicationService, generalService, qualificationService, reportService, leaveManagementService, sickLeaveService, eventManagementService, myRequestService, permissionService, holidayService, payrollService, deputationService, WFHService, designationService, timeInTimeOutService, departmentService, documentPolicyService, addComplianceListService } from "../services";
import { employeeActions } from "../../redux/employeeReducer";
import { userActions } from "../../redux/userReducer";
import { loginActions } from "../../redux/loginReducer";
import { loginResponseActions } from "../../redux/loginResponseReducer";
import { eventManagementReducerState, exportDateFormat, getNumberOfYears } from "../helper";
import { complianceReportActions } from "../../redux/complianceReportReducer";
import { leaveManagementActions } from "../../redux/leaveManagementReducer";
import { sickLeaveActions } from "../../redux/sickLeaveReducer";
import { routerPath, setDefaultValue } from "../Constants";
import { eventManagementActions } from "../../redux/eventManagementReducer";
import { myRequestActions } from "../../redux/myRequestReducer";
import { permissionAction } from "../../redux/permissionReducer";
import { holidayActions } from "../../redux/holidayReducer";
import { employeeDashboardActions } from "../../redux/employeeDashboardReducer";
import { attendancePayrollActions } from "../../redux/AttendancePayrollReducer";
import { deputationActions } from "../../redux/DeputationReducer";
import { wfhActions } from "../../redux/wfhReducer";
import { departmentActions } from "../../redux/departmentReducer";
import { designationActions } from "../../redux/DesignationReducer";
import { ComplianceAgreementActions } from "../../redux/ComplianceAgreementReducer";
import { AddComplianceRequestAction } from "../../redux/AddComplianceRequest";
import { timeInTimeOutActions } from "../../redux/TimeInTimeOutReducer";

export const employeeRequests = {
    //                                ------------------   Employee Detail Screen  -------------------
    clinicalUser: () => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.ClinicalUsers();
                if (res.status === 200) {
                    dispatch(employeeActions.setClinicalUserLists(res.data.data.map((val, idx) => ({ value: idx + 1, label: val }))));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Employee Clinical User API Error Found", error);
            }
        }
    },
    tableDatas: () => {
        return async (dispatch) => {
            try {
                const employeeState = JSON.parse(sessionStorage.getItem("staffFilterState"));
                const res = await employeeServices.TableRecords(employeeState);
                if (res.status === 200) {
                    await dispatch(employeeActions.setTableRecords(res.data.data));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Employee Table Records API Error Found", error);
            }
        }
    },
    employeeDetails: (employeeDetails) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.EmployeeDetails(employeeDetails.employeeId);
                if (res.status === 200) {
                    await dispatch(employeeRequests.updateEmployeeDetailView({ show: true, data: { ...res.data.data } }));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Employee Details API Error Found", error);
            }
        }
    },
    employeeName: () => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.EmployeeName();
                if (res.status === 200) {
                    await dispatch(employeeActions.setEmployeeNameLists(res.data.data.map(val => ({ ...val, value: val.employeeId, label: val.empName, locationId: val.locationId, employmentStatus: val.employmentStatus }))));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Employee Name Lists API Error Found", error);
            }
        }
    },
    employeeDesignation: () => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.EmployeeDesignation();
                if (res.status === 200) {
                    await dispatch(employeeActions.setDesignationLists(res.data.data.map(val => ({ value: val.designationId, label: val.designationName }))));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Employee Designation Lists API Error Found", error);
            }
        }
    },
    employeeDepartment: () => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.EmployeeDepartment();
                if (res.status === 200) {
                    await dispatch(employeeActions.setDepartmentLists(res.data.data.map(val => ({ ...val, value: val.departmentId, label: val.departmentName, locationId: val.locationId }))));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Employee Department Lists API Error Found", error);
            }
        }
    },
    employeeType: () => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.EmployeeType();
                if (res.status === 200) {
                    await dispatch(employeeActions.setEmployeeTypeLists(res.data.data.map((val) => ({ value: val.employeeTypeCode, label: val.employeeType, employeeTypeId: val.employeeTypeId }))));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Employee Department Lists API Error Found", error);
            }
        }
    },
    location: () => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.EmployeeLocation();
                if (res.status === 200) {
                    await dispatch(employeeActions.setLocationLists(res.data.data.map(val => ({ value: val.locationId, label: val.locationCountry }))));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Employee Location Lists API Error Found", error);
            }
        }
    },
    status: () => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.EmployeeStatus();
                if (res.status === 200) {
                    await dispatch(employeeActions.setEmployeeStatusLists(res.data.data.map((val, idx) => ({ value: idx + 1, label: val }))));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Employee Status Lists API Error Found", error);
            }
        }
    },
    loader: (isload) => {
        return async (dispatch) => {
            dispatch(employeeActions.setEmployeeLoader(isload));
        }
    },
    getEmployeeDocument: (type, documentId) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getEmployeeDocument(type, documentId);
                if (res.status === 200) {
                    if (type === "continousEducation" || type === "workHistory" || type === "qualification") {
                        await dispatch(userRequest.imageViewer({ show: true, data: res.data.data.employeeImageBinary, imageName: res.data.data.employeeImage }));
                    }
                    else if (type === "compliance" || type === "hrDocument") {
                        await dispatch(userRequest.imageViewer({ show: true, data: res.data.data.documentImage, imageName: res.data.data.documentName }));
                    }
                    else if (type === "training") {
                        await dispatch(userRequest.imageViewer({ show: true, data: res.data.data.trainingDocBinary, imageName: res.data.data.trainingDocumentName }));
                    }
                    else {
                        await dispatch(userRequest.imageViewer({ show: true, data: res.data.data.imageBinary, imageName: res.data.data.imageName }));
                    }
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Employee Certificate API Error Found", error);
            }
        }
    },
    viewMultipleDocuments: (type, documentId, key, header) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getEmployeeDocument(type, documentId);
                if (res.status === 200) {
                    const convertedDocs = Array.isArray(res.data.data) ? res.data.data.map(val => ({ name: val.documentName, binary: val.documentBinary })) : res.data.data[key].map(val => ({ name: val.documentName, binary: val.documentBinary }));
                    await dispatch(loginResponseActions.setMultiDocumentViewer({ show: true, docs: convertedDocs, header }));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Multiple Documents API Error Found", error);
            }
        }
    },
    updateEmployeeDetailView: (data) => {
        return async (dispatch) => {
            await dispatch(employeeActions.setEmployeeDetailView(data));
        }
    },
    setEmployeeModule: (data) => {
        return async (dispatch) => {
            await dispatch(employeeActions.setEmployeeModule(data));
        }
    },
    //                                ------------------   Employee Personal Screen  -------------------
    createEmployee_Personal: (loginId, data, setCallback) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.createEmployee__personal(loginId, data);
                if (res.status <= 202) {
                    await setCallback(true, res.data.data, data);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Create Personal Details API Error Found", error);
            }
        }
    },
    updateEmployee_Personal: (employeeId, data, setCallback) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.updateEmployee_personal(employeeId, data);
                if (res.status <= 202) {
                    await setCallback(true, res.data.data, data);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Create Personal Details API Error Found", error);
            }
        }
    },
    getEmployee_Personal: (selectedRow, history) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getEmployee_personal(selectedRow.employeeId);
                if (res.status <= 202) {
                    await dispatch(employeeRequests.setEmployeeModule({ data: {}, communication: {}, work: {}, personalDetails: {}, workDetails: {}, personal: { ...selectedRow, ...res.data.data }, action: "Edit", isDisable: !!(Object.hasOwn(selectedRow, "employeeStatus") && typeof (selectedRow.employeeStatus) === "string" && selectedRow.employeeStatus.length > 0 && selectedRow.employeeStatus === setDefaultValue.employmentStatus.relieved) }));
                    history && await history.push(routerPath.employeePersonal);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("get Personal Details API Error Found", error);
            }
        }
    },
    getGrade: () => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getgradeLists();
                if (res.status === 200) {
                    await dispatch(employeeActions.setGradeList(res.data.data.map(val => ({ label: val.gradeName, value: val.gradeId }))));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Grade API Error Found", error);
            }
        }
    },
    //                                ------------------   Employee Work Screen  -------------------
    getEmployee_work_details: (employeeId, getDetailsBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getEmployee_work_details(employeeId);
                if (res.status <= 202) {
                    await getDetailsBack(true, res.data.data);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("get Work details API Error Found", error);
            }
        }
    },
    createEmployee_work: (loginId, data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.createEmployee_work(loginId, data);
                if (res.status <= 202) {
                    await setCallBack(true, res.data.data);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Create Work details API Error Found", error);
            }
        }
    },
    updateEmployee_work: (employeeId, data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.updateEmployee_work(employeeId, data);
                if (res.status <= 202) {
                    await setCallBack(true);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Update Work details API Error Found", error);
            }
        }
    },
    //                                ------------------   Employee Continuous Education  -------------------
    getEducationDetails: (employeeId, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getContinuousEducation(employeeId);
                if (res.status <= 202) {
                    await setCallBack(true, res.data.data);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Employee Continuous Education details API Error Found", error);
            }
        }
    },
    createEducationDetails: (data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.createContinuousEducationDetails(data);
                if (res.status <= 202) {
                    await setCallBack(true);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Create Employee Continuous Education details API Error Found", error);
            }
        }
    },
    updateEducationDetails: (continuousEducationId, data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.updateEducationDetails(continuousEducationId, data);
                if (res.status <= 202) {
                    await setCallBack(true);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Update Employee Continuous Education details API Error Found", error);
            }
        }
    },
    getCourseData: (continuousEducationId, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getEmployeeDocument("continousEducation", continuousEducationId);
                if (res.status <= 202) {
                    await setCallBack(true, res.data.data);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Create Work History details API Error Found", error);
            }
        }
    },
    deleteEducationDetails: (continuousEducationId, data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.deleteEducationDetails(continuousEducationId, data);
                if (res.status <= 202) {
                    await setCallBack(res.data.status);
                    dispatch(errorHandling(res));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Delete Employee Continuous Education details API Error Found", error);
            }
        }
    },
    //                                  ------------------   Employee Work History Screen  -------------------
    createemploeeWorkHistory: (data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.createWorkHistory(data);
                if (res.status <= 202) {
                    await setCallBack(true);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("get Certificate details API Error Found", error);
            }
        }
    },
    updateWorkHistoryDetails: (workHistoryId, data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.updateWorkHistoryDetails(workHistoryId, data);
                if (res.status <= 202) {
                    await setCallBack(true);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Update Work History details API Error Found", error);
            }
        }
    },
    getWorkHistoryDetails: (employeeID, callBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getWorkHistoryDetails(employeeID);
                if (res.status === 200) {
                    await callBack(true, res.data.data);
                } else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Qualification Lists by QualificationId - API Error Found", error);
            }
        }
    },
    getWorkHistory: (workHistoryId, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getWorkHistory(workHistoryId);
                if (res.status <= 202) {
                    await setCallBack(true, res.data.data);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Employee Continuous Education details API Error Found", error);
            }
        }
    },
    deleteWorkHistory: (workHistoryId, data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.deleteWorkHistory(workHistoryId, data);
                if (res.status <= 202) {
                    await setCallBack(res.data.status);
                    dispatch(errorHandling(res));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Delete Employee Work History details API Error Found", error);
            }
        }
    },
    //                                ------------------   Employee Nys Compliance Education  -------------------
    getComplianceCategory: () => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getComplianceCategory();
                if (res.status <= 202) {
                    await dispatch(employeeActions.setNysComplianceCategory(res.data.data.map(val => ({ ...val, value: val.complianceCategoryId, label: val.complianceCategory, compliancePeriodIds: val?.compliancePeriodId }))));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Nys Compliance Category dropdown API Error Found", error);
            }
        }
    },
    getCompliancePeriod: () => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getCompliancePeriod();
                if (res.status <= 202) {
                    await dispatch(employeeActions.setNysCompliancePeriod(res.data.data.map(val => ({ value: val.compliancePeriodId, label: val.compliancePeriod }))));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Nys Compliance Period dropdown API Error Found", error);
            }
        }
    },
    getNysComplianceDetails: (employeeId, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getNysComplianceDetails(employeeId);
                if (res.status <= 202) {
                    await setCallBack(true, res.data.data);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Nys Compliance data API Error Found", error);
            }
        }
    },
    createNysComplianceRecords: (data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.createNysComplianceRecords(data);
                if (res.status <= 202) {
                    await setCallBack(true);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Create Nys Compliance details API Error Found", error);
            }
        }
    },
    updateNysComplianceRecords: (id, data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.updateNysComplianceRecords(id, data);
                if (res.status <= 202) {
                    await setCallBack(true);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Update Nys Compliance Records API Error Found", error);
            }
        }
    },
    getNysComplianceData: (id, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getEmployeeDocument("compliance", id);
                if (res.status <= 202) {
                    await setCallBack(true, res.data.data);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get NYS Compliance details API Error Found", error);
            }
        }
    },
    deleteNysComplianceRecord: (id, data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.deleteNysComplianceRecord(id, data);
                if (res.status <= 202) {
                    await setCallBack(true);
                }
                await dispatch(errorHandling(res));

            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Delete NYS Compliance data API Error Found", error);
            }
        }
    },
    //                                ------------------   Employee Training Screen  -------------------
    getEmployeeTrainingDetails: (employeeId, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getEmployeeTrainingDetails(employeeId);
                if (res.status <= 202) {
                    await setCallBack(true, res.data.data);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Employee Training details API Error Found", error);
            }
        }
    },
    createTrainingRecords: (data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.createTrainingRecords(data);
                if (res.status <= 202) {
                    await setCallBack(true);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Create Training Records API Error Found", error);
            }
        }
    },
    updateTrainingRecords: (id, data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.updateTrainingRecords(id, data);
                if (res.status <= 202) {
                    await setCallBack(true);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Update Training Records API Error Found", error);
            }
        }
    },
    getTrainingData: (id, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getEmployeeDocument("training", id);
                if (res.status <= 202) {
                    await setCallBack(true, res.data.data);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get employee training document API Error Found", error);
            }
        }
    },
    getTrainingCategory: () => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getTrainingCategory();
                if (res.status <= 202) {
                    await dispatch(employeeActions.setTrainingCategory(res.data.data.map(val => ({ value: val.trainingCategoryId, label: val.trainingCategory }))));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get employee training category API Error Found", error);
            }
        }
    },
    deleteTrainingRecord: (id, data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.deleteTrainingRecord(id, data);
                if (res.status <= 202) {
                    await setCallBack(true);
                }
                await dispatch(errorHandling(res));
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Delete training Record API Error Found", error);
            }
        }
    },
    //                                ------------------   Employee HR Documents  -------------------
    getHrDocumentDetails: (employeeId, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getHrDocumentDetails(employeeId);
                if (res.status <= 202) {
                    await setCallBack(true, res.data.data);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Hr Documents data API Error Found", error);
            }
        }
    },
    createHrDocumentRecords: (data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.createHrDocumentRecords(data);
                if (res.status <= 202) {
                    await setCallBack(true);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Create Hr Document details API Error Found", error);
            }
        }
    },
    updateHrDocumentRecords: (id, data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.updateHrDocumentRecords(id, data);
                if (res.status <= 202) {
                    await setCallBack(true);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Update Hr Document Records API Error Found", error);
            }
        }
    },
    getHrDocumentData: (id, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getEmployeeDocument("hrDocument", id);
                if (res.status <= 202) {
                    await setCallBack(true, res.data.data);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Hr Documents API Error Found", error);
            }
        }
    },
    setDocumentType: () => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.hrDocumentType();
                if (res.status <= 202) {
                    await dispatch(employeeActions.setDocumentType(res.data.data.map(val => ({ value: val.documentTypeId, label: val.documentName }))));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Hr Document Type API Error Found", error);
            }
        }
    },
    deleteHRDocumentRecord: (id, data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.deleteHrDocumentRecord(id, data);
                if (res.status <= 202) {
                    await setCallBack(true);
                    dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Delete Hr Document Record API Error Found", error);
            }
        }
    },
    getEmployeeDashboardInfo: (id) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getEmployeeDashboardinfo(id);
                if (res.status <= 202) {
                    await dispatch(employeeDashboardActions.getEmployeeDashboardDetails(res.data.data))
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Employee Dashboard Info Record API Error Found", error);
            }
        }
    },
    getEmployeeBirthdayDetails: (id) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getEmployeeBirthDayDetails(id);
                if (res.status <= 202) {
                    await dispatch(employeeDashboardActions.getBirthDayDeatils(res.data.data))
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Employee Birthday Details Record API Error Found", error);

            }
        }
    },
    getEmployeeleaveDetails: (id) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getEmployeeLeaveDetails(id);
                if (res.status <= 202) {
                    await dispatch(employeeDashboardActions.getEmployeeLeaveDetails(res.data.data))
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Employee leave Details Record API Error Found", error);

            }
        }
    },
    getEmployeeLeaveAndPermissionHistory: (params) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getEmployeeLeavePermissionHistory(params);
                if (res.status <= 202) {
                    await dispatch(employeeDashboardActions.getLeaveAndPermissionHistory(res.data.data));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Employee leave And Permission  Details Record API Error Found", error);

            }
        }
    },
}

export const userRequest = {
    getImageData: (type, imageId) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.getImageData(type, imageId);
                if (res.status === 200) {
                    await dispatch(userRequest.imageViewer({ show: true, data: res.data.data.documentBinary, imageName: res.data.data.documentName }));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("get Image data API Error Found", error);
            }
        }
    },
    imageViewer: (data) => {
        return async (dispatch) => {
            await dispatch(loginResponseActions.updateImageViewer(data));
        }
    },
    hideImageViewer: () => {
        return async (dispatch) => {
            await dispatch(loginResponseActions.updateImageViewer({ show: false, data: "", imageName: "" }))
        }
    },
    updateUserDetails: (params) => {
        return async (dispatch) => {
            await dispatch(userActions.setUserDetails(params));
        }
    },
    apiResponse: (params) => {
        return async (dispatch) => {
            await dispatch(loginResponseActions.apiResponse(params));
        }
    },
}

export const loginRequest = {
    userInformation: (setCallBack) => {
        return async () => {
            try {
                const res = await loginService.UserInformation();
                if (res.status === 200) {
                    setCallBack(true, res.data.data);
                }
                else {
                    setCallBack(false, res.data);
                }
            } catch (error) {
                setCallBack(false, error);
                console.error("User Credential API Error Found", error);
            }
        }
    },
    tableDatas: () => {
        return async (dispatch) => {
            try {
                const loginState = JSON.parse(sessionStorage.getItem("loginFilterState"));
                const res = await loginService.TableRecords(loginState);
                if (res.status === 200) {
                    await dispatch(loginActions.setTableRecords(res.data.data));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Login Table Records API Error Found", error);
            }
        }
    },
    employeeName: () => {
        return async (dispatch) => {
            try {
                const res = await loginService.EmployeeName();
                if (res.status === 200) {
                    await dispatch(loginActions.setEmployeeNameLists(res.data.data.map(val => ({ ...val, value: val.loginId, label: val.empName })).filter((v, i, a) => a.findIndex(v2 => (v2.value === v.value)) === i)));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Login Name Lists API Error Found", error);
            }
        }
    },
    location: () => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.EmployeeLocation();
                if (res.status === 200) {
                    await dispatch(loginActions.setLocationLists(res.data.data.map(val => ({ value: val.locationId, label: val.locationCountry }))));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get User Login Location Lists API Error Found", error);
            }
        }
    },
    loginId: () => {
        return async (dispatch) => {
            try {
                const res = await loginService.LoginIdLists();
                if (res.status === 200) {
                    await dispatch(loginActions.setLoginIDLists(res.data.data.map((val, idx) => ({ value: idx + 1, label: val }))));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get User LoginID Lists API Error Found", error);
            }
        }
    },
    roles: () => {
        return async (dispatch) => {
            try {
                const res = await loginService.Roles();
                if (res.status === 200) {
                    await dispatch(loginActions.setRoleLists(res.data.data.map(val => ({ value: val.id, label: val.roleName }))));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get User Role Lists API Error Found", error);
            }
        }
    },
    status: () => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.EmployeeStatus();
                if (res.status === 200) {
                    await dispatch(loginActions.setStatusLists(res.data.data.map((val, idx) => ({ value: idx + 1, label: val }))));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Employee Status Lists API Error Found", error);
            }
        }
    },
    loader: (isload) => {
        return async (dispatch) => {
            dispatch(loginActions.setLoginLoader(isload));
        }
    }
}

export const loginUserRequest = {
    createUser: (data, isValidated, setCallback) => {
        return async (dispatch) => {
            try {
                const res = await loginService.createUser(data, isValidated);
                if (res.status <= 202) {
                    await setCallback(res.data.data);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Create User API Error Found", error);
            }
        }
    },
    updateUserInfo: (loginId, data, setCallback) => {
        return async (dispatch) => {
            try {
                const res = await loginService.editUser(loginId, data);
                if (res.status === 200) {
                    setCallback();
                    await dispatch(loginActions.resetUserDetails());
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Update user API error found", error);
            }
        }
    },
    getEmployeType: () => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.EmployeeType();
                if (res.status === 200) {
                    await dispatch(loginActions.setEmployeeType(res.data.data.map((val) => ({ value: val.employeeTypeCode, label: val.employeeType, employeeTypeId: val.employeeTypeId }))));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get employee type API error found", error);
            }
        }
    },
    getUserDetails: (selectedData, history) => {
        return async (dispatch) => {
            try {
                const res = await loginService.getUserDetails(selectedData.loginid);
                if (res.status === 200) {
                    await dispatch(loginActions.setUserDetails({ ...res.data.data, loginId: selectedData.loginid, employeeCode: selectedData?.employeeCode }));
                    history.push(routerPath.loginUserForm);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get employee type API error found", error);
            }
        }
    },
    resetUserDetails: () => {
        return async (dispatch) => {
            dispatch(loginActions.resetUserDetails());
        }
    },
    getEmployeeDetails: (loginId, history) => {
        return async (dispatch) => {
            try {
                const res = await loginService.getEmployeeDetails(loginId);
                if (res.status === 200) {
                    await dispatch(employeeActions.setEmployeeModule({ data: res.data.data, action: "Add", personal: {}, isDisable: false, personalDetails: {}, workDetails: {}, communication: {}, work: {} }));
                    await history.push(routerPath.employeePersonal);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get employee Details API error found", error);
            }
        }
    },
    deleteLoginRecord: (loginId, data) => {
        return async (dispatch) => {
            try {
                const res = await loginService.deleteLoginRecord(loginId, data);
                if (res.status <= 202) {
                    await dispatch(loginRequest.tableDatas());
                }
                await dispatch(errorHandling(res));
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Delete Login Record API error found", error);
            }
        }
    }
}

export const CommunicationRequest = {
    location: (callBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.EmployeeLocation();
                if (res.status <= 202) {
                    let resp = res.data.data.map((val) => { return { value: val.locationId, label: val.locationCountry } });
                    let result = resp.filter((val) => val.label !== "All")
                    await callBack(result);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Employee Location Lists API Error Found", error);
            }
        }
    },
    createCommunication: (data, history) => {
        return async (dispatch) => {
            try {
                const res = await communicationService.createCommunication(data);
                if (res.status <= 202) {
                    await history.push(routerPath.employeeQualification);
                }
                else {
                    await dispatch(errorHandling(res));
                }

            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Create Employee - Communication API Error Found", error);
            }
        }
    },
    editCommunication: (data, empCmmId, history) => {
        return async (dispatch) => {
            try {
                const res = await communicationService.editCommunication(data, empCmmId);
                if (res.status <= 202) {
                    await history.push(routerPath.employeeQualification);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Edit Employee - Communication API Error Found", error);
            }
        }
    },
    getEmployeeCodeAndDetails: (loginId, callBack) => {
        return async (dispatch) => {
            try {
                const res = await communicationService.getEmployeeCodeAndDetails(loginId);
                if (res.status === 200) {
                    callBack(res.data);
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Employee code and Details - Communication API Error Found", error);
            }
        }
    },
    getCommunicationInfo: (empId, callBack) => {
        return async (dispatch) => {
            try {
                const res = await communicationService.getCommunicationInfo(empId);
                if (res.status === 200) {
                    callBack(res.data.data);
                } else {
                    await dispatch(errorHandling(res));
                    callBack(false);
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Employee - Communication API Error Found", error);
            }
        }
    }
}

export const qualificationrequest = {
    location: (callBack) => {
        return async (dispatch) => {
            try {
                const res = await employeeServices.EmployeeLocation();
                if (res.status === 200) {
                    let resp = res.data.data.map((val) => { return { value: val.locationId, label: val.locationCountry } });
                    let result = resp.filter((val) => val.label !== "All")
                    await callBack(result);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Lists API Error Found", error);
            }
        }
    },
    getQualificationList: (callBack) => {
        return async (dispatch) => {
            try {
                const res = await qualificationService.getQualificationList();
                if (res.status === 200) {
                    let resp = res.data.data.map((val) => { return { value: val.qualificationId, label: val.qualificationName } });
                    await callBack(resp);
                } else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Qualification Lists API Error Found", error);
            }
        }
    },
    saveQualification: (data) => {
        return async (dispatch) => {
            try {
                const res = await qualificationService.saveQualification(data);
                if (res.status !== 200) {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Qualification Lists API Error Found", error);
            }
        }
    },
    putQualification: (data, qualifId) => {
        return async (dispatch) => {
            try {
                const res = await qualificationService.putQualification(data, qualifId);
                if (res.status !== 200) {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Qualification Lists API Error Found", error);
            }
        }
    },
    getEducationList: (qualifId, callBack) => {
        return async (dispatch) => {
            try {
                const res = await qualificationService.getEducationList(qualifId);
                if (res.status === 200) {
                    callBack(res.data);
                } else if (res.status !== 200) {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Qualification Lists API Error Found", error);
            }
        }
    },
    getQualificationDetailsByEmpId: (empId, callback) => {
        return async (dispatch) => {
            try {
                const res = await qualificationService.getQualificationDetailsByEmpId(empId);
                if (res.status === 200) {
                    callback(res.data.data);
                } else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Qualification Lists by EmpId - API Error Found", error);
            }
        }
    },
    getQualificationDetailsByQualfId: (qualfId, callBack) => {
        return async (dispatch) => {
            try {
                const res = await qualificationService.getQualificationDetailsByQualfId(qualfId);
                if (res.status === 200) {
                    callBack(res.data.data, qualfId);
                } else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Qualification Lists by QualificationId - API Error Found", error);
            }
        }
    },
    getFileByQualfId: (qualfId, callBack) => {
        return async (dispatch) => {
            try {
                const res = await qualificationService.getFileByQualfId(qualfId);
                if (res.status === 200) {
                    callBack(res.data.data, qualfId);
                } else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Qualification Lists by QualificationId - API Error Found", error);
            }
        }
    },
    deleteQualificationDetails: (qualfId, data, callBack) => {
        return async (dispatch) => {
            try {
                const res = await qualificationService.deleteQualificationDetails(qualfId, data);
                if (res.status <= 202) {
                    await callBack(res.data.status);
                    dispatch(errorHandling(res));
                } else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Delete Qualification Lists by QualificationId - API Error Found", error);
            }
        }
    }
}

export const generalRequest = {
    uploadDocument: (file, uploadFileBack) => {
        return async (dispatch) => {
            try {
                const res = await generalService.uploadDocument(file);
                if (res.status === 200) {
                    uploadFileBack(true, res.data.data);
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Employee Location Lists API Error Found", error);
            }
        }
    }
}

const errorHandling = (params) => {
    let error = { ...params };
    return async (dispatch) => {
        if (error?.status && error.status === 403) {
            return dispatch(userRequest.apiResponse({ show: true, status: 403, header: "Warning!", message: "Access Denied !! Please login again." }));
        }
        if (!error || !error.status || !error.data) {
            return dispatch(userRequest.apiResponse({ show: true, status: 99999, header: "Error!", message: "Internal Server Error" }));
        }

        const statusCode = error.status;
        let statusText = error.data;
        let isOptional = false;

        if ("information" in error.data) {
            statusText = error.data.information.description;
            if (error.data.information.message === "Optional type") {
                isOptional = true;
            }
        }
        else if (typeof (statusText) !== "string") {
            if ("message" in error.data) {
                statusText = error.data.message;
            } else {
                statusText = "Internal Server Error"
            }
        }

        switch (statusCode) {
            case 200:
                return dispatch(userRequest.apiResponse({ show: true, status: statusCode, header: "Message ", message: statusText, isOptional }));
            case 204:
                return dispatch(userRequest.apiResponse({ show: true, status: statusCode, header: "Warning!", message: "No Content", isOptional }));
            case 400:
                return dispatch(userRequest.apiResponse({ show: true, status: statusCode, header: "Warning!", message: "Bad Request", isOptional }));
            case 401:
                return dispatch(userRequest.apiResponse({ show: true, status: statusCode, header: "Warning!", message: "Your session has timed out. Please login again.", isOptional }));
            case 403:
                return dispatch(userRequest.apiResponse({ show: true, status: statusCode, header: "Warning!", message: "Your session has timed out. Please login again.", isOptional }));
            case 404:
                return dispatch(userRequest.apiResponse({ show: true, status: statusCode, header: "Error!", message: "Oops! Page Not Found", isOptional }));
            case 500:
                return dispatch(userRequest.apiResponse({ show: true, status: statusCode, header: "Error!", message: "Internal Server Error", isOptional }));
            default:
                return dispatch(userRequest.apiResponse({ show: true, status: statusCode, header: isOptional ? "Confirmation" : (statusText === "Internal Server Error" ? "Error!" : "Warning!"), message: statusText, isOptional }));
        }
    }
}

export const reportRequest = {
    getComplianceReports: (complianceState) => {
        return async (dispatch) => {
            try {
                const res = await reportService.complianceRecords(complianceState);
                if (res.status <= 202) {
                    dispatch(complianceReportActions.setComplianceRecord(res.data?.data ? res.data?.data : []))
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Compliance Reports API Error Found", error);
            }
        }
    },
    sendComplianceMailRequest: (data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await reportService.complianceSendMail(data);
                if (res.status <= 202) {
                    setCallBack();
                }
                await dispatch(errorHandling(res));
            }
            catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Compliance Mail Request Error Found", error);
            }
        }
    },
    getComplianceEmailTemplateRequest: (params) => {
        return async (dispatch) => {
            try {
                const res = await reportService.complianceEmailTemplate(params);
                if (res.status <= 202) {
                    await dispatch(complianceReportActions.setComplianceNotifyMailDetails({ show: true, data: res.data.data }));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            }
            catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Compliance Mail Request Error Found", error);
            }
        }
    },
    getEmployeeType: () => {
        return async (dispatch) => {
            try {
                const res = await reportService.employeeType();
                if (res.status <= 202) {
                    dispatch(complianceReportActions.setEmployeeType(res.data?.data ? res.data?.data.map((val, idx) => ({ label: val, value: idx + 1 })) : []));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            }
            catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Employee Type API Error Found", error);
            }
        }
    },
    setComplianceView: (data) => {
        return async (dispatch) => {
            await dispatch(complianceReportActions.setComplianceView(data));
        }
    },
    setComplianceLoader: (isload) => {
        return async (dispatch) => {
            await dispatch(complianceReportActions.setLoader(isload));
        }
    },
    getComplianceCertificate: (selectedRecord) => {
        return async (dispatch) => {
            try {
                const res = await reportService.complianceCertificate(selectedRecord);
                if (res.status <= 202) {
                    await dispatch(loginResponseActions.setMultiDocumentViewer({ show: true, docs: res.data.data.map(val => ({ name: val.documentName, binary: val.documentBinary })), header: "Compliance Reports" }));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            }
            catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Compliance Certificate API Error Found", error);
            }
        }
    },
    leaveReports: {
        getTotalHoursReport: (data, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await reportService.leaveReport.totalHoursReport(data);
                    if (res.status <= 202) {
                        await setCallBack(res.data.data)
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Total Hours Report API Error Found", error);
                }
            }
        },
        getEmployeeAttendanceReport: (data, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await reportService.leaveReport.employeeAttendanceReport(data);
                    if (res.status <= 202) {
                        await setCallBack(res.data.data)
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Employee Attendance Report API Error Found", error);
                }
            }
        },
        getLeaveAvailedReport: (data, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await reportService.leaveReport.leaveAvailedReport(data);
                    if (res.status <= 202) {
                        await setCallBack(res.data.data)
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Employee's Leave Detail Availed Report API Error Found", error);
                }
            }
        }
    }
}

export const leaveManagementRequest = {
    setLoader: (isload) => {
        return async (dispatch) => {
            await dispatch(leaveManagementActions.setLoader(isload));
        }
    },
    setLeaveLedgerData: (data) => {
        return async (dispatch) => {
            await dispatch(leaveManagementActions.setLeaveLedgerData(data));
        }
    },
    leaveHistory: {
        getLeaveHistoryDatas: (params) => {
            return async (dispatch) => {
                try {
                    const res = await leaveManagementService.leaveHistory.getLeaveHistoryData(params);
                    if (res.status === 200) {
                        await dispatch(leaveManagementActions.setLeaveHistoryData(res.data.data));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Leave History API error found", error);
                }
            }
        },
        editLeaveHistoryData: (requestId, data, isLossOfPay, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await leaveManagementService.leaveHistory.editLeaveHistoryData(requestId, data, isLossOfPay);
                    if (res.status <= 202) {
                        await setCallBack(true)
                        dispatch(errorHandling(res));
                    }
                    else {
                        await setCallBack(false);
                        await dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await setCallBack(false);
                    await dispatch(errorHandling(error.response));
                    console.error("Edit Leave Request API error found", error);
                }
            }
        },
        cancelLeaveHistoryData: (filterRecords, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await leaveManagementService.leaveHistory.cancelLeaveHistoryData(filterRecords);
                    if (res.status <= 202) {
                        await setCallBack(true)
                        dispatch(errorHandling(res));
                    }
                    else {
                        await setCallBack(false);
                        await dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await setCallBack(false);
                    await dispatch(errorHandling(error.response));
                    console.error("Cancel Leave Request API error found", error);
                }
            }
        },
        getHistoryLeaveRequestDetails: (reqId, status, selectedRow) => {
            return async (dispatch) => {
                try {
                    let res = await leaveManagementService.leaveRequestQueue.leaveReqDetails(reqId, status);
                    if (res.status === 200 && res.data.status) {
                        let data = res.data.data.leaveDetailsRecord.filter(res => exportDateFormat(res.date) === exportDateFormat(selectedRow.leaveDate));
                        await dispatch(leaveManagementActions.setLeaveReqDetails({ view: true, reqId: reqId, empName: res.data.data.employeeName, status, rowData: data, selectedRowData: [], comments: "", requestStatus: '' }));
                    } else {
                        await dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error(error);
                }
            }
        },
    },
    leaveRequest: {
        addLeaveRequest: (userId, data, isLossOfPay, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await leaveManagementService.leaveRequest.addLeaveRequest(userId, data, isLossOfPay);
                    if (res.status === 200) {
                        await setCallBack(true);
                        dispatch(errorHandling(res));
                    }
                    else {
                        await setCallBack(false);
                        await dispatch(errorHandling(res));
                    }
                } catch (error) {
                    setCallBack(false);
                    await dispatch(errorHandling(error.response));
                    console.error("Add Leave Request API error found", error);
                }
            }
        },
        getLeaveType: (locationId) => {
            return async (dispatch) => {
                try {
                    const res = await leaveManagementService.leaveRequest.getLeaveRequestType(0);
                    if (res.status <= 202) {
                        let leaveType = res.data.data && res.data.data.length > 0 ? res.data.data : [];
                        await dispatch(leaveManagementActions.setLeaveType(leaveType.filter(val => val.locationID === locationId).map(val => ({ value: val.leaveTypeId, label: val.leaveTypeName }))));
                        await dispatch(leaveManagementActions.setAllLeaveTypes(leaveType.sort((val, val2) => val.locationID - val2.locationID).map(val => ({ value: val.leaveTypeId, label: val.leaveTypeName, locationId: val.locationID }))));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Leave Type API error found", error);
                }
            }
        },
        getLeaveBalance: (loginId, getLeaveBalanceBack) => {
            return async (dispatch) => {
                try {
                    const res = await leaveManagementService.leaveRequest.getLeaveBalance(loginId);
                    if (res.status <= 202) {
                        await getLeaveBalanceBack(res.data.data);
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Leave Balance API error found", error);
                }
            }
        }
    },
    leaveRequestQueue: {
        leaveReqEmpFilter: (params, callBack) => {
            return async (dispatch) => {
                try {
                    const res = await leaveManagementService.leaveRequestQueue.getLeaveRequestQueue(params);
                    if (res.status === 200) {
                        callBack(res.data.data);
                    } else {
                        await dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Lists API Error Found", error);
                }
            }
        },
        getLeaveHistoryData: (UserID, callBack) => {
            return async (dispatch) => {
                try {
                    const res = await leaveManagementService.leaveHistory.getLeaveHistoryData(UserID);
                    if (res.status === 200) {
                        callBack(res.data.data);
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Leave History API error found", error);
                }
            }
        },
        postApprovalLeaveReq: (data) => {
            return async (dispatch) => {
                try {
                    const res = await leaveManagementService.leaveRequestQueue.postLeaveRequestApproval(data);
                    if (res.status !== 200) {
                        await dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Leave History API error found", error);
                }
            }
        },
        getLeaveRequestDetails: (reqId, status) => {
            return async (dispatch) => {
                try {
                    let res = await leaveManagementService.leaveRequestQueue.leaveReqDetails(reqId, status);
                    if (res.status === 200 && res.data.status) {
                        await dispatch(leaveManagementActions.setLeaveReqDetails({ view: true, reqId: reqId, empName: res.data.data.employeeName, status, rowData: res.data.data.leaveDetailsRecord, selectedRowData: [], comments: "", requestStatus: '' }));
                    } else {
                        await dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error(error);
                }
            }
        },
        ackLeaveReqQueue: (data, isLopFlag, filtrerCallback) => {
            return async (dispatch) => {
                try {
                    let res = await leaveManagementService.leaveRequestQueue.ackLeaveRequest(data, isLopFlag);
                    if (res.data.status && filtrerCallback) {
                        await filtrerCallback();
                    }
                    if (res.status) {
                        dispatch(errorHandling(res));
                    }
                } catch (error) {
                    filtrerCallback();
                    await dispatch(errorHandling(error.response));
                    console.error(error);
                }
            }
        },
        getLeaveHistoryPopupData: (rowData) => {
            return async (dispatch) => {
                try {
                    const res = await leaveManagementService.leaveHistory.getLeaveHistoryData(rowData);
                    if (res.status <= 202) {
                        await dispatch(leaveManagementActions.setLeaveHistoryPopup({ show: true, data: res.data.data, rowData: { ...rowData } }));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Employee Leave History API Error Found!", error);
                }
            }
        }
    },
    leaveLedger: {
        getLeaveLedger: (selectedData) => {
            return async (dispatch) => {
                try {
                    const res = await leaveManagementService.leaveLedger.getLeaveLedger(selectedData);
                    if (res.status === 200) {
                        await dispatch(leaveManagementRequest.setLeaveLedgerData(res.data.data));
                    } else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Leave Ledger API Error Found", error);
                }
            }
        },
        updateLeaveLedger: (data, ledgerId) => {
            return async (dispatch) => {
                try {
                    const res = await leaveManagementService.leaveLedger.updateLeaveLedger(data, ledgerId);
                    if (res.status) {
                        dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Update Leave Ledger API Error Found", error);
                }
            }
        },
        deleteLeaveLedger: (ledgerId, data) => {
            return async (dispatch) => {
                try {
                    const res = await leaveManagementService.leaveLedger.deleteLeaveLedger(ledgerId, data);
                    if (res.status) {
                        dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Delete Leave Ledger API Error Found", error);
                }
            }
        }
    },
    leaveStatus: {
        getLeaveStatus: () => {
            return async (dispatch) => {
                try {
                    const res = await leaveManagementService.leaveStatus.getLeaveStatus();
                    if (res.status <= 202) {
                        let data = res.data.data;
                        dispatch(leaveManagementActions.setLeaveStatus(data.map((data, index) => ({ value: index, label: data }))))
                    } else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Leave Status API Error Found", error);
                }
            }
        },
    },
    getPayroll: () => {
        return async (dispatch) => {
            try {
                const res = await leaveManagementService.getPayroll();
                if (res.status <= 202) {
                    dispatch(leaveManagementActions.setPayroll(res.data.data))
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get payroll API Error Found", error);
            }
        }
    },
    viewleaveLedger: {
        getLeaveLedger: (selectedData) => {
            return async (dispatch) => {
                try {
                    const res = await leaveManagementService.leaveLedger.getLeaveLedger(selectedData);
                    if (res.status === 200) {
                        await dispatch(leaveManagementActions.setViewLeaveLedgerData(res.data.data));
                    } else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get view Leave Ledger API Error Found", error);
                }
            }
        }
    },
}

export const sickLeaveRequests = {
    balanceSummary: {
        getFilterParams: (params) => {
            return async (dispatch) => {
                try {
                    const res = await sickLeaveService.getBalanceSummary(params);
                    if (res.status === 200) {
                        await dispatch(sickLeaveActions.setBalanceSummaryData(res.data.data));
                    } else {
                        await dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Sick Leave Balance Summary API Error Found", error);
                }
            }
        }
    },
    SummaryDetails: {
        getFilterParams: (params) => {
            return async (dispatch) => {
                try {
                    const res = await sickLeaveService.getSummaryDetails(params);
                    if (res.status === 200) {
                        await dispatch(sickLeaveActions.setSummaryDetailsData(res.data.data));
                    } else {
                        await dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Sick Leave Summary Details API Error Found", error);
                }
            }
        }
    },
    LeaveLedger: {
        getLeaveLedger: (params) => {
            return async (dispatch) => {
                try {
                    const res = await sickLeaveService.getLeaveLedger(params);
                    if (res.status === 200) {
                        await dispatch(leaveManagementRequest.setLeaveLedgerData(res.data.data));
                    } else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Sick Leave Ledger API Error Found", error);
                }
            }
        },
        deleteLeaveLedger: (ledgerId) => {
            return async (dispatch) => {
                try {
                    const res = await sickLeaveService.deleteLeaveLedger(ledgerId);
                    if (res.status) {
                        dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Delete Sick Leave Ledger API Error Found", error);
                }
            }
        },
        updateLeaveLedger: (data, ledgerId) => {
            return async (dispatch) => {
                try {
                    const res = await sickLeaveService.updateLeaveLedger(data, ledgerId);
                    if (res.status) {
                        dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Update Sick Leave Ledger API Error Found", error);
                }
            }
        },
        addLeaveLedger: (data) => {
            return async (dispatch) => {
                try {
                    const res = await sickLeaveService.addLeaveLedger(data);
                    if (res.status) {
                        dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Add Sick Leave Ledger API Error Found", error);
                }
            }
        }
    }
}

export const eventManagementRequests = {
    recordEvents: {
        getAllEventsTypes: () => {
            return async (dispatch) => {
                try {
                    const res = await eventManagementService.recordEvents.getAllEventTypes();
                    if (res.status === 200) {
                        await dispatch(eventManagementActions.eventTypes(res.data?.data?.map(val => ({ ...val, label: val.eventTypeDescription, value: val.eventTypeId, eventTypeDetails: val.eventTypeDetails && val.eventTypeDetails.length > 0 ? val.eventTypeDetails.map((type) => ({ ...type, label: type.eventTypeDetailDescription, value: type.eventTypeDetailId })) : [] }))));
                    } else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get All Events Types API Error Found", error);
                }
            }
        },
        getAllParticipationLevel: () => {
            return async (dispatch) => {
                try {
                    const res = await eventManagementService.recordEvents.getAllParticipationLevel();
                    if (res.status === 200 && res.data.data) {
                        await dispatch(eventManagementActions.setParticipationLevel(res.data.data.map(val => ({ ...val, label: val.participationLevel, value: val.id }))))
                    } else {
                        await dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get All Participation Level API Error Found", error);
                }
            }
        },
        getEventEmployeeName: (participationStaffTree) => {
            return async (dispatch) => {
                try {
                    const res = await eventManagementService.recordEvents.getEventEmployeeName();
                    if (res.status === 200 && res.data.data) {
                        await participationStaffTree(res.data.data?.length > 0 ? res.data.data : [])
                    } else {
                        await dispatch(errorHandling(res))
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response))
                    console.error("Get All Participation Level API Error Found", error)
                }
            }
        },
        saveEvents: (data, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await eventManagementService.recordEvents.saveEvent(data);
                    if (res.status <= 202) {
                        await setCallBack(res.data.status)
                        dispatch(errorHandling(res))
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response))
                    console.error("Post All events API Error Found", error)
                }
            }
        },
        getEditEvent: (data, type) => {
            return async (dispatch) => {
                try {
                    const res = await eventManagementService.recordEvents.getEditEvent(data.eventID);
                    if (res.status <= 202) {
                        await dispatch(eventManagementActions.setRecordEventPopup({ show: true, data: res.data.data, selectedRow: data, type: type }));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Edit Event API Error Found", error);
                }
            }
        },
        editEvent: (id, data, setCallback) => {
            return async (dispatch) => {
                try {
                    const res = await eventManagementService.recordEvents.editEvent(id, data);
                    if (res.status <= 202) {
                        await setCallback(res.data.status);
                        dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Put Edit Event API Error Found", error)
                }
            }
        }
    },
    viewEvents: {
        getViewEvents: (params, isNew) => {
            return async (dispatch) => {
                try {
                    const res = await eventManagementService.viewEvents.getViewEvents(params);
                    if (res.status <= 202) {
                        const currentYears = getNumberOfYears(params.fromdate, params.toDate);
                        if (isNew) {
                            await dispatch(eventManagementActions.setViewEventsData([...res.data.data]));
                            await dispatch(eventManagementActions.setSelectedYear([...currentYears]));
                        }
                        else {
                            const existingData = eventManagementReducerState().calendarView.data;
                            await dispatch(eventManagementActions.setViewEventsData([...existingData, ...res.data.data]));
                            const existingYears = eventManagementReducerState().calendarView.selectedYears;
                            await dispatch(eventManagementActions.setSelectedYear([...new Set([...existingYears, ...currentYears])]));
                        }
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get View Events API Error Found", error);
                }
            }
        },
        getTabularView: (params) => {
            return async (dispatch) => {
                try {
                    const res = await eventManagementService.viewEvents.getViewEvents(params);
                    if (res.status <= 202) {
                        await dispatch(eventManagementActions.setTabularViewData(res.data.data));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get View Events(Tabular View) API Error Found", error);
                }
            }
        },
        deleteEvent: (params, setCallback) => {
            return async (dispatch) => {
                try {
                    const res = await eventManagementService.viewEvents.deleteEvent(params);
                    if (res.status <= 202) {
                        await setCallback();
                        dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Event Delete API Error Found", error);
                }
            }
        },
        LogViewEventsRequest: (id) => {
            return async (dispatch) => {
                try {
                    const res = await eventManagementService.viewEvents.LogViewEvents(id);
                    if (res.status <= 200) {
                        await dispatch(eventManagementActions.setLogViewPopup({ show: true, data: res.data.data }));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Log View API Error Found", error);
                }
            }
        }
    },
    reportEvents: {
        getEventReports: (params, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await eventManagementService.reportEvents.getEventReports(params);
                    if (res.status <= 202) {
                        await setCallBack(res.data.data);
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Report Events API Error Found", error);
                }
            }
        },
        getDocumentViewforGenerateSummary: (params, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await eventManagementService.reportEvents.getDocumentViewforGenerateSummary(params);
                    if (res.status <= 202) {
                        await setCallBack(res.data.data);
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Document View for Generate Summary API Error Found", error);
                }
            }
        },
    },
    facilityPersonalReport: {
        getFacilityReport: () => {
            return async (dispatch) => {
                try {
                    const res = await eventManagementService.facilityPersonalReport.getFacilityReport();
                    if (res.status <= 202) {
                        await dispatch(eventManagementActions.setFacilityReport({ data: res.data.data }))
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.reponse));
                    console.error("Get All Facility Report API Error Found", error)
                }
            }
        }
    }
}

export const myRequestRequests = {
    getRequestType: () => {
        return async (dispatch) => {
            try {
                const res = await myRequestService.getRequestType();
                if (res.status <= 202) {
                    await dispatch(myRequestActions.setTypeOfRequest(res.data.data.map(val => ({ ...val, value: val.requestTypeId, label: val.request }))))
                } else {
                    await dispatch(errorHandling(res))
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Request Type API Error Found", error);
            }
        }
    },
    addRequest: (params, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await myRequestService.addRequest(params);
                if (res.status <= 202) {
                    await dispatch(errorHandling(res));
                    await setCallBack(true)
                } else {
                    await dispatch(errorHandling(res))
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Add Request API Error Found", error.response);
            }
        }
    },
    getRequest: (params) => {
        return async (dispatch) => {
            try {
                const res = await myRequestService.getRequest(params);
                if (res.status <= 202) {
                    await dispatch(myRequestActions.setRequestData(res.data.data))
                } else {
                    await dispatch(errorHandling(res))
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Request  API Error Found", error);
            }
        }
    },
    editRequest: (requestId, params, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await myRequestService.editRequest(requestId, params);
                if (res.status <= 202) {
                    await dispatch(errorHandling(res));
                    await setCallBack(true)
                } else {
                    await dispatch(errorHandling(res))
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Edit Request  API Error Found", error);
            }
        }
    },
    getRequestDetails: (requestId) => {
        return async (dispatch) => {
            try {
                const res = await myRequestService.getRequestDetails(requestId);
                if (res.status <= 202) {
                    await dispatch(myRequestActions.showPopup({ show: true, selectedRow: res.data.data, actions: "Edit", loader: false }))
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Request Details API Error Found", error)
            }
        }
    },
    getStatusTypes: () => {
        return async (dispatch) => {
            try {
                const res = await myRequestService.typeOfStatus();
                if (res.status <= 202 && res.data.status) {
                    await dispatch(myRequestActions.setStatusTypes(res.data.data.map(val => ({ ...val, value: val.type, label: val.value }))));
                } else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Type of Status API Error Found", error);
            }
        }
    },
    approveRequests: (data) => {
        return async (dispatch) => {
            try {
                const res = await myRequestService.approveRequest(data);
                dispatch(errorHandling(res));
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Approve or Reject Request API Error Found", error);
            }
        }
    },
    trackingRequest: {
        getTrackingRequest: (params) => {
            return async (dispatch) => {
                try {
                    const res = await myRequestService.trackingRequest.getTrackingRequest(params);
                    if (res.status <= 202) {
                        await dispatch(myRequestActions.setTrackingRequest({ data: res.data.data }));
                    } else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Tracking Request Filter API Error Found", error);
                }
            }
        },
        getAssigneeList: () => {
            return async (dispatch) => {
                try {
                    const res = await myRequestService.trackingRequest.getAssigneeList();
                    if (res.status <= 202) {
                        await dispatch(myRequestActions.setAssigneeList(res.data.data.map(val => ({ ...val, label: val.employeeName, value: val.employeeId, image: ("imageBinary" in val) && val.imageBinary?.length > 0 ? val.imageBinary : "" }))));
                    } else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Assignee List API Error Found", error);
                }
            }
        },
        updateTrackingRequestDetails: (id, data, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await myRequestService.trackingRequest.updateTrackingRequestDetails(id, data);
                    if (res.status <= 202) {
                        setCallBack(true);
                    } else {
                        setCallBack(false);
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    setCallBack(false);
                    dispatch(errorHandling(error.response));
                    console.error("Update Tracking Request Details API Error Found", error);
                }
            }
        }
    },
    getTrackingStatus: () => {
        return async (dispatch) => {
            try {
                const res = await myRequestService.getTrackingStatus();
                if (res.status <= 202) {
                    await dispatch(myRequestActions.setTrackingStatus(res.data.data?.length > 0 ? res.data.data.map(val => ({ ...val, label: val.RequestStatus, value: val.StatusID })) : []));
                }
                else {
                    dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Tracking Status API Error Found", error);
            }
        }
    }
}

export const permissionRequests = {
    getPermissionType: () => {
        return async (dispatch) => {
            try {
                const res = await permissionService.permissionType();
                if (res.status <= 202) {
                    await dispatch(permissionAction.setPermissionType(res.data.data?.length > 0 ? res.data.data.map(val => ({ ...val, label: val.permissionType, value: val.permissionTypeID })) : []))
                } else {
                    dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Permission Type API Error Found", error);
            }
        }
    },
    getPermissionHistory: (params) => {
        return async (dispatch) => {
            try {
                const res = await permissionService.permissionHistory(params);
                if (res.status <= 202) {
                    await dispatch(permissionAction.setpermissionRequestdata(res.data.data))
                }
                else {
                    dispatch(errorHandling(res))
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Permission Type API Error Found", error);
            }
        }
    },
    addPermissionRequest: (data, setcallback = null) => {
        return async (dispatch) => {
            try {
                const res = await permissionService.addpermission(data);
                if (res.status <= 202) {
                    if (setcallback) { setcallback(); }
                    await dispatch(errorHandling(res));
                }
                else {
                    dispatch(errorHandling(res))
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Add Permission Api Error Found", error)
            }
        }
    },
    editPermissionRequest: (id, data, setcallback) => {
        return async (dispatch) => {
            try {
                const res = await permissionService.editPermission(id, data);
                if (res.status <= 202) {
                    setcallback();
                    await dispatch(errorHandling(res));
                }
                else {
                    dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Edit Permission API Error Found", error)
            }
        }
    },
    getCurrentMonthPermission: (id) => {
        return async (dispatch) => {
            try {
                const res = await permissionService.getCurrentPermission(id);
                if (res.status <= 202) {
                    await dispatch(permissionAction.setPermissionRequestDetails(res.data?.data));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Current Month Permission History API Error Found", error)
            }
        }
    },
    permissionApproveOrRejectRequest: (data, setcallback) => {
        return async (dispatch) => {
            try {
                const res = await permissionService.permissionApproveOrReject(data);
                if (res.status <= 202) {
                    setcallback();
                    await dispatch(errorHandling(res));
                }
                else {
                    dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Permission Approve Or Rejct Request API Errpr Found", error)
            }
        }
    },
    getPermissionDetailRequest: (params, type) => {
        return async (dispatch) => {
            try {
                const res = await permissionService.getPermissionDetail(params);
                if (res.status <= 202) {
                    await dispatch(permissionAction.setRequestApprovalPopup({ show: true, selectedRowData: res.data.data, requestStatus: type }));
                }
                else {
                    dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Permission Detail Request API Error Found", error)
            }
        }
    },
    viewPermissionHistoryRequest: (params) => {
        return async (dispatch) => {
            try {
                const res = await permissionService.viewPermissionHistory(params);
                if (res.status <= 202) {
                    await dispatch(permissionAction.setPermissionHistoryPopup({ data: res.data.data }));
                }
                else {
                    dispatch(errorHandling(res));
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get View Permission History Request API Error Found", error)
            }
        }
    }
}

export const holidayRequests = {
    getHolidayDetailsForRestrictions: (params, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await holidayService.getHolidayDetailsForRestrictions(params);
                if (res.status <= 202) {
                    await setCallBack(res.data.data);
                } else {
                    dispatch(errorHandling(res));
                }
            }
            catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Holiday Details Request API Error Found", error);
            }
        }
    },
    setFloatingHolidayPopup: {
        saveFloatingHolidayDetails: (data, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await holidayService.setFloatingHolidayPopup.saveFloatingHolidayDetails(data);
                    if (res.status <= 202) {
                        await setCallBack()
                    }
                    dispatch(errorHandling(res));
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Update Floating Holidays Request API Error Found", error);
                }
            }
        }
    },
    holidayList: {
        getHolidayLists: (params) => {
            return async (dispatch) => {
                try {
                    const res = await holidayService.holidayList.getHolidayList(params);
                    if (res.status <= 202) {
                        await dispatch(holidayActions.setHolidayListData(res.data.data));
                    } else {
                        dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Holiday List Request API Error Found", error);
                }
            }
        },
        getFloatingHolidayDetails: (params, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await holidayService.holidayList.getFloatingHolidayDetails(params);
                    if (res.status <= 202) {
                        await setCallBack(res.data.data);
                    } else {
                        dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Holiday List Request API Error Found", error);
                }
            }
        }
    },
    holidayNameList: {
        getHolidayNameLists: (params) => {
            return async (dispatch) => {
                try {
                    const res = await holidayService.holidayNameList.getHolidayNameList(params);
                    if (res.status <= 202) {
                        await dispatch(holidayActions.setHolidayNameLists(res.data.data));
                    } else {
                        dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Holiday Name List Request API Error Found", error);
                }
            }
        },
        addHolidayName: (data, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await holidayService.holidayNameList.addHolidayNameList(data);
                    if (res.status <= 202) {
                        await setCallBack();
                    }
                    dispatch(errorHandling(res));
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Add Holiday Name List Request API Error Found", error);
                }
            }
        },
        editHolidayName: (holidayId, data, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await holidayService.holidayNameList.editHolidayNameList(holidayId, data);
                    if (res.status <= 202) {
                        await setCallBack();
                    }
                    dispatch(errorHandling(res));
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Edit Holiday Name List Request API Error Found", error);
                }
            }
        },
        deleteHolidayName: (holidayId, data, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await holidayService.holidayNameList.deleteHolidayNameList(holidayId, data);
                    if (res.status <= 202) {
                        await setCallBack();
                    }
                    dispatch(errorHandling(res));
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Delete Holiday Name List Request API Error Found", error);
                }
            }
        }
    },
    addHoliday: {
        getHolidayLists: (params, getValidationCallBack = null) => {
            return async (dispatch) => {
                try {
                    const res = await holidayService.addHolidays.getHolidayList(params);
                    if (res.status <= 202) {
                        if (getValidationCallBack) {
                            await getValidationCallBack(res.data.data)
                        } else {
                            await dispatch(holidayActions.setAddHolidayData(res.data.data));
                        }
                    } else {
                        dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Add Holiday List Request API Error Found", error);
                }
            }
        },
        getAllHolidayNames: () => {
            return async (dispatch) => {
                try {
                    const res = await holidayService.holidayNameList.getHolidayNameList();
                    if (res.status <= 202) {
                        await dispatch(holidayActions.setAddHolidayNames(res.data.data.map(val => ({ ...val, label: val.holidayName, value: val.holidayId }))));
                    } else {
                        dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get All Holiday Names Request API Error Found", error);
                }
            }
        },
        addHoliday: (data, setCallback) => {
            return async (dispatch) => {
                try {
                    const res = await holidayService.addHolidays.addHoliday(data);
                    if (res.status <= 202) {
                        await setCallback();
                    }
                    dispatch(errorHandling(res));

                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Add Holiday Request API Error Found", error);
                }
            }
        },
        editHoliday: (holidayId, data, setCallback) => {
            return async (dispatch) => {
                try {
                    const res = await holidayService.addHolidays.editHoliday(holidayId, data);
                    if (res.status <= 202) {
                        await setCallback();
                    }
                    dispatch(errorHandling(res));

                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Edit Holiday Request API Error Found", error);
                }
            }
        },
        deleteHoliday: (holidayId, data, setCallback) => {
            return async (dispatch) => {
                try {
                    const res = await holidayService.addHolidays.deleteHoliday(holidayId, data);
                    if (res.status <= 202) {
                        await setCallback();
                    }
                    dispatch(errorHandling(res));
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Delete Holiday Request API Error Found", error);
                }
            }
        },
        getAlternateHolidayDetails: (id, year, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await holidayService.addHolidays.getalternateHolidays(id, year);
                    if (res.status <= 202) {
                        setCallBack(res.data.data.map(val => ({ ...val, label: val.holidayName, value: val.holidayId })));
                    } else {
                        dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get alternate Holiday Details Request API Error Found", error);
                }
            }
        },
        postUsFederalHolidayDetails: (data, year, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await holidayService.addHolidays.postUsFederalHoliday(data, year);
                    if (res.status <= 202) {
                        await setCallBack(res.data?.data)
                    } else {
                        dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Post US Federal Holiday API Error Found", error);
                }
            }
        }

    },
    addFloatingHolidays: {
        getFloatingHolidayRecords: (params) => {
            return async (dispatch) => {
                try {
                    const res = await holidayService.addFloatingHolidays.getFloatingHolidayRecords(params);
                    if (res.status <= 202) {
                        await dispatch(holidayActions.setAddFloatingHolidayData(res.data.data));
                    } else {
                        dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get All Floating Holidays Request API Error Found", error);
                }
            }
        },
    },
    floatingHolidayList: {
        getYearlyFloatingHolidays: (year, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await holidayService.floatingHolidayList.getYearlyFloatingHolidays(year);
                    if (res.status <= 202) {
                        setCallBack(year, res.data.data);
                    } else {
                        dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Yearly floating Holidays Request API Error Found", error);
                }
            }
        },
        getFloatingHolidayDetails: (params) => {
            return async (dispatch) => {
                try {
                    const res = await holidayService.floatingHolidayList.getFloatingHolidayDetails(params);
                    if (res.status <= 202) {
                        await dispatch(holidayActions.setFloatingHolidayListData(res.data.data));
                    } else {
                        dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get floating Holiday Details Request API Error Found", error);
                }
            }
        }
    },

}

export const payrollRequest = {
    employeePayrollDetailRequest: (params, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await payrollService.employeePayrollDetail(params);
                if (res.status <= 202) {
                    await dispatch(attendancePayrollActions.setPayrollDetails({ data: res.data.data }));
                    await setCallBack(true);
                } else {
                    dispatch(errorHandling(res));
                }
            }
            catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get employee payroll Details Request API Error Found", error);
            }
        }

    },
    payrollUploadRequest: (data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await payrollService.payrollUpload(data);
                if (res.status <= 202) {
                    await dispatch(errorHandling(res));
                    setCallBack(res.status)
                } else {
                    dispatch(errorHandling(res))
                }
            }
            catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Upload Auditor Document popup Request API Error Found", error);
            }
        }
    },
    uploadAuditorRequest: (params) => {
        return async (dispatch) => {
            try {
                const res = await payrollService.uploadAuditor(params);
                if (res.status <= 202) {
                    await dispatch(attendancePayrollActions.setUploadAuditor({ data: res.data.data }))
                }
                else {
                    dispatch(errorHandling(res))
                }
            }
            catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Upload Auditor Document Request API Error Found", error)
            }
        }
    },
    editUploadAuditor: (id, data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await payrollService.editUploadAuditor(id, data);
                if (res.status <= 202) {
                    await dispatch(errorHandling(res));
                    setCallBack(res.status)
                }
                else {
                    dispatch(errorHandling(res))
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response))
                console.error("Edit Upload Auditor Document Request API Error Found", error);
            }
        }
    }
}

export const deputationRequest = {
    getDeputationDetailsRequest: (params) => {
        return async (dispatch) => {
            try {
                const res = await deputationService.getDeputationDetails(params);
                if (res.status <= 202) {
                    await dispatch(deputationActions.setDeputationData(res.data.data));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Get Deputation Request API Error Found", error);
            }
        }
    },
    deleteDeputationRequest: (id, data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await deputationService.deleteDeputationDetails(id, data);
                if (res.status <= 202) {
                    await setCallBack(true);
                    dispatch(errorHandling(res));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Delete Deputation Request API Error Found", error);
            }
        }
    },
    addDeputation: (data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await deputationService.addDeputation(data);
                if (res.status <= 202) {
                    await setCallBack(true);
                    dispatch(errorHandling(res));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Add Deputation Request API Error Found", error);
            }
        }
    },
    editDeputationRequest: (id, data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await deputationService.editDeputation(id, data);
                if (res.status <= 202) {
                    await setCallBack(true);
                    dispatch(errorHandling(res));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Edit Deputation Request API Error Found", error);
            }
        }
    },
    getEditDeputationetailsRequest: (id) => {
        return async (dispatch) => {
            try {
                const res = await deputationService.getEditDeputationDetail(id);
                if (res.status <= 202) {
                    await dispatch(deputationActions.setDeputationPopup({ show: true, selectedRow: res.data.data, action: 'Edit' }));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Get Deputation Details Request API Error Found", error)
            }
        }
    }
}

export const wfhRequest = {
    ApproveRejectRequest: {
        employeeHistoryRequest: (params) => {
            return async (dispatch) => {
                try {
                    const res = await WFHService.ApproveRejectRequest.getEmployeeWFHHistory(params);
                    if (res.status <= 202) {
                        await dispatch(wfhActions.setWFHHistoryPopup({ data: res.data?.data }));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Edit Deputation Request API Error Found", error);
                }
            }
        },
        approvalRequest: (params, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await WFHService.ApproveRejectRequest.approvalRequest(params);
                    if (res.status <= 202) {
                        await setCallBack();
                    }
                    await dispatch(errorHandling(res));
                }
                catch (err) {
                    dispatch(errorHandling(err.response));
                    console.error("WFH Approve or Reject Request API Error Found");
                }
            }
        },
        getApproveOrRejectDetails: (id, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await WFHService.ApproveRejectRequest.approveOrRejectDetails(id);
                    if (res.status <= 202) {
                        await setCallBack(res.data.data);
                    } else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (err) {
                    dispatch(errorHandling(err.response));
                    console.error("Get Approve Reject Details API Error Found");
                }
            }
        }
    },
    addWFHRequest: (params, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await WFHService.addWFHRequest(params);
                if (res.status <= 202) {
                    await setCallBack(true);
                    await dispatch(errorHandling(res))
                }
                else {
                    await dispatch(errorHandling(res))
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Add WFH Request API Error Found", error)
            }
        }
    },
    getWFHRequestDetails: (params, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await WFHService.getWFHRequest(params);
                if (res.status <= 202) {
                    await setCallBack(res.data?.data);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Get WFH Request Details API Error Found");
            }
        }
    },
    getWFHBalanceRequest: (id) => {
        return async (dispatch) => {
            try {
                const res = await WFHService.getWFHBalance(id);
                if (res.status <= 202) {
                    const data = res?.data?.data.length > 0 ? res.data.data[0] : {};
                    await dispatch(wfhActions.setWFHLeaveBalance(data));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Get WFH Balance Request API Error Found");
            }
        }
    }
}


export const departmentRequest = {
    departmentScreenRequest: {
        addDepartmentRequest: (params, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await departmentService.departmentScreenService.addDepartmentService(params);
                    if (res.status <= 202) {
                        await setCallBack(true);
                    }
                    dispatch(errorHandling(res));
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Add Department Request API Error Found", error);
                }
            }
        },
        getEditDepartmentRequest: (id, data, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await departmentService.departmentScreenService.getEditDepartmentService(id, data);
                    if (res.status <= 202) {
                        await setCallBack(true);
                    }
                    dispatch(errorHandling(res));
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("  Edit Department Request API Error Found", error);
                }
            }
        },

        deleteDepartmentRequest: (params, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await departmentService.departmentScreenService.deleteDepartmentService(params);
                    if (res.status <= 202) {
                        await setCallBack(true);
                    }
                    dispatch(errorHandling(res));
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Delete Department Request API Error Found", error);
                }
            }
        },

        getFilterDepartmentRequest: (params) => {
            return async (dispatch) => {
                try {
                    const res = await departmentService.departmentScreenService.getFilterDepartmentService(params);
                    if (res.status <= 202) {
                        await dispatch(departmentActions.setDepartmentName(res?.data.data.map((val) => ({ ...val, value: val.id, label: val.departmentName }))));
                    } else {
                        dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Get Filter Department Request API Error Found", error);
                }
            }
        },
    },
    departmentSupervisor: {
        getDepartmentSupervisor: (params) => {
            return async (dispatch) => {
                try {
                    const res = await departmentService.departmentSupervisorService.getDepartmentSupervisorService(params);
                    if (res.status <= 202) {
                        await dispatch(departmentActions.setDepartmentSupervisor(res.data.data));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Get Department Supervisor Request API Error Found");
                }
            }
        },
        addDepartmentSupervisorRequest: (params, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await departmentService.departmentSupervisorService.addDepartmentSupervisorService(params);
                    if (res.status <= 202) {
                        await dispatch(errorHandling(res))
                        await setCallBack(true);
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Add Department Supervisor Request API Error Found");
                }
            }
        },
        editDepartmentSupervisorRequest: (id, params, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await departmentService.departmentSupervisorService.editDepartmentSupervisor(id, params);
                    if (res.status <= 202) {
                        await setCallBack(true);
                        await dispatch(errorHandling(res))
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Edit Department Supervisor Request API Error Found");
                }
            }
        },
        deleteDepartmentSupervisorRequest: (params, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await departmentService.departmentSupervisorService.deleteDepartmentSupervisor(params);
                    if (res.status <= 202) {
                        await setCallBack(true);
                        await dispatch(errorHandling(res))
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Delete Department Supervisor Request API Error Found");
                }
            }
        }
    }
}
export const timeInTimeOutRequest = {
    addTimeInTimeOutRequest: (params, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await timeInTimeOutService.addTimeInTimeOutRequest(params);
                if (res.status <= 202) {
                    await setCallBack();
                } else {
                    await dispatch(errorHandling(res));
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Add Time-in Or Time-Out Request API Error Found");
            }
        }
    },
    timeIntimeOutHistoryRequest: (params, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await timeInTimeOutService.timeIntimeOutHistory(params);
                if (res.status <= 202) {
                    await setCallBack(res.data.data);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Time In / Out Report History Requet API Error Found");
            }
        }
    },
    getTimeInTimeOutDetails: (params, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await timeInTimeOutService.getTimeInTimeOutDetails(params);
                if (res.status <= 202) {
                    await setCallBack(res.data.data);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("get Time In / Out Employee Details API Error Found");
            }
        }
    },
    updateTimeInTimeOutDetails: (params, setCallBack, isAddPopup) => {
        return async (dispatch) => {
            try {
                const res = await timeInTimeOutService.updateTimeInTimeOutDetails(params);
                if (res.status <= 202) {
                    await setCallBack();
                }
                if (!isAddPopup) await dispatch(errorHandling(res));
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("update Time In / Out Employee Details API Error Found");
            }
        }
    },
    getMissOutPunchDetails: (params, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await timeInTimeOutService.getMissOutPunchDetails(params);
                if (res.status <= 202) {
                    await setCallBack(res.data.data);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Get Missout Punch details Details API Error Found");
            }
        }
    },
    getTimeInTimeOutSummaryRequest: (params, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await timeInTimeOutService.getTimeInOutSummary(params);
                if (res.status <= 202) {
                    await setCallBack(res.data.data);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Get Time In / Out Summary Details API Error Found");
            }
        }
    },
    getTimeSheetRequest: (params, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await timeInTimeOutService.getTimeSheet(params);
                if (res.status <= 202) {
                    await setCallBack(res.data.data);
                }
                else {
                    await dispatch(errorHandling(res));
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Get Time sheet record API Error Found");
            }
        }
    },
    uploadTimeInOutRequest: (setCallBack, data) => {
        return async (dispatch) => {
            try {
                const res = await timeInTimeOutService.uploadTimeInOutDetails(data);
                if (res.status <= 202) {
                    setCallBack(true)
                    await dispatch(errorHandling(res));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Upload Time In / Out Request API Error Found");
            }
        }
    },
    getEmployeeCodeRequest: (params) => {
        return async (dispatch) => {
            try {
                const res = await timeInTimeOutService.getEmployeeCodeServices(params);
                if (res.status <= 202) {
                    await dispatch(timeInTimeOutActions.setTimeInOutUploadDocument({ employeeCodes: res.data.data }));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Upload Time In / Out Request API Error Found");
            }
        }
    }
}

export const designationRequest = {

    getDesignation: (params) => {
        return async (dispatch) => {
            try {
                const res = await designationService.getDesignationList(params);
                if (res.status <= 202) {
                    await dispatch(designationActions.setDesignationDetails(res.data?.data));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Get Designation Request details API Error Found", error);
            }
        }
    },

    addDesignationRequest: (params, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await designationService.addDesignation(params);
                if (res.status <= 202) {
                    setCallBack(res);
                    await dispatch(errorHandling(res));
                }
                else {
                    await dispatch(errorHandling(res))
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Add Designation Request Details API Error Found");
            }
        }
    },

    editDesignationRequest: (id, params, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await designationService.editDesignation(id, params);
                if (res.status <= 202) {
                    await dispatch(errorHandling(res));
                    setCallBack(res);
                }
                else {
                    await dispatch(errorHandling(res))
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Edit Designation Request API Error Found", error)
            }
        }
    },

    deleteDesignationRequest: (data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await designationService.deleteDesignation(data);
                if (res.status <= 202) {
                    setCallBack(res);
                    await dispatch(errorHandling(res));
                }
                else {
                    await dispatch(errorHandling(res))
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Delete Designation Request API Error Found", error);
            }
        }
    },
    getDesignationDetailsRequest: (id) => {
        return async (dispatch) => {
            try {
                const res = await designationService.getDesignationDetail(id);
                if (res.status <= 202) {
                    await dispatch(designationActions.setDesignationPopup({ show: true, selectedRow: res.data.data, isEditable: true }));
                }
                else {
                    await dispatch(errorHandling(res));
                }
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Delete Designation Request API Error Found", error);
            }
        }
    }
}


export const documentPolicyRequest = {
    complianceAgreement: {
        getDocument: (params) => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.complianceAgreement.getDocumentList(params);
                    if (res.status <= 202) {
                        await dispatch(ComplianceAgreementActions.setDocumentData(res.data?.data));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Get Document Request details API Error Found", error);
                }
            }
        },
        addDocument: (params, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.complianceAgreement.addDocument(params);
                    if (res.status <= 202 && setCallBack) {
                        await setCallBack(res);
                    }
                    else {
                        dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Add Document Request details API Error Found", error);
                }
            }
        },
        editGetDocumentData: (id) => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.complianceAgreement.editGetDocumentData(id);
                    if (res.status <= 202) {
                        await dispatch(ComplianceAgreementActions.setDocumentPopup({ show: true, selectedRow: res?.data.data, action: 'Edit' }))
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Add Document Request details API Error Found", error);
                }
            }
        },
        updateDocument: (id, params, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.complianceAgreement.editDocument(id, params);
                    if (res.status <= 202) {
                        if (setCallBack) { setCallBack(); }
                        await dispatch(errorHandling(res));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Update Document Request details API Error Found", error);
                }
            }
        },
        deleteDocument: (id, params, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.complianceAgreement.deleteDocument(id, params);
                    if (res.status <= 202) {
                        if (setCallBack) { setCallBack(); }
                        await dispatch(errorHandling(res));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Delete Document Request details API Error Found", error);
                }
            }
        },
        getViewDocument: (id) => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.complianceAgreement.editGetDocumentData(id);
                    if (res.status <= 202) {
                        dispatch(ComplianceAgreementActions.setPdfViewerPopup({ show: true, data: res?.data.data.documentImage, docxName: res?.data.data.documentTitle }));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Add Document Request details API Error Found", error);
                }
            }
        },
        policyAssignDocument: (params, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.complianceAgreement.policyAssignDocument(params);
                    if (res.status <= 202) {
                        if (setCallBack) { setCallBack(); }
                        await dispatch(errorHandling(res));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("policy Assign Document Request details API Error Found", error);
                }
            }
        },
        updatePolicyAssignDocument: (params, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.complianceAgreement.updatePolicyAssignDocument(params);
                    if (res.status <= 202) {
                        if (setCallBack) { setCallBack(); }
                        dispatch(errorHandling(res));
                    }
                    else {
                        dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Update  Assignment Document Request details API Error Found", error);
                }
            }
        },
        getPreloadDetailsRequest: () => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.complianceAgreement.getPreloadDetails();
                    if (res.status <= 202) {
                        await dispatch(ComplianceAgreementActions.setPreloadDetails(res.data.data));
                    }
                    else {
                        dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Get Preload Request details API Error Found", error);
                }
            }
        }
    },
    complianceDocumenyHistory: {
        getHistoryDocument: (params) => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.complianceHistory.getcomplianceHistoryDocument(params);
                    if (res.status <= 202) {
                        await dispatch(ComplianceAgreementActions.setcomplianceDocHistory(res.data?.data));
                    }
                    else {
                        dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Get History Document Request details API Error Found", error);
                }
            }
        },
        getViewDocument: (params) => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.complianceHistory.getcomplianceViewDocument(params);
                    if (res.status <= 202) {
                        dispatch(ComplianceAgreementActions.setPdfViewerPopup({ show: true, data: res?.data.data.documentImage, docxName: res?.data.data.documentName }));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Get View Document Request details API Error Found", error);
                }
            }
        },
        getPolicyViewDocument: (id) => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.complianceHistory.getDocumentData(id);
                    if (res.status <= 202) {
                        dispatch(ComplianceAgreementActions.setPdfViewerPopup({ show: true, data: res?.data.data.documentBinary, docxName: res?.data.data.documentName }));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Get Policy History Document Request details API Error Found", error);
                }
            }
        },
    },
    agreementDocument: {
        sendDocument: (params, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.complianceHistory.sendDocument(params);
                    if (res.status <= 202) {
                        if (setCallBack) { setCallBack(); }
                        await dispatch(errorHandling(res));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Send Document Request details API Error Found", error);
                }
            }
        },
        sendDocumentAndNotify: (params, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.complianceHistory.sendDocumentAndNotify(params);
                    if (res.status <= 202) {
                        if (setCallBack) { setCallBack(); }
                        await dispatch(errorHandling(res));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Send Document  and Notify Request details API Error Found", error);
                }
            }
        },
    },
    policyData: {
        getPolicyDataRequest: (isNotify, params, setcallback = null) => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.policyData.getPolicyData(isNotify, params);
                    if (res.status <= 202) {
                        setcallback();
                        await dispatch(errorHandling(res));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Pending Employees Notify API Error Found", error);
                }
            }
        },
        getNotificationRequest: (params) => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.policyData.getNotification(params);
                    if (res.status <= 202) {
                        await dispatch(ComplianceAgreementActions.setNotification(res.data.data));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Get Notification Request API Error Found", error);
                }
            }
        }
    },
    employeeAgreementPolicyRequest: {
        getEmployeeAgreementPolicyRequest: (params) => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.employeeAgreementPolicy.getEmployeeAgreementPolicy(params);
                    if (res.status <= 202) {
                        const data = res.data.data;
                        await dispatch(ComplianceAgreementActions.setEmployeeAgreementPolicy({ policyData: data, totalCount: data.length, currentPolicyData: data.length > 0 ? data[0] : {} }));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Get Employee Agreement Policy API Error Found", error);
                }
            }
        }
    },
    sendEmployeeAgreementPolicyRequest: (data, setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await documentPolicyService.employeeAgreementPolicy.sendEmployeeAgreementPolicy(data);
                await setCallBack(true);
                dispatch(errorHandling(res));
            }
            catch (error) {
                dispatch(errorHandling(error.response));
                console.error("Get Employee Agreement Policy API Error Found", error);
            }
        }
    },
    assignedDocumentHistory: {
        getAssignedDocumentHistoryRequest: (params) => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.assignedDocumentHistory.getFilterRecords(params);
                    if (res.status <= 202) {
                        await dispatch(ComplianceAgreementActions.setAssignedDocumentHistoryData(res.data.data));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Get Assigned Document History Filter API Error Found", error);
                }
            }
        },
        editAssignedDocumentRequest: (selectedRow) => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.assignedDocumentHistory.editAssignmentRecords(selectedRow.documentId);
                    if (res.status <= 202) {
                        await dispatch(ComplianceAgreementActions.setAgreementDocmentPopup({ show: true, selectedRow: { ...selectedRow, ...res?.data?.data }, action: 'edit' }));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Get Edit Assignment Document  API Error Found", error);
                }
            }
        },
        getPolicyType: () => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.assignedDocumentHistory.getPolicyType();
                    if (res.status <= 202) {
                        await dispatch(ComplianceAgreementActions.setAgreementPolicyType(res.data.data.map(val => ({ label: val, value: val }))));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Get Agreement Policy Type Filter API Error Found", error);
                }
            }
        },
        getPolicyEmployeeDataRequest: (params) => {
            return async (dispatch) => {
                try {
                    const res = await documentPolicyService.assignedDocumentHistory.getPolicyEmployeeDataService(params.documentId);
                    if (res.status <= 202) {
                        dispatch(ComplianceAgreementActions.setAssignedDocumentHistoryPopup({ show: true, selectedRow: params }));
                        const responseRecords = res?.data?.data;
                        dispatch(ComplianceAgreementActions.setEmployeeAcceptanceStatusData({ employeeDetails: Object.hasOwn(responseRecords, "employeeDetails") ? responseRecords.employeeDetails : [], totalCount: Object.hasOwn(responseRecords, "empCount") ? responseRecords.empCount : {} }))
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                }
                catch (error) {
                    dispatch(errorHandling(error.response));
                    console.error("Get Employee Policy  Data API Error Found", error);
                }
            }
        },
    }
}

export const addComplianceListReruest = {
    complianceRequest: {
        createComplianceRequest: (data, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await addComplianceListService.complianceRequestAction.addComplianceRequest(data);
                    if (res.status <= 202) {
                        await setCallBack(true);
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Create Compliance Request details API Error Found", error);
                }
            }
        },
        updateComplianceRequestRecords: (id, data, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await addComplianceListService.complianceRequestAction.updateComplianceRequest(id, data);
                    if (res.status <= 202) {
                        await setCallBack(true);
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Update  Compliance Request Records API Error Found", error);
                }
            }
        },
        getComplianceRecords: (id, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await addComplianceListService.complianceRequestAction.getComplianceRecord(id);
                    if (res.status <= 202) {
                        await setCallBack(true, res.data.data);
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Single Compliance Request Records  API Error Found", error);
                }
            }
        },
        getComplianceRequestRecords: (id, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await addComplianceListService.complianceRequestAction.getComplianceRequest(id);
                    if (res.status <= 202) {
                        await setCallBack(true, res.data.data);
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Compliance Request Records  API Error Found", error);
                }
            }
        },
        deleteComplianceRequestRecords: (id, data, setCallBack) => {
            return async (dispatch) => {
                try {
                    const res = await addComplianceListService.complianceRequestAction.deleteComplianceRequest(id, data);
                    if (res.status <= 202) {
                        await setCallBack(true);
                    }
                    await dispatch(errorHandling(res));
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Delete Compliance Request Record data API Error Found", error);
                }
            }
        },
    },
    approveAndRejectComplianceRequest: {
        getApproveAndRejectComplianceRequest: (params) => {
            return async (dispatch) => {
                try {
                    const res = await addComplianceListService.approverAndRejectService.getApproveAndRejectData(params);
                    if (res.status <= 202) {
                        await dispatch(AddComplianceRequestAction.setApproveAndRejectData(res.data.data));
                    }
                    else {
                        await dispatch(errorHandling(res));
                    }
                } catch (error) {
                    await dispatch(errorHandling(error.response));
                    console.error("Get Approve And Reject Compliance Request API Error Found", error);
                }
            }
        },
    }
}