import AgGrid from '../Grid/AgGrid';
import { useSelector } from 'react-redux';
import { employeeDetails } from '../Grid/Columns';

function Qualification() {
    const employeeQualificationDetailState = useSelector(state => state.employee.employeeDetailView.data.qualification);
    return (
        <div>
            <AgGrid columns={employeeDetails.qualificationColumns()} data={employeeQualificationDetailState || []} height="h-[13rem]" />
        </div>
    )
}

export default Qualification
