import PropTypes from 'prop-types';
import { useSelector } from 'react-redux'
import { classNames } from '../Constants';
import { dateFormat } from '../helper';

function Work({ isPrintView }) {
    let employeeWorkDetailState = useSelector(state => state.employee.employeeDetailView.data.workDetail);
    employeeWorkDetailState = employeeWorkDetailState && typeof (employeeWorkDetailState) === "object" && employeeWorkDetailState.length > 0 ? employeeWorkDetailState[0] : {};
    const labelClass = isPrintView ? "col-start-1 col-end-6" : classNames.grid.gridSplitFirst_4Cols;
    const valueClass = isPrintView ? "col-start-7 col-end-13" : classNames.grid.gridSplitLast_7Cols;
    return (
        <div>
            <div className={isPrintView ? "font-fontfamily font-bold text-14px grid grid-cols-1" : classNames.grid.gridCols2_And_text}>
                <div className={classNames.grid.gridCols12}>
                    <span className={labelClass}> Designation</span> <span className={valueClass}>: <span className='mx-2'>{employeeWorkDetailState?.designationName}</span></span>
                    <span className={labelClass}> Date Of Join</span> <span className={valueClass}>: <span className='mx-2'>{employeeWorkDetailState && !isNaN(new Date(employeeWorkDetailState.doj)) && dateFormat(employeeWorkDetailState.doj)}</span></span>
                    <span className={labelClass}> Work Location</span> <span className={valueClass}>: <span className='mx-2'>{employeeWorkDetailState?.locationCountry}</span></span>
                    <span className={labelClass}> Confirmation Date</span> <span className={valueClass}>: <span className='mx-2'>{employeeWorkDetailState && !isNaN(new Date(employeeWorkDetailState.confirmationDate)) && dateFormat(employeeWorkDetailState.confirmationDate)}</span></span>
                </div>
                <div className='grid grid-cols-12'>
                    <span className={labelClass}> Section</span> <span className={valueClass}>: <span className='mx-2'>{employeeWorkDetailState?.departmentName}</span></span>
                    <span className={labelClass}> Employee Type</span> <span className={valueClass}>: <span className='mx-2'>{employeeWorkDetailState?.employeeType}</span></span>
                    <span className={labelClass}> Employment Status</span> <span className={valueClass}>: <span className='mx-2'>{employeeWorkDetailState?.employmentStatus}</span></span>
                    <span className={labelClass}> Relieving Date</span> <span className={valueClass}>: <span className='mx-2'>{employeeWorkDetailState && !isNaN(new Date(employeeWorkDetailState.relievingDate)) && dateFormat(employeeWorkDetailState.relievingDate)}</span></span>
                </div>
            </div>
        </div>
    )
}

export default Work

Work.propTypes = {
    isPrintView: PropTypes.bool
}