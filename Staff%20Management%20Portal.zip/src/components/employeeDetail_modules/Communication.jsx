import PropTypes from 'prop-types';
import { useSelector } from 'react-redux';
import { classNames } from '../Constants';

function Communication({ isPrintView }) {
    const employeeCommunicationDetailState = useSelector(state => state.employee.employeeDetailView.data.communicationDetail);
    const labelClass = isPrintView ? "col-start-1 col-end-6" : classNames.grid.gridSplitFirst_4Cols;
    const valueClass = isPrintView ? "col-start-7 col-end-13" : classNames.grid.gridSplitLast_7Cols;
    return (
        <div>
            <div className={isPrintView ? "font-fontfamily font-bold text-14px grid grid-cols-1" : classNames.grid.gridCols2_And_text}>
                <div className={classNames.grid.gridCols12}>
                    <span className={labelClass}> Email ID</span> <span className={valueClass}>: <span className='mx-2'>{employeeCommunicationDetailState.emailID}</span></span>
                    <span className={labelClass}> Mobile No</span> <span className={valueClass}>: <span className='mx-2'>{employeeCommunicationDetailState.mobileNo}</span></span>
                    <span className={labelClass}> Land Line No</span> <span className={valueClass}>: <span className='mx-2'>{employeeCommunicationDetailState.phoneno}</span></span>
                    <span className={labelClass}> Address</span> <span className={valueClass}>: <span className='mx-2'>{employeeCommunicationDetailState.address1}</span></span>
                </div>
                <div className='grid grid-cols-12'>
                    <span className={labelClass}> Emergency Contact Name</span> <span className={valueClass}>: <span className='mx-2'>{employeeCommunicationDetailState.emergencyContactName}</span></span>
                    <span className={labelClass}> Relation</span> <span className={valueClass}>: <span className='mx-2'>{employeeCommunicationDetailState.emergencyContactRelation}</span></span>
                    <span className={labelClass}> Emergency Phone No</span> <span className={valueClass}>: <span className='mx-2'>{employeeCommunicationDetailState.emergencyContactNumber}</span></span>
                    <span className={labelClass}> Emergency Address</span> <span className={valueClass}>: <span className='mx-2'>{employeeCommunicationDetailState.emergencyAddress}</span></span>
                </div>
            </div>
        </div>
    )
}

export default Communication

Communication.propTypes = {
    isPrintView: PropTypes.bool
}