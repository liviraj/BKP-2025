import PropTypes from 'prop-types';
import { useSelector } from 'react-redux'
import { classNames } from '../Constants';
import LinkView from '../elements/LinkView';
import { dateFormat } from '../helper';

function Personal({ isPrintView }) {
    const employeePersonalDetailState = useSelector(state => state.employee.employeeDetailView.data.personalDetail);
    const labelClass = isPrintView ? "col-start-1 col-end-6" : classNames.grid.gridSplitFirst_4Cols;
    const valueClass = isPrintView ? "col-start-7 col-end-13" : classNames.grid.gridSplitLast_7Cols;
    return (
        <div>
            <div className={isPrintView ? "font-fontfamily font-bold text-14px grid grid-cols-1" : classNames.grid.gridCols2_And_text}>
                <div className={classNames.grid.gridCols12}>
                    <span className={labelClass}> Employee Code</span> <span className={valueClass}>: <span className='mx-2'>{employeePersonalDetailState.employeeCode}</span></span>
                    <span className={labelClass}> Date Of Birth</span> <span className={valueClass}>: <span className='mx-2'>{dateFormat(employeePersonalDetailState.dob)}</span></span>  {/* format("DD-MMMM-YYYY") */}
                    <span className={labelClass}>ID Proof Image</span> <span className={valueClass}>: <span className='mx-2'><LinkView value={"View"} imageId={employeePersonalDetailState.employeeId} type="Id Proof" /></span></span>
                    <span className={labelClass}> Gender</span> <span className={valueClass}>: <span className='mx-2'>{employeePersonalDetailState.gender}</span></span>
                </div>
                <div className={classNames.grid.gridCols12}>
                    <span className={labelClass}> Employee Name</span> <span className={valueClass}>: <span className='mx-2'>{employeePersonalDetailState.employeeName}</span></span>
                    <span className={labelClass}> Marital Status</span> <span className={valueClass}>: <span className='mx-2'>{employeePersonalDetailState.maritalstatus}</span></span>
                    <span className={labelClass}> Passport Number</span> <span className={valueClass}>: <span className='mx-2'>{employeePersonalDetailState.passportNo}</span></span>
                    <span className={labelClass}> Passport Image</span> <span className={valueClass}>: <span className='mx-2'><LinkView value={"View"} imageId={employeePersonalDetailState.employeeId} type="Passport Image" /></span></span>
                </div>
            </div>
        </div>
    )
}

export default Personal

Personal.propTypes = {
    isPrintView: PropTypes.bool
}