import AgGrid from '../Grid/AgGrid';
import { useDispatch, useSelector } from 'react-redux';
import { employeeDetails } from '../Grid/Columns';
import { employeeRequests } from '../requests';

function WorkHistory() {
    const dispatch = useDispatch();
    const employeeWorkHistoryState = useSelector(state => state.employee.employeeDetailView.data.workHistory);
    const setLoaderValue = (isload) => {
        dispatch(employeeRequests.loader(isload))
    }
    return (
        <div>
            <AgGrid columns={employeeDetails.workHistory_columns(setLoaderValue, false)} data={employeeWorkHistoryState || []} height="h-[13rem]" />
        </div>
    )
}

export default WorkHistory