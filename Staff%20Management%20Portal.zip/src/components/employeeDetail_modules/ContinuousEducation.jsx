import AgGrid from '../Grid/AgGrid';
import { useSelector } from 'react-redux';
import { employeeDetails } from '../Grid/Columns';

function ContinuousEducation() {
    const employeeContinuousEducationDetailState = useSelector(state => state.employee.employeeDetailView.data.continuousEducation);
    return (
        <div>
            <AgGrid columns={employeeDetails.continuousEducationDetailViewColumns()} data={employeeContinuousEducationDetailState || []} height="h-[13rem]" />
        </div>
    )
}

export default ContinuousEducation