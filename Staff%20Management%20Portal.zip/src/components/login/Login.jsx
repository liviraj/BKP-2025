import SignInBtn from './SignInBtn';
import loginImage from '../../assets/login-image.png';
import LoginHeader from '../layouts/Header';

function Login() {
    return (
        <div className='h-full'>
            <LoginHeader />
            <div className='flex justify-center flex-col h-3/4 min-h-75vh'>
                <img src={loginImage} alt='#' className='mx-auto' />
                <SignInBtn />
            </div>
        </div>
    );
}

export default Login;

