import { useDispatch } from 'react-redux';
import { userActions } from '../../redux/userReducer';
import { FaPowerOff } from 'react-icons/fa';
import { removeSessionStorage } from '../helper';

function LogoutBtn() {
    const dispatch = useDispatch();

    const onLogout = async () => {
        await removeSessionStorage();
        await dispatch(userActions.updateLoader(true));
    }

    return (
        <span className='cursor-pointer xsm:items-start md:items-center bg-headerColor border-2 border-solid border-white m-1 p-1 rounded-md flex' onClick={() => onLogout()}><FaPowerOff className="md:text-lg xsm:text-base text-white ml-1" /> <span className=' tracking-wide md:text-base xsm:text-12px text-white font-QuattrocentoSans px-1 font-bold'>LOGOUT</span></span>
    )
}

export default LogoutBtn