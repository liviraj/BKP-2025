import { useDispatch } from 'react-redux';
import { userActions } from '../../redux/userReducer';

function SignInBtn() {
    const dispatch = useDispatch();
    const handleLogin = () => {
        dispatch(userActions.resetUserDetails());
    }
    return (
        <div className='flex justify-center mt-2'>
            <button className='flex border-solid border-headerColor m-1 rounded-md cursor-pointer md:border-2 xsm:border-2' onClick={() => handleLogin()}>
                <div className='flex justify-center text-center align-middle items-center m-2 md:m-1.5 xsm:m-1'>
                    <object type="image/svg+xml"
                        data="https://s3-eu-west-1.amazonaws.com/cdn-testing.web.bas.ac.uk/scratch/bas-style-kit/ms-pictogram/ms-pictogram.svg"
                        className="mr-1 h-7 xsm:h-5"
                        aria-label="login"
                    />
                    <span className='flex tracking-wide text-shadow-sm text-medium text-homeTextColor font-fontfamily md:text-lg xsm:text-base'>Sign in with Microsoft</span>
                </div>
            </button>
        </div>
    );
}

export default SignInBtn;
