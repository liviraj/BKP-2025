import LoginHeader from '../components/layouts/Header';
import LogoutBtn from '../components/login/LogoutBtn';

function UnAuthorizedRoute() {
    return (
        <div>
            <LoginHeader />
            <div className="h-75vh flex justify-center items-center flex-col">
                <h2 className='flex text-darkGrey flex-col relative md:text-2rem font-QuattrocentoSans font-semibold text-center xsm:text-18px'> SORRY, YOUR REQUEST IS UNAUTHORIZED</h2>
                <div className=' text-lightGrey font-bold font-QuattrocentoSans md:text-2xl xsm:text-16px text-center'>PLEASE CLICK THE &quot;LOGOUT&quot; BUTTON BELOW TO TRY AGAIN.</div>
                <div className="error-actions bgColor">
                    <LogoutBtn />
                </div>
            </div>
        </div>
    )
}

export default UnAuthorizedRoute;