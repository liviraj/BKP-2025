/* eslint-disable react-refresh/only-export-components */
import { Route, Switch, withRouter } from "react-router-dom";
import UnAuthorizedRoute from './UnAuthorizedRoute';
import LoginView from '../components/RequestRoutes/LoginView';
import Staff from '../components/RequestRoutes/Staff';
import LoginUserForm from '../components/RequestRoutes/LoginUserForm';
import Personal from '../components/RequestRoutes/employeeDetail_modules/Personal';
import Communication from '../components/RequestRoutes/employeeDetail_modules/Communication';
import WorkHistory from '../components/RequestRoutes/employeeDetail_modules/WorkHistory';
import Work from '../components/RequestRoutes/employeeDetail_modules/Work';
import Qualification from '../components/RequestRoutes/employeeDetail_modules/Qualification';
import ContinuousEducation from '../components/RequestRoutes/employeeDetail_modules/ContinuousEducation';
import NysCompliance from '../components/RequestRoutes/employeeDetail_modules/NysCompliance';
import Training from '../components/RequestRoutes/employeeDetail_modules/Training';
import HRDocuments from '../components/RequestRoutes/employeeDetail_modules/HrDocuments';
import Compliance from '../components/RequestRoutes/Reports/Compliance';
import { userReducerState } from '../components/helper';
import { routerPath, setDefaultValue, strings } from '../components/Constants';
import LeaveRequest from '../components/RequestRoutes/LeaveManagement/LeaveRequest';
import LeaveRequestQueue from '../components/RequestRoutes/LeaveManagement/LeaveRequestQueue';
import LeaveHistory from '../components/RequestRoutes/LeaveManagement/LeaveHistory';
import ViewEditLeaveLedger from '../components/RequestRoutes/LeaveManagement/ViewEditLeaveLedger';
import LeaveBalanceSummary from '../components/RequestRoutes/LeaveManagement/LeaveBalanceSummary';
import LeaveSummaryDetails from '../components/RequestRoutes/LeaveManagement/LeaveSummaryDetails';
import ViewLeaveLedger from '../components/RequestRoutes/LeaveManagement/ViewLeaveLedger';
import RecordEvents from '../components/RequestRoutes/EventManagement/RecordEvents';
import ViewEvents from '../components/RequestRoutes/EventManagement/ViewEvents';
import FacilityPersonalReport from '../components/RequestRoutes/EventManagement/FacilityPersonalReport';
import MyRequests from '../components/RequestRoutes/MyRequests/MyRequests'
import ApproveRejectMyRequests from '../components/RequestRoutes/MyRequests/ApproveRejectMyRequests';
import IndiaLeaveReports from '../components/RequestRoutes/Reports/IndiaLeaveReports';
import TrackingRequest from '../components/RequestRoutes/MyRequests/TrackingRequest';
import GenerateReport from '../components/RequestRoutes/EventManagement/ContinuousEducationReport/GenerateReport';
import GenerateSummary from '../components/RequestRoutes/EventManagement/ContinuousEducationReport/GenerateSummary';
import GenerateDetails from '../components/RequestRoutes/EventManagement/ContinuousEducationReport/GenerateDetails';
import ApproveRejectPermissionRequest from "../components/RequestRoutes/Permission/ApproveRejectPermissionRequest";
import PermissionRequest from "../components/RequestRoutes/Permission/PermissionRequest";
import PermissionHistory from "../components/RequestRoutes/Permission/PermissionHistory";
import HolidayListOrganization from "../components/RequestRoutes/Holiday/HolidayListOrganization";
import ViewFloatingHolidayList from '../components/RequestRoutes/Holiday/ViewFloatingHolidayList'
import AddFloatingHoliday from "../components/RequestRoutes/Holiday/AddFloatingHoliday";
import AddHolidays from "../components/RequestRoutes/Holiday/AddHolidays";
import HolidayNames from "../components/RequestRoutes/Holiday/HolidayNames";
import EmployeePayrollDetails from "../components/RequestRoutes/AttendancePayrollDetails/EmployeePayrollDetails";
import UploadAuditorDocument from "../components/RequestRoutes/AttendancePayrollDetails/UploadAuditorDocument";
import EmployeeDashboard from "../components/RequestRoutes/Dashboard/EmployeeDashboard";
import Department from "../components/RequestRoutes/Department/Department";
import SuperVisor from "../components/RequestRoutes/Department/Supervisor";
import DesignationList from "../components/RequestRoutes/Designation/DesignationList";
import Deputation from "../components/RequestRoutes/Deputation/Deputation";
import WFHRequest from "../components/RequestRoutes/WFH_Request/WFHRequest";
import ApproveRejectWFH from "../components/RequestRoutes/WFH_Request/ApproveRejectWFH";
import DashboardEmployeeRequest from "../components/RequestRoutes/Dashboard/DashboardEmployeeRequest";
import WFHHistory from "../components/RequestRoutes/WFH_Request/WFHHistory";
import AddTimeInAndTimeOut from "../components/RequestRoutes/TimeInAndTimeOut/AddTimeInAndTimeOut";
import TimeInAndTimeOutHistory from "../components/RequestRoutes/TimeInAndTimeOut/TimeInAndTimeOutHistory";
import TimeINAndOutEmployeeHistory from "../components/RequestRoutes/TimeInAndTimeOut/TimeINAndOutEmployeeHistory";
import TimeInTimeOutSummary from "../components/RequestRoutes/TimeInAndTimeOut/TimeInTimeOutSummary";
import CreateAndEditPolicy from "../components/RequestRoutes/AgreementPolicy/CreateAndEditPolicy";
import PolicyHistory from "../components/RequestRoutes/AgreementPolicy/PolicyHistory";
import TimeSheetRecord from "../components/RequestRoutes/TimeInAndTimeOut/TimeSheetRecord";
import AssignedDocumentHistory from "../components/RequestRoutes/AgreementPolicy/AssignedDocumentHistory";
import MyTeamComplianceDocument from "../components/RequestRoutes/Dashboard/AddComplianceList/MyTeamComplianceDocument";
import MyComplianceDocument from "../components/RequestRoutes/Dashboard/AddComplianceList/MyComplianceDocument";

const AllRoutes = () => {

    const isAdmin = (userReducerState().Role === strings.userRoles.admin || userReducerState().Role === strings.userRoles.humanResource);
    const isAuthorizedUser = (userReducerState().Role === strings.userRoles.admin || userReducerState().Role === strings.userRoles.humanResource || userReducerState().Role === strings.userRoles.superVisor);
    const isIndiaAdmin = (userReducerState().Role === strings.userRoles.admin || userReducerState().Role === strings.userRoles.humanResource) && userReducerState().LocationID === setDefaultValue.location.value;
    const isUSAdmin = (userReducerState().Role === strings.userRoles.admin || userReducerState().Role === strings.userRoles.humanResource) && userReducerState().LocationID === setDefaultValue.usLocation.value;

    return (
        <Switch>
            <Route exact path={routerPath.unAuthorized} component={() => <UnAuthorizedRoute />} />
            <Route exact path={routerPath.loginView} component={() => isAdmin ? <LoginView /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.staff} component={() => isAdmin ? <Staff /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.loginUserForm} component={() => isAdmin ? <LoginUserForm /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.employeePersonal} component={() => isAdmin ? <Personal /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.employeeCommunication} component={() => isAdmin ? <Communication /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.employeeWork} component={() => isAdmin ? <Work /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.employeeQualification} component={() => isAdmin ? <Qualification /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.employeeWorkHistory} component={() => isAdmin ? <WorkHistory /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.employeeContinuousEducation} component={() => isAdmin ? <ContinuousEducation /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.employeeHrDocuments} component={() => isAdmin ? <HRDocuments /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.employeeNysCompliance} component={() => isAdmin ? <NysCompliance /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.employeeTraining} component={() => isAdmin ? <Training /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.reportCompliance} component={() => <Compliance />} />
            <Route exact path={routerPath.indiaLeaveReports} component={() => isIndiaAdmin ? <IndiaLeaveReports /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.leaveRequest} component={() => <LeaveRequest />} />
            <Route exact path={routerPath.leaveHistory} component={() => <LeaveHistory />} />
            <Route exact path={routerPath.leaveRequestQueue} component={() => isAuthorizedUser ? <LeaveRequestQueue /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.leaveLedger} component={() => isAdmin ? <ViewEditLeaveLedger /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.leaveBalanceSummary} component={() => isAdmin ? <LeaveBalanceSummary /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.leaveSummaryDetails} component={() => isAdmin ? <LeaveSummaryDetails /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.viewLeaveLedger} component={() => <ViewLeaveLedger />} />
            <Route exact path={routerPath.recordEvents} component={() => <RecordEvents />} />
            <Route exact path={routerPath.viewEvents} component={() => <ViewEvents />} />
            <Route exact path={routerPath.facilityPersonalReport} component={() => <FacilityPersonalReport />} />
            <Route exact path={routerPath.myRequest} component={() => <MyRequests />} />
            <Route exact path={routerPath.approveRejectRequest} component={() => isAdmin ? <ApproveRejectMyRequests /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.trackingRequest} component={() => isAdmin ? <TrackingRequest /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.generateReport} component={() => <GenerateReport />} />
            <Route exact path={routerPath.generateSummary} component={() => <GenerateSummary />} />
            <Route exact path={routerPath.generateDetails} component={() => <GenerateDetails />} />
            <Route exact path={routerPath.permissionRequest} component={() => <PermissionRequest />} />
            <Route exact path={routerPath.permissionHistory} component={() => <PermissionHistory />} />
            <Route exact path={routerPath.permissionApproveRejectRequest} component={() => isAuthorizedUser ? <ApproveRejectPermissionRequest /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.holidayList} component={() => <HolidayListOrganization />} />
            <Route exact path={routerPath.floatingHolidayList} component={() => isAdmin ? <ViewFloatingHolidayList /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.addFloatingHolidays} component={() => isAdmin ? <AddFloatingHoliday /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.addHolidays} component={() => isAdmin ? <AddHolidays /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.holidayNameList} component={() => isAdmin ? <HolidayNames /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.employeePayrollDetails} component={() => isAdmin ? <EmployeePayrollDetails /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.uploadAuditDocument} component={() => isAdmin ? <UploadAuditorDocument /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.employeeDashboard} component={() => <EmployeeDashboard />} />
            <Route exact path={routerPath.employeeDashboardRequest} component={() => isIndiaAdmin ? <DashboardEmployeeRequest /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.department} component={() => isAdmin ? <Department /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.departmentSupervisor} component={() => isAdmin ? <SuperVisor /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.designationList} component={() => isAdmin ? <DesignationList /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.deputation} component={() => isAdmin ? <Deputation /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.wfhRequest} component={() => <WFHRequest />} />
            <Route exact path={routerPath.wfhApproveRejectRequest} component={() => isAuthorizedUser ? <ApproveRejectWFH /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.wfhHistory} component={() => <WFHHistory />} />
            <Route exact path={routerPath.addTimeInAndTimeOut} component={() => <AddTimeInAndTimeOut />} />
            <Route exact path={routerPath.timeInTimeOutHistory} component={() => <TimeInAndTimeOutHistory />} />
            <Route exact path={routerPath.timeInTimeOutEmployeeRecords} component={() => isUSAdmin ? <TimeINAndOutEmployeeHistory /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.timeInTimeOutSummary} component={() => isUSAdmin ? <TimeInTimeOutSummary /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.timeInTimeOutTimeSheet} component={() => isUSAdmin ? <TimeSheetRecord /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.createPolicyDocument} component={() => isAdmin ? <CreateAndEditPolicy /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.employeeViewPolicy} component={() => <PolicyHistory />} />
            <Route exact path={routerPath.assignedDocumentHistory} component={() => isAdmin ? <AssignedDocumentHistory /> : <UnAuthorizedRoute />} />
            <Route exact path={routerPath.complianceRequest} component={() => <MyComplianceDocument />} />
            <Route exact path={routerPath.myTeamComplianceDocuments} component={() => isAuthorizedUser ? <MyTeamComplianceDocument /> : <UnAuthorizedRoute />} />
        </Switch>
    );
};

export default withRouter(AllRoutes);