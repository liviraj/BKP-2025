import PropTypes from 'prop-types';
import React from 'react';
import { Route } from 'react-router-dom';

const ProtectedRoutes = React.memo(({ Component }) => {
  return (<Route render={(props) => <Component {...props} />} />);
});

ProtectedRoutes.displayName = "ProtectedRoutes";

export default ProtectedRoutes;

ProtectedRoutes.propTypes = {
  Component: PropTypes.any
}

