package com.histo.fileuploader.process.interfaces;

public interface FileTransfer {
	public void transferFile();
	public void transferFolder();
}
