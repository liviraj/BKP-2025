package com.histo.fileuploader.process.interfaces;

import javax.net.ssl.HttpsURLConnection;

public interface Authenticator {
	/**
	 * @param connection The connection that needs to be authenticated
	 */
	public void authenticateConnection(HttpsURLConnection connection);
}
