package com.histo.fileuploader.process;

import com.histo.fileuploader.process.interfaces.FileTransfer;
import com.histo.fileuploader.process.interfaces.impl.GlobusFileTranfer;
import com.histo.fileuploader.process.interfaces.impl.SFTPFileTransfer;
import com.histo.fileuploader.util.Params;
import com.histo.fileuploader.util.UploadType;

/*
 * FileUploaderMainProcess -- Will upload file to Globus or SFTP or FTP
 */
public class FileUploaderMainFactory {
	
	 public FileTransfer CreateFileTransfer(Params params) {
		 if(params.uploadType == UploadType.GLOBUS) {
			 return new GlobusFileTranfer(params);
		 }
		 else if (params.uploadType == UploadType.SFTP) {
			 return new SFTPFileTransfer(params);
		 }
		 return null;
	 }
}
