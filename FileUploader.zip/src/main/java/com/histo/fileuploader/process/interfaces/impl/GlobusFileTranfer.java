package com.histo.fileuploader.process.interfaces.impl;


import com.histo.fileupload.globus.connection.GlobusDataTransfer;
import com.histo.fileupload.globus.connection.JSONTransferAPIClient;
import com.histo.fileuploader.globus.GoauthAuthenticator;
import com.histo.fileuploader.process.interfaces.Authenticator;
import com.histo.fileuploader.process.interfaces.FileTransfer;
import com.histo.fileuploader.util.Params;
import org.json.JSONException;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

public class GlobusFileTranfer implements FileTransfer {
	private String oauthToken = null;
	private JSONTransferAPIClient client;
	private Params params;
	
	public GlobusFileTranfer(Params params) {
		this.params = params;
		//this.oauthToken = getToken();

		java.lang.System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
		oauthToken = params.oAuth;
		Authenticator authenticator = new GoauthAuthenticator(oauthToken);
		try {
			
			client = new JSONTransferAPIClient(params.username,
			                                                null, null);
		} catch (KeyManagementException | NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		client.setAuthenticator(authenticator);
	}
	
	public void transferFile() {
		GlobusDataTransfer globusTransfer = new GlobusDataTransfer(client, params, false);
		try {
			globusTransfer.run();
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	public void transferFolder() {
		GlobusDataTransfer globusTransfer = new GlobusDataTransfer(client, params, true);
		try {
			globusTransfer.run();
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
	public String getOauthToken() {
		return oauthToken;
	}
	public void setOauthToken(String oauthToken) {
		this.oauthToken = oauthToken;
	}


}
