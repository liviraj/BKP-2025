package com.histo.fileuploader.process;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.histo.fileuploader.connection.ApplicationPropertiesParams;
import com.histo.fileuploader.process.interfaces.FileTransfer;
import com.histo.fileuploader.util.Params;
import com.histo.fileuploader.util.UploadType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.LoggerContext;

import java.lang.reflect.Field;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public class FileUploaderMainProcess {
	/*
	 * Usage : java FileUploaderMainProcess.jar <Upload Type> <Username> <password> <IsFolder>
	 * Upload Type: Globus or SFTP or FTP
	 * Username : User name for the account
	 * Password: Password
	 * IsFolder : True or False
	 */
	static final Logger LOGGER = LogManager.getLogger(FileUploaderMainProcess.class.getName());
	 public static void main(String[] args) {

	        if (args.length < 1) {
	            LOGGER.error("java FileUploaderMainProcess.jar <Upload Type> <Username> <password> <IsFolder> oAuth");
	            System.exit(1);
	        }
		 	LOGGER.info("File Uploader Arguments: {}", Arrays.toString(args));
	        System.setProperty("log_file", System.getProperty("user.home"));
			LoggerContext ctx =(LoggerContext) LogManager.getContext(false);
			ctx.reconfigure();
			 final Logger logger = LogManager.getLogger(FileUploaderMainProcess.class);
	        //If Upload type Globus
			try {
				Params params = new Params();
                String argsString = Arrays.toString(args);
                // argsString = argsString.replaceAll("[\\{\\}\\[\\]]", "");
				argsString = argsString.replaceFirst("^[\\[\\]]", "");
				argsString = argsString.replaceFirst("[\\[\\]]$", "");
				argsString = argsString.replaceFirst("^[\\{\\}]", "");
				argsString = argsString.replaceFirst("[\\{\\}]$", "");
                args = argsString.split(",");
                LOGGER.info("args all: {}", Arrays.toString(args));
                setValuesFromArgsArray(params, args);

				LOGGER.info("Params Mapped Value: {}", params);
				String strReplace = params.getSourceParentPath().replace("HistoNAS2\\", "HistoNAS2.histogenetics.com\\");
				if(!strReplace.isEmpty()) {
					params.setSourceParentPath(strReplace);
				}

				if (params.uploadType == UploadType.GLOBUS) {
					params.setoAuth(URLDecoder.decode(params.getoAuth()));
					params.setoAuth(params.getoAuth().replace("\\u003d", "="));
					params.setoAuth(params.getoAuth().replace(" ",""));
				}
				params.setSourceParentPath(URLDecoder.decode(params.getSourceParentPath()));
				params.setDestinationParentPath(URLDecoder.decode(params.getDestinationParentPath()));
				params.setRunName(URLDecoder.decode(params.getRunName()));
				FileUploaderMainFactory fileUploaderMainFactory = new FileUploaderMainFactory();
		        FileTransfer fileTransfer =  fileUploaderMainFactory.CreateFileTransfer(params);
		        if(params.isFolder) {
		        	fileTransfer.transferFolder();
		        } else {
		        	fileTransfer.transferFile();
		        }
			}catch(Exception e) {
				logger.error("Error :{}" +e);
			}
	 }

    public static void setValuesFromArgsArray(Object obj, String[] args) {
        Class<?> clazz = obj.getClass();
        for (String arg : args) {
            String[] keyValue = arg.split(":", 2);
            if (keyValue.length == 2) {
                String key = keyValue[0].trim().replace("\"","");
                String value = keyValue[1].trim().replace("\"","");
                try {
                    Field field = clazz.getDeclaredField(key);
                    field.setAccessible(true);
                    setFieldValue(field, obj, value, key);
                } catch (NoSuchFieldException | IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private static void setFieldValue(Field field, Object obj, String value, String key) throws IllegalAccessException {
        if (field.getType().equals(Integer.class) || key.equals("gridIonStatusViewerId")) {
            field.set(obj, Integer.valueOf(value) );
        } else if (field.getType().equals(String.class)) {
            field.set(obj, value);
        } else if (field.getType().equals(Boolean.class) || key.equals("isFolder")) {
            field.set(obj, Boolean.valueOf(value));
        } else if (field.getType().equals(Double.class)) {
            field.set(obj, Double.valueOf(value));
        } else if (key.equals("uploadType")) {
			field.set(obj, getEnumFromString(UploadType.class, value));
		}
    }

	private static <T extends Enum<T>> T getEnumFromString(Class<T> enumClass, String value) {
		if (enumClass == null || value == null) {
			throw new IllegalArgumentException("Enum class and value must not be null");
		}

		try {
			return Enum.valueOf(enumClass, value.toUpperCase());
		} catch (IllegalArgumentException e) {
			// Handle the exception as needed (e.g., return a default value or rethrow)
			throw new IllegalArgumentException("No enum constant " + enumClass.getCanonicalName() + "." + value);
		}
	}
}
