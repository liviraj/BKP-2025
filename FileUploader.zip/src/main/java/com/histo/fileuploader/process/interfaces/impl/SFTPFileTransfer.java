package com.histo.fileuploader.process.interfaces.impl;

import com.histo.fileupload.sftp.connection.SFTPDataTransfer;
import com.histo.fileuploader.process.interfaces.FileTransfer;
import com.histo.fileuploader.util.Params;

public class SFTPFileTransfer implements FileTransfer {
	private Params params;
	public SFTPFileTransfer(Params params) {
		this.params = params;
	}

	public String getToken() {
		// TODO Auto-generated method stub
		return null;
	}

	public void transferFile() {
		// TODO Auto-generated method stub
		
	}

	public void transferFolder() {
		SFTPDataTransfer sftpDataTransfer = new SFTPDataTransfer(params);
		try {
			sftpDataTransfer.run();
		}
		catch (Exception e) {
			
		}
		
	}

}
