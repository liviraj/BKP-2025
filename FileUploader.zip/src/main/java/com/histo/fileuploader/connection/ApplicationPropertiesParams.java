package com.histo.fileuploader.connection;

import java.io.InputStream;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ApplicationPropertiesParams {
	private static final Logger logger = LogManager.getLogger(ApplicationPropertiesParams.class);
	public static  String getProperties(String propertyKey) {	
		String propertyValue = null;
	try {
		Properties prop = new Properties();
    	InputStream inputStream = ApplicationPropertiesParams.class.getClassLoader().getResourceAsStream("application.properties");
    	prop.load(inputStream);
        propertyValue=prop.getProperty(propertyKey);
    	
	}catch(Exception e) {
		logger.error("Error : {}"+e);
	}
	return propertyValue;
	}
}
