package com.histo.fileuploader.connection;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.security.cert.X509Certificate;

import com.histo.fileuploader.model.GridIonClientTransferStatus;
import com.histo.fileuploader.model.GridIonLogModel;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.google.gson.Gson;
import com.histo.fileuploader.model.WGSErrorLogInput;
import com.histo.fileuploader.model.WgsClientTransferStatus;

import javax.net.ssl.*;


public class ConnectionIntermitant {
	private static final Logger logger = LogManager.getLogger(ConnectionIntermitant.class);
	private static final String PACBIO_BASEURL = ApplicationPropertiesParams.getProperties("pacbio.baseurl");
	private static final String GRIDION_BASEURL = ApplicationPropertiesParams.getProperties("gridion.baseurl");
	public void updateWGSUploadStatus(WgsClientTransferStatus wgsGlobusTransferStatus) { 
		try {
			// Bypass SSL verification
			ignoreSSLVerification();

			String json = new Gson().toJson(wgsGlobusTransferStatus);
			byte[] input = json.getBytes("utf-8");
			URI uri = new URI(PACBIO_BASEURL +"wgsClientTransferStatus");
			URL url = uri.toURL();
			HttpURLConnection con = (HttpURLConnection)url.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("Content-Type", "application/json; utf-8");
			con.setDoOutput(true);
			con.setRequestProperty("Content-Length", String.valueOf(input.length));
			con.getOutputStream().write(input);
			Reader in = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
			
	        for (int c; (c = in.read()) >= 0;)
	            System.out.print((char)c);
			
			    
		} catch (MalformedURLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			logger.error(e);
		}
	}
	public void updateWGSErrorLog(WGSErrorLogInput wgsErrorLogInput) { 
		try {
			// Bypass SSL verification
			ignoreSSLVerification();

			String json = new Gson().toJson(wgsErrorLogInput);
			byte[] input = json.getBytes("utf-8");
			URI uri = new URI(PACBIO_BASEURL +"wgsLogInfo");
			URL url = uri.toURL();
			HttpURLConnection con = (HttpURLConnection)url.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("Content-Type", "application/json; utf-8");
			con.setDoOutput(true);
			con.setRequestProperty("Content-Length", String.valueOf(input.length));
			con.getOutputStream().write(input);
			Reader in = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
			    
		} catch(Exception e) {
			logger.error("Error :"+e.getMessage());
		}
	}

	public void updateGridIonUploadStatus(GridIonClientTransferStatus gridIonClientTransferStatus) {
		try {
			// Bypass SSL verification
			ignoreSSLVerification();

			String json = new Gson().toJson(gridIonClientTransferStatus);
			byte[] input = json.getBytes("utf-8");
			URI uri = new URI(GRIDION_BASEURL +"/gridIonRun/gridIonClientTransferStatus");
			URL url = uri.toURL();
			HttpURLConnection con = (HttpURLConnection)url.openConnection();
			con.setRequestMethod("PUT");
			con.setRequestProperty("Content-Type", "application/json; utf-8");
			con.setDoOutput(true);
			con.setRequestProperty("Content-Length", String.valueOf(input.length));
			con.getOutputStream().write(input);
			Reader in = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));

			for (int c; (c = in.read()) >= 0;){
				logger.info((char)c);
			}
		} catch (Exception e) {
			logger.error(e);
		}
	}

	public void updateGridIonLog(GridIonLogModel gridIonLogModel) {
		try {
			// Bypass SSL verification
			ignoreSSLVerification();

			String json = new Gson().toJson(gridIonLogModel);
			byte[] input = json.getBytes("utf-8");
			URI uri = new URI(GRIDION_BASEURL +"/gridIonRun/gridIonLog");
			URL url = uri.toURL();
			HttpURLConnection con = (HttpURLConnection)url.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("Content-Type", "application/json; utf-8");
			con.setDoOutput(true);
			con.setRequestProperty("Content-Length", String.valueOf(input.length));
			con.getOutputStream().write(input);
			Reader in = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));

		} catch(Exception e) {
			logger.error("Error :"+e.getMessage());
		}
	}

	private void ignoreSSLVerification() throws Exception {
		TrustManager[] trustAllCerts = new TrustManager[]{
				new X509TrustManager() {
					public java.security.cert.X509Certificate[] getAcceptedIssuers() {
						return null;
					}

					public void checkClientTrusted(X509Certificate[] certs, String authType) {
					}

					public void checkServerTrusted(X509Certificate[] certs, String authType) {
					}
				}
		};

		SSLContext sc = SSLContext.getInstance("SSL");
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

		HostnameVerifier allHostsValid = new HostnameVerifier() {
			public boolean verify(String hostname, SSLSession session) {
				return true;
			}
		};
		HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	}
}
