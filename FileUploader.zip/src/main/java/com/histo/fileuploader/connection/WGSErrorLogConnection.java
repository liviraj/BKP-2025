package com.histo.fileuploader.connection;

import com.histo.fileuploader.model.GridIonLogModel;
import com.histo.fileuploader.model.ProgramType;
import com.histo.fileuploader.util.Params;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.histo.fileuploader.model.WGSErrorLogInput;

public class WGSErrorLogConnection {
	private static final Logger logger = LogManager.getLogger(WGSErrorLogConnection.class);
	public static void updateErrorLog(int runId, int statusViewerId, String errorMessage, Params params) {
		try {
			if (params == null) {
				params = new Params();
			}
			ConnectionIntermitant connection = new ConnectionIntermitant();
			if (params.getProgramType() != null && params.getProgramType().equals(String.valueOf(ProgramType.GRIDION))) {
				logger.info("calling /gridIonLog service");
				GridIonLogModel gridIonLogModel = new GridIonLogModel(
						runId
						, params.getGridIonStatusViewerId()
						, errorMessage
						, "FileUploader"
						, 0
				);
				connection.updateGridIonLog(gridIonLogModel);
				logger.info("completed /gridIonLog service");
			} else {
				logger.info("calling wgsAuditingLog/ service");

				WGSErrorLogInput wgsErrorLogInput = new WGSErrorLogInput();
				wgsErrorLogInput.setWGSRunID(runId);
				wgsErrorLogInput.setWGSStatusViewerID(statusViewerId);
				wgsErrorLogInput.setLogInfo(errorMessage);
				wgsErrorLogInput.setProgramName("FileUploader");
				connection.updateWGSErrorLog(wgsErrorLogInput);
				logger.info("completed wgsAuditingLog/ service");
			}

		} catch (Exception e) {
			logger.error("Error :" + e.getMessage());
		}
	}

}
