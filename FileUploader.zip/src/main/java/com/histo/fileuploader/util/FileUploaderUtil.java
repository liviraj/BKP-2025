package com.histo.fileuploader.util;


import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.share.DiskShare;
import com.hierynomus.smbj.share.File;
import com.histo.config.DiskShareConfig;
import com.histo.fileuploader.connection.ApplicationPropertiesParams;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.Document;

import javax.xml.parsers.DocumentBuilderFactory;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import java.util.stream.Collectors;

public class FileUploaderUtil {
    private static final Logger logger = LogManager.getLogger(FileUploaderUtil.class);

    public static boolean validateRunName(Params params) {

        boolean isRunNameValid = false;
        try {
            String sourceUrl = params.getSourceParentPath().replace("\\", "/");
            String userName = ApplicationPropertiesParams.getProperties("sourcepath.username");
            String password = ApplicationPropertiesParams.getProperties("sourcepath.password");

            List<String> pathSplit = Arrays.stream(sourceUrl.split("/"))
                    .filter(path -> !path.equalsIgnoreCase(""))
                    .collect(Collectors.toList());

            DiskShareConfig diskShare = new DiskShareConfig(pathSplit.get(0), pathSplit.get(1), userName, password);
            String smbPath = sourceUrl.replace("//", "").replace(pathSplit.get(0) + "/", "")
                    .replace(pathSplit.get(1) + "/", "");

            boolean isFolderExist = diskShare.getDiskShare().folderExists(smbPath);
            if (isFolderExist) {
                String runTagName;
                List<FileIdBothDirectoryInformation> fileList = diskShare.getDiskShare().list(smbPath, "*");
                FileIdBothDirectoryInformation xmlFile = null;
                String xmlFileName = null;
                if (sourceUrl.contains("/ccs_data")) {
                    runTagName = "pbmeta:WellSample";
                    List<FileIdBothDirectoryInformation> listOutFiles = new ArrayList<>();
                    xmlFileName = getXmlFile(diskShare.getDiskShare(), smbPath).get(0);
                } else {
                    runTagName = "WellSample";
                    xmlFile = fileList.stream().filter(fileInfo
                            -> fileInfo.getFileName().toLowerCase().contains("subreadset.xml")
                            && fileInfo.getFileName().toLowerCase().endsWith(".xml")).findFirst().get();
                    xmlFileName = smbPath + "/" + xmlFile.getFileName();
                }

                File xmlSmbFile = diskShare.getDiskShare().openFile(xmlFileName, EnumSet.of(
                                AccessMask.GENERIC_READ)
                        , null
                        , SMB2ShareAccess.ALL
                        , SMB2CreateDisposition.FILE_OPEN
                        , null);

                Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(xmlSmbFile.getInputStream());
                doc.getDocumentElement().normalize();
                String key = doc.getElementsByTagName(runTagName).item(0).getAttributes().getNamedItem("Name").getNodeValue();
                String runName = params.runName;
                if (runName.contains("/ccs_data") || runName.contains("/raw_data")) {
                    runName = params.runName.split("/")[0];
                }
                isRunNameValid = (runName.trim()).equals(key.trim());
            }
        } catch (Exception e) {
            logger.error("Error : {}", e);
        }
        return isRunNameValid;
    }

    private static List<String> getXmlFile(DiskShare share, String folderPath) {
        List<String> resultList = new ArrayList<>();

        List<FileIdBothDirectoryInformation> files = share.list(folderPath, "*");

        files.stream()
                .filter(f -> !f.getFileName().equals(".") && !f.getFileName().equals("..")) // Ignore '.' and '..'
                .forEach(file -> {
                    String fullPath = folderPath + file.getFileName();

                    if (share.folderExists(fullPath) && resultList.size() <= 0) {
                        resultList.addAll(getXmlFile(share, fullPath + "/")); // Recursively add files from subdirectories
                    } else {
                        if (resultList.size() <= 0  && file.getFileName().endsWith(".xml")) {
                             resultList.add(fullPath);
                        }
                    }
                });

        return resultList;
    }
}
