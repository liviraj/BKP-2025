package com.histo.fileuploader.util;

import java.net.URLDecoder;

public class Params {
	public UploadType uploadType;
	public String username;
	public String password;
	public boolean isFolder;
	public String oAuth;
	public String sourceEndPoint;
	public String destinationEndPoint;
	public String sourceParentPath;
	public String destinationParentPath;
	public String runName;
	public String wgsStatusViewerID;
	public String sftpUserName;
	public String sftpPassword;
	public String sftpClientDomain;
	private String programType;
    private Integer gridIonStatusViewerId;

	public Params() {

	}

    public Integer getGridIonStatusViewerId() {
        return gridIonStatusViewerId;
    }

    public void setGridIonStatusViewerId(Integer gridIonStatusViewerId) {
        this.gridIonStatusViewerId = gridIonStatusViewerId;
    }

    public String getProgramType() {
		return programType;
	}

	public void setProgramType(String programType) {
		this.programType = programType;
	}

	public UploadType getUploadType() {
		return uploadType;
	}

	public void setUploadType(UploadType uploadType) {
		this.uploadType = uploadType;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isFolder() {
		return isFolder;
	}

	public void setFolder(boolean isFolder) {
		this.isFolder = isFolder;
	}

	public String getoAuth() {
		return oAuth;
	}

	public void setoAuth(String oAuth) {
		this.oAuth = oAuth;
	}

	public String getSourceEndPoint() {
		return sourceEndPoint;
	}

	public void setSourceEndPoint(String sourceEndPoint) {
		this.sourceEndPoint = sourceEndPoint;
	}

	public String getDestinationEndPoint() {
		return destinationEndPoint;
	}

	public void setDestinationEndPoint(String destinationEndPoint) {
		this.destinationEndPoint = destinationEndPoint;
	}

	public String getSourceParentPath() {
		return sourceParentPath;
	}

	public void setSourceParentPath(String sourceParentPath) {
		this.sourceParentPath = URLDecoder.decode(sourceParentPath);
	}

	public String getDestinationParentPath() {
		return destinationParentPath;
	}

	public void setDestinationParentPath(String destinationParentPath) {
		this.destinationParentPath = URLDecoder.decode(destinationParentPath);
	}

	public String getRunName() {
		return runName;
	}

	public void setRunName(String runName) {
		this.runName = URLDecoder.decode(runName);
	}

	public String getWgsStatusViewerID() {
		return wgsStatusViewerID;
	}

	public void setWgsStatusViewerID(String wgsStatusViewerID) {
		this.wgsStatusViewerID = wgsStatusViewerID;
	}

	public String getSftpUserName() {
		return sftpUserName;
	}

	public void setSftpUserName(String sFTPUsertName) {
		sftpUserName = sFTPUsertName;
	}

	public String getSftpPassword() {
		return sftpPassword;
	}

	public void setSftpPassword(String sFTPPassword) {
		sftpPassword = sFTPPassword;
	}

	public String getSftpClientDomain() {
		return sftpClientDomain;
	}

	public void setSftpClientDomain(String sFTPClientDomain) {
		sftpClientDomain = sFTPClientDomain;
	}
	@Override
	public String toString() {
		return "Params [uploadType=" + uploadType + ", username=" + username + ", password=" + password + ", isFolder="
				+ isFolder + ", oAuth=" + oAuth + ", sourceEndPoint=" + sourceEndPoint + ", destinationEndPoint="
				+ destinationEndPoint + ", sourceParentPath=" + sourceParentPath + ", destinationParentPath="
				+ destinationParentPath + ", runName=" + runName + ", wgsStatusViewerID=" + wgsStatusViewerID
				+ ", SFTPUsertName=" + sftpUserName + ", SFTPPassword=" + sftpPassword + ", SFTPClientDomain="
				+ sftpClientDomain + "]";
	}

}
