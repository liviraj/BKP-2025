package com.histo.fileuploader.util;

public enum UploadType {
	GLOBUS,
	SFTP,
	FTP
}
