package com.histo.fileuploader.model;

public class WgsClientTransferStatus {
	private int WGSStatusViewerID;
	private int Status;
	private String DestinationUplodPath;
	
	public int getWGSStatusViewerID() {
		return WGSStatusViewerID;
	}
	public void setWGSStatusViewerID(int wGSStatusViewerID) {
		WGSStatusViewerID = wGSStatusViewerID;
	}
	public int getStatus() {
		return Status;
	}
	public void setStatus(int status) {
		Status = status;
	}
	public String getDestinationUplodPath() {
		return DestinationUplodPath;
	}
	public void setDestinationUplodPath(String destinationUplodPath) {
		DestinationUplodPath = destinationUplodPath;
	}
}
