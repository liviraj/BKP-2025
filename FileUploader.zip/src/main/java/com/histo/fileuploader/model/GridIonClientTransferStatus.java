package com.histo.fileuploader.model;

public class GridIonClientTransferStatus {
    private int gridIonStatusViewerId;
    private int statusId;
    private String destinationUploadPath;

    public GridIonClientTransferStatus() {
    }

    public GridIonClientTransferStatus(int gridIonStatusViewerId, int statusId, String destinationUploadPath) {
        this.gridIonStatusViewerId = gridIonStatusViewerId;
        this.statusId = statusId;
        this.destinationUploadPath = destinationUploadPath;
    }

    public int getGridIonStatusViewerId() {
        return gridIonStatusViewerId;
    }

    public void setGridIonStatusViewerId(int gridIonStatusViewerId) {
        this.gridIonStatusViewerId = gridIonStatusViewerId;
    }

    public int getStatusId() {
        return statusId;
    }

    public void setStatusId(int statusId) {
        this.statusId = statusId;
    }

    public String getDestinationUploadPath() {
        return destinationUploadPath;
    }

    public void setDestinationUploadPath(String destinationUploadPath) {
        this.destinationUploadPath = destinationUploadPath;
    }

    @Override
    public String toString() {
        return "GridIonClientTransferStatus{" +
                "gridIonStatusViewerId=" + gridIonStatusViewerId +
                ", statusId=" + statusId +
                ", destinationUploadPath='" + destinationUploadPath + '\'' +
                '}';
    }
}
