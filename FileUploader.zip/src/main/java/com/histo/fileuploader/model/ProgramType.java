package com.histo.fileuploader.model;

public enum ProgramType {
    WGS,GRIDION
}
