package com.histo.fileuploader.model;

public class GridIonLogModel {
    private int gridIonRunId;
    private int gridIonStatusViewerId;
    private String logInfo;
    private String programName;
    private Integer userId;

    public GridIonLogModel() {
    }

    public GridIonLogModel(int gridIonRunId, int gridIonStatusViewerId, String logInfo, String programName, Integer userId) {
        this.gridIonRunId = gridIonRunId;
        this.gridIonStatusViewerId = gridIonStatusViewerId;
        this.logInfo = logInfo;
        this.programName = programName;
        this.userId = userId;
    }

    public int getGridIonRunId() {
        return gridIonRunId;
    }

    public void setGridIonRunId(int gridIonRunId) {
        this.gridIonRunId = gridIonRunId;
    }

    public int getGridIonStatusViewerId() {
        return gridIonStatusViewerId;
    }

    public void setGridIonStatusViewerId(int gridIonStatusViewerId) {
        this.gridIonStatusViewerId = gridIonStatusViewerId;
    }

    public String getLogInfo() {
        return logInfo;
    }

    public void setLogInfo(String logInfo) {
        this.logInfo = logInfo;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "GridIonLogModel{" +
                "gridIonRunId=" + gridIonRunId +
                ", gridIonStatusViewerId=" + gridIonStatusViewerId +
                ", logInfo='" + logInfo + '\'' +
                ", programName='" + programName + '\'' +
                ", userId=" + userId +
                '}';
    }
}
