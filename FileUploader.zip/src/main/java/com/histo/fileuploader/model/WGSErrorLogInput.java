package com.histo.fileuploader.model;

public class WGSErrorLogInput {
	private int WGSRunID;
	private int WGSStatusViewerID;
	private String LogInfo;
	private String ProgramName;
	public int getWGSRunID() {
		return WGSRunID;
	}
	public void setWGSRunID(int wGSRunID) {
		WGSRunID = wGSRunID;
	}
	public int getWGSStatusViewerID() {
		return WGSStatusViewerID;
	}
	public void setWGSStatusViewerID(int wGSStatusViewerID) {
		WGSStatusViewerID = wGSStatusViewerID;
	}
	public String getLogInfo() {
		return LogInfo;
	}
	public void setLogInfo(String logInfo) {
		LogInfo = logInfo;
	}
	public String getProgramName() {
		return ProgramName;
	}
	public void setProgramName(String programName) {
		ProgramName = programName;
	}
	

}
