package com.histo.fileupload.globus.connection;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;

import com.histo.fileuploader.model.GridIonClientTransferStatus;
import com.histo.fileuploader.model.ProgramType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.histo.fileuploader.connection.ConnectionIntermitant;
import com.histo.fileuploader.connection.WGSErrorLogConnection;
import com.histo.fileuploader.model.WgsClientTransferStatus;
import com.histo.fileuploader.util.Params;



public class GlobusDataTransfer implements Runnable{
	private static final Logger logger = LogManager.getLogger(GlobusDataTransfer.class);
	private JSONTransferAPIClient client;
	private boolean isRecursive = false;
	private Params params;
	private static final String DATA_TYPE = "DATA_TYPE";
	public GlobusDataTransfer(JSONTransferAPIClient client, Params params, boolean isRecursive) {
		this.client = client;
		this.isRecursive = isRecursive;
		this.params = params;
	}
	public void run()
	{
		
		JSONTransferAPIClient.Result r;
		String ep1id = params.sourceEndPoint; //"ddb59aef-6d04-11e5-ba46-22000b92c6ec"; //"4334c376-e5b7-11eb-ae20-5fb6ebd5f3fb";//"ddb59aef-6d04-11e5-ba46-22000b92c6ec";
		String ep2id = params.destinationEndPoint; //"ddb59af0-6d04-11e5-ba46-22000b92c6ec";
		int wgsStatusViewerId = Integer.parseInt(params.wgsStatusViewerID);
		
//		if(!FileUploaderUtil.validateRunName(params)) {
//			logger.info("Run name is not valid");
//			updateClientTransferStatus(4, Integer.parseInt(params.wgsStatusViewerID), params.destinationParentPath + params.runName);
//			WGSErrorLogConnection.updateWGSErrorLog(0, wgsStatusViewerId, "Run name is not same as XML file run name" );
//			return;
//		}
		try {
			
			updateClientTransferStatus(2, Integer.parseInt(params.wgsStatusViewerID), params.destinationParentPath + params.runName, params);
			logger.info("=== Before Transfer ===");
			WGSErrorLogConnection.updateErrorLog(0,wgsStatusViewerId,"Copy process started", params);
			logger.info("Getting ls from Globus");
			Map<String, String> queryParams = new HashMap<String, String>();
			queryParams.put("path", "/~/" + params.destinationParentPath + params.runName);
			r= client.getResult("/operation/endpoint/" + ep2id + "/ls", queryParams);
			JSONObject value = r.document;
			logger.info("ls completed from Globus");
			logger.info("Params: {}", params);
		} catch (JSONException | IOException | GeneralSecurityException e) {
			logger.error("Error: {}", e);
		} catch (APIError e) {
			//Create Run name
			if(e.statusCode == 404) {
				JSONObject body = new JSONObject();
				body.put(DATA_TYPE, "mkdir");
				body.put("path", "/~" +  params.destinationParentPath + params.runName);
				try {
					logger.info("calling mkdir");
					r = client.postResult("/operation/endpoint/" + ep2id + "/mkdir", body, null);
					logger.info("calling mkdir completed");
				} catch (JSONException | IOException | GeneralSecurityException | APIError e1) {
					e1.printStackTrace();
				} 
			} else {
				logger.error("Error: {}", e);
			}
			
		} finally {
			
			
			try {
				logger.info("submission_id call");
				r = client.getResult("/submission_id");
				String submissionId = r.document.getString("value");
				logger.info("submission_id is %s" , submissionId);
				JSONObject transfer = new JSONObject();
				transfer.put(DATA_TYPE, "transfer");
				transfer.put("submission_id", submissionId);
				transfer.put("source_endpoint", ep1id);
				transfer.put("destination_endpoint", ep2id);

				JSONObject item = new JSONObject();
				item.put(DATA_TYPE, "transfer_item");
				item.put("source_path", params.sourceParentPath + params.runName);//"/Z/Syngenta/11232020/CCS Data/m54294U_201117_001947/");
				item.put("destination_path", params.destinationParentPath + params.runName);//"/Vendors/ Histogenetics/Test/");
				item.put("recursive", isRecursive); //This will decide whether need to transfer folder or file
				//item.put("label", "Transfer the run : " + params.runName);
				transfer.append("DATA", item);
				logger.info("transfer starting");
				r = client.postResult("/transfer", transfer, null);
				String taskId = r.document.getString("task_id");
				logger.info("transfer taskId is %s" , taskId);
				logger.info("transfer starting");
				/* Below is the setting the transfer label*/
//				JSONObject labelChangeItem = new JSONObject();
//				labelChangeItem.put("label","Transfer the run : " + params.runName);
//				JSONTransferAPIClient.Result resultUpdateLabel = client.putResult("/task/"+taskId, labelChangeItem);
//				String label = resultUpdateLabel.document.getString("label");
//				logger.info("Transfer label is %s", label);

				if (!waitForTask(taskId)) {
					logger.error(
							"Transfer not completed, exiting");
					updateClientTransferStatus(4, Integer.parseInt(params.wgsStatusViewerID), params.destinationParentPath + params.runName, params);
					WGSErrorLogConnection.updateErrorLog(0,wgsStatusViewerId,"Transfer not completed, exiting", params);
				} else {
					updateClientTransferStatus(3, Integer.parseInt(params.wgsStatusViewerID), params.destinationParentPath + params.runName, params);
					WGSErrorLogConnection.updateErrorLog(0,wgsStatusViewerId,"Copied successfully", params);
					logger.info("=== After Transfer ===");
	
	
					logger.info("=== Endpoint Management ===");
				}
			} 
			catch (Exception e) {
				logger.error("Error : {}", e.getMessage());
				updateClientTransferStatus(4, Integer.parseInt(params.wgsStatusViewerID), params.destinationParentPath + params.runName, params);
				WGSErrorLogConnection.updateErrorLog(0,wgsStatusViewerId,e.getMessage(), params);
			}
			
		}
	}


	public boolean waitForTask(String taskId) {
		String status = "ACTIVE";
		JSONTransferAPIClient.Result r;
		Instant instant = Instant.now().minus(1, ChronoUnit.DAYS);
		String time = DateTimeFormatter.ISO_INSTANT.format(instant);
		String resource = "/task_list";
		Map<String, String> params = new HashMap<String, String>();
		params.put("orderby", "request_time DESC");
		params.put("filter", "status:ACTIVE,FAILED,INACTIVE,SUCCEEDED/type:TRANSFER,DELETE/request_time:" + time);
		params.put("limit", "25");
		params.put("offset", "0");
		
		while (status.equals("ACTIVE")) {
			try {
			r = client.getResult(resource, params);
			JSONArray jsonArray = r.document.getJSONArray("DATA");
			for(int i = 0; i < jsonArray.length(); i++) {
				JSONObject jsonObject = jsonArray.getJSONObject(i);
				if(taskId.equals(jsonObject.getString("task_id"))) {
					status = jsonObject.getString("status");
					break;
				}
			}
			} catch(IOException ex) {
				logger.error("IOException : %s", ex.getMessage());
				ex.printStackTrace();
			} catch(GeneralSecurityException ex) {
				logger.error("GeneralSecurityException : %s", ex.getMessage());
				ex.printStackTrace();
			} catch(JSONException ex) {
				logger.error("JSONException : %s", ex.getMessage());
				ex.printStackTrace();
			} catch(APIError ex) {
				logger.error("APIError : %s", ex.getMessage());
				ex.printStackTrace();
			} catch(UnsupportedOperationException ex) {
				logger.error("UnsupportedOperationException : %s", ex.getMessage());
				ex.printStackTrace();
			} catch (IllegalStateException ex) {
				logger.error("IllegalStateException : %s", ex.getMessage());
				ex.printStackTrace();
			} catch (Exception e) {
				logger.error("Exception : %s", e.getStackTrace());
				e.printStackTrace();
			} 
			try {
				Thread.sleep(4*1000);
			}
			catch(Exception e) {
				logger.error("Thread Exception : %s", e.getMessage());
				return false;
			}
		}
		logger.info("Final Status : %s", status);

		if (status.equals("ACTIVE"))
			return false;
		return true;
	}

	public JSONObject copyEndpoint(String endpointId, String copyName)
			throws IOException, JSONException, GeneralSecurityException, APIError {
		String resource = BaseTransferAPIClient.endpointPath(endpointId);
		JSONTransferAPIClient.Result r = client.getResult(resource);
		JSONObject endpoint = r.document;
		endpoint.put("display_name", copyName);
		endpoint.put("name", copyName);
		endpoint.remove("username");
		endpoint.remove("canonical_name");
		endpoint.remove("id");
		endpoint.remove("subscription_id");

		r = client.postResult("/endpoint", endpoint);
		return r.document;
	}

	public String setEndpointDescription(String endpointId,
			String description)
					throws IOException, JSONException, GeneralSecurityException, APIError {
		String resource = BaseTransferAPIClient.endpointPath(endpointId);
		JSONObject o = new JSONObject();
		o.put("DATA_TYPE", "endpoint");
		o.put("description", description);

		JSONTransferAPIClient.Result r = client.putResult(resource, o);
		return r.document.getString("code");
	}

	public String deleteEndpoint(String endpointId)
			throws IOException, JSONException, GeneralSecurityException, APIError {
		String resource = BaseTransferAPIClient.endpointPath(endpointId);
		JSONTransferAPIClient.Result r = client.deleteResult(resource);
		return r.document.getString("code");
	}
	public void updateClientTransferStatus(int status, int statusViewerId,String destinationPath, Params params) {
		logger.info("ClientTransferStatus service call for %s", status);
		try {
			ConnectionIntermitant connection = new ConnectionIntermitant();
			if (params.getProgramType() != null && params.getProgramType().equals(String.valueOf(ProgramType.GRIDION))) {
				GridIonClientTransferStatus gridIonClientTransferStatus = new GridIonClientTransferStatus(
						params.getGridIonStatusViewerId()
						, status
						, destinationPath
				);

				connection.updateGridIonUploadStatus(gridIonClientTransferStatus);
			} else {
				WgsClientTransferStatus localTransferIdStatus = new WgsClientTransferStatus();
				localTransferIdStatus.setStatus(status);
				localTransferIdStatus.setWGSStatusViewerID(statusViewerId);
				localTransferIdStatus.setDestinationUplodPath(destinationPath);
				connection.updateWGSUploadStatus(localTransferIdStatus);
			}
		}
		catch (Exception e) {
			logger.error("Error : %s", e.getMessage());
		}
		logger.info("ClientTransferStatus service call completed for %s", status);
	}
}
