package com.histo.fileupload.globus.connection;

public class APIError extends Exception {
    public int statusCode;
    public String statusMessage;

    public String category;

    public String resource;
    public String requestId;
    public String code;
    public String message;

    public static final String CLIENT_ERROR = "ClientError";
    public static final String SERVER_ERROR = "ServerError";
    public static final String SERVICE_UNAVAILABLE = "ServiceUnavailable";
    public static final String EXTERNAL_ERROR = "ExternalError";
    public static final String UNKNOWN_ERROR = "UnknownError";

    public APIError(int statusCode, String statusMessage, String code) {
        this(statusCode, statusMessage, code, null, null, null);
    }

    public APIError(int statusCode, String statusMessage, String code,
                    String resource, String requestId, String message) {
        this.statusCode = statusCode;
        this.statusMessage = statusMessage;

        // Error category is the first part of the error code.
        if (code != null && code.length() > 0) {
            String[] codeParts = code.split(".", 2);
            this.category = codeParts[0];
        } else {
            this.category = "ServerError";
            code = "ServerError.UnknownError";
        }

        this.resource = resource;
        this.requestId = requestId;
        this.code = code;
        this.message = message;
    }

    @Override
    public String toString() {
        return code + "(" + statusCode + " "
               + statusMessage + ") on request '" + requestId
               + "' resource '" + resource + "': " + message;
    }
}
