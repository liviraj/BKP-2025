package com.histo.fileupload.sftp.connection;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.histo.config.DiskShareConfig;
import com.histo.fileuploader.connection.ApplicationPropertiesParams;
import com.histo.fileuploader.util.FileUploaderUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.histo.fileuploader.connection.ConnectionIntermitant;
import com.histo.fileuploader.connection.WGSErrorLogConnection;
import com.histo.fileuploader.model.WgsClientTransferStatus;
import com.histo.fileuploader.util.Params;

import net.schmizz.sshj.SSHClient;
import net.schmizz.sshj.sftp.FileAttributes;
import net.schmizz.sshj.sftp.FileMode;
import net.schmizz.sshj.sftp.RemoteResourceInfo;
import net.schmizz.sshj.sftp.SFTPClient;
import net.schmizz.sshj.transport.verification.PromiscuousVerifier;

public class SFTPDataTransfer {
	private static final Logger logger = LogManager.getLogger(SFTPDataTransfer.class);
	private Params  params;
	static SFTPClient sftp = null;
	static SSHClient ssh = null;
	static int wgsStatucViewerID = 0;
	static String destinationPath = "";

	public SFTPDataTransfer(Params params) {
		this.params = params;
		SFTPDataTransfer.wgsStatucViewerID = Integer.parseInt(params.wgsStatusViewerID);
		SFTPDataTransfer.destinationPath =params.destinationParentPath+params.runName;
	}
	

	public void run() throws IOException {
		
		if(!FileUploaderUtil.validateRunName(params)) {
			logger.info("Run name is not validated");
			WGSErrorLogConnection.updateErrorLog(0, wgsStatucViewerID, "Run name is not same as XML file run name", params);
			updateclientTransferStatus(4,wgsStatucViewerID,destinationPath);
			return;
		}

		String osName = System.getProperty("os.name");
		logger.info("OS name: {}",osName);
		if (osName.toLowerCase().contains("ubuntu") || osName.toLowerCase().contains("linux")) {
			params.sourceParentPath = params.sourceParentPath.replace("\\","/");
			List<String> pathSplit = Arrays.stream(params.sourceParentPath.split("/"))
					.filter(path -> !path.equalsIgnoreCase(""))
					.collect(Collectors.toList());


			params.sourceParentPath = params.sourceParentPath.replace("//", "").replace(pathSplit.get(0) + "/", "")
					.replace(pathSplit.get(1) + "/", "");
			String sourceMountPath = ApplicationPropertiesParams.getProperties("mount.source-path");
			params.sourceParentPath = sourceMountPath + params.sourceParentPath;
		}
		ssh = new SSHClient();
		try {
			
//			Security.setProperty("crypto.policy", "unlimited");
			ssh.addHostKeyVerifier(new PromiscuousVerifier());
//	        ssh.loadKnownHosts();
			ssh.connect(params.sftpClientDomain);
			ssh.authPassword(params.sftpUserName, params.sftpPassword);
//            ssh.authPublickey(null, arg);
//			final String src = params.sourceParentPath; //System.getProperty("user.home") + File.separator + "S3176--S3176";
			params.sourceParentPath = params.sourceParentPath.replace("\\","/");
			params.sourceParentPath = params.sourceParentPath.endsWith("/") ? params.sourceParentPath : params.sourceParentPath + "/";
			File localFile = new File(params.sourceParentPath);
			if(!localFile.exists()) {
				logger.info("Source path-60: {}", params.sourceParentPath);
				logger.error(params.sourceParentPath+ "not exist or accessable");
				updateclientTransferStatus(4,wgsStatucViewerID,destinationPath);
				WGSErrorLogConnection.updateErrorLog(0,wgsStatucViewerID,params.sourceParentPath+ "not exist or accessable", params);
				throw new RuntimeException(params.sourceParentPath+ "not exist or accessable");
			}
			sftp = ssh.newSFTPClient();
			String clientDestinatioPath = params.destinationParentPath + params.runName;
			try {
				// check whethere the Path is exist or not
				FileAttributes fAttr = sftp.statExistence(clientDestinatioPath);
				if (fAttr == null) {
					logger.info("Copy process started...");
					WGSErrorLogConnection.updateErrorLog(0,wgsStatucViewerID,"Copy process started", params);
					sftp.mkdirs(clientDestinatioPath);
					long statTime = System.currentTimeMillis();
					copyProcess(localFile.getAbsolutePath(), clientDestinatioPath); // copy process
					updateclientTransferStatus(3,wgsStatucViewerID,destinationPath);
					long endTime = System.currentTimeMillis();
					logger.info("Copied successfully");
					WGSErrorLogConnection.updateErrorLog(0,wgsStatucViewerID,"Copied successfully", params);
					logger.info("Total time taken for copied :" + (endTime - statTime));
				} else {
					logger.info("File already exists");
					long localFileSize = Files.walk(localFile.getAbsoluteFile().toPath())
							.mapToLong(p -> p.toFile().length()).sum();
					long RemoteFileorFolderSize = getFileorFolderSize(fAttr,
							clientDestinatioPath);
					logger.info("Source File/Directory Size :" + localFileSize);
					logger.info("Destination File/Diretory Size :" + RemoteFileorFolderSize);
            		if(localFileSize != RemoteFileorFolderSize)
            		{
            			copyProcess(localFile.getAbsolutePath(), clientDestinatioPath); //copy process
            			updateclientTransferStatus(3,wgsStatucViewerID,destinationPath);
            		}
					else {
						logger.info("Destination file already exists with same size of source path.");
						WGSErrorLogConnection.updateErrorLog(0,wgsStatucViewerID,"Destination file already exists with same size of source path.", params);
						updateclientTransferStatus(3,wgsStatucViewerID,destinationPath);
					}
				}
			} catch (Exception e) {
				logger.info("Source path-102: {}", params.sourceParentPath);
				logger.error(e.getMessage());
				updateclientTransferStatus(4,wgsStatucViewerID,destinationPath);
				WGSErrorLogConnection.updateErrorLog(0,wgsStatucViewerID,e.getMessage(), params);
			} 
//			finally {
//				sftp.close();
//			}
		}
		catch (Exception e) {
			logger.info("Source path-112: {}", params.sourceParentPath);
			logger.error(e);
			logger.error("Error :"+e.getMessage());
			updateclientTransferStatus(4,wgsStatucViewerID,destinationPath);
			WGSErrorLogConnection.updateErrorLog(0,wgsStatucViewerID,e.getMessage(), params);
		}
		finally {
			ssh.disconnect();
			ssh.close();
		}
	}
	
	public static void copyProcess(String sourcePath, String destinationPath) throws IOException {
		// 1 mins for 1GB data
		try {
			updateclientTransferStatus(2,wgsStatucViewerID,destinationPath);
			logger.info("In progress updated");
			sftp.getFileTransfer().setPreserveAttributes(false);
			sourcePath = sourcePath.replace("\\","/");
			sourcePath = sourcePath.endsWith("/") ? sourcePath : sourcePath + "/";
			sftp.put(sourcePath, destinationPath);
		} catch (Exception e) {
			logger.error("File copy process stopped due to :" + e.getMessage());
			updateclientTransferStatus(4,wgsStatucViewerID,destinationPath);
			WGSErrorLogConnection.updateErrorLog(0,wgsStatucViewerID,e.getMessage(), null);
			ssh.disconnect();
			ssh.close();
			throw new RuntimeException();
			
		}
	}

	public static long getFileorFolderSize(FileAttributes fAttr, String path) {
		long length = 0;
		try {
			if (fAttr.getMode().getType() == FileMode.Type.REGULAR) { // file
				return fAttr.getSize();
			}
			for (RemoteResourceInfo file : sftp.ls(path)) { // Directory
				if (file.isRegularFile()) {
					length += file.getAttributes().getSize();
				} else {
					length += getFileorFolderSize(file.getAttributes(), file.getPath());
				}
			}
		} catch (Exception e) {
//			e.printStackTrace();
			logger.error("Error :"+e.getMessage());
			updateclientTransferStatus(4,wgsStatucViewerID,destinationPath);
			WGSErrorLogConnection.updateErrorLog(0,wgsStatucViewerID,e.getMessage(), null);
			throw new RuntimeException();
		}
		return length;
	}
	public static void updateclientTransferStatus(int statusCode,int wgsStatusViewerID,String destinationPath) {
		try {
			logger.info("calling ClientTransferStatus service");
			ConnectionIntermitant conection = new ConnectionIntermitant();
			WgsClientTransferStatus localTransferIdStatus = new WgsClientTransferStatus();
			localTransferIdStatus.setStatus(statusCode);
			localTransferIdStatus.setWGSStatusViewerID(wgsStatusViewerID);
			localTransferIdStatus.setDestinationUplodPath(destinationPath);
			conection.updateWGSUploadStatus(localTransferIdStatus);
			logger.info("completed ClientTransferStatus service");
		} catch (Exception e) {
			logger.error("Error :" + e.getMessage());
			//no need to insert error log because pacbioweb already in connection issue
		}
	}

}
