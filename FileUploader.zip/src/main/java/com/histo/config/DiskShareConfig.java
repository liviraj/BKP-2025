package com.histo.config;

import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;

import java.io.IOException;

public class DiskShareConfig {
    private DiskShare diskShare;
    private SMBClient client;
    private Connection connection;
    private Session session;
    private static final String SMB_DOMAIN_NAME = "histogenetics.com";

    public DiskShareConfig(String server, String share, String username, String password) {
        try {
            client = new SMBClient();
            connection = client.connect(server);
            AuthenticationContext authContextDelete = new AuthenticationContext(username, password.toCharArray()
                    , SMB_DOMAIN_NAME);
            session = connection.authenticate(authContextDelete);
            this.diskShare = (DiskShare) session.connectShare(share);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public DiskShare getDiskShare() {
        return diskShare;
    }

    public void close() throws Exception {
        if (diskShare != null) {
            diskShare.close();
        }
        if (session != null) {
            session.close();
        }
        if (connection != null) {
            connection.close();
        }
        if (client != null) {
            client.close();
        }
    }

    @Override
    public String toString() {
        return "DiskShareConfig{" +
                "diskShare=" + diskShare +
                '}';
    }
}
