import { useNavigate } from "react-router-dom";
import databaseBackupStatusViewer from "../../assets/Redirect_img/DatabaseBackupStatusViewer.png";
import { path } from "../Shared/Constant";
import { useDispatch, useSelector } from "react-redux";
import { userActions } from "../redux/userReducer";
import TransparentLoader from "../loader/TransparentLoader";
import ApiResponse from "../Alert/ApiResponse";
import Illuminapacbio from "../../assets/Redirect_img/Illumina_Pacbio.png"
function HomePage() {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const userState = useSelector(state => state.user);
    const apiResponseState = useSelector(state => state.user.apiResponse);

   
    const onhandleRedirect = async (e, proj) => {
        await dispatch(userActions.setLoader(true));
        if (proj.redirectPath === path.dbBkp) {
            navigate(path.dbBkp);
        }
        else if(proj.redirectPath == path.illuminaPacbio){
            navigate(path.illuminaPacbio)
        }
        dispatch(userActions.setLoader(false));
    }

    return (
        <div>
            <div className='w-full my-10 flex justify-center'>
                <div className='grid lg:grid-cols-4 md:grid-cols-4 sm:grid-cols-2 xsm:grid gap-12 lg:justify-center'>
                    {
                        projects.map(val => <span className='w-full max-w-md mx-auto' key={val.projectID} onClick={(e) => onhandleRedirect(e, val)}> <img src={val.imageSrc} alt='#' className='mx-auto cursor-pointer h-48 md:h-44 sm:h-36 xsm:h-32' /></span>)
                    }
                </div>
            </div>
            {userState.loader && <TransparentLoader />}
            {apiResponseState.show && <ApiResponse />}
        </div>
    )
}

export default HomePage

const projects = [
    {
        projectName: "Database Backup Status Viewer",
        projectID: 1,
        imageSrc: databaseBackupStatusViewer,
        redirectPath: path.dbBkp
    },
    {
        projectName: "Illumina pacbio Backup Status Viewer",
        projectID: 2,
        imageSrc: Illuminapacbio,
        redirectPath: path.illuminaPacbio
    }
]