import { useForm } from "react-hook-form";
import Dropdown from "../Element/Dropdown"
import AgGrid from "../Grid/AgGrid"
import { databaseStatusViewer } from "../Grid/Columns"
import SubHeader from "../layouts/SubHeader"
import { path, period, periodOptions, strings } from "../Shared/Constant";
import { Space } from "antd";
import PrimaryButton from "../Element/PrimaryButton";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { dbBkpStatusViewer_request } from "../Request";
import TransparentLoader from "../loader/TransparentLoader";
import { dbBkpStatusActions } from "../redux/dbBkpStatusReducer";
import ViewDBRecords from "../PopupScreens/ViewDBRecords";
import { databaseReducerState } from "../Helper";
import ApiResponse from "../Alert/ApiResponse";
import RangePickerElement from "../Element/RangePickerElement";
import dayjs from "dayjs";

function DbBkpStatusViewer() {
    const { watch, setValue, handleSubmit, getValues, reset } = useForm({ defaultValues: initialState });
    let serverName = watch(strings.dbkStatusViewer.serverName)
    const dispatch = useDispatch();
    const databaseReduxState = useSelector(state => state.database);
    const apiResponseState = useSelector(state => state.user.apiResponse);

    useEffect(() => {
        const initialLoad = async () => {
            document.title = "Database Backup Status Viewer"
            await dispatch(dbBkpStatusActions.setLoader(true));
            await handleDateformat(period[1]);
            await dispatch(dbBkpStatusViewer_request.filterOptions());
            await onSubmit(getValues());
            dispatch(dbBkpStatusActions.setLoader(false));
            sessionStorage.setItem(strings.login.path, path.dbBkp);
        }
        initialLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const resetValues = async () => {
        reset();
        await handleDateformat(period[1]);
        await onSubmit(getValues());
    }

    const handleDateformat = (data) => {
        setValue(strings.dbkStatusViewer.period, data);
        periodOptions(data.value, setValue);
      }

      const onServerNameChange = (data) => {
        const database = watch(strings.dbkStatusViewer.database);
        const value = data.value;
        setValue(strings.dbkStatusViewer.serverName, data);
        if(database && Object.keys(database).length > 0){
            const databaseNames = databaseReduxState.database.find(val => val.serverName.toLowerCase() === value.toLowerCase()).dataBaseNames;
            if(!databaseNames.find(val => val.label === database.label)){
                setValue(strings.dbkStatusViewer.database, databaseNames.find(val => val.label.toLowerCase() === 'All Important Databases'.toLowerCase()));
            }
        }
      }

      const onSubmit = async (data) => {
        let filterRecords = {};
        let fromDate = "";
        let toDate = ""
        await dispatch(dbBkpStatusActions.setLoader(true));
        if(data[strings.dbkStatusViewer.date]){
            fromDate = dayjs(data[strings.dbkStatusViewer.date][0]).format("MM/DD/YYYY");
            toDate = dayjs(data[strings.dbkStatusViewer.date][1]).format("MM/DD/YYYY");
        }
        
        if(strings.dbkStatusViewer.serverType in data){
            filterRecords = {...filterRecords, serverType: data[strings.dbkStatusViewer.serverType].label }
        }
        if(strings.dbkStatusViewer.serverName in data){
            filterRecords = {...filterRecords, serverName: data[strings.dbkStatusViewer.serverName].label }
        }
        if(strings.dbkStatusViewer.database in data){
            filterRecords = {...filterRecords, databaseName: data[strings.dbkStatusViewer.database].label }
        }
        if(strings.dbkStatusViewer.type in data){
            filterRecords = {...filterRecords, typeOfBackup: data[strings.dbkStatusViewer.type].label }
        }
        if(strings.dbkStatusViewer.backupStatus in data){
            filterRecords = { ...filterRecords, secondaryBackupStatus: data[strings.dbkStatusViewer.backupStatus].label}
        }
        if(strings.dbkStatusViewer.date in data){
            filterRecords = {...filterRecords, fromDate: fromDate, toDate: toDate  }
        }
       
        await dispatch(dbBkpStatusViewer_request.getFilterRecords(filterRecords));
        dispatch(dbBkpStatusActions.setLoader(false));
      }
    const databaseOptions = () => {
        serverName = watch(strings.dbkStatusViewer.serverName);
        if (serverName && Object.keys(serverName).length > 0 && databaseReducerState().database && databaseReducerState().database.length > 0) {
            const tempData = databaseReducerState().database.find(val => val.serverName.toLowerCase() === serverName.label.toLowerCase());
            return tempData ? tempData.dataBaseNames : [];
        }
        return []
    }

    return (
        <div>
            <SubHeader subHeader={"DataBase Backup Status Viewer"} />
            <div className=" mx-5">
                <div className='grid lg:grid-rows-2 md:grid-rows-2 sm:grid-rows-3 gap-x-4 gap-y-2 lg:grid-cols-5 md:grid-cols-5 sm:grid-cols-3 w-full mb-5'>
                    <Dropdown placeholder={"Server Type"} value={watch(strings.dbkStatusViewer.serverType)} onChange={value => setValue(strings.dbkStatusViewer.serverType, value)}  options={databaseReduxState.serverType} isSortable={true} />
                    <Dropdown placeholder={"Server Name"} value={serverName} onChange={value => onServerNameChange(value)}  options={databaseReduxState.serverName} isSortable={true} />
                    <Dropdown placeholder={"Database"} value={watch(strings.dbkStatusViewer.database)} onChange={value => setValue(strings.dbkStatusViewer.database, value)}  options={databaseOptions()} isSearchable={true} isSortable={true} />
                    <Dropdown placeholder={"Type"} value={watch(strings.dbkStatusViewer.type)} onChange={value => setValue(strings.dbkStatusViewer.type, value)}  options={databaseReduxState.databaseType} isSortable={true} />
                    <Dropdown placeholder={"Secondary Site Backup Status"} value={watch(strings.dbkStatusViewer.backupStatus)} onChange={value => setValue(strings.dbkStatusViewer.backupStatus, value)}  options={databaseReduxState.backupStatus} isSortable={true} />
                    <Dropdown placeholder={"Period"} value={watch(strings.dbkStatusViewer.period)} onChange={data => handleDateformat(data)} options={period}  />
                    <div className=" col-span-2"><RangePickerElement placeholder={["From", "To"]} value={watch(strings.dbkStatusViewer.date)} onChange={value => setValue(strings.dbkStatusViewer.date, value)}  isDisable={watch(strings.dbkStatusViewer.period) && watch(strings.dbkStatusViewer.period).value === period[0].value ? false : true} /></div>
                    {/* <Datepicker placeholder={"From"} value={watch(strings.dbkStatusViewer.fromDate)} onChange={value =>setValue(strings.dbkStatusViewer.fromDate, value)}  maxDate={watch(strings.dbkStatusViewer.toDate)} isDisable={watch(strings.dbkStatusViewer.period) && watch(strings.dbkStatusViewer.period).value === period[0].value ? false : true} /> */}
                    {/* <Datepicker placeholder={"To"} value={watch(strings.dbkStatusViewer.toDate)} onChange={value => setValue(strings.dbkStatusViewer.toDate, value)}  minDate={watch(strings.dbkStatusViewer.fromDate)} isDisable={watch(strings.dbkStatusViewer.period) && watch(strings.dbkStatusViewer.period).value === period[0].value ? false : true} /> */}
                    <div className=" flex justify-center items-end"><Space><PrimaryButton value={"Search"} disable={!watch(strings.dbkStatusViewer.date)} onClick={handleSubmit(onSubmit)} /><PrimaryButton value={"Reset"} onClick={resetValues} /></Space></div>
                </div>
                <AgGrid height={"65vh"} data={databaseReduxState.data} columns={databaseStatusViewer.columns()} ContextMenuItems={databaseStatusViewer.contextMenuItems} />
            </div>
            {databaseReduxState.loader && <TransparentLoader />}
            {databaseReduxState.showViwerPopup && <ViewDBRecords show={databaseReduxState.showViwerPopup} />}
            {apiResponseState.show && <ApiResponse />}
        </div>
    )
}

export default DbBkpStatusViewer

const initialState = {
    serverType: { label: "All", value: "All" },
    serverName:  { label: "All", value: "All" },
    database:  { label: 'All Important Databases', value: 'All Important Databases' },
    type:  { label: "All", value: "All" },
    backupStatus: { label: "All", value: "All" },
    period: period[1],
    date: [],
    fromDate: "",
    toDate: ""
}
