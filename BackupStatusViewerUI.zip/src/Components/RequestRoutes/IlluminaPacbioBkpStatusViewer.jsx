import AgGrid from "../Grid/AgGrid"
import { IlluminaPacbioStatusViewer } from "../Grid/Columns"
import { period, strings, path, periodOptions } from '../Shared/Constant';
import { Row, Col } from 'antd'
import { useForm } from "react-hook-form";
import Dropdown from '../Element/Dropdown';
import { useEffect } from 'react';
import { illuminaPacbio_request } from "../Request";
import { useDispatch, useSelector } from 'react-redux';
import PrimaryButton from '../Element/PrimaryButton';
import TransparentLoader from "../loader/TransparentLoader";
import { illuminaPacbioActions } from "../redux/illuminaPacbioReducer";
import ApiResponse from "../Alert/ApiResponse";
import SubHeader from "../layouts/SubHeader"
import RangePickerElement from "../Element/RangePickerElement";
import dayjs from "dayjs";


function IlluminaPacbioBPKStatusViewer() {
  const dispatch = useDispatch();
  const illumina = useSelector(state => state.illumina);
  const { machineType, machineName } = illumina;
  const apiResponseState = useSelector(state => state.user.apiResponse);


  const { watch, setValue, reset, getValues, handleSubmit } = useForm({ defaultValues: initialValues });
  const onSubmit = async (data) => {
    let filterRecords = {};
    let fromDate = "";
    let toDate = ""
    await dispatch(illuminaPacbioActions.setLoader(true));

    if (data[strings.illuminaPacbio.date]) {
      fromDate = dayjs(data[strings.illuminaPacbio.date][0]).format("MM/DD/YYYY");
      toDate = dayjs(data[strings.illuminaPacbio.date][1]).format("MM/DD/YYYY");
    }

    if (strings.illuminaPacbio.machineName in data) {
      filterRecords = { ...filterRecords, machineName: data[strings.illuminaPacbio.machineName].label }
    }
    if (strings.illuminaPacbio.machineType in data) {
      filterRecords = { ...filterRecords, machineType: data[strings.illuminaPacbio.machineType].label }
    }
    if (strings.illuminaPacbio.date in data) {
      filterRecords = { ...filterRecords, fromDate: fromDate, toDate: toDate }
    }

    await dispatch(illuminaPacbio_request.getFilterRecords(filterRecords))
    dispatch(illuminaPacbioActions.setLoader(false));
  }

  const resetValues = async () => {
    reset();
    await handleDateformat(period[1]);
    await onSubmit(getValues());
  }

  useEffect(() => {
    const filterdata = async () => {
      document.title = "Illumina pacbio Backup Status Viewer"
      await dispatch(illuminaPacbioActions.setLoader(true));
      await handleDateformat(period[1]);
      await dispatch(illuminaPacbio_request.filterOptions());
      await onSubmit(getValues());
      dispatch(illuminaPacbioActions.setLoader(false));
      sessionStorage.setItem(strings.login.path, path.illuminaPacbio);
    }
    filterdata()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])


  const handleDateformat = (data) => {
    setValue(strings.illuminaPacbio.period, data)
    periodOptions(data.value, setValue)
  }
  const handleMachineName = () => {
    let machinetype = watch(strings.illuminaPacbio.machineType);
    let machinename = watch(strings.illuminaPacbio.machineName);

    if (machineName.length > 0 && Object.keys(machinetype).length > 0) {
      let resultdata = machineName.find((val) => val.values === machinetype.value)
      if (!(resultdata.machineNames.find((val) => val.value === machinename.value))) {
        setValue(strings.illuminaPacbio.machineName, resultdata.machineNames[0])
      }
      return resultdata ? resultdata.machineNames : []
    }
    return []

  }

  return (
    <div className='overflow-hidden w-100'>
      <SubHeader subHeader={"Illumina pacbio Backup Status Viewer"} />
      <div className='p-3 pt-0'>
          <Row gutter={[15, 15]} className='my-3 lg:w-3/4 md:w-full'>
            <Col className="gutter-row" lg={8} md={12} sm={12} xs={12}>
              <Dropdown placeholder={"Period"} value={watch(strings.illuminaPacbio.period)} onChange={(newvalue) => handleDateformat(newvalue)} options={period} />
            </Col>
            <Col className="gutter-row" lg={16} md={24} sm={24} xs={24} span={2} >
              <RangePickerElement placeholder={["From", "To"]} value={watch(strings.illuminaPacbio.date)} onChange={value => setValue(strings.illuminaPacbio.date, value)}  isDisable={watch(strings.illuminaPacbio.period) && watch(strings.illuminaPacbio.period).value === period[0].value ? false : true} />
            </Col>
            <Col className="gutter-row" lg={8} md={12} sm={12} xs={12}>
              <Dropdown placeholder={"Machine Type"} value={watch(strings.illuminaPacbio.machineType)} onChange={(newvalue) => setValue(strings.illuminaPacbio.machineType, newvalue)} options={machineType} />
            </Col>
            <Col className="gutter-row" lg={8} md={12} sm={12} xs={12}>
              <Dropdown placeholder={"Machine Name"} value={watch(strings.illuminaPacbio.machineName)} onChange={(newvalue) => setValue(strings.illuminaPacbio.machineName, newvalue)} options={handleMachineName()} />
            </Col>
            <Col className="gutter-row" lg={8} md={12} sm={12} xs={12}>
              <Row gutter={10} className='pt-5'>
                <Col className="gutter-row" xl={6} lg={12} md={12} sm={12} xs={12}>
                  <PrimaryButton onClick={handleSubmit(onSubmit)} type="primary" disable={!watch(strings.illuminaPacbio.date)} value={"Search"}></PrimaryButton>
                </Col>
                <Col className="gutter-row" xl={6} lg={12} md={12} sm={12} xs={12}>
                  <PrimaryButton onClick={resetValues} type="primary" value={"Reset"}></PrimaryButton>
                </Col>
              </Row>
            </Col>
          </Row>
      </div>
      <div className=" mx-5">
        <AgGrid height={"63vh"} data={illumina.data} columns={IlluminaPacbioStatusViewer.columns} />
      </div>
      {illumina.loader && <TransparentLoader />}
      {apiResponseState.show && <ApiResponse />}
    </div>
  )
}

export default IlluminaPacbioBPKStatusViewer


const initialValues = {
  period: period[1],
  fromDate: "",
  toDate: "",
  machineType: { label: "ALL", value: "ALL" },
  machineName: { label: "ALL", value: "ALL" },
  date: []
} 