import PrimaryButton from "../Element/PrimaryButton";
import { onLogout } from "../Helper";

function UnAuthorizedRoute() {
  
    return (
        <div>
            <div className="h-[75vh] flex justify-center items-center flex-col">
                <h2 className='flex text-darkGrey flex-col relative md:text-[2rem] font-QuattrocentoSans font-semibold text-center xsm:text-[18px] text-headerColor'> SORRY, YOUR REQUEST IS UNAUTHORIZED</h2>
                <div className=' text-lightGrey font-bold font-QuattrocentoSans md:text-2xl xsm:text-[16px] text-center'>{`PLEASE CLICK THE "LOGOUT" BUTTON BELOW TO TRY AGAIN.`}</div>
                <div className="error-actions bgColor mt-3">
                   <PrimaryButton value={"LOGOUT"} onClick={() => onLogout()} />
                </div>
            </div>
        </div>
    )
}

export default UnAuthorizedRoute;