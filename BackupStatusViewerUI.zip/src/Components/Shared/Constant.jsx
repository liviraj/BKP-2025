import dayjs from "dayjs";

export const period = [
  // { label: "ALL", value: 7 },
  { label: "Custom", value: 1 },
  { label: "Last 7 Days", value: 5 },
  { label: "Last 30 Days", value: 2 },
  { label: "Last 3 Months", value: 3 },
  { label: "Last 6 Months", value: 4 },
  { label: "This Year", value: 6 }
]


export const periodOptions = (value, setValue) => {
  let todate = dayjs()
  switch (value) {
    case 7:
      setValue("date", []);
      break;
    case 1:
      setValue("date", "");
      break;
    case 5:
      setValue("date", [dayjs().subtract(7, 'days'), todate]);
      break;
    case 2:
      setValue("date", [dayjs().subtract(30, "days"), todate]);
      break;
    case 3:
      setValue("date", [dayjs().subtract(3, "months"), todate]);
      break;
    case 4:
      setValue("date", [dayjs().subtract(6, "months"), todate]);
      break;
    case 6:
      setValue("date", [dayjs(`01/01/${dayjs().year()}`), todate]);
      break;
  }
}



// eslint-disable-next-line react-refresh/only-export-components
export const strings = {
  dbkStatusViewer: {
    serverType: "serverType",
    serverName: "serverName",
    database: "database",
    type: "type",
    backupStatus: "backupStatus",
    period: "period",
    fromDate: "fromDate",
    toDate: "toDate",
    date: "date"
  },
  login: {
    token: "BSV_A_T",
    name: "BSV_U_N",
    email: "BSV_U_E",
    path: "BSV_R_P"
  },
  illuminaPacbio:{
    period: "period",
    fromDate: "fromDate",
    toDate: "toDate",
    machineType:"machineType",
    machineName:"machineName",
    date: "date"
  }
}

export const classNames = {
  contextMenu: "text-headerColor border border-solid border-[#999] font-fontfamily text-12px font-bold bg-white z-10 tracking-wide rounded shadow-contextMenu shadow-boxShadow hover:rounded hover:border-white",
  contextMenuItem: "p-2 cursor-pointer hover:bg-headerColor hover:text-white hover:rounded tracking-widest",
  contextMenuValue: "h-full m-0 !pl-5 w-full",
  contextMenuDisable: " opacity-60 hover:!bg-white hover:!text-headerColor !cursor-text",
  grid:{
    gridCols2_And_text: "font-fontfamily font-bold text-14px grid grid-cols-1 md:grid-cols-1 sm:grid-cols-1 xsm:grid-cols-1",
    gridCols12: "grid grid-cols-12",
    gridSplitFirst_4Cols: "col-start-1 col-end-3 md:col-end-3 sm:col-end-6 xsm:col-end-6 break-all",
    gridSplitLast_7Cols: "col-start-3 col-end-13 md:col-start-3 sm:col-start-6 xsm:col-start-6"
  }
}

export const path = {
  dbBkp: "/db",
  illuminaPacbio: "/illuminaPacbio",
  unAuthorize: "/unAuthorize",
  home:"/"
}
