import axios from "axios";
import { userReducerState } from "../Helper";

const apiURL = import.meta.env.VITE_API_URL;

export const dbbkpStatusViewer_Services = {
    login: () => {
        return axios.get(`${apiURL}/dbStatusViewer/login`, getRequestOption());
    },
    filterOptions: () => {
        return axios.get(`${apiURL}/dbStatusViewer/filterValues`, getRequestOption());
    },
    filterRecords: (params) => {
        return axios.get(`${apiURL}/dbStatusViewer/filter${Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', '=') : ""}`, getRequestOption());
    }
}
export const illuminapacbioservice = {   
    filterValues : async() =>{
        return await axios.get(`${apiURL}/illuminaPacbioBackupStatus/filterValues`, getRequestOption());
    },
    filterRecords: (params) => {
        return axios.get(`${apiURL}/illuminaPacbioBackupStatus/filter${Object.keys(params).length > 0 ? "?" + Object.entries(params).join('&').replaceAll(',', '=') : ""}`, getRequestOption());
    }
}
const getRequestOption = () => {
    const token = userReducerState().token;
    const requestOptions = {
        method: "GET",
        headers: {
            Authorization: token,
            "Content-Type": "application/json",
            // 'Access-Control-Allow-Origin': '*',
        },
    };
    return requestOptions;
};

