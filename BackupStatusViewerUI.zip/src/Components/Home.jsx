import { ConfigProvider } from "antd"
import AllRoutes from "./Routes"
import ErrorBoundary from "antd/es/alert/ErrorBoundary"
import { IdleTimerProvider } from "react-idle-timer"
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { userActions } from "./redux/userReducer";
import Loader from "./loader/Loader";
import { strings } from "./Shared/Constant";
import { onLogout } from "./Helper";
import { dbBkpStatusViewer_request } from "./Request";
// import { dbBkpStatusViewer_request } from "./Request";

function Home() {
  const [time, setTime] = useState(1000 * 60 * 15);
  const [loader, setLoader] = useState(true);
  const dispatch = useDispatch();
  const setCallBack = async (isValidUser) => {
    if (isValidUser) {
        await dispatch(userActions.setUserDetails({ isLoggerIn: true }));
    }
    else {
        await dispatch(userActions.setUserDetails({ isLoggerIn: false }));
    }
}
  useEffect(() => {
    const userCredentials = async () => {
      document.title = "Backup Status Viewer"
      let token = sessionStorage.getItem(strings.login.token);
      let userName = sessionStorage.getItem(strings.login.name);
      let email = sessionStorage.getItem(strings.login.email);
      let routerPath = sessionStorage.getItem(strings.login.path);
      let userDetails = window.location.hash && window.location.hash.split('/?').length > 1 && decodeURIComponent(window.location.hash.split('/?')[1]).length >= 0 && Object.keys(JSON.parse(decodeURIComponent(window.location.hash.split('/?')[1]))).length > 0 && JSON.parse(decodeURIComponent(window.location.hash.split('/?')[1]));
      userDetails = Object.keys(userDetails).length > 0 ? { ...userDetails, path: window.location.hash.split('/?')[0].replaceAll("#","") } : token ? { token: decodeURIComponent(token), Name: userName, Email: email, path: routerPath } : {};
      if (userDetails && Object.keys(userDetails).length > 0) {
        await dispatch(userActions.setUserDetails({ ...userDetails }));
        sessionStorage.setItem(strings.login.token, encodeURIComponent(userDetails.token));
        sessionStorage.setItem(strings.login.name, userDetails.Name);
        sessionStorage.setItem(strings.login.email, userDetails.Email);
        sessionStorage.setItem(strings.login.path, userDetails.path);
        await dispatch(dbBkpStatusViewer_request.login(setCallBack));
        window.history.replaceState("", document.title, "#/");
        setLoader(false);
      }
      else{
        await dispatch(userActions.setUserDetails({ isLoggerIn: false}));
        setLoader(false);
      }
    };
    userCredentials();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onIdle = async () => {
    await onLogout();
  }

  const onAction = () => {
    setTime(1000 * 60 * 15);
  }

  const config = {
    token: {
      colorPrimary: "#ef4641",
      // colorPrimaryBg: "#ef4641",
      // colorBgContainer:  "#ef4641",
      borderRadius: 4,
    },
  }
  
  return (
    <>
      <ErrorBoundary>
        <IdleTimerProvider timeout={time} onIdle={onIdle} onAction={onAction} >
          <ConfigProvider theme={config}>
            {loader ? <Loader /> : <AllRoutes />}
          </ConfigProvider>
        </IdleTimerProvider>
      </ErrorBoundary>
    </>
  )
}

export default Home