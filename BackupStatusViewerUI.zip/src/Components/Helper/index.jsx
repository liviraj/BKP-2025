import { store } from "../redux/store"
import { userActions } from "../redux/userReducer";
import { NodeEnv_URL } from "../layouts/Sidebar";
import dayjs from "dayjs";

export const userReducerState = () => {
    return store.getState().user;
}

export const databaseReducerState = () => {
    return store.getState().database;
}

export const dateFormat = (date) => {
    return date && !isNaN(new Date(date)) ? dayjs(date).format("MM/DD/YYYY") : ""
}
export const HourFormat = (date) => {
    return date && !isNaN(new Date(date)) ? dayjs(date).format("HH:mm:ss") : ""
}

export const onLogout = () => {
    window.location.replace(`${NodeEnv_URL().SS}logout`);
    store.dispatch(userActions.setUserDetails({ isLoggerIn: false }));
    sessionStorage.clear();
}

export const bgColorCode = (data) => {
    const isValidData = data.length > 0 ? data.replaceAll(" ", "").trim().toLowerCase() : false;
    if (!isValidData) {
        return ""
    }
    else if (isValidData === "success") {
        return "text-[#008000] tracking-wide";
    }
    else if (isValidData === "failure") {
        return "text-[#ff0000] tracking-wide";
    }
    else if (isValidData === "inprogress") {
        return "text-blue-600 tracking-wide"
    }
    return ""
}