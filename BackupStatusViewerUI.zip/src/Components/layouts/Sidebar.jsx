import { useState } from 'react';
import { Dock } from 'react-dock';
import { CgChevronRightO } from 'react-icons/cg';
import { BiChevronLeftCircle } from 'react-icons/bi';
import logo from '../../assets/Sidebar_img/S-logo.png';
import swab from '../../assets/Sidebar_img/Swab.png';
import wgs from '../../assets/Sidebar_img/whole-genome.png';
import im from '../../assets/Sidebar_img/Instrument.png';
import rm from '../../assets/Sidebar_img/Reagent1.png';
//import wfc from '../../assets/images/Work-flow.png';
import si from '../../assets/Sidebar_img/inventory.png';
import dashboard from '../../assets/Sidebar_img/Dashboard.png';
import shipmentTracking from '../../assets/Sidebar_img/ShipmentTracking.png';
import { userReducerState } from '../Helper';


function Sidebar() {
    const [isOpen, setIsOpen] = useState(false);
    const onRedirect = (name, path) => {
        if (name === "Software Suite") {
            window.location.replace(path);
        }
        else {
            window.location.replace(`${path}?${encodeURIComponent(JSON.stringify({ token: userReducerState().token, Name: userReducerState().Name, Email: userReducerState().Email }))}`);
        }
    }
    return (
        <>
           <div className={`${isOpen ? ' invisible opacity-0 sidebarHide' : ' visible opacity-20 hover:opacity-[1] sidebarVisible'} fixed h-screen z-30 bg-[#e3c5c57d] flex items-center min-w-[10px] border-[1px] border-solid border-transparent rounded-xl rounded-l-none shadow-[1px_1px_1px_#c8352e] mr-5`}><span className=' cursor-pointer' onClick={() => setIsOpen(!isOpen)}><CgChevronRightO className=' fixed left-[1px] text-white bg-[#ef4641] rounded-2xl text-[24px] stroke-1 z-50' /></span></div>
            <div className='hideOverflow'>
                <Dock position='left' fluid={false} size={51} duration={500} isVisible={isOpen} onVisibleChange={() => setIsOpen(!isOpen)}>
                    <div className='bg-HeaderColor bg-white border-r border-r-[#ef4641] border-solid h-full w-full flex'>
                        <ul className=' p-0'>
                            <li className=' list-none mt-6 mb-14'><span title={"Software Suite"} className='cursor-pointer' onClick={() => onRedirect("Software Suite", NodeEnv_URL().SS)} ><img src={logo} className=" h-[37px] flex justify-center items-center ml-[0.45rem] mr-2 my-[5px] text-white text-[30px] cursor-pointer" alt='#' /> </span></li>
                            {
                                link.map((val, idx) => <li key={idx} className=' list-none'>
                                    <span title={val.name} className='cursor-pointer' onClick={() => onRedirect(val.name, val.path)} > <img src={val.imageSrc} className=" h-[37px] flex justify-center items-center ml-[0.3rem] mr-2 mb-[5px] mt-6 text-white text-[30px]  cursor-pointer" alt='#' />  </span>
                                </li>)
                            }
                        </ul>
                        <div className='flex justify-center items-center absolute right-[11px] h-screen border-[1px] border-solid border-transparent rounded-[11px] rounded-l-none'><span className='cursor-pointer' onClick={() => setIsOpen(!isOpen)}><BiChevronLeftCircle className=' fixed text-white bg-[#ef4641] border-2 border-solid border-[#ef4641] rounded-2xl text-[26px] stroke-1 z-50' /></span></div>
                    </div>
                </Dock>
            </div>
        </>
    )
}

export default Sidebar;

export const NodeEnv_URL = () => {
    const NodeEnv = import.meta.env.VITE_API_STAGE_ENVIRONMENT;
    if (NodeEnv === "DEV") {
        const HistoTyperURL = 'http://localhost:3334'
        return {
            SS: "http://localhost:3333/#/",
            SOIM: "http://localhost:7777/#/",
            WGS: "http://localhost:2222/#/",
            SI: "http://localhost:5555/#/",
            MD: "http://localhost:6001/#/",
            STS: "http://localhost:3000/#/",
            IM: `${HistoTyperURL}/?instrumentMaintenance/`,
            RM: `${HistoTyperURL}/?reagent/`,
            WF: `${HistoTyperURL}/?workflowCheckin/`
        };
    } else if (NodeEnv === "UAT") {
        const HistoTyperURL = 'http://localhost:3334'
        return {
            SS: "https://histoasgqc01.histogenetics.com:9133/#/",
            SOIM: "https://histoasgqc01.histogenetics.com:7005/#/",
            WGS: "https://histoasgqc01.histogenetics.com:9700/#/",
            SI: "https://histoasgqc01.histogenetics.com:7002/#/",
            MD: "http://localhost:6001/#/",
            STS: "http://histoasgqc01:8040/#/",
            IM: `${HistoTyperURL}/?instrumentMaintenance/`,
            RM: `${HistoTyperURL}/?reagent/`,
            WF: `${HistoTyperURL}/?workflowCheckin/`
        };
    } else if (NodeEnv === "PROD") {
        const HistoTyperURL = 'https://histoas5.histogenetics.com:9150' 
        return {
            SS: "https://histoas5.histogenetics.com:9900/#/",
            SOIM: "https://histoas5.histogenetics.com:7105/#/",
            WGS: "https://histoas5.histogenetics.com:9810/#/",
            SI: "https://histoas5.histogenetics.com:7102/#/",
            MD: "https://histoas5.histogenetics.com:9196/#/",
            STS: "https://histoas5.histogenetics.com:9112/#/",
            IM: `${HistoTyperURL}/#/?instrumentMaintenance/`,
            RM: `${HistoTyperURL}/#/?reagent/`,
            WF: `${HistoTyperURL}/#/?workflowCheckin/`
        };
    }
}

const link = import.meta.env.VITE_API_STAGE_ENVIRONMENT === "UAT" ?
    [
        { name: "Swab Order Tracking System", path: NodeEnv_URL().SOIM, imageSrc: swab  },
        { name: "Whole Genome Sequencing", path: NodeEnv_URL().WGS, imageSrc: wgs },
        { name: "Software Inventory", path: NodeEnv_URL().SI, imageSrc: si },
        { name: "Shipment Tracking System", path: NodeEnv_URL().STS, imageSrc: shipmentTracking },
    ] :
    [
        { name: "Swab Order Tracking System", path: NodeEnv_URL().SOIM, imageSrc: swab  },
        { name: "Management Dashboard", path: NodeEnv_URL().MD, imageSrc: dashboard },
        { name: "Whole Genome Sequencing", path: NodeEnv_URL().WGS, imageSrc: wgs },
        { name: "Software Inventory", path: NodeEnv_URL().SI, imageSrc: si },
        { name: "Shipment Tracking System", path: NodeEnv_URL().STS, imageSrc: shipmentTracking },
        { name: "Instrument Maintenance", path: NodeEnv_URL().IM, imageSrc: im },
        { name: "Reagent Management", path: NodeEnv_URL().RM, imageSrc: rm },
        // { name: "Histo Workflow CheckIn", path: NodeEnv_URL().WF, imageSrc: wfc  },
    ];
