import { Divider } from "antd";
import PropTypes from "prop-types";

function SubHeader({ subHeader }) {
    return (
        <header className={`flex h-6vh min-h-11 md:h-6vh sm:h-9 xsm:h-9 w-full flex-col justify-end`}>
            <div className='text-headerColor font-fontfamily font-bold tracking-wide ml-3'>{subHeader}</div>
            <Divider className=" my-2 border border-headerColor" />
        </header>
    )
}

export default SubHeader

SubHeader.propTypes = {
    subHeader: PropTypes.string
}