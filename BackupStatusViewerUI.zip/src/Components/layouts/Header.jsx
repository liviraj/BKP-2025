import header from '../../assets/HistoLogo.png';
import bkpStatusViewer from '../../assets/Backup_Status_Viewer.png';
import { FaPowerOff } from 'react-icons/fa';
import { useSelector } from 'react-redux';
import { Outlet, useNavigate } from 'react-router-dom';
import { onLogout } from '../Helper';
import Sidebar from './Sidebar';
import { path, strings } from '../Shared/Constant';

function Header() {
    const userDetails = useSelector(state => state.user);
    const navigate = useNavigate();
    const onhandleNavigate = () => {
        sessionStorage.setItem(strings.login.path, path.home);
        navigate(path.home);
    }
    return (
        <>
            <Sidebar />
            <header className={`bg-headerColor flex min-h-11 h-7vh md:h-6vh xsm:h-14 items-center justify-between sticky top-0 z-20`}>
                <span className='ml-2 flex items-center' > <img src={header} className='h-10 md:h-8 xsm:h-7' alt='#' /><img src={bkpStatusViewer} className=' h-16 md:h-10 cursor-pointer md:flex xsm:hidden ml-3' onClick={() => onhandleNavigate()} alt='#' /></span>
                <div className='mr-4 flex'><span className='text-white text-lg md:text-16px sm:text-sm mr-2 xsm:text-xs'>{userDetails.Name && userDetails.Name.length > 0 ? `Welcome ${userDetails.Name}` : " "}</span><span className='cursor-pointer' onClick={() => onLogout()}><FaPowerOff className="md:text-2xl sm:text-xl xsm:text-lg text-white" /></span></div>
            </header>
            <Outlet />
        </>
    )
}

export default Header