import { configureStore } from '@reduxjs/toolkit';
import userReducer from './userReducer';
import illuminaPacbioReducer from './illuminaPacbioReducer';
import { composeWithDevTools } from 'redux-devtools-extension';
import  dbBkpStatusReducer from './dbBkpStatusReducer';

export const store = configureStore({
  reducer: {
    user: userReducer, 
    illumina: illuminaPacbioReducer,
    database: dbBkpStatusReducer
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false,
    })
}, composeWithDevTools());
