import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    data: [],
    loader: false,
    showViwerPopup:false,
    selectedRow:{},
    serverType: [],
    serverName: [],
    database: [],
    databaseType: [],
    backupStatus: []
};

export const dbBkpStatusReducer = createSlice(
    {
        name: "database",
        initialState: initialState,
        reducers: {
            setData: (state, action) => {
                state.data = action.payload;
            },
            setLoader: (state, action) => {
                state.loader = action.payload;
            },
            setViewerPopUp: (state, action) => {
                state.showViwerPopup = action.payload;
            },
            setSelectedRow: (state, action) => {
                state.selectedRow = action.payload;
            },
            setServerType: (state, action) => {
                state.serverType = action.payload;
            },
            setServerName: (state, action) => {
                state.serverName = action.payload;
            },
            setDatabase: (state, action) => {
                state.database = action.payload;
            },
            setDatabaseTypes: (state, action) => {
                state.databaseType = action.payload;
            },
            setBackupStatus: (state, action) => {
                state.backupStatus = action.payload;
            },
        }
    }
);

export const dbBkpStatusActions = dbBkpStatusReducer.actions;
export default dbBkpStatusReducer.reducer;