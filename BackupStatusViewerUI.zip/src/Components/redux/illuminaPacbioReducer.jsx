import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    data: [],
    machineType:[],
    machineName:[],
    loader: false,
};

export const illuminaPacbioReducer = createSlice(
    {
        name: "illumina",
        initialState: initialState,
        reducers: {
            setData: (state, action) => {
                state.data = action.payload;
            },
            setMachineType:(state,action) =>{
                state.machineType = action.payload
               
            },
            setMachineName:(state,action) =>{
                state.machineName = action.payload
     
            },
            setLoader: (state, action) => {
                state.loader = action.payload;
            },
        }
    }
);

export const illuminaPacbioActions = illuminaPacbioReducer.actions;
export default illuminaPacbioReducer.reducer;