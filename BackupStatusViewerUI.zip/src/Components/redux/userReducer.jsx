import { createSlice } from '@reduxjs/toolkit';


// eslint-disable-next-line react-refresh/only-export-components
const UserCredentials = {
    FName: "",
    LName: "",
    Name: "",
    Email: "",
    token: "",
    isLoggerIn: false,
    isAuthorized: false,
    path: "",
    apiResponse: { show: false, status: 200, header: "Message Box", message: "", isOptional: false },
    loader: false
  };

export const userReducer = createSlice({
    name: 'user',
    initialState: UserCredentials,
    reducers: {
        setUserDetails: (state, action) => {
           return state = { ...state, ...action.payload };
        },
        resetUserDetails: (state) => {
           return state = { ...state, ...UserCredentials};
        },
        setIsLoggedIn: (state, action) => {
            return state.isLoggerIn = action.payload;
        },
        apiResponse: (state, action) => {
            return void(state.apiResponse = action.payload);
        },
        setLoader: (state, action) => {
            return void(state.loader = action.payload);
        },
    },
});

export const userActions = userReducer.actions;

export default userReducer.reducer;