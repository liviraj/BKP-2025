import { ContextMenu, MenuItem, ContextMenuTrigger } from "react-contextmenu";
import { store } from "../redux/store";
import { classNames } from "../Shared/Constant";
import { dbBkpStatusActions } from "../redux/dbBkpStatusReducer";
import { HourFormat, bgColorCode, dateFormat } from "../Helper";
import { HiOutlineClipboardList } from 'react-icons/hi';

export const databaseStatusViewer = {
    columns: () => [
        {
            headerName: "S.No",
            field: "sno",
            // eslint-disable-next-line no-unused-vars
            comparator: (valueA, valueB, nodeA, nodeB, isDescending) => Number(nodeA.id) - Number(nodeB.id),
            cellRenderer: params => (<ContextMenuTrigger collect={(props) => props} rowData={params.data && params.data} id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
            lockPosition: 'left',
            // checkboxSelection: true,
            minWidth: 85,
            maxWidth: 85
        },
        {
            headerName: "Server Type",
            field: "serverType",
            minWidth: 80,
            maxWidth: 150,
            cellRenderer: params => SetContextMenuTrigger(params, false, false, false, false, {}, false, false),
        },
        {
            headerName: "Server Name",
            field: "dbServerName",
            minWidth: 80,
            maxWidth: 150,
            cellRenderer: params => SetContextMenuTrigger(params, false, false, false, false, {}, false, false),
        },
        {
            headerName: "Database Name",
            field: "databaseName",
            minWidth: 80,
            cellRenderer: params => SetContextMenuTrigger(params, false, false, false, false, {}, false, false),
        },
        {
            headerName: "Backup Type",
            field: "backupType",
            minWidth: 80,
            maxWidth: 150,
            cellRenderer: params => SetContextMenuTrigger(params, false, false, false, false, {}, false, false),
        },
        {
            headerName: "Scheduled Date",
            field: "scheduledDate",
            minWidth: 80,
            maxWidth: 150,
            cellRenderer: params => SetContextMenuTrigger(params, false, true, false, false, {}, false, false),
        },
        {
            headerName: "Scheduled Time",
            field: "time",
            minWidth: 80,
            maxWidth: 150,
            cellRenderer: params => SetContextMenuTrigger(params, false, false, false, false, {}, false, false),
        },
        {
            headerName: "Primary Site Backup Status",
            field: "primaryBackupStatus",
            minWidth: 80,
            maxWidth: 250,
            cellRenderer: params => SetContextMenuTrigger(params, false, false, false, false, {}, true, false),
        },
        {
            headerName: "Secondary Site Backup Status",
            field: "secondaryBackupStatus",
            minWidth: 80,
            maxWidth: 250,
            cellRenderer: params => SetContextMenuTrigger(params, false, false, false, false, {}, true, false),
        },
        {
            headerName: "API Run Date",
            field: "apiRunDateTime",
            minWidth: 80,
            cellRenderer: params => SetContextMenuTrigger(params, false, true, false, false, {}, false, false),
        },
        {
            headerName: "API Run Time",
            field: "apiRunDateTime",
            minWidth: 80,
            cellRenderer: params => SetContextMenuTrigger(params, false, false, false, false, {}, false, true),
        },
    ],
    contextMenuItems: ({ selectedRow }) => {
        return (<ContextMenu id="staff_contextmenu_id" hideOnLeave={true} preventHideOnResize={false} className={classNames.contextMenu}>
            <MenuItem
                data={{ menu: "view" }}
                className={classNames.contextMenuItem}
                onClick={async () => {
                    store.dispatch(dbBkpStatusActions.setViewerPopUp(true));
                    store.dispatch(dbBkpStatusActions.setSelectedRow(selectedRow));
                }}
            >
                <span className='flex items-center'> <HiOutlineClipboardList size={18} style={{ strokeWidth: "2.5px" }} />  <span className='mx-2'>View</span></span>
            </MenuItem>
        </ContextMenu>)
    },
}

export const IlluminaPacbioStatusViewer = {
    columns: [
        {
            headerName: "S.No",
            field: "sno",
            // eslint-disable-next-line no-unused-vars
            comparator: (valueA, valueB, nodeA, nodeB, isDescending) => Number(nodeA.id) - Number(nodeB.id),
            cellRenderer: params => (<ContextMenuTrigger collect={(props) => props} rowData={params.data && params.data} id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{Number(params.node.id) + 1}</div></ContextMenuTrigger>), //holdToDisplay={0}
            lockPosition: 'left',
            minWidth: 85,
            maxWidth: 85
        },
        {
            headerName: "Machine Type",
            field: "machineType",
            minWidth: 80,
            cellRenderer: params => SetContextMenuTrigger(params, false, false, false, false, {}, false, false),
        },
        {
            headerName: "Machine Name",
            field: "machineName",
            minWidth: 80,
            cellRenderer: params => SetContextMenuTrigger(params, false, false, false, false, {}, false, false),
        },
        {
            headerName: "Experiment Name/Job Name",
            field: "experimentName",
            minWidth: 80,
            cellRenderer: params => SetContextMenuTrigger(params, false, false, false, false, {}, false, false),
        },
        {
            headerName: "Experiment Date",
            field: "experimentDate",
            minWidth: 80,
            cellRenderer: params => SetContextMenuTrigger(params, false, true, false, false, {}, false, false),
        },
        {
            headerName: "Total Sample",
            field: "totalSamples",
            minWidth: 80,
            cellRenderer: params => SetContextMenuTrigger(params, false, false, false, false, {}, false, false),
        },
        {
            headerName: "Secondary Backup Available Sample",
            field: "secondaryBackupSamplesCount",
            minWidth: 80,
            cellRenderer: params => SetContextMenuTrigger(params, false, false, false, false, {}, false, false),
        }
    ]
}

const SetContextMenuTrigger = (params, isBoolean, isDateView, isSelectable, isDocumentView, onClick, isBgColor, isHourview) => {
    if (isBoolean) {
        return (<ContextMenuTrigger collect={(props) => props} rowData={params.data && params.data} id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{typeof (params.value) === "boolean" ? params.value ? <span className=" text-blue-600" >Active</span> : <span className=" text-red-500" >In Active</span> : <div className=' text-transparent w-96'>ContextMenu</div>}</div></ContextMenuTrigger>)
    }
    else if (isDocumentView) {
        return (<ContextMenuTrigger collect={(props) => props} rowData={params.data && params.data} id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{<span className=" text-blue-600 underline cursor-pointer" onClick={onClick}>View Document</span>}</div></ContextMenuTrigger>)
    }
    else if (!params.value && params.value !== 0) {
        return (<ContextMenuTrigger collect={(props) => props} rowData={params.data && params.data} id="staff_contextmenu_id"><div className=' text-transparent w-96'>ContextMenu</div></ContextMenuTrigger>)
    }
    else if (isDateView) {
        return (<ContextMenuTrigger collect={(props) => props} rowData={params.data && params.data} id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{dateFormat(params.value)}</div></ContextMenuTrigger>)
    }
    else if (isBgColor) {
        return (<ContextMenuTrigger collect={(props) => props} rowData={params.data && params.data} id="staff_contextmenu_id"><div className={`${classNames.contextMenuValue} ${params.value && params.value.length > 0 ? bgColorCode(params.value) : ""} tracking-wide !w-full`}>{params.value}</div></ContextMenuTrigger>)
    }
    else if (isHourview) {
        return (<ContextMenuTrigger collect={(props) => props} rowData={params.data && params.data} id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{HourFormat(params.value)}</div></ContextMenuTrigger>)
    }
    return (<ContextMenuTrigger collect={(props) => props} rowData={params.data && params.data} id="staff_contextmenu_id"><div className={classNames.contextMenuValue}>{isSelectable ? <span className=" text-blue-600 underline cursor-pointer" onClick={onClick}>{params.value}</span> : params.value}</div></ContextMenuTrigger>)
}