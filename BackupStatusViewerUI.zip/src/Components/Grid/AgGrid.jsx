import { useRef, useMemo, useEffect, useState, useCallback } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import PropTypes from "prop-types";

function AgGrid({ data, columns, ContextMenuItems, height }) {
  const gridRef = useRef();
  const [selectedRow, setSelectedRow] = useState({});
  const defaultColDef = useMemo(() => {
    return {
      sortable: true,
      resizable: true,
      width: 100,
      flex: 1,
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    setSelectedRow({});
  }, [data])

  const getRowStyle = params => {
    if (params.node.rowIndex % 2 === 0) {
      return { background: "#ffff" };
    }
    else {
      return { backgroundColor: '#ffff' }
    }
  };

  const onSelectionChanged = useCallback(() => {
    const selectedRows = gridRef.current.api.getSelectedRows();
    setSelectedRow(selectedRows && selectedRows.length > 0 ? { ...selectedRows[0] } : {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <div className="ag-theme-alpine" style={{ height, width: "100%" }} >
        {ContextMenuItems && selectedRow && Object.keys(selectedRow).length > 0 && <ContextMenuItems selectedRow={selectedRow} />}
        <AgGridReact
          rowData={data}
          animateRows={true}
          rowHeight={38}
          headerHeight={40}
          getRowStyle={getRowStyle}
          ref={gridRef}
          defaultColDef={defaultColDef}
          rowGroupPanelShow={'always'}
          suppressDragLeaveHidesColumns={true}
          tooltipShowDelay={0}
          tooltipHideDelay={6000}
          onSelectionChanged={onSelectionChanged}
          suppressRowHoverHighlight={true}
          suppressRowTransform={true}
          pivotPanelShow={'always'}
          localeText={{ dateFormatOoo: "DD MMM YYYY", noRowsToShow: "No Records Found!" }}
          rowSelection={"single"}
          columnDefs={columns ? columns : []}>
        </AgGridReact>
      </div>
    </>
  )
}

export default AgGrid

AgGrid.propTypes = {
    data: PropTypes.array,
    columns: PropTypes.array,
    ContextMenuItems: PropTypes.any,
    height: PropTypes.string
}