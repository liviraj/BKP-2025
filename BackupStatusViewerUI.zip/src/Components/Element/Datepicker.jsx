import { DatePicker } from 'antd'
import propTypes from "prop-types";
import dayjs from 'dayjs';

const Datepicker = ({ onChange, value, placeholder, isDisable, minDate, maxDate }) => {
    const dateFormat = 'MM/DD/YYYY';
    
    function disabledFromDate(current) {

        if(minDate && maxDate){
            return current && current < dayjs(new Date(minDate)).endOf('day') && current > dayjs(new Date(maxDate)).endOf('day')
        }
        else if(minDate){
            return current && current < dayjs(new Date(minDate)).startOf('day');
        }
        else if(maxDate){
            return current && current > dayjs(new Date(maxDate)).endOf('day');
        }
        return false;
    }

    return (
        <div className='border-b-2 border-grey'>
            <label className={`${value ? "opacity-90" : "opacity-0"} font-fontfamily text-13px tracking-wide font-bold text-darkCustomGrey  text-ellipsis overflow-hidden whitespace-nowrap block`}>{placeholder}</label>
            <DatePicker onChange={onChange}
                placeholder={placeholder}
                value={value ? dayjs(value) : null}
                disabledDate={disabledFromDate}
                className={` font-fontfamily text-13px w-full font-bold`}
                bordered={false}
                format={dateFormat}
                disabled={isDisable}
            />
        </div>

    );
};

export default Datepicker;
Datepicker.propTypes = {
    label: propTypes.string,
    onChange: propTypes.any,
    value: propTypes.any,
    placeholder: propTypes.string,
    isDisable: propTypes.bool,
    currentvalue: propTypes.any,
    minDate: propTypes.any,
    maxDate: propTypes.any
}
