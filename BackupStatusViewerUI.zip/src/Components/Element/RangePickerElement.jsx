import { DatePicker } from 'antd'
import propTypes from "prop-types";
import dayjs from 'dayjs';

const RangePickerElement = ({ onChange, value, placeholder, isDisable, minDate, maxDate }) => {
    const { RangePicker } = DatePicker;
    const dateFormat = 'MM/DD/YYYY';
    
    function disabledFromDate(current) {

        if(minDate && maxDate){
            return current && current < dayjs(new Date(minDate)).endOf('day') && current > dayjs(new Date(maxDate)).endOf('day')
        }
        else if(minDate){
            return current && current < dayjs(new Date(minDate)).startOf('day');
        }
        else if(maxDate){
            return current && current > dayjs(new Date(maxDate)).endOf('day');
        }
        return false;
    }

    return (
        <div className='border-b-2 border-grey'>
            <label className={`${"opacity-0"} font-fontfamily text-13px tracking-wide font-bold text-darkCustomGrey  text-ellipsis overflow-hidden whitespace-nowrap block`}>{placeholder}</label>
            <RangePicker onChange={onChange}
                placeholder={placeholder}
                value={value && value.length > 0 ? value : null}
                disabledDate={disabledFromDate}
                className={` font-fontfamily text-13px w-full font-bold`}
                bordered={false}
                format={dateFormat}
                disabled={isDisable}
            />
        </div>

    );
};

export default RangePickerElement;
RangePickerElement.propTypes = {
    label: propTypes.string,
    onChange: propTypes.any,
    value: propTypes.any,
    placeholder: propTypes.string,
    isDisable: propTypes.bool,
    currentvalue: propTypes.any,
    minDate: propTypes.any,
    maxDate: propTypes.any
}
