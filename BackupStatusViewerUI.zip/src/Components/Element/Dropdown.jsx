
import { Select } from 'antd';
import propTypes from "prop-types";

const Dropdown = ({ value, onChange, options, placeholder, isSearchable, isSortable }) => {

  return (
    <div className='border-b-2 border-grey'>
      <label htmlFor="" className={`${value ? "opacity-90" : "opacity-0"} font-fontfamily text-13px tracking-wide font-bold text-darkCustomGrey  text-ellipsis overflow-hidden whitespace-nowrap block`}>{placeholder}</label>
      <Select
        value={value}
        bordered={false}
        placeholder={placeholder}
        showSearch={isSearchable}
        className={` font-fontfamily w-full`}
        onChange={value => onChange(options.find(val => val.value === value))}
        options={options ? options : ""}
        filterSort={(optionA, optionB) => isSortable ? (optionA?.label ?? "").toLowerCase().localeCompare((optionB?.label ?? "").toLowerCase()) :  false}
      />
    </div>

  );
};

export default Dropdown;

Dropdown.propTypes = {
  label: propTypes.string,
  value: propTypes.any,
  onChange: propTypes.any,
  options: propTypes.array,
  placeholder: propTypes.string,
  isSearchable: propTypes.bool,
  isSortable: propTypes.bool
}
