import { Button } from 'antd';
import PropTypes from 'prop-types';

const PrimaryButton = ({ value, onClick, disable }) => {
    return (
        <Button onClick={onClick} type="primary" disabled={disable} className=" bg-headerColor font-fontfamily text-[16px] p-1 rounded-none w-full mx-3 h-[34px] tracking-wide" >{value} </Button>
    );
};

export default PrimaryButton;

PrimaryButton.propTypes = {
    value: PropTypes.string,
    onClick: PropTypes.func,
    disable: PropTypes.bool
}
