import React, { useState } from "react";
import ReactDOM from "react-dom";
import "react-responsive-modal/styles.css";
import { Modal } from "react-responsive-modal";
import { IoClose } from "react-icons/io5";
import { components } from "react-select";

const ModelBox = ({ Component, open, onClose, headerTitle }) => {

  return (
    <div>
      <Modal
        open={open}
        classNames={{ modal: "p-0 !m-0 overflow-hidden  w-auto !rounded-md" }}
        showCloseIcon={false}
        onClose={onClose}
        onEscKeyDown={onClose}
      >
        <div className=" bg-white rounded-md">
          <div className="flex font-fontfamily font-bold text-base rounded-t justify-between px-2 tracking-wider py-2 bg-headerColor text-white">
            <span className="tracking-widest">{headerTitle}</span>
            <span className=" cursor-pointer">
              <IoClose
                size={22}
                style={{ strokeWidth: "10px" }}
                onClick={onClose}
              />
            </span>
          </div>
          <div>{Component}</div>
        </div>
      </Modal>
    </div>
  );
};

export default ModelBox;
