import { dbbkpStatusViewer_Services,illuminapacbioservice as illuminapacbioservice } from "../Services";
import { dbBkpStatusActions } from "../redux/dbBkpStatusReducer";
import { illuminaPacbioActions } from "../redux/illuminaPacbioReducer";
import { userActions } from "../redux/userReducer";


// eslint-disable-next-line react-refresh/only-export-components
export const dbBkpStatusViewer_request = {
    login: (setCallBack) => {
        return async (dispatch) => {
            try {
                const res = await dbbkpStatusViewer_Services.login();
                if (res.status < 202) {
                    await setCallBack(true);
                }
                else {
                    await setCallBack(false);
                    console.error("Get Database Backup Status viewer Filter Data API Error Found", res);
                }
            } catch (error) {
                await setCallBack(false);
                await dispatch(errorHandling(error.response));
                console.error("Get Database Backup Status viewer Filter Data API Error Found", error);
            }
        }
    },
    filterOptions: () => {
        return async (dispatch) => {
            try {
                const res = await dbbkpStatusViewer_Services.filterOptions();
                if (res.status < 202) {
                    const filterOptions = res.data;
                    if("serverNames" in filterOptions){
                        await dispatch(dbBkpStatusActions.setServerName(filterOptions.serverNames.map(val => ({ label: val, value: val}))));
                    }
                    if("serverTypes" in filterOptions){
                        await dispatch(dbBkpStatusActions.setServerType(filterOptions.serverTypes.map(val => ({ label: val, value: val}))));
                    }
                    if("typeOfBackups" in filterOptions){
                        await dispatch(dbBkpStatusActions.setDatabaseTypes(filterOptions.typeOfBackups.map(val => ({ label: val, value: val}))));
                    }
                    if("secondaryBackupStatusList" in filterOptions){
                        await dispatch(dbBkpStatusActions.setBackupStatus(filterOptions.secondaryBackupStatusList.map(val => ({ label: val, value: val }))));
                    }
                    if("databaseNames" in filterOptions){
                        let databaseOptionTypes = filterOptions.databaseNames;
                        let allOptions = [];                        
                        for (let i = 0; i < databaseOptionTypes.length; i++) {
                            allOptions = [...allOptions, ...databaseOptionTypes[i].dataBaseNames];
                            databaseOptionTypes[i].dataBaseNames = databaseOptionTypes[i].dataBaseNames.map(val => ({ label: val, value: val}));
                        }
                        allOptions = [...new Set(allOptions)];
                        await dispatch(dbBkpStatusActions.setDatabase([{serverName: "ALL", dataBaseNames: allOptions.map(val => ({ label: val, value: val})) }, ...databaseOptionTypes]))
                    }
                }
                else {
                    await dispatch(errorHandling(res));
                    console.error("Get Database Backup Status viewer Filter API Error Found", res);
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Database Backup Status viewer Filter API Error Found", error);
            }
        }
    },
    getFilterRecords: (params) => {
        return async (dispatch) => {
            try {
                const res = await dbbkpStatusViewer_Services.filterRecords(params);
                if (res.status < 202) {
                   await dispatch(dbBkpStatusActions.setData(res.data))
                }
                else {
                    await dispatch(errorHandling(res));
                    console.error("Get Database Backup Status viewer Filter Data API Error Found", res);
                }
            } catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Database Backup Status viewer Filter Data API Error Found", error);
            }
        }
    }
}

const errorHandling = (params) => {
    let error = { ...params };
    return async (dispatch) => {
        if(error && error.status && error.status === 403){
            return dispatch(userActions.apiResponse({ show: true, status: 403, header: "Warning!", message: "Access Denied !! Please login again." }));
        }
        if (!error || !error.status || !error.status || !error.data) {
            return dispatch(userActions.apiResponse({ show: true, status: 99999, header: "Error!", message: "Internal Server Error" }));
        }

        const statusCode = error.status;
        let statusText = error.data;
        let isOptional = false;

        if (typeof (statusText) !== "string") {
            if ("message" in error.data) {
                statusText = error.data.message;
            } else {
                statusText = "Internal Server Error"
            }
        }
        
        switch (statusCode) {
            case 200:
                return dispatch(userActions.apiResponse({ show: true, status: statusCode, header: "Message ", message: statusText, isOptional }));
            case 204:
                return dispatch(userActions.apiResponse({ show: true, status: statusCode, header: "Warning!", message: "No Content", isOptional }));
            case 400:
                return dispatch(userActions.apiResponse({ show: true, status: statusCode, header: "Warning!", message: "Bad Request", isOptional }));
            case 401:
                return dispatch(userActions.apiResponse({ show: true, status: statusCode, header: "Warning!", message: "Your session has timed out. Please login again.", isOptional }));
            case 403:
                return dispatch(userActions.apiResponse({ show: true, status: statusCode, header: "Warning!", message: "Your session has timed out. Please login again.", isOptional }));
            case 404:
                return dispatch(userActions.apiResponse({ show: true, status: statusCode, header: "Error!", message: "Oops! Page Not Found", isOptional }));
            case 500:
                return dispatch(userActions.apiResponse({ show: true, status: statusCode, header: "Error!", message: "Internal Server Error", isOptional }));
            default:
                return dispatch(userActions.apiResponse({ show: true, status: statusCode, header: isOptional ? "Confirmation" : "Error!", message: statusText, isOptional }));
        }
    }
}

export const illuminaPacbio_request = { 
    filterOptions: () => {
        return async (dispatch) => {
            try {
                const res =await illuminapacbioservice.filterValues();
                let options = res.data;
                let machineType = [];
                let machineNames = [];
                for (let i=0 ;i< options.length ;i++){
                    machineType = [...machineType , {label:options[i]["machineType"],value:options[i]["machineType"]}]  
                    machineNames[i] = {values:options[i]["machineType"],machineNames:options[i]["machineNames"]}
                    machineNames[i].machineNames = machineNames[i].machineNames.map(val =>({label:val,value:val}) )  
                }
                dispatch(illuminaPacbioActions.setMachineName(machineNames))
                dispatch(illuminaPacbioActions.setMachineType(machineType))
            }
            catch (error) {
                await dispatch(errorHandling(error.response));
                console.error("Get Database Backup Status viewer Filter API Error Found", error);
            }
        }
} ,
getFilterRecords: (params) => {
    return async (dispatch) => {
        try {
            const res = await illuminapacbioservice.filterRecords(params);
            if (res.status < 202) {
               await dispatch(illuminaPacbioActions.setData(res.data))
            }
            else {
                await dispatch(errorHandling(res));
                console.error("Get Database Backup Status viewer Filter Data API Error Found", res);
            }
        } catch (error) {
            await dispatch(errorHandling(error.response));
            console.error("Get Database Backup Status viewer Filter Data API Error Found", error);
        }
    }
}
}