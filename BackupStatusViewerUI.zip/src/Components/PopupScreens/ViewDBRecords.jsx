import ModelBox from '../Element/ModelBox';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import { classNames } from '../Shared/Constant';
import { useDispatch } from 'react-redux';
import { dbBkpStatusActions } from '../redux/dbBkpStatusReducer';
import { useSelector } from 'react-redux';
import PrimaryButton from '../Element/PrimaryButton';
import PropTypes from 'prop-types'
import { Space } from 'antd';
import { bgColorCode, dateFormat } from '../Helper';

function ViewDBRecords({ show }) {
    const dispatch = useDispatch();
    const selectedRow = useSelector((state) => state.database.selectedRow)
    const onClose = () => {
        dispatch(dbBkpStatusActions.setViewerPopUp(false))
    };
    return (
        <div>
            <ModelBox Component={
                <div className=' w-fit lg:max-w-[80vw] md:max-w-screen-md md:w-screen xsm:w-screen m-4'>
                    <div >
                        <Accordion className='!m-0 !mb-1 !shadow-none !rounded-none' defaultExpanded={true}>
                            <AccordionSummary
                                aria-controls="panel1a-content"
                                id="panel1a-header"
                                className=' !border-0 !bg-lightGrey !text-black !font-fontfamily font-bold !h-10 !max-h-10 !min-h-[40px]'
                            >
                                DB Servers
                            </AccordionSummary>
                            <AccordionDetails className=' mt-1 mb-2'>
                                <div>
                                    <div className={classNames.grid.gridCols2_And_text}>
                                        <div className={classNames.grid.gridCols12}>
                                            {setCommonComponent("DB Server ID", ("serverId" in selectedRow) ? selectedRow.serverId : "")}
                                            {setCommonComponent("DB Server Name", ("dbServerName" in selectedRow) ? selectedRow.dbServerName : "")}
                                            {setCommonComponent("Type", ("serverType" in selectedRow) ? selectedRow.serverType : "")}
                                        </div>
                                    </div>
                                </div>
                            </AccordionDetails>
                        </Accordion>
                        <Accordion className='!m-0 !mb-1 !shadow-none !rounded-none' defaultExpanded={true}>
                            <AccordionSummary
                                aria-controls="panel1a-content"
                                id="panel1a-header"
                                className=' !border-0 !bg-lightGrey !text-black !font-fontfamily font-bold !h-10 !max-h-10 !min-h-[40px]'
                            >
                                Databases
                            </AccordionSummary>
                            <AccordionDetails className=' mt-1 mb-2'>
                                <div>
                                    <div className={classNames.grid.gridCols2_And_text}>
                                        <div className={classNames.grid.gridCols12}>
                                        {setCommonComponent("Database ID", ("databaseId" in selectedRow) ? selectedRow.databaseId : "")}
                                        {setCommonComponent("DB Server ID", ("serverId" in selectedRow) ? selectedRow.serverId : "")}
                                        {setCommonComponent("Database Name", ("databaseName" in selectedRow) ? selectedRow.databaseName : "")}
                                        </div>
                                    </div>
                                </div>
                            </AccordionDetails>
                        </Accordion>
                        <Accordion className='!m-0 !mb-1 !shadow-none !rounded-none' defaultExpanded={true}>
                            <AccordionSummary
                                aria-controls="panel1a-content"
                                id="panel1a-header"
                                className=' !border-0 !bg-lightGrey !text-black !font-fontfamily font-bold !h-10 !max-h-10  !min-h-[40px]'
                            >
                                DB Backup Schedule
                            </AccordionSummary>
                            <AccordionDetails className=' mt-1 mb-2 '>
                                <div>
                                    <div className={classNames.grid.gridCols2_And_text}>
                                        <div className={classNames.grid.gridCols12}>
                                            {setCommonComponent("DB Backup Schedule ID", ("dbBackupScheduleId" in selectedRow) ? selectedRow.dbBackupScheduleId : "")}
                                            {setCommonComponent("DB Server ID", ("serverId" in selectedRow) ? selectedRow.serverId : "")}
                                            {setCommonComponent("Database ID", ("databaseId" in selectedRow) ? selectedRow.databaseId : "")}
                                            {setCommonComponent("Date", ("date" in selectedRow) ? dateFormat(selectedRow.date) : "")}
                                            {setCommonComponent("Time", ("time" in selectedRow) ? selectedRow.time : "")}
                                            {setCommonComponent("Backup Type", ("backupType" in selectedRow) ? selectedRow.backupType : "")}
                                            {setCommonComponent("Primary Backup Status", ("primaryBackupStatus" in selectedRow) ? selectedRow.primaryBackupStatus : "", selectedRow && selectedRow.primaryBackupStatus.length > 0 && bgColorCode(selectedRow.primaryBackupStatus) )}
                                            {setCommonComponent("Backup File Name", ("backupFileName" in selectedRow) ? selectedRow.backupFileName : "")}
                                            {setCommonComponent("Secondary Backup Status", ("secondaryBackupStatus" in selectedRow) ? selectedRow.secondaryBackupStatus : "", selectedRow && selectedRow.secondaryBackupStatus.length > 0 && bgColorCode(selectedRow.secondaryBackupStatus))}
                                        </div>
                                    </div>
                                </div>
                            </AccordionDetails>
                        </Accordion>
                    </div>
                    <div className="justify-center flex flex-row gap-3 sm:flex-row mb-3" >
                        <Space>
                            <PrimaryButton value={'Close'} onClick={() => { onClose() }} />
                        </Space>
                    </div>
                </div>
            } headerTitle={'View'} open={show} onClose={() => { onClose() }} />
        </div>
    )
}

export default ViewDBRecords;

ViewDBRecords.propTypes = {
    show: PropTypes.bool,
}

const  setCommonComponent = (label, value, addStyles) => {
  return (
    <><span className={classNames.grid.gridSplitFirst_4Cols}>{label}</span> <span className={classNames.grid.gridSplitLast_7Cols}><span className=' flex'><span className='mx-2'>:</span> <span className={`break-all ${addStyles}`}>{value}</span></span></span></>
  )
}

setCommonComponent.propTypes = {
    label: PropTypes.string,
    value: PropTypes.any,
    addStyles: PropTypes.string
}

