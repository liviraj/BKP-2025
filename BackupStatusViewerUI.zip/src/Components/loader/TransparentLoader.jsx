import { RingLoader } from 'react-spinners';

function TransparentLoader() {
  return (
    <div className={` flex justify-center items-center absolute xsm:overflow-auto  top-0 bg-blurColor !w-full !h-full z-10`}> <RingLoader size={80} speedMultiplier={2.5} color="#ef4641" className={" loader"} /></div>
  )
}

export default TransparentLoader