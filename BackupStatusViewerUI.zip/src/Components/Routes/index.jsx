import { HashRouter, Navigate, Route, Routes } from "react-router-dom"
import Header from "../layouts/Header"
import DbBkpStatusViewer from "../RequestRoutes/DbBkpStatusViewer"
import IlluminaPacbioBkpStatusViewer from "../RequestRoutes/IlluminaPacbioBkpStatusViewer"
import UnAuthorizedRoute from "../RequestRoutes/UnAuthorizedRoute"
import HomePage from "../RequestRoutes/HomePage"
import { path, strings } from "../Shared/Constant"
import { useSelector } from "react-redux"


function AllRoutes() {
    const loginState = useSelector(state => state.user);
    let routerPath = sessionStorage.getItem(strings.login.path);
    return (
        <>
            <HashRouter>
                <Routes>
                    <Route element={<Header />}>
                        <Route index={true} path={path.home} element={loginState.isLoggerIn ? routerPath && routerPath.length > 0 && routerPath !== path.home ? <Navigate to={routerPath} /> : <HomePage /> : <Navigate to={path.unAuthorize} />} />
                        <Route path={path.dbBkp} element={loginState.isLoggerIn ? <DbBkpStatusViewer /> : <Navigate to={path.unAuthorize} />} />
                        <Route path={path.illuminaPacbio} element={loginState.isLoggerIn ? <IlluminaPacbioBkpStatusViewer /> : <Navigate to={path.unAuthorize} />} />
                        <Route path={path.unAuthorize} element={<UnAuthorizedRoute />} />
                    </Route>
                    <Route path={"*"} element={<Navigate to={path.unAuthorize} />} />
                </Routes>
            </HashRouter>
        </>
    )
}

export default AllRoutes