/** @type {import('tailwindcss').Config} */
// eslint-disable-next-line no-undef
const defaultTheme = require('tailwindcss/defaultTheme');
export default {
  content: ["./src/**/*.{js,jsx,ts,tsx}", '/index.html'],
  theme: {
    extend: {
      colors: {
        headerColor: "#ef4641",
        lightGrey: "#afacace3",
        darkCustomGrey: "#655f5f",
        grey:"#808080",
        blurColor: "#f5f5f594",
      },
      spacing: {
        "7vh": "7vh",
        "6vh": "6vh",
      },
      screens: {
        xsm: "0px"
      },
      fontFamily: {
        fontfamily: ['Nunito Sans', 'sans-serif'],
        QuattrocentoSans: ["Quattrocento Sans", 'sans-serif']
      },
      fontSize: {
        "12px": "12px",
        "13px": "13px",
        "14px": "14px",
      },
      minHeight: {
        ...defaultTheme.spacing,
      }
    },
  },
  plugins: [],
}

