package com.histo.gridion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GridIonMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
