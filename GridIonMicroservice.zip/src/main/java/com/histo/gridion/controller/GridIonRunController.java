package com.histo.gridion.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.histo.gridion.model.*;
import com.histo.gridion.proxcy.WholeGenomeSequencingProxy;
import com.histo.gridion.security.AuthorizationValidation;
import com.histo.gridion.service.GridIonRunService;
import com.histo.gridion.util.FilterUtil;
import io.swagger.v3.oas.annotations.Operation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static com.histo.gridion.model.GridIonStatusMaster.IN_PROGRESS;

@RestController
@RequestMapping("/gridIonRun")
public class GridIonRunController {
    private static final Logger LOGGER = LogManager.getLogger(GridIonRunController.class);

    private final GridIonRunService gridIonRunService;
    private final WholeGenomeSequencingProxy wholeGenomeSequencingProxy;
    private final AuthorizationValidation authorizationValidation;
    private GridIonResModel response;
    private MappingJacksonValue mappingJacksonValue;

    private static final String STATUS = "status";

    public GridIonRunController(GridIonRunService gridIonService, WholeGenomeSequencingProxy wholeGenomeSequencingProxy, AuthorizationValidation authorizationValidation) {
        this.gridIonRunService = gridIonService;
        this.wholeGenomeSequencingProxy = wholeGenomeSequencingProxy;
        this.authorizationValidation = authorizationValidation;
        this.response = new GridIonResModel();
    }

    @GetMapping
    @Operation(summary = "Fetch run by filters", description = "Retrieve all Grid ION run details based on filters")
    public ResponseEntity<Object> findAllGridIonRuns(@RequestHeader("Authorization") String token, @RequestParam Map<Object, Object> gridIonRunFilterParams) {
        ResponseEntity<Object> response = authorizationValidation.isAuthorize(token);
        if (response.getStatusCode() == HttpStatus.OK) {
            return gridIonRunService.findAllGridIonRuns(new ObjectMapper().convertValue(gridIonRunFilterParams, GridIonRunFilterRequest.class));
        }
        return response;
    }

    @PostMapping
    @Operation(summary = "Create Run", description = "Create Grid ION run details")
    public ResponseEntity<Object> createGridIonRun(@RequestHeader("Authorization") String token, @RequestBody GridIONRunCreateModel gridIONRunCreate) {
        ResponseEntity<Object> response = authorizationValidation.isAuthorize(token);
        if (response.getStatusCode() == HttpStatus.OK) {
            return gridIonRunService.createGridIonRun(gridIONRunCreate);
        }
        return response;
    }

    @PutMapping
    @Operation(summary = "Update GridION run", description = "Update grid ION run details")
    public ResponseEntity<Object> updateGridIonRun(@RequestHeader("Authorization") String token, @RequestBody GridIONRunUpdateModel gridIONRunUpdate) {
        ResponseEntity<Object> response = authorizationValidation.isAuthorize(token);
        if (response.getStatusCode() == HttpStatus.OK) {
            return gridIonRunService.updateGridIonRun(gridIONRunUpdate);
        }
        return response;
    }

    @PutMapping("/{gridIONStatusViewerId}/updateAnalysisStatus")
    @Operation(summary = "Update analysis status", description = "Update grid ION analysis status")
    public ResponseEntity<Object> updateAnalysisStatus(@PathVariable Integer gridIONStatusViewerId, @RequestBody UpdateAnalysisStatus analysisStatus) {
        return gridIonRunService.updateAnalysisStatus(gridIONStatusViewerId, analysisStatus);
    }

    @GetMapping("/runInfo")
    @Operation(summary = "Get run info based on analysis status", description = "Retrieve gridION run info")
    public ResponseEntity<Object> findRunInfoByStatusId() {
        return gridIonRunService.findRunInfoByStatusId();
    }

    @GetMapping("/findAllClientProjects")
    @Operation(summary = "Get all client projects", description = "Retrieve all client projects")
    public ResponseEntity<Object> findAllClientProjects(@RequestHeader("Authorization") String token) {
        ResponseEntity<Object> response = authorizationValidation.isAuthorize(token);
        if (response.getStatusCode() == HttpStatus.OK) {
            return wholeGenomeSequencingProxy.findAllClientProjects(token);
        }
        return response;
    }

    @PostMapping("/gridIonLocalTransferStatus")
    public ResponseEntity<String> updateLTSDetails(@RequestBody LocalTransferStatus statusData) {
        LOGGER.info("called API /gridIonLocalTransferStatus");
        if (statusData.getStatus() == IN_PROGRESS.getValue()) {
            gridIonRunService.updateLTSDetails(statusData); // update In progress status for LTS
        }
        ExecutorService checksumExecutor = Executors.newSingleThreadExecutor();
        checksumExecutor.submit(() -> {
            if (statusData.getStatus() == GridIonStatusMaster.COMPLETED.getValue()) {
                gridIonRunService.executeMd5Checksum(statusData);
            }
        });
        LOGGER.info("/wgsLocalTransferStatus completed");

        return new ResponseEntity<>("Success", HttpStatus.OK);

    }

    @PostMapping("/gridIonLog")
    public ResponseEntity<Object> insertGridIonLog(@RequestBody GridIonLogModel gridIonLogModel) {
        return gridIonRunService.insertGridIonLog(gridIonLogModel);
    }

    @PutMapping("/updateLocalTransferStatus")
    public ResponseEntity<Object> updateLocalTransferStatus(@RequestBody LocalTransferStatus localTransfer) {
        return gridIonRunService.updateLTSStatusAndSendEmail(localTransfer);
    }

    @PostMapping("/md5Checksum/details/{gridIonRunId}")
    public ResponseEntity<Object> saveWGSMD5ChecksumDetails(@PathVariable("gridIonRunId") Integer gridIonRunId, @RequestBody Map<String, String> md5ChecksumDetails) {
        return gridIonRunService.saveMd5ChecksumDetails(md5ChecksumDetails, gridIonRunId);
    }

    @GetMapping("/executeFileUploader/{gridIonStatusViewerId}")
    public ResponseEntity<Object> executeFileUploader(@PathVariable("gridIonStatusViewerId") Integer gridIonStatusViewerId) {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        LOGGER.info("called API /executeFileUploader/{wgsStatusViewerId}");
        executor.submit(() -> {
            gridIonRunService.callFileMover(gridIonStatusViewerId);
        });
        LOGGER.info("/executeFileUploader/{wgsStatusViewerId} completed");
        response.setStatus(true);
        response.setInformation(new InformationModel(new Date(), "Success", "Client transfer started successfully"));
        mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{"status", "information"});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @PutMapping("/gridIonClientTransferStatus")
    public ResponseEntity<String> gridIonClientTransferStatus(@RequestBody GridIonClientTransferStatus transferStatus) {
        LOGGER.info("called API /wgsClientTransferStatus");
        String transferStatusRes = gridIonRunService.updateGridIonClientTransferStatus(transferStatus).getBody();
        LOGGER.info("/wgsClientTransferStatus completed");
        return new ResponseEntity<>(transferStatusRes, HttpStatus.OK);
    }

    @PostMapping("/logDetail")
    public ResponseEntity<Object> insertLogDetail(@RequestBody LogDetailModel logDetail) {
        return gridIonRunService.insertLogDetail(logDetail);
    }

    @PostMapping("/reportToClient/emailInfo")
    public ResponseEntity<Object> reportToClientEmailInfo(@RequestBody ClientReportMaster clientReportMaster, @RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return gridIonRunService.reportToClientEmailInfo(clientReportMaster);
        }
        return responseEntity;
    }
    @PostMapping("/reportToClient/sendEmail")
    public ResponseEntity<Object> reportToClientSendEmail(@RequestBody GridIonEmailDetails emailDetails, @RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return gridIonRunService.reportToClientSendEmail(emailDetails);
        }
        return responseEntity;
    }

    @GetMapping("/reportToClient/downloadFile")
    public ResponseEntity<Object> downloadFileBypath(@RequestParam("path") String path, @RequestHeader("Authorization") String token) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return gridIonRunService.downloadFileByPath(path);
        }
        return responseEntity;
    }

    @PostMapping("/reportToClient/uploadFile")
    public ResponseEntity<Object> reportToClientUploadFile(@RequestParam("file") MultipartFile file, @RequestHeader("Authorization") String token, @RequestParam("uploadPath") String uploadPath) {
        ResponseEntity<Object> responseEntity = authorizationValidation.isAuthorize(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return gridIonRunService.reportToClientUploadFile(file, uploadPath);
        }
        return responseEntity;
    }
}
