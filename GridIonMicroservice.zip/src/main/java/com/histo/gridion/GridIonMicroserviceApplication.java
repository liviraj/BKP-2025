package com.histo.gridion;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
@OpenAPIDefinition(
        servers = {
                @Server(url = "https://webapiuat.histogenetics.com:8765/GridIon", description = "UAT Server API Gateway"),
                @Server(url = "https://webapiuat:8601/GridIon", description = "UAT Server native"),
                @Server(url = "http://localhost:8765/GridIon", description = "local Server"),
                @Server(url = "http://localhost:8601/GridIon", description = "local Native Server"),
                @Server(url = "https://javawebag01.histogenetics.com:8765/GridIon", description = "PROD Server API Gateway"),
                @Server(url = "https://javawebag01:8601/GridIon", description = "PROD Server Native"),
                @Server(url = "http://10.201.100.32:8766/GridIon", description = "Local IP API Gateway Server Native"),
                @Server(url = "http://10.201.100.32:8601/GridIon", description = "Local IP Server Native"),
                @Server(url = "http://10.201.100.32:8765/GridIon", description = "Local IP API Gateway Server Native"),
                @Server(url = "http://10.201.100.32:8600/GridIon", description = "Local IP Server Native"),
                @Server(url = "http://localhost:8765/GridIon", description = "Local IP API Gateway Server Native"),
                @Server(url = "http://localhost:8600/GridIon", description = "Local IP Server Native")
        }
)
public class GridIonMicroserviceApplication {

    public static void main(String[] args) {
        SpringApplication.run(GridIonMicroserviceApplication.class, args);
    }

}
