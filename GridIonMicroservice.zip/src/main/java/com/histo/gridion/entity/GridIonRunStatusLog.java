package com.histo.gridion.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "GridIonRunStatusLog")
@NoArgsConstructor
@Getter
@Setter
@ToString
public class GridIonRunStatusLog implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "AutoID")
    private Integer autoId;

    @Column(name = "GridIonRunID", nullable = false)
    private Integer gridIonRunId;

    @Column(name = "GridIonStatusViewerID", nullable = false)
    private Integer gridIonStatusViewerId;

    @Column(name = "LogInfo", columnDefinition = "varchar(max)")
    private String logInfo;

    @Column(name = "ProgramName", length = 500)
    private String programName;

    @Column(name = "LogDateTime")
    private Date logDateTime;

    @Column(name = "UserID")
    private Integer userId;
}

