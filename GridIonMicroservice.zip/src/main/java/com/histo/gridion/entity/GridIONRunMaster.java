package com.histo.gridion.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Entity
@Table(name = "GridIONRunMaster")
@NoArgsConstructor
@Getter
@Setter
@ToString
public class GridIONRunMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "GridIONRunId")
    private Integer gridIONRunId;

    @Column(name = "RunName", unique = true, length = 500)
    private String runName;

    @Column(name = "ClientProjectId")
    private Integer clientProjectId;

    @Column(name = "CreatedBy")
    private int createdBy;

    @Column(name = "CreatedOn")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdOn;

    @Column(name = "LastModifiedBy")
    private int lastModifiedBy;

    @Column(name = "LastModifiedDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @Column(name = "ModifiedCount")
    private int modifiedCount;
}
