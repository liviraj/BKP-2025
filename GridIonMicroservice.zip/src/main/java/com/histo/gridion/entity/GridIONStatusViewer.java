package com.histo.gridion.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Entity
@Table(name = "GridIONStatusViewer")
@NoArgsConstructor
@Getter
@Setter
@ToString
public class GridIONStatusViewer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "GridIONStatusViewerID")
    private Integer gridIONStatusViewerId;

    @ManyToOne
    @JoinColumn(name = "GridIONRunId")
    private GridIONRunMaster gridIONRunMaster;

    @Column(name = "RawDataPath", length = 1000)
    private String rawDataPath;

    @Column(name = "AnalysisDataPath", length = 1000)
    private String analysisDataPath;

    @Column(name = "SourcePath", length = 500)
    private String sourcePath;

    @Column(name = "DestinationUploadPath", length = 1000)
    private String destinationUploadPath;

    @Column(name = "AnalysisStatusID")
    private int analysisStatusId;

    @Column(name = "LocalTransferStatusID")
    private int localTransferStatusId;

    @Column(name = "TransferStatusID")
    private int transferStatusId;

    @Column(name = "ReportedStatus")
    private boolean reportedStatus;

    @Column(name = "LocalTransferCompletedTime")
    @Temporal(TemporalType.TIMESTAMP)
    private Date localTransferCompletedTime;

    @Column(name = "ClientTransferCompletedTime")
    @Temporal(TemporalType.TIMESTAMP)
    private Date clientTransferCompletedTime;

    @Column(name = "CellName", length = 100)
    private String cellName;

    @ManyToOne
    @JoinColumn(name = "GridIONDetailID")
    private GridIONSampleDetail gridIONSampleDetail;
}
