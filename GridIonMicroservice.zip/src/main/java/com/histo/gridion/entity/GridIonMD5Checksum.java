package com.histo.gridion.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Entity
@Table(name = "GridIonMD5Checksum")
@NoArgsConstructor
@Getter
@Setter
@ToString
public class GridIonMD5Checksum {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MD5ChecksumId")
    private Integer md5ChecksumId;

    @Column(name = "GridIonRunId")
    private Integer gridIonRunId;

    @Column(name = "Filename", length = 1000)
    private String filename;

    @Column(name = "MD5ChecksumValue", length = 255)
    private String md5ChecksumValue;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CreatedOn", nullable = false, updatable = false)
    private Date createdOn;
}

