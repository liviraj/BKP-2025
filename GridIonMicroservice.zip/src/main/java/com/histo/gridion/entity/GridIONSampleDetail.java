package com.histo.gridion.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "GridIONSampleDetail")
@NoArgsConstructor
@Getter
@Setter
@ToString
public class GridIONSampleDetail {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "GridIONDetailID")
    private Integer gridIONDetailId;

    @ManyToOne
    @JoinColumn(name = "GridIONRunId")
    private GridIONRunMaster gridIONRunMaster;

    @Column(name = "Sample", length = 100)
    private String sample;
}
