package com.histo.gridion.repository;

import com.histo.gridion.entity.GridIonRunStatusLog;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GridIonRunStatusLogRepository extends JpaRepository<GridIonRunStatusLog, Integer> {
}