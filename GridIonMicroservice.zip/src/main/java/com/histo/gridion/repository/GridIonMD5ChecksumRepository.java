package com.histo.gridion.repository;

import com.histo.gridion.entity.GridIonMD5Checksum;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GridIonMD5ChecksumRepository extends JpaRepository<GridIonMD5Checksum, Integer> {
}