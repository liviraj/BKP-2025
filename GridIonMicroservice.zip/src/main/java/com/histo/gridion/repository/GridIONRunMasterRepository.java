package com.histo.gridion.repository;

import com.histo.gridion.entity.GridIONRunMaster;
import com.histo.gridion.model.GridIonRunDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;

public interface GridIONRunMasterRepository extends JpaRepository<GridIONRunMaster, Integer> {
    GridIONRunMaster findByRunName(String runName);
    boolean existsByRunName(String runName);

    @Query(value = "{call FindAllGridIonRuns(?, ?, ?, ?, ?, ?)}", nativeQuery = true)
    List<GridIonRunDetail> findAllGridIonRuns(
            @Param("ClientProjectID") int clientProjectId,
            @Param("StartDate") Date startDate,
            @Param("EndDate") Date endDate,
            @Param("TransferStatusId") int transferStatusId,
            @Param("AnalysisStatusId") int analysisStatusId,
            @Param("LocalTransferStatusID") int localTransferStatusId);
}
