package com.histo.gridion.repository;

import com.histo.gridion.entity.GridIONSampleDetail;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface GridIONSampleDetailRepository extends JpaRepository<GridIONSampleDetail, Integer> {
    GridIONSampleDetail findByGridIONRunMaster_GridIONRunIdAndSample(Integer gridIONRunId, String sample);
    List<GridIONSampleDetail> findByGridIONRunMaster_GridIONRunId(Integer gridIONRunId);

}