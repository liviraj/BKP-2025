package com.histo.gridion.repository;

import com.histo.gridion.entity.GridIONSampleDetail;
import com.histo.gridion.entity.GridIONStatusViewer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface GridIONStatusViewerRepository extends JpaRepository<GridIONStatusViewer, Integer> {
    List<GridIONStatusViewer> findByGridIONRunMaster_GridIONRunId(Integer gridIONRunId);
    List<GridIONStatusViewer> findByAnalysisStatusIdAndLocalTransferStatusIdAndTransferStatusId(int analysisStatusId, int localTransferStatusId, int transferStatusId);
    GridIONStatusViewer findByGridIONRunMaster_GridIONRunIdAndCellName(Integer gridIONRunId, String cellName);
    GridIONStatusViewer findByGridIONSampleDetail_GridIONDetailId(Integer gridIONDetailId);
}