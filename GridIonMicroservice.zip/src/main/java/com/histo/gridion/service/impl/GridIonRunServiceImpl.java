package com.histo.gridion.service.impl;

import com.google.gson.Gson;
import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.share.DiskShare;
import com.histo.gridion.config.DiskShareConfig;
import com.histo.gridion.config.PropertyConfig;
import com.histo.gridion.entity.GridIONRunMaster;
import com.histo.gridion.entity.GridIONSampleDetail;
import com.histo.gridion.entity.GridIONStatusViewer;
import com.histo.gridion.entity.GridIonRunStatusLog;
import com.histo.gridion.model.*;
import com.histo.gridion.repository.GridIONRunMasterRepository;
import com.histo.gridion.repository.GridIONSampleDetailRepository;
import com.histo.gridion.repository.GridIONStatusViewerRepository;
import com.histo.gridion.repository.GridIonRunStatusLogRepository;
import com.histo.gridion.service.GridIonRunService;
import com.histo.gridion.util.FilterUtil;
import com.histo.gridion.util.GridIonConstants;
import com.histo.gridion.util.GridIonUtil;
import jakarta.transaction.Transactional;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.math.BigInteger;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

@Service
@Transactional
public class GridIonRunServiceImpl implements GridIonRunService {
    private static final Logger LOGGER = LogManager.getLogger(GridIonRunServiceImpl.class);

    @Autowired
    private GridIONRunMasterRepository gridIONRunMasterRepository;
    @Autowired
    private GridIONStatusViewerRepository gridIONStatusViewerRepository;
    @Autowired
    private GridIONSampleDetailRepository gridIONSampleDetailRepository;
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private PropertyConfig propertyConfig;
    @Autowired
    private GridIonRunStatusLogRepository gridIonRunStatusLogRepository;
    @Autowired
    private RestTemplate restTemplate;

    private GridIonResModel response;
    private MappingJacksonValue mappingJacksonValue;
    private static final String STATUS = "status";
    private static final String INFORMATION = "information";
    private static final String CREDENTIALJSON = "CredentialJson";
    private static final String GLOBUS = "GLOBUS";
    private static final String SUCCESS = "Success";


    private static Integer GRIDION_REPORT_TO_CLIENT_UNIQUE_ID;
    private static Integer USER_ID;
    private static List<GridIonClientReport> GRIDION_CLIENT_REPORTS;

    public GridIonRunServiceImpl() {
        this.response = new GridIonResModel();
    }

    @Override
    public ResponseEntity<Object> findAllGridIonRuns(GridIonRunFilterRequest filterRequest) {
        try {
            List<GridIonRunDetail> gridIonRuns = jdbcTemplate.query("EXEC FindAllGridIonRuns ?, ?, ?, ?, ?, ?;"
                    , BeanPropertyRowMapper.newInstance(GridIonRunDetail.class)
                    , filterRequest.getClientProjectId()
                    , new SimpleDateFormat("yyyy-MM-dd").parse(filterRequest.getStartDate())
                    , new SimpleDateFormat("yyyy-MM-dd").parse(filterRequest.getEndDate())
                    , filterRequest.getTransferStatusId()
                    , filterRequest.getAnalysisStatusId()
                    , filterRequest.getLocalTransferId());
            for (GridIonRunDetail gridIonRun : gridIonRuns) {
                GridIONSampleDetail sampleDetail = gridIONSampleDetailRepository.findById(gridIonRun.getGridIONDetailId()).get();
                List<SampleDetail> sampleDetailsModels = new ArrayList<>();

                    SampleDetail sampleDetailModel = new SampleDetail();
                    sampleDetailModel.setGridIONDetailId(sampleDetail.getGridIONDetailId());
                    sampleDetailModel.setSample(sampleDetail.getSample());
                    sampleDetailModel.setCellName(gridIonRun.getCellName());

                    sampleDetailsModels.add(sampleDetailModel);
                gridIonRuns.get(gridIonRuns.indexOf(gridIonRun)).setSampleDetails(sampleDetailsModels);
            }

            response.setStatus(true);
            response.setData(gridIonRuns);
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "data"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException("findAllGridIonRuns()", e);
        }
    }

    @Override
    public ResponseEntity<Object> createGridIonRun(GridIONRunCreateModel gridIONRunCreate) {

        try {
            GridIONRunMaster gridIonRun = gridIONRunMasterRepository.findByRunName(gridIONRunCreate.getRunName());
            boolean isCellNameExist = false;
            List<String> existCellName = null;
            if (gridIonRun != null) {
                for (Map.Entry<String, String> sampleAndCellName:gridIONRunCreate.getSamplesAndCellName().entrySet()) {
                    GridIONStatusViewer gridIonStatusViewer = gridIONStatusViewerRepository
                            .findByGridIONRunMaster_GridIONRunIdAndCellName(gridIonRun.getGridIONRunId(), sampleAndCellName.getKey());
                    if (gridIonStatusViewer != null) {
                        isCellNameExist = true;
                        if (existCellName == null) {
                            existCellName = new ArrayList<>();
                        }
                        existCellName.add(gridIonStatusViewer.getCellName());
                    }
                }
            }
            if (gridIonRun != null && isCellNameExist) {
                return responseFalseValidation("Already Exist", "Given run already exist. Exist cell name/names: " + String.join(",", existCellName));
            }

            GridIONRunMaster saveGridIonRun;
            if (gridIonRun == null) {
                GridIONRunMaster gridIONRunMaster = new GridIONRunMaster();
                gridIONRunMaster.setRunName(gridIONRunCreate.getRunName());
                gridIONRunMaster.setCreatedBy(gridIONRunCreate.getCreatedBy());
                gridIONRunMaster.setClientProjectId(gridIONRunCreate.getClientProjectId());
                gridIONRunMaster.setModifiedCount(0);
                gridIONRunMaster.setCreatedOn(new Date());

                saveGridIonRun = gridIONRunMasterRepository.save(gridIONRunMaster);
            } else {
                saveGridIonRun = gridIonRun;
            }

            for (Map.Entry<String, String> sampleAndCellName : gridIONRunCreate.getSamplesAndCellName().entrySet()) {
                if (StringUtils.isBlank(sampleAndCellName.getKey()) || StringUtils.isBlank(sampleAndCellName.getValue())) {
                    continue;
                }
                GridIONSampleDetail sampleDetailCheck = gridIONSampleDetailRepository
                        .findByGridIONRunMaster_GridIONRunIdAndSample(saveGridIonRun.getGridIONRunId(), sampleAndCellName.getValue());
                GridIONSampleDetail gridIONSampleDetail = new GridIONSampleDetail();
                if (sampleDetailCheck == null) {
                    gridIONSampleDetail.setSample(sampleAndCellName.getValue());
                    gridIONSampleDetail.setGridIONRunMaster(saveGridIonRun);

                    gridIONSampleDetail = gridIONSampleDetailRepository.save(gridIONSampleDetail);
                } else {
                    gridIONSampleDetail = sampleDetailCheck;
                }

                GridIONStatusViewer gridIONStatusViewer = new GridIONStatusViewer();
                gridIONStatusViewer.setGridIONRunMaster(saveGridIonRun);
                gridIONStatusViewer.setAnalysisStatusId(GridIonStatusMaster.NOT_STARTED.getValue());
                gridIONStatusViewer.setLocalTransferStatusId(GridIonStatusMaster.NOT_STARTED.getValue());
                gridIONStatusViewer.setTransferStatusId(GridIonStatusMaster.NOT_STARTED.getValue());
                gridIONStatusViewer.setReportedStatus(ReportStatus.NOT_SEND.isValue());
                gridIONStatusViewer.setRawDataPath(gridIONRunCreate.getDataPath());
                gridIONStatusViewer.setCellName(sampleAndCellName.getKey());
                gridIONStatusViewer.setGridIONSampleDetail(gridIONSampleDetail);

                gridIONStatusViewerRepository.save(gridIONStatusViewer);

            }

            jdbcTemplate.queryForObject("exec GridIonRunCreationMail ?;", String.class, saveGridIonRun.getGridIONRunId());

            response.setStatus(true);
            response.setInformation(new InformationModel(new Date(), SUCCESS, "Run created successfully"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, INFORMATION});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException("createGridIonRun()", e);
        }
    }

    @Override
    public ResponseEntity<Object> updateGridIonRun(GridIONRunUpdateModel gridIONRunUpdate) {
        try {
            Optional<GridIONRunMaster> gridIONRunMaster = gridIONRunMasterRepository.findById(gridIONRunUpdate.getGridIonRunId());
            if (!gridIONRunMaster.isPresent()) {
                return responseFalseValidation("Not Found", "Given run not found");
            }

            GridIONRunMaster checkRunExist = gridIONRunMasterRepository.findByRunName(gridIONRunUpdate.getRunName());
            if (checkRunExist != null && !Objects.equals(gridIONRunMaster.get().getGridIONRunId(), checkRunExist.getGridIONRunId())) {
                return responseFalseValidation("Already Exist", "Given run already exist");
            }

            gridIONRunMaster.get().setRunName(gridIONRunUpdate.getRunName());
            gridIONRunMaster.get().setModifiedCount(gridIONRunMaster.get().getModifiedCount() + 1);
            gridIONRunMaster.get().setLastModifiedBy(gridIONRunUpdate.getModifiedBy());
            gridIONRunMaster.get().setLastModifiedDate(new Date());

            gridIONRunMasterRepository.save(gridIONRunMaster.get());

            List<GridIONStatusViewer> statusViewer = gridIONStatusViewerRepository.findByGridIONRunMaster_GridIONRunId(gridIONRunMaster.get().getGridIONRunId());
            statusViewer.forEach(viewer -> viewer.setRawDataPath(gridIONRunUpdate.getDataPath()));
            gridIONStatusViewerRepository.saveAll(statusViewer);

            for (SampleDetail sample : gridIONRunUpdate.getSamples()) {
                if (StringUtils.isBlank(sample.getSample())) {
                    continue;
                }
                GridIONSampleDetail gridIONSampleDetail = new GridIONSampleDetail();

                GridIONStatusViewer sampleUpdateCheck = gridIONStatusViewerRepository
                        .findByGridIONRunMaster_GridIONRunIdAndCellName(gridIONRunMaster.get().getGridIONRunId(), sample.getCellName());
                if (sample.getGridIONDetailId() == 0) {
                    if (sampleUpdateCheck != null) {
                        LOGGER.error("Already Exist", "Given CellName already exist. CellName Id: {}", sample.getCellName());
                        continue;
                    }
                    GridIONSampleDetail sampleDetailsBySampleName = gridIONSampleDetailRepository
                            .findByGridIONRunMaster_GridIONRunIdAndSample(gridIONRunMaster.get().getGridIONRunId(), sample.getSample());
                    if (sampleDetailsBySampleName == null) {
                        gridIONSampleDetail.setSample(sample.getSample());
                        gridIONSampleDetail.setGridIONRunMaster(gridIONRunMaster.get());
                        gridIONSampleDetail = gridIONSampleDetailRepository.save(gridIONSampleDetail);
                    } else {
                        gridIONSampleDetail = sampleDetailsBySampleName;
                    }

                    GridIONStatusViewer gridIONStatusViewer = new GridIONStatusViewer();
                    gridIONStatusViewer.setGridIONRunMaster(gridIONRunMaster.get());
                    gridIONStatusViewer.setAnalysisStatusId(GridIonStatusMaster.NOT_STARTED.getValue());
                    gridIONStatusViewer.setLocalTransferStatusId(GridIonStatusMaster.NOT_STARTED.getValue());
                    gridIONStatusViewer.setTransferStatusId(GridIonStatusMaster.NOT_STARTED.getValue());
                    gridIONStatusViewer.setReportedStatus(ReportStatus.NOT_SEND.isValue());
                    gridIONStatusViewer.setRawDataPath(gridIONRunUpdate.getDataPath());
                    gridIONStatusViewer.setCellName(sample.getCellName());
                    gridIONStatusViewer.setGridIONSampleDetail(gridIONSampleDetail);

                    gridIONStatusViewerRepository.save(gridIONStatusViewer);


                } else {
                    if (sampleUpdateCheck != null && !sampleUpdateCheck.getGridIONStatusViewerId().equals(sample.getGridIONStatusViewerId())) {
                        LOGGER.error("Already Exist", "Given CellName already exist. CellName Id: {}", sample.getCellName());
                        continue;
                    }
                    if (sampleUpdateCheck == null && sample.getGridIONDetailId() != null && sample.getGridIONDetailId() != 0) {
                        sampleUpdateCheck = gridIONStatusViewerRepository.findByGridIONSampleDetail_GridIONDetailId(sample.getGridIONDetailId());
                    }
                    gridIONSampleDetail.setGridIONDetailId(sample.getGridIONDetailId());
                    gridIONSampleDetail.setSample(sample.getSample());
                    gridIONSampleDetail.setGridIONRunMaster(gridIONRunMaster.get());
                    gridIONSampleDetail = gridIONSampleDetailRepository.save(gridIONSampleDetail);

                    assert sampleUpdateCheck != null;
                    sampleUpdateCheck.setCellName(sample.getCellName());
                    sampleUpdateCheck.setGridIONSampleDetail(gridIONSampleDetail);
                    gridIONStatusViewerRepository.save(sampleUpdateCheck);

                }
            }
            response.setStatus(true);
            response.setInformation(new InformationModel(new Date(), SUCCESS, "Run updated successfully"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, INFORMATION});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException("updateGridIonRun()", e);
        }
    }

    @Override
    public ResponseEntity<Object> updateAnalysisStatus(Integer gridIONStatusViewerId, UpdateAnalysisStatus analysisStatus) {
        try {
            Optional<GridIONStatusViewer> gridIONStatusViewer = gridIONStatusViewerRepository.findById(gridIONStatusViewerId);
            if (gridIONStatusViewer.isEmpty()) {
                return responseFalseValidation("Not Found", "Given run not found");
            }
            gridIONStatusViewer.get().setAnalysisStatusId(analysisStatus.getStatusId());
            gridIONStatusViewer.get().getGridIONRunMaster().setLastModifiedDate(new Date());
            gridIONStatusViewer.get().getGridIONRunMaster().setModifiedCount(gridIONStatusViewer.get().getGridIONRunMaster().getModifiedCount() + 1);
            gridIONStatusViewer.get().setAnalysisDataPath(analysisStatus.getAnalysisDataPath());
            gridIONStatusViewerRepository.save(gridIONStatusViewer.get());

            if (Objects.equals(analysisStatus.getStatusId(), GridIonStatusMaster.COMPLETED.getValue())
                    && gridIONStatusViewer.get().getAnalysisStatusId() == GridIonStatusMaster.COMPLETED.getValue()) {
                HashMap<String, String> attributesValues = getAttributesValues(gridIONStatusViewer.get().getGridIONStatusViewerId());
                if (!propertyConfig.getLocalCopyDestinationPath().endsWith("/")) {
                    propertyConfig.setLocalCopyDestinationPath(propertyConfig.getLocalCopyDestinationPath().concat("/"));
                }
                String localDestinationPath = propertyConfig.getLocalCopyDestinationPath().replace("?", attributesValues == null ? "" : attributesValues.get("ClientName"));

                LocalCopyDetails localCopyDetails = new LocalCopyDetails();
                localCopyDetails.setGridIonRunId(gridIONStatusViewer.get().getGridIONRunMaster().getGridIONRunId());
                localCopyDetails.setRunName(gridIONStatusViewer.get().getGridIONRunMaster().getRunName());
                localCopyDetails.setGridIonStatusViewerId(gridIONStatusViewer.get().getGridIONStatusViewerId());
                localCopyDetails.setSourcePath(gridIONStatusViewer.get().getAnalysisDataPath()
                        .concat(gridIONStatusViewer.get().getCellName().concat("/"))
                );
                localCopyDetails.setDesPath(localDestinationPath
                        .concat(gridIONStatusViewer.get().getCellName().concat("/"))
                );

                ExecutorService executor = Executors.newSingleThreadExecutor();
                executor.submit(() -> {
                    ScheduledExecutorService scheduledExecutorService = Executors.newScheduledThreadPool(5);
                    ScheduledFuture<?> scheduledFuture =
                            scheduledExecutorService.schedule(() -> localCopyProcess(localCopyDetails), 5, // 5 seconds to wait
                                    TimeUnit.SECONDS);
                    scheduledExecutorService.shutdown();
                });
                executor.shutdown();
            }

            response.setStatus(true);
            response.setInformation(new InformationModel(new Date(), SUCCESS, "Analysis status update successfully"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, INFORMATION});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException("updateAnalysisStatus()", e);
        }
    }

    @Override
    public ResponseEntity<Object> findRunInfoByStatusId() {
        try {
            List<GridIONStatusViewer> gridIonRunInfoList = gridIONStatusViewerRepository.findByAnalysisStatusIdAndLocalTransferStatusIdAndTransferStatusId(1
                    , GridIonStatusMaster.NOT_STARTED.getValue(), GridIonStatusMaster.NOT_STARTED.getValue());
            // Group by GridIONRunMaster
            Map<GridIONRunMaster, List<GridIONStatusViewer>> groupedByRunMaster = gridIonRunInfoList.stream()
                    .collect(Collectors.groupingBy(GridIONStatusViewer::getGridIONRunMaster));
            List<GridIonRunInfo> gridIonRunInfos = new ArrayList<>();
            for (Map.Entry<GridIONRunMaster, List<GridIONStatusViewer>> runInfo : groupedByRunMaster.entrySet()) {

                GridIonRunInfo gridIonRunInfo = new GridIonRunInfo();
                GridIONStatusViewer statusViewerByRunId = gridIONStatusViewerRepository.findByGridIONRunMaster_GridIONRunId(runInfo.getKey().getGridIONRunId()).get(0);

                gridIonRunInfo.setGridIONRunId(runInfo.getKey().getGridIONRunId());
                gridIonRunInfo.setRunName(runInfo.getKey().getRunName());
                gridIonRunInfo.setDataPath(statusViewerByRunId.getRawDataPath());

                List<SampleDetail> sampleDetails = new ArrayList<>();
                for (GridIONStatusViewer gridIONStatusViewer : runInfo.getValue()) {
                    GridIONSampleDetail sampleDetailsByStatusViewer = gridIONSampleDetailRepository
                            .findByGridIONRunMaster_GridIONRunId(gridIONStatusViewer.getGridIONRunMaster().getGridIONRunId()).get(0);
                    SampleDetail sampleDetail = new SampleDetail();
                    sampleDetail.setGridIONDetailId(sampleDetailsByStatusViewer.getGridIONDetailId());
                    sampleDetail.setSample(sampleDetailsByStatusViewer.getSample());
                    sampleDetail.setCellName(gridIONStatusViewer.getCellName());
                    sampleDetail.setGridIONStatusViewerId(gridIONStatusViewer.getGridIONStatusViewerId());

                    sampleDetails.add(sampleDetail);
                }
                gridIonRunInfo.setSampleDetails(sampleDetails);

                gridIonRunInfos.add(gridIonRunInfo);
            }
            response.setStatus(true);
            response.setData(gridIonRunInfos);
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "data"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException("findRunInfoByStatusId()", e);
        }
    }

    @Override
    public ResponseEntity<Object> updateLTSDetails(LocalTransferStatus statusData) {
        try {
            Optional<GridIONStatusViewer> statusViewer = gridIONStatusViewerRepository.findById(statusData.getGridIonStatusViewerId());
            if (statusViewer.isEmpty()) {
                LOGGER.info("Given run not found. GridION status viewer ID: {}", statusData.getGridIonStatusViewerId());
                return responseFalseValidation("Not Found", "Given run not found");
            }

            statusViewer.get().setLocalTransferStatusId(statusData.getStatus());
            statusViewer.get().setSourcePath(statusData.getSourcePath());
            if (GridIonStatusMaster.COMPLETED.getValue() == statusData.getStatus()) {
                statusViewer.get().setLocalTransferCompletedTime(new Date());
            }
            gridIONStatusViewerRepository.save(statusViewer.get());
            return ResponseEntity.ok().body("Local Status Update Successfully");
        } catch (Exception e) {
            return catchException("updateLTSDetails()", e);
        }
    }

    @Override
    public ResponseEntity<Object> executeMd5Checksum(LocalTransferStatus statusData) {
        try {
            // update source path
            statusData.setStatus(GridIonStatusMaster.IN_PROGRESS.getValue());
            updateLTSDetails(statusData);


            Optional<GridIONStatusViewer> gridIonStatusViewer = gridIONStatusViewerRepository.findById(statusData.getGridIonStatusViewerId());
            if (gridIonStatusViewer.isEmpty()) {
                return new ResponseEntity<>("GridION run not found", HttpStatus.CONFLICT);
            }
            Integer gridIonRunMasterId = gridIonStatusViewer.get().getGridIONRunMaster().getGridIONRunId();

            if (StringUtils.isBlank(gridIonStatusViewer.get().getSourcePath())) {
                LOGGER.info("Source-path is empty. To process. To process MD5Checksum source path should not be null/empty. StatusViewerId={}"
                        , gridIonStatusViewer.get().getGridIONStatusViewerId());
                return new ResponseEntity<>("Source-path is empty. To process. To process MD5Checksum source path should not be null/empty", HttpStatus.CONFLICT);
            }

            Optional<GridIONRunMaster> runMaster = gridIONRunMasterRepository.findById(gridIonStatusViewer.get().getGridIONRunMaster().getGridIONRunId());
            if (runMaster.isEmpty()) {
                return new ResponseEntity<>("GridION run not found", HttpStatus.CONFLICT);
            }

            // Split server name and share name in source path;
            String checkSumPath = gridIonStatusViewer.get().getSourcePath().replace("\\", "/");
            List<String> checkSumSplit = Arrays.stream(checkSumPath.split("/"))
                    .filter(path -> !path.equalsIgnoreCase("")).toList();
            checkSumPath = checkSumPath.replace("//", "").replace(checkSumSplit.get(0) + "/", "").replace(checkSumSplit.get(1) + "/", "");


            MD5ChecksumInputArgs inputArgs = new MD5ChecksumInputArgs();
            inputArgs.setChecksumFilePath(URLEncoder.encode(checkSumPath, StandardCharsets.UTF_8.name()));
            inputArgs.setGridIonRunId(gridIonRunMasterId);
            inputArgs.setSmbServerName(checkSumSplit.get(0));
            inputArgs.setSmbShareName(checkSumSplit.get(1));
            inputArgs.setSmbUsername(propertyConfig.getLocalCopyDestUsername());
            inputArgs.setSmbPassword(propertyConfig.getLocalCopyDestPassword());
            inputArgs.setGridIonStatusViewerId(statusData.getGridIonStatusViewerId());
            inputArgs.setProgramType(String.valueOf(ProgramType.GRIDION));

            String inputArgsJson = new Gson().toJson(inputArgs);

            String command = "java -jar " + propertyConfig.getMd5ChecksumJarPath() + " " + inputArgsJson;
            LOGGER.info("MD5Checksum jar execute command -> {}", command);

            Process proc = Runtime.getRuntime().exec(command);

            // https://stackoverflow.com/questions/5483830/process-waitfor-never-returns
            BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            String line;
            LOGGER.info("Process Status :");
            while ((line = reader.readLine()) != null) {
                LOGGER.info(line);
            }
            proc.waitFor();

            return new ResponseEntity<>("MD5Checksum process done successfully", HttpStatus.OK);
        } catch (Exception e) {
            Thread.currentThread().interrupt();
            return catchException("executeMd5Checksum()", e);
        }
    }

    @Override
    public ResponseEntity<Object> insertGridIonLog(GridIonLogModel gridIonLog) {
        try {
            if (gridIonLog.getGridIonRunId() == 0) {
                Optional<GridIONStatusViewer> statusViewer = gridIONStatusViewerRepository.findById(gridIonLog.getGridIonStatusViewerId());
                if (statusViewer.isEmpty()) {
                    LOGGER.debug("insertGridIonLog(). Given GridIon Run Not Found. StatusViewerId: {}", gridIonLog.getGridIonStatusViewerId());
                    return new ResponseEntity<>("GridION Run Not Found", HttpStatus.NOT_FOUND);
                }
                gridIonLog.setGridIonRunId(statusViewer.get().getGridIONRunMaster().getGridIONRunId());
            }
            GridIonRunStatusLog gridIonRunStatusLog = new GridIonRunStatusLog();
            gridIonRunStatusLog.setGridIonRunId(gridIonLog.getGridIonRunId());
            gridIonRunStatusLog.setGridIonStatusViewerId(gridIonLog.getGridIonStatusViewerId());
            gridIonRunStatusLog.setLogInfo(gridIonLog.getLogInfo());
            gridIonRunStatusLog.setUserId(gridIonLog.getUserId());
            gridIonRunStatusLog.setProgramName(gridIonLog.getProgramName());
            gridIonRunStatusLog.setLogDateTime(new Date());

            gridIonRunStatusLogRepository.save(gridIonRunStatusLog);

            return ResponseEntity.ok().body("GridIon log saved successfully");
        } catch (Exception e) {
            return catchException("insertGridIonLog()", e);
        }
    }

    @Override
    public ResponseEntity<Object> updateLTSStatusAndSendEmail(LocalTransferStatus localTransfer) {
        try {
            if (localTransfer.getStatus() == 3 || localTransfer.getStatus() == 4) {
                gridIonFileTransferStatusMail(localTransfer.getGridIonStatusViewerId(), "Local Transfer", localTransfer.getStatus(), localTransfer.getSourcePath());
            }

            ResponseEntity<Object> ltsResponse = updateLTSDetails(localTransfer);
            if (ltsResponse.getStatusCode() == HttpStatus.OK) {
                return new ResponseEntity<>("Local Transfer Status Updated Successfully.", HttpStatus.OK);
            }
            return new ResponseEntity<>("Local Transfer Status Update Failed.", HttpStatus.CONFLICT);
        } catch (Exception e) {
            return catchException("updateLTSStatusAndSendEmail()", e);
        }
    }

    @Override
    public ResponseEntity<Object> saveMd5ChecksumDetails(Map<String, String> md5ChecksumDetails, Integer gridIonRunId) {
        try {
            Optional<GridIONRunMaster> gridIonRunMaster = gridIONRunMasterRepository.findById(gridIonRunId);
            if (gridIonRunMaster.isEmpty()) {
                return new ResponseEntity<>("GridIon run not found", HttpStatus.CONFLICT);
            }
            String sql = "INSERT INTO GridIonMD5Checksum (GridIonRunId, Filename, MD5ChecksumValue) VALUES (?,?,?);";
            List<Map.Entry<String, String>> checksumList = new ArrayList<>(md5ChecksumDetails.entrySet());
            jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement preparedStatement, int i) throws SQLException {
                    Map.Entry<String, String> entry = checksumList.get(i);
                    preparedStatement.setInt(1, gridIonRunId);
                    preparedStatement.setString(2, entry.getKey());
                    preparedStatement.setString(3, entry.getValue());
                }

                @Override
                public int getBatchSize() {
                    return checksumList.size();
                }
            });
            return new ResponseEntity<>("Saved Successfully", HttpStatus.OK);
        } catch (Exception e) {
            return catchException("saveMd5ChecksumDetails()", e);
        }
    }

    @Override
    public void callFileMover(Integer gridIonStatusViewerId) {
        try {
            HashMap<String, String> attributesData = getAttributesValues(gridIonStatusViewerId);
            if (attributesData == null) {
                LOGGER.error("getAttributesValues is null");
                return;
            }
            String dataDestinationPath = URLDecoder.decode(attributesData.get("GridIonDataDestinationPath"), "UTF-8");

            if (dataDestinationPath.startsWith("/")) {
                dataDestinationPath = dataDestinationPath.substring(1);
            }

            attributesData.put("GridIonDataDestinationPath", dataDestinationPath);

            if (attributesData.get("GridIonDataTransferType").equals(GLOBUS)) {
                tokenIdFromGlobus(attributesData, gridIonStatusViewerId);
                attributesData = getAttributesValues(gridIonStatusViewerId);
            }

            Optional<GridIONStatusViewer> gridIonStatusViewer = gridIONStatusViewerRepository.findById(gridIonStatusViewerId);
            if (gridIonStatusViewer.isEmpty()) {
                LOGGER.debug("Given GridION run not found. GridIonStatusViewerId : {}", gridIonStatusViewerId);
                return;
            }

            /*List<GridIONSampleDetail> sampleDetails = gridIONSampleDetailRepository
                    .findByGridIONStatusViewer_GridIONStatusViewerId(gridIonStatusViewer.get().getGridIONStatusViewerId());
            if (sampleDetails.isEmpty()) {
                LOGGER.debug("GridION samples not found. GridIonStatusViewerId : {}", gridIonStatusViewerId);
                return;
            }*/
//            for (GridIONSampleDetail sampleDetail : sampleDetails) {
                Gson gson = new Gson();
                FileUploaderArgs args = new FileUploaderArgs();

                if (attributesData.get("GridIonDataTransferType").equals(GLOBUS)
                        || attributesData.get("GridIonDataTransferType").equals("SFTP")) {
                    File fileUploaderJarPath = new File(propertyConfig.getFileUploaderJarPath());
                    if (!fileUploaderJarPath.exists()) {
                        LOGGER.error("File uploader jar not present in the location :"
                                + propertyConfig.getFileUploaderJarPath());
                        GridIonLogModel gridIonLogModel = new GridIonLogModel(0
                                , gridIonStatusViewerId
                                , "File uploader jar not present in the location :" + propertyConfig.getFileUploaderJarPath()
                                , "GridION"
                                , 0
                        );
                        insertGridIonLog(gridIonLogModel);
                        return;
                    }
                    LOGGER.info("File uploader is starting Type : " + attributesData.get("GridIonDataTransferType"));
                    String command = "";

                    if (attributesData.get("GridIonDataTransferType").equals(GLOBUS)) {
                        String gridIonDataSourcePath = propertyConfig.getDataSourcePath().replace("?", attributesData.get("ClientName"));
                        args.setUploadType(UploadType.GLOBUS);
                        args.setUsername(attributesData.get("GridIonClientUserName"));
                        args.setPassword(attributesData.get("GridIonClientPassword"));
                        args.setFolder(true);
                        args.setOAuth(URLEncoder.encode(attributesData.get(CREDENTIALJSON), StandardCharsets.UTF_8));
                        args.setSourceEndPoint(attributesData.get("GridIonGlobusSourceEndPoint"));
                        args.setDestinationEndPoint(attributesData.get("GridIonGlobusDestinationEndPoint"));
                        args.setSourceParentPath(URLEncoder.encode(gridIonDataSourcePath, StandardCharsets.UTF_8));
                        String destParentPath = URLDecoder.decode(attributesData.get("GridIonDataDestinationPath"), StandardCharsets.UTF_8).replaceFirst("/", "");
                        args.setDestinationParentPath(URLEncoder.encode(destParentPath, StandardCharsets.UTF_8));
                        args.setRunName(gridIonStatusViewer.get().getCellName());
                        args.setGridIonStatusViewerId(gridIonStatusViewerId);
                        args.setProgramType(String.valueOf(ProgramType.GRIDION));
                    } else if (attributesData.get("GridIonDataTransferType").equals("SFTP")) {
                        args.setUploadType(UploadType.SFTP);
                        args.setUsername(propertyConfig.getSourceUsername());
                        args.setPassword(propertyConfig.getSourcePassword());
                        args.setFolder(true);
                        args.setSftpClientDomain(attributesData.get("GridIonClientDomainURL"));
                        args.setSftpUserName(attributesData.get("GridIonClientUserName"));
                        args.setSftpPassword(attributesData.get("GridIonClientPassword"));
                        args.setSourceParentPath(URLEncoder.encode(gridIonStatusViewer.get().getSourcePath(), StandardCharsets.UTF_8));
                        args.setDestinationParentPath(URLEncoder.encode(attributesData.get("GridIonDataDestinationPath"), StandardCharsets.UTF_8));
                        args.setRunName(gridIonStatusViewer.get().getCellName());
                        args.setGridIonStatusViewerId(gridIonStatusViewerId);
                        args.setProgramType(String.valueOf(ProgramType.GRIDION));
                    }
                    String argsJsonString = gson.toJson(args);

                    command = "java -jar " + propertyConfig.getFileUploaderJarPath()
                            + " " + argsJsonString;
                    LOGGER.info("File uploader command is " + command);
                    Process proc = Runtime.getRuntime().exec(command);
                    // https://stackoverflow.com/questions/5483830/process-waitfor-never-returns
                    BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream()));
                    String line;
                    LOGGER.info("Process Status :");
                    while ((line = reader.readLine()) != null) {
                        LOGGER.info(line);
                    }
                    proc.waitFor();
                    reader.close();
                } else {
                    LOGGER.error("Not applicable for file transfer program.");
                }
            // }
        } catch (Exception e) {
            Thread.currentThread().interrupt();
            LOGGER.error("Error :" + e.getMessage());
            GridIonLogModel gridIonLogModel = new GridIonLogModel(0, gridIonStatusViewerId, e.getMessage(), "GridION", 0);
            insertGridIonLog(gridIonLogModel);
        }
    }

    @Override
    public ResponseEntity<String> updateGridIonClientTransferStatus(GridIonClientTransferStatus transferStatus) {
        try {
            Optional<GridIONStatusViewer> statusViewer = gridIONStatusViewerRepository.findById(transferStatus.getGridIonStatusViewerId());
            if (statusViewer.isEmpty()) {
                LOGGER.debug("Given GridIon Run Not Found. GridIonStatusViewerId: {}", transferStatus.getGridIonStatusViewerId());
                return new ResponseEntity<>("GridIon Run Not Found", HttpStatus.NOT_FOUND);
            }
            statusViewer.get().setTransferStatusId(transferStatus.getStatusId());
            statusViewer.get().setDestinationUploadPath(transferStatus.getDestinationUploadPath());
            statusViewer.get().setLocalTransferCompletedTime(new Date());

            gridIONStatusViewerRepository.save(statusViewer.get());

            if (transferStatus.getStatusId() == 3 || transferStatus.getStatusId() == 4) {
                gridIonFileTransferStatusMail(transferStatus.getGridIonStatusViewerId()
                        , "Client Transfer"
                        , transferStatus.getStatusId()
                        , transferStatus.getDestinationUploadPath())
                ;
            }

            return ResponseEntity.ok().body(SUCCESS);
        } catch (Exception e) {
            LOGGER.error("updateGridIonClientTransferStatus() Error :" + e.getMessage());
            return ResponseEntity.internalServerError().body("Something Went Wrong");
        }
    }

    @Override
    public ResponseEntity<Object> insertLogDetail(LogDetailModel logDetail) {
        try {
            String sql = "INSERT INTO LogDetail (ActionType,SourceLocation,DestinationLocation,DeleteLocation,Status,Program) VALUES (?,?,?,?,?,?);";
            jdbcTemplate.update(sql
                    , logDetail.getActionType()
                    , logDetail.getSourceLocation()
                    , logDetail.getDestinationLocation()
                    , logDetail.getDeleteLocation()
                    , logDetail.getStatus()
                    , logDetail.getProgram()
            );
            return new ResponseEntity<>(SUCCESS, HttpStatus.OK);
        } catch (Exception e) {
            return catchException("insertLogDetail()", e);
        }
    }

    @Override
    public ResponseEntity<Object> reportToClientEmailInfo(ClientReportMaster clientReportMaster) {
        try {
            boolean isAllClientProjectsMatch = clientReportMaster.getGridIonClientReports().stream().map(GridIonClientReport::getClientProjectId).distinct().count() == 1;

            if (!isAllClientProjectsMatch) {
                response.setStatus(false);
                response.setInformation(new InformationModel(new Date(), "Failed to generate report", "Mixed client projects are not allowed to be reported"));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }

            List<String> pathSplit = Arrays.stream(propertyConfig.getReportSmbUrl().split("/"))
                    .filter(path -> !path.equalsIgnoreCase("")).toList();

            DiskShareConfig diskShareConfig = new DiskShareConfig(
                    pathSplit.get(0)
                    , pathSplit.get(1)
                    , propertyConfig.getReportSmbUsername()
                    , propertyConfig.getReportSmbPassword()
                    , propertyConfig.getReportSmbDomain()
            );

            String smbPath = propertyConfig.getReportSmbUrl().replace("//", "").replace(pathSplit.get(0) + "/", "")
                    .replace(pathSplit.get(1) + "/", "");
            boolean isFolderExists = diskShareConfig.getDiskShare().folderExists(smbPath);
            if (!isFolderExists) {
                LOGGER.info("reportToClientEmailInfo() info. File/Folder Permission Issue.Report SMB URL: " + propertyConfig.getReportSmbUrl());
                response.setStatus(false);
                response.setInformation(new InformationModel(new Date()
                        , "File/Folder Permission Issue", "Sorry! You are not authorized to generate reports. Please contact administrator"));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }
            diskShareConfig.close();

            String fromAddressSql = "SELECT AV.AttributeValue FROM AttributeDetails AV, Attributes A WHERE A.AttributeID = AV.AttributeID AND A.AttributeName = '"
                    + propertyConfig.getMailUsernameAttributeName() + "'";
            String reportFromAddress = jdbcTemplate.queryForObject(fromAddressSql, String.class);

            String geneGroupInfoSql = "SELECT GeneGroupID FROM GeneGroups WHERE GeneGroupName = '" + GridIonConstants.GENE_GROUP_NAME + "'";
            Integer geneGroupId = jdbcTemplate.queryForObject(geneGroupInfoSql, Integer.class);

            GridIonReportAttributes gridIonReportAttribute = jdbcTemplate.queryForObject("exec GetReportAttributesByClientProjectIDNGeneGroupID ?,?,?;"
                    , BeanPropertyRowMapper.newInstance(GridIonReportAttributes.class)
                    , clientReportMaster.getGridIonClientReports().get(0).getClientProjectId(), 0, geneGroupId);

            List<List<GridIonReportData>> gridIonClientReportsGroup = new ArrayList<>();
            for (GridIonClientReport clientReport : clientReportMaster.getGridIonClientReports()) {
                List<GridIonReportData> gridIonReportData = jdbcTemplate.query("exec GetGridIonDetailsForReporting ?,?,?;",
                        BeanPropertyRowMapper.newInstance(GridIonReportData.class),
                        clientReport.getGridIonStatusViewerId(), gridIonReportAttribute.getReportFormatSubType(), clientReport.getClientProjectId());
                Optional<GridIONRunMaster> gridIonRunMaster = gridIONRunMasterRepository.findById(clientReport.getGridIonRunId());
                gridIonReportData.forEach(data -> data.setGridIonRunMaster(gridIonRunMaster.get()));
                gridIonClientReportsGroup.add(gridIonReportData);
            }

            List<GridIonReportData> reportDataFinal = new ArrayList<>();
            gridIonClientReportsGroup.forEach(reportDataFinal::addAll);

            List<String> rawRuns = reportDataFinal.stream().filter(data ->
                            data.getType().equalsIgnoreCase("raw"))
                    .map(GridIonReportData::getRun).distinct().toList();
            List<GridIonReportData> differentRawRuns = new ArrayList<>();
            for (String rawRun : rawRuns) {
                differentRawRuns.add(
                        reportDataFinal.stream().filter(data -> data.getRun().equalsIgnoreCase(rawRun)).findFirst().get()
                );
            }

            List<GridIonReportData> reportDataFinalMaster = reportDataFinal.stream().filter(data ->
                            !data.getType().equalsIgnoreCase("raw"))
                    .collect(Collectors.toList());
            reportDataFinalMaster.addAll(differentRawRuns);

            String fileNameForGetUniqeId = GridIonConstants.REPORT_TO_CLIENT_BASE_FILE_NAME + GridIonUtil.getCurrentDate() + "__" + reportDataFinalMaster.get(0).getProject();

            Integer uniqueId = insertUpdateClientReportLog(clientReportMaster, gridIonReportAttribute, fileNameForGetUniqeId);

            GRIDION_REPORT_TO_CLIENT_UNIQUE_ID = uniqueId;
            USER_ID = clientReportMaster.getUserId();
            GRIDION_CLIENT_REPORTS = clientReportMaster.getGridIonClientReports();

            StringBuilder fileName = new StringBuilder().append(GridIonConstants.REPORT_TO_CLIENT_BASE_FILE_NAME)
                    .append(GridIonUtil.getCurrentDate()).append("__")
                    .append(uniqueId.toString()).append("_").append(reportDataFinalMaster.get(0).getProject()).append(".xlsx");
            StringBuilder filePath = new StringBuilder().append(propertyConfig.getReportSmbUrl())
                    .append(GridIonUtil.getCurrentYear().toString()).append("/")
                    .append(GridIonConstants.REPORT_TO_CLIENT_GRIDION_REPORTS).append("/")
                    .append(reportDataFinalMaster.get(0).getProject()).append("/").append(GridIonUtil.getCurrentDate()).append("/");

            Attachment attachment = new Attachment(fileName.toString(), filePath.toString());
            EmailInfo emailInfo = new EmailInfo();
            emailInfo.setMailTitle(gridIonReportAttribute.getMailSubject().concat(" - ").concat(gridIonReportAttribute.getReportFormatSubType()));
            emailInfo.setFrom(reportFromAddress);
            emailInfo.setTo(gridIonReportAttribute.getReportTo().split(";"));
            emailInfo.setCc(gridIonReportAttribute.getReportCC().split(";"));
            emailInfo.setBcc(new String[]{});
            emailInfo.setSubject(gridIonReportAttribute.getMailSubject());
            emailInfo.setAttachments(wgsXlsReportGenerate(reportDataFinalMaster, attachment));
            emailInfo.setMessage(GridIonConstants.REPORT_TO_CLIENT_MAIL_BODY);

            response.setStatus(true);
            response.setData(emailInfo);
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "data"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error("WgsRunServiceImpl.reportToClientEmailInfo(clientReportMasterDTO clientReportMaster). Error:  {}", e);
            response.setStatus(false);
            response.setInformation(new InformationModel(new Date(), "Mail failed to send", "Sorry! Mail failed to send. Please contact administrator"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
        }
    }

    private Integer insertUpdateClientReportLog(ClientReportMaster clientReportMaster, GridIonReportAttributes gridIonReportAttribute, String fileName) {
        return jdbcTemplate.queryForObject("EXEC InsertUpdateClientReportLog ?,?,?,?,?,?,?,?,?,?;"
                , Integer.class
                , gridIonReportAttribute.getClientProjectId(), GridIonConstants.GENE_GROUP_NAME, gridIonReportAttribute.getReportFormatSubTypeId()
                , "", fileName, clientReportMaster.getUserId(), GridIonConstants.REPORT_TO_CLIENT_MAIL_COUNT, "", "N", BigInteger.valueOf(0));
    }

    private List<Attachment> wgsXlsReportGenerate(List<GridIonReportData> reportDataFinal, Attachment attachment) {
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("WgsReport");

        XSSFFont headerFont = workbook.createFont();
        headerFont.setFontHeightInPoints((short) 10);
        headerFont.setFontName("Calibri");
        headerFont.setBold(true);

        String[] reportHeaders = {"Project", "SampleID", "CellName", "Submitted Name", "Data Source", "Technology", "Run", "Type", "Lane", "# of Cycles", "Run Type", "Index Seq", "Vendor ID", "Output file path", "Reports Folder Size (GB)"};
        int rowNum = 0;
        int colNumHeader = 0;
        Row rowHeader = sheet.createRow(rowNum++);

        XSSFCellStyle headerStyle = workbook.createCellStyle(); // header text style property
        headerStyle.setAlignment(HorizontalAlignment.CENTER);
        headerStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        headerStyle.setFillForegroundColor(IndexedColors.TAN.index);
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerStyle.setFont(headerFont);
        headerStyle.setBorderBottom(BorderStyle.THIN);
        headerStyle.setBorderTop(BorderStyle.THIN);
        headerStyle.setBorderRight(BorderStyle.THIN);
        headerStyle.setBorderLeft(BorderStyle.THIN);

        for (String header : reportHeaders) {
            Cell cell = rowHeader.createCell(colNumHeader++);
            rowHeader.setHeight((short) 800);
            cell.setCellValue(header);
            cell.setCellStyle(headerStyle);
        }

        XSSFFont bodyFont = workbook.createFont();
        bodyFont.setFontHeightInPoints((short) 12);
        bodyFont.setFontName("Calibri");
        bodyFont.setBold(false);

        XSSFCellStyle bodyStyle = workbook.createCellStyle(); // body data style property
        bodyStyle.setFont(bodyFont);
        bodyStyle.setBorderBottom(BorderStyle.THIN);
        bodyStyle.setBorderTop(BorderStyle.THIN);
        bodyStyle.setBorderRight(BorderStyle.THIN);
        bodyStyle.setBorderLeft(BorderStyle.THIN);

        for (GridIonReportData reportData : reportDataFinal) { // data set loop functionality
            Row row = sheet.createRow(rowNum++);
            int colNum = 0;
            Cell cellProject = row.createCell(colNum++);
            cellProject.setCellValue(reportData.getProject());
            cellProject.setCellStyle(bodyStyle);

            Cell cellSampleId = row.createCell(colNum++);
            cellSampleId.setCellValue(reportData.getSampleId());
            cellSampleId.setCellStyle(bodyStyle);

            Cell cellName = row.createCell(colNum++);
            cellName.setCellValue(reportData.getCellName());
            cellName.setCellStyle(bodyStyle);

            Cell cellSubmittedName = row.createCell(colNum++);
            cellSubmittedName.setCellValue(reportData.getSubmittedName());
            cellSubmittedName.setCellStyle(bodyStyle);

            Cell cellDataSource = row.createCell(colNum++);
            cellDataSource.setCellValue(reportData.getDataSource());
            cellDataSource.setCellStyle(bodyStyle);

            Cell cellTechnology = row.createCell(colNum++);
            cellTechnology.setCellValue(reportData.getTechnology());
            cellTechnology.setCellStyle(bodyStyle);

            Cell cellRun = row.createCell(colNum++);
            cellRun.setCellValue(reportData.getRun());
            cellRun.setCellStyle(bodyStyle);

            Cell cellType = row.createCell(colNum++);
            cellType.setCellValue(reportData.getType());
            cellType.setCellStyle(bodyStyle);

            Cell cellLane = row.createCell(colNum++);
            cellLane.setCellValue(reportData.getLane());
            cellLane.setCellStyle(bodyStyle);

            if (StringUtils.isBlank(reportData.getNoOfCycles())) {
                reportData.setNoOfCycles("N/A");
            }
            Cell cellNoOfCycles = row.createCell(colNum++);
            cellNoOfCycles.setCellValue(reportData.getNoOfCycles());
            cellNoOfCycles.setCellStyle(bodyStyle);

            Cell cellRunType = row.createCell(colNum++);
            cellRunType.setCellValue(reportData.getRunType());
            cellRunType.setCellStyle(bodyStyle);

            Cell cellIndexSeq = row.createCell(colNum++);
            cellIndexSeq.setCellValue(reportData.getIndexSeq());
            cellIndexSeq.setCellStyle(bodyStyle);

            Cell cellVendorId = row.createCell(colNum++);
            cellVendorId.setCellValue(reportData.getVendorId());
            cellVendorId.setCellStyle(bodyStyle);

            Cell cellOutputFilePath = row.createCell(colNum++);
            cellOutputFilePath.setCellValue(reportData.getOutputFilePath());
            cellOutputFilePath.setCellStyle(bodyStyle);

            Cell cellReportFolderSize = row.createCell(colNum++);
            try {
                String pathString = reportData.getSourcePath().replaceFirst("/", "").replace("\\", "/");
                if (!pathString.endsWith("/")) {
                    pathString += "/";
                }

                List<String> pathSplit = Arrays.stream(pathString.split("/"))
                        .filter(path -> !path.equalsIgnoreCase("")).toList();

                DiskShareConfig diskShareConfig = new DiskShareConfig(
                        pathSplit.get(0)
                        , pathSplit.get(1)
                        , propertyConfig.getNasSmbUsername()
                        , propertyConfig.getNasSmbPassword()
                        , propertyConfig.getReportSmbDomain()
                );

                String smbPath = pathString.replace("//", "").replace(pathSplit.get(0) + "/", "")
                        .replace(pathSplit.get(1) + "/", "");

                cellReportFolderSize.setCellValue(
                        GridIonUtil.findShareDirectorySizeInGB(smbPath, diskShareConfig));
                diskShareConfig.close();
            } catch (Exception e) {
                LOGGER.error("wgsXlsReportGenerate() Error:{}", e);
            }
            cellReportFolderSize.setCellStyle(bodyStyle);
        }
        for (int i = 0; i < reportHeaders.length; i++) {
            sheet.autoSizeColumn(i);
        }
        List<String> pathSplit = Arrays.stream(attachment.getFilePath().split("/"))
                .filter(path -> !path.equalsIgnoreCase("")).toList();

        try {
            DiskShareConfig diskShareConfig = new DiskShareConfig(
                    pathSplit.get(0)
                    , pathSplit.get(1)
                    , propertyConfig.getReportSmbUsername()
                    , propertyConfig.getReportSmbPassword()
                    , propertyConfig.getReportSmbDomain()
            );
            String smbPath = attachment.getFilePath().replace("//", "").replace(pathSplit.get(0) + "/", "")
                    .replace(pathSplit.get(1) + "/", "");
            boolean isFolderExists = diskShareConfig.getDiskShare().folderExists(smbPath);
            if (!isFolderExists) {
                String[] desNestedDirectory = smbPath.split("/");
                String currentDirectory = "";
                for (String directory : desNestedDirectory) {
                    currentDirectory += directory + "/";
                    if (!diskShareConfig.getDiskShare().folderExists(currentDirectory)) {
                        diskShareConfig.getDiskShare().mkdir(currentDirectory);
                    }
                }
            }

            try (OutputStream outputStream = diskShareConfig.getDiskShare().openFile(smbPath.concat("/").concat(attachment.getFileName())
                    , EnumSet.of(AccessMask.GENERIC_WRITE)
                    , null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_CREATE, null).getOutputStream()) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                workbook.write(bos);
                outputStream.write(bos.toByteArray());
                workbook.close();

            }
            diskShareConfig.close();
        } catch (Exception e) {
            LOGGER.debug("Attachment creation failed: Message:  {}", e);
        }
        List<Attachment> attachments = new ArrayList<>();
        attachment.setFilePath(attachment.getFilePath() + attachment.getFileName());
        attachments.add(attachment);
        return attachments;
    }

    @Override
    public ResponseEntity<Object> reportToClientSendEmail(GridIonEmailDetails details) {
        String msgBody = details.getMsgBody() + "\n\n" + "Histo Reference ID: " + GRIDION_REPORT_TO_CLIENT_UNIQUE_ID + "-" + GridIonUtil.getCurrentDate();

        try {
            List<String> pathSplit = Arrays.stream(details.getAttachmentsSourcePath().split("/"))
                    .filter(path -> !path.equalsIgnoreCase("")).toList();

            DiskShareConfig diskShareConfig = new DiskShareConfig(
                    pathSplit.get(0)
                    , pathSplit.get(1)
                    , propertyConfig.getReportSmbUsername()
                    , propertyConfig.getReportSmbPassword()
                    , propertyConfig.getReportSmbDomain()
            );

            String smbPath = details.getAttachmentsSourcePath().replace("//", "").replace(pathSplit.get(0) + "/", "")
                    .replace(pathSplit.get(1) + "/", "");
            boolean isFolderExists = diskShareConfig.getDiskShare().folderExists(smbPath);

            if (!isFolderExists) {
                LOGGER.info("reportToClientSendEmail() info. Current user not have file permission. File path:" + details.getAttachmentsSourcePath());
                response.setStatus(false);
                response.setInformation(new InformationModel(new Date(), "File/Folder Permission Issue", "Sorry! You are not authorized to generate reports. Please contact administrator"));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }
            diskShareConfig.close();

            StringBuilder file = new StringBuilder().append(details.getAttachmentsSourcePath());
            List<String> pathSplitFolder = Arrays.stream(file.toString().split("/"))
                    .filter(path -> !path.equalsIgnoreCase("")).toList();

            DiskShareConfig diskShareConfigFile = new DiskShareConfig(
                    pathSplitFolder.get(0)
                    , pathSplitFolder.get(1)
                    , propertyConfig.getReportSmbUsername()
                    , propertyConfig.getReportSmbPassword()
                    , propertyConfig.getReportSmbDomain()
            );

            Map<String, byte[]> reportFiles = new HashMap<>();
            Map<String, InputStream> reportFilesInput = new HashMap<>();
            InputStream inputStream = null;
            int filesCount = 0;
            ResponseEntity<String> emailResponse = null;
            for (String fileName : details.getFileNames()) {
                file.append(fileName);
                List<String> pathSplitFile = Arrays.stream(file.toString().split("/"))
                        .filter(path -> !path.equalsIgnoreCase("")).toList();

                String smbPathFile = file.toString().replace("//", "").replace(pathSplitFile.get(0) + "/", "")
                        .replace(pathSplitFile.get(1) + "/", "");
                boolean isFileExistsFile = diskShareConfigFile.getDiskShare().fileExists(smbPathFile);

                if (!isFileExistsFile) {
                    LOGGER.info("reportToClientSendEmail() info. Report attachment file not exist. File path:" + file.toString());
                    response.setStatus(false);
                    response.setInformation(new InformationModel(new Date(), "Given file not exist", "File not exist. File name:" + fileName));
                    mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                    return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
                }
                inputStream = diskShareConfigFile.getDiskShare().openFile(
                        smbPathFile,
                        EnumSet.of(AccessMask.GENERIC_READ),
                        null,
                        SMB2ShareAccess.ALL,
                        SMB2CreateDisposition.FILE_OPEN,
                        null
                ).getInputStream();
                reportFilesInput.put(fileName, inputStream);
                filesCount++;
                if (details.getFileNames().length == filesCount) {
                    emailResponse = sendEmailViaPacbio(details.getTo(), Optional.of(details.getCc()), Optional.of(details.getBcc())
                            , details.getSubject(), msgBody, reportFilesInput);
                }
                reportFiles.put(fileName, new ByteArrayResource(IOUtils.toByteArray(inputStream)).getByteArray());
            }
            // Sending the mail
            assert inputStream != null;
            inputStream.close();
            diskShareConfigFile.close();
            for (GridIonClientReport gridIonClientReport : GRIDION_CLIENT_REPORTS) {
                updateGridIonReportingStatus(gridIonClientReport.getGridIonStatusViewerId().toString(), details.getUserId()
                        , BigInteger.valueOf(GRIDION_REPORT_TO_CLIENT_UNIQUE_ID)); // update email status
            }

            // Log the email data and file in DB
            insertReportMailLog(details, GRIDION_REPORT_TO_CLIENT_UNIQUE_ID, reportFiles);

            assert emailResponse != null;
            if (emailResponse.getStatusCode() == HttpStatus.OK) {
                response.setStatus(true);
                response.setInformation(new InformationModel(new Date(), "E-Mail Send", "E-Mail sent Successfully"));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            } else {
                response.setStatus(false);
                response.setInformation(new InformationModel(new Date(), "Failed", "Error while sending E-Mail!!!"));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                return new ResponseEntity<>(mappingJacksonValue, emailResponse.getStatusCode());
            }
        } catch (Exception e) {
            return catchException("reportToClientSendEmail()", e);
        }
    }

    private ResponseEntity<String> sendEmailViaPacbio(String[] to, Optional<String[]> cc, Optional<String[]> bcc, String subject, String emailBody
            , Map<String, InputStream> reportFilesInput) throws IOException {
        String url = propertyConfig.getPacbioBaseUrl().concat("/REPORT/sendEmail/attachment");

        // Create the multipart request body
        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();

        List<File> tempFiles = new ArrayList<>();
        // Add files to the request body
        for (Map.Entry<String, InputStream> reportFile : reportFilesInput.entrySet()) {
            Resource fileResource = new ByteArrayResource(reportFile.getValue().readAllBytes()) {
                @Override
                public String getFilename() {
                    return reportFile.getKey();
                }
            };
            body.add("files", fileResource);
        }

        // Add other parameters
        body.add("to", String.join(",", to));
        body.add("cc", cc.map(strings -> String.join(",", strings)).orElse(""));
        body.add("bcc", bcc.map(strings -> String.join(",", strings)).orElse(""));
        body.add("subject", subject);
        body.add("body", emailBody); // Add the email body here

        // Set up headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);

        // Create the request entity
        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);

        // Make the request
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class);

        tempFiles.forEach(tempFile -> {
            if (tempFile.exists()) {
                tempFile.delete();
            }
        });
        return response;
    }

    private void insertReportMailLog(GridIonEmailDetails emailDetails, Integer reportUniqueId, Map<String, byte[]> reportFiles) {

        String mailLogSpQuery = "EXEC InsertUpdateReportMailLog_GridIon ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?";

        String spResult = jdbcTemplate.queryForObject(mailLogSpQuery
                , String.class
                , new Object[]{
                        Long.valueOf(reportUniqueId)
                        , emailDetails.getSubject()
                        , emailDetails.getSubject()
                        , String.join(",", emailDetails.getTo())
                        , String.join(",", emailDetails.getCc())
                        , String.join(",", emailDetails.getBcc())
                        , emailDetails.getMsgBody()
                        , ""
                        , ""
                        , "EMAIL"
                        , emailDetails.getUserId()
                }
        );

        if (spResult.equalsIgnoreCase("Success") && !reportFiles.isEmpty()) {
            String fileLogSqlSp = "EXEC InsertClientReportFileLog_WGS ?, ?, ?, ?;";
            for (Map.Entry<String, byte[]> fileEntrySet : reportFiles.entrySet()) {
                String fileLogSpResult = jdbcTemplate.queryForObject(fileLogSqlSp
                        , String.class
                        , new Object[]{fileEntrySet.getKey(), fileEntrySet.getValue(), reportUniqueId, GridIonConstants.GENE_GROUP_NAME}
                );
            }
        }
    }

    private String updateGridIonReportingStatus(String gridIonStatusViewerId, int userId, BigInteger uniqueId) {
        return jdbcTemplate.queryForObject("exec UpdateGridIonReportingStatus ?,?,?;"
                , String.class
                , gridIonStatusViewerId, userId, uniqueId);
    }

    @Override
    public ResponseEntity<Object> downloadFileByPath(String encodeFilePath) {
        byte[] data;
        String filePath = GridIonUtil.decode(encodeFilePath);
        try {
            List<String> pathSplit = Arrays.stream(filePath.split("/"))
                    .filter(path -> !path.equalsIgnoreCase("")).toList();

            DiskShareConfig diskShareConfig = new DiskShareConfig(
                    pathSplit.get(0)
                    , pathSplit.get(1)
                    , propertyConfig.getReportSmbUsername()
                    , propertyConfig.getReportSmbPassword()
                    , propertyConfig.getReportSmbDomain()
            );

            String smbPath = filePath.replace("//", "").replace(pathSplit.get(0) + "/", "")
                    .replace(pathSplit.get(1) + "/", "");
            boolean isFolderExists = diskShareConfig.getDiskShare().fileExists(smbPath);
            if (!isFolderExists) {
                LOGGER.info("downloadFileByPath() info. Download path:" + filePath);
                response.setStatus(false);
                response.setInformation(new InformationModel(new Date(), "File Permission Issue", "Sorry! You are not authorized to download. Please contact administrator"));
                mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }

            try (DiskShare diskShare = diskShareConfig.getDiskShare();
                 InputStream inputStream = diskShare.openFile(
                         smbPath,
                         EnumSet.of(AccessMask.GENERIC_READ),
                         null,
                         SMB2ShareAccess.ALL,
                         SMB2CreateDisposition.FILE_OPEN,
                         null
                 ).getInputStream()) {
                data = IOUtils.toByteArray(inputStream);
            }
        } catch (IOException e) {
            LOGGER.error("downloadFileByPath() error.Failed to download file. Message:  {}", e);
            response.setStatus(false);
            response.setInformation(new InformationModel(new Date(), "File related issue.", "File conversion failed. Please contact administrator"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
        }

        String[] filename = filePath.split("/");
        GridIonReportFile gridIonReportFile = new GridIonReportFile();
        gridIonReportFile.setFilename(filename[filename.length - 1]);
        gridIonReportFile.setData(data);

        response.setStatus(true);
        response.setData(gridIonReportFile);
        mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "data"});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Object> reportToClientUploadFile(MultipartFile multipartFile, String encodeUploadPath) {
        String uploadPath = GridIonUtil.decode(encodeUploadPath);
        if (multipartFile.isEmpty()) {
            response.setStatus(false);
            response.setInformation(new InformationModel(new Date(), "File Upload Failed", "Does not contain any file"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }

        List<String> pathSplit = Arrays.stream(uploadPath.split("/"))
                .filter(path -> !path.equalsIgnoreCase("")).toList();

        DiskShareConfig diskShareConfig = new DiskShareConfig(
                pathSplit.get(0)
                , pathSplit.get(1)
                , propertyConfig.getReportSmbUsername()
                , propertyConfig.getReportSmbPassword()
                , propertyConfig.getReportSmbDomain()
        );

        String smbPath = uploadPath.replace("//", "").replace(pathSplit.get(0) + "/", "")
                .replace(pathSplit.get(1) + "/", "");
        boolean isFolderExists = diskShareConfig.getDiskShare().folderExists(smbPath);
        if (!isFolderExists) {
            LOGGER.info("reportToClientUploadFile() info.Directory or file does not exist. Path: " + uploadPath);
            response.setStatus(false);
            response.setInformation(new InformationModel(new Date(), "File Permission Issue", "Sorry! You are not authorized to upload file. Please contact administrator"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }

        try (OutputStream outputStream = diskShareConfig.getDiskShare().openFile(smbPath.concat(multipartFile.getOriginalFilename())
                , EnumSet.of(AccessMask.GENERIC_WRITE)
                , null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OVERWRITE_IF, null).getOutputStream()) {
            outputStream.write(multipartFile.getBytes());
        } catch (Exception e) {
            LOGGER.error("reportToClientUploadFile() error. Failed to upload file. Message:  {}", e);
            response.setStatus(false);
            response.setInformation(new InformationModel(new Date(), "File Upload Failed", "Something went wrong while uploading the file"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
        }

        try {
            diskShareConfig.close();
        } catch (Exception e) {
            LOGGER.error("reportToClientUploadFile() error. Failed to upload file. Message:  {}", e);
            response.setStatus(false);
            response.setInformation(new InformationModel(new Date(), "File Upload Failed", "Something went wrong while uploading the file"));
            mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
        }
        response.setStatus(true);
        response.setInformation(new InformationModel(new Date(), "File Upload Successfully", "File uploaded destination path"));
        mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, "information"});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    public EmailAttributeDetails getMailAttributeDetails(JdbcTemplate jdbcTemplate, PropertyConfig propertyConfig) {
        EmailAttributeDetails emailAttributeDetails = new EmailAttributeDetails();
        List<AttributeDetails> allAttributesByCategory = getAllAttributesByCategory(GridIonConstants.GENERAL, jdbcTemplate);

        emailAttributeDetails.setSmtpUserName(allAttributesByCategory.stream().filter(attribute -> attribute.getAttributeName()
                .equals(propertyConfig.getSmtpMailUserNameAttribute())).findFirst().get().getAttributeValue());

        emailAttributeDetails.setSmtpPassword(allAttributesByCategory.stream().filter(attribute -> attribute.getAttributeName()
                .equals(propertyConfig.getSmtpMailPasswordAttribute())).findFirst().get().getAttributeValue());

        return emailAttributeDetails;
    }

    private List<AttributeDetails> getAllAttributesByCategory(String category, JdbcTemplate jdbcTemplate) {
        return jdbcTemplate.query("EXEC GetAllAttributesByCategory ?;", BeanPropertyRowMapper.newInstance(AttributeDetails.class), category);
    }

    private void tokenIdFromGlobus(HashMap<String, String> attributesData, int gridIonStatusViewerId) {
        try {
            String userNamePassword = attributesData.get("GridIonClientUserName") + ":"
                    + attributesData.get("GridIonClientPassword");
            Process proc = Runtime.getRuntime()
                    .exec("curl --user " + userNamePassword + " " + attributesData.get("GridIonClientDomainURL") + "");
            proc.waitFor();
            // Then retrieve the process output
            InputStream in = proc.getInputStream();
            byte[] b = new byte[in.available()];
            in.read(b, 0, b.length);
            String jsonString = new String(b);
            LOGGER.info(jsonString);
            JSONObject jsonObj = new JSONObject(jsonString);
            if (jsonObj.has("token_id")) {
                int expiry = jsonObj.getInt("expiry");
                jdbcTemplate.update("exec GridIonUpdateGlobusAccesstokenDetailsIfExpired ?,?,? ",
                        gridIonStatusViewerId, jsonString, expiry);

            } else {
                LOGGER.debug("Method: tokenIdFromGlobus(). Message: Not Found");
            }

        } catch (Exception e) {
            Thread.currentThread().interrupt();
            LOGGER.error("Error :" + e.getMessage());
        }

    }

    private HashMap<String, String> getAttributesValues(int gridIonStatusViewerId) {
        LOGGER.info("fetching attribute values");
        HashMap<String, String> data = jdbcTemplate.query("exec GridIon_GetClientProjectAttributes ?;",
                (ResultSet rs) -> {
                    HashMap<String, String> results = new HashMap<>();
                    while (rs.next()) {
                        results.put(rs.getString("AttributeName"), rs.getString("AttributeValue"));
                    }
                    return results;
                }
                , gridIonStatusViewerId);
        if (data != null && (data.containsKey(CREDENTIALJSON)) && (data.get(CREDENTIALJSON) != null)) {
            String[] splitCredJson = data.get(CREDENTIALJSON).split("\"access_token\":\"");
            String[] splitCredToPassFileUploader = splitCredJson[1].split(",");
            data.put(CREDENTIALJSON, splitCredToPassFileUploader[0].replace("\"", ""));

        }
        LOGGER.info("fetching attribute values Completed");
        return data;
    }

    private String gridIonFileTransferStatusMail(int gridIonStatusViewerId, String type, int result, String path) {
        LOGGER.info("WGSFileTransferStatusMail in progress");
        String mailResult = "";
        try {
            mailResult = jdbcTemplate.queryForObject("GridIonFileTransferStatusMail ?,?,?,?;"
                    , String.class
                    , gridIonStatusViewerId, type, result, path);
            LOGGER.info("WGSFileTransferStatusMail in progress completed");
        } catch (Exception e) {
            LOGGER.error("Error :" + e.getMessage());
            return e.getMessage();
        }
        return mailResult;
    }

    private ResponseEntity<Object> responseFalseValidation(String message, String description) {
        response.setStatus(false);
        response.setInformation(new InformationModel(new Date(), message, description));
        mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{STATUS, INFORMATION});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }

    private ResponseEntity<Object> catchException(String methodName, Exception e) {
        String errorMessage = "An error occurred in " + methodName + ": " + e.getMessage();
        LOGGER.error(errorMessage, e);
        response.setStatus(false);
        response.setInformation(new InformationModel(new Date(), "Internal Server Error", "Something went wrong. Please contact administrator."));
        mappingJacksonValue = FilterUtil.responseFilter(response, new String[]{INFORMATION, STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    private void localCopyProcess(LocalCopyDetails localCopyDetails) {
        try {
            Gson gson = new Gson();
            Path filePath = Paths.get(propertyConfig.getGridIonFileDataOrganizerJarPath());
            Files.exists(filePath);
            if (true) {
                // Split server name and share name in source path;
                String sourcePath = localCopyDetails.getSourcePath().replace("\\", "/");
                List<String> sourceSplit = Arrays.stream(sourcePath.split("/"))
                        .filter(path -> !path.equalsIgnoreCase("")).toList();
                sourcePath = sourcePath.replace("//", "").replace(sourceSplit.get(0) + "/", "").replace(sourceSplit.get(1) + "/", "");

                // Split server name and share name in destination path;
                String localDestinationPath = localCopyDetails.getDesPath().replace("\\", "/");
                List<String> destinationSplit = Arrays.stream(localDestinationPath.split("/"))
                        .filter(path -> !path.equalsIgnoreCase("")).toList();
                localDestinationPath = localDestinationPath.replace("//", "").replace(destinationSplit.get(0) + "/", "").replace(destinationSplit.get(1) + "/", "");

                FileDataOrganizerArgs inputArgs = new FileDataOrganizerArgs();
                inputArgs.setSourceServer(sourceSplit.get(0));
                inputArgs.setSourceShare(sourceSplit.get(1));
                inputArgs.setDestinationServer(destinationSplit.get(0));
                inputArgs.setDestinationShare(destinationSplit.get(1));
                inputArgs.setSourcePath(URLEncoder.encode(sourcePath, StandardCharsets.UTF_8));
                inputArgs.setDestinationDirectory(URLEncoder.encode(localDestinationPath, StandardCharsets.UTF_8));
                inputArgs.setDestinationUsername(propertyConfig.getLocalCopyDestUsername());
                inputArgs.setDestinationPassword(propertyConfig.getLocalCopySourcePassword());
                inputArgs.setStatusViewerId(localCopyDetails.getGridIonStatusViewerId());
                inputArgs.setActionType(String.valueOf(ActionType.COPY));
                inputArgs.setSourceUsername(propertyConfig.getLocalCopySourceUsername());
                inputArgs.setSourcePassword(propertyConfig.getLocalCopySourcePassword());
                inputArgs.setProgramType(String.valueOf(ProgramType.GRIDION));
                inputArgs.setRunId(localCopyDetails.getGridIonRunId());


                String argsJsonString = gson.toJson(inputArgs);
                String command = "java -jar " + propertyConfig.getGridIonFileDataOrganizerJarPath() + " " + argsJsonString;
                LOGGER.info("GridIon file data organizer path " + command);
                Process proc = Runtime.getRuntime().exec(command);

                // https://stackoverflow.com/questions/5483830/process-waitfor-never-returns
                BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream()));
                String line;
                LOGGER.info("Process Status :");
                while ((line = reader.readLine()) != null) {
                    LOGGER.info(line);
                }
                proc.waitFor();
                LOGGER.info("GridIon Local Copy Process Completed");
            } else {
                LOGGER.error("GridIonFileDataOrganizer Jar Missing or Path is wrong");
                GridIonLogModel gridIonLogModel = new GridIonLogModel(
                        localCopyDetails.getGridIonRunId()
                        , localCopyDetails.getGridIonStatusViewerId()
                        , "PacBioFileDataOrganizer Jar Missing"
                        , "GridION"
                        , 0
                );
                insertGridIonLog(gridIonLogModel);
            }
        } catch (Exception e) {
            Thread.currentThread().interrupt();
            LOGGER.error("Error :" + e.getMessage());
            GridIonLogModel gridIonLogModel = new GridIonLogModel(
                    localCopyDetails.getGridIonRunId()
                    , localCopyDetails.getGridIonStatusViewerId()
                    , e.getMessage()
                    , "GridION"
                    , 0
            );
            insertGridIonLog(gridIonLogModel);
        }
    }
}
