package com.histo.gridion.service;

import com.histo.gridion.model.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

public interface GridIonRunService {
    ResponseEntity<Object> findAllGridIonRuns(GridIonRunFilterRequest filterRequest);
    ResponseEntity<Object> createGridIonRun(GridIONRunCreateModel gridIONRunCreate);
    ResponseEntity<Object> updateGridIonRun(GridIONRunUpdateModel gridIONRunUpdate);
    ResponseEntity<Object> updateAnalysisStatus(Integer gridIONStatusViewerId, UpdateAnalysisStatus analysisStatus);
    ResponseEntity<Object> findRunInfoByStatusId();
    ResponseEntity<Object> updateLTSDetails(LocalTransferStatus statusData);
    ResponseEntity<Object> executeMd5Checksum(LocalTransferStatus statusData);
    ResponseEntity<Object> insertGridIonLog(GridIonLogModel gridIonLog);
    ResponseEntity<Object> updateLTSStatusAndSendEmail(LocalTransferStatus localTransfer);
    ResponseEntity<Object> saveMd5ChecksumDetails(Map<String, String> md5ChecksumDetails, Integer gridIonRunId);
    void callFileMover(Integer gridIonStatusViewerId);
    ResponseEntity<String> updateGridIonClientTransferStatus(GridIonClientTransferStatus transferStatus);
    ResponseEntity<Object> insertLogDetail(LogDetailModel logDetail);
    public ResponseEntity<Object> reportToClientEmailInfo(ClientReportMaster clientReportMaster);
    public ResponseEntity<Object> reportToClientSendEmail(GridIonEmailDetails emailDetails);
    public ResponseEntity<Object> downloadFileByPath(String filePath);
    public ResponseEntity<Object> reportToClientUploadFile(MultipartFile multipartFile, String uploadPath);
}
