package com.histo.gridion.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class GridIonClientReport {
    private Integer gridIonRunId;
    private Integer gridIonStatusViewerId;
    private Integer clientProjectId;
}
