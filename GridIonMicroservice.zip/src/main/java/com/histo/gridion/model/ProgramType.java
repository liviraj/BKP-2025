package com.histo.gridion.model;

public enum ProgramType {
    WGS,GRIDION
}
