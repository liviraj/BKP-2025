package com.histo.gridion.model;

import lombok.*;

@NoArgsConstructor
@Getter
@Setter
@ToString
@AllArgsConstructor
public class GridIonLogModel {
    private int gridIonRunId;
    private int gridIonStatusViewerId;
    private String logInfo;
    private String programName;
    private Integer userId;
}
