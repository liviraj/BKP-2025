package com.histo.gridion.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class GridIonRunFilterRequest {

	private Integer clientProjectId = 0;
	private String startDate;
	private String endDate;
	private Integer transferStatusId = 0;
	private Integer analysisStatusId = 0;
	private Integer localTransferId = 0;
}
