package com.histo.gridion.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class EmailInfo {
    private String mailTitle;
    private String from;
    private String to[];
    private String cc[];
    private String bcc[];
    private String subject;
    private List<Attachment> attachments;
    private String message;
}
