package com.histo.gridion.model;

import com.fasterxml.jackson.annotation.JsonFilter;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@JsonFilter("GridIonResModel")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class GridIonResModel {
    private boolean status;
    private InformationModel information;
    private Object data;
}
