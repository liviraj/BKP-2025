package com.histo.gridion.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class EmailAttributeDetails {
    @JsonProperty("SMTPUserName")
    private String smtpUserName;

    @JsonProperty("SMTPPassword")
    private String smtpPassword;

    @JsonProperty("SMTPMailHost")
    private String smtpMailHost;

    @JsonProperty("SMTPPort")
    private Integer smtpPort;
}
