package com.histo.gridion.model;

import lombok.Getter;

@Getter
public enum GridIonStatusMaster {
    NOT_STARTED(1),
    IN_PROGRESS(2),
    COMPLETED(3),
    FAILED(4),
    NOT_APPLICABLE(5);

    private Integer value;
    GridIonStatusMaster(Integer value) {
        this.value = value;
    }
}
