package com.histo.gridion.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class GridIonMD5ChecksumModel {
    private Integer gridIonRunId;
    private String filename;
    private String md5ChecksumValue;
}

