package com.histo.gridion.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class LocalTransferStatus {
	private int gridIonStatusViewerId;
	private int status;
    private String sourcePath;
//	private int uploadTypeId;
//	private String failureReason;
}
