package com.histo.gridion.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class GridIonRunDetail {
    private Integer gridIONRunId;
    private String runName;
    private Integer clientProjectId;
    private String clientProjectCode;
    private String clientProjectName;
    private String dataPath;
    private int createdBy;
    private String userFullName;
    private String createdOn;
    private Integer gridIONStatusViewerId;
    private Integer analysisStatusId;
    private Integer localTransferStatusId;
    private Integer transferStatusId;
    private boolean reportedStatus;
    private String localTransferCompletedTime;
    private String clientTransferCompletedTime;
    private String cellName;
    private int gridIONDetailId;
    private List<SampleDetail> sampleDetails;
}
