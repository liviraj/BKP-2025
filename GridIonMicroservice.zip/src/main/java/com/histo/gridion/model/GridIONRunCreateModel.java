package com.histo.gridion.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.Map;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class GridIONRunCreateModel {
    private String runName;
    private int clientProjectId;
    private String dataPath;
    private int createdBy;
    private Map<String, String> samplesAndCellName;
}
