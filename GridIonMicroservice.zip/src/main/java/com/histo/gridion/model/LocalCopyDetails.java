package com.histo.gridion.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class LocalCopyDetails {
    private Integer gridIonStatusViewerId;
    private String runName;
    private String sourcePath;
    private String desPath;
    private Integer gridIonRunId;
}
