package com.histo.gridion.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class GridIonEmailDetails {
    private Integer userId;
    private String to[];
    private String cc[];
    private String bcc[];
    private String msgBody;
    private String subject;
    private String attachmentsSourcePath;
    private String fileNames[];
}
