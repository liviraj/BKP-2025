package com.histo.gridion.model;

import lombok.Getter;

@Getter
public enum ReportStatus {
    SEND(true),
    NOT_SEND(false);

    boolean value;
    ReportStatus(boolean value) {
        this.value = value;
    }
}
