package com.histo.gridion.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class GridIonReportAttributes {
    @JsonProperty("ReportTo")
    private String reportTo;
    @JsonProperty("ReportCC")
    private String reportCC;
    @JsonProperty("ReportPassword")
    private String reportPassword;
    @JsonProperty("MailSubject")
    private String mailSubject;
    @JsonProperty("ClientProjectID")
    private Integer clientProjectId;
    @JsonProperty("ReportFormatSubTypeID")
    private Integer reportFormatSubTypeId;
    @JsonProperty("ReportFormatSubType")
    private String reportFormatSubType;
    @JsonProperty("ShareFileEmailAddress")
    private String shareFileEmailAddress;
    @JsonProperty("ShareFileFolderID")
    private String shareFileFolderId;
    @JsonProperty("IsMulitpleShareFileLinkRequired")
    private String isMulitpleShareFileLinkRequired;
    @JsonProperty("MailTransmission")
    private String mailTransmission;
    @JsonProperty("FTPPath")
    private String ftpPath;
    @JsonProperty("FTPUsername")
    private String ftpUsername;
    @JsonProperty("FTPPassword")
    private String ftpPassword;
    @JsonProperty("FTPType")
    private String ftpType;
    @JsonProperty("FTPSSHHostKey")
    private String ftpSSHHostKey;
    @JsonProperty("IsFTPAttachmentRequired")
    private boolean isFTPAttachmentRequired;
    @JsonProperty("IsCompressionRequired")
    private boolean isCompressionRequired;
}
