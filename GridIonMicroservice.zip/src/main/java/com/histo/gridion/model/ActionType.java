package com.histo.gridion.model;

public enum ActionType {
    COPY, MOVE, DELETE;
}
