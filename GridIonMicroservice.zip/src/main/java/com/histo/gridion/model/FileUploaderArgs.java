package com.histo.gridion.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class FileUploaderArgs {
	private UploadType uploadType;
	private String username;
	private String password;
	private boolean isFolder;
	private String oAuth;
	private String sourceEndPoint;
	private String destinationEndPoint;
	private String sourceParentPath;
	private String destinationParentPath;
	private String runName;
	private int wgsStatusViewerID;
	private String sftpUserName;
	private String sftpPassword;
	private String sftpClientDomain;
	private Integer gridIonStatusViewerId;
	private String programType;
}
