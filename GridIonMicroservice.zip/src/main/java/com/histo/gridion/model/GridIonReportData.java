package com.histo.gridion.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.histo.gridion.entity.GridIONRunMaster;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class GridIonReportData {
    @JsonProperty("Project")
    private String project;
    @JsonProperty("SampleID")
    private String sampleId;
    @JsonProperty("CellName")
    private String cellName;
    @JsonProperty("Submitted Name")
    private String submittedName;
    @JsonProperty("Data Source")
    private String dataSource;
    @JsonProperty("Technology")
    private String technology;
    @JsonProperty("Run")
    private String run;
    @JsonProperty("Type")
    private String type;
    @JsonProperty("Lane")
    private String lane;
    @JsonProperty("# of Cycles")
    private String noOfCycles;
    @JsonProperty("Run Type")
    private String runType;
    @JsonProperty("Index Seq")
    private String indexSeq;
    @JsonProperty("Vendor ID")
    private String vendorId;
    @JsonProperty("Output file path")
    private String outputFilePath;
    @JsonProperty("Sourcepath")
    private String sourcePath;
    private float reportFolderSize;
    private GridIONRunMaster gridIonRunMaster;
}
