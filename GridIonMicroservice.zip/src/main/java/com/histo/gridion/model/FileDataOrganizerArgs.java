package com.histo.gridion.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class FileDataOrganizerArgs {
	private String sourceServer;
	private String sourceShare;
	private String destinationServer;
	private String destinationShare;
	private String sourcePath;
	private String destinationDirectory;
	private String sourceUsername;
	private String sourcePassword;
	private String destinationUsername;
	private String destinationPassword;
	private int statusViewerId = 0;
	private int runId = 0;
	private String actionType;
	private String programType;
	private Integer userId;
}
