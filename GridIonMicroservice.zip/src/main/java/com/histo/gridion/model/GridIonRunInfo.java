package com.histo.gridion.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class GridIonRunInfo {
    private Integer gridIONRunId;
    private String runName;
    private String dataPath;
    private List<SampleDetail> sampleDetails;
}
