package com.histo.gridion.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class SampleDetail {
    private Integer gridIONDetailId;
    private Integer gridIONStatusViewerId;
    private String sample;
    private String cellName;
}
