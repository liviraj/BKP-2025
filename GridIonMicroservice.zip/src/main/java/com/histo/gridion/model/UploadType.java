package com.histo.gridion.model;

public enum UploadType {
	GLOBUS,
	SFTP,
	FTP
}
