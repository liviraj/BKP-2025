package com.histo.gridion.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class GridIonClientTransferStatus {
	private int gridIonStatusViewerId;
	private int statusId;
	private String destinationUploadPath;
}
