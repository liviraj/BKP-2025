package com.histo.gridion.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class GridIONRunUpdateModel {
    private Integer gridIonRunId;
    private String runName;
    private int clientProjectId;
    private String dataPath;
    private int modifiedBy;
    private List<SampleDetail> samples;
}
