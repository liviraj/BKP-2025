package com.histo.gridion.proxcy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "WholeGenomeSequencingWebApi", url = "${feign.base.url.wgs}")
public interface WholeGenomeSequencingProxy {
    @GetMapping("/wgsRuns/clientProjects")
    public ResponseEntity<Object> findAllClientProjects(@RequestHeader("Authorization") String token);
}
