package com.histo.gridion.util;

public class GridIonConstants {
    private GridIonConstants() {
    }

    public static final String EMAIL_CLAIM_NAME = "unique_name";
    public static final String GENE_GROUP_NAME = "Whole Genome Sequencing";
    public static final String REPORT_TO_CLIENT_BASE_FILE_NAME = "Histogenetics metadata File_";
    public static final Integer REPORT_TO_CLIENT_MAIL_COUNT = 1;
    public static final String REPORT_TO_CLIENT_GRIDION_REPORTS = "GridIonReports";
    public static final String REPORT_TO_CLIENT_MAIL_BODY = "\n" +
            "Dear Sir/Madam,\n" +
            "\n" +
            "Please find the attached Report.\n" +
            "\n" +
            "Thanks,\n" +
            "Histogenetics\n" +
            "\n" +
            "\n" +
            "*****Please do not reply to this mail. This is an automated mail.****\n";
    public static final String GENERAL = "General";

}
