package com.histo.gridion.util;

import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import com.histo.gridion.model.GridIonResModel;
import org.springframework.http.converter.json.MappingJacksonValue;

/**
 * @author ArockiajayarajM
 *
 */
public class FilterUtil {
	private FilterUtil() {
	}

	public static MappingJacksonValue responseFilter(GridIonResModel response, String[] fields) {
		SimpleBeanPropertyFilter propertyFilter = SimpleBeanPropertyFilter.filterOutAllExcept(fields);
		FilterProvider filterProvider = new SimpleFilterProvider().addFilter("GridIonResModel", propertyFilter);
		MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(response);
		mappingJacksonValue.setFilters(filterProvider);
		return mappingJacksonValue;
	}
}
