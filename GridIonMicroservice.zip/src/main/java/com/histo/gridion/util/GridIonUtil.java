package com.histo.gridion.util;

import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.share.DiskShare;
import com.hierynomus.smbj.share.File;
import com.histo.gridion.config.DiskShareConfig;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Stream;

public class GridIonUtil {

    public static Integer getCurrentYear() {
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        return currentYear;
    }

    public static String getCurrentDate() {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        return dateFormat.format(date);
    }

    public static String findDirectorySizeInGB(String pathString) {
        long size = 0;
        long gb = 1024 * 1024 * 1024;
        String fileSize = "";
        Path path = Paths.get(pathString);

        try (Stream<Path> walk = Files.walk(path)) {
            size = walk
                    .filter(Files::isRegularFile)
                    .mapToLong(p -> {
                        try {
                            return Files.size(p);
                        } catch (IOException e) {
                            return 0L;
                        }
                    })
                    .sum();

        } catch (IOException e) {
            System.out.printf("IO errors %s", e);
        }
        fileSize = new DecimalFormat("#.##").format((float) size / gb);
        return fileSize;
    }

    public static String findShareDirectorySizeInGB(String pathString, DiskShareConfig diskShareConfig)  {
        long size = 0;
        long gb = 1024 * 1024 * 1024;
        String fileSize = "";
        // SmbFile smbFile = new SmbFile(pathString, diskShareConfig);
        size = GridIonUtil.smbFolderSize(diskShareConfig.getDiskShare(), pathString);
        fileSize = new DecimalFormat("#.##").format((float) size / gb);
        return fileSize;
    }

    public static long smbFolderSize(DiskShare share, String directoryPath) {
        ExecutorService executorService = Executors.newCachedThreadPool();
        long totalSize = 0;
        directoryPath = directoryPath.replace(share.getSmbPath().toUncPath(), "");
        directoryPath = directoryPath.replace("\\", "/");
        boolean isDirectory = share.getFileInformation(directoryPath).getStandardInformation().isDirectory();

        if (!isDirectory) {
            try (File file = share.openFile(directoryPath, EnumSet.of(AccessMask.GENERIC_READ), null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null)) {
                return file.getFileInformation().getStandardInformation().getEndOfFile();
            }
        }

        List<Future<Long>> futures = new ArrayList<>();
        for (FileIdBothDirectoryInformation fileInfo : share.list(directoryPath)) {
            String fileName = fileInfo.getFileName();
            if (fileName.equals(".") || fileName.equals("..")) {
                continue;
            }

            String filePath = directoryPath + "/" + fileName;
            futures.add(executorService.submit(() -> {
                if (!fileInfo.getFileName().contains(".")) {
                    return smbFolderSize(share, filePath);
                } else {
                    try (File file = share.openFile(filePath, EnumSet.of(AccessMask.GENERIC_READ), null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null)) {
                        return file.getFileInformation().getStandardInformation().getEndOfFile();
                    }
                }
            }));
        }

        for (Future<Long> future : futures) {
            try {
                totalSize += future.get();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        executorService.shutdown();
        return totalSize;
    }

//    public static long smbFolderSize(DiskShare share, String directoryPath) {
//        long totalSize = 0;
//        directoryPath = directoryPath.replace(share.getSmbPath().toUncPath(), "");
//        directoryPath = directoryPath.replace("\\", "/");
//        boolean isDirectory = share.getFileInformation(directoryPath).getStandardInformation().isDirectory();
//        if (!isDirectory) {
//            File file = share.openFile(directoryPath, EnumSet.of(
//                            AccessMask.GENERIC_READ)
//                    , null
//                    , SMB2ShareAccess.ALL
//                    , SMB2CreateDisposition.FILE_OPEN
//                    , null);
//            totalSize += file.getFileInformation().getStandardInformation().getEndOfFile();
//            file.closeSilently();
//            return totalSize;
//        }
//        for (FileIdBothDirectoryInformation fileInfo : share.list(directoryPath)) {
//            String fileName = fileInfo.getFileName();
//            if (fileName.equals(".") || fileName.equals("..")) {
//                continue;
//            }
//
//            String filePath = directoryPath + "/" + fileName;
//            if (!fileInfo.getFileName().contains(".")) {
//                totalSize += smbFolderSize(share, filePath);
//            } else {
//                File file = share.openFile(filePath, EnumSet.of(
//                                AccessMask.GENERIC_READ)
//                        , null
//                        , SMB2ShareAccess.ALL
//                        , SMB2CreateDisposition.FILE_OPEN
//                        , null);
//                totalSize += file.getFileInformation().getStandardInformation().getEndOfFile();
//                file.closeSilently();
//            }
//        }
//        return totalSize;
//    }

    public static boolean isDirectoryOrFileExists(String pathString) {
        boolean exists = false;
        Path path = Paths.get(pathString);
        if (Files.exists(path)) {
            exists = true;
        }
        return exists;
    }

    public static String encodeValue(String value) {
        try {
            return URLEncoder.encode(value, StandardCharsets.UTF_8.toString());
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
    }

    public static String decode(String value) {
        try {
            return URLDecoder.decode(value, StandardCharsets.UTF_8.toString());
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
    }
}
