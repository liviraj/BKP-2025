package com.histo.gridion.config;

import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;

import java.io.IOException;

public class DiskShareConfig {
    private DiskShare diskShare;
    private SMBClient client;
    private Connection connection;
    private Session session;

    public DiskShareConfig(String sourceServer, String sourceShare, String smbUsername
                           , String smbPassword, String smbDomain
    ) {
        try {

            client = new SMBClient();
            connection = client.connect(sourceServer);
            AuthenticationContext authContextSource = new AuthenticationContext(smbUsername
                    , smbPassword.toCharArray()
                    , smbDomain);
            session = connection.authenticate(authContextSource);
            this.diskShare = (DiskShare) session.connectShare(sourceShare);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public DiskShare getDiskShare() {
        return diskShare;
    }

    public void setDiskShare(DiskShare diskShare) {
        this.diskShare = diskShare;
    }

    @Override
    public String toString() {
        return "DiskShareConfig{" +
                "sourceDiskShare=" + diskShare +
                '}';
    }

    public void close() throws Exception {
        if (diskShare != null) {
            diskShare.close();
        }
        if (session != null) {
            session.close();
        }
        if (connection != null) {
            connection.close();
        }
        if (client != null) {
            client.close();
        }
    }
}
