package com.histo.gridion.config;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:application.properties")
@NoArgsConstructor
@Getter
@Setter
@ToString
public class PropertyConfig {
    @Value("${gridion.automation.local-copy.source.username}")
    private String localCopySourceUsername;
    @Value("${gridion.automation.local-copy.source.password}")
    private String localCopySourcePassword;
    @Value("${gridion.automation.local-copy.destination.username}")
    private String localCopyDestUsername;
    @Value("${gridion.automation.local-copy.destination.password}")
    private String localCopyDestPassword;
    @Value("${gridion.automation.file-uploader-jar-path}")
    private String fileUploaderJarPath;
    @Value("${gridion.automation.gridion-file-data-organizer-jar-path}")
    private String gridIonFileDataOrganizerJarPath;
    @Value("${gridion.automation.md5checksum.jar.path}")
    private String md5ChecksumJarPath;
    @Value("${gridion.automation.data-path.source}")
    private String dataSourcePath;
    @Value("${gridion.automation.source.username}")
    private String sourceUsername;
    @Value("${gridion.automation.source.password}")
    private String sourcePassword;
    @Value("${gridion.automation.local-copy.destination.path}")
    private String localCopyDestinationPath;
    @Value("${gridion.report.smb.url}")
    private String reportSmbUrl;
    @Value("${gridion.report.smb.username}")
    private String reportSmbUsername;
    @Value("${gridion.report.smb.password}")
    private String reportSmbPassword;
    @Value("${gridion.report.smb.domain}")
    private String reportSmbDomain;
    @Value("${attribute.mail.username.attribute-name}")
    private String mailUsernameAttributeName;
    @Value("${gridion.nas.smb.username}")
    private String nasSmbUsername;
    @Value("${gridion.nas.smb.password}")
    private String nasSmbPassword;
    @Value("${smtp.mail.attribute.name.username}")
    private String smtpMailUserNameAttribute;
    @Value("${smtp.mail.attribute.name.password}")
    private String smtpMailPasswordAttribute;
    @Value("${spring.mail.host}")
    private String mailHost;
    @Value("${spring.mail.port}")
    private Integer mailPort;
    @Value("${base.url.pacbio}")
    private String pacbioBaseUrl;
}
