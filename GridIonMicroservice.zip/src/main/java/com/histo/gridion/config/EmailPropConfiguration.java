package com.histo.gridion.config;

import com.histo.gridion.model.EmailAttributeDetails;
import com.histo.gridion.service.impl.GridIonRunServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.web.context.annotation.SessionScope;

import java.util.Properties;

@Configuration
public class EmailPropConfiguration {
    @Autowired
    private PropertyConfig propertyConfig;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Bean
    @SessionScope
    public JavaMailSender getJavaMailSender() {
        GridIonRunServiceImpl runsService = new GridIonRunServiceImpl();
        EmailAttributeDetails mailAttributeDetails = runsService.getMailAttributeDetails(jdbcTemplate, propertyConfig);

        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        mailSender.setHost(propertyConfig.getMailHost());
        mailSender.setPort(propertyConfig.getMailPort());
        mailSender.setUsername(mailAttributeDetails.getSmtpUserName());
        mailSender.setPassword(mailAttributeDetails.getSmtpPassword());
        Properties props = mailSender.getJavaMailProperties();
        // props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.debug", "true");

        return mailSender;
    }
}
