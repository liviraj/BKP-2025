package com.histo.datacopier.config;

import lombok.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:application.properties")
@Getter @Setter @ToString
public class PropertyConfig {

    @Value("${pacbio.web.service.base-url}")
    private String pacbioWebServiceBaseUrl;
    @Value("${smb.domain.name}")
    private String smbDomainName;
    @Value("${illumina.grace-period.in-days}")
    private Integer illuminaGracePeriod;
    @Value("${pacbio.grace-period.in-days}")
    private Integer pacbioGracePeriod;
	public String getPacbioWebServiceBaseUrl() {
		return pacbioWebServiceBaseUrl;
	}
	public void setPacbioWebServiceBaseUrl(String pacbioWebServiceBaseUrl) {
		this.pacbioWebServiceBaseUrl = pacbioWebServiceBaseUrl;
	}
	public String getSmbDomainName() {
		return smbDomainName;
	}
	public void setSmbDomainName(String smbDomainName) {
		this.smbDomainName = smbDomainName;
	}
	public Integer getIlluminaGracePeriod() {
		return illuminaGracePeriod;
	}
	public void setIlluminaGracePeriod(Integer illuminaGracePeriod) {
		this.illuminaGracePeriod = illuminaGracePeriod;
	}
	public Integer getPacbioGracePeriod() {
		return pacbioGracePeriod;
	}
	public void setPacbioGracePeriod(Integer pacbioGracePeriod) {
		this.pacbioGracePeriod = pacbioGracePeriod;
	}
    
}
