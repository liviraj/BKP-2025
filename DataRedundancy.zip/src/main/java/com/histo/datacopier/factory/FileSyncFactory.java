package com.histo.datacopier.factory;

import com.histo.datacopier.model.MachineTypeEnum;
import com.histo.datacopier.process.FileSyncProcess;
import com.histo.datacopier.process.impl.IlluminaMiSeqSyncProcessImpl;
import com.histo.datacopier.process.impl.IlluminaNovaSeqSyncProcessImpl;
import com.histo.datacopier.process.impl.PacbioSyncProcessImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("fileSyncFactory")
public class FileSyncFactory {
    @Autowired
    PacbioSyncProcessImpl pacbioSyncProcessImpl;
    @Autowired
    IlluminaNovaSeqSyncProcessImpl illuminaNovaSeqSyncProcess;
    @Autowired
    IlluminaMiSeqSyncProcessImpl illuminaMiSeqSyncProcess;
    public FileSyncProcess getFileSyncProcess(MachineTypeEnum machine) {
        return switch (machine) {
            case PACBIO -> pacbioSyncProcessImpl;
            case ILLUMINA_NOVASEQ -> illuminaNovaSeqSyncProcess;
            case ILLUMINA_MISEQ -> illuminaMiSeqSyncProcess;
            default -> null;
        };

    }
}
