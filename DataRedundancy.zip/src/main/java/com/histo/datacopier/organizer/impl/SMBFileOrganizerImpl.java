package com.histo.datacopier.organizer.impl;

import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.mssmb2.SMBApiException;
import com.hierynomus.smbj.share.DiskShare;
import com.hierynomus.smbj.share.File;
import com.histo.datacopier.config.PropertyConfig;
import com.histo.datacopier.model.MachineTypeEnum;
import com.histo.datacopier.organizer.SMBFileOrganizer;
import jcifs.smb.SmbException;
import jcifs.smb.SmbFile;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.EnumSet;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Service
public class SMBFileOrganizerImpl implements SMBFileOrganizer {
    private static Logger LOGGER = LogManager.getLogger(SMBFileOrganizerImpl.class.getName());
    @Autowired
    PropertyConfig propertyConfig;

    @Override
    public void doSmbFileCopy(String sourcePath, String destinationPath, DiskShare sourceShare, DiskShare destinationShare, MachineTypeEnum machineType) throws IOException {
        sourcePath = sourcePath.replace(sourceShare.getSmbPath().toUncPath(), "");
        destinationPath = destinationPath.replace(destinationShare.getSmbPath().toUncPath(), "");
        sourcePath = sourcePath.replace("\\", "/");
        destinationPath = destinationPath.replace("\\", "/");

        List<FileIdBothDirectoryInformation> fileList = sourceShare.list(sourcePath + "/").stream().filter(
                fileInfo -> !fileInfo.getFileName().equals(".") && !fileInfo.getFileName().equals("..")
        ).toList();
        for (FileIdBothDirectoryInformation fileInfo : fileList) {
            String fileName = fileInfo.getFileName();
            if (fileName.contains("Reanalysis") || fileName.contains("html")) {
                continue;
            }

            String sourceFilePath;
            String destinationFilePath;
            if (!destinationShare.folderExists(destinationPath) && machineType == MachineTypeEnum.PACBIO) {
                destinationShare.mkdir(destinationPath);
            }
            if (fileName.contains(".")) {
                sourceFilePath = sourcePath + "/" + fileName;
                destinationFilePath = destinationPath + "/" + fileName;
            } else {
                sourceFilePath = sourcePath + "/" + fileName + "/";
                destinationFilePath = destinationPath + "/" + fileName + "/";
                fileName += "/"; // Adding '/' in directory
            }


            if (fileName.endsWith("/") || fileName.endsWith("\\")) {
                // It is a directory
                String[] desNestedDirectory = destinationFilePath.split("/");
                String currentDirectory = "";
                for (String directory : desNestedDirectory) {
                    currentDirectory += directory + "/";
                    if (!destinationShare.folderExists(currentDirectory)) {
                        destinationShare.mkdir(currentDirectory);
                    }
                }
                // destinationShare.mkdir(destinationFilePath);
                doSmbFileCopy(sourceFilePath, destinationFilePath, sourceShare, destinationShare, machineType);
            } else {
                // It is a file
                // Get the input stream for the source file
                File source = sourceShare.openFile(sourceFilePath, EnumSet.of(AccessMask.GENERIC_READ)
                        , null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null);
                InputStream inputStream = new BufferedInputStream(source.getInputStream());

                // Get the output stream for the destination file
                File destination = destinationShare.openFile(destinationFilePath, EnumSet.of(AccessMask.GENERIC_WRITE)
                        , null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_CREATE, null);
                OutputStream outputStream = new BufferedOutputStream(destination.getOutputStream());

                int bufferSize = 32768; // Adjust the buffer size as needed.

                // Read from the source and write to the destination
                byte[] buffer = new byte[bufferSize];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    byte[] dataChunk = new byte[bytesRead];
                    System.arraycopy(buffer, 0, dataChunk, 0, bytesRead);
                    outputStream.write(dataChunk);
                }

                // Close the streams and connections
                inputStream.close();
                outputStream.close();
                source.close();
                destination.close();
            }
        }
    }

    @Override
    public int calculateSamplesCount(String path, DiskShare diskShare) {
        int samplesCount = 0;
        path = path.replace(diskShare.getSmbPath().toUncPath(), "");
        path = path.replace("\\", "/");

        List<FileIdBothDirectoryInformation> fileList = diskShare.list(path + "/").stream().filter(
                fileInfo -> !fileInfo.getFileName().equals(".") && !fileInfo.getFileName().equals("..")
        ).toList();
        for (FileIdBothDirectoryInformation fileInfo : fileList) {
            String platPath = path.concat("/").concat(fileInfo.getFileName());
            List<FileIdBothDirectoryInformation> plateFileList = diskShare.list(platPath + "/").stream().filter(
                    plateFileInfo -> !plateFileInfo.getFileName().equals(".") && !plateFileInfo.getFileName().equals("..")
            ).toList();

            samplesCount += plateFileList.size();
        }
        return samplesCount;
    }

    @Override
    public boolean isFileValidUsingGracePeriod(Date creationDate) {
        Date currentDate = new Date();

        long diffInMillies = Math.abs(currentDate.getTime() - creationDate.getTime());
        long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
        return diff > propertyConfig.getIlluminaGracePeriod();
    }

    @Override
    public String getDurationBreakdown(long millis) {
        if (millis < 0) {
            throw new IllegalArgumentException("Duration must be greater than zero!");
        }

        long days = TimeUnit.MILLISECONDS.toDays(millis);
        millis -= TimeUnit.DAYS.toMillis(days);
        long hours = TimeUnit.MILLISECONDS.toHours(millis);
        millis -= TimeUnit.HOURS.toMillis(hours);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(millis);
        millis -= TimeUnit.MINUTES.toMillis(minutes);
        long seconds = TimeUnit.MILLISECONDS.toSeconds(millis);

        StringBuilder sb = new StringBuilder(64);
        sb.append(" Days ");
        sb.append(days);
        sb.append(hours);
        sb.append(" Hours ");
        sb.append(minutes);
        sb.append(" Minutes ");
        sb.append(seconds);
        sb.append(" Seconds");

        return (sb.toString());
    }

    @Override
    public String timeStampToString(Date date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
        return dateFormat.format(date);
    }

    @Override
    public boolean isMonthValidToChangeIsCopiedStatus(String month) {
        int fileMonth = Integer.valueOf(month);
        int currentMonth = Calendar.getInstance().get(Calendar.MONTH) + 1; // is zero based so added 1 - JAN=0, FEB=1 ...DEC=11
        return fileMonth == currentMonth ? false : true;
    }

    @Override
    public boolean isYearValidToChangeIsCopiedStatus(String year) {
        int fileYear = Integer.valueOf(year);
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        return fileYear == currentYear ? false : true;
    }

    @Override
    public long getSMBFileSize(DiskShare share, String directoryPath) throws SMBApiException {
        long totalSize = 0;
        directoryPath = directoryPath.replace(share.getSmbPath().toUncPath(), "");
        directoryPath = directoryPath.replace("\\", "/");
        for (FileIdBothDirectoryInformation fileInfo : share.list(directoryPath)) {
            String fileName = fileInfo.getFileName();
            if (fileName.equals(".") || fileName.equals("..") || fileName.contains("Reanalysis") || fileName.contains("html")) {
                continue;
            }

            String filePath = directoryPath + "/" + fileName;
            if (share.folderExists(filePath)) {
                totalSize += getSMBFileSize(share, filePath);
            } else {
                File file = share.openFile(filePath, EnumSet.of(
                                AccessMask.GENERIC_READ.GENERIC_READ)
                        , null
                        , SMB2ShareAccess.ALL
                        , SMB2CreateDisposition.FILE_OPEN.FILE_OPEN
                        , null);
                totalSize += file.getFileInformation().getStandardInformation().getEndOfFile();
                file.closeSilently();
            }
        }
        return totalSize;
    }

    @Override
    public void deleteSmbFile(DiskShare diskShare, String deletePath) throws SmbException {
        diskShare.rmdir(deletePath, true);
    }
}
