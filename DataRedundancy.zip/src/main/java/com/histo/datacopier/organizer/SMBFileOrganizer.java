package com.histo.datacopier.organizer;


import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.smbj.share.DiskShare;
import com.histo.datacopier.model.MachineTypeEnum;
import jcifs.smb.SmbException;
import jcifs.smb.SmbFile;

import java.io.IOException;
import java.util.Date;
import java.util.List;


public interface SMBFileOrganizer {
    public void doSmbFileCopy(String sourcePath, String destinationPath, DiskShare sourceShare, DiskShare destinationShare, MachineTypeEnum machineType) throws IOException;
    public boolean isFileValidUsingGracePeriod(Date creationDate);
    public String getDurationBreakdown(long millis);
    public String timeStampToString(Date date);
    public boolean isMonthValidToChangeIsCopiedStatus(String month);
    public boolean isYearValidToChangeIsCopiedStatus(String year);
    public long getSMBFileSize(DiskShare share, String directoryPath);
    public void deleteSmbFile(DiskShare diskShare, String deletePath) throws SmbException;

    public int calculateSamplesCount(String path, DiskShare diskShare);
}
