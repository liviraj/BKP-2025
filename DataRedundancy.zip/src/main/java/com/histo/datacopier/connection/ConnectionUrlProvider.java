package com.histo.datacopier.connection;

import com.histo.datacopier.config.PropertyConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("connectionUrlProvider")
public class ConnectionUrlProvider {
    @Autowired
    private PropertyConfig propertyConfig;

    // Illumina NOVASEQ URL
    public String getAllIlluminaNovaSeqSyncDetailsURL() {
        return propertyConfig.getPacbioWebServiceBaseUrl() + "/novaSeq/sync";
    }

    public String updateIlluminaNovaSeqSyncDetailsURL() {
        return propertyConfig.getPacbioWebServiceBaseUrl().concat("/novaSeq/sync");
    }

    public String syncIlluminaNovaSeqDetailsURL() {
        return propertyConfig.getPacbioWebServiceBaseUrl().concat("/novaSeq/detailsSync");
    }

    public String updateIlluminaNovaSeqExperimentStatus() {
        return propertyConfig.getPacbioWebServiceBaseUrl().concat("/status/novaSeq/experimentStatus");
    }

    public String updateIlluminaNovaSeqMachineStatus() {
        return propertyConfig.getPacbioWebServiceBaseUrl().concat("/status/novaSeq/machineStatus");
    }

    public String updateIlluminaNovaSeqMonthStatus() {
        return propertyConfig.getPacbioWebServiceBaseUrl().concat("/status/novaSeq/monthStatus");
    }

    public String updateIlluminaNovaSeqYearStatus() {
        return propertyConfig.getPacbioWebServiceBaseUrl().concat("/status/novaSeq/yearStatus");
    }

    public String getAllIlluminaMiSeqSyncDetailsURL() {
        return propertyConfig.getPacbioWebServiceBaseUrl() + "/miSeq/sync";
    }

    public String updateIlluminaMiSeqSyncDetailsURL() {
        return propertyConfig.getPacbioWebServiceBaseUrl().concat("/miSeq/sync");
    }

    public String syncIlluminaMiSeqDetailsURL() {
        return propertyConfig.getPacbioWebServiceBaseUrl().concat("/miSeq/detailsSync");
    }

    public String updateIlluminaMiSeqExperimentStatus() {
        return propertyConfig.getPacbioWebServiceBaseUrl().concat("/status/miSeq/experimentStatus");
    }

    public String updateIlluminaMiSeqMachineStatus() {
        return propertyConfig.getPacbioWebServiceBaseUrl().concat("/status/miSeq/machineStatus");
    }

    public String updateIlluminaMiSeqMonthStatus() {
        return propertyConfig.getPacbioWebServiceBaseUrl().concat("/status/miSeq/monthStatus");
    }

    public String updateIlluminaMiSeqYearStatus() {
        return propertyConfig.getPacbioWebServiceBaseUrl().concat("/status/miSeq/yearStatus");
    }

    public String insertIlluminaBackupLogURL() {
        return propertyConfig.getPacbioWebServiceBaseUrl().concat("/illumina/log");
    }

    // pacbio URL
    public String getAllPacbioSyncDetailsURL() {
        return propertyConfig.getPacbioWebServiceBaseUrl().concat("/pacbio/sync");
    }

    public String updatePacbioSyncDetailsURL() {
        return propertyConfig.getPacbioWebServiceBaseUrl().concat("/pacbio/sync");
    }

    public String syncPacbioDetailsURL() {
        return propertyConfig.getPacbioWebServiceBaseUrl().concat("/pacbio/detailsSync");
    }

    public String updatePacbioJobStatus() {
        return propertyConfig.getPacbioWebServiceBaseUrl().concat("/status/pacbio/jobStatus");
    }

    public String insertPacbioBackupLogURL() {
        return propertyConfig.getPacbioWebServiceBaseUrl().concat("/pacbio/log");
    }
}
