package com.histo.datacopier.connection;

import com.histo.datacopier.model.*;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

@Component("connectionIntermittent")
public class ConnectionIntermittent {
    private static Logger LOGGER = LogManager.getLogger(ConnectionIntermittent.class.getName());
    @Autowired
    private ConnectionUrlProvider connectionUrlProvider;

    public IlluminaMasterData callGetAllIlluminaNovaSeqSyncDetails() {
        LOGGER.info("getIlluminaSyncDetails() Request Info. URL:{}, Method: {}", connectionUrlProvider.getAllIlluminaNovaSeqSyncDetailsURL(), HttpMethod.GET);
        IlluminaMasterData illuminaMasterData = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(trustSSL()))
                .build()
                .get()
                .uri(connectionUrlProvider.getAllIlluminaNovaSeqSyncDetailsURL())
                .retrieve()
                .bodyToMono(IlluminaMasterData.class)
                .block();
        return illuminaMasterData;
    }

    public String callUpdateIlluminaNovaSeqSyncDetails(IlluminaMasterData illuminaSyncDetails) {
        LOGGER.info("getIlluminaSyncDetails() Request Info. URL:{}, Method: {}", connectionUrlProvider.updateIlluminaNovaSeqSyncDetailsURL(), HttpMethod.PUT);
        String responseMsg = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(trustSSL()))
                .build()
                .put()
                .uri(connectionUrlProvider.getAllIlluminaNovaSeqSyncDetailsURL())
                .bodyValue(illuminaSyncDetails)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return responseMsg;
    }

    public ResponseEntity<String> callSyncIlluminaNovaSeqDetails(IlluminaMasterData allIlluminaSyncDetails) {
        LOGGER.info("callInsertPacbioBackupLog() Request Info. URL:{}, Method: {}", connectionUrlProvider.syncIlluminaNovaSeqDetailsURL(), HttpMethod.POST);
        ResponseEntity<String> response = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(trustSSL()))
                .build()
                .post()
                .uri(connectionUrlProvider.syncIlluminaNovaSeqDetailsURL())
                .bodyValue(allIlluminaSyncDetails)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .toEntity(String.class)
                .block();
        return response;
    }

    public String callUpdateIlluminaNovaSeqExperimentStatus(IlluminaExperimentUpdate experiment) {
        LOGGER.info("callUpdateIlluminaExperimentStatus() Request Info. URL:{}, Method: {}", connectionUrlProvider.updateIlluminaNovaSeqExperimentStatus(), HttpMethod.PUT);
        String responseMsg = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(trustSSL()))
                .build()
                .put()
                .uri(connectionUrlProvider.updateIlluminaNovaSeqExperimentStatus())
                .bodyValue(experiment)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return responseMsg;
    }

    public String callUpdateIlluminaNovaSeqMachineStatus(IlluminaMachineUpdate machine) {
        LOGGER.info("callUpdateIlluminaMachineStatus() Request Info. URL:{}, Method: {}", connectionUrlProvider.updateIlluminaNovaSeqMachineStatus(), HttpMethod.PUT);
        String responseMsg = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(trustSSL()))
                .build()
                .put()
                .uri(connectionUrlProvider.updateIlluminaNovaSeqMachineStatus())
                .bodyValue(machine)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return responseMsg;
    }

    public String callUpdateIlluminaNovaSeqMonthStatus(IlluminaMonthUpdate month) {
        LOGGER.info("callUpdateIlluminaMonthStatus() Request Info. URL:{}, Method: {}", connectionUrlProvider.updateIlluminaNovaSeqMonthStatus(), HttpMethod.PUT);
        String responseMsg = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(trustSSL()))
                .build()
                .put()
                .uri(connectionUrlProvider.updateIlluminaNovaSeqMonthStatus())
                .bodyValue(month)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return responseMsg;
    }

    public String callUpdateIlluminaNovaSeqYearStatus(IlluminaYearUpdate year) {
        LOGGER.info("callUpdateIlluminaYearStatus() Request Info. URL:{}, Method: {}", connectionUrlProvider.updateIlluminaNovaSeqYearStatus(), HttpMethod.PUT);
        String responseMsg = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(trustSSL()))
                .build()
                .put()
                .uri(connectionUrlProvider.updateIlluminaNovaSeqYearStatus())
                .bodyValue(year)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return responseMsg;
    }

    public IlluminaMasterData callGetAllIlluminaMiSeqSyncDetails() {
        LOGGER.info("getIlluminaSyncDetails() Request Info. URL:{}, Method: {}", connectionUrlProvider.getAllIlluminaMiSeqSyncDetailsURL(), HttpMethod.GET);
        IlluminaMasterData illuminaMasterData = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(trustSSL()))
                .build()
                .get()
                .uri(connectionUrlProvider.getAllIlluminaMiSeqSyncDetailsURL())
                .retrieve()
                .bodyToMono(IlluminaMasterData.class)
                .block();
        return illuminaMasterData;
    }

    public String callUpdateIlluminaMiSeqSyncDetails(IlluminaMasterData illuminaSyncDetails) {
        LOGGER.info("getIlluminaSyncDetails() Request Info. URL:{}, Method: {}", connectionUrlProvider.updateIlluminaMiSeqSyncDetailsURL(), HttpMethod.PUT);
        String responseMsg = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(trustSSL()))
                .build()
                .put()
                .uri(connectionUrlProvider.getAllIlluminaMiSeqSyncDetailsURL())
                .bodyValue(illuminaSyncDetails)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return responseMsg;
    }

    public ResponseEntity<String> callSyncIlluminaMiSeqDetails(IlluminaMasterData allIlluminaSyncDetails) {
        LOGGER.info("callInsertPacbioBackupLog() Request Info. URL:{}, Method: {}", connectionUrlProvider.syncIlluminaMiSeqDetailsURL(), HttpMethod.POST);
        ResponseEntity<String> response = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(trustSSL()))
                .build()
                .post()
                .uri(connectionUrlProvider.syncIlluminaMiSeqDetailsURL())
                .bodyValue(allIlluminaSyncDetails)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .toEntity(String.class)
                .block();
        return response;
    }

    public String callUpdateIlluminaMiSeqExperimentStatus(IlluminaExperimentUpdate experiment) {
        LOGGER.info("callUpdateIlluminaExperimentStatus() Request Info. URL:{}, Method: {}", connectionUrlProvider.updateIlluminaMiSeqExperimentStatus(), HttpMethod.PUT);
        String responseMsg = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(trustSSL()))
                .build()
                .put()
                .uri(connectionUrlProvider.updateIlluminaMiSeqExperimentStatus())
                .bodyValue(experiment)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return responseMsg;
    }

    public String callUpdateIlluminaMiSeqMachineStatus(IlluminaMachineUpdate machine) {
        LOGGER.info("callUpdateIlluminaMachineStatus() Request Info. URL:{}, Method: {}", connectionUrlProvider.updateIlluminaMiSeqMachineStatus(), HttpMethod.PUT);
        String responseMsg = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(trustSSL()))
                .build()
                .put()
                .uri(connectionUrlProvider.updateIlluminaMiSeqMachineStatus())
                .bodyValue(machine)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return responseMsg;
    }

    public String callUpdateIlluminaMiSeqMonthStatus(IlluminaMonthUpdate month) {
        LOGGER.info("callUpdateIlluminaMonthStatus() Request Info. URL:{}, Method: {}", connectionUrlProvider.updateIlluminaMiSeqMonthStatus(), HttpMethod.PUT);
        String responseMsg = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(trustSSL()))
                .build()
                .put()
                .uri(connectionUrlProvider.updateIlluminaMiSeqMonthStatus())
                .bodyValue(month)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return responseMsg;
    }

    public String callUpdateIlluminaMiSeqYearStatus(IlluminaYearUpdate year) {
        LOGGER.info("callUpdateIlluminaYearStatus() Request Info. URL:{}, Method: {}", connectionUrlProvider.updateIlluminaMiSeqYearStatus(), HttpMethod.PUT);
        String responseMsg = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(trustSSL()))
                .build()
                .put()
                .uri(connectionUrlProvider.updateIlluminaMiSeqYearStatus())
                .bodyValue(year)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return responseMsg;
    }

    public String callInsertIlluminaBackupLog(IlluminaDataSecondaryBackupLog backupLog) {
        LOGGER.info("callInsertIlluminaBackupLog() Request Info. URL:{}, Method: {}", connectionUrlProvider.insertIlluminaBackupLogURL(), HttpMethod.POST);
        String responseMsg = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(trustSSL()))
                .build()
                .post()
                .uri(connectionUrlProvider.insertIlluminaBackupLogURL())
                .bodyValue(backupLog)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return responseMsg;
    }

    public PacbioMasterData callGetAllPacbioSyncDetails() {
        LOGGER.info("getIlluminaSyncDetails() Request Info. URL:{}, Method: {}", connectionUrlProvider.getAllPacbioSyncDetailsURL(), HttpMethod.GET);
        PacbioMasterData pacbioMasterData = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(trustSSL()))
                .build()
                .get()
                .uri(connectionUrlProvider.getAllPacbioSyncDetailsURL())
                .retrieve()
                .bodyToMono(PacbioMasterData.class)
                .block();
        return pacbioMasterData;
    }

    public String callInsertPacbioBackupLog(PacbioDataSecondaryBackupLog backupLog) {
        LOGGER.info("callInsertPacbioBackupLog() Request Info. URL:{}, Method: {}", connectionUrlProvider.insertPacbioBackupLogURL(), HttpMethod.POST);
        String responseMsg = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(trustSSL()))
                .build()
                .post()
                .uri(connectionUrlProvider.insertPacbioBackupLogURL())
                .bodyValue(backupLog)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return responseMsg;
    }

    public String callUpdatePacbioSyncDetails(PacbioMasterData pacbioMasterData) {
        LOGGER.info("getIlluminaSyncDetails() Request Info. URL:{}, Method: {}", connectionUrlProvider.updatePacbioSyncDetailsURL(), HttpMethod.PUT);
        String responseMsg = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(trustSSL()))
                .build()
                .put()
                .uri(connectionUrlProvider.updatePacbioSyncDetailsURL())
                .bodyValue(pacbioMasterData)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return responseMsg;
    }

    public ResponseEntity<String> callSyncPacbioDetails(PacbioMasterData pacbioMasterData) {
        LOGGER.info("callInsertPacbioBackupLog() Request Info. URL:{}, Method: {}", connectionUrlProvider.syncPacbioDetailsURL(), HttpMethod.POST);
        ResponseEntity<String> response = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(trustSSL()))
                .build()
                .post()
                .uri(connectionUrlProvider.syncPacbioDetailsURL())
                .bodyValue(pacbioMasterData)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .toEntity(String.class)
                .block();
        return response;
    }

    public String callUpdatePacbioJobStatus(PacbioJobStatusUpdate job) {
        LOGGER.info("callUpdatePacbioJobStatus() Request Info. URL:{}, Method: {}", connectionUrlProvider.updatePacbioJobStatus(), HttpMethod.PUT);
        String responseMsg = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(trustSSL()))
                .build()
                .put()
                .uri(connectionUrlProvider.updatePacbioJobStatus())
                .bodyValue(job)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return responseMsg;
    }

    private HttpClient trustSSL() {
        // Create a custom SSLContext that trusts all certificates
        SslContextBuilder sslContextBuilder = SslContextBuilder.forClient().trustManager(InsecureTrustManagerFactory.INSTANCE);
        HttpClient httpClient = HttpClient.create().secure(sslContextSpec -> sslContextSpec.sslContext(sslContextBuilder));

        return  httpClient;
    }
}
