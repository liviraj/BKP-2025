package com.histo.datacopier;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.histo.datacopier.connection.ConnectionIntermittent;
import com.histo.datacopier.factory.FileSyncFactory;
import com.histo.datacopier.model.InputArgs;
import com.histo.datacopier.process.FileSyncProcess;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

@Component("fileSyncProcessMain")
public class FileSyncProcessMain {
    public static Logger LOGGER = LogManager.getLogger(FileSyncProcessMain.class.getName());

    @Autowired
    private FileSyncFactory fileSyncFactory;
    @Autowired
    private ConnectionIntermittent connectionIntermittent;

    public void fileSyncMain(String args[]) {
        InputArgs inputArgs = null;

        /*Illumina miseq test args:
        {"sourceServer":"prodnas01.histogenetics.com","destinationServer":"prodnas01.histogenetics.com","sourceShare":"APP_Test","destinationShare":"APP_Test","sourceLocation":"source\illumina\MiSeqOutputFiles\PreProcessed","destinationLocation":"destination\illumina\MiSeqOutputFiles\PreProcessed","sourceUsername":"cloudsync","sourcePassword":"H1st0.Cloud","destinationUsername":"cloudsync","destinationPassword":"H1st0.Cloud","machineType":"ILLUMINA_MISEQ"}

        Illuminsa novaseq test args
        {"sourceServer":"prodnas01.histogenetics.com","destinationServer":"prodnas01.histogenetics.com","sourceShare":"APP_Test","destinationShare":"APP_Test","sourceLocation":"source\illumina\NovaSeqOutput\PreProcessed","destinationLocation":"destination\illumina\NovaSeqOutput\PreProcessed","sourceUsername":"cloudsync","sourcePassword":"H1st0.Cloud","destinationUsername":"cloudsync","destinationPassword":"H1st0.Cloud","machineType":"ILLUMINA_NOVASEQ"}
        Pacbio test args:
        {"sourceServer":"prodnas01.histogenetics.com","destinationServer":"prodnas01.histogenetics.com","sourceShare":"APP_Test","destinationShare":"APP_Test","sourceLocation":"source\pacbiojobs","destinationLocation":"destination\pacbiojobs","sourceUsername":"cloudsync","sourcePassword":"H1st0.Cloud","destinationUsername":"cloudsync","destinationPassword":"H1st0.Cloud","machineType":"PACBIO"}*/
        try {
            if (StringUtils.isAllEmpty(args)) { // Checking if args is empty
                LOGGER.debug("Missing arguments. Argument List:" + Arrays.toString(args));
                System.exit(0);
            }

            LOGGER.info("SMRTPortalViewer Arguments: {}", Arrays.toString(args));
            args[0] = args[0].replaceAll("[{}]", "");
            args = args[0].split(",");

            Map<String, String> argInput = Arrays.asList(args).stream().map(arg -> arg.split(":"))
                    .filter(arg -> arg.length == 2)
                    .collect(Collectors.toMap(arg -> arg[0].trim(), arg -> arg[1].trim()));
            inputArgs = new ObjectMapper().convertValue(argInput, InputArgs.class); // Mapping args to InputArgs
            if (inputArgs.getSourceLocation().substring(0,1).equals("/") || inputArgs.getSourceLocation().substring(0,1).equals("\\")){
                inputArgs.setSourceLocation(inputArgs.getSourceLocation().substring(0,0)+""+inputArgs.getSourceLocation().substring(1));
            }
            if (inputArgs.getDestinationLocation().substring(0,1).equals("/") || inputArgs.getDestinationLocation().substring(0,1).equals("\\")){
                inputArgs.setDestinationLocation(inputArgs.getDestinationLocation().substring(0,0)+""+inputArgs.getDestinationLocation().substring(1));
            }
            LOGGER.info("Mapped input args: {}", inputArgs);

            FileSyncProcess process = fileSyncFactory.getFileSyncProcess(inputArgs.getMachineType()); // creating instance of Pacbio/Illumina
            process.doFileSync(inputArgs); // call sync process
        } catch (Exception e) {
            LOGGER.error("fileSyncMain() Error: {}", e);
        }
    }
}
