package com.histo.datacopier.process.impl;

import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.smbj.common.SmbPath;
import com.histo.datacopier.config.PropertyConfig;
import com.histo.datacopier.connection.ConnectionIntermittent;
import com.histo.datacopier.model.*;
import com.histo.datacopier.organizer.SMBFileOrganizer;
import com.histo.datacopier.process.FileSyncProcess;
import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbException;
import jcifs.smb.SmbFile;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Component("pacbioSyncProcessImpl")
public class PacbioSyncProcessImpl implements FileSyncProcess {
    private static Logger LOGGER = LogManager.getLogger(PacbioSyncProcessImpl.class.getName());

    @Autowired
    private PropertyConfig propertyConfig;
    @Autowired
    private ConnectionIntermittent connectionIntermittent;
    @Autowired
    private SMBFileOrganizer smbFileOrganizer;

    @Override
    public void doFileSync(InputArgs input) {

        try {
            InputInfoParam inputInfoParam = new InputInfoParam(input, propertyConfig);
            PacbioMasterData allPacbioSyncDetails = connectionIntermittent.callGetAllPacbioSyncDetails();
            allPacbioSyncDetails = allPacbioSyncDetails == null
                    ? constructPacbioSyncDetails(input, inputInfoParam) : constructPacbioSyncDetails(input, inputInfoParam, allPacbioSyncDetails);
            if (allPacbioSyncDetails == null) {
                LOGGER.error("doFileSync() In Pacbio data construction is failed");
                System.exit(0);
            }
           // ResponseEntity<String> response = connectionIntermittent.callSyncPacbioDetails(allPacbioSyncDetails); // sync/update/create the folder details

//            if (response.getStatusCodeValue() != HttpStatus.OK.value()) {
//                LOGGER.error("fileSyncMain() Error: {}", response.getBody());
//                System.exit(0);
//            }

            SmbPath sourceSmbPath = inputInfoParam.getSourceShare().getSmbPath();
            String sourceParentPath = sourceSmbPath.toUncPath().concat("\\").concat(input.getSourceLocation());
            SmbPath destinationSmbPath = inputInfoParam.getDestinationShare().getSmbPath();
            String destinationParentPath = destinationSmbPath.toUncPath().concat("\\").concat(input.getDestinationLocation());

            if (!inputInfoParam.getSourceShare().folderExists(input.getSourceLocation().replace("\\", "/"))) {
                LOGGER.error("Failed: Invalid Source Folder -> " + sourceParentPath.replace("/", "\\"));
                System.exit(0);
            }
            if (!inputInfoParam.getDestinationShare().folderExists(input.getDestinationLocation().replace("\\", "/"))) {
                LOGGER.error("Failed: Invalid Destination Folder -> " + destinationParentPath.replace("/", "\\"));
                System.exit(0);
            }

            PacbioMasterData pacbioMasterData = connectionIntermittent.callGetAllPacbioSyncDetails();
            if (pacbioMasterData == null) {
                LOGGER.debug("Pacbio doFileSync(). Pacbio detail is empty");
            }

            // file sync process start
            LOGGER.info("Pacbio sync process started");
            long startProcess = System.currentTimeMillis(); // start time
            int jobIndex = 0;
            for (PacbioJobsItem jobsItem : pacbioMasterData.getJobs()) {
                jobIndex = pacbioMasterData.getJobs().indexOf(jobsItem);
                if (!jobsItem.isCopied()) {
                    String jobPath = sourceParentPath.concat("\\")
                            .concat(jobsItem.getJobId());
                    boolean jobIdFileIeExist = inputInfoParam.getSourceShare().folderExists(
                            input.getSourceLocation().replace("\\", "/")
                                    .concat("/")
                                    .concat(jobsItem.getJobId()));
                    if (!jobIdFileIeExist) {
                        LOGGER.error("Pacbio job id path is not exists. Path: {}", jobPath.replace("/", "\\"));
                        continue;
                    }
                    Date jobCreationTime = inputInfoParam.getSourceShare().getFileInformation(input.getSourceLocation().replace("\\", "/")
                            .concat("/")
                            .concat(jobsItem.getJobId())).getBasicInformation().getCreationTime().toDate();
                    /*if (!smbFileOrganizer.isFileValidUsingGracePeriod(jobCreationTime)) {
                        LOGGER.info("Pacbio job is not valid by grace period. Path: {}", jobPath.replace("/", "\\"));
                        continue;
                    }*/
                    String destinationCopyPath = destinationParentPath.concat("\\")
                            .concat(jobsItem.getJobId());
                    boolean isExistDestinationCopyFile = inputInfoParam.getDestinationShare().folderExists(
                            input.getDestinationLocation().replace("\\", "/")
                                    .concat("/")
                                    .concat(jobsItem.getJobId())
                    );
                    if (isExistDestinationCopyFile) {
                        if (smbFileOrganizer.getSMBFileSize(inputInfoParam.getSourceShare(), jobPath)
                                == smbFileOrganizer.getSMBFileSize(inputInfoParam.getDestinationShare(), destinationCopyPath)) {
                            LOGGER.info("Destination experiment size is equal source experiment. Source: {}, Destination:{}"
                                    , jobPath.replace("/", "\\"), destinationCopyPath.replace("/", "\\"));
                            pacbioMasterData.getJobs().get(jobIndex).setCopied(true);
                            PacbioDataSecondaryBackupLog backupLog = new PacbioDataSecondaryBackupLog(jobsItem.getJobId()
                                    , jobPath.replace("/", "\\"), destinationCopyPath.replace("/", "\\"), smbFileOrganizer.timeStampToString(new Date()));
                          //  connectionIntermittent.callInsertPacbioBackupLog(backupLog);
                            PacbioJobStatusUpdate jobStatusUpdate = new PacbioJobStatusUpdate(pacbioMasterData.getId(), jobIndex, jobsItem.getJobId());
                            // String responseMsg = connectionIntermittent.callUpdatePacbioJobStatus(jobStatusUpdate);
                          //  LOGGER.info("Update pacbio job status response is : {}", responseMsg);
                            continue;
                        } else {
                            String deleteJobPath = input.getDestinationLocation().replace("\\", "/")
                                    .concat("/")
                                    .concat(jobsItem.getJobId());
                            // delete destination file
                            smbFileOrganizer.deleteSmbFile(inputInfoParam.getDestinationShare(), deleteJobPath);
                        }
                    }

                    smbFileOrganizer.doSmbFileCopy(jobPath, destinationCopyPath, inputInfoParam.getSourceShare(), inputInfoParam.getDestinationShare(), input.getMachineType()); // File copy process happen
                    long sourceSmbFileSize = smbFileOrganizer.getSMBFileSize(inputInfoParam.getSourceShare(), jobPath);
                    if (sourceSmbFileSize == 0 || !inputInfoParam.getDestinationShare().folderExists(
                            input.getDestinationLocation().replace("\\", "/")
                                    .concat("/")
                                    .concat(jobsItem.getJobId())
                    )) {
                        LOGGER.info("The source file size is zero OR Destination location not exist. Location: {}", destinationCopyPath);
                        continue;
                    }
                    long destinationSmbFileSize = smbFileOrganizer.getSMBFileSize(inputInfoParam.getDestinationShare(), destinationCopyPath);
                    LOGGER.info("Source smb file size in Bytes: {}. Destination smb file size Bytes: {}", sourceSmbFileSize, destinationSmbFileSize);
                    boolean isFileCopied = sourceSmbFileSize == destinationSmbFileSize;
                    if (isFileCopied) {
                        pacbioMasterData.getJobs().get(jobIndex).setCopied(true);
                        PacbioDataSecondaryBackupLog backupLog = new PacbioDataSecondaryBackupLog(jobsItem.getJobId()
                                , jobPath.replace("/", "\\"), destinationCopyPath.replace("/", "\\"), smbFileOrganizer.timeStampToString(new Date()));
                        connectionIntermittent.callInsertPacbioBackupLog(backupLog);
                       // PacbioJobStatusUpdate jobStatusUpdate = new PacbioJobStatusUpdate(pacbioMasterData.getId(), jobIndex, jobsItem.getJobId());
                       // String responseMsg = connectionIntermittent.callUpdatePacbioJobStatus(jobStatusUpdate);
                       // LOGGER.info("Update pacbio job status response is : {}", responseMsg);
                    }
                }
            }
            LOGGER.info("Pacbio sync process completed");
            long endProcess = System.currentTimeMillis(); // end process
            LOGGER.info("Pacbio sync process taken time is: {}", smbFileOrganizer.getDurationBreakdown(endProcess - startProcess));
            System.exit(0);
        } catch (Exception e) {
            LOGGER.error("Pacbio doFileSync() error: {}", e);
        }
    }

    private PacbioMasterData constructPacbioSyncDetails(InputArgs inputArgs, InputInfoParam inputInfoParam, PacbioMasterData pacbioMasterData) throws SmbException, MalformedURLException {
        PacbioMasterData filePacbioMasterData = constructPacbioSyncDetails(inputArgs, inputInfoParam);
        if (filePacbioMasterData == null) {
            return null;
        }
        List<PacbioJobsItem> newPacbioJobsItems = filePacbioMasterData.getJobs().stream().filter(
                job -> !pacbioMasterData.getJobs().contains(job)
        ).collect(Collectors.toList());

        if (newPacbioJobsItems.size() > 0) {
            pacbioMasterData.getJobs().addAll(newPacbioJobsItems);
        }
        return pacbioMasterData;
    }

    // create new pacbio details
    private PacbioMasterData constructPacbioSyncDetails(InputArgs inputArgs, InputInfoParam inputInfoParam) {
        boolean isSourceExists = inputInfoParam.getSourceShare().folderExists(inputArgs.getSourceLocation().replace("\\", "/"));
        String sourceBasePath = inputInfoParam.getSourceShare().getSmbPath().toUncPath().concat(inputArgs.getSourceLocation());
        if (!isSourceExists) {
            LOGGER.error("Failed: Invalid Source Folder -> " + sourceBasePath.replace("/", "\\"));
            return null;
        }
        List<FileIdBothDirectoryInformation> smbPabioJobFiles = inputInfoParam.getSourceShare().list(inputArgs.getSourceLocation());
        if (smbPabioJobFiles.size() == 0) {
            return null;
        }

        List<PacbioJobsItem> pacbioJobsItems = new ArrayList<>();
        for (FileIdBothDirectoryInformation jobIdFile : smbPabioJobFiles) {
            if (jobIdFile.getFileName().equals(".") || jobIdFile.getFileName().equals("..")) {
                continue;
            }
            PacbioJobsItem jobsItem = new PacbioJobsItem();
            jobsItem.setJobId(jobIdFile.getFileName());
            jobsItem.setCopied(false);

            pacbioJobsItems.add(jobsItem);
        }
        PacbioMasterData pacbioMasterData = new PacbioMasterData();
        pacbioMasterData.setJobs(pacbioJobsItems);
        return pacbioMasterData;
    }
}
