package com.histo.datacopier.process;

import com.histo.datacopier.model.InputArgs;

public interface FileSyncProcess {
    public void doFileSync(InputArgs input);
}
