package com.histo.datacopier.process.impl;

import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.smbj.common.SmbPath;
import com.histo.datacopier.config.PropertyConfig;
import com.histo.datacopier.connection.ConnectionIntermittent;
import com.histo.datacopier.model.*;
import com.histo.datacopier.organizer.SMBFileOrganizer;
import com.histo.datacopier.process.FileSyncProcess;
import jcifs.smb.SmbException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Component("IlluminaMiSeqSyncProcessImpl")
public class IlluminaMiSeqSyncProcessImpl implements FileSyncProcess {
    private static Logger LOGGER = LogManager.getLogger(IlluminaMiSeqSyncProcessImpl.class.getName());

    @Autowired
    private PropertyConfig propertyConfig;
    @Autowired
    private ConnectionIntermittent connectionIntermittent;
    @Autowired
    private SMBFileOrganizer smbFileOrganizer;

    @Override
    public void doFileSync(InputArgs input) {

        try {
            InputInfoParam inputInfoParam = new InputInfoParam(input, propertyConfig);

            IlluminaMasterData allIlluminaSyncDetails = connectionIntermittent.callGetAllIlluminaMiSeqSyncDetails();
            allIlluminaSyncDetails = allIlluminaSyncDetails == null
                    ? constructIlluminaSyncDetails(input, inputInfoParam) : constructIlluminaSyncDetails(input, inputInfoParam, allIlluminaSyncDetails);
            if (allIlluminaSyncDetails == null) {
                LOGGER.error("doFileSync() Illumina data construction failed.");
                System.exit(0);
            }
            ResponseEntity<String> response = connectionIntermittent.callSyncIlluminaMiSeqDetails(allIlluminaSyncDetails); // sync/update/create the folder details

            if (response.getStatusCodeValue() != HttpStatus.OK.value()) {
                LOGGER.error("fileSyncMain() Error: {}", response.getBody());
                System.exit(0);
            }
            SmbPath sourceSmbPath = inputInfoParam.getSourceShare().getSmbPath();
            String sourceParentPath = sourceSmbPath.toUncPath().concat("\\").concat(input.getSourceLocation());
            SmbPath destinationSmbPath = inputInfoParam.getDestinationShare().getSmbPath();
            String destinationParentPath = destinationSmbPath.toUncPath().concat("\\").concat(input.getDestinationLocation());
            if (!inputInfoParam.getSourceShare().folderExists(input.getSourceLocation().replace("\\", "/"))) {
                LOGGER.error("Failed: Invalid Source Folder -> " + sourceParentPath.replace("/", "\\"));
                System.exit(0);
            }
            if (!inputInfoParam.getDestinationShare().folderExists(input.getDestinationLocation().replace("\\", "/"))) {
                LOGGER.error("Failed: Invalid Destination Folder -> " + destinationParentPath.replace("/", "\\"));
                System.exit(0);
            }
            // Get illumina details API call
            IlluminaMasterData illuminaSyncDetails = connectionIntermittent.callGetAllIlluminaMiSeqSyncDetails();
            if (illuminaSyncDetails == null) {
                LOGGER.error("doFileSync() Illumina data is null.");
                System.exit(0);
            }
            // file sync process start
            LOGGER.info("Illumina sync process started");
            long startProcess = System.currentTimeMillis(); // start time
            for (IlluminaMasterDataItem illuminaMasterDataItem : illuminaSyncDetails.getIlluminaMasterData()) { // year
                Integer yearIndex = illuminaSyncDetails.getIlluminaMasterData().indexOf(illuminaMasterDataItem);
                if (illuminaMasterDataItem.getIsCopied().equals("no")) {
                    boolean isYearFolderExist = inputInfoParam.getSourceShare().folderExists(input.getSourceLocation().replace("\\", "/")
                            .concat("/")
                            .concat(illuminaMasterDataItem.getYear()));

                    if (!isYearFolderExist) {
                        LOGGER.error("Illumina year path is not exists. Path: {}"
                                , sourceParentPath
                                        .concat("\\")
                                        .concat(illuminaMasterDataItem.getYear()).replace("/", "\\"));
                        continue;
                    }
                    for (IlluminaMonthItem illuminaMonthItem : illuminaMasterDataItem.getMonths()) { // month
                        Integer monthIndex = illuminaMasterDataItem.getMonths().indexOf(illuminaMonthItem);
                        if (illuminaMonthItem.getIsCopied().equals("no")) {
                            boolean isMonthFolderExist = inputInfoParam.getSourceShare().folderExists(input.getSourceLocation().replace("\\", "/")
                                    .concat("/")
                                    .concat(illuminaMasterDataItem.getYear())
                                    .concat("/")
                                    .concat(illuminaMonthItem.getMonth())
                            );
                            if (!isMonthFolderExist) {
                                LOGGER.error("Illumina month path is not exists. Path: {}", sourceParentPath
                                        .concat("\\")
                                        .concat(illuminaMasterDataItem.getYear())
                                        .concat("\\")
                                        .concat(illuminaMonthItem.getMonth())
                                        .replace("/", "\\")
                                );
                                continue;
                            }
                            for (IlluminaMachineIdsItem illuminaMachineidsItem : illuminaMonthItem.getMachineIds()) { // machineId
                                Integer machineIndex = illuminaMonthItem.getMachineIds().indexOf(illuminaMachineidsItem);
                                if (illuminaMachineidsItem.getIsCopied().equals("no")) {
                                    boolean isMachineFolderExist = inputInfoParam.getSourceShare().folderExists(input.getSourceLocation().replace("\\", "/")
                                            .concat("/")
                                            .concat(illuminaMasterDataItem.getYear())
                                            .concat("/")
                                            .concat(illuminaMonthItem.getMonth())
                                            .concat("/")
                                            .concat(illuminaMachineidsItem.getId())
                                    );
                                    if (!isMachineFolderExist) {
                                        LOGGER.error("Illumina MachineId File path is not exists. Path: {}", sourceParentPath
                                                .concat("\\")
                                                .concat(illuminaMasterDataItem.getYear())
                                                .concat("\\")
                                                .concat(illuminaMonthItem.getMonth())
                                                .concat("\\")
                                                .concat(illuminaMachineidsItem.getId())
                                                .replace("/", "\\")
                                        );
                                        continue;
                                    }
                                    for (IlluminaExperimentItem illuminaExperimentItem : illuminaMachineidsItem.getExperiments()) { // experiment
                                        if (illuminaExperimentItem.getIsCopied().equals("no")) {
                                            boolean isExperimentFolderExist = inputInfoParam.getSourceShare().folderExists(input.getSourceLocation().replace("\\", "/")
                                                    .concat("/")
                                                    .concat(illuminaMasterDataItem.getYear())
                                                    .concat("/")
                                                    .concat(illuminaMonthItem.getMonth())
                                                    .concat("/")
                                                    .concat(illuminaMachineidsItem.getId())
                                                    .concat("/")
                                                    .concat(illuminaExperimentItem.getNgsExpName())
                                            );
                                            if (!isExperimentFolderExist) {
                                                LOGGER.error("Illumina experiment File path is not exists. Path: {}", sourceParentPath
                                                        .concat("\\")
                                                        .concat(illuminaMasterDataItem.getYear())
                                                        .concat("\\")
                                                        .concat(illuminaMonthItem.getMonth())
                                                        .concat("\\")
                                                        .concat(illuminaMachineidsItem.getId())
                                                        .concat("\\")
                                                        .concat(illuminaExperimentItem.getNgsExpName())
                                                        .replace("/", "\\")
                                                );
                                                continue;
                                            }
//                                            if (experimentItemFile.length() == 0) {
//                                                LOGGER.error("Illumina experiment Folder is not empty. Path: {}", experimentItemFile.getUncPath());
//                                                continue;
//                                            }
                                            Date experimentFileCreationTime = inputInfoParam.getSourceShare().getFileInformation(input.getSourceLocation().replace("\\", "/")
                                                    .concat("/")
                                                    .concat(illuminaMasterDataItem.getYear())
                                                    .concat("/")
                                                    .concat(illuminaMonthItem.getMonth())
                                                    .concat("/")
                                                    .concat(illuminaMachineidsItem.getId())
                                                    .concat("/")
                                                    .concat(illuminaExperimentItem.getNgsExpName())).getBasicInformation().getCreationTime().toDate();
                                            if (!smbFileOrganizer.isFileValidUsingGracePeriod(experimentFileCreationTime)) {
                                                LOGGER.info("Illumina experiment is not valid by grace period. Path: {}", sourceParentPath
                                                        .concat("\\")
                                                        .concat(illuminaMasterDataItem.getYear())
                                                        .concat("\\")
                                                        .concat(illuminaMonthItem.getMonth())
                                                        .concat("\\")
                                                        .concat(illuminaMachineidsItem.getId())
                                                        .concat("\\")
                                                        .concat(illuminaExperimentItem.getNgsExpName())
                                                        .replace("/", "\\"));
                                                continue;
                                            }
                                            boolean isDestinationExist = inputInfoParam.getDestinationShare().folderExists(input.getDestinationLocation().replace("\\", "/"));
                                            String experimentSourcePath = sourceParentPath.concat("\\")
                                                    .concat(illuminaMasterDataItem.getYear())
                                                    .concat("\\")
                                                    .concat(illuminaMonthItem.getMonth())
                                                    .concat("\\")
                                                    .concat(illuminaMachineidsItem.getId())
                                                    .concat("\\")
                                                    .concat(illuminaExperimentItem.getNgsExpName());
                                            String experimentDestinationPath = destinationParentPath.concat("\\")
                                                    .concat(illuminaMasterDataItem.getYear())
                                                    .concat("\\")
                                                    .concat(illuminaMonthItem.getMonth())
                                                    .concat("\\")
                                                    .concat(illuminaMachineidsItem.getId())
                                                    .concat("\\")
                                                    .concat(illuminaExperimentItem.getNgsExpName());
                                            if (isDestinationExist) {
                                                boolean isDestinationExpExist = inputInfoParam.getDestinationShare().folderExists(input.getDestinationLocation().concat("/")
                                                        .concat(illuminaMasterDataItem.getYear())
                                                        .concat("/")
                                                        .concat(illuminaMonthItem.getMonth())
                                                        .concat("/")
                                                        .concat(illuminaMachineidsItem.getId())
                                                        .concat("/")
                                                        .concat(illuminaExperimentItem.getNgsExpName()));
                                                if (isDestinationExpExist) {
                                                    if (smbFileOrganizer.getSMBFileSize(inputInfoParam.getSourceShare(), experimentSourcePath)
                                                            == smbFileOrganizer.getSMBFileSize(inputInfoParam.getDestinationShare(), experimentDestinationPath)) {
                                                        LOGGER.info("Destination experiment size is equal source experiment. Source: {}, Destination:{}"
                                                                , experimentSourcePath, experimentDestinationPath);
                                                        illuminaExperimentItem.setIsCopied("yes");
                                                        Integer experimentIndex = illuminaMachineidsItem.getExperiments().indexOf(illuminaExperimentItem);
                                                        IlluminaExperimentUpdate experimentUpdate = new IlluminaExperimentUpdate(illuminaSyncDetails.getId()
                                                                , yearIndex
                                                                , monthIndex
                                                                , machineIndex
                                                                , experimentIndex
                                                                , illuminaExperimentItem.getNgsExpName());
                                                        String experimentResponse = connectionIntermittent.callUpdateIlluminaMiSeqExperimentStatus(experimentUpdate);
                                                        LOGGER.info("Illumina experiment status update response: {}", experimentResponse);

                                                        int samplesCount = smbFileOrganizer.calculateSamplesCount(experimentDestinationPath, inputInfoParam.getDestinationShare());
                                                        IlluminaDataSecondaryBackupLog backupLog = new IlluminaDataSecondaryBackupLog(illuminaExperimentItem.getNgsExpName()
                                                                , experimentSourcePath, experimentDestinationPath, smbFileOrganizer.timeStampToString(new Date())
                                                                , samplesCount);
                                                        connectionIntermittent.callInsertIlluminaBackupLog(backupLog);
                                                        continue;
                                                    } else {
                                                        // delete destination experiment
                                                        String destinationDeletePath = input.getDestinationLocation().replace("\\", "/").concat("/")
                                                                .concat(illuminaMasterDataItem.getYear())
                                                                .concat("/")
                                                                .concat(illuminaMonthItem.getMonth())
                                                                .concat("/")
                                                                .concat(illuminaMachineidsItem.getId())
                                                                .concat("/")
                                                                .concat(illuminaExperimentItem.getNgsExpName());
                                                        smbFileOrganizer.deleteSmbFile(inputInfoParam.getDestinationShare(), destinationDeletePath);
                                                    }
                                                }

                                            }
                                            smbFileOrganizer.doSmbFileCopy(experimentSourcePath, experimentDestinationPath
                                                    , inputInfoParam.getSourceShare(), inputInfoParam.getDestinationShare(), input.getMachineType()); // File copy process happen
                                            long sourceSmbFileSize = smbFileOrganizer.getSMBFileSize(inputInfoParam.getSourceShare(), experimentSourcePath);
                                            long destinationSmbFileSize = smbFileOrganizer.getSMBFileSize(inputInfoParam.getDestinationShare(), experimentDestinationPath);
                                            LOGGER.info("Source smb file size in Bytes: {}. Destination smb file size Bytes: {}", sourceSmbFileSize, destinationSmbFileSize);
                                            boolean isFileCopied = sourceSmbFileSize == destinationSmbFileSize;
                                            if (isFileCopied) {
                                                int samplesCount = smbFileOrganizer.calculateSamplesCount(experimentDestinationPath, inputInfoParam.getDestinationShare());
                                                String sourceExperimentFullPath = experimentSourcePath.replace("/", "\\");
                                                String destinationExperimentFullPath = experimentDestinationPath.replace("/", "\\");
                                                illuminaExperimentItem.setIsCopied("yes");
                                                IlluminaDataSecondaryBackupLog backupLog = new IlluminaDataSecondaryBackupLog(illuminaExperimentItem.getNgsExpName()
                                                        , sourceExperimentFullPath, destinationExperimentFullPath, smbFileOrganizer.timeStampToString(new Date())
                                                        , samplesCount);
                                                connectionIntermittent.callInsertIlluminaBackupLog(backupLog);

                                                // update isCopied status
                                                Integer experimentIndex = illuminaMachineidsItem.getExperiments().indexOf(illuminaExperimentItem);
                                                IlluminaExperimentUpdate experimentUpdate = new IlluminaExperimentUpdate(illuminaSyncDetails.getId()
                                                        , yearIndex
                                                        , monthIndex
                                                        , machineIndex
                                                        , experimentIndex
                                                        , illuminaExperimentItem.getNgsExpName());
                                                String experimentResponse = connectionIntermittent.callUpdateIlluminaMiSeqExperimentStatus(experimentUpdate);
                                                LOGGER.info("Illumina experiment status update response: {}", experimentResponse);
                                            }
                                        }
                                    }
                                    // checking is all experiments are copied
                                    long nonSyncExperimentsCount = illuminaMachineidsItem.getExperiments().stream().filter(
                                            experiment -> experiment.getIsCopied().equals("no")
                                    ).count();
                                    if (nonSyncExperimentsCount == 0 && smbFileOrganizer.isMonthValidToChangeIsCopiedStatus(illuminaMonthItem.getMonth())) {
                                        illuminaMachineidsItem.setIsCopied("yes");
                                        IlluminaMachineUpdate machineUpdate = new IlluminaMachineUpdate(illuminaSyncDetails.getId()
                                                , yearIndex
                                                , monthIndex
                                                , machineIndex
                                                , illuminaMachineidsItem.getId());
                                        String machineResponse = connectionIntermittent.callUpdateIlluminaMiSeqMachineStatus(machineUpdate);
                                        LOGGER.info("Illumina machine status update response: {}", machineResponse);
                                    }
                                }
                            }

                            if (smbFileOrganizer.isMonthValidToChangeIsCopiedStatus(illuminaMonthItem.getMonth())) {
                                // Checking is all machine copied
                                long nonSyncMachineCount = illuminaMonthItem.getMachineIds().stream().filter(
                                        machine -> machine.getIsCopied().equals("no")
                                ).count();
                                if (nonSyncMachineCount == 0) {
                                    illuminaMonthItem.setIsCopied("yes");
                                    IlluminaMonthUpdate monthUpdate = new IlluminaMonthUpdate(illuminaSyncDetails.getId()
                                            , yearIndex, monthIndex, illuminaMonthItem.getMonth());
                                    String monthResponse = connectionIntermittent.callUpdateIlluminaMiSeqMonthStatus(monthUpdate);
                                    LOGGER.info("Illumina month status update response: {}", monthResponse);
                                }
                            }
                        }
                    }
                    if (smbFileOrganizer.isYearValidToChangeIsCopiedStatus(illuminaMasterDataItem.getYear())) {
                        // Checking all month is copied
                        long nonSyncMonthCount = illuminaMasterDataItem.getMonths().stream().filter(
                                month -> month.getIsCopied().equals("no")
                        ).count();
                        if (nonSyncMonthCount == 0) {
                            illuminaMasterDataItem.setIsCopied("yes");
                            IlluminaYearUpdate yearUpdate = new IlluminaYearUpdate(illuminaSyncDetails.getId(), yearIndex, illuminaMasterDataItem.getYear());
                            String yearResponse = connectionIntermittent.callUpdateIlluminaMiSeqYearStatus(yearUpdate);
                            LOGGER.info("Illumina year status update response: {}", yearResponse);
                        }
                    }

                }
            } // file sync process end
            LOGGER.info("Illumina sync process completed");
            long endProcess = System.currentTimeMillis(); // end process
            LOGGER.info("Illumina sync process taken time is: {}", smbFileOrganizer.getDurationBreakdown(endProcess - startProcess));
            System.exit(0);
        } catch (Exception e) {
            LOGGER.error("Illumina doFileSync() error: {}", e);
        }
    }

    // update new illumina details
    private IlluminaMasterData constructIlluminaSyncDetails(InputArgs inputArgs, InputInfoParam inputInfoParam, IlluminaMasterData illuminaMasterData)
            throws MalformedURLException, SmbException {

        // get the illumina details based on given source file
        IlluminaMasterData fileSystemMasterData = constructIlluminaSyncDetails(inputArgs, inputInfoParam);

        // Update new illumina year file in existing
        List<IlluminaMasterDataItem> newIlluminaYearFile = fileSystemMasterData.getIlluminaMasterData().stream().filter(
                year -> !illuminaMasterData.getIlluminaMasterData().contains(year)
        ).collect(Collectors.toList());

        if (newIlluminaYearFile.size() > 0) {
            illuminaMasterData.getIlluminaMasterData().addAll(newIlluminaYearFile);
            // fileSystemMasterData.getIlluminaMasterData().removeAll(newIlluminaYearFile);
        }

        // update new illumina month file in existing
        for (int yearIndex = 0; yearIndex < illuminaMasterData.getIlluminaMasterData().size(); yearIndex++) { //year
            IlluminaMasterDataItem dbMasterDataItem = illuminaMasterData.getIlluminaMasterData().get(yearIndex); // get the year file
            IlluminaMasterDataItem fileIlluminaMonth = fileSystemMasterData.getIlluminaMasterData().stream().filter( // filter year file in file illumina
                    year -> year.getYear().equals(dbMasterDataItem.getYear())
            ).findFirst().get();

            List<IlluminaMonthItem> newIlluminaMonthFile = fileIlluminaMonth.getMonths().stream().filter( // Get the new month file
                    month -> !dbMasterDataItem.getMonths().contains(month)
            ).collect(Collectors.toList());
            if (newIlluminaMonthFile.size() > 0) {
                illuminaMasterData.getIlluminaMasterData().get(yearIndex).getMonths().addAll(newIlluminaMonthFile); // add the new month file in existing
                continue;
            }

            // update new illumina machine file in existing
            for (int monthIndex = 0; monthIndex < illuminaMasterData.getIlluminaMasterData().get(yearIndex).getMonths().size(); monthIndex++) { // month
                IlluminaMonthItem dbMonthItem = illuminaMasterData.getIlluminaMasterData().get(yearIndex).getMonths().get(monthIndex);
                IlluminaMasterDataItem fileIlluminaMonthMachine = fileSystemMasterData.getIlluminaMasterData().stream().filter(
                        year -> year.getYear().equals(dbMasterDataItem.getYear())
                ).findFirst().get();
                List<IlluminaMachineIdsItem> newIlluminaMachineFile = fileIlluminaMonthMachine.getMonths().stream()
                        .filter(month ->
                                month.getMonth().equals(dbMonthItem.getMonth()))
                        .findFirst().get()
                        .getMachineIds().stream().filter(
                                machine -> !dbMonthItem.getMachineIds().contains(machine))
                        .collect(Collectors.toList());
                if (newIlluminaMachineFile.size() > 0) {
                    illuminaMasterData.getIlluminaMasterData().get(yearIndex).getMonths().get(monthIndex).getMachineIds().addAll(newIlluminaMachineFile);
                    continue;
                }

                // update new illumina experiment file in existing
                for (int machineIndex = 0; machineIndex < illuminaMasterData.getIlluminaMasterData().get(yearIndex).getMonths().get(monthIndex).getMachineIds().size()
                        ; machineIndex++) { // machine
                    IlluminaMachineIdsItem dbMachineIdsItem = illuminaMasterData.getIlluminaMasterData()
                            .get(yearIndex).getMonths().get(monthIndex).getMachineIds().get(machineIndex);

                    IlluminaMasterDataItem fileIlluminaMasterYear = fileSystemMasterData.getIlluminaMasterData().stream().filter(
                            year -> year.getYear().equals(dbMasterDataItem.getYear())
                    ).findFirst().get();

                    List<IlluminaMachineIdsItem> fileIlluminaMonthMachineExperiments = fileIlluminaMasterYear.getMonths()
                            .stream()
                            .filter(month ->
                                    month.getMonth().equals(dbMonthItem.getMonth()))
                            .findFirst().get().getMachineIds().stream().filter(
                                    machine -> dbMonthItem.getMachineIds().contains(machine)
                            ).collect(Collectors.toList());

                    List<IlluminaExperimentItem> newExperimentFile = fileIlluminaMonthMachineExperiments.stream().filter(
                                    machine -> machine.getId().equals(dbMachineIdsItem.getId())
                            ).findFirst().get()
                            .getExperiments().stream().filter(
                                    experiment -> !dbMachineIdsItem.getExperiments().contains(experiment)
                            ).collect(Collectors.toList());

                    if (newExperimentFile.size() > 0) {
                        illuminaMasterData.getIlluminaMasterData().get(yearIndex).getMonths()
                                .get(monthIndex).getMachineIds()
                                .get(machineIndex).getExperiments().addAll(newExperimentFile);
                    }
                }
            }
        }
        return illuminaMasterData;
    }

    // create new illumina details
    private IlluminaMasterData constructIlluminaSyncDetails(InputArgs inputArgs, InputInfoParam inputInfoParam) throws MalformedURLException, SmbException {
        boolean isSourceExists = inputInfoParam.getSourceShare().folderExists(inputArgs.getSourceLocation().replace("\\", "/"));
        String sourceBasePath = inputInfoParam.getSourceShare().getSmbPath().toUncPath().concat("\\").concat(inputArgs.getSourceLocation());
        if (!isSourceExists) {
            LOGGER.error("Failed: Invalid Source Folder -> " + sourceBasePath.replace("/", "\\"));
            return null;
        }
        List<FileIdBothDirectoryInformation> sourceListYear = inputInfoParam.getSourceShare().list(inputArgs.getSourceLocation());
        if (sourceListYear.size() == 0) {
            return null;
        }
        List<IlluminaMasterDataItem> illuminaMasterDataItems = new ArrayList<>();
        for (FileIdBothDirectoryInformation yearFile : sourceListYear) { // year
            if (yearFile.getFileName().equals(".") || yearFile.getFileName().equals("..")) {
                continue;
            }
            IlluminaMasterDataItem illuminaMasterDataItem = new IlluminaMasterDataItem();
            illuminaMasterDataItem.setYear(yearFile.getFileName());
            illuminaMasterDataItem.setIsCopied("no");

            List<FileIdBothDirectoryInformation> sourceListMonth = inputInfoParam.getSourceShare().list(inputArgs.getSourceLocation()
                    .concat("/")
                    .concat(yearFile.getFileName())
            );

            if (sourceListMonth.size() == 0) {
                continue;
            }
            List<IlluminaMonthItem> monthItems = new ArrayList<>();
            for (FileIdBothDirectoryInformation monthFile : sourceListMonth) { // month
                if (monthFile.getFileName().equals(".") || monthFile.getFileName().equals("..")) {
                    continue;
                }
                IlluminaMonthItem monthItem = new IlluminaMonthItem();
                monthItem.setMonth(monthFile.getFileName());
                monthItem.setIsCopied("no");

                List<FileIdBothDirectoryInformation> sourceListMachine = inputInfoParam.getSourceShare().list(inputArgs.getSourceLocation()
                        .concat("/")
                        .concat(yearFile.getFileName())
                        .concat("/")
                        .concat(monthFile.getFileName())
                );
                if (sourceListMachine.size() == 0) {
                    continue;
                }
                List<IlluminaMachineIdsItem> machineIds = new ArrayList<>();
                for (FileIdBothDirectoryInformation machineFile : sourceListMachine) { // machine
                    if (machineFile.getFileName().equals(".") || machineFile.getFileName().equals("..")) {
                        continue;
                    }
                    IlluminaMachineIdsItem machineIdsItem = new IlluminaMachineIdsItem();
                    machineIdsItem.setId(machineFile.getFileName());
                    machineIdsItem.setIsCopied("no");
                    List<FileIdBothDirectoryInformation> sourceListExperiment = inputInfoParam.getSourceShare().list(inputArgs.getSourceLocation()
                            .concat("/")
                            .concat(yearFile.getFileName())
                            .concat("/")
                            .concat(monthFile.getFileName())
                            .concat("/")
                            .concat(machineFile.getFileName())
                    );
                    if (sourceListExperiment.size() == 0) {
                        continue;
                    }
                    List<IlluminaExperimentItem> experiments = new ArrayList<>();
                    for (FileIdBothDirectoryInformation experimentFile : sourceListExperiment) { // experiment
                        if (experimentFile.getFileName().equals(".") || experimentFile.getFileName().equals("..")) {
                            continue;
                        }
                        IlluminaExperimentItem experiment = new IlluminaExperimentItem();
                        experiment.setNgsExpName(experimentFile.getFileName());
                        experiment.setIsCopied("no");

                        experiments.add(experiment);
                    }
                    experiments.sort(Comparator.comparing(IlluminaExperimentItem::getNgsExpName));
                    machineIdsItem.setExperiments(experiments);
                    machineIds.add(machineIdsItem);
                }
                machineIds.sort(Comparator.comparing(IlluminaMachineIdsItem::getId));
                monthItem.setMachineIds(machineIds);
                monthItems.add(monthItem);
            }
            monthItems.sort(Comparator.comparing(IlluminaMonthItem::getMonth));
            illuminaMasterDataItem.setMonths(monthItems);
            illuminaMasterDataItems.add(illuminaMasterDataItem);
        }
        illuminaMasterDataItems.sort(Comparator.comparing(IlluminaMasterDataItem::getYear));
        IlluminaMasterData illuminaMasterData = new IlluminaMasterData();
        illuminaMasterData.setIlluminaMasterData(illuminaMasterDataItems);
        return illuminaMasterData;
    }
}
