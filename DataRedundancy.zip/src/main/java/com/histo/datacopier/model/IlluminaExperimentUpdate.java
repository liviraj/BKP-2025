package com.histo.datacopier.model;

public class IlluminaExperimentUpdate {
    private String id;
    private Integer yearIndex;
    private Integer monthIndex;
    private Integer machineIndex;
    private Integer experimentIndex;
    private String experimentName;

    public IlluminaExperimentUpdate() {
    }

    public IlluminaExperimentUpdate(String id, Integer yearIndex, Integer monthIndex, Integer machineIndex, Integer experimentIndex, String experimentName) {
        this.id = id;
        this.yearIndex = yearIndex;
        this.monthIndex = monthIndex;
        this.machineIndex = machineIndex;
        this.experimentIndex = experimentIndex;
        this.experimentName = experimentName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getYearIndex() {
        return yearIndex;
    }

    public void setYearIndex(Integer yearIndex) {
        this.yearIndex = yearIndex;
    }

    public Integer getMonthIndex() {
        return monthIndex;
    }

    public void setMonthIndex(Integer monthIndex) {
        this.monthIndex = monthIndex;
    }

    public Integer getMachineIndex() {
        return machineIndex;
    }

    public void setMachineIndex(Integer machineIndex) {
        this.machineIndex = machineIndex;
    }

    public Integer getExperimentIndex() {
        return experimentIndex;
    }

    public void setExperimentIndex(Integer experimentIndex) {
        this.experimentIndex = experimentIndex;
    }

    public String getExperimentName() {
        return experimentName;
    }

    public void setExperimentName(String experimentName) {
        this.experimentName = experimentName;
    }

    @Override
    public String toString() {
        return "IlluminaExperimentUpdate{" +
                "id='" + id + '\'' +
                ", yearIndex=" + yearIndex +
                ", monthIndex=" + monthIndex +
                ", machineIndex=" + machineIndex +
                ", experimentIndex=" + experimentIndex +
                ", experimentName='" + experimentName + '\'' +
                '}';
    }
}
