package com.histo.datacopier.model;

public class IlluminaMachineUpdate {
    private String id;
    private Integer yearIndex;
    private Integer monthIndex;
    private Integer machineIndex;
    private String machineId;


    public IlluminaMachineUpdate() {
    }

    public IlluminaMachineUpdate(String id, Integer yearIndex, Integer monthIndex, Integer machineIndex, String machineId) {
        this.id = id;
        this.yearIndex = yearIndex;
        this.monthIndex = monthIndex;
        this.machineIndex = machineIndex;
        this.machineId = machineId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getYearIndex() {
        return yearIndex;
    }

    public void setYearIndex(Integer yearIndex) {
        this.yearIndex = yearIndex;
    }

    public Integer getMonthIndex() {
        return monthIndex;
    }

    public void setMonthIndex(Integer monthIndex) {
        this.monthIndex = monthIndex;
    }

    public Integer getMachineIndex() {
        return machineIndex;
    }

    public void setMachineIndex(Integer machineIndex) {
        this.machineIndex = machineIndex;
    }

    public String getMachineId() {
        return machineId;
    }

    public void setMachineId(String machineId) {
        this.machineId = machineId;
    }

    @Override
    public String toString() {
        return "IlluminaMachineUpdate{" +
                "id='" + id + '\'' +
                ", yearIndex=" + yearIndex +
                ", monthIndex=" + monthIndex +
                ", machineIndex=" + machineIndex +
                ", machineId='" + machineId + '\'' +
                '}';
    }
}
