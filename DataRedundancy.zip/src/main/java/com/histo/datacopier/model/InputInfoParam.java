package com.histo.datacopier.model;

import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import com.histo.datacopier.config.PropertyConfig;
import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;

import java.io.IOException;
import java.net.MalformedURLException;

public class InputInfoParam {
    private DiskShare sourceShare;
    DiskShare destinationShare;

    public InputInfoParam() {
    }

    public InputInfoParam(InputArgs input, PropertyConfig propertyConfig) {
        SMBClient clientSource = new SMBClient();
        SMBClient clientDestination = new SMBClient();
        try {
            Connection connectionSource = clientSource.connect(input.getSourceServer());
            AuthenticationContext authContextSource = new AuthenticationContext(input.getSourceUsername(), input.getSourcePassword().toCharArray(), propertyConfig.getSmbDomainName());
            Session sessionSource = connectionSource.authenticate(authContextSource);
            this.sourceShare = (DiskShare) sessionSource.connectShare(input.getSourceShare());

            Connection connectionDestination = clientDestination.connect(input.getDestinationServer());
            AuthenticationContext authContextDestination = new AuthenticationContext(input.getDestinationUsername(), input.getDestinationPassword().toCharArray(), propertyConfig.getSmbDomainName());
            Session session = connectionDestination.authenticate(authContextDestination);
            this.destinationShare = (DiskShare) session.connectShare(input.getDestinationShare());
        } catch (IOException e) {
            e.printStackTrace();
        }

//        String sourceUrl = "smb:" + input.getSourceLocation().replace("\\", "/");
//        String destinationUrl = "smb:" + input.getDestinationLocation().replace("\\", "/");
//        this.sourceAuth = new NtlmPasswordAuthentication(propertyConfig.getSmbDomainName(), input.getSourceUsername(), input.getSourcePassword());
//        this.destinationAuth = new NtlmPasswordAuthentication(propertyConfig.getSmbDomainName(), input.getDestinationUsername(), input.getDestinationPassword());
//        sourceUrl = sourceUrl.endsWith("/") ? sourceUrl : sourceUrl + "/";
//        destinationUrl = destinationUrl.endsWith("/") ? destinationUrl : destinationUrl + "/";
//        try {
//            this.sourceDir = new SmbFile(sourceUrl, sourceAuth);
//            this.destDir = new SmbFile(destinationUrl, destinationAuth);
//        } catch (MalformedURLException e) {
//            throw new RuntimeException(e);
//        }

    }

    public DiskShare getSourceShare() {
        return sourceShare;
    }

    public void setSourceShare(DiskShare sourceShare) {
        this.sourceShare = sourceShare;
    }

    public DiskShare getDestinationShare() {
        return destinationShare;
    }

    public void setDestinationShare(DiskShare destinationShare) {
        this.destinationShare = destinationShare;
    }

    @Override
    public String toString() {
        return "InputInfoParam{" + "sourceShare=" + sourceShare + ", destinationShare=" + destinationShare + '}';
    }
}
