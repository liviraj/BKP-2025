package com.histo.datacopier.model;

public class InputArgs {
    private String sourceServer;
    private String destinationServer;
    private String sourceShare;
    private String destinationShare;
    private String sourceLocation;
    private String destinationLocation;
    private String sourceUsername;
    private String sourcePassword;
    private String destinationUsername;
    private String destinationPassword;
    private MachineTypeEnum machineType;

    public InputArgs() {
    }

    public String getSourceLocation() {
        return sourceLocation;
    }

    public void setSourceLocation(String sourceLocation) {
        this.sourceLocation = sourceLocation;
    }

    public String getDestinationLocation() {
        return destinationLocation;
    }

    public void setDestinationLocation(String destinationLocation) {
        this.destinationLocation = destinationLocation;
    }

    public String getSourceUsername() {
        return sourceUsername;
    }

    public void setSourceUsername(String sourceUsername) {
        this.sourceUsername = sourceUsername;
    }

    public String getSourcePassword() {
        return sourcePassword;
    }

    public void setSourcePassword(String sourcePassword) {
        this.sourcePassword = sourcePassword;
    }

    public String getDestinationUsername() {
        return destinationUsername;
    }

    public void setDestinationUsername(String destinationUsername) {
        this.destinationUsername = destinationUsername;
    }

    public String getDestinationPassword() {
        return destinationPassword;
    }

    public void setDestinationPassword(String destinationPassword) {
        this.destinationPassword = destinationPassword;
    }

    public MachineTypeEnum getMachineType() {
        return machineType;
    }

    public void setMachineType(MachineTypeEnum machineType) {
        this.machineType = machineType;
    }

    public String getSourceServer() {
        return sourceServer;
    }

    public void setSourceServer(String sourceServer) {
        this.sourceServer = sourceServer;
    }

    public String getDestinationServer() {
        return destinationServer;
    }

    public void setDestinationServer(String destinationServer) {
        this.destinationServer = destinationServer;
    }

    public String getSourceShare() {
        return sourceShare;
    }

    public void setSourceShare(String sourceShare) {
        this.sourceShare = sourceShare;
    }

    public String getDestinationShare() {
        return destinationShare;
    }

    public void setDestinationShare(String destinationShare) {
        this.destinationShare = destinationShare;
    }

    @Override
    public String toString() {
        return "InputArgs{" +
                "sourceServer='" + sourceServer + '\'' +
                ", destinationServer='" + destinationServer + '\'' +
                ", sourceShare='" + sourceShare + '\'' +
                ", destinationShare='" + destinationShare + '\'' +
                ", sourceLocation='" + sourceLocation + '\'' +
                ", destinationLocation='" + destinationLocation + '\'' +
                ", sourceUsername='" + sourceUsername + '\'' +
                ", sourcePassword='" + sourcePassword + '\'' +
                ", destinationUsername='" + destinationUsername + '\'' +
                ", destinationPassword='" + destinationPassword + '\'' +
                ", machineType=" + machineType +
                '}';
    }
}
