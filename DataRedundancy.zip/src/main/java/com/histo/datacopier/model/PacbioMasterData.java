package com.histo.datacopier.model;

import lombok.*;

import java.util.List;


public class PacbioMasterData {
    private String id;
    private List<PacbioJobsItem> jobs;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public List<PacbioJobsItem> getJobs() {
		return jobs;
	}
	public void setJobs(List<PacbioJobsItem> jobs) {
		this.jobs = jobs;
	}
    
    
}