package com.histo.datacopier.model;

import lombok.*;


public class IlluminaDataSecondaryBackupLog {
    private String illuminaExperimentName;
    private String primaryExperimentLocation;
    private String secondaryExperimentLocation;
    private String backupCompletionDate;
    private Integer sampleCount;


    public IlluminaDataSecondaryBackupLog(String illuminaExperimentName, String primaryExperimentLocation, String secondaryExperimentLocation
            , String backupCompletionDate, Integer sampleCount) {
        this.illuminaExperimentName = illuminaExperimentName;
        this.primaryExperimentLocation = primaryExperimentLocation;
        this.secondaryExperimentLocation = secondaryExperimentLocation;
        this.backupCompletionDate = backupCompletionDate;
        this.sampleCount = sampleCount;
    }

    public String getIlluminaExperimentName() {
        return illuminaExperimentName;
    }

    public void setIlluminaExperimentName(String illuminaExperimentName) {
        this.illuminaExperimentName = illuminaExperimentName;
    }

    public String getPrimaryExperimentLocation() {
        return primaryExperimentLocation;
    }

    public void setPrimaryExperimentLocation(String primaryExperimentLocation) {
        this.primaryExperimentLocation = primaryExperimentLocation;
    }

    public String getSecondaryExperimentLocation() {
        return secondaryExperimentLocation;
    }

    public void setSecondaryExperimentLocation(String secondaryExperimentLocation) {
        this.secondaryExperimentLocation = secondaryExperimentLocation;
    }

    public String getBackupCompletionDate() {
        return backupCompletionDate;
    }

    public void setBackupCompletionDate(String backupCompletionDate) {
        this.backupCompletionDate = backupCompletionDate;
    }

    public Integer getSampleCount() {
        return sampleCount;
    }

    public void setSampleCount(Integer sampleCount) {
        this.sampleCount = sampleCount;
    }

    @Override
    public String toString() {
        return "IlluminaDataSecondaryBackupLog{" +
                "illuminaExperimentName='" + illuminaExperimentName + '\'' +
                ", primaryExperimentLocation='" + primaryExperimentLocation + '\'' +
                ", secondaryExperimentLocation='" + secondaryExperimentLocation + '\'' +
                ", backupCompletionDate='" + backupCompletionDate + '\'' +
                ", sampleCount='" + sampleCount + '\'' +
                '}';
    }
}
