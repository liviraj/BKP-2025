package com.histo.datacopier.model;

import java.util.List;
import java.util.Objects;

public class IlluminaMasterDataItem {
    private String isCopied;
    private List<IlluminaMonthItem> months;
    private String year;

    public void setIsCopied(String isCopied) {
        this.isCopied = isCopied;
    }

    public String getIsCopied() {
        return isCopied;
    }

    public void setMonths(List<IlluminaMonthItem> months) {
        this.months = months;
    }

    public List<IlluminaMonthItem> getMonths() {
        return months;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getYear() {
        return year;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof IlluminaMasterDataItem)) return false;
        IlluminaMasterDataItem that = (IlluminaMasterDataItem) o;
        return getYear().equals(that.getYear());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getYear());
    }

    @Override
    public String toString() {
        return "IlluminaMasterDataItem{" +
                "isCopied='" + isCopied + '\'' +
                ", months=" + months +
                ", year='" + year + '\'' +
                '}';
    }
}