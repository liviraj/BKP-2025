package com.histo.datacopier.model;

public enum MachineTypeEnum {
    PACBIO,
    ILLUMINA_NOVASEQ,
    ILLUMINA_MISEQ
}
