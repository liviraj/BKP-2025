package com.histo.datacopier.model;

import lombok.*;


public class PacbioDataSecondaryBackupLog {
    private String jobId;
    private String primaryExperimentLocation;
    private String secondaryExperimentLocation;
    private String backupCompletionDate;
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public String getPrimaryExperimentLocation() {
		return primaryExperimentLocation;
	}
	public void setPrimaryExperimentLocation(String primaryExperimentLocation) {
		this.primaryExperimentLocation = primaryExperimentLocation;
	}
	public String getSecondaryExperimentLocation() {
		return secondaryExperimentLocation;
	}
	public void setSecondaryExperimentLocation(String secondaryExperimentLocation) {
		this.secondaryExperimentLocation = secondaryExperimentLocation;
	}
	public String getBackupCompletionDate() {
		return backupCompletionDate;
	}
	public void setBackupCompletionDate(String backupCompletionDate) {
		this.backupCompletionDate = backupCompletionDate;
	}
	public PacbioDataSecondaryBackupLog(String jobId, String primaryExperimentLocation,
			String secondaryExperimentLocation, String backupCompletionDate) {
		super();
		this.jobId = jobId;
		this.primaryExperimentLocation = primaryExperimentLocation;
		this.secondaryExperimentLocation = secondaryExperimentLocation;
		this.backupCompletionDate = backupCompletionDate;
	}
    
    
}
