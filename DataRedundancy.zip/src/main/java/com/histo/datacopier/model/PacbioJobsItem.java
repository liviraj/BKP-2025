package com.histo.datacopier.model;

import lombok.*;

import java.util.Objects;


public class PacbioJobsItem {
    private String jobId;
    private boolean isCopied;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PacbioJobsItem)) return false;
        PacbioJobsItem that = (PacbioJobsItem) o;
        return getJobId().equals(that.getJobId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getJobId());
    }

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public boolean isCopied() {
		return isCopied;
	}

	public void setCopied(boolean isCopied) {
		this.isCopied = isCopied;
	}
    
    
}
