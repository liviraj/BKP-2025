package com.histo.datacopier.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter @Setter @NoArgsConstructor @ToString
public class IlluminaMasterData{
	private String id;
	private List<IlluminaMasterDataItem> illuminaMasterData;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public List<IlluminaMasterDataItem> getIlluminaMasterData() {
		return illuminaMasterData;
	}
	public void setIlluminaMasterData(List<IlluminaMasterDataItem> illuminaMasterData) {
		this.illuminaMasterData = illuminaMasterData;
	}
	
}