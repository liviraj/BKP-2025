package com.histo.permissionrequest.repository;

import com.histo.permissionrequest.entity.PermissionTypes;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PermissionTypesRepository extends JpaRepository< PermissionTypes,Integer> {
}
