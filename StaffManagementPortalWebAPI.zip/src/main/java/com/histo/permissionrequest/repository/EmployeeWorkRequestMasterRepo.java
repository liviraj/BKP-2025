package com.histo.permissionrequest.repository;

import com.histo.permissionrequest.entity.EmployeeWorkRequestDetails;
import com.histo.permissionrequest.entity.EmployeeWorkRequestMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeWorkRequestMasterRepo extends JpaRepository<EmployeeWorkRequestMaster, Integer> {
}
