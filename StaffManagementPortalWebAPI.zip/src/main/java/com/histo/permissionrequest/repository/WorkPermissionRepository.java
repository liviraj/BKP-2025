package com.histo.permissionrequest.repository;

import com.histo.permissionrequest.entity.WorkPermissions;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface WorkPermissionRepository extends JpaRepository< WorkPermissions,Integer> {

    List<WorkPermissions> findByEmployeeIdAndPermissionDateAndApprovalStatusIn(Integer employeeId, Instant permissionDate, Collection<String> approvalStatuses);

    Optional<WorkPermissions> findByPermissionId(Integer permissionId);

    @Query(value = """
            select count(employeeId) from WorkPermissions w
            where w.employeeId = ?1 
            and month(permissiondate) = month(?2) AND year(permissiondate) = year(?2) 
            and (w.permissionId <> ?3 OR ?3 = 0)
            and w.ApprovalStatus not in ('C','R') 
            and ((?4 = 'A' AND w.ApprovalStatus = 'A') 
            OR (ISNULL(?4,'') = '' AND w.ApprovalStatus not in ('C','R')))
            and w.permissionTypeId = ?5""",nativeQuery = true)
    long getTotalPermissionCount(Integer employeeId, String permissionDate, Integer permissionId, String status, Integer permissionTypeId);

}
