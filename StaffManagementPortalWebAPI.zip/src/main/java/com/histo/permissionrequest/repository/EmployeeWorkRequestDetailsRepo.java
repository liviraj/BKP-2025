package com.histo.permissionrequest.repository;

import com.histo.permissionrequest.entity.EmployeeWorkRequestDetails;
import com.histo.permissionrequest.entity.EmployeeWorkRequestMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface EmployeeWorkRequestDetailsRepo extends JpaRepository<EmployeeWorkRequestDetails, Integer> {
    List<EmployeeWorkRequestDetails> findByRequestDetailsIdInAndApprovalStatusIn(Collection<Integer> requestDetailsIds, Collection<String> approvalStatuses);
    List<EmployeeWorkRequestDetails> findByRequestDetailsIdIn(Collection<Integer> requestDetailsIds);

    interface WorkDetailsCount{
        Integer getEmployeeId();
        String getApprovalStatus();
        int getTotalWfhCount();
        double getTotalWfhDaysCount();
    }
    @Query(value = """
            SELECT A.employeeId, A.approvalStatus , CASE WHEN B.RequestFromForH = 'H'  THEN count(A.employeeId)-0.5
            WHEN B.RequestToForH = 'H' THEN  count(A.employeeId)-0.5 ELSE  count(A.employeeId) END as totalWfhDaysCount,COUNT(A.employeeId) As totalWfhCount
            FROM EmployeeWorkRequestDetails A INNER JOIN EmployeeWorkRequestMaster B ON A.RequestId = B. WorkRequestId
            WHERE A.EmployeeId = ?1 AND (MONTH(A.requestDate) = MONTH(?2) OR MONTH(A.requestDate) = MONTH(?3)) 
            AND A.ApprovalStatus IN ('T','A')
            GROUP BY A.employeeId, A.approvalStatus, B.RequestFromForH, B.RequestToForH"""
            ,nativeQuery = true)
    List<WorkDetailsCount> findByEmployeeIdAndRequestDate(Integer employeeId, Instant requestStartDate, Instant requestEndDate);
    Optional<EmployeeWorkRequestDetails> findByRequestId_WorkRequestIdAndEmployeeId(Optional<EmployeeWorkRequestMaster> workRequestId, Integer employeeId);
    Optional<EmployeeWorkRequestDetails> findByRequestId_WorkRequestIdAndApprovalStatusNotIn(Integer workRequestId, Collection<String> approvalStatuses);
    List<EmployeeWorkRequestDetails> findByEmployeeIdAndRequestDateBetween(Integer employeeId, Instant requestDateStart, Instant requestDateEnd);
}
