package com.histo.permissionrequest.service;

import com.histo.permissionrequest.dto.EmployeeWorkRequestMasterDTO;
import com.histo.permissionrequest.model.RequestFilter;
import com.histo.permissionrequest.model.WorkRequestApproveDetails;
import org.springframework.http.ResponseEntity;

public interface EmployeeWorkRequestService {

    ResponseEntity<Object> addRequestDetails(EmployeeWorkRequestMasterDTO employeeWorkRequestMasterDTO);
    ResponseEntity<Object> editRequestDetails(Integer requestId,EmployeeWorkRequestMasterDTO employeeWorkRequestMasterDTO);
    ResponseEntity<Object> reviewRequestDetails(WorkRequestApproveDetails workRequestApproveDetails);

    ResponseEntity<Object> viewRequestQueueDetails(Integer requestId);

    ResponseEntity<Object> getRequestHistory(RequestFilter requestFilter);

    ResponseEntity<Object> getEmpLastWorkRequest(Integer employeeId);
}
