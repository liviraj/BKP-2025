package com.histo.permissionrequest.service;

import com.histo.permissionrequest.model.EmailFilterModel;
import com.histo.permissionrequest.model.FilterModel;
import com.histo.permissionrequest.model.PermissionApproverDetails;
import com.histo.permissionrequest.dto.WorkPermissionDTO;
import org.springframework.http.ResponseEntity;

public interface PermissionRequestService {

    ResponseEntity<Object> getPermissiontype();
    ResponseEntity<Object> getEmployeePermissionHistory(FilterModel filterModel);

    ResponseEntity<Object> addPermissionRequest(WorkPermissionDTO workPermissionDTO);

    ResponseEntity<Object> getPermissionRequest(Integer permissionId);
    ResponseEntity<Object> updatePermissionRequest(WorkPermissionDTO workPermissionDTO, Integer permissionId);

    ResponseEntity<Object> approveOrRejectPermissionRequest(PermissionApproverDetails permissionApproverDetails);

    ResponseEntity<Object> getPermissionDetailsForEmail(EmailFilterModel filterModel);

    ResponseEntity<Object> getEmpLastPermissionRequest(Integer employeeId);
}
