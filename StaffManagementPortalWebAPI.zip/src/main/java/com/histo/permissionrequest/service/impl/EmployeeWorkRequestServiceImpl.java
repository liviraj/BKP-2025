package com.histo.permissionrequest.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.permissionrequest.dto.EmployeeWorkRequestMasterDTO;
import com.histo.permissionrequest.entity.EmployeeWorkRequestDetails;
import com.histo.permissionrequest.entity.EmployeeWorkRequestMaster;
import com.histo.permissionrequest.model.*;
import com.histo.permissionrequest.repository.EmployeeWorkRequestDetailsRepo;
import com.histo.permissionrequest.repository.EmployeeWorkRequestMasterRepo;
import com.histo.permissionrequest.service.EmployeeWorkRequestService;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.intranet.entity.EmployeeLeaveDetails;
import com.histo.staffmanagementportal.intranet.entity.Holiday;
import com.histo.staffmanagementportal.intranet.repository.EmployeeHolidayRepository;
import com.histo.staffmanagementportal.intranet.repository.HolidayRepository;
import com.histo.staffmanagementportal.model.*;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.Instant;
import java.util.*;

@Service
public class EmployeeWorkRequestServiceImpl implements EmployeeWorkRequestService {

    private static final Logger logger = LogManager.getLogger (EmployeeWorkRequestServiceImpl.class);
    private static final String STATUS = "status";

    private static final String OPTIONAL_TYPE = "Optional type";
    private final ResponseModel response;
    private MappingJacksonValue mappingJacksonValue;

    private final EmployeeWorkRequestMasterRepo employeeWorkRequestMasterRepo;

    private final EmployeeWorkRequestDetailsRepo employeeWorkRequestDetailsRepo;

    private final HolidayRepository holidayRepository;

    private final EmployeeHolidayRepository employeeHolidayRepository;

    public EmployeeWorkRequestServiceImpl(ResponseModel response, EmployeeWorkRequestMasterRepo employeeWorkRequestMasterRepo,
                                          EmployeeWorkRequestDetailsRepo employeeWorkRequestDetailsRepo, HolidayRepository holidayRepository, EmployeeHolidayRepository employeeHolidayRepository) {
        this.response = response;
        this.employeeWorkRequestMasterRepo = employeeWorkRequestMasterRepo;
        this.employeeWorkRequestDetailsRepo = employeeWorkRequestDetailsRepo;
        this.holidayRepository = holidayRepository;
        this.employeeHolidayRepository = employeeHolidayRepository;
    }

    @Override
    public ResponseEntity<Object> addRequestDetails(EmployeeWorkRequestMasterDTO employeeWorkRequestMasterDTO) {
        try {
            String roleName = SqlConnectionSetup.getJdbcConnection ()
                    .queryForObject ("exec GetRoleByEmployeeID ?;", String.class, employeeWorkRequestMasterDTO.getEnteredBy ());

            if(StringUtils.isBlank (roleName)){
                return catchException ("addRequestDetails()", null, "Failed","Unable to get employee role name.");
            }

            Instant startDate = InstantFormatter.InstantFormat (employeeWorkRequestMasterDTO.getFromDate ());
            Instant endDate = InstantFormatter.InstantFormat (employeeWorkRequestMasterDTO.getToDate ());

            LeaveDatesModel requestDatesExcludingHoliday = excludeHoliday (employeeWorkRequestMasterDTO);

            List<EmployeeWorkRequestDetailsRepo.WorkDetailsCount> wfhCount = employeeWorkRequestDetailsRepo
                    .findByEmployeeIdAndRequestDate (employeeWorkRequestMasterDTO.getEmployeeId (),
                    startDate,
                    endDate);

            double totalWfhCount = wfhCount.stream()
                    .mapToDouble (data -> data.getTotalWfhCount ())
                    .sum();

            if (roleName.contains (RoleEnum.EMPLOYEE.getValue ()) && (totalWfhCount >= 1)) {
                return catchException ("addRequestDetails()", null, "Failed","Employee can avail maximum of 1 day work from home. You have already taken 1 day.");
            } else if (requestDatesExcludingHoliday.workDays ().isEmpty ()) {
                return catchException ("addRequestDetails()", null, "Failed", "Requested dates is holiday, Please select valid date.");
            } else if (startDate.isAfter (endDate)) {
                return catchException ("addRequestDetails()", null, "Failed", "Start date should be before end date.");
            }

            List<EmployeeWorkRequestDetails> requestDetailsList = employeeWorkRequestDetailsRepo.findByEmployeeIdAndRequestDateBetween (
                            employeeWorkRequestMasterDTO.getEmployeeId (),
                            InstantFormatter.InstantFormat (employeeWorkRequestMasterDTO.getFromDate ()),
                            InstantFormatter.InstantFormat (employeeWorkRequestMasterDTO.getToDate ()))
                    .stream ()
                    .filter (requestDetail -> !Objects.equals (requestDetail.getRequestId ().getWorkRequestId (), employeeWorkRequestMasterDTO.getWorkRequestId ()))
                    .filter (requestDetails -> (requestDetails.getApprovalStatus ().equalsIgnoreCase (LeaveStatusEnum.TO_BE_APPROVED.getValue ()) ||
                            requestDetails.getApprovalStatus ().equalsIgnoreCase (LeaveStatusEnum.APPROVED_STATUS.getValue ())))
                    .toList ();



            if (!requestDetailsList.isEmpty ()) {
                return catchException ("addRequestDetails()", null, "Failed", "Requested dates is overlapping with previous request. Please check.");
            }

            EmployeeWorkRequestMaster employeeWorkRequestMaster = new EmployeeWorkRequestMaster ();

            employeeWorkRequestMaster.setEmployeeId (employeeWorkRequestMasterDTO.getEmployeeId ());
            employeeWorkRequestMaster.setRequestFromForH (employeeWorkRequestMasterDTO.getRequestFromForH ());
            employeeWorkRequestMaster.setRequestToForH (employeeWorkRequestMasterDTO.getRequestToForH ());
            employeeWorkRequestMaster.setFromDate (startDate);
            employeeWorkRequestMaster.setToDate (endDate);
            employeeWorkRequestMaster.setEnteredOn (InstantFormatter.InstantFormat (employeeWorkRequestMasterDTO.getEnteredOn ()));
            employeeWorkRequestMaster.setEnteredBy (employeeWorkRequestMasterDTO.getEnteredBy ());
            employeeWorkRequestMaster.setRemarks (employeeWorkRequestMasterDTO.getRemarks ());
            employeeWorkRequestMaster.setStatus (Constants.REVIEW_COMMENT);

            EmployeeWorkRequestMaster workRequestMaster = employeeWorkRequestMasterRepo.save (employeeWorkRequestMaster);

            for (Instant workDate : requestDatesExcludingHoliday.workDays ()) {

                EmployeeWorkRequestDetails employeeWorkRequestDetails = new EmployeeWorkRequestDetails ();

                employeeWorkRequestDetails.setEmployeeId (employeeWorkRequestMasterDTO.getEmployeeId ());
                employeeWorkRequestDetails.setRequestDate (workDate);
                employeeWorkRequestDetails.setRequestId (workRequestMaster);
                employeeWorkRequestDetails.setApprovalStatus (LeaveStatusEnum.TO_BE_APPROVED.getValue ());

                EmployeeWorkRequestDetails workRequestDetails = employeeWorkRequestDetailsRepo.save (employeeWorkRequestDetails);
            }

            WorkRequestEmailDetails workRequestEmailDetails = SqlConnectionSetup.getJdbcConnection ()
                    .queryForObject ("exec GetWorkRequestDetailsForEmail ?;",
                    BeanPropertyRowMapper.newInstance (WorkRequestEmailDetails.class),workRequestMaster.getWorkRequestId ());

            if(workRequestEmailDetails == null){
                return catchException ("addRequestDetails()", null, "Failed", "Work from Request added successfully, but unable to get email details.");
            }
            workRequestEmailDetails.setRequestAction ( Constants.LEDGER_ADD );
            workRequestEmailDetails.setNoOfDaysRequested (requestDatesExcludingHoliday.noOfDaysApplied ());

            response.setData (workRequestEmailDetails);
            response.setStatus (true);
            response.setMessage ("Work home request added successfully.");
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("addRequestDetails()", e, "Failed", "Unable to add work from request.");
        }
    }

    @Override
    public ResponseEntity<Object> editRequestDetails(Integer requestId, EmployeeWorkRequestMasterDTO employeeWorkRequestMasterDTO) {
        try {
            Optional<EmployeeWorkRequestMaster> workRequestById = employeeWorkRequestMasterRepo.findById (requestId);

            Optional<EmployeeWorkRequestDetails> workDetailsById = employeeWorkRequestDetailsRepo
                    .findByRequestId_WorkRequestIdAndEmployeeId (workRequestById, employeeWorkRequestMasterDTO.getEmployeeId ());

            Instant startDate = InstantFormatter.InstantFormat (employeeWorkRequestMasterDTO.getFromDate ());
            Instant endDate = InstantFormatter.InstantFormat (employeeWorkRequestMasterDTO.getToDate ());

            if (workRequestById.isEmpty () || workDetailsById.isEmpty ()) {
                return catchException ("editRequestDetails()", null, "Failed", "Employee work home request not found.");
            } else if (startDate.isAfter (endDate)) {
                return catchException ("editRequestDetails()", null, "Failed", "Start date should be before end date.");
            }

            List<EmployeeWorkRequestDetails> requestDetailsList = employeeWorkRequestDetailsRepo.findByEmployeeIdAndRequestDateBetween (
                            employeeWorkRequestMasterDTO.getEmployeeId (),
                            InstantFormatter.InstantFormat (employeeWorkRequestMasterDTO.getFromDate ()),
                            InstantFormatter.InstantFormat (employeeWorkRequestMasterDTO.getToDate ()))
                    .stream ()
                    .filter (requestDetail -> !Objects.equals (requestDetail.getRequestId ().getWorkRequestId (), employeeWorkRequestMasterDTO.getWorkRequestId ()))
                    .filter (requestDetail -> employeeWorkRequestDetailsRepo.findByRequestId_WorkRequestIdAndApprovalStatusNotIn (
                            requestDetail.getRequestId ().getWorkRequestId (),
                            Arrays.asList (LeaveStatusEnum.CANCELLED_STATUS.getValue (), LeaveStatusEnum.REJECTED_STATUS.getValue ())).isEmpty ()).toList ();

            if (!requestDetailsList.isEmpty ()) {
                return catchException ("editRequestDetails()", null, "Failed", "Requested dates is overlapping with previous request. Please check.");
            }

            workRequestById.get ().setRequestFromForH (employeeWorkRequestMasterDTO.getRequestFromForH ());
            workRequestById.get ().setRequestToForH (employeeWorkRequestMasterDTO.getRequestToForH ());
            workRequestById.get ().setFromDate (startDate);
            workRequestById.get ().setToDate (endDate);
            workRequestById.get ().setModifiedOn (InstantFormatter.InstantFormat (employeeWorkRequestMasterDTO.getModifiedOn ()));
            workRequestById.get ().setModifiedBy (employeeWorkRequestMasterDTO.getModifiedBy ());
            workRequestById.get ().setRemarks (employeeWorkRequestMasterDTO.getRemarks ());

            EmployeeWorkRequestMaster workRequestMaster = employeeWorkRequestMasterRepo.save (workRequestById.get ());

            workDetailsById.get ().setRequestDate (startDate);

            EmployeeWorkRequestDetails workRequestDetails = employeeWorkRequestDetailsRepo.save (workDetailsById.get ());

            WorkRequestEmailDetails workRequestEmailDetails = SqlConnectionSetup.getJdbcConnection ()
                    .queryForObject ("exec GetWorkRequestDetailsForEmail ?;",
                            BeanPropertyRowMapper.newInstance (WorkRequestEmailDetails.class),workRequestMaster.getWorkRequestId ());

            if(workRequestEmailDetails == null){
                return catchException ("editRequestDetails()", null, "Failed", "Work from Request edited successfully, but unable to get email details.");
            }
            workRequestEmailDetails.setRequestAction ( Constants.LEDGER_UPDATE );
            response.setStatus (true);
            response.setMessage ("Work home request edited successfully.");
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("editRequestDetails()", e, "Failed", "Unable to edit work from request.");
        }
    }

    @Override
    public ResponseEntity<Object> reviewRequestDetails(WorkRequestApproveDetails workRequestApproveDetails) {
        try {
            Optional<EmployeeWorkRequestMaster> workRequestMasterRepoById = employeeWorkRequestMasterRepo
                    .findById (workRequestApproveDetails.getRequestId ());

            List<EmployeeWorkRequestDetails> requestDetailsIdIn = employeeWorkRequestDetailsRepo
                    .findByRequestDetailsIdIn (workRequestApproveDetails.getWorkRequestDetailId ());

            double noOfDaysApplied = requestDetailsIdIn.size();

            if (workRequestMasterRepoById.isEmpty ()) {
                return catchException ("reviewRequestDetails()", null, "Not found", "Work from home request details not found.");
            }

            for (EmployeeWorkRequestDetails details : requestDetailsIdIn) {
                if (workRequestMasterRepoById.get ().getRequestFromForH ().equalsIgnoreCase("H")
                        && details.getRequestDate ().equals(workRequestMasterRepoById.get ().getFromDate ())) {
                    noOfDaysApplied = noOfDaysApplied - 0.5;
                } else if (workRequestMasterRepoById.get ().getRequestToForH ().equalsIgnoreCase("H")
                        && details.getRequestDate ().equals(workRequestMasterRepoById.get ().getToDate ())) {
                    noOfDaysApplied = noOfDaysApplied - 0.5;
                }
            }

            switch (workRequestApproveDetails.getStatus()) {

                case Constants.APPROVED_STATUS -> {
                    List<EmployeeWorkRequestDetailsRepo.WorkDetailsCount> wfhCount = employeeWorkRequestDetailsRepo.findByEmployeeIdAndRequestDate (
                            workRequestMasterRepoById.get ().getEmployeeId (),
                            workRequestMasterRepoById.get ().getFromDate (),
                            workRequestMasterRepoById.get ().getToDate ());

                    boolean approvedRequestCount = wfhCount.stream ().filter (data -> data.getApprovalStatus ().equalsIgnoreCase (Constants.APPROVED_STATUS))
                            .anyMatch (value -> value.getTotalWfhCount () >= 1);

                    if (isAlreadyReviewed(requestDetailsIdIn)) {
                        return alreadyReviewedResponse(requestDetailsIdIn);
                    }
                    else if (approvedRequestCount && !workRequestApproveDetails.getIsAdditionalWfh ()) {
                       return catchException ("reviewRequestDetails()", null, OPTIONAL_TYPE,
                                    String.format ("Already taken maximum %s work from home for current month.</br> Are you sure want to Approve given work from home?",wfhCount.get (0).getTotalWfhCount ()));
                    }
                }
                case Constants.REJECTED_STATUS -> {
                    if (isAlreadyReviewed(requestDetailsIdIn)) {
                        return alreadyReviewedResponse(requestDetailsIdIn);
                    }
                }
                case Constants.CANCELLED_STATUS -> {
                    if (isEligibleForCancellation(requestDetailsIdIn)) {
                        return alreadyReviewedResponse(requestDetailsIdIn);
                    }
                }
                default -> {
                    return catchException ("reviewRequestDetails()", null, "Failed", "Please select valid approval or rejection action.");
                }
            }

            for (EmployeeWorkRequestDetails employeeWorkRequestDetails: requestDetailsIdIn) {

                employeeWorkRequestDetails.setApprovalStatus (workRequestApproveDetails.getStatus ());
                employeeWorkRequestDetails.setApproverComments (workRequestApproveDetails.getApproverComments ());
                employeeWorkRequestDetails.setReviewedOn (InstantFormatter.InstantFormat (workRequestApproveDetails.getApprovedOn ()));
                 employeeWorkRequestDetails.setReviewedBy (workRequestApproveDetails.getApprovedBy ());

                employeeWorkRequestDetailsRepo.save (employeeWorkRequestDetails);
            }
            workRequestMasterRepoById.get().setStatus("Reviewed");
            employeeWorkRequestMasterRepo.save(workRequestMasterRepoById.get());

            WorkRequestEmailDetails workRequestEmailDetails = SqlConnectionSetup.getJdbcConnection ()
                    .queryForObject ("exec GetWorkRequestDetailsForEmail ?;",
                            BeanPropertyRowMapper.newInstance (WorkRequestEmailDetails.class),workRequestMasterRepoById.get().getWorkRequestId ());

            if(workRequestEmailDetails == null || ObjectUtils.isEmpty (workRequestEmailDetails)) {
                return catchException ("reviewRequestDetails()", null, "Failed", String.format ("Work From Home request %s successfully."
                        , LeaveStatusEnum.getEnumValueFromString (workRequestApproveDetails.getStatus ())));
            }
            workRequestEmailDetails.setRequestAction (Constants.ACTIVE_RECORD_STATUS);
            workRequestEmailDetails.setNoOfDaysRequested (noOfDaysApplied);

            response.setMessage(String.format("Work From Home request %s successfully.",LeaveStatusEnum.getEnumValueFromString (workRequestApproveDetails.getStatus ())));
            response.setStatus(true);
            response.setData (workRequestEmailDetails);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "message", STATUS });
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("reviewRequestDetails()", e, "Failed", "Unable to review employee work from home request.");
        }
    }

    @Override
    public ResponseEntity<Object> viewRequestQueueDetails(Integer requestId) {
        try {
            List<WorkRequestDetails> requestHistory = SqlConnectionSetup.getJdbcConnection ()
                    .query ("EXEC GetEmployeeRequestDetailsForRerview ?;", BeanPropertyRowMapper.newInstance (WorkRequestDetails.class),
                    requestId);

            response.setStatus (true);
            response.setData (requestHistory);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("viewRequestQueueDetails()", e, "Failed", "Unable to get employee work from home request details.");
        }
    }

    private boolean isAlreadyReviewed(List<EmployeeWorkRequestDetails> requestDetailsIdIn) {
        return requestDetailsIdIn.stream().noneMatch (
                l -> l.getApprovalStatus().equalsIgnoreCase(Constants.TO_BE_APPROVED));
    }

    private boolean isEligibleForCancellation(List<EmployeeWorkRequestDetails> requestDetailsIdIn) {
        return requestDetailsIdIn.stream().noneMatch (
                l -> l.getApprovalStatus().equalsIgnoreCase(Constants.APPROVED_STATUS));
    }

    private ResponseEntity<Object> alreadyReviewedResponse(List<EmployeeWorkRequestDetails> requestDetailsIdIn) {

        String currentStatus = requestDetailsIdIn.stream().map(EmployeeWorkRequestDetails :: getApprovalStatus )
                .distinct ().findFirst ().orElseThrow (() -> new NullPointerException (("Approval status not found.")));

        String message = LeaveStatusEnum.getEnumValueFromString(currentStatus);
        return catchException("approveOrRejectPermissionRequest()", null, "Already reviewed",
                String.format("Work Home request details has been %s already", message));
    }

    @Override
    public ResponseEntity<Object> getRequestHistory(RequestFilter requestFilter) {
        try {
            List<Object> requestHistory = SqlConnectionSetup.getJdbcConnection ().query ("EXEC getEmployeeRequestHistory ?,?,?,?;", new ResultSetMapper (),
                    requestFilter.getEmployeeId (),
                    requestFilter.getStartDate (),
                    requestFilter.getEndDate (),
                    requestFilter.getStatus ());

            response.setStatus (true);
            response.setData (requestHistory);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("getRequestHistory()", e, "Failed", "Unable to get employee work from home request history.");
        }
    }

    @Override
    public ResponseEntity<Object> getEmpLastWorkRequest(Integer employeeId) {
        try {
            List<Object> latestRequestHistory = SqlConnectionSetup.getJdbcConnection ().query ("EXEC getEmpLastWorkRequest ?;", new ResultSetMapper (),
                    employeeId);

            response.setStatus (true);
            response.setData (latestRequestHistory);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("getEmpLastWorkRequest()", e, "Failed", "Unable to get employee latest work from home request details.");
        }
    }

    private LeaveDatesModel excludeHoliday(EmployeeWorkRequestMasterDTO employeeWorkRequestMasterDTO) {

        ArrayList<Instant> workDays = new ArrayList<> ();
        double noOfDaysApplied = 0;
        LeaveDatesModel requestDates = new LeaveDatesModel (noOfDaysApplied, workDays);
        try {
            Instant date = InstantFormatter.InstantFormat (employeeWorkRequestMasterDTO.getFromDate ());
            if (!employeeWorkRequestMasterDTO.getFromDate ().equals (employeeWorkRequestMasterDTO.getToDate ())) {
                noOfDaysApplied = "F".equals (employeeWorkRequestMasterDTO.getRequestToForH ()) ? noOfDaysApplied + 1
                        : noOfDaysApplied + 0.5;
                noOfDaysApplied = "F".equals (employeeWorkRequestMasterDTO.getRequestFromForH ()) ? noOfDaysApplied + 1
                        : noOfDaysApplied + 0.5;
                noOfDaysApplied = noOfDaysApplied
                        + Duration.between (InstantFormatter.InstantFormat (employeeWorkRequestMasterDTO.getFromDate ())
                        , InstantFormatter.InstantFormat (employeeWorkRequestMasterDTO.getToDate ())).toDays () - 1;
            } else {
                noOfDaysApplied = "H".equals (employeeWorkRequestMasterDTO.getRequestFromForH ()) ? 0.5 : "H".equals (employeeWorkRequestMasterDTO.getRequestToForH ()) ? 0.5 : 1;
            }
            while (!date.isAfter (InstantFormatter.InstantFormat (employeeWorkRequestMasterDTO.getToDate ()))) {
                Optional<Holiday> employeeHoliday = holidayRepository
                        .findHolidayByLocationidAndDate (date.toString (), LocationEum.INDIA.getValue ());

                Boolean isHoliday = employeeHoliday.isPresent ();

                if (employeeHoliday.isPresent ()) {

                    if(employeeHoliday.get ().getIsOptional ().equalsIgnoreCase (Boolean.TRUE.toString ())){
                        isHoliday = employeeHoliday.get ().getIsOptional ().equalsIgnoreCase (Boolean.TRUE.toString ()) ?
                                employeeHolidayRepository.findByEmployeeIdAndHoliDayId_HolidayDetailId (employeeWorkRequestMasterDTO.getEmployeeId ()
                                        , employeeHoliday.get ().getHolidayDetailId ()).isPresent () ? Boolean.TRUE : Boolean.FALSE : Boolean.FALSE;
                    }

                }

                DayOfWeek dayOfWeek = InstantFormatter.getWeek (date);

                if (dayOfWeek.equals (DayOfWeek.SATURDAY)
                        || dayOfWeek.equals (DayOfWeek.SUNDAY)
                        || Boolean.TRUE.equals (isHoliday)) {

                    if (InstantFormatter.InstantFormat (date).equals (employeeWorkRequestMasterDTO.getFromDate ()) && "H".equals (employeeWorkRequestMasterDTO.getRequestFromForH ()))
                        noOfDaysApplied -= 0.5;
                    else if (InstantFormatter.InstantFormat (date).equals (employeeWorkRequestMasterDTO.getToDate ()) && "H".equals (employeeWorkRequestMasterDTO.getRequestToForH ()))
                        noOfDaysApplied -= 0.5;
                    else
                        noOfDaysApplied -= 1;
                } else {
                    workDays.add (date);
                }

                date = date.plus (Duration.ofDays (1));
                requestDates = new LeaveDatesModel (noOfDaysApplied, workDays);
            }
        } catch (Exception e) {
            catchException ("excludeHoliday()", e, "Failed", "Unable to get employee holiday details");
        }
        return requestDates;
    }

    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
        logger.error ("{} Error : {}", methodName, e);
        response.setStatus (false);
        response.setInformation (new ExceptionBean (Instant.now (), message, description));
        mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"information", STATUS});
        return new ResponseEntity<> (mappingJacksonValue, HttpStatus.CONFLICT);
    }
}
