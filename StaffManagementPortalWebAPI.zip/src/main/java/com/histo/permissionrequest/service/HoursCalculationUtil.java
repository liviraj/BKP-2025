package com.histo.permissionrequest.service;

import java.time.Duration;
import java.time.Instant;

public class HoursCalculationUtil {

    public static Float hoursCalculation(Instant startTime,Instant endTime) {
        // Calculate the duration between the two instants
        Duration duration = Duration.between (startTime, endTime);

        // Get the total minutes
        long totalMinutes = duration.toMinutes ();

        // Calculate hours and remaining minutes
        long hours = totalMinutes / 60; // 1
        long minutes = totalMinutes % 60; // 65%1 = 0.05000

        // Format the result as hours.minutes
        String result = String.format ("%d.%02d", hours, minutes);

        Float noOfHrs = Float.parseFloat (result);

        return noOfHrs;

    }

}
