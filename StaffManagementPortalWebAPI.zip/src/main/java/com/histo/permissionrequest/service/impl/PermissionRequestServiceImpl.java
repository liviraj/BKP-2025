package com.histo.permissionrequest.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.permissionrequest.dto.WorkPermissionDTO;
import com.histo.permissionrequest.entity.PermissionTypes;
import com.histo.permissionrequest.entity.WorkPermissions;
import com.histo.permissionrequest.model.*;
import com.histo.permissionrequest.model.FilterModel;
import com.histo.permissionrequest.repository.PermissionTypesRepository;
import com.histo.permissionrequest.repository.WorkPermissionRepository;
import com.histo.permissionrequest.service.HoursCalculationUtil;
import com.histo.permissionrequest.service.PermissionRequestService;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.intranet.repository.LoginRepository;
import com.histo.staffmanagementportal.model.*;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class PermissionRequestServiceImpl implements PermissionRequestService {

    private static final Logger logger = LogManager.getLogger(PermissionRequestServiceImpl.class);
    private static final String STATUS = "status";

    private static final String OPTIONAL_TYPE = "Optional type";
    private final ResponseModel response;
    private MappingJacksonValue mappingJacksonValue;

    private final PermissionTypesRepository permissionTypesRepository;

    private final WorkPermissionRepository workPermissionRepository;

    private final LoginRepository loginRepository;

    public PermissionRequestServiceImpl(ResponseModel response, PermissionTypesRepository permissionTypesRepository, WorkPermissionRepository workPermissionRepository, LoginRepository loginRepository) {
        this.response = response;
        this.permissionTypesRepository = permissionTypesRepository;
        this.workPermissionRepository = workPermissionRepository;
        this.loginRepository = loginRepository;
    }


    @Override
    public ResponseEntity<Object> getPermissiontype() {
        try{
            List<PermissionTypes> permissionTypes = permissionTypesRepository.findAll ();
            permissionTypes.add (0,new PermissionTypes (0,"All"));

            response.setData (permissionTypes);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        }
        catch (Exception e){
            return catchException ("getPermissiontype()", e, "Failed", "Unable to get permission type details.");
        }
    }

    @Override
    public ResponseEntity<Object> getEmployeePermissionHistory(FilterModel filterModel) {
        try{

            List<PermisisonHistory> permissionDetails = SqlConnectionSetup.getJdbcConnection ().query ("exec GetEmployeePermissionDetails ?,?,?,?,?,?,?;",
                    BeanPropertyRowMapper.newInstance (PermisisonHistory.class),
                    filterModel.getFromTime (),
                    filterModel.getToTime (),
                    filterModel.getEmployeeId (),
                    filterModel.getLocationId (),
                    filterModel.getPermissionTypeId (),
                    filterModel.getStatus (),
                    filterModel.getSupervisorId ()
            );

            response.setData (permissionDetails);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        }
        catch (Exception e){
            return catchException ("getEmployeePermissionHistory()", e, "Failed", "Unable to get employee permission details.");
        }
    }

    @Override
    public ResponseEntity<Object> addPermissionRequest(WorkPermissionDTO workPermissionDTO) {
        try{

            WorkPermissions workPermissions = new WorkPermissions ();

            return addEmployeeWorkPermission (workPermissionDTO,workPermissions,"addPermissionRequest()",0);
        }
        catch (Exception e){
            return catchException ("addPermissionRequest()", e, "Failed", "Unable to add employee permission details.");
        }
    }

    @Override
    public ResponseEntity<Object> getPermissionRequest(Integer permissionId) {
        try{

            Optional<WorkPermissions> workPermissions = workPermissionRepository.findByPermissionId (permissionId);

            if(workPermissions.isEmpty ()){
                return catchException ("getPermissionRequest()", null, "Not found", "Employee permission details not found.");
            }

            WorkPermissionDTO workPermissionDTO = new WorkPermissionDTO ();

            workPermissionDTO.setEmployeeId (workPermissions.get().getEmployeeId ());
            workPermissionDTO.setFromTime (InstantFormatter.InstantFormat (workPermissions.get().getFromTime ()));
            workPermissionDTO.setToTime (InstantFormatter.InstantFormat (workPermissions.get().getToTime ()));
            workPermissionDTO.setPermissionDate (InstantFormatter.InstantFormat (workPermissions.get().getPermissionDate ()));
            workPermissionDTO.setRemarks (workPermissions.get().getRemarks ());
            workPermissionDTO.setNoofHrs (workPermissions.get().getNoofHrs ());
            workPermissionDTO.setEnteredBy (workPermissions.get().getEnteredBy ());
            workPermissionDTO.setPermissionType (workPermissions.get().getPermissionType ().getPermissionTypeID ());
            workPermissionDTO.setApprovalStatus (workPermissions.get().getApprovalStatus ());
            workPermissionDTO.setLastModifiedBy (workPermissions.get().getLastModifiedBy ());
            workPermissionDTO.setLastModifiedOn (InstantFormatter.InstantFormat (workPermissions.get ().getLastModifiedOn ()));


            response.setData (workPermissionDTO);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        }
        catch (Exception e){
            return catchException ("getPermissionRequest()", e, "Failed", "Unable to get employee permission details.");
        }
    }

    @Override
    public ResponseEntity<Object> updatePermissionRequest(WorkPermissionDTO workPermissionDTO, Integer permissionId) {
        try{

            Optional<WorkPermissions> workPermissions = workPermissionRepository.findByPermissionId (permissionId);

            if(workPermissions.isEmpty ()){
                return catchException ("updatePermissionRequest()", null, "Not found", "Permission details not found.");
            }

            return addEmployeeWorkPermission (workPermissionDTO,workPermissions.get (),"updatePermissionRequest()",permissionId);

        }catch (Exception e){
            return catchException ("updatePermissionRequest()", e, "Failed", "Unable to edit employee permission details.");
        }
    }

    @Override
    public ResponseEntity<Object> approveOrRejectPermissionRequest(PermissionApproverDetails permissionApproverDetails) {
        try{
            Optional<WorkPermissions> workPermissions = workPermissionRepository.findByPermissionId (permissionApproverDetails.getPermissionId ());

            if(workPermissions.isEmpty ()){
                return catchException ("approveOrRejectPermissionRequest()", null, "Not found", "Permission details not found.");
            }

            Integer locationIdByEmployeeId = loginRepository.findLocationIdByEmployeeId (workPermissions.get ().getEmployeeId ());

            String currentStatus = workPermissions.get().getApprovalStatus();
            response.setMessage(String.format("Permission request %s successfully.",
                    LeaveStatusEnum.getEnumValueFromString(permissionApproverDetails.getStatus())));

            switch (permissionApproverDetails.getStatus()) {
                case Constants.APPROVED_STATUS -> {
                    if (isAlreadyReviewed(currentStatus)) {
                        return alreadyReviewedResponse(currentStatus);
                    }
                    else if (locationIdByEmployeeId.equals (LocationEum.INDIA.getValue())) {
                        long totalPermissionHrsTaken = workPermissionRepository.getTotalPermissionCount(
                                workPermissions.get().getEmployeeId(),
                                InstantFormatter.InstantFormat(workPermissions.get().getPermissionDate()),
                                workPermissions.get().getPermissionId(),
                                LeaveStatusEnum.APPROVED_STATUS.getValue (),
                                PermissionTypesEnum.PERSONAL.getValue ());

                            if((totalPermissionHrsTaken >= Constants.MAXI_PERMISSION_COUNT_INDIA) && !permissionApproverDetails.getIsAdditionalPermission ())
                                return catchException ("approveOrRejectPermissionRequest()", null, OPTIONAL_TYPE,
                                        String.format ("Already taken maximum of %s permissions for current month.</br> Are you sure want to Approve given permission",totalPermissionHrsTaken));
                    }
                }
                case Constants.REJECTED_STATUS -> {
                    if (isAlreadyReviewed(currentStatus)) {
                        return alreadyReviewedResponse(currentStatus);
                    }
                }
                case Constants.CANCELLED_STATUS -> {
                    if (!isEligibleForCancellation(currentStatus)) {
                        return alreadyReviewedResponse(currentStatus);
                    }
                }
                case Constants.TO_BE_CANCELLED -> {
                    if (!isEligibleForCancellationRequest(currentStatus)) {
                        return alreadyReviewedResponse(currentStatus);
                    }
                    response.setMessage("Cancellation request submitted successfully");
                }
                default -> {
                    return catchException ("approveOrRejectPermissionRequest()", null, "Failed", "Please select valid approval or rejection action.");
                }
            }

            workPermissions.get ().setReviewedBy (permissionApproverDetails.getReviewedBy ());
            workPermissions.get ().setReviewedOn (InstantFormatter.InstantFormat (permissionApproverDetails.getReviewedOn ()));
            workPermissions.get ().setReviewerComments (permissionApproverDetails.getComments ());
            workPermissions.get().setLastModifiedBy(permissionApproverDetails.getModifiedBy());
            workPermissions.get()
                    .setLastModifiedOn(InstantFormatter.InstantFormat(permissionApproverDetails.getModifiedOn()));
            workPermissions.get().setReviewerComments(permissionApproverDetails.getComments());
            workPermissions.get().setApprovalStatus (permissionApproverDetails.getStatus ());

            WorkPermissions permissions = workPermissionRepository.save (workPermissions.get ());
            PermissionEmailDetails permissionEmailDetails = SqlConnectionSetup.getJdbcConnection ().queryForObject ("exec GetPermissionDetailsForEmail ?;",
                    BeanPropertyRowMapper.newInstance (PermissionEmailDetails.class), permissions.getPermissionId ());

            if(permissionEmailDetails == null || ObjectUtils.isEmpty (permissionEmailDetails)){
                return catchException ("approveOrRejectPermissionRequest()", null, "Failed", (String.format("Permission request %s successfully. But unable to get email content.",
                        LeaveStatusEnum.getEnumValueFromString(permissionApproverDetails.getStatus()))));
            }
            permissionEmailDetails.setPermissionAction (Constants.ACTIVE_RECORD_STATUS);

            response.setData (permissionEmailDetails);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);


        }catch (Exception e){
            return catchException ("approveOrRejectPermissionRequest()", e, "Failed", "Unable to update employee permission reviewer details.");
        }
    }

    @Override
    public ResponseEntity<Object> getPermissionDetailsForEmail(EmailFilterModel filterModel) {
        try{

            PermisisonHistory permissionDetails = SqlConnectionSetup.getJdbcConnection ().queryForObject ("exec GetPermissionHistoryForEmail ?,?;"
                    , BeanPropertyRowMapper.newInstance (PermisisonHistory.class),
                    filterModel.getPermissionId (),
                    filterModel.getEmployeeId ());

            response.setData (permissionDetails);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        }
        catch (Exception e){
            return catchException ("getPermissionDetailsForEmail()", e, "Failed", "Unable to get employee permission details.");
        }
    }

    @Override
    public ResponseEntity<Object> getEmpLastPermissionRequest(Integer employeeId) {
        try{
            List<Object> empLastPermissionRequest = SqlConnectionSetup.getJdbcConnection ().query ("Exec getEmpLastPermissionRequest ?;", new ResultSetMapper (), employeeId);

            response.setData (empLastPermissionRequest);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter (response,new String[]{"data",STATUS});
            return new ResponseEntity<Object> (mappingJacksonValue,HttpStatus.OK);
        }
        catch(Exception e){
            return catchException ("getEmpLastPermissionRequest",e,"Failed","Unable to get employee last permission availed details.");
        }
    }

    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
        logger.error("{} Error : {}" , methodName, e);
        response.setStatus(false);
        response.setInformation(new ExceptionBean (Instant.now(), message, description));
        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }

    private ResponseEntity<Object> addEmployeeWorkPermission(WorkPermissionDTO workPermissionDTO,WorkPermissions workPermissions, String methodName,Integer permissionId){

        try{

            Instant startTime = InstantFormatter.InstantFormat (workPermissionDTO.getFromTime ());
            Instant endTime = InstantFormatter.InstantFormat (workPermissionDTO.getToTime ());

            List<WorkPermissions> permissionDetails = workPermissionRepository.findByEmployeeIdAndPermissionDateAndApprovalStatusIn (
                    workPermissionDTO.getEmployeeId (),
                    InstantFormatter.InstantFormat (workPermissionDTO.getPermissionDate ()),
                    Arrays.asList (Constants.APPROVED_STATUS,Constants.TO_BE_APPROVED,Constants.TO_BE_CANCELLED)
            );

            permissionDetails = permissionDetails.stream ().filter (details -> !details.getPermissionId ().equals (permissionId)).collect(Collectors.toList());

            PermissionTypes permissionTypeById = permissionTypesRepository.findById (workPermissionDTO.getPermissionType ())
                    .orElseThrow (() -> new NullPointerException ("Permission type not found for given id."));

            Integer locationIdByEmployeeId = loginRepository.findLocationIdByEmployeeId (workPermissionDTO.getEmployeeId ());

            if(ObjectUtils.isNotEmpty (permissionDetails)){
                return catchException (methodName, null, "Already exist", "Permission date overlapping with your previous requests. Please Check.");
            }
            else if(!startTime.isBefore (endTime))
            {
                return catchException (methodName, null, "Incorrect data", "Permission start time should be before permission end time. Please select valid time.");
            }
            else if(locationIdByEmployeeId.equals (LocationEum.INDIA.getValue ())){

                PermissionTypesEnum permissionTypesEnum = PermissionTypesEnum.getEnumFromString (workPermissionDTO.getPermissionType ());

                String roleNameByEmployeeId = loginRepository.findRoleNameByEmployeeId (workPermissionDTO.getEnteredBy ())
                        .orElseThrow (() -> new NullPointerException ("Employee Role name not found."));

                switch(permissionTypesEnum){
                    case PERSONAL -> {
                        long totalPermissionHrsTaken = workPermissionRepository.getTotalPermissionCount (
                                workPermissionDTO.getEmployeeId (),
                                workPermissionDTO.getPermissionDate (),
                                permissionId,
                                workPermissionDTO.getApprovalStatus (),
                                PermissionTypesEnum.PERSONAL.getValue ());

                        if(roleNameByEmployeeId != null){
                            if(roleNameByEmployeeId.equalsIgnoreCase (RoleEnum.EMPLOYEE.getValue()) &&
                                    totalPermissionHrsTaken >= Constants.MAXI_PERMISSION_COUNT_INDIA)
                                return catchException (methodName, null, "Exceeded permission Hours", "Already taken maximum of 2 permissions for current month.");
                        }

                    }

                    case ON_DUTY -> {
                        if(roleNameByEmployeeId.equalsIgnoreCase (RoleEnum.EMPLOYEE.getValue())){
                            return catchException (methodName, null, "Not Applicable", "Only HR or Admin can apply OnDuty permission for any employee.");
                        }
                    }
                    default ->  {return catchException (methodName, null, "Not Applicable", "Please select valid permission type.");}
                        // only HR can add
                }

            }

            Float noOfHrs = HoursCalculationUtil.hoursCalculation (InstantFormatter.InstantFormat (workPermissionDTO.getFromTime ())
                    , InstantFormatter.InstantFormat (workPermissionDTO.getToTime ()));

            if(noOfHrs > Constants.MAXI_PERMISSION_HRS &&
                    ObjectUtils.notEqual (permissionTypeById.getPermissionTypeID (),PermissionTypesEnum.ON_DUTY.getValue ())){
                return catchException (methodName, null, "Exceeded maximum Hours", "Employee can avail a maximum of 2 hours of permission.");
            }

            workPermissions.setEmployeeId (workPermissionDTO.getEmployeeId ());
            workPermissions.setFromTime (startTime);
            workPermissions.setToTime (endTime);
            workPermissions.setPermissionDate (InstantFormatter.InstantFormat (workPermissionDTO.getPermissionDate ()));
            workPermissions.setRemarks (workPermissionDTO.getRemarks ());
            workPermissions.setNoofHrs (noOfHrs);
            workPermissions.setLastModifiedBy (workPermissionDTO.getLastModifiedBy ());
            workPermissions.setLastModifiedOn (InstantFormatter.InstantFormat (workPermissionDTO.getLastModifiedOn ()));
            workPermissions.setEnteredBy (workPermissionDTO.getEnteredBy ());
            workPermissions.setPermissionType (permissionTypeById);
            workPermissions.setApprovalStatus (ObjectUtils.isEmpty (workPermissionDTO.getApprovalStatus ())?Constants.TO_BE_APPROVED :
                    workPermissionDTO.getApprovalStatus ());

            WorkPermissions permissions = workPermissionRepository.save (workPermissions);
            PermissionEmailDetails permissionEmailDetails = SqlConnectionSetup.getJdbcConnection ().queryForObject ("exec GetPermissionDetailsForEmail ?;",
                    BeanPropertyRowMapper.newInstance (PermissionEmailDetails.class), permissions.getPermissionId ());

            if(permissionEmailDetails == null || ObjectUtils.isEmpty (permissionEmailDetails)){
                return catchException ("addEmployeeWorkPermission()", null, "Failed",
                        permissionId == 0 ?"Permission request submitted successfully. But Unable to get email details."
                                :"Permission request updated successfully.But Unable to get email details.");
            }

            permissionEmailDetails.setPermissionAction (permissionId == 0 ? Constants.LEDGER_ADD : Constants.LEDGER_UPDATE);

            response.setData (permissionEmailDetails);
            response.setMessage (permissionId == 0 ?"Permission request submitted successfully.":"Permission request updated successfully.");
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        }
        catch (Exception e){
            return catchException ("addEmployeeWorkPermission()", e, "Failed", "Unable to add/edit employee permission details.");
        }
    }
    private boolean isAlreadyReviewed(String currentStatus) {
        return !currentStatus.equalsIgnoreCase(Constants.TO_BE_APPROVED);
    }

    private boolean isEligibleForCancellation(String currentStatus) {
        return currentStatus.equalsIgnoreCase(Constants.APPROVED_STATUS) ||
                currentStatus.equalsIgnoreCase(Constants.TO_BE_CANCELLED);
    }

    private ResponseEntity<Object> alreadyReviewedResponse(String currentStatus) {
        String message = LeaveStatusEnum.getEnumValueFromString(currentStatus);
        return catchException("approveOrRejectPermissionRequest()", null, "Already reviewed",
                String.format("Permission details has been %s already", message));
    }

    private boolean isEligibleForCancellationRequest(String currentStatus) {
        return currentStatus.equalsIgnoreCase(Constants.TO_BE_APPROVED) ||
                currentStatus.equalsIgnoreCase(Constants.APPROVED_STATUS);
    }

}
