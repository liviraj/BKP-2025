package com.histo.permissionrequest.entity;

import com.histo.staffmanagementportal.util.InstantConverter;
import lombok.Data;
import javax.persistence.*;
import java.time.Instant;

@Entity
@Data
@Table(name = "EmployeeWorkRequestMaster")
public class EmployeeWorkRequestMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "WorkRequestId")
    private Integer workRequestId;

    @Column(name = "EmployeeId", nullable = false)
    private Integer employeeId;

    @Column(name = "RequestDate")
    @Convert(converter = InstantConverter.class)
    private Instant requestDate;

    @Column(name = "FromDate", nullable = false)
    @Convert(converter = InstantConverter.class)
    private Instant fromDate;

    @Column(name = "ToDate", nullable = false)
    @Convert(converter = InstantConverter.class)
    private Instant toDate;

    @Column(name = "Remarks")
    private String remarks;

    @Column(name = "EnteredBy", nullable = false)
    private Integer enteredBy;

    @Column(name = "EnteredOn")
    @Convert(converter = InstantConverter.class)
    private Instant enteredOn;

    @Column(name = "RequestFromForH", nullable = false)
    private String requestFromForH;

    @Column(name = "RequestToForH", nullable = false)
    private String requestToForH;

    @Column(name = "Status")
    private String status;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @Column(name = "ModifiedOn")
    @Convert(converter = InstantConverter.class)
    private Instant modifiedOn;

}