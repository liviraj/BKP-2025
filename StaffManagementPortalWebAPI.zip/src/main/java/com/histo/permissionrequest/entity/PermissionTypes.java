package com.histo.permissionrequest.entity;

import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.Table;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Table(name = "PermissionTypes")
public class PermissionTypes {

    @Id
    @Column(name = "PermissionTypeID")
    private Integer permissionTypeID;

    @Column(name = "PermissionType", length = 25, nullable = false)
    private String permissionType;
}
