package com.histo.permissionrequest.entity;

import com.histo.staffmanagementportal.util.InstantConverter;
import lombok.*;

import javax.persistence.*;
import java.time.Instant;


@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Table(name = "WorkPermissions")
public class WorkPermissions {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "permissionId")
    private Integer permissionId;

    @Column(name = "EmployeeId", nullable = false)
    private Integer employeeId;

    @Column(name = "FromTime", nullable = false)
    @Convert(converter = InstantConverter.class)
    private Instant fromTime;

    @Column(name = "ToTime", nullable = false)
    @Convert(converter = InstantConverter.class)
    private Instant toTime;

    @Column(name = "NoofHrs")
    private Float noofHrs;

    @Column(name = "Remarks", length = 1000)
    private String remarks;

    @Column(name = "EnteredBy")
    private Integer enteredBy;

    @Column(name = "LastModifiedBy")
    private Integer lastModifiedBy;

    @Column(name = "LastModifiedOn")
    @Convert(converter = InstantConverter.class)
    private Instant lastModifiedOn;

    @ManyToOne
    @JoinColumn(name = "PermissionTypeID")
    private PermissionTypes permissionType;

    @Column(name = "reviewerComments", length = 1000)
    private String reviewerComments;

    @Column(name = "reviewedBy")
    private Integer reviewedBy;

    @Column(name = "reviewedOn")
    @Convert(converter = InstantConverter.class)
    private Instant reviewedOn;

    @Column(name = "permissionDate")
    @Convert(converter = InstantConverter.class)
    private Instant permissionDate;

    @Column(name = "approvalStatus", length = 50)
    private String approvalStatus;

}
