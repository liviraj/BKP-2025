package com.histo.permissionrequest.entity;

import com.histo.staffmanagementportal.util.InstantConverter;
import lombok.Data;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.Instant;


@Entity
@Data
@Table(name = "EmployeeWorkRequestDetails")
public class EmployeeWorkRequestDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "RequestDetailsId")
    private Integer requestDetailsId;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RequestId", nullable = false)
    private EmployeeWorkRequestMaster requestId;

    @Column(name = "EmployeeId", nullable = false)
    private Integer employeeId;

    @Column(name = "RequestDate", nullable = false)
    @Convert(converter = InstantConverter.class)
    private Instant requestDate;

    @Column(name = "ReviewedBy")
    private Integer reviewedBy;

    @Column(name = "ReviewedOn")
    @Convert(converter = InstantConverter.class)
    private Instant reviewedOn;

    @Column(name = "ApproverComments")
    private String approverComments;

    @Column(name = "ApprovalStatus")
    private String approvalStatus;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @Column(name = "ModifiedOn")
    @Convert(converter = InstantConverter.class)
    private Instant modifiedOn;

}
