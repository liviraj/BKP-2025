package com.histo.permissionrequest.dto;

import com.azure.core.annotation.Get;
import com.histo.permissionrequest.entity.PermissionTypes;
import lombok.*;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class WorkPermissionDTO {

    private Integer employeeId;
    private String fromTime;
    private String permissionDate;
    private String toTime;
    private Float noofHrs;
    private String remarks;
    private Integer enteredBy;
    private Integer lastModifiedBy;
    private String lastModifiedOn;
    private Integer permissionType;
    private String approvalStatus;

}
