package com.histo.permissionrequest.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class EmployeeWorkRequestMasterDTO {

    private Integer workRequestId;
    private Integer employeeId;
    private String requestDate;
    private String fromDate;
    private String toDate;
    private String remarks;
    private Integer enteredBy;
    private String enteredOn;
    private String requestFromForH;
    private String requestToForH;
    private String status;
    private Integer modifiedBy;
    private String modifiedOn;


}
