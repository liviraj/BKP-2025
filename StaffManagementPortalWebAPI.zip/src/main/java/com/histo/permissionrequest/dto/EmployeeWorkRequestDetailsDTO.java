package com.histo.permissionrequest.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class EmployeeWorkRequestDetailsDTO {

    private Integer requestDetailsId;
    private Integer requestId;
    private Integer employeeId;
    private String requestDate;
    private Integer reviewedBy;
    private String reviewedOn;
    private String approverComments;
    private String approvalStatus;
    private Integer modifiedBy;
    private String modifiedOn;

}
