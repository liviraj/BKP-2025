package com.histo.permissionrequest.resources;

import com.azure.core.annotation.QueryParam;
import com.histo.permissionrequest.dto.EmployeeWorkRequestMasterDTO;
import com.histo.permissionrequest.model.RequestFilter;
import com.histo.permissionrequest.model.WorkRequestApproveDetails;
import com.histo.permissionrequest.service.EmployeeWorkRequestService;
import com.histo.staffmanagementportal.model.Constants;
import com.histo.staffmanagementportal.service.EmailService;
import org.simpleframework.xml.Path;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/workRequest")
public class EmployeeWorkRequestResource {
    private  final EmployeeWorkRequestService employeeWorkRequestService;
    private final EmailService emailService;
    public EmployeeWorkRequestResource(EmployeeWorkRequestService employeeWorkRequestService, EmailService emailService) {
        this.employeeWorkRequestService = employeeWorkRequestService;
        this.emailService = emailService;
    }

    @GetMapping("/history")
    public ResponseEntity<Object> getEmployeeWorkRequestHistory(@QueryParam ("input") RequestFilter filterModel){
        return employeeWorkRequestService.getRequestHistory (filterModel);
    }

    @GetMapping
    public ResponseEntity<Object> getEmployeeWorkRequestQueue(@QueryParam ("input") RequestFilter filterModel){
        return employeeWorkRequestService.getRequestHistory (filterModel);
    }

    @GetMapping("/balance/{employeeId}")
    public ResponseEntity<Object> getEmployeeWorkDetailsByEmpId(@PathVariable Integer employeeId){
        return employeeWorkRequestService.getEmpLastWorkRequest (employeeId);
    }


    @GetMapping("/requestDetail/{requestId}")
    public ResponseEntity<Object> getWorkRequestDetailsForReview(@PathVariable Integer requestId){
        return employeeWorkRequestService.viewRequestQueueDetails (requestId);
    }

    @PostMapping
    public ResponseEntity<Object> addWorkRequest(@RequestBody EmployeeWorkRequestMasterDTO employeeWorkRequestMasterDTO){
        ResponseEntity<Object> responseEntity = employeeWorkRequestService.addRequestDetails (employeeWorkRequestMasterDTO);
        if(responseEntity.getStatusCode() == HttpStatus.OK) {
            ResponseEntity<Object>  workRequestEmail = emailService.sendEmployeeWorkRequestEmail (responseEntity.getBody ());
        }
        return responseEntity;
    }

    @PutMapping("{workRequestId}")
    public ResponseEntity<Object> updateWorkRequest(@PathVariable Integer workRequestId,@RequestBody EmployeeWorkRequestMasterDTO employeeWorkRequestMasterDTO){
        ResponseEntity<Object> responseEntity = employeeWorkRequestService.editRequestDetails (workRequestId, employeeWorkRequestMasterDTO);
        if(responseEntity.getStatusCode() == HttpStatus.OK) {
            ResponseEntity<Object>  workRequestEmail = emailService.sendEmployeeWorkRequestEmail (responseEntity.getBody ());
        }
        return responseEntity;
    }

    @PostMapping("/requestQueue")
    public ResponseEntity<Object> approveOrRejectWorkRequest(@RequestBody WorkRequestApproveDetails workRequestApproveDetails){
        ResponseEntity<Object> responseEntity = employeeWorkRequestService.reviewRequestDetails (workRequestApproveDetails);
        if(responseEntity.getStatusCode() == HttpStatus.OK ) {
            ResponseEntity<Object>  workRequestEmail = emailService.sendEmployeeWorkRequestApprovalEmail (responseEntity.getBody ());
        }
        return responseEntity;
    }
}
