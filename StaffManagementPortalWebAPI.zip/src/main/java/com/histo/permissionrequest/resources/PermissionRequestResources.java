package com.histo.permissionrequest.resources;


import com.azure.core.annotation.QueryParam;
import com.histo.permissionrequest.model.EmailFilterModel;
import com.histo.permissionrequest.model.FilterModel;
import com.histo.permissionrequest.model.PermissionApproverDetails;
import com.histo.permissionrequest.dto.WorkPermissionDTO;
import com.histo.permissionrequest.service.PermissionRequestService;
import com.histo.staffmanagementportal.model.Constants;
import com.histo.staffmanagementportal.service.EmailService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/permissions")
public class PermissionRequestResources {

    private  final PermissionRequestService permissionRequestService;
    private final EmailService emailService;

    public PermissionRequestResources(PermissionRequestService permissionRequestService, EmailService emailService) {
        this.permissionRequestService = permissionRequestService;
        this.emailService = emailService;
    }

    @GetMapping("/types")
    public ResponseEntity<Object> getTypesOfPermissions(){
        return permissionRequestService.getPermissiontype ();
    }

    @GetMapping("{permissionId}")
    public ResponseEntity<Object> getEmployeePermissionById(@PathVariable Integer permissionId){
        return permissionRequestService.getPermissionRequest (permissionId);
    }

    @GetMapping("/balance/{employeeId}")
    public ResponseEntity<Object> getEmployeePermissionDetailsByEmpId(@PathVariable Integer employeeId){
        return permissionRequestService.getEmpLastPermissionRequest (employeeId);
    }

    @GetMapping("/history")
    public ResponseEntity<Object> getPermissionHistory(@QueryParam (value = "input") FilterModel filterModel){
        return permissionRequestService.getEmployeePermissionHistory (filterModel);
    }

    @GetMapping("/requestDetail")
    public ResponseEntity<Object> getPermissionDetailsForReview(@QueryParam (value = "input") EmailFilterModel filterModel){
        return permissionRequestService.getPermissionDetailsForEmail (filterModel);
    }

    @PostMapping
    public ResponseEntity<Object> addPermissionRequest(@RequestBody WorkPermissionDTO workPermissionDTO){
        ResponseEntity<Object> responseEntity = permissionRequestService.addPermissionRequest (workPermissionDTO);
        if(responseEntity.getStatusCode() == HttpStatus.OK) {
            ResponseEntity<Object>  permissionRequestEmail = emailService.sendPermissionRequestEmail (responseEntity.getBody ());
        }
        return responseEntity;
    }

    @PutMapping("{permissionId}")
    public ResponseEntity<Object> updatePermissionRequest(@PathVariable Integer permissionId,@RequestBody WorkPermissionDTO workPermissionDTO){
        ResponseEntity<Object> responseEntity = permissionRequestService.updatePermissionRequest (workPermissionDTO, permissionId);
        if(responseEntity.getStatusCode() == HttpStatus.OK) {
            ResponseEntity<Object>  permissionRequestEmail = emailService.sendPermissionRequestEmail (responseEntity.getBody ());
        }
        return responseEntity;
    }

    @PostMapping("/requestQueue")
    public ResponseEntity<Object> approveOrRejectPermissionRequest(@RequestBody PermissionApproverDetails permissionApproverDetails){
        ResponseEntity<Object> responseEntity = permissionRequestService.approveOrRejectPermissionRequest (permissionApproverDetails);
        if(responseEntity.getStatusCode() == HttpStatus.OK ) {
            ResponseEntity<Object>  permissionRequestEmail = permissionApproverDetails.getStatus ().equalsIgnoreCase (Constants.TO_BE_CANCELLED)?
                    emailService.sendPermissionRequestEmail (responseEntity.getBody ())
                    : emailService.sendPermissionRequestApprovalEmail (responseEntity.getBody ());
        }
        return responseEntity;
    }
}
