package com.histo.permissionrequest.model;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class WorkRequestEmailDetails {

    Integer workRequestId;
    Integer employeeId;
    String employeeName;
    String requestDate;
    double noOfDaysRequested;
    String comments;
    String section;
    String status;
    String reviewedOn;
    String reviewerComments;
    String requestedDate;
    String requestorName;
    String reviewerName;
    String requestAction;
    Integer locationId;
}
