package com.histo.permissionrequest.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class EmailFilterModel {

    private Integer employeeId;
    private Integer permissionId;
    private String status;
}
