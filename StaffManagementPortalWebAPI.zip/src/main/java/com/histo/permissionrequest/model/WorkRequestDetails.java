package com.histo.permissionrequest.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class WorkRequestDetails {

    private String employeeName;
    private Integer requestDetailsId;
    private Integer requestId;
    private String requestedDate;
    private String fromDate;
    private String fullOrHalfDay;
    private String approvalStatus;
    private String toDate;
}
