package com.histo.permissionrequest.model;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PermissionEmailDetails {

     Integer permissionId;
     Integer employeeId;
     String employeeName;
     String permissionDate;
     String permissionTime;
     String totalPermissionHrs;
     String comments;
     String permissionType;
     String section;
     String permissionStatus;
     String reviewedOn;
     String reviewerComments;
     String requestedDate;
     String requestorName;
     String reviewerName;
     String permissionAction;
     Integer locationId;
}
