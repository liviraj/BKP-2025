package com.histo.permissionrequest.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class WorkRequestApproveDetails {

    private List<Integer> workRequestDetailId;
    private Integer employeeId;
    private Integer requestId;
    private Integer approvedBy;
    private String approverComments;
    private String status;
    private String approvedOn;
    private Boolean isAdditionalWfh;
}
