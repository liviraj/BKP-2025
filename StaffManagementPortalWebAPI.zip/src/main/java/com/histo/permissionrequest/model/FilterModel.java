package com.histo.permissionrequest.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class FilterModel{
    private String fromTime;
    private String toTime;
    private Integer employeeId;
    private Integer locationId;
    private Integer permissionTypeId;
    private String status;
    private Integer permissionId;
    private Integer supervisorId;
}