package com.histo.permissionrequest.model;

import com.azure.core.annotation.Get;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PermisisonHistory {

    private Integer permissionID;
    private Integer employeeId;
    private String employeeName;
    private String fromTime	;
    private String toTime;
    private String noofHrs;
    private String remarks;
    private String permissionType;
    private Integer permissionTypeID;
    private String employmentStatus;
    private Integer locationid;
    private String approvalStatus;
    private String status;
    private String permissionDate;
    private String reviewedBy;
    private String reviewedOn;
    private Integer supervisorId;

}
