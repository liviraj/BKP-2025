package com.histo.permissionrequest.model;

public enum PermissionTypesEnum {
    PERSONAL(3),
    ON_DUTY(2),
    EMERGENCY(1);
    private Integer value;

    public Integer getValue() {
        return value;
    }

    PermissionTypesEnum(Integer value) {
        this.value = value;
    }

    public static PermissionTypesEnum getEnumFromString(Integer text) {
        for (PermissionTypesEnum permission : PermissionTypesEnum.values()) {
            if (permission.value.equals( text)) {
                return permission;
            }

        }
        return null;
    }
}