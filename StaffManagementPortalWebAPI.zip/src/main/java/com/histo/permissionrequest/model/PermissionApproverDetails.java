package com.histo.permissionrequest.model;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PermissionApproverDetails {

    private Integer permissionId;
    private Integer reviewedBy;
    private String reviewedOn;
    private Integer modifiedBy; // only for to be cancel request
    private String modifiedOn; //only for to be cancel request
    private String status;
    private String comments;
    private Boolean isAdditionalPermission = false;

}
