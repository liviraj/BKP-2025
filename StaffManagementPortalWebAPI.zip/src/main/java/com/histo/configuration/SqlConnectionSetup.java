package com.histo.configuration;

import com.histo.staffmanagementportal.model.ResultSetMapper;
import com.microsoft.sqlserver.jdbc.SQLServerDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;

import javax.annotation.PostConstruct;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

@Configuration
@PropertySource("classpath:application.properties")
public class SqlConnectionSetup {

    private static final Logger logger = LogManager.getLogger(SqlConnectionSetup.class);
    public String histoServerURL;
    public String histoServerUsername;
    public String histoServerPassword;

    public static String url;
    public static String Uname;
    public static String Pswd;


    @Value("${spring.datasource.jdbc-url}")
    public void setHistoServerURL(String histoServerURL) {
        SqlConnectionSetup.url = histoServerURL;
    }
    @Value("${spring.datasource.username}")
    public void setHistoServerUsername(String histoServerUsername) {
        SqlConnectionSetup.Uname = histoServerUsername;
    }
    @Value("${spring.datasource.password}")
    public void setHistoServerPassword(String histoServerPassword) {
        SqlConnectionSetup.Pswd = histoServerPassword;
    }

    private static Connection sqlcon = null;

    @PostConstruct
    private static Connection getSqlConnection() {
        try {
            DriverManager.registerDriver(new SQLServerDriver());
            sqlcon = DriverManager.getConnection(url, Uname, Pswd);
        } catch (SQLException e) {
            logger.error("SqlConnectionSetup {}",e);
        }
        return sqlcon;
    }

    public static synchronized Connection getConnection() {
        try {
            if(sqlcon == null || sqlcon.isClosed())
                getSqlConnection();
        }
        catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return sqlcon;

    }public static JdbcTemplate getJdbcConnection() {
        try {
            if(sqlcon == null || sqlcon.isClosed())
                getConnection();
        }
        catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return new JdbcTemplate(new SingleConnectionDataSource(sqlcon, true));

    }
}
