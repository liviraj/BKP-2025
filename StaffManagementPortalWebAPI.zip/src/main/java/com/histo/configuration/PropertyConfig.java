package com.histo.configuration;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:application.properties")
public class PropertyConfig {
    
    @Value("${email.approve-link}")
    private String approveLink;
    
    @Value("${pacbio.histosupport-email-link}")
    private String histosupportLink;
    
    @Value("${pacbio.histoapps-email-link}")
    private String histoAppsLink;

	@Value("${permission-request.email-link}")
	private String permissionRedirectLink;

	public String getPermissionRedirectLink() {
		return permissionRedirectLink;
	}

	public void setPermissionRedirectLink(String permissionRedirectLink) {
		this.permissionRedirectLink = permissionRedirectLink;
	}

	public String getApproveLink() {
		return approveLink;
	}

	public void setApproveLink(String approveLink) {
		this.approveLink = approveLink;
	}

	public String getHistosupportLink() {
		return histosupportLink;
	}

	public void setHistosupportLink(String histosupportLink) {
		this.histosupportLink = histosupportLink;
	}

	public String getHistoAppsLink() {
		return histoAppsLink;
	}

	public void setHistoAppsLink(String histoAppsLink) {
		this.histoAppsLink = histoAppsLink;
	}

}
