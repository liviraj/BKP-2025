package com.histo.policyagreement.controller;

import com.azure.core.annotation.QueryParam;
import com.histo.policyagreement.dto.PolicyDocumentDTO;
import com.histo.policyagreement.model.SearchFilter;
import com.histo.policyagreement.service.PolicyDocumentService;
import com.histo.staffmanagementportal.model.DeleteDetails;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/policy")
public class PolicyDocumentController {
    
    private final PolicyDocumentService documentService;

    public PolicyDocumentController(PolicyDocumentService documentService) {
        this.documentService = documentService;
    }


    @GetMapping
    ResponseEntity<Object> getPolicyDetails(@QueryParam("inputs") SearchFilter filter){
        return documentService.getPolicyDocument(filter);
    }

    @GetMapping("/type")
    ResponseEntity<Object> getPolicyDocumentType(){
        return documentService.policyDocumentType();
    }
    @GetMapping("{policyId}")
    ResponseEntity<Object> getPolicyDetailsById(@PathVariable Integer policyId){
        return documentService.getPolicyDocumentById(policyId);
    }

    @PostMapping
    ResponseEntity<Object> addPolicyAgreementDetails(@RequestBody PolicyDocumentDTO policyDocumentDTO){
        return documentService.addPolicyDocument(policyDocumentDTO);
    }

    @PutMapping("{policyId}")
    ResponseEntity<Object> updatePolicyAgreementDetails(@PathVariable Integer policyId,@RequestBody PolicyDocumentDTO policyDocumentDTO){
        return documentService.editPolicyDocument(policyId,policyDocumentDTO);
    }

    @DeleteMapping("{policyId}")
    ResponseEntity<Object> removePolicyAgreementDetails(@PathVariable Integer policyId, @RequestBody DeleteDetails deleteDetails){
        return documentService.deletePolicyDocument(policyId,deleteDetails);
    }

    @GetMapping("/preloadDetails")
    ResponseEntity<Object> getPolicyDocPreloadDetails(){
        return documentService.getPolicyDocPreloadDetails();
    }
}


