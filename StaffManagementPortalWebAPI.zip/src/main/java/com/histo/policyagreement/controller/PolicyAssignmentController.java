package com.histo.policyagreement.controller;

import com.azure.core.annotation.QueryParam;
import com.histo.policyagreement.dto.AssignedPolicyDetailsDTO;
import com.histo.policyagreement.model.AssignedPolicySearchFilter;
import com.histo.policyagreement.model.SearchFilter;
import com.histo.policyagreement.service.PolicyAssignmentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/policy/assign")
public class PolicyAssignmentController {
    
    private final PolicyAssignmentService assignmentService;

    public PolicyAssignmentController(PolicyAssignmentService assignmentService) {
        this.assignmentService = assignmentService;
    }

    @PostMapping
    ResponseEntity<Object> assignPolicyAgreementDetails(@RequestBody AssignedPolicyDetailsDTO policyDocumentDTO){
        return assignmentService.assignDocument(policyDocumentDTO);
    }

    @GetMapping("{isNotify}")
    ResponseEntity<Object> viewAssignPolicyAgreementDetails(@PathVariable String isNotify, @QueryParam( "inputs") AssignedPolicySearchFilter assignedPolicySearchFilter){
        return assignmentService.viewAssignedPolicy(isNotify,assignedPolicySearchFilter);
    }
    @GetMapping("/document-history")
    ResponseEntity<Object> getPolicyFilterList(@QueryParam( "inputs") SearchFilter filter){
        return assignmentService.getPolicyTitle(filter);
    }

    @GetMapping("/view/{assignedPolicyId}")
    ResponseEntity<Object> getPolicyFilterList(@PathVariable Integer assignedPolicyId){
        return assignmentService.getAssignedDocumentById(assignedPolicyId);
    }

    @PutMapping
    ResponseEntity<Object> editAssignedDocument(@RequestBody AssignedPolicyDetailsDTO policyDocumentDTO){
        return assignmentService.editAssignedDocument(policyDocumentDTO);
    }

    @GetMapping("/status/{policyId}")
    ResponseEntity<Object> getAssignedEmployeeDetailsForView(@PathVariable Integer policyId){
        return assignmentService.getPolicyAssignedStatusDetails(policyId);
    }
}
