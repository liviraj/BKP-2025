package com.histo.policyagreement.controller;

import com.azure.core.annotation.QueryParam;
import com.histo.policyagreement.model.AssignedPolicySearchFilter;
import com.histo.policyagreement.model.ReviewerDetails;
import com.histo.policyagreement.model.SearchFilter;
import com.histo.policyagreement.service.PolicyReviewService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/policy/review")
public class PolicyReviewController {
    
    private final PolicyReviewService reviewService;

    public PolicyReviewController(PolicyReviewService reviewService) {
        this.reviewService = reviewService;
    }

    @GetMapping("/employee-notify/{employeeId}")
    ResponseEntity<Object> getpolicyNotificationDetailById(@PathVariable Integer employeeId){
        return reviewService.getPolicyNotification(employeeId);
    }

    @PostMapping
    ResponseEntity<Object> reviewAgreedPolicy(@RequestBody ReviewerDetails assignedPolicySearchFilter){
        return reviewService.reviewPolicyDocument(assignedPolicySearchFilter);
    }

    @GetMapping
    ResponseEntity<Object> getEmployeePolicyforReviewById(@QueryParam( "inputs") AssignedPolicySearchFilter assignedPolicySearchFilter){
        return reviewService.getEmployeePolicyList(assignedPolicySearchFilter);
    }

    @GetMapping("/history")
    ResponseEntity<Object> employeePolicyHistorySearch(@QueryParam( "inputs") AssignedPolicySearchFilter assignedPolicySearchFilter){
        return reviewService.getEmployeePolicyHistory(assignedPolicySearchFilter);
    }
}
