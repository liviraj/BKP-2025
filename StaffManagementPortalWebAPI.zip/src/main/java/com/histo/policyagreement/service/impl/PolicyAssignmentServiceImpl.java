package com.histo.policyagreement.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.policyagreement.dto.AssignedPolicyDetailsDTO;
import com.histo.policyagreement.entity.AssignedPolicyDetails;
import com.histo.policyagreement.entity.DocumentStatusEnum;
import com.histo.policyagreement.entity.PolicyDocument;
import com.histo.policyagreement.entity.ReviewedPolicyDetails;
import com.histo.policyagreement.model.*;
import com.histo.policyagreement.repository.AssignedPolicyDetailsRepository;
import com.histo.policyagreement.repository.PolicyDocumentRepository;
import com.histo.policyagreement.repository.ReviewedPolicyDetailsRepository;
import com.histo.policyagreement.service.PolicyAssignmentService;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.model.Constants;
import com.histo.staffmanagementportal.model.LocationEum;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.model.ResultSetMapper;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class PolicyAssignmentServiceImpl implements PolicyAssignmentService {

    private static final Logger logger = LogManager.getLogger(PolicyAssignmentServiceImpl.class);
    private static final String STATUS = "status";
    private final ResponseModel response;
    private MappingJacksonValue mappingJacksonValue;

    private final PolicyDocumentRepository policyDocumentRepository;

    private final AssignedPolicyDetailsRepository assignedPolicyDetailsRepo;

    private  final ReviewedPolicyDetailsRepository reviewedPolicyDetailsRepo;

    public PolicyAssignmentServiceImpl(ResponseModel response, PolicyDocumentRepository policyDocumentRepository,
                                      AssignedPolicyDetailsRepository assignedPolicyDetailsRepo, ReviewedPolicyDetailsRepository reviewedPolicyDetailsRepo) {
        this.response = response;
        this.policyDocumentRepository = policyDocumentRepository;
        this.assignedPolicyDetailsRepo = assignedPolicyDetailsRepo;
        this.reviewedPolicyDetailsRepo = reviewedPolicyDetailsRepo;

    }
    @Override
    public ResponseEntity<Object> assignDocument(AssignedPolicyDetailsDTO assignedPolicyDetailsDTO) {
        try{
            PolicyDocument policyDocument = policyDocumentRepository.findById(assignedPolicyDetailsDTO.getDocumentId())
                    .orElseThrow(() -> new NullPointerException("Policy Documnent details not found"));

            List<ReviewedPolicyDetails> isAlreadyAssigned = reviewedPolicyDetailsRepo.findByDocumentId_DocumentIdAndRecordStatus(assignedPolicyDetailsDTO.getDocumentId(),
                    Constants.ACTIVE_RECORD_STATUS);

            if(!isAlreadyAssigned.isEmpty()){
                return catchException ("assignDocuments",null,"Failed","Given document has been already assigned.</br>" +
                        " Please add new employee in Edit PopUp.");
            }

            List<ReviewedPolicyDetails> reviewedPolicyDetail = new ArrayList<>();

            assignedPolicyDetailsDTO.getEmployeeId().forEach(data ->{

                ReviewedPolicyDetails reviewedPolicyDetails = new ReviewedPolicyDetails();

                reviewedPolicyDetails.setEmployeeId(data);
                reviewedPolicyDetails.setDocumentId(policyDocument);
                reviewedPolicyDetails.setIsReviewed(DocumentStatusEnum.PENDING.getValue());
                reviewedPolicyDetails.setRecordStatus(Constants.ACTIVE_RECORD_STATUS);
                reviewedPolicyDetails.setCreatedBy(assignedPolicyDetailsDTO.getAssignedBy());
                reviewedPolicyDetails.setCreatedOn(InstantFormatter.InstantFormat(assignedPolicyDetailsDTO.getAssignedDate()));

                reviewedPolicyDetail.add(reviewedPolicyDetails);
            });

            List<ReviewedPolicyDetails> reviewedPolicyDetails = reviewedPolicyDetailsRepo.saveAll(reviewedPolicyDetail);

            response.setMessage("Document assigned to selected employees.");

//            if(assignedPolicyDetailsDTO.getIsNotify().equalsIgnoreCase(Boolean.TRUE.toString())){
                String policyIds = reviewedPolicyDetails.stream()
                        .map(policy -> String.valueOf(policy.getReviewedPolicyId()))
                        .collect(Collectors.joining(","));

                SqlConnectionSetup.getJdbcConnection().query("EXEC PolicyEmailDetails ?;",new ResultSetMapper(),policyIds);
                response.setMessage("Document assigned to selected employees and email sent to assigned employees");
//            }

            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch(Exception e){
            return catchException ("assignDocuments",e,"Failed","Unable to assign document to selected employee.");
        }
    }

    @Override
    public ResponseEntity<Object> getAssignedDocumentById(Integer assignedPolicyId) {
        try {

            PolicyDocument policyDocument = policyDocumentRepository.findById(assignedPolicyId)
                    .orElseThrow(() -> new NullPointerException("Policy Documnent details not found"));

            List<ReviewedPolicyDetails> reviewedPolicyDetails = reviewedPolicyDetailsRepo
                    .findByDocumentId_DocumentIdAndRecordStatus(assignedPolicyId,Constants.ACTIVE_RECORD_STATUS);

            AssignedPolicyView assignedPolicyView = new AssignedPolicyView();

            List<Integer> pendingEmployeeId = reviewedPolicyDetails.stream()
                    .filter(data -> DocumentStatusEnum.PENDING.getValue().equalsIgnoreCase(data.getIsReviewed()))
                    .map(ReviewedPolicyDetails::getEmployeeId)
                    .toList();

            List<Integer> completedEmployeeId = reviewedPolicyDetails.stream()
                    .filter(data -> DocumentStatusEnum.COMPLETED.getValue().equalsIgnoreCase(data.getIsReviewed()))
                    .map(ReviewedPolicyDetails::getEmployeeId)
                    .toList();

            assignedPolicyView.setPendingEmployeeId(pendingEmployeeId);
            assignedPolicyView.setCompletedEmployeeId(completedEmployeeId);
            assignedPolicyView.setLocationId(policyDocument.getLocationId());
            assignedPolicyView.setDocumentId(assignedPolicyId);
            assignedPolicyView.setLocationName(LocationEum.getEnumFromString(String.valueOf(policyDocument.getLocationId())).toString());

            response.setData(assignedPolicyView);
            response.setStatus(true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException("getAssignedDocumentById", e, "Failed", "Unable to assign document details for given filter value.");
        }
    }

    @Override
    public ResponseEntity<Object> getPolicyTitle(SearchFilter filter) {
        try{

            List<DocumentFilterView> assignedPolicyDetailsList = SqlConnectionSetup.getJdbcConnection().query("exec PolicyTitleByFilter ?,?,?;"
                    , BeanPropertyRowMapper.newInstance(DocumentFilterView.class),filter.getLocationId(), filter.getDocumentType(), filter.getYear());

            response.setStatus (true);
            response.setData (assignedPolicyDetailsList);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);

        }
        catch(Exception e){
            return catchException ("getPolicyTitle()", e, "Failed", "Unable to get document title details.");
        }
    }

    @Override
    public ResponseEntity<Object> editAssignedDocument(AssignedPolicyDetailsDTO assignedPolicyDetailsDTO) {
        try{
            PolicyDocument policyDocument = policyDocumentRepository.findById(assignedPolicyDetailsDTO.getDocumentId())
                    .orElseThrow(() -> new NullPointerException("Policy Documnent details not found"));

            List<ReviewedPolicyDetails> reviewedPolicyDetailsList = reviewedPolicyDetailsRepo.findByDocumentId_DocumentIdAndRecordStatus(assignedPolicyDetailsDTO.getDocumentId(),
                    Constants.ACTIVE_RECORD_STATUS);

            List<Integer> existingEmpId = reviewedPolicyDetailsList.stream()
                    .map(ReviewedPolicyDetails::getEmployeeId)
                    .toList();

            // Find new employee IDs (in updatedEmpId but not in existingEmpId)
            List<Integer> newEmpId = assignedPolicyDetailsDTO.getEmployeeId().stream()
                    .filter(id -> !existingEmpId.contains(id))
                    .toList();

            // Find removed employee IDs (in existingEmpId but not in updatedEmpId)
            List<Integer> removedEmpId = existingEmpId.stream()
                    .filter(id -> !assignedPolicyDetailsDTO.getEmployeeId().contains(id))
                    .toList();

            List<ReviewedPolicyDetails> removedPolicies = reviewedPolicyDetailsList.stream()
                    .filter(data -> removedEmpId.contains(data.getEmployeeId()) &&
                            DocumentStatusEnum.PENDING.getValue().equalsIgnoreCase(data.getIsReviewed()))
                    .toList();

            if(!removedPolicies.isEmpty()){

                removedPolicies.forEach(data -> {
                    data.setRecordStatus(String.valueOf(Constants.DELETED_RECORD_STATUS));
                    data.setModifiedBy(assignedPolicyDetailsDTO.getModifiedBy());
                    data.setModifiedDate(InstantFormatter.InstantFormat(assignedPolicyDetailsDTO.getModifiedDate()));
                });

                reviewedPolicyDetailsRepo.saveAll(removedPolicies);
            }

            List<ReviewedPolicyDetails> reviewedPolicyDetail = new ArrayList<>();

            newEmpId.stream().forEach(data ->{

                ReviewedPolicyDetails reviewedPolicyDetails = new ReviewedPolicyDetails();

                reviewedPolicyDetails.setEmployeeId(data);
                reviewedPolicyDetails.setDocumentId(policyDocument);
                reviewedPolicyDetails.setIsReviewed(DocumentStatusEnum.PENDING.getValue());
                reviewedPolicyDetails.setRecordStatus(Constants.ACTIVE_RECORD_STATUS);
                reviewedPolicyDetails.setCreatedBy(assignedPolicyDetailsDTO.getAssignedBy());
                reviewedPolicyDetails.setCreatedOn(InstantFormatter.InstantFormat(assignedPolicyDetailsDTO.getAssignedDate()));

                reviewedPolicyDetail.add(reviewedPolicyDetails);
            });

            List<ReviewedPolicyDetails> reviewedPolicyDetails = reviewedPolicyDetailsRepo.saveAll(reviewedPolicyDetail);

            response.setMessage("Assigned Document details updated successfully.");

            if( !removedPolicies.isEmpty()){
                String policyIds = newEmpId.stream().map(String::valueOf)
                        .collect(Collectors.joining(","));

                SqlConnectionSetup.getJdbcConnection().query("EXEC PolicyEmailDetails ?;",new ResultSetMapper(),policyIds);
                response.setMessage("Document details updated and email sent to newly assigned employees");
            }

            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch(Exception e){
            return catchException ("editAssignDocuments",e,"Failed","Unable to edit assigned document to selected employee.");
        }
    }

    @Override
    public ResponseEntity<Object> viewAssignedPolicy(String isNotify, AssignedPolicySearchFilter assignedPolicySearchFilter) {
        try {

            Optional<PolicyDocument> assignedPolicyDetails = policyDocumentRepository.findByDocumentIdAndRecordStatus(assignedPolicySearchFilter.getDocumentId(),Constants.ACTIVE_RECORD_STATUS);

            if(assignedPolicyDetails.isEmpty()){
                return catchException("viewAssignedPolicy", null, "Failed", "No records found for given Id");
            }

            List<ReviewedPolicyDetails> reviewedPolicyDetails = reviewedPolicyDetailsRepo
                    .findByDocumentId_DocumentIdAndRecordStatus(assignedPolicySearchFilter.getDocumentId(),Constants.ACTIVE_RECORD_STATUS);

            if(isNotify.equalsIgnoreCase(Boolean.TRUE.toString())){

                boolean anyMatch = reviewedPolicyDetails.stream().anyMatch(data -> data.getIsReviewed().equalsIgnoreCase(DocumentStatusEnum.PENDING.getValue()));

                if(!anyMatch){
                    return catchException("viewAssignedPolicy", null, "Failed", "No pending documents by employee.");
                }
                String policyIds = reviewedPolicyDetails.stream()
                        .map(policy -> String.valueOf(policy.getReviewedPolicyId()))
                        .collect(Collectors.joining(","));

                SqlConnectionSetup.getJdbcConnection().query("EXEC PolicyEmailDetails ?;",new ResultSetMapper(),policyIds);
                response.setMessage("Notification email sent to pending employees");
                response.setStatus(true);
                mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
            }

            AssignedPolicyView assignedPolicyView = new AssignedPolicyView();

            List<Integer> pendingEmployeeId = reviewedPolicyDetails.stream()
                    .filter(data -> DocumentStatusEnum.PENDING.getValue().equalsIgnoreCase(data.getIsReviewed()))
                    .map(ReviewedPolicyDetails::getEmployeeId)
                    .toList();

            List<Integer> completedEmployeeId = reviewedPolicyDetails.stream()
                    .filter(data -> DocumentStatusEnum.COMPLETED.getValue().equalsIgnoreCase(data.getIsReviewed()))
                    .map(ReviewedPolicyDetails::getEmployeeId)
                    .toList();

            assignedPolicyView.setPendingEmployeeId(pendingEmployeeId);
            assignedPolicyView.setCompletedEmployeeId(completedEmployeeId);

            assignedPolicyView.setDocumentId(assignedPolicySearchFilter.getDocumentId());
            assignedPolicyView.setLocationId(assignedPolicyDetails.get().getLocationId());

            response.setData(assignedPolicyView);
            response.setStatus(true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException("viewAssignedPolicy", e, "Failed", "Unable to assign document details for given filter value.");
        }
    }

    @Override
    public ResponseEntity<Object> getPolicyAssignedStatusDetails(Integer policyId) {
        try{
            Optional<PolicyDocument> assignedPolicyDetails = policyDocumentRepository.findByDocumentIdAndRecordStatus(policyId,Constants.ACTIVE_RECORD_STATUS);

            if(assignedPolicyDetails.isEmpty()){
                return catchException("getPolicyAssignedStatusDetails", null, "Failed", "No records found for given Id");
            }

            long pendingEmpCount = reviewedPolicyDetailsRepo
                    .getCountByIdAndStatus(policyId, DocumentStatusEnum.PENDING.getValue());

            long completedEmpCount = reviewedPolicyDetailsRepo
                    .getCountByIdAndStatus(policyId, DocumentStatusEnum.COMPLETED.getValue());

            long allEmpCount = reviewedPolicyDetailsRepo.getCountByIdAndStatus(policyId, "All");

            Map<String, Long> empCount = new HashMap<>();

            empCount.putIfAbsent("pendingEmpCount",pendingEmpCount);
            empCount.putIfAbsent("completedEmpCount",completedEmpCount);
            empCount.putIfAbsent("allEmpCount", allEmpCount);

            List<Object> employeeDetails = SqlConnectionSetup.getJdbcConnection().query("EXEC spGetAssignedEmployeeById ?;", new ResultSetMapper(), policyId);

            Map<String,Object> data = new HashMap<>();

            data.putIfAbsent("empCount",empCount);
            data.putIfAbsent("employeeDetails",employeeDetails);

            response.setData(data);
            response.setStatus(true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

        }
        catch (Exception e) {
            return catchException("getPolicyAssignedStatusDetails", e, "Failed", "Unable to get policy assigned status details for employees.");
        }
    }

    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
        logger.error("{} Error : {}" , methodName, e);
        response.setStatus(false);
        response.setInformation(new ExceptionBean(Instant.now(), message, description));
        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }
}
