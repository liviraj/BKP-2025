package com.histo.policyagreement.service;

import com.histo.policyagreement.dto.AssignedPolicyDetailsDTO;
import com.histo.policyagreement.model.AssignedPolicySearchFilter;
import com.histo.policyagreement.model.SearchFilter;
import org.springframework.http.ResponseEntity;

public interface PolicyAssignmentService {

    ResponseEntity<Object> assignDocument(AssignedPolicyDetailsDTO assignedPolicyDetailsDTO);
    ResponseEntity<Object> getAssignedDocumentById(Integer assignedPolicyId);
    ResponseEntity<Object> getPolicyTitle(SearchFilter filter);
    ResponseEntity<Object> editAssignedDocument(AssignedPolicyDetailsDTO assignedPolicyDetailsDTO);
    ResponseEntity<Object> viewAssignedPolicy(String isNotify, AssignedPolicySearchFilter assignedPolicySearchFilter);

    ResponseEntity<Object> getPolicyAssignedStatusDetails(Integer policyId);
}
