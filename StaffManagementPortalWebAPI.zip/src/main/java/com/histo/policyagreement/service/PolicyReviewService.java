package com.histo.policyagreement.service;

import com.histo.policyagreement.model.AssignedPolicySearchFilter;
import com.histo.policyagreement.model.ReviewerDetails;
import org.springframework.http.ResponseEntity;

public interface PolicyReviewService {

    ResponseEntity<Object> getPolicyNotification(Integer employeeId);
    ResponseEntity<Object> reviewPolicyDocument(ReviewerDetails reviewerDetails);
    ResponseEntity<Object> getEmployeePolicyList(AssignedPolicySearchFilter assignedPolicySearchFilter);
    ResponseEntity<Object> getEmployeePolicyHistory(AssignedPolicySearchFilter assignedPolicySearchFilter);
}
