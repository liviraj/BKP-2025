package com.histo.policyagreement.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.policyagreement.dto.PolicyDocumentDTO;
import com.histo.policyagreement.entity.PolicyDocument;
import com.histo.policyagreement.entity.PolicyDocumentTypeEnun;
import com.histo.policyagreement.model.*;
import com.histo.policyagreement.repository.DocumentVersionProjection;
import com.histo.policyagreement.repository.PolicyDocumentRepository;
import com.histo.policyagreement.service.PolicyAssignmentService;
import com.histo.policyagreement.service.PolicyDocumentService;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.model.Constants;
import com.histo.staffmanagementportal.model.DeleteDetails;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;

@Service
public class PolicyDocumentServiceImpl implements PolicyDocumentService {

    private static final Logger logger = LogManager.getLogger(PolicyDocumentServiceImpl.class);
    private static final String STATUS = "status";
    private final ResponseModel response;
    private MappingJacksonValue mappingJacksonValue;

    private final PolicyDocumentRepository policyDocumentRepository;

    private final PolicyAssignmentService assignmentService;


    public PolicyDocumentServiceImpl(ResponseModel response, PolicyDocumentRepository policyDocumentRepository,
                                      PolicyAssignmentService assignmentService) {
        this.response = response;
        this.policyDocumentRepository = policyDocumentRepository;
        this.assignmentService = assignmentService;
    }

    @Override
    public ResponseEntity<Object> getPolicyDocument(SearchFilter filter) {
        try {
            List<DocumentView> documentDetails = SqlConnectionSetup.getJdbcConnection()
                    .query("exec spGetPolicyDocumentDetails ?,?;", BeanPropertyRowMapper.newInstance(DocumentView.class),
                            filter.getLocationId(),
                            filter.getStatus()
                    );

            response.setStatus(true);
            response.setData(documentDetails);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException("getPolicyDocument()", e, "Failed", "Unable to get document master details.");
        }
    }

    @Override
    public ResponseEntity<Object> getPolicyDocumentById(Integer policyId) {
        try {

            PolicyDocument policyDocument = policyDocumentRepository.findById(policyId).orElseThrow(() -> new NullPointerException("Document details not exist for given id."));

            response.setStatus(true);
            response.setData(policyDocument);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException("getPolicyDocumentById()", e, "Failed", "Unable to get document details.");
        }
    }

    @Override
    public ResponseEntity<Object> addPolicyDocument(PolicyDocumentDTO policyDocumentDTO) {
        try {
            List<PolicyDocument> policyDoc = policyDocumentRepository.findByDocumentTypeAndDocumentTypeIdAndDocumentCategoryNameAndRecordStatusAndLocationId(policyDocumentDTO.getDocumentType(),
                    policyDocumentDTO.getDocumentTypeId(),
                    policyDocumentDTO.getDocumentCategoryName(),
                    Constants.ACTIVE_RECORD_STATUS,
                    policyDocumentDTO.getLocationId());

            Optional<PolicyDocument> isAlreadyExists = policyDoc.stream()
                    .sorted(Comparator.comparing(PolicyDocument::getValidityDate).reversed())
                    .findFirst();

            if (!isAlreadyExists.isEmpty()) {
                if(isAlreadyExists.get().getValidityDate().isAfter(new Date().toInstant())){
                    return catchException("addPolicyDocument", null, "Failed", "Given document details already exists. Please update existing record.");
                }

            }

            if(InstantFormatter.InstantFormat(policyDocumentDTO.getValidFromDate())
                    .isAfter(InstantFormatter.InstantFormat(policyDocumentDTO.getValidityDate()))){
                return catchException("addPolicyDocument", null, "Failed", "Given document valid from date should be after document valid to date.");
            }

            PolicyDocument policyDocument = new PolicyDocument();

            policyDocument.setDocumentName(policyDocumentDTO.getDocumentName());
            policyDocument.setDocumentTitle(policyDocumentDTO.getDocumentTitle());
            policyDocument.setDocumentType(policyDocumentDTO.getDocumentType());
            policyDocument.setDocumentCategoryName(policyDocumentDTO.getDocumentCategoryName());
            policyDocument.setDocumentTypeId(policyDocumentDTO.getDocumentTypeId());
            policyDocument.setDocumentImage(policyDocumentDTO.getDocumentImage());
            policyDocument.setCreatedBy(policyDocumentDTO.getCreatedBy());
            policyDocument.setCreatedOn(InstantFormatter.InstantFormat(policyDocumentDTO.getCreatedOn()));
            policyDocument.setLocationId(policyDocumentDTO.getLocationId());
            policyDocument.setRecordStatus(Constants.ACTIVE_RECORD_STATUS);

            policyDocument.setRevisionFrequency(policyDocumentDTO.getRevisionFrequency());
            policyDocument.setAuthor(policyDocumentDTO.getAuthorId());
            policyDocument.setVersion(policyDocumentDTO.getVersion());
            policyDocument.setDocumentNumber(policyDocumentDTO.getDocumentNumber());
            policyDocument.setValidityDate(InstantFormatter.InstantFormat(policyDocumentDTO.getValidityDate()));
            policyDocument.setValidFromDate(InstantFormatter.InstantFormat(policyDocumentDTO.getValidFromDate()));

            PolicyDocument savedDetails = policyDocumentRepository.save(policyDocument);

            response.setData (savedDetails);
            response.setMessage("Document added successfully.");
            response.setStatus(true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException("addPolicyDocument", e, "Failed", "Unable to add document details.");
        }
    }

    @Override
    public ResponseEntity<Object> editPolicyDocument(Integer policyId, PolicyDocumentDTO policyDocumentDTO) {
        try {
            PolicyDocument policyDocument = policyDocumentRepository.findById(policyId).orElseThrow(() -> new NullPointerException("Policy details not found for given id."));

            List<PolicyDocument> policyDoc = policyDocumentRepository.findByDocumentTypeAndDocumentTypeIdAndDocumentCategoryNameAndRecordStatusAndLocationId(policyDocumentDTO.getDocumentType(),
                    policyDocumentDTO.getDocumentTypeId(),
                    policyDocumentDTO.getDocumentCategoryName(),
                    Constants.ACTIVE_RECORD_STATUS,
                    policyDocumentDTO.getLocationId());

            Optional<PolicyDocument> isAlreadyExists = policyDoc.stream()
                    .sorted(Comparator.comparing(PolicyDocument::getValidityDate).reversed())
                    .findFirst();

            if (!isAlreadyExists.isEmpty()) {
                boolean exists = isAlreadyExists.stream()
                        .anyMatch(doc -> !doc.getDocumentId().equals(policyId));

                if(exists && isAlreadyExists.get().getValidityDate().isAfter(new Date().toInstant())){
                    return catchException("editPolicyDocument", null, "Failed", "Given document details already exists. Please update existing record.");
                }
            }

            if(InstantFormatter.InstantFormat(policyDocumentDTO.getValidFromDate())
                    .isAfter(InstantFormatter.InstantFormat(policyDocumentDTO.getValidityDate()))){
                return catchException("editPolicyDocument", null, "Failed", "Given document valid from date should be after document valid to date.");
            }

            policyDocument.setDocumentName(policyDocumentDTO.getDocumentName());
            policyDocument.setDocumentTitle(policyDocumentDTO.getDocumentTitle());
            policyDocument.setDocumentType(policyDocumentDTO.getDocumentType());
            policyDocument.setDocumentCategoryName(policyDocumentDTO.getDocumentCategoryName());
            policyDocument.setDocumentTypeId(policyDocumentDTO.getDocumentTypeId());
            policyDocument.setDocumentImage(policyDocumentDTO.getDocumentImage());
            policyDocument.setModifiedBy(policyDocumentDTO.getModifiedBy());
            policyDocument.setModifiedDate(InstantFormatter.InstantFormat(policyDocumentDTO.getModifiedDate()));
            policyDocument.setRevisionFrequency(policyDocumentDTO.getRevisionFrequency());
            policyDocument.setAuthor(policyDocumentDTO.getAuthorId());
            policyDocument.setVersion(policyDocumentDTO.getVersion());
            policyDocument.setDocumentNumber(policyDocumentDTO.getDocumentNumber());
            policyDocument.setValidityDate(InstantFormatter.InstantFormat(policyDocumentDTO.getValidityDate()));
            policyDocument.setValidFromDate(InstantFormatter.InstantFormat(policyDocumentDTO.getValidFromDate()));

            PolicyDocument savedDetails = policyDocumentRepository.save(policyDocument);

            response.setData(savedDetails);
            response.setMessage("Document details updated successfully.");
            response.setStatus(true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException("editPolicyDocument", e, "Failed", "Unable to edit document details.");
        }
    }

    @Override
    public ResponseEntity<Object> deletePolicyDocument(Integer policyId, DeleteDetails deleteDetails) {
        try {
            PolicyDocument policyDocument = policyDocumentRepository.findById(policyId).orElseThrow(() -> new NullPointerException("Policy details not found for given id."));

            int updateRecordStatusById = policyDocumentRepository.updateModifiedByById(deleteDetails.id(), deleteDetails.modifiedBy(), InstantFormatter.InstantFormat(deleteDetails.modifiedDate()));

            if (updateRecordStatusById <= 0) {
                return catchException("deletePolicyDocument()", null, "Error", "Document details not deleted");

            }

            response.setMessage("Document details deleted successfully.");
            response.setStatus(true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException("deletePolicyDocument", e, "Failed", "Unable to edit document details.");
        }
    }

    @Override
    public ResponseEntity<Object> policyDocumentType() {
        try {
            List<String> documentType = Arrays.asList(PolicyDocumentTypeEnun.COMPLIANCE.getValue());
            response.setStatus(true);
            response.setData(documentType);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException("policyDocumentType()", e, "Failed", "Unable to get policy document type.");
        }
    }

    @Override
    public ResponseEntity<Object> getPolicyDocPreloadDetails() {
        try {
            PolicyDocPreloadDetails policyDocPreloadDetails = new PolicyDocPreloadDetails();
            DocumentVersionProjection laterDocInfo = getLaterDocInfo();

            String curretVersion = doVersionincrement(laterDocInfo.getVersion());
            String currentDocNumber = incrementDocNumber(laterDocInfo.getDocumentNumber(), DocTypeEnum.HIPPA);

            List<DocAuthorDetails> authors = SqlConnectionSetup.getJdbcConnection()
                    .query("EXEC GetPolicyDocAuthors;", (rs, rowNum) -> {
                        DocAuthorDetails author = new DocAuthorDetails();
                        author.setAuthorName(rs.getString("authorName"));
                        author.setEmployeeId(rs.getInt("EmployeeID"));
                        return author;
                    });

            List<String> revisionFrequencies = getRevisionFrequencies();

            policyDocPreloadDetails.setCurrentVersion(curretVersion);
            policyDocPreloadDetails.setDocumentNumber(currentDocNumber);
            policyDocPreloadDetails.setPolicyDocAuthors(authors);
            policyDocPreloadDetails.setRevisionFrequencyList(revisionFrequencies);


            response.setStatus(true);
            response.setData(policyDocPreloadDetails);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException("getPolicyDocPreloadDetails()", e, "Failed", "Unable to get policy document preload details.");
        }
    }

    public List<String> getRevisionFrequencies() {
        return Arrays.stream(RevisionFrequencyEnum.values())
                .map(RevisionFrequencyEnum::getValue)
                .toList();
    }

    public DocumentVersionProjection getLaterDocInfo() {
        DocumentVersionProjection latestDocInfo = policyDocumentRepository.findLatestDocumentVersion();
        return latestDocInfo;
    }

    public static String incrementDocNumber(String currentNumber, DocTypeEnum docTypeEnum) {
        if (StringUtils.isBlank(currentNumber)) {
            return "HIS-EMP-" + docTypeEnum + "AGM-001";
        }
        int lastDashIndex = currentNumber.lastIndexOf("-");
        if (lastDashIndex == -1) {
            throw new IllegalArgumentException("Invalid format: No dash found");
        }

        String numberPart = currentNumber.substring(lastDashIndex + 1);

        int number = Integer.parseInt(numberPart);
        number++; // increment

        // Format to 3 digits with leading zeros
        String newNumberPart = String.format("%03d", number);

        return "HIS-EMP-" + docTypeEnum + "AGM-" + newNumberPart;
    }

    public String doVersionincrement(String version) {
        if (StringUtils.isBlank(version)) {
            return "v0.0.0.1";
        }
        version = version.startsWith("v") ? version.substring(1) : version;
        String[] parts = version.split("\\.");

        if (parts.length != 4) {
            throw new IllegalArgumentException("Version must have 4 parts, e.g. v0.0.0.1");
        }

        int[] nums = new int[4];
        for (int i = 0; i < 4; i++) {
            nums[i] = Integer.parseInt(parts[i]);
        }

        // Start incrementing from last part
        for (int i = 3; i >= 0; i--) {
            nums[i]++;
            if (nums[i] <= 9) {
                break;
            } else {
                nums[i] = 0; // rollover and carry to next
            }
        }

        return "v" + nums[0] + "." + nums[1] + "." + nums[2] + "." + nums[3];
    }

    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
        logger.error("{} Error : {}", methodName, e);
        response.setStatus(false);
        response.setInformation(new ExceptionBean(Instant.now(), message, description));
        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }
}
