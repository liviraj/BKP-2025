package com.histo.policyagreement.service;

import com.histo.policyagreement.dto.PolicyDocumentDTO;
import com.histo.policyagreement.model.SearchFilter;
import com.histo.staffmanagementportal.model.DeleteDetails;
import org.springframework.http.ResponseEntity;

public interface PolicyDocumentService {

    ResponseEntity<Object> getPolicyDocument(SearchFilter filter);
    ResponseEntity<Object> getPolicyDocumentById(Integer policyId);
    ResponseEntity<Object> addPolicyDocument(PolicyDocumentDTO policyDocumentDTO);
    ResponseEntity<Object> editPolicyDocument(Integer policyId,PolicyDocumentDTO policyDocumentDTO);
    ResponseEntity<Object> deletePolicyDocument(Integer policyId, DeleteDetails deleteDetails);
    ResponseEntity<Object> policyDocumentType();
    ResponseEntity<Object> getPolicyDocPreloadDetails();
}
