package com.histo.policyagreement.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.policyagreement.entity.DocumentStatusEnum;
import com.histo.policyagreement.entity.PolicyDocumentTypeEnun;
import com.histo.policyagreement.entity.ReviewedPolicyDetails;
import com.histo.policyagreement.model.AssignedPolicySearchFilter;
import com.histo.policyagreement.model.NotificationPolicyView;
import com.histo.policyagreement.model.ReviewedDocumentDetails;
import com.histo.policyagreement.model.ReviewerDetails;
import com.histo.policyagreement.repository.ReviewedPolicyDetailsRepository;
import com.histo.policyagreement.service.PolicyReviewService;
import com.histo.staffmanagementportal.dto.EmployeeComplianceDTO;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.intranet.entity.Document;
import com.histo.staffmanagementportal.model.Constants;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.model.ResultSetMapper;
import com.histo.staffmanagementportal.model.RoleEnum;
import com.histo.staffmanagementportal.service.EmployeeComplianceService;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class PolicyReviewServiceImpl implements PolicyReviewService {

    private static final Logger logger = LogManager.getLogger(PolicyReviewServiceImpl.class);
    private static final String STATUS = "status";
    private final ResponseModel response;
    private MappingJacksonValue mappingJacksonValue;

    private  final ReviewedPolicyDetailsRepository reviewedPolicyDetailsRepo;

    private final PdfConversionService docConversion;

    private final EmployeeComplianceService employeeComplianceService;

    public PolicyReviewServiceImpl(ResponseModel response, ReviewedPolicyDetailsRepository reviewedPolicyDetailsRepo,
                                   PdfConversionService docConversion, EmployeeComplianceService employeeComplianceService) {
        this.response = response;
        this.reviewedPolicyDetailsRepo = reviewedPolicyDetailsRepo;
        this.docConversion = docConversion;
        this.employeeComplianceService = employeeComplianceService;
    }
    @Override
    public ResponseEntity<Object> getPolicyNotification(Integer employeeId) {
        try{

            List<ReviewedPolicyDetails> assignedPolicyDetailsList = reviewedPolicyDetailsRepo
                    .findByEmployeeIdAndRecordStatusAndIsReviewed(employeeId, Constants.ACTIVE_RECORD_STATUS, DocumentStatusEnum.PENDING.getValue());

            List<ReviewedPolicyDetails> reviewedPolicyDetails = assignedPolicyDetailsList.stream()
                    .filter(data -> data.getDocumentId().getRecordStatus().equalsIgnoreCase(Constants.ACTIVE_RECORD_STATUS))
                    .toList();

            List<NotificationPolicyView> notificationPolicyViews = new ArrayList<>();

            if (!reviewedPolicyDetails.isEmpty()) {
                notificationPolicyViews = reviewedPolicyDetails.stream()
                        .map(data -> {
                            NotificationPolicyView value = new NotificationPolicyView();
                            value.setDocumentId(data.getDocumentId().getDocumentId());
                            value.setDocumentTitle(data.getDocumentId().getDocumentTitle());
                            value.setStatus(data.getIsReviewed());
                            value.setPolicyDetailId(data.getReviewedPolicyId());
                            value.setAssignedDate(InstantFormatter.InstantFormat(data.getCreatedOn()));
                            return value;
                        })
                        .toList();
            }

            response.setData(notificationPolicyViews);
            response.setStatus(true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

        }catch (Exception e) {
            return catchException("getPolicyNotification", e, "Failed", "Policy document details not found.");
        }
    }

    @Override
    public ResponseEntity<Object> reviewPolicyDocument(ReviewerDetails reviewerDetails) {
        try{

            ReviewedPolicyDetails reviewedPolicyDetails = reviewedPolicyDetailsRepo.findById(reviewerDetails.getDocumentId())
                    .orElseThrow(() -> new NullPointerException("Assigned document details not found."));

            List<ReviewedDocumentDetails> reviewedDocumentDetails = SqlConnectionSetup.getJdbcConnection()
                    .query("EXEC getDocumentForReview ?,?",
                            BeanPropertyRowMapper.newInstance(ReviewedDocumentDetails.class)
                            , reviewerDetails.getDocumentId()
                            ,reviewerDetails.getReviewedEmpId());

            reviewedDocumentDetails.get(0).setEmployeeSignature(reviewerDetails.getEmployeeSignature());

            ReviewedDocumentDetails documentDetails = docConversion.appendSignatureTableAndSave(reviewedDocumentDetails.get(0));

            if(documentDetails == null){
                return catchException("reviewPolicyDocument", null, "Failed", "Unable to process reviewed document.");
            }

            reviewedPolicyDetails.setIsReviewed(DocumentStatusEnum.COMPLETED.getValue());
            reviewedPolicyDetails.setModifiedBy(reviewerDetails.getReviewedEmpId());
            reviewedPolicyDetails.setModifiedDate(InstantFormatter.InstantFormat(reviewerDetails.getDate()));
            reviewedPolicyDetails.setDocumentName(String.format("%s_%s.pdf",reviewedDocumentDetails.get(0).getEmployeeName(),reviewedDocumentDetails.get(0).getCurrentDate()));
            reviewedPolicyDetails.setDocumentImage(documentDetails.getDocumentImage());
            reviewedPolicyDetails.setReviewedDate(InstantFormatter.InstantFormat(reviewerDetails.getDate()));
            reviewedPolicyDetails.setDocumentExpiryDate(InstantFormatter.InstantFormat(reviewedDocumentDetails.get(0).getDocumentExpiryDate()));

            ReviewedPolicyDetails policyDetails = reviewedPolicyDetailsRepo.save(reviewedPolicyDetails);

            return addEmployeeComplainceOrHrDocument(policyDetails);

        }catch (Exception e) {
            return catchException("reviewPolicyDocument", e, "Failed", "Unable to review policy.");
        }
    }

    public ResponseEntity<Object> addEmployeeComplainceOrHrDocument(ReviewedPolicyDetails policyDetails){

        try{

            ReviewedPolicyDetails reviewedPolicyDetails = reviewedPolicyDetailsRepo.findById(policyDetails.getReviewedPolicyId())
                    .orElseThrow(() -> new NullPointerException("Assigned document details not found."));

            if(reviewedPolicyDetails.getDocumentId().getDocumentType().equalsIgnoreCase(PolicyDocumentTypeEnun.COMPLIANCE.getValue())){

                EmployeeComplianceDTO employeeComplianceDTO = new EmployeeComplianceDTO();

                Document document = new Document();

                document.setDocumentName(policyDetails.getDocumentName());
                document.setDocumentBinary(policyDetails.getDocumentImage());
                document.setRecordStatus(Constants.ACTIVE_RECORD_STATUS);

                employeeComplianceDTO.setEmployeeID(reviewedPolicyDetails.getEmployeeId());
                employeeComplianceDTO.setComplianceDate(InstantFormatter.InstantFormat(reviewedPolicyDetails.getReviewedDate()));
                employeeComplianceDTO.setExpiryDate(InstantFormatter.InstantFormat(reviewedPolicyDetails.getDocumentExpiryDate()));
                employeeComplianceDTO.setCompliancePeriod(reviewedPolicyDetails.getDocumentId().getDocumentCategoryName());
                employeeComplianceDTO.setComplianceCategoryID(reviewedPolicyDetails.getDocumentId().getDocumentTypeId());
                employeeComplianceDTO.setCreatedBy(reviewedPolicyDetails.getEmployeeId());
                employeeComplianceDTO.setDescription(reviewedPolicyDetails.getDocumentId().getDocumentTitle());
                employeeComplianceDTO.setDocumentDetails(Arrays.asList(document));
                employeeComplianceDTO.setAuthenticateUserRole(RoleEnum.ADMINISTRATOR.getValue());

                employeeComplianceService.addEmployeeCompliance(employeeComplianceDTO);

                response.setMessage("Document reviewed successfully and uploaded in NYS compliance.");
            }

//            if(reviewedPolicyDetails.getAssignedPolicyDetails().getPolicyDocument().getDocumentType().equalsIgnoreCase(PolicyDocumentTypeEnun.HR_DOCUMENT.getValue())){
//
//                EmployeeDocumentDTO employeeDocument = new EmployeeDocumentDTO();
//
//                Document document = new Document();
//
//                document.setDocumentName(policyDetails.getDocumentName());
//                document.setDocumentBinary(policyDetails.getDocumentImage());
//
//                employeeDocument.setEmployeeId(reviewedPolicyDetails.getEmployeeId());
//                employeeDocument.setDocumentDate(InstantFormatter.InstantFormat(reviewedPolicyDetails.getAssignedPolicyDetails().getDocumentValidFromDate()));
//                employeeDocument.setExpiryDate(InstantFormatter.InstantFormat(reviewedPolicyDetails.getAssignedPolicyDetails().getDocumentValidToDate()));
//                employeeDocument.setDocumentName(reviewedPolicyDetails.getAssignedPolicyDetails().getPolicyDocument().getDocumentCategoryName());
//                employeeDocument.setDocumentTypeId(reviewedPolicyDetails.getAssignedPolicyDetails().getPolicyDocument().getDocumentTypeId());
//                employeeDocument.setDescription(reviewedPolicyDetails.getAssignedPolicyDetails().getPolicyDocument().getDocumentTitle());
//                employeeDocument.setDocumentList(Arrays.asList(document));
//                employeeDocument.setModifiedBy(reviewedPolicyDetails.getEmployeeId());
//
//                documentService.addEmployeeHrDocument(employeeDocument);
//
//                response.setMessage("Document reviewed successfully and uploaded in Documents");
//            }

            response.setStatus(true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
        catch (Exception e) {
            return catchException("reviewPolicyDocument", e, "Failed", "Unable to review policy.");
        }


    }

    @Override
    public ResponseEntity<Object> getEmployeePolicyList(AssignedPolicySearchFilter assignedPolicySearchFilter) {
        try{

            List<ReviewedDocumentDetails> reviewedDocumentDetails = SqlConnectionSetup.getJdbcConnection()
                    .query("EXEC getDocumentForReview ?,?", BeanPropertyRowMapper.newInstance(ReviewedDocumentDetails.class), assignedPolicySearchFilter.getDocumentId()
                            ,assignedPolicySearchFilter.getEmployeeId());

            response.setData(reviewedDocumentDetails);
            response.setStatus(true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

        }catch (Exception e) {
            return catchException("getEmployeePolicyList", e, "Failed", "Unable to get employee review policy.");
        }
    }

    @Override
    public ResponseEntity<Object> getEmployeePolicyHistory(AssignedPolicySearchFilter assignedPolicySearchFilter) {
        try{

            List<Object> reviewedDocumentDetails = SqlConnectionSetup.getJdbcConnection()
                    .query("EXEC EmployeePolicyDocumentHistory ?", new ResultSetMapper()
                            ,assignedPolicySearchFilter.getEmployeeId());

            response.setData(reviewedDocumentDetails);
            response.setStatus(true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

        }catch (Exception e) {
            return catchException("getEmployeePolicyHistory", e, "Failed", "Unable to get employee policy history.");
        }
    }

    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
        logger.error("{} Error : {}" , methodName, e);
        response.setStatus(false);
        response.setInformation(new ExceptionBean(Instant.now(), message, description));
        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }
}
