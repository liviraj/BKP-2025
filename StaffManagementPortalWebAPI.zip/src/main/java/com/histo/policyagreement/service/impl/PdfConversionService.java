package com.histo.policyagreement.service.impl;

import com.histo.policyagreement.model.ReviewedDocumentDetails;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.springframework.stereotype.Service;

import java.io.*;

@Service
public class PdfConversionService {

    public ReviewedDocumentDetails appendSignatureTableAndSave(ReviewedDocumentDetails file) throws IOException {
        byte[] pdfBytes = file.getDocumentImage();
        try (PDDocument document = PDDocument.load(new ByteArrayInputStream(pdfBytes))) {
            // Create a new page and add it to the document
            PDPage newPage = new PDPage();
            document.addPage(newPage);

            try (PDPageContentStream contentStream = new PDPageContentStream(document, newPage, PDPageContentStream.AppendMode.APPEND, true)) {
                contentStream.setFont(PDType1Font.TIMES_BOLD, 10);
                contentStream.setNonStrokingColor(0, 0, 0); // Dark black

                float margin = 70;
                float y = 700; // Adjusted for new page (top-down)
                float tableWidth = 500;
                float rowHeight = 20;

                // Write signature and employee name
                contentStream.beginText();
                contentStream.newLineAtOffset(margin + 5, y);
                contentStream.showText("Employee Signature: " + file.getEmployeeSignature());
                contentStream.newLineAtOffset(0, -rowHeight);
                contentStream.showText("Employee Name: " + file.getEmployeeName());
                contentStream.endText();

                // Write date and place in the right corner
                contentStream.beginText();
                contentStream.newLineAtOffset(margin + tableWidth - 150, y);
                contentStream.showText("Place: " + file.getLocation());
                contentStream.newLineAtOffset(0, -rowHeight);
                contentStream.showText("Date: " + file.getCurrentDate());
                contentStream.endText();

                // Add signature image if available
                String signaturePath = "signature.png"; // Update if dynamic
                File signatureFile = new File(signaturePath);
                if (signatureFile.exists()) {
                    PDImageXObject signatureImage = PDImageXObject.createFromFile(signaturePath, document);
                    contentStream.drawImage(signatureImage, margin + tableWidth - 100, y - rowHeight - 10, 80, 40);
                }
            }

            // Save updated PDF
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            document.save(outputStream);
            file.setDocumentImage(outputStream.toByteArray());
        }

        return file;
    }


}

