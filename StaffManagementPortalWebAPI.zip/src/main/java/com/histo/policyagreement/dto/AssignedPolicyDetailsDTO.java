package com.histo.policyagreement.dto;

import lombok.Data;

import java.util.List;

@Data
public class AssignedPolicyDetailsDTO {

    private Integer documentId;
    private List<Integer> employeeId;
    private String assignedDate;
    private String reviewedDate;
    private Integer modifiedBy;
    private String modifiedDate;
    private Integer assignedBy;
    private String recordStatus;
    private String isNotify;
}

