package com.histo.policyagreement.dto;

import lombok.Data;

@Data
public class ReviewedPolicyDetailsDTO {

    private Integer policyId;
    private String documentId;
    private Integer policyDetailId;
    private String documentTitle;
    private String documentName;
    private byte[] documentImage;
    private Integer modifiedBy;
    private String modifiedDate;
    private Integer createdBy;
    private String createdOn;
    private Character recordStatus;
}
