package com.histo.policyagreement.dto;

import com.histo.policyagreement.model.RevisionFrequencyEnum;
import lombok.Data;

@Data
public class PolicyDocumentDTO {
    private Integer documentId;
    private String documentType;
    private String documentTitle;
    private String documentName;
    private String documentContent;
    private byte[] documentImage;
    private String documentCategoryName;
    private Integer documentTypeId;
    private Integer locationId;
    private Integer modifiedBy;
    private String modifiedDate;
    private Integer createdBy;
    private String createdOn;
    private Character recordStatus;

    private String revisionFrequency;
    private Integer authorId;
    private String version;
    private String documentNumber;
    private String validityDate;
    private String validFromDate;
}
