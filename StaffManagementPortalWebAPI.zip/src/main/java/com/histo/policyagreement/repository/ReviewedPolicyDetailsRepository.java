package com.histo.policyagreement.repository;

import com.histo.policyagreement.entity.ReviewedPolicyDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface ReviewedPolicyDetailsRepository extends JpaRepository< ReviewedPolicyDetails, Integer> {
    @Query("select count(r) from ReviewedPolicyDetails r where r.documentId.documentId = ?1 and (r.isReviewed = ?2 OR ?2 = 'All')")
    long getCountByIdAndStatus(Integer documentId, String isReviewed);
    List<ReviewedPolicyDetails> findByDocumentId_DocumentIdAndRecordStatus(Integer documentId, String recordStatus);

    List<ReviewedPolicyDetails> findByEmployeeIdAndRecordStatusAndIsReviewed(Integer employeeId, String recordStatus, String isReviewed);

}
