package com.histo.policyagreement.repository;

public interface DocumentVersionProjection {
    String getDocumentNumber();
    String getVersion();
}
