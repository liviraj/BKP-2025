package com.histo.policyagreement.repository;

import com.histo.policyagreement.entity.PolicyDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface PolicyDocumentRepository extends JpaRepository< PolicyDocument, Integer> {

    Optional<PolicyDocument> findByDocumentIdAndRecordStatus(Integer documentId, String recordStatus);

    List<PolicyDocument> findByDocumentTypeAndDocumentTypeIdAndDocumentCategoryNameAndRecordStatusAndLocationId
            (String documentType, Integer documentTypeId, String documentCategoryName, String recordStatus, Integer locationId);

    @Transactional
    @Modifying
    @Query("update PolicyDocument e set e.modifiedBy = :modifiedBy ,e.modifiedDate = :modifiedOn, e.recordStatus = 'D' where e.documentId = :id")
    int updateModifiedByById(@Param("id") Integer id, @Param("modifiedBy") Integer modifiedBy, @Param("modifiedOn") Instant modifiedDate);

    @Query("""
            SELECT MAX(d.documentNumber) AS documentNumber,MAX(d.version) AS version FROM PolicyDocument d
            """)
    DocumentVersionProjection findLatestDocumentVersion();


}
