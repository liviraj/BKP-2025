package com.histo.policyagreement.repository;

import com.histo.policyagreement.entity.AssignedPolicyDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;


public interface AssignedPolicyDetailsRepository extends JpaRepository< AssignedPolicyDetails, Integer> {
    @Query(value = "select DATEDIFF(month,a.DocumentValidFromDate,a.DocumentValidToDate) As validPeriod from AssignedPolicyDetails a where a.assignedPolicyDetailId = ?1 ",nativeQuery = true)
    Optional<Integer> findByDocumentPeriod(Integer assignedPolicyDetailId);

    @Query(value = "select a.* from AssignedPolicyDetails a where a.documentId = ?1 ",nativeQuery = true)
    Optional<AssignedPolicyDetails> findByPolicyDocument_DocumentId(Integer documentId);

    @Query(value = "select a.* from AssignedPolicyDetails a where a.assignedPolicyDetailId = ?1 and a.dueDate = ?2",nativeQuery = true)
    Optional<AssignedPolicyDetails> findByAssignedPolicyDetailIdAndDueDate(Integer assignedPolicyDetailId, String dueDate);

    @Query(value = """
             SELECT CASE WHEN documentCategoryName = 'Every Year' THEN DATEADD(YEAR,1,?1) ELSE null END AS validToDate
             from PolicyDocument P  WHERE P.DocumentId = ?2
            """,nativeQuery = true)
    String getPolicyValidityToDate(String dueDate, Integer documentId);

}
