package com.histo.policyagreement.entity;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.histo.staffmanagementportal.util.InstantConverter;
import lombok.Data;

import java.time.Instant;
import java.util.Date;

@Entity
@Table(name = "PolicyDocument")
@Data
public class PolicyDocument {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DocumentId")
    private Integer documentId;

    @Column(name = "DocumentType")
    private String documentType;

    @Column(name = "DocumentTitle")
    private String documentTitle;

    @Column(name = "DocumentName")
    private String documentName;

    @Column(name = "documentTypeId" )
    private Integer documentTypeId;

    @Column(name = "documentCategoryName")
    private String documentCategoryName;

    @Lob
    @Column(name = "DocumentImage")
    private byte[] documentImage;

    @Column(name = "locationId" )
    private Integer locationId;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @Column(name = "ModifiedDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS",timezone = "UTC")
    @Convert(converter = InstantConverter.class)
    private Instant modifiedDate;

    @Column(name = "CreatedBy")
    private Integer createdBy;

    @Column(name = "CreatedOn")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS",timezone = "UTC")
    @Convert(converter = InstantConverter.class)
    private Instant createdOn;

    @Column(name = "RecordStatus", length = 1)
    private String recordStatus;

    @Column(name = "version", length = 25)
    private String version;

    @Column(name = "DocumentNumber", length = 255)
    private String documentNumber;

    @Column(name = "RevisionFrequency", length = 100)
    private String revisionFrequency;

    @Column(name = "Author")
    private Integer author;

    @Column(name = "ValidityDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS", timezone = "Default")
    @Convert(converter = InstantConverter.class)
    private Instant validityDate;

    @Column(name = "validFromDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS", timezone = "Default")
    @Convert(converter = InstantConverter.class)
    private Instant validFromDate;
}
