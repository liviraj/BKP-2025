package com.histo.policyagreement.entity;

public enum DocumentStatusEnum {

    COMPLETED("Completed"),
    PENDING("Pending");

    private String value;

    public String getValue() {
        return value;
    }

    DocumentStatusEnum(String value) {
        this.value = value;
    }

}
