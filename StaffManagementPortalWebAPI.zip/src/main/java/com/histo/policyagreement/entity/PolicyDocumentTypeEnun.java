package com.histo.policyagreement.entity;

public enum PolicyDocumentTypeEnun {

    COMPLIANCE("Compliance");
//    HR_DOCUMENT("HR Document");

    private String value;

    public String getValue() {
        return value;
    }

    PolicyDocumentTypeEnun(String value) {
        this.value = value;
    }

}
