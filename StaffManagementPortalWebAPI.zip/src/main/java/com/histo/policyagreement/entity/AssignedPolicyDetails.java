package com.histo.policyagreement.entity;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.histo.staffmanagementportal.util.InstantConverter;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

@Entity
@Table(name = "AssignedPolicyDetails")
@Getter
@Setter
@NoArgsConstructor
public class AssignedPolicyDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "AssignedPolicyDetailId")
    private Integer assignedPolicyDetailId;

    @ManyToOne
    @JoinColumn(name = "DocumentId", nullable = false)
    private PolicyDocument policyDocument;

    @Column(name = "AssignedDate", nullable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS",timezone = "UTC")
    @Convert(converter = InstantConverter.class)
    private Instant assignedDate;

    @Column(name = "DueDate", nullable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS",timezone = "UTC")
    @Convert(converter = InstantConverter.class)
    private Instant dueDate;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @Column(name = "ModifiedDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS",timezone = "UTC")
    @Convert(converter = InstantConverter.class)
    private Instant modifiedDate;

    @Column(name = "AssignedBy")
    private Integer assignedBy;

    @Column(name = "RecordStatus", length = 1)
    private String recordStatus;

    @Column(name = "DocumentValidFromDate", nullable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS",timezone = "UTC")
    @Convert(converter = InstantConverter.class)
    private Instant documentValidFromDate;

    @Column(name = "DocumentValidToDate", nullable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS",timezone = "UTC")
    @Convert(converter = InstantConverter.class)
    private Instant documentValidToDate;
}
