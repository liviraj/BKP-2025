package com.histo.policyagreement.entity;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.histo.staffmanagementportal.util.InstantConverter;
import lombok.Data;

import java.time.Instant;
import java.util.Date;

@Entity
@Table(name = "ReviewedPolicyDetails")
@Data
public class ReviewedPolicyDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ReviewedPolicyId")
    private Integer reviewedPolicyId;

    @ManyToOne
    @JoinColumn(name = "documentId", nullable = false)
    private PolicyDocument documentId;

    @Column(name = "EmployeeId", nullable = false)
    private Integer employeeId;

    @Column(name = "IsReviewed", nullable = false)
    private String isReviewed;

    @Column(name = "DocumentName",  nullable = false)
    private String documentName;

    @Lob
    @Column(name = "DocumentImage")
    private byte[] documentImage;

    @Column(name = "ReviewedDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS",timezone = "UTC")
    @Convert(converter = InstantConverter.class)
    private Instant reviewedDate;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @Column(name = "ModifiedDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS",timezone = "UTC")
    @Convert(converter = InstantConverter.class)
    private Instant modifiedDate;

    @Column(name = "CreatedBy")
    private Integer createdBy;

    @Column(name = "CreatedOn")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS",timezone = "UTC")
    @Convert(converter = InstantConverter.class)
    private Instant createdOn;

    @Column(name = "documentExpiryDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS",timezone = "Default")
    @Convert(converter = InstantConverter.class)
    private Instant documentExpiryDate;

    @Column(name = "RecordStatus", length = 1)
    private String recordStatus;
}
