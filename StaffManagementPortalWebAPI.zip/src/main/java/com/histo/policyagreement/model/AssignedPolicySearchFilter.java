package com.histo.policyagreement.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class AssignedPolicySearchFilter {

     Integer locationId;
     Integer documentId;
     Integer employeeId; //only for Review Document API
     String dueDate;
}
