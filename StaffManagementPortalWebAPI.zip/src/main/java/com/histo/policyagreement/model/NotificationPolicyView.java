package com.histo.policyagreement.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
public class NotificationPolicyView {

    private Integer policyDetailId;
    private String documentTitle;
    private Integer documentId;
    private String status;
    private String assignedDate;
}
