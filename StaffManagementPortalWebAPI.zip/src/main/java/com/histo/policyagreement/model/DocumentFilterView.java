package com.histo.policyagreement.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DocumentFilterView {

     private Integer documentId;
     private String location;
     private Integer locationId;
     private String documentType;
     private String documentTitle;
     private String documentCategory;
     private String assignedDate;
     private String dueDate;
     private Boolean isValid;
     private String completedPercentage;
}
