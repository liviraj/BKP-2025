package com.histo.policyagreement.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DocumentView {
    private Integer documentId;
    private String documentType;
    private String documentTitle;
    private String modifiedBy;
    private String modifiedDate;
    private String createdBy;
    private String createdOn;
    private String recordStatus;
    private Integer documentTypeId;
    private String documentCategoryName;
    private String location;
    private Integer locationId;
    private String documentNumber;
    private String version;
    private String author;
}
