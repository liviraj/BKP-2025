package com.histo.policyagreement.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class SearchFilter {

    private Integer locationId;
    private Integer status;
    private Integer year;
    private String documentType;
}
