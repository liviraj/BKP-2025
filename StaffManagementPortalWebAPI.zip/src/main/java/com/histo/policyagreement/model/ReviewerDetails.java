package com.histo.policyagreement.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ReviewerDetails {

    private Integer documentId;
    private String employeeSignature;
    private String date;
    private Integer reviewedEmpId;
}
