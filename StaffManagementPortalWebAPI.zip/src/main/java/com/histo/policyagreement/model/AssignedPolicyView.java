package com.histo.policyagreement.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AssignedPolicyView extends AssignedPolicySearchFilter{

    private String locationName;
    private List<Integer> pendingEmployeeId;
    private List<Integer> completedEmployeeId;
}
