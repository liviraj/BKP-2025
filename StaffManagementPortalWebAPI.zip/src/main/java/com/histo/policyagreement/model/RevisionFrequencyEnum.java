package com.histo.policyagreement.model;

public enum RevisionFrequencyEnum {
    YEARLY("Yearly"),
    SEMI_ANNUALLY("Semi-Annually"),
    QUARTERLY("Quarterly"),
    MONTHLY("Monthly"),
    WEEKLY("Weekly"),
    DAILY("Daily");

    private final String value;

    RevisionFrequencyEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static RevisionFrequencyEnum fromValue(String value) {
        for (RevisionFrequencyEnum frequency : RevisionFrequencyEnum.values()) {
            if (frequency.getValue().equalsIgnoreCase(value)) {
                return frequency;
            }
        }
        throw new IllegalArgumentException("Unknown value: " + value);
    }
}
