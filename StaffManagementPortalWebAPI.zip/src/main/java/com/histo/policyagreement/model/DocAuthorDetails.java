package com.histo.policyagreement.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DocAuthorDetails {
    private int employeeId;
    private String authorName;
}
