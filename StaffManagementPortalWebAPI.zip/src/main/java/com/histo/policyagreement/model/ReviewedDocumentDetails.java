package com.histo.policyagreement.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ReviewedDocumentDetails {

    private Integer policyDetailId;
    private Integer employeeId;
    private String documentTitle;
    private String employeeName;
    private String employeeSignature;
    private String assigneeName;
    private String isReviewed;
    private String documentExpiryDate;
    private String currentDate;
    private String assignedDate;
    private String documentName;
    private byte[] documentImage;
    private String location;
}
