package com.histo.policyagreement.model;

public enum DocTypeEnum {
    HIPPA("HIPPA");
    private final String value;

    DocTypeEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
