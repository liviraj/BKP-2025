package com.histo.policyagreement.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
public class PolicyDocPreloadDetails {
    private List<String> revisionFrequencyList;
    private String currentVersion;
    private String documentNumber;
    private List<DocAuthorDetails> policyDocAuthors;
}
