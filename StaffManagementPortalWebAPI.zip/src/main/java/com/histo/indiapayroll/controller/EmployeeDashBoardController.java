package com.histo.indiapayroll.controller;

import com.azure.core.annotation.QueryParam;
import com.histo.indiapayroll.model.PayRollFilterModel;
import com.histo.indiapayroll.service.EmployeeDashBoardService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/dashboard")
public class EmployeeDashBoardController {

    private final EmployeeDashBoardService employeeDashBoardService;

    public EmployeeDashBoardController(EmployeeDashBoardService employeeDashBoardService) {
        this.employeeDashBoardService = employeeDashBoardService;
    }


    @GetMapping("/employee-info/{employeeId}")
    public ResponseEntity<Object> getEmployeeDetails(@PathVariable Integer employeeId){
        return employeeDashBoardService.getEmployeeInfo (employeeId);
    }
    @GetMapping("/birthday-details/{locationId}")
    public ResponseEntity<Object> getEmployeeBirthDayDetails(@PathVariable Integer locationId){
        return employeeDashBoardService.getBirthDetails (locationId);
    }
    @GetMapping("/leave-details/{locationId}")
    public ResponseEntity<Object> getEmployeeLeaveDetails(@PathVariable Integer locationId){
        return employeeDashBoardService.getEmployeeLeaveDetails (locationId);
    }


    @GetMapping("/org/{employeeId}")
    public ResponseEntity<Object> getEmployeeOrgDetails(@PathVariable Integer employeeId){
        return employeeDashBoardService.getOrganizationChartDetails (employeeId);
    }

    @GetMapping("/employee/requestHistory")
    public ResponseEntity<Object> getEmployeeLeaveAndPermissionHistory(@QueryParam (value = "filter") PayRollFilterModel payRollFilterModel){
        return employeeDashBoardService.getEmployeeLeaveAndPermissionHistory (payRollFilterModel);
    }


}
