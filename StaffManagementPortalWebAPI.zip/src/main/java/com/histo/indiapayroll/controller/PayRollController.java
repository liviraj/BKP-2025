package com.histo.indiapayroll.controller;


import com.azure.core.annotation.QueryParam;
import com.histo.indiapayroll.model.AuditDocUpdateModel;
import com.histo.indiapayroll.model.PayCycleDetails;
import com.histo.indiapayroll.model.PayRollFilterModel;
import com.histo.indiapayroll.model.PayRollViewFilter;
import com.histo.indiapayroll.service.PayRollDetailsService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payroll")
public class PayRollController {

    private final PayRollDetailsService payRollDetailsService;

    public PayRollController(PayRollDetailsService payRollDetailsService) {
        this.payRollDetailsService = payRollDetailsService;
    }


    @GetMapping
    public ResponseEntity<Object> getEmployeeDetails(@QueryParam (value = "input")PayRollFilterModel payRollFilterModel){
        return payRollDetailsService.getEmployeePayrollDetails (payRollFilterModel);
    }

    @PostMapping("/upload")
    public ResponseEntity<Object> uploadExcel(@RequestBody PayCycleDetails payCycleDetails) {

        return payRollDetailsService.uploadAuditorDocument (payCycleDetails);
    }

    @GetMapping("/details")
    public ResponseEntity<Object> getLeaveBalanceDetail(@QueryParam (value = "input") PayRollViewFilter filterModel) {

        return payRollDetailsService.getLeaveDetails (filterModel);
    }

    @PutMapping("{documentId}")
    public ResponseEntity<Object> editAuditLeaveBalance(@PathVariable("documentId") Integer documentId, @RequestBody AuditDocUpdateModel auditDocUpdateModel) {

        return payRollDetailsService.editAuditDocLeaveBalance (documentId,auditDocUpdateModel);
    }

}
