package com.histo.indiapayroll.service;

import com.histo.indiapayroll.model.PayRollFilterModel;
import org.springframework.http.ResponseEntity;

public interface EmployeeDashBoardService {

    ResponseEntity<Object> getEmployeeInfo(Integer employeeId);

    ResponseEntity<Object> getBirthDetails(Integer employeeId);

    ResponseEntity<Object> getEmployeeLeaveDetails(Integer employeeId);

    ResponseEntity<Object> getOrganizationChartDetails(Integer employeeId);
    ResponseEntity<Object> getEmployeeLeaveAndPermissionHistory(PayRollFilterModel payRollFilterModel);

}
