package com.histo.indiapayroll.service;

import com.histo.indiapayroll.model.AuditDocUpdateModel;
import com.histo.indiapayroll.model.PayCycleDetails;
import com.histo.indiapayroll.model.PayRollFilterModel;
import com.histo.indiapayroll.model.PayRollViewFilter;
import org.springframework.http.ResponseEntity;

public interface PayRollDetailsService {

    ResponseEntity<Object> getEmployeePayrollDetails(PayRollFilterModel payRollFilterModel);
    ResponseEntity<Object> uploadAuditorDocument(PayCycleDetails payCycleDetails);

    ResponseEntity<Object> getLeaveDetails(PayRollViewFilter filterModel);
    ResponseEntity<Object> editAuditDocLeaveBalance(Integer documentId, AuditDocUpdateModel dto);
}
