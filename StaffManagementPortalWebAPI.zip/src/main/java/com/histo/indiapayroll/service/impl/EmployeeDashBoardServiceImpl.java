package com.histo.indiapayroll.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.indiapayroll.model.EmployeeInfo;
import com.histo.indiapayroll.model.EmployeeOrgDetails;
import com.histo.indiapayroll.model.PayRollFilterModel;
import com.histo.indiapayroll.service.EmployeeDashBoardService;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.model.ResultSetMapper;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class EmployeeDashBoardServiceImpl implements EmployeeDashBoardService {

    private static final Logger logger = LogManager.getLogger(EmployeeDashBoardServiceImpl.class);
    private static final String STATUS = "status";
    private final ResponseModel response;

    private MappingJacksonValue mappingJacksonValue;


    public EmployeeDashBoardServiceImpl(ResponseModel response) {
        this.response = response;
    }

    @Override
    public ResponseEntity<Object> getEmployeeInfo(Integer employeeId) {
        try{
            List<EmployeeInfo> employeeDetails = SqlConnectionSetup.getJdbcConnection ().query ("exec spEmployeeDetailsForDashBoard ?",
                    BeanPropertyRowMapper.newInstance (EmployeeInfo.class),
                    employeeId);

            if(ObjectUtils.isEmpty (employeeDetails)){
                return catchException ("getEmployeeInfo()", null, "Failed", "Unable to get employee personal details.");
            }

            response.setData (employeeDetails);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        }
        catch (Exception e){
            return catchException ("getEmployeeInfo()", e, "Failed", "Unable to get employee details.");
        }
    }

    @Override
    public ResponseEntity<Object> getBirthDetails(Integer locationId) {
        try{

            List<Object> employeeBirthDayDetails = SqlConnectionSetup.getJdbcConnection ().query ("exec spEmployeeBirthDayDetailsForDashBoard ?",
                    new ResultSetMapper (),
                    locationId);

            response.setData (employeeBirthDayDetails);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        }
        catch (Exception e){
            return catchException ("getBirthDetails()", e, "Failed", "Unable to get employee birthday details.");
        }
    }

    @Override
    public ResponseEntity<Object> getEmployeeLeaveDetails(Integer locationId) {
        try{

            List<Object> employeeLeaveDetails = SqlConnectionSetup.getJdbcConnection ().query ("exec spEmployeeLeaveDetailsForDashBoard ?",
                    new ResultSetMapper (),
                    locationId);

            response.setData (employeeLeaveDetails);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        }
        catch (Exception e){
            return catchException ("getEmployeeLeaveDetails()", e, "Failed", "Unable to get employee leave details.");
        }
    }

    @Override
    public ResponseEntity<Object> getOrganizationChartDetails(Integer employeeId) {
        try{
            List<EmployeeOrgDetails> employeeDashBoardDetails = SqlConnectionSetup.getJdbcConnection ().query ("exec GetEmployeeOrgChartForDashBoard ?",
                    BeanPropertyRowMapper.newInstance (EmployeeOrgDetails.class),
                    employeeId);

            if(employeeDashBoardDetails.isEmpty ()){
                return catchException ("getOrganizationChartDetails()", null, "Failed", "Unable to get employee details.");
            }

            HashMap<String, List<EmployeeOrgDetails>> map = new HashMap ();

            map.putIfAbsent ("supervisorDetails",employeeDashBoardDetails.stream ().filter (data -> data.getReportingTo () == 0).toList ());

            if (map.get("supervisorDetails") != null ) {
                List<Integer> supervisorIds = map.get("supervisorDetails").stream()
                        .map(EmployeeOrgDetails::getEmployeeId)
                        .toList();

                // Filter employees whose reportingTo matches a supervisor's employeeId
                List<EmployeeOrgDetails> filteredEmployees = employeeDashBoardDetails.stream()
                        .filter(data -> supervisorIds.contains(data.getReportingTo()))
                        .toList();

                // Update the map
                map.put("employeeDetails", filteredEmployees);

                if (map.get("employeeDetails") != null ) {
                    List<Integer> supervisorId = map.get("employeeDetails").stream()
                            .map(EmployeeOrgDetails::getEmployeeId)
                            .toList();

                    // Filter employees whose reportingTo matches a supervisor's employeeId
                    filteredEmployees = employeeDashBoardDetails.stream()
                            .filter(data -> supervisorId.contains(data.getReportingTo()))
                            .toList();

                    // Update the map
                    map.put("teamMember", filteredEmployees);
                }
            }
            response.setData (map);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        }
        catch (Exception e){
            return catchException ("getEmployeeInfo()", e, "Failed", "Unable to get employee details.");
        }
    }

    @Override
    public ResponseEntity<Object> getEmployeeLeaveAndPermissionHistory(PayRollFilterModel payRollFilterModel) {
        try{

            List<Object> employeeOverAllRequestDetails = SqlConnectionSetup.getJdbcConnection ().query ("exec GetEmployeeRequestDetailsForDashboard ?,?,?;",
                    new ResultSetMapper (),
                    payRollFilterModel.getFromDate (),
                    payRollFilterModel.getToDate (),
                    payRollFilterModel.getEmployeeId ());

            response.setData (employeeOverAllRequestDetails);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        }
        catch (Exception e){
            return catchException ("getEmployeeLeaveAndPermissionHistory()", e, "Failed", "Unable to get employee leave and permission history details.");
        }
    }

    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
        logger.error("{} Error : {}" , methodName, e);
        response.setStatus(false);
        response.setInformation(new ExceptionBean (Instant.now(), message, description));
        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }
}
