package com.histo.indiapayroll.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.indiapayroll.entity.AuditorDocument;
import com.histo.indiapayroll.entity.AuditorDocumentDetails;
import com.histo.indiapayroll.model.*;
import com.histo.indiapayroll.repository.AuditorDocumentDetailsRepository;
import com.histo.indiapayroll.repository.AuditorDocumentRepository;
import com.histo.indiapayroll.service.PayRollDetailsService;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.intranet.entity.LeaveTypeMaster;
import com.histo.staffmanagementportal.intranet.repository.LeaveTypeMasterRepository;
import com.histo.staffmanagementportal.model.Constants;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.model.ResultSetMapper;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class PayRollDetailsServiceImpl implements PayRollDetailsService {

    private static final Logger logger = LogManager.getLogger(PayRollDetailsServiceImpl.class);
    private static final String STATUS = "status";
    private final ResponseModel response;
    private MappingJacksonValue mappingJacksonValue;

    private final AuditorDocumentRepository auditorDocumentRepository;
    private final AuditorDocumentDetailsRepository auditorDocumentDetailsRepo;

    private final LeaveTypeMasterRepository leaveTypeMasterRepo;

    public PayRollDetailsServiceImpl(ResponseModel response, AuditorDocumentRepository auditorDocumentRepository, AuditorDocumentDetailsRepository auditorDocumentDetailsRepo, LeaveTypeMasterRepository leaveTypeMasterRepo) {
        this.response = response;
        this.auditorDocumentRepository = auditorDocumentRepository;
        this.auditorDocumentDetailsRepo = auditorDocumentDetailsRepo;
        this.leaveTypeMasterRepo = leaveTypeMasterRepo;
    }

    @Override
    public ResponseEntity<Object> getEmployeePayrollDetails(PayRollFilterModel payRollFilterModel) {
       try{
           List<PayRollDetails> indiaPayRollDetails = SqlConnectionSetup.getJdbcConnection ().query ("exec GetPayRollDetails ?,?;",
                   BeanPropertyRowMapper.newInstance (PayRollDetails.class),
                   payRollFilterModel.getFromDate (),
                   payRollFilterModel.getToDate ());
           if(ObjectUtils.isEmpty (indiaPayRollDetails)){
               return catchException ("getEmployeePayrollDetails()", null, "Failed", "Unable to get employee details.");
           }
           Map<String, List<PayRollDetails>> payRollDetails = indiaPayRollDetails.stream()
                   .collect(Collectors.groupingBy(PayRollDetails::getModuleName));
           response.setData (payRollDetails);
           response.setStatus (true);
           mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
           return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
       }
       catch(Exception e){
           return catchException ("getEmployeePayrollDetails()", e, "Failed", "Unable to get employee details.");
       }
    }

    @Override
    public ResponseEntity<Object> uploadAuditorDocument(PayCycleDetails payCycleDetails) {
        try {

            LeaveTypeMaster leaveTypeMaster = leaveTypeMasterRepo.findById(payCycleDetails.leaveTypeId())
                    .orElseThrow(() -> new NullPointerException("Please select valid leave type."));

            Optional<AuditorDocument> auditorDocumentOptional = auditorDocumentRepository.findByMonthNameAndForYearAndDocumentStatusAndLeaveTypeId_LeaveTypeId(
                    payCycleDetails.monthName (),
                    payCycleDetails.forYear (),
                    Constants.ACTIVE_RECORD_STATUS,
                    payCycleDetails.leaveTypeId());

            if(auditorDocumentOptional.isPresent ()){
                return catchException ("uploadAuditorDocument()", null, "Failed", "Already uploaded file for given year and month.");
            }

            ResponseEntity<Object> readExcelFile = readExcelFile (payCycleDetails.imageBinary ());

            if(readExcelFile.getStatusCode () != HttpStatus.OK){
                return readExcelFile;
            }

            Object processedExcelData = readExcelFile.getBody();

            if (processedExcelData  == null) {
                return catchException("uploadAuditorDocument()", null, "Failed", "No records found in given excel sheet.");
            }

            ResponseModel value = (ResponseModel) ((MappingJacksonValue) processedExcelData).getValue();
            List<AuditorDocumentDTO> auditorDocumentDTOs = (List<AuditorDocumentDTO>)  value.getData();

            AuditorDocument auditorDocument = new AuditorDocument ();

            auditorDocument.setDocument (payCycleDetails.imageBinary ());
            auditorDocument.setDocumentFileName (payCycleDetails.imageName ());
            auditorDocument.setDocumentStatus (Constants.ACTIVE_RECORD_STATUS);
            auditorDocument.setMonthName (payCycleDetails.monthName ());
            auditorDocument.setUploadedBy (payCycleDetails.addedBy ());
            auditorDocument.setDateOfUpload (InstantFormatter.InstantFormat (payCycleDetails.addedOn ()));
            auditorDocument.setForYear (payCycleDetails.forYear ());
            auditorDocument.setLeaveTypeId(leaveTypeMaster);

            AuditorDocument savedDocument = auditorDocumentRepository.save (auditorDocument);

            List<AuditorDocumentDetails> auditorDocuments = auditorDocumentDTOs.stream ().map (dto -> convertToEntity(dto, savedDocument))
                    .toList ();

            List<AuditorDocumentDetails> auditorDocumentDetails = auditorDocumentDetailsRepo.saveAll (auditorDocuments);

            response.setStatus (true);
            response.setMessage ("Successfully uploaded audit documents.");
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);

        }
        catch (Exception e) {
            return catchException ("uploadAuditorDocument()", e, "Failed", "Error processing file." );
        }

    }

    @Override
    public ResponseEntity<Object> getLeaveDetails(PayRollViewFilter filterModel) {
       try{

           List<Object> leaveDetails = SqlConnectionSetup.getJdbcConnection ().query ("exec spValidateAndGetLeaveBal ?,?,?,?;", new ResultSetMapper (),
                   filterModel.getEmployeeId (),
                   filterModel.getYear (),
                   filterModel.getPayRollMonth (),
                   filterModel.getLeaveTypeId());

           response.setStatus (true);
           response.setData (leaveDetails);
           mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
           return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);

       }
       catch (Exception e) {
           return catchException ("getLeaveDetails()", e, "Failed", "Unable to get leave balance details.");
       }
    }

    @Override
    public ResponseEntity<Object> editAuditDocLeaveBalance(Integer documentId, AuditDocUpdateModel dto) {
        try{

            Optional<AuditorDocumentDetails> auditorDocument = auditorDocumentDetailsRepo.findById (documentId);

            if(auditorDocument.isEmpty ()){
                return catchException ("editAuditDocLeaveBalance()", null, "Failed", "No value present for given documentId.");
            }

            auditorDocument.get ().setClosing (dto.getClosing ());
            auditorDocument.get ().setModifiedBy (dto.getModifiedBy ());
            auditorDocument.get ().setModifiedOn (InstantFormatter.InstantFormat (dto.getModifiedOn ()));

            AuditorDocumentDetails save = auditorDocumentDetailsRepo.save (auditorDocument.get ());

            response.setStatus (true);
            response.setMessage ("Leave balance updated successfully.");
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);

        }
        catch(Exception e){
            return catchException ("editAuditDocLeaveBalance()", e, "Failed", "Unable to edit Auditor document leave balance." );
        }
    }

    private ResponseEntity<Object> readExcelFile(byte[] binaryData) {
        List<AuditorDocumentDTO> employeeLeaveList = new ArrayList<> ();
        try{

            InputStream inputStream = new ByteArrayInputStream (binaryData);
            Workbook workbook = new XSSFWorkbook(inputStream);
            Sheet sheet = workbook.getSheetAt(0);

            // Get the first row (usually contains column names)
            Row headerRow = sheet.getRow(0);

            if (headerRow == null) {
                return catchException ("readExcelFile()", null, "Failed","Please upload a valid auditor document.");
            }

            // Map column names to indices
            Map<String, Integer> columnIndexMap = new HashMap<>();
            for (Cell cell : headerRow) {
                columnIndexMap.put(cell.getStringCellValue(), cell.getColumnIndex());
            }

            List<String> requiredColumns = Arrays.asList(
                    "EmployeeCode", "Name", "Opening", "AVD (PL)", "ALLD","Additional Credit", "Total Leave credit", "LOP", "Leave Encashed", "Closing"
            );

            if (!columnIndexMap.keySet().containsAll(requiredColumns)) {
                return catchException("readExcelFile()", null, "Failed", "Please upload a valid auditor document.");
            }

            Iterator<Row> rowIterator = sheet.iterator();
            rowIterator.next(); // Skip header row

            while (rowIterator.hasNext() ) {
                Row row = rowIterator.next();
                Cell employeeCodeCell = row.getCell(0);

                // Check if the EmployeeCode cell is null or empty
                if (employeeCodeCell == null || employeeCodeCell.getCellType() == CellType.BLANK || employeeCodeCell.getStringCellValue().trim().isEmpty()) {
                    break;
                }

                AuditorDocumentDTO dto = new AuditorDocumentDTO();


                dto.setEmployeeCode(row.getCell(columnIndexMap.get("EmployeeCode")).getStringCellValue());
                dto.setName(row.getCell(columnIndexMap.get("Name")).getStringCellValue());
                dto.setOpening(getCellValue(row.getCell(columnIndexMap.get("Opening"))));
                dto.setAvd(getCellValue(row.getCell(columnIndexMap.get("AVD (PL)"))));
                dto.setAlld(getCellValue(row.getCell(columnIndexMap.get("Total Leave credit"))));
                dto.setLop(getCellValue(row.getCell(columnIndexMap.get("LOP"))));
                // Get the "closing" value directly from the cell
                Cell closingCell = row.getCell(columnIndexMap.get("Closing"));
                dto.setClosing(getCellValue(closingCell)); // Handles numeric, string, and formula cells

//                dto.setRemarks(row.getCell(columnIndexMap.get("Remarks")) != null ? row.getCell(columnIndexMap.get("Remarks")).getStringCellValue() : null);

                employeeLeaveList.add(dto);
            }

            workbook.close();

            response.setStatus (true);
            response.setData (employeeLeaveList);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        }
        catch(Exception e){
             return catchException ("readExcelFile()", e, "Failed", "Error processing file." );
        }
    }

    private Double getCellValue(Cell cell) {
        if (cell == null || cell.getCellType() == CellType.BLANK) {
            return 0.0;
        }
        switch (cell.getCellType()) {
            case NUMERIC:
                return cell.getNumericCellValue();
            case STRING:
                String cellValue = cell.getStringCellValue().trim();
                if (cellValue.equals("-")) {
                    return 0.0;
                }
                try {
                    return Double.valueOf(cellValue);
                } catch (NumberFormatException e) {
                    return 0.0;
                }
            case FORMULA:
                // Evaluate the formula and get the resulting value
                FormulaEvaluator evaluator = cell.getSheet().getWorkbook().getCreationHelper().createFormulaEvaluator();
                CellValue celldata = evaluator.evaluate(cell);
                if (celldata != null && celldata.getCellType() == CellType.NUMERIC) {
                    return celldata.getNumberValue();
                }
                return 0.0; // Default to 0 if no numeric result
            default:
                return 0.0;
        }
    }

    private AuditorDocumentDetails convertToEntity(AuditorDocumentDTO dto, AuditorDocument documentId) {
        AuditorDocumentDetails auditorDocumentDetails = new AuditorDocumentDetails ();
        auditorDocumentDetails.setEmployeeCode(dto.getEmployeeCode());
        auditorDocumentDetails.setName(dto.getName());
        auditorDocumentDetails.setOpening(dto.getOpening());
        auditorDocumentDetails.setAvd(dto.getAvd());
        auditorDocumentDetails.setAlld(dto.getAlld());
        auditorDocumentDetails.setLop(dto.getLop());
        auditorDocumentDetails.setClosing(dto.getClosing());
        auditorDocumentDetails.setRemarks(dto.getRemarks());
        auditorDocumentDetails.setDocumentId (documentId);
        return auditorDocumentDetails;
    }

    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
        logger.error("{} Error : {}" , methodName, e);
        response.setStatus(false);
        response.setInformation(new ExceptionBean (Instant.now(), message, description));
        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }
}
