package com.histo.indiapayroll.repository;

import com.histo.indiapayroll.entity.AuditorDocument;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AuditorDocumentRepository extends JpaRepository<AuditorDocument, Integer> {
    Optional<AuditorDocument> findByMonthNameAndForYearAndDocumentStatus(String monthName, Integer forYear, String documentStatus);

    Optional<AuditorDocument> findByMonthNameAndForYearAndDocumentStatusAndLeaveTypeId_LeaveTypeId(String monthName, Integer forYear, String documentStatus, Integer leaveTypeId);


}

