package com.histo.indiapayroll.repository;

import com.histo.indiapayroll.entity.AuditorDocumentDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuditorDocumentDetailsRepository extends JpaRepository<AuditorDocumentDetails,Integer> {

}
