package com.histo.indiapayroll.entity;

import com.histo.staffmanagementportal.intranet.entity.LeaveTypeMaster;
import com.histo.staffmanagementportal.util.InstantConverter;
import lombok.*;

import javax.persistence.*;
import java.time.Instant;


@Entity
@Table(name = "AuditorDocuments")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class AuditorDocument {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DocumentID")
    private int documentId;

    @Column(name = "DateOfUpload")
    @Convert(converter = InstantConverter.class)
    private Instant dateOfUpload;

    @Column(name = "PayCycleMonthName", length = 150)
    private String monthName;

    @Column(name = "uploadedBy")
    private Integer uploadedBy;

    @Column(name = "ForYear")
    private Integer forYear;

    @Column(name = "Document")
    private byte[] document;

    @Column(name = "DocumentFileName", length = 255)
    private String documentFileName;

    @Column(name = "DocumentStatus", length = 1)
    private String documentStatus;

    @Column(name = "ModifiedOn")
    @Convert(converter = InstantConverter.class)
    private Instant modifiedOn;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "leaveTypeId", nullable = false)
    private LeaveTypeMaster leaveTypeId;
}