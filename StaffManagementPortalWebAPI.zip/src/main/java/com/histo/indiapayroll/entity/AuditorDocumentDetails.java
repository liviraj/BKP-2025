package com.histo.indiapayroll.entity;

import com.histo.staffmanagementportal.util.InstantConverter;
import lombok.*;

import javax.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "AuditorDocumentDetails")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class AuditorDocumentDetails {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "DocumentId", referencedColumnName = "DocumentId", nullable = false)
    private AuditorDocument documentId;

    @Column(name = "EmployeeCode")
    private String employeeCode;

    @Column(name = "EmployeeName")
    private String name;

    @Column(name = "OpeningBalance")
    private Double opening;

    @Column(name = "LeaveAvailed")
    private Double avd;

    @Column(name = "LeaveCredit")
    private Double alld;

    @Column(name = "LossOfPay")
    private Double lop;

    @Column(name = "ClosingBalance")
    private Double closing;

    @Column(name = "Remarks")
    private String remarks;

    @Column(name = "modifiedBy")
    private Integer modifiedBy;

    @Column(name = "modifiedOn")
    @Convert(converter = InstantConverter.class)
    private Instant modifiedOn;

}