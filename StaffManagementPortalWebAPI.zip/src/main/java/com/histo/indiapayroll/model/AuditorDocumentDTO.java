package com.histo.indiapayroll.model;

import lombok.Data;

@Data
public class AuditorDocumentDTO {
        private String employeeCode;
        private String name;
        private Double opening;
        private Double avd;
        private Double alld;
        private Double lop;
        private Double closing;
        private String remarks;
        private Integer documentId;
        private Integer leaveTypeId;

        // Getters and setters

}
