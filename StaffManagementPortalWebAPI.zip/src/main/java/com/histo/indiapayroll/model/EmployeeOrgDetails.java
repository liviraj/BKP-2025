package com.histo.indiapayroll.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class EmployeeOrgDetails {

    private Integer employeeId;
    private String employeeName;
    private String departmentName;
    private byte[] empImg;
    private String dateOfJoin;
    private String designationName;
    private Integer reportingTo;
}
