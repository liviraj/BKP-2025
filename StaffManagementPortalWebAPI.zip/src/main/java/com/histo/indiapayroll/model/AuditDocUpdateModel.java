package com.histo.indiapayroll.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class AuditDocUpdateModel {

    private Integer documentId;
    private Double closing;
    private Integer modifiedBy;
    private String modifiedOn;
}
