package com.histo.indiapayroll.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class EmployeeInfo {

    private Integer employeeId;
    private String employeeName;
    private String employeeCode;
    private String dateOfJoining;
    private Integer reportingToEmpId;
    private Integer departmentID;
    private String departmentName;
    private String designationName;
    private Integer locationid;
    private String reportingToEmpName;
    private Integer departmentSupervisorEmpId;
    private String departmentSupervisorEmpName;
    private byte[] employeeImage;
    private String employeeImageName;
    private double totalPermissionCount;
    private double totalSlCount;
    private double totalClCount;
    private double totalplCount ;
    private double totalVlCount ;
    private double totalWfhCount ;


}
