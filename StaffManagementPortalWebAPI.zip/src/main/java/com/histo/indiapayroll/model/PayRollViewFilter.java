package com.histo.indiapayroll.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class PayRollViewFilter {

    Integer leaveTypeId;
    Integer employeeId;
    Integer year;
    String payRollMonth; // Only for payroll fetch
}
