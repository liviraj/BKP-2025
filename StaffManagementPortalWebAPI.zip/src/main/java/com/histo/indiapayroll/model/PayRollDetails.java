package com.histo.indiapayroll.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class PayRollDetails {

    private Integer employeeId;
    private String employeeName;
    private String dateOfJoining;
    private String moduleName;
    private String employeeCode;
    private String completionDate;
    private String day;
}
