package com.histo.indiapayroll.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class WorkRequestHistoryForEmail {

     String requestDate;
     String remarks;
     String status;
     String approverComments;
}
