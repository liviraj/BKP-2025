package com.histo.indiapayroll.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class PayRollFilterModel {

    private Integer locationId;
    private String fromDate;
    private String toDate;
    private Integer employeeId; // Only for employee leave and permission request history

}
