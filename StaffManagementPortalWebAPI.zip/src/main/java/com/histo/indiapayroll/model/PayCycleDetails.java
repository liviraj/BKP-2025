package com.histo.indiapayroll.model;

import java.util.Arrays;
import java.util.Objects;

public record PayCycleDetails(String addedOn, Integer addedBy, String monthName, Integer forYear, String imageName, byte[] imageBinary, Integer leaveTypeId) {
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PayCycleDetails that = (PayCycleDetails) o;
        return Objects.equals(addedOn, that.addedOn) && Objects.equals(addedBy, that.addedBy) && Objects.equals(monthName, that.monthName) && Objects.equals(forYear, that.forYear) && Objects.equals(imageName, that.imageName) && Arrays.equals(imageBinary, that.imageBinary) && Objects.equals(leaveTypeId, that.leaveTypeId);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(addedOn, addedBy, monthName, forYear, imageName, leaveTypeId);
        result = 31 * result + Arrays.hashCode(imageBinary);
        return result;
    }

    public String toString() {
        return "PayCycleDetails : {" +
                "addedOn='" + addedOn +
                ", addedBy=" + addedBy +
                ", monthName='" + monthName +
                ", forYear=" + forYear +
                ", imageName='" + imageName +
                ", imageBinary=" + Arrays.toString(imageBinary) +
                ", leaveTypeId=" + leaveTypeId +
                '}';
    }
}
