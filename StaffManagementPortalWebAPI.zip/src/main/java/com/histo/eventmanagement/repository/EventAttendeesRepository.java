package com.histo.eventmanagement.repository;

import com.histo.eventmanagement.entity.EventAttendees;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.List;

public interface EventAttendeesRepository extends JpaRepository<EventAttendees, Integer> {
    @Transactional
    @Modifying
    @Query("delete from EventAttendees e where e.eventId = ?1")
    int deleteByEventId(Integer eventId);

    List<EventAttendees> findByEventIdOrderByEventAttendeeIDAsc(Integer eventId);

    @Transactional
    @Modifying
    @Query("update EventAttendees e set e.employeeId = ?1 where e.eventAttendeeID = ?2")
    int updateEmployeeIdByEventAttendeeID(Integer employeeId, Integer eventAttendeeID);

    @Transactional
    @Modifying
    @Query("delete from EventAttendees e where e.eventAttendeeID not in ?1 and e.eventId = ?2")
    int deleteByEventAttendeeIDNotInAndEventId(Collection<Integer> eventAttendeeIDS, Integer eventId);


}
