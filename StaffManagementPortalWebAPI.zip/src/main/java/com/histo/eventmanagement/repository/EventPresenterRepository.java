package com.histo.eventmanagement.repository;

import com.histo.eventmanagement.entity.EventPresenter;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EventPresenterRepository extends JpaRepository<EventPresenter,Integer> {
}
