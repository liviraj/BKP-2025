package com.histo.eventmanagement.repository;

import com.histo.eventmanagement.dto.ParticipationLevelDTO;
import com.histo.eventmanagement.entity.EventParticipationLevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface EventParticipationLevelRepository extends JpaRepository<EventParticipationLevel,Integer> {
    @Query(value = """
    select e.participationLevelID as id,e.participationLevel,case when participationLevel like '%presenter%' then 'true' else 'false' end as isPresenter from EventParticipationLevel e 
    order by e.participationLevel""",nativeQuery = true)
    List<ParticipationLevelDTO> GetAllOrderByParticipationLevelAsc();


}
