package com.histo.eventmanagement.repository;

import com.histo.eventmanagement.entity.Events;
import com.histo.eventmanagement.model.ViewEvents;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Repository
public interface EventsRepository extends JpaRepository<Events, Integer> {

    @Transactional
    @Modifying
    @Query("update Events e set e.modifiedBy = :modified, e.modifiedOn = :modifiedOn where e.eventID = :eventID")
    int updateModifiedByAndModifiedOnByEventID(@Param("modified") Integer modified, @Param("modifiedOn") Instant modifiedOn, @Param("eventID") Integer eventID);

    @Transactional
    @Modifying
    @Query("delete from Events e where e.eventID = ?1")
    int deleteByEventID(Integer eventID);

    Optional<Events> findByEventStartDateAndEventEndDateAndEventTypeId_EventTypeIDAndEventTypeDetailID
            (Instant eventStartDate, Instant eventEndDate, Integer eventTypeID, Integer eventTypeDetailID);

    Optional<Events> findByEventStartDateAndEventEndDateAndEventTypeId_EventTypeIDAndEventTypeDetailIDAndEventID
            (Instant eventStartDate, Instant eventEndDate, Integer eventTypeID, Integer eventTypeDetailID, Integer eventID);

    Optional<Events> findByEventStartDateAndEventEndDateAndEventTypeId_EventTypeIDAndEventTypeDetailIDAndEventIDNotIn
            (Instant eventStartDate, Instant eventEndDate, Integer eventTypeID, Integer eventTypeDetailID, Collection<Integer> eventIDS);

    Optional<Events> findEventsByEventStartDateAndEventEndDateAndEventTypeId_EventTypeIDAndEventTypeDetailIDAndEventIDNotInAndEventLocationId
            (Instant eventStartDate, Instant eventEndDate, Integer eventTypeID, Integer eventTypeDetailID, Collection<Integer> eventIDS, Integer eventLocationId);

    Optional<Events> findEventsByEventStartDateAndEventEndDateAndEventTypeId_EventTypeIDAndEventTypeDetailIDAndEventLocationId
            (Instant eventStartDate, Instant eventEndDate, Integer eventTypeID, Integer eventTypeDetailID, Integer eventLocationId);

    @Query("""
            select count(e.eventID)from Events e
            where e.eventStartDate = ?1 and e.eventEndDate = ?2 and e.eventTypeId.eventTypeID = ?3 and e.eventTypeDetailID = ?4 
            and e.eventID not in ?5 and e.eventLocationId = ?6 and e.eventTopic = ?7""")
    Integer existsByEventDetails(Instant eventStartDate, Instant eventEndDate, Integer eventTypeID
            , Integer eventTypeDetailID, Collection<Integer> eventIDS, Integer eventLocationId, String eventTopic);



}
