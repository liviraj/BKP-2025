package com.histo.eventmanagement.repository;

import com.histo.eventmanagement.entity.EventTypeDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EventTypeDetailRepository extends JpaRepository<EventTypeDetail,Integer> {
}
