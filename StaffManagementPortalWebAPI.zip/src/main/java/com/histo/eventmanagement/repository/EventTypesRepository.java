package com.histo.eventmanagement.repository;

import com.histo.eventmanagement.entity.EventTypes;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EventTypesRepository extends JpaRepository<EventTypes,Integer> {
    Optional<EventTypes> findByEventTypeID(Integer eventTypeID);
    

}
