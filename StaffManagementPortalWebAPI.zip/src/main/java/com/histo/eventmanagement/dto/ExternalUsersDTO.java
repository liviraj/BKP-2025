package com.histo.eventmanagement.dto;

import com.histo.eventmanagement.entity.EventAttendees;
import com.histo.eventmanagement.entity.ExternalUsers;
import lombok.*;

import java.util.Objects;

@Data
public class ExternalUsersDTO {

   private String externalUserName;
   private Integer eventId;
   private Integer externalUserID;


}
