package com.histo.eventmanagement.dto;

public interface ParticipationLevelDTO {

     Integer getId();
     String getParticipationLevel();
     String getIsPresenter();
}
