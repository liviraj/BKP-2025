package com.histo.eventmanagement.dto;

import com.histo.eventmanagement.model.EventAttendeeView;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EventDTO{

        private Integer eventId;
        private String guestName;
        private String eventStartDate;
        private String eventEndDate;
        private Integer eventTypeID;
        private Integer eventTypeDetailID;
        private String eventTopic;
        private String eventDescription;
        private int durationMin;
        private String isPartOfContinuousEducation;
        private Integer departmentID;
        private Integer modifiedBy;
        private String modifiedOn;
        private String fileName;
        private byte[] fileImageBinary;
        private String duration;
        private Integer eventLocationId;
        List<EventAttendeeView> attendeeDetailsDTO;
        List<ExternalUsersDTO> externalUsersDTO;
        List<EventAttendeeDTO> attendeeDetailsList;

}
