package com.histo.eventmanagement.dto;

import lombok.*;

@Data
public class EventAttendeeDTO {

    private Integer eventId;
    private Integer employeeId;
    private Integer participationLevelID;
    private String eventAttendeeType;
    private Integer eventAttendeeID;
}
