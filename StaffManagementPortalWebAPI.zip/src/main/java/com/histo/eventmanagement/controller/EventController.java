package com.histo.eventmanagement.controller;

import com.azure.core.annotation.QueryParam;
import com.histo.eventmanagement.dto.EventDTO;
import com.histo.eventmanagement.model.EventDetails;
import com.histo.eventmanagement.model.EventFilterModel;
import com.histo.eventmanagement.model.OrganizationChart;
import com.histo.eventmanagement.model.ReportFilter;
import com.histo.eventmanagement.service.EventService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/events")
public class EventController {

    private  final EventService eventService;

    public EventController(EventService eventService) {
        this.eventService = eventService;
    }

    @GetMapping("/types")
    public ResponseEntity<Object> getAllEventType(){
        return eventService.getEventTypes ();
    }

    @GetMapping("/employeeName")
    public ResponseEntity<Object> getEventEmployeeName(){
        return eventService.getEmployeeList ();
    }
    @GetMapping("/keywordType")
    public ResponseEntity<Object> getEventKeyWordType(){
        return eventService.getEventKeyWordType ();
    }

    @GetMapping("/externalAttendees")
    public ResponseEntity<Object> getAllExternalAttendees(){
        return eventService.getExternalAttendees ();
    }

    @GetMapping("/participationLevel")
    public ResponseEntity<Object> getAllParticipationLevel(){
        return eventService.getParticipationLevel ();
    }

    @GetMapping("/continousEducationReport")
    public ResponseEntity<Object> getContinousEducationReport(@QueryParam (value = "input") EventFilterModel eventFilterModel){
        return eventService.getContinousEducationReport (eventFilterModel);
    }

    @PostMapping
    public ResponseEntity<Object> recordEvent(@RequestBody EventDTO eventDTO){
        return eventService.recordEvent (eventDTO);
    }

    @GetMapping("/viewEvents")
    public ResponseEntity<Object> viewEventDetails(@QueryParam (value = "input") EventFilterModel eventFilterModel){
        return eventService.viewEvent (eventFilterModel);
    }

    @DeleteMapping
    public ResponseEntity<Object> deleteEventById(@RequestBody EventDetails eventDetails){
        return eventService.deleteEvent (eventDetails);
    }

    @PutMapping("{eventId}")
    public ResponseEntity<Object> editEvent(@RequestBody EventDTO eventDTO,@PathVariable(name = "eventId") Integer eventId){
        return eventService.updateEvent (eventDTO,eventId);
    }

    @GetMapping("{eventId}")
    public ResponseEntity<Object> getEventById(@PathVariable(name = "eventId") Integer eventId){
        return eventService.getEventByEventId (eventId);
    }

    @GetMapping("/reports")
    public ResponseEntity<Object> eventReport(@QueryParam (value = "input") ReportFilter reportFilter){
        return eventService.getEventReports (reportFilter);
    }

    @GetMapping("/report/category")
    public ResponseEntity<Object> eventReportCategory(){
        return eventService.getReportCategory ();
    }

    @GetMapping("/report/facilityPersonnel")
    public ResponseEntity<Object> getFacilityPersonnelReport(){
        return eventService.getFacilityPersonnelReport ();
    }

    @GetMapping("/log/{eventId}")
    public ResponseEntity<Object> getEventsLogDetails(@PathVariable("eventId") Integer eventId){
        return eventService.getEventLogDetailsById (eventId);
    }

    @GetMapping("/reports/summary")
    public ResponseEntity<Object> eventSummaryReport(@QueryParam (value = "input") ReportFilter reportFilter){
        return eventService.getEventSummaryDetails (reportFilter);
    }
}
