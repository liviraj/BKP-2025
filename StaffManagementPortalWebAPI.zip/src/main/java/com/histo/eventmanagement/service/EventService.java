package com.histo.eventmanagement.service;

import com.histo.eventmanagement.model.EventFilterModel;
import com.histo.eventmanagement.dto.EventDTO;
import com.histo.eventmanagement.model.EventDetails;
import com.histo.eventmanagement.model.ReportFilter;
import org.springframework.http.ResponseEntity;

public interface EventService {

    ResponseEntity<Object> getEventTypes();
    ResponseEntity<Object> getEmployeeList();
    ResponseEntity<Object> getParticipationLevel();
    ResponseEntity<Object> getExternalAttendees();
    ResponseEntity<Object> getContinousEducationReport(EventFilterModel eventFilterModel);
    ResponseEntity<Object> recordEvent(EventDTO eventDTO);
    ResponseEntity<Object> updateEvent(EventDTO eventDTO,Integer eventId);
    ResponseEntity<Object> deleteEvent(EventDetails eventDetails);
    ResponseEntity<Object> viewEvent(EventFilterModel eventFilterModel);
    ResponseEntity<Object> getEventByEventId(Integer eventId);
    ResponseEntity<Object> getEventKeyWordType();
    ResponseEntity<Object> getReportCategory();

    ResponseEntity<Object> getEventReports(ReportFilter reportFilter);
    ResponseEntity<Object> getFacilityPersonnelReport();

    ResponseEntity<Object> getEventLogDetailsById(Integer eventId);

    ResponseEntity<Object> getEventSummaryDetails(ReportFilter reportFilter);
}
