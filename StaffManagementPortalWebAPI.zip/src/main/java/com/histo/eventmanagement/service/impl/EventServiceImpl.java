package com.histo.eventmanagement.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.eventmanagement.dto.EventAttendeeDTO;
import com.histo.eventmanagement.dto.EventDTO;
import com.histo.eventmanagement.dto.ExternalUsersDTO;
import com.histo.eventmanagement.dto.ParticipationLevelDTO;
import com.histo.eventmanagement.entity.*;
import com.histo.eventmanagement.mapper.EventMapper;
import com.histo.eventmanagement.model.*;
import com.histo.eventmanagement.repository.*;
import com.histo.eventmanagement.service.EventService;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.helper.DateValidation;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.model.ResultSetMapper;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.Instant;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class EventServiceImpl implements EventService {

    private static final Logger logger = LogManager.getLogger (EventServiceImpl.class);
    private static final String STATUS = "status";
    private final ResponseModel response;
    private MappingJacksonValue mappingJacksonValue;
    private final EventTypesRepository eventTypesRepository;

    private final EventTypeDetailRepository eventTypeDetailRepository;

    private final EventsRepository eventsRepository;

    private final EventParticipationLevelRepository participationLevelRepo;

    private final EventAttendeesRepository eventAttendeesRepository;

    private final EventMapper eventMapper;
    private final ExternalUsersRepository externalUsersRepo;

    private final JdbcTemplate jdbcTemplate;

    public EventServiceImpl(ResponseModel response, EventTypesRepository eventTypesRepository, EventTypeDetailRepository eventTypeDetailRepository
            , EventsRepository eventsRepository, EventParticipationLevelRepository participationLevelRepo, EventAttendeesRepository eventAttendeesRepository
            , EventMapper eventMapper, ExternalUsersRepository externalUsersRepo, JdbcTemplate jdbcTemplate) {
        this.response = response;
        this.eventTypesRepository = eventTypesRepository;
        this.eventTypeDetailRepository = eventTypeDetailRepository;
        this.eventsRepository = eventsRepository;
        this.participationLevelRepo = participationLevelRepo;
        this.eventAttendeesRepository = eventAttendeesRepository;
        this.eventMapper = eventMapper;
        this.externalUsersRepo = externalUsersRepo;
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public ResponseEntity<Object> getEventTypes() {
        try {
            List<EventTypes> eventType = eventTypesRepository.findAll (Sort.by (Sort.Direction.ASC, "eventTypeDescription"));
            List<EventTypeDetail> eventTypeDetails = eventTypeDetailRepository.findAll ();

            List<EventTypesModel> detailsModel = new ArrayList<> ();
            for (EventTypes eventTypes : eventType) {

                List<EventTypeDetailModel> matchingDetails = eventTypeDetails.stream ()
                        .filter (detail -> detail.getEventType ().getEventTypeID ().equals (eventTypes.getEventTypeID ()))
                        .map (detail -> {
                            return new EventTypeDetailModel (detail.getEventTypeDetailID (), detail.getEventTypeDetail ());
                        })
                        .toList ();

                EventTypesModel model = new EventTypesModel (eventTypes.getEventTypeID (), eventTypes.getEventTypeDescription (), !matchingDetails.isEmpty (),
                        matchingDetails);

                detailsModel.add (model);
            }
            response.setStatus (true);
            response.setData (detailsModel);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);


        } catch (Exception e) {
            return catchException ("getEventtypes()", e, "Failed", "Unable to get event types");
        }
    }

    @Override
    public ResponseEntity<Object> getEmployeeList() {

        try {

            List<EmployeeDetails> emp = SqlConnectionSetup.getJdbcConnection ().query ("Exec spOrganizationChartDetails 1"
                    , BeanPropertyRowMapper.newInstance (EmployeeDetails.class));

            List<OrganizationChart> organizationCharts = new ArrayList<> ();
            Map<String, Map<String, List<EmployeeDetails>>> countryMap = new HashMap<> ();

            for (EmployeeDetails employee : emp) {
                String country = employee.getCountry ();
                String departmentName = employee.getDepartmentName ();

                countryMap
                        .computeIfAbsent (country, k -> new HashMap<> ())
                        .computeIfAbsent (departmentName, k -> new ArrayList<> ())
                        .add (employee);
            }

            // Convert map to list of OrganizationChart objects
            for (Map.Entry<String, Map<String, List<EmployeeDetails>>> countryEntry : countryMap.entrySet ()) {
                OrganizationChart orgChart = new OrganizationChart ();
                orgChart.setCountry (countryEntry.getKey ());

                List<DepartmentName> departments = new ArrayList<> ();
                for (Map.Entry<String, List<EmployeeDetails>> departmentEntry : countryEntry.getValue ().entrySet ()) {
                    DepartmentName department = new DepartmentName ();
                    department.setDepartmentName (departmentEntry.getKey ());
                    department.setEmployees (departmentEntry.getValue ());
                    departments.add (department);
                }

                orgChart.setDepartments (departments);
                orgChart.sortOrganizationChart ();
                organizationCharts.add (orgChart);
            }

            response.setStatus (true);
            response.setData (organizationCharts);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);


        } catch (Exception e) {
            return catchException ("getEmployeeList()", e, "Failed", "Unable to get employee list");
        }
    }

    @Override
    public ResponseEntity<Object> getParticipationLevel() {
        try {
            List<ParticipationLevelDTO> eventParticipationLevels = participationLevelRepo.GetAllOrderByParticipationLevelAsc ();

            response.setStatus (true);
            response.setData (eventParticipationLevels);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException ("getParticipationLevel()", e, "Failed", "Unable to get participation list");
        }
    }

    @Override
    public ResponseEntity<Object> getExternalAttendees() {
        return null;
    }

    @Override
    public ResponseEntity<Object> getContinousEducationReport(EventFilterModel eventFilterModel) {
        try {
            List<ContinousEducationDetails> continousEducationDetails = SqlConnectionSetup.getJdbcConnection ().query ("exec getContinousEducationReport ?,?,?;"
                    , BeanPropertyRowMapper.newInstance (ContinousEducationDetails.class),
                    eventFilterModel.getEmployeeId (),
                    eventFilterModel.getFromdate (),
                    eventFilterModel.getToDate ());

            response.setStatus (true);
            response.setData (continousEducationDetails);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException ("getContinousEducationReport()", e, "Failed", "Unable to get continous Education details");
        }
    }

    @Override
    public ResponseEntity<Object> recordEvent(EventDTO eventDTO) {
        try {
            Optional<Events> eventDetail = eventsRepository.findEventsByEventStartDateAndEventEndDateAndEventTypeId_EventTypeIDAndEventTypeDetailIDAndEventLocationId (
                    InstantFormatter.InstantFormat (eventDTO.getEventStartDate ()),
                    InstantFormatter.InstantFormat (eventDTO.getEventEndDate ()),
                    eventDTO.getEventTypeID (),
                    eventDTO.getEventTypeDetailID (),
                    eventDTO.getEventLocationId ()
            );
            if (eventDetail.isPresent ()) {
                return catchException ("recordEvent()", null, "Exist", "Event detail already exists");
            } else if (DateValidation.validateDate (eventDTO.getEventStartDate (), eventDTO.getEventEndDate ())) {
                return catchException ("recordEvent()", null, "Invalid date", "Start time should be before end time");
            }

            EventTypes byEventTypeID = eventTypesRepository.findByEventTypeID (eventDTO.getEventTypeID ())
                    .orElseThrow (() -> new IllegalArgumentException ("EventTypeID " + eventDTO.getEventTypeID () + " not found"));

            Events events = new Events ();
            events.setEventTypeId (byEventTypeID);
            events.setEventStartDate (InstantFormatter.InstantFormat (eventDTO.getEventStartDate ()));
            events.setEventEndDate (InstantFormatter.InstantFormat (eventDTO.getEventEndDate ()));
            events.setEventTypeDetailID (eventDTO.getEventTypeDetailID ());
            events.setEventTopic (eventDTO.getEventTopic ());
            events.setEventDescription (eventDTO.getEventDescription ());
            events.setDurationMin (eventDTO.getDurationMin ());
            events.setIsPartOfContinuousEducation (eventDTO.getIsPartOfContinuousEducation ());
            events.setDepartmentID (eventDTO.getDepartmentID ());
            events.setFileName (eventDTO.getFileName ());
            events.setFileImageBinary (eventDTO.getFileImageBinary ());
            events.setCreatedBy (eventDTO.getModifiedBy ());
            events.setCreatedOn (InstantFormatter.InstantFormat (eventDTO.getModifiedOn ()));
            events.setGuestName (eventDTO.getGuestName ());
            events.setDuration (eventDTO.getDuration ());
            events.setEventLocationId (eventDTO.getEventLocationId ());
            Events newEvents = eventsRepository.save (events);

            List<ExternalUsers> dtoToexternalUsers = eventMapper.externalUsersDtoListToEntity (eventDTO.getExternalUsersDTO (), newEvents);

            List<EventAttendees> eventAttendees = eventMapper.eventAttendeesDtoListToEntity (eventDTO.getAttendeeDetailsList (), newEvents.getEventID ());

            externalUsersRepo.saveAll (dtoToexternalUsers);
            HttpStatus savedAllEventAttendees = saveAllEventAttendees (eventAttendees);

            String responseMsg = ObjectUtils.isEmpty (newEvents) ? "Event details not added" : "Event details added successfully";

            if (!savedAllEventAttendees.is2xxSuccessful ()) {
                responseMsg = "Event details added successfully. But attendee details not added .</br> Please try again";
            }

            response.setStatus (true);
            response.setMessage (responseMsg);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("recordEvent()", e, "Failed", "Cannot add new event details");
        }
    }

    @Override
    public ResponseEntity<Object> updateEvent(EventDTO eventDTO, Integer eventId) {
        try {
            Optional<Events> events = eventsRepository.findById (eventId);

            List<EventAttendees> eventAttendeesList = eventAttendeesRepository.findByEventIdOrderByEventAttendeeIDAsc (eventId);

            List<ExternalUsers> externalUsersList = externalUsersRepo.findByEventId_EventIDOrderByExternalUserIDAsc (eventId);

            Integer isExists = eventsRepository.existsByEventDetails (
                    InstantFormatter.InstantFormat (eventDTO.getEventStartDate ()),
                    InstantFormatter.InstantFormat (eventDTO.getEventEndDate ()),
                    eventDTO.getEventTypeID (),
                    eventDTO.getEventTypeDetailID (),
                    Arrays.asList (eventId),
                    eventDTO.getEventLocationId (),
                    eventDTO.getEventTopic ()
            );

            if (isExists > 0) {
                return catchException ("updateEvents()", null, "Exist", "Event detail already exists");
            } else if (events.isEmpty ()) {
                return catchException ("updateEvent()", null, "Not Exist", "Event detail not found");
            } else if (DateValidation.validateDate (eventDTO.getEventStartDate (), eventDTO.getEventEndDate ())) {
                return catchException ("recordEvent()", null, "Invalid date", "Start time should be before end time");
            }

            EventTypes byEventTypeID = eventTypesRepository.findByEventTypeID (eventDTO.getEventTypeID ())
                    .orElseThrow (() -> new IllegalArgumentException ("EventTypeID " + eventDTO.getEventTypeID () + " not found"));

            events.get ().setEventTypeId (byEventTypeID);
            events.get ().setEventStartDate (InstantFormatter.InstantFormat (eventDTO.getEventStartDate ()));
            events.get ().setEventEndDate (InstantFormatter.InstantFormat (eventDTO.getEventEndDate ()));
            events.get ().setEventTypeDetailID (eventDTO.getEventTypeDetailID ());
            events.get ().setEventTopic (eventDTO.getEventTopic ());
            events.get ().setEventDescription (eventDTO.getEventDescription ());
            events.get ().setDurationMin (eventDTO.getDurationMin ());
            events.get ().setIsPartOfContinuousEducation (eventDTO.getIsPartOfContinuousEducation ());
            events.get ().setDepartmentID (eventDTO.getDepartmentID ());
            events.get ().setFileName (eventDTO.getFileName ());
            events.get ().setFileImageBinary (eventDTO.getFileImageBinary ());
            events.get ().setModifiedBy (eventDTO.getModifiedBy ());
            events.get ().setModifiedOn (InstantFormatter.InstantFormat (eventDTO.getModifiedOn ()));
            events.get ().setGuestName (eventDTO.getGuestName ());
            events.get ().setDuration (eventDTO.getDuration ());
            events.get ().setEventLocationId (eventDTO.getEventLocationId ());

            Events newEvents = eventsRepository.save (events.get ());

            ResponseEntity<Object> areListsEqualByEventAttendeeID = areListsEqualByEventAttendeeID (eventDTO.getAttendeeDetailsList (), eventAttendeesList, eventId);

            ResponseEntity<Object> areListsEqualByExternalUserID = areListsEqualByExternalUserID (eventDTO.getExternalUsersDTO (), externalUsersList, events.get ());

            response.setStatus (true);
            response.setMessage ("Event details updated successfully");
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("updateEvent()", e, "Failed", "Cannot edit event details");
        }
    }

    @Override
    public ResponseEntity<Object> deleteEvent(EventDetails eventDetails) {
        try {
            Optional<Events> events = eventsRepository.findById (eventDetails.EventId ());
            if (events.isEmpty ()) {
                return catchException ("deleteEvents()", null, "Not found", "No value present");
            }

            int updated = eventsRepository.updateModifiedByAndModifiedOnByEventID
                    (eventDetails.modifiedBy (),
                            InstantFormatter.InstantFormat (eventDetails.modifiedDate ()),
                            eventDetails.EventId ());

            int eventAttendeeById = eventAttendeesRepository.deleteByEventId (eventDetails.EventId ());
            int externalUserById = externalUsersRepo.deleteByEventId (events.get ());
            int deleteByEventID = eventsRepository.deleteByEventID (eventDetails.EventId ());

            response.setStatus (true);
            response.setMessage (deleteByEventID <= 0 ? "Event not deleted" : "Event details deleted successfully");
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("deleteEvents()", e, "Failed", "Cannot delete event details");
        }
    }

    @Override
    public ResponseEntity<Object> viewEvent(EventFilterModel eventFilterModel) {
        try {
            List<ViewEvents> eventsList = SqlConnectionSetup.getJdbcConnection ().query ("exec spGetEventDetails ? ,? ,? ,?, ?, ?;"
                    , BeanPropertyRowMapper.newInstance (ViewEvents.class)
                    , eventFilterModel.getEmployeeId ()
                    , eventFilterModel.getFromdate ()
                    , eventFilterModel.getToDate ()
                    , eventFilterModel.getEventTypeId ()
                    , eventFilterModel.getEventKeyword ()
                    , eventFilterModel.getKeyword ());

            response.setStatus (true);
            response.setData (eventsList);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("viewEvent()", e, "Failed", "unable to view event details");
        }
    }

    @Override
    public ResponseEntity<Object> getEventByEventId(Integer eventId) {
        try {
            Optional<Events> events = eventsRepository.findById (eventId);

            if (events.isEmpty ()) {
                return catchException ("getEventByEventId()", null, "Failed", "No value present");
            }

            List<EventAttendeeView> eventAttendeesList = SqlConnectionSetup.getJdbcConnection ().query ("exec spGetEventAttendeeDetails ?;",
                    BeanPropertyRowMapper.newInstance (EventAttendeeView.class),
                    eventId);

            List<ExternalUsers> externalUsersList = externalUsersRepo.findByEventId_EventIDOrderByExternalUserIDAsc (eventId);

            EventDTO eventDTO = new EventDTO ();

            eventDTO.setEventId (eventId);
            eventDTO.setEventTypeID (events.get ().getEventTypeId ().getEventTypeID ());
            eventDTO.setEventStartDate (InstantFormatter.InstantFormat (events.get ().getEventStartDate ()));
            eventDTO.setEventEndDate (InstantFormatter.InstantFormat (events.get ().getEventEndDate ()));
            eventDTO.setEventTypeDetailID (events.get ().getEventTypeDetailID ());
            eventDTO.setEventTopic (events.get ().getEventTopic ());
            eventDTO.setEventDescription (events.get ().getEventDescription ());
            eventDTO.setDurationMin (events.get ().getDurationMin ());
            eventDTO.setIsPartOfContinuousEducation (events.get ().getIsPartOfContinuousEducation ());
            eventDTO.setDepartmentID (events.get ().getDepartmentID ());
            eventDTO.setFileName (events.get ().getFileName ());
            eventDTO.setFileImageBinary (events.get ().getFileImageBinary ());
            eventDTO.setAttendeeDetailsDTO (eventAttendeesList);
            eventDTO.setExternalUsersDTO (eventMapper.externalUsersListToDto (externalUsersList));
            eventDTO.setGuestName (events.get ().getGuestName ());
            eventDTO.setDuration (events.get ().getDuration ());
            eventDTO.setEventLocationId (events.get ().getEventLocationId ());

            response.setStatus (true);
            response.setData (eventDTO);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("getEventByEventId()", e, "Failed", "Unable to get event details");
        }
    }

    @Override
    public ResponseEntity<Object> getEventKeyWordType() {
        try {
            List<EventKeyWordType> keywordType = Arrays.asList (EventKeyWordType.values ());

            response.setStatus (true);
            response.setData (keywordType);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException ("getEventKeyWordType()", e, "Failed", "Unable to get event KeyWord details");
        }
    }

    @Override
    public ResponseEntity<Object> getReportCategory() {
        try {
            List<String> reportCategoryList = Arrays.stream (ReportCategory.values ())
                    .map (ReportCategory::getValue)
                    .collect (Collectors.toList ());

            response.setStatus (true);
            response.setData (reportCategoryList);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException ("getReportCategory()", e, "Failed", "Unable to get event report category details");
        }
    }

    @Override
    public ResponseEntity<Object> getEventReports(ReportFilter reportFilter) {
        try {
            List<Object> eventReport = new ArrayList ();
            ReportCategory reportCategory = ReportCategory.getEnumFromString (reportFilter.getReportCategory ());
            switch (reportCategory) {
                case GENERATE_REPORT:
                    eventReport = SqlConnectionSetup.getJdbcConnection ().query ("exec GetContinousEducationReport ?,?,?,?;",
                            new ResultSetMapper (), reportFilter.getEmployeeId (), reportFilter.getFromDate (), reportFilter.getToDate ()
                            , reportFilter.getLocationId ());
                    response.setData (eventReport);
                    break;

                case GENERATE_DETAILS:
                    eventReport = SqlConnectionSetup.getJdbcConnection ().query ("exec GetASHIContEduDetails ?,?,?,?,?;",
                            new ResultSetMapper (),
                            reportFilter.getReportType (),
                            reportFilter.getEmployeeId (),
                            reportFilter.getFromDate (),
                            reportFilter.getToDate (),
                            reportFilter.getLocationId ());
                    response.setData (eventReport);
                    break;

                case GENERATE_SUMMARY:

                    List<Object> employeeDetail = SqlConnectionSetup.getJdbcConnection ().query ("exec GetEmpHeeaderDetailsForCE ?;",
                            new ResultSetMapper (),
                            reportFilter.getEmployeeId ());

                    List<Object> summaryTableValues = SqlConnectionSetup.getJdbcConnection ().query ("exec GetASHISummaryByContactHrs ?,?,?;",
                            new ResultSetMapper (),
                            reportFilter.getEmployeeId (),
                            reportFilter.getFromDate (),
                            reportFilter.getToDate ());

                    List<Object> summaryDetails = SqlConnectionSetup.getJdbcConnection ().query ("exec GetASHIContEduSummary ?,?,?;",
                            new ResultSetMapper (),
                            reportFilter.getEmployeeId (),
                            reportFilter.getFromDate (),
                            reportFilter.getToDate ());

                    Map<String, List<Object>> continousEducationSummary = new HashMap<> ();

                    continousEducationSummary.put ("EmployeeDetail", employeeDetail);
                    continousEducationSummary.put ("TableContent", summaryTableValues);
                    continousEducationSummary.put ("Summary", summaryDetails);

                    response.setData (continousEducationSummary);

//                default -> {
//                        return catchException("getEventReports()", null, "Invalid report category", "Please select valid report category");
//                    }

            }
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException ("getEventReports()", e, "Failed", "Unable to get event report details");
        }
    }

    @Override
    public ResponseEntity<Object> getFacilityPersonnelReport() {
        try {
            List<FacilityPersonnelReport> facilityPersonnelData = SqlConnectionSetup.getJdbcConnection ()
                    .query ("exec GetFacilityPersonnelData", BeanPropertyRowMapper.newInstance (FacilityPersonnelReport.class));

            response.setData (facilityPersonnelData);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("getFacilityPersonnelReport()", e, "Failed", "Unable to get staff facility personnel report");
        }
    }

    @Override
    public ResponseEntity<Object> getEventLogDetailsById(Integer eventId) {
        try {
            List<Object> eventLogDetails = SqlConnectionSetup.getJdbcConnection ()
                    .query ("exec spGetEventLogDetailsValue ?;", new ResultSetMapper ()
                            , eventId);

            response.setData (eventLogDetails);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("getEventLogDetailsById()", e, "Failed", "Unable to get event log details");
        }
    }

    @Override
    public ResponseEntity<Object> getEventSummaryDetails(ReportFilter reportFilter) {
        try {
            List<EventSummaryDetails> eventLogDetails = SqlConnectionSetup.getJdbcConnection ()
                    .query ("exec GetReportSummaryDetails ?,?,?,?,?;", BeanPropertyRowMapper.newInstance (EventSummaryDetails.class)
                            , reportFilter.getEmployeeId ()
                            , reportFilter.getFromDate ()
                            , reportFilter.getToDate ()
                            , reportFilter.getReportCategory ()
                            , reportFilter.getReportType ());

            response.setData (eventLogDetails);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("getEventSummaryDetails()", e, "Failed", "Unable to get event summary details");
        }
    }


    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
        logger.error ("{} Error : {}" + methodName, e);
        response.setStatus (false);
        response.setInformation (new ExceptionBean (Instant.now (), message, description));
        mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"information", STATUS});
        return new ResponseEntity<> (mappingJacksonValue, HttpStatus.CONFLICT);
    }

    public ResponseEntity<Object> areListsEqualByEventAttendeeID(List<EventAttendeeDTO> dtoList, List<EventAttendees> attendeesList, Integer eventId) {
        try {

            List<Integer> attendeeIdsToDelete = dtoList.stream ()
                    .map (EventAttendeeDTO::getEventAttendeeID)
                    .distinct ()
                    .collect (Collectors.toList ());

            int deleted = eventAttendeesRepository.deleteByEventAttendeeIDNotInAndEventId (attendeeIdsToDelete, eventId);

            // Find new attendees to add
            List<EventAttendeeDTO> newAttendeesDTOs = dtoList.stream ()
                    .filter (dto -> dto.getEventAttendeeID () == 0)
                    .collect (Collectors.toList ());

            // Convert new attendees DTOs to entities and save them
            List<EventAttendees> newAttendees = eventMapper.eventAttendeesDtoListToEntity (newAttendeesDTOs, eventId);
            saveAllEventAttendees (newAttendees);

            response.setStatus (true);
            response.setMessage ("EventAttendee details updated");
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException ("areListsEqualByEventAttendeeID()", e, "Failed", "Unable to validate event details");
        }
    }

    public ResponseEntity<Object> areListsEqualByExternalUserID(List<ExternalUsersDTO> dtoList, List<ExternalUsers> externalUsersList, Events events) {
        try {

            Map<Integer, ExternalUsersDTO> dtoMap = dtoList.stream ()
                    .filter (id -> id.getExternalUserID () != 0)
                    .collect (Collectors.toMap (ExternalUsersDTO::getExternalUserID, Function.identity ()));
            Map<Integer, ExternalUsers> externalUsersMap = externalUsersList.stream ()
                    .collect (Collectors.toMap (ExternalUsers::getExternalUserID, Function.identity ()));

            int count = 0;


            //delete external attendee record
            externalUsersMap.values ().stream ()
                    .filter (attendee -> !dtoMap.containsKey (attendee.getExternalUserID ()))
                    .forEach (externalUsersRepo::delete);

            List<ExternalUsersDTO> externalUsersDTOS = dtoList.stream ()
                    .filter (dto -> !externalUsersMap.containsKey (dto.getExternalUserID ()))
                    .toList ();
            List<ExternalUsers> externalUsers = eventMapper.externalUsersDtoListToEntity (externalUsersDTOS, events);

            externalUsersRepo.saveAll (externalUsers);

            for (Integer id : dtoMap.keySet ()) {
                if (externalUsersMap.containsKey (id) && !externalUserObjectsEqual (dtoMap.get (id), externalUsersMap.get (id))) {
                    ExternalUsers updatedExternalUsersFromDTO = eventMapper
                            .updateExternalUsersFromDTO (dtoMap.get (id), externalUsersMap.get (id), events);
                    externalUsersRepo.save (updatedExternalUsersFromDTO);
                    count++;
                }
            }
            response.setStatus (true);
            response.setMessage (count >= 0 ? "External user details updated" : "No change");
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("areListsEqualByExternalUserID()", e, "Failed", "Unable to validate external user details");
        }
    }

    private boolean externalUserObjectsEqual(ExternalUsersDTO dto, ExternalUsers entity) {
        return ObjectUtils.equals (dto.getExternalUserID (), entity.getExternalUserID ()) &&
                ObjectUtils.equals (dto.getExternalUserName (), entity.getExternalUserName ()) &&
                ObjectUtils.equals (dto.getEventId (), entity.getEventId ());
    }

    private HttpStatus saveAllEventAttendees(List<EventAttendees> attendees) {
        try {
            String sql = """
                    INSERT INTO EventAttendees(
                    EventID,
                    EventAttendeeType,
                    ParticipationLevelID,
                    EmployeeId)
                    VALUES (?,?,?,?)
                    """;

            jdbcTemplate.batchUpdate (sql, new BatchPreparedStatementSetter () {
                @Override
                public void setValues(PreparedStatement ps, int i) throws SQLException {
                    EventAttendees attendee = attendees.get (i);
                    ps.setInt (1, attendee.getEventId ());
                    ps.setString (2, attendee.getEventAttendeeType ());
                    ps.setInt (3, attendee.getParticipationLevelID ());
                    ps.setInt (4, attendee.getEmployeeId ());
                }

                @Override
                public int getBatchSize() {
                    return attendees.size ();
                }
            });
            return HttpStatus.OK;
        } catch (Exception e) {
            logger.error ("{} Error : {}", "saveAllEventAttendees", e);
            return HttpStatus.CONFLICT;
        }

    }
}
