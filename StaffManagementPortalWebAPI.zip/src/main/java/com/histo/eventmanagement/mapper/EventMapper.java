package com.histo.eventmanagement.mapper;

import com.histo.eventmanagement.dto.EventAttendeeDTO;
import com.histo.eventmanagement.dto.ExternalUsersDTO;
import com.histo.eventmanagement.entity.EventAttendees;
import com.histo.eventmanagement.entity.Events;
import com.histo.eventmanagement.entity.ExternalUsers;
import com.histo.eventmanagement.model.ViewEvents;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = "spring")
public interface EventMapper {

    EventMapper INSTANCE = Mappers.getMapper (EventMapper.class);

    EventAttendeeDTO eventAttendeesToDto(EventAttendees eventAttendees);
    @Mapping(expression = "java(eventId)", target = "eventId" )
    EventAttendees eventAttendeesDtoToEntity(EventAttendeeDTO eventAttendeeDTO, @Context Integer eventId);

    List<EventAttendeeDTO> eventAttendeesListToDto(List<EventAttendees> eventAttendees);

    List<EventAttendees> eventAttendeesDtoListToEntity(List<EventAttendeeDTO> eventAttendeesDto, @Context Integer eventId);

    @Mapping(source = "eventId.eventID", target = "eventId")
    ExternalUsersDTO externalUsersToDto(ExternalUsers externalUsers);

    @Mapping(expression = "java(events)", target = "eventId" )
    ExternalUsers externalUsersDtoToEntity(ExternalUsersDTO externalUsersDTO,@Context  Events events);

    List<ExternalUsersDTO> externalUsersListToDto(List<ExternalUsers> externalUsers);

    List<ExternalUsers> externalUsersDtoListToEntity(List<ExternalUsersDTO> externalUsersDTO,@Context Events events);

// update mappers
    EventAttendees updateEventAttendeesFromDTO(EventAttendeeDTO dto, @MappingTarget EventAttendees entity);

    @Mapping(expression = "java(events)", target = "eventId" )
    ExternalUsers updateExternalUsersFromDTO(ExternalUsersDTO dto, @MappingTarget ExternalUsers entity,@Context Events events);

}

