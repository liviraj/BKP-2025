package com.histo.eventmanagement.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Column;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "EventContent")
@Data
@NoArgsConstructor
public class EventContent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EventContentID")
    private Integer eventContentID;

    @Column(name = "EventContent")
    private byte[] eventContent;

    @Column(name = "EventContentFileName")
    private String eventContentFileName;

    @Column(name = "EventContentFileNameExtn")
    private String eventContentFileNameExtn;

    @ManyToOne
    @JoinColumn(name = "EventID", referencedColumnName = "EventID", nullable = false)
    private Events event;

}

