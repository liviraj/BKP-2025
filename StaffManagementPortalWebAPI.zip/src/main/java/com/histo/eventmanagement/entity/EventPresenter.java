package com.histo.eventmanagement.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "EventPresenter")
@Data
@NoArgsConstructor
public class EventPresenter {

    @Id
    @Column(name = "EventPresenterID")
    private Integer eventPresenterID;

    @ManyToOne
    @JoinColumn(name = "EventID", referencedColumnName = "EventID", nullable = false)
    private Events event;

    @Column(name = "EventPresenterType")
    private char eventPresenterType;

    @ManyToOne
    @JoinColumn(name = "ParticipationLevelID", referencedColumnName = "ParticipationLevelID", nullable = false)
    private EventParticipationLevel participationLevel;

}
