package com.histo.eventmanagement.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

@Entity
@Table(name = "EventAttendees")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class EventAttendees {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EventAttendeeID")
    private Integer eventAttendeeID;

    @Column(name = "EventID")
    private Integer eventId;

    @Column(name = "EmployeeId", nullable = false)
    private Integer employeeId;

    @Column(name = "EventAttendeeType")
    private String eventAttendeeType;

    @Column(name = "ParticipationLevelID")
    private Integer participationLevelID;


}


