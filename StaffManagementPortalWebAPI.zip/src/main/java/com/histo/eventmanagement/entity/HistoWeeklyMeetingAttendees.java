package com.histo.eventmanagement.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Entity
@Table(name = "HistoWeeklyMeetingAttendees")
@Data
@NoArgsConstructor
public class HistoWeeklyMeetingAttendees {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EmployeeID")
    private Integer employeeID;

    @Column(name = "FirstName", nullable = false, length = 25)
    private String firstName;

    @Column(name = "MiddleName", length = 25)
    private String middleName;

    @Column(name = "LastName", nullable = false, length = 25)
    private String lastName;

    @Column(name = "Gender", nullable = false, length = 1)
    private char gender;

    @Column(name = "Pan_Ssn", length = 1)
    private char panSsn;

    @Column(name = "Pan_Ssn_Number", length = 50)
    private String panSsnNumber;

    @Column(name = "Dob", nullable = false)
    private Instant dob;

    @Column(name = "Fathername", nullable = false, length = 50)
    private String fatherName;

    @Column(name = "Mothername", nullable = false, length = 50)
    private String motherName;

    @Column(name = "Maritalstatus", nullable = false, length = 50)
    private String maritalStatus;

    @Column(name = "Spousename", length = 50)
    private String spouseName;

    @Column(name = "Childnos", precision = 18, scale = 0)
    private Integer childNos;

    @Column(name = "Childname", length = 50)
    private String childName;

    @Column(name = "ModifiedBy", nullable = false)
    private Integer modifiedBy;

    @Column(name = "ModifiedDate", nullable = false)
    private Instant modifiedDate;

    @Column(name = "RecordStatus", nullable = false, length = 1)
    private char recordStatus;

    @Column(name = "Image", length = 4000)
    private String image;

    @Column(name = "Nationality", nullable = false, length = 25)
    private String nationality;

    @Column(name = "PassportNo", length = 25)
    private String passportNo;

    @Column(name = "IssuePlace", length = 25)
    private String issuePlace;

    @Column(name = "IssueDate")
    private Instant issueDate;

    @Column(name = "ExpiryDate")
    private Instant expiryDate;

    @Column(name = "IdProofImg", length = 500)
    private String idProofImg;

    @Column(name = "EmployeeCode", nullable = false, length = 50)
    private String employeeCode;

    @Column(name = "TimePunchId", length = 20)
    private String timePunchId;

    @Column(name = "PassportImage", length = 4000)
    private String passportImage;

    @Lob
    @Column(name = "PhotoImageBinary")
    private byte[] photoImageBinary;

    @Lob
    @Column(name = "IdProofImageBinary")
    private byte[] idProofImageBinary;

    @Lob
    @Column(name = "PassportImageBinary")
    private byte[] passportImageBinary;

}
