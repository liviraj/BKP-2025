package com.histo.eventmanagement.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "ExternalUsers")
@Data
public class ExternalUsers {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ExternalUserID")
    private Integer externalUserID;

    @Column(name = "ExternalUserName", nullable = true)
    private String externalUserName;

    @ManyToOne
    @JoinColumn(name = "EventID", referencedColumnName = "EventID", nullable = false)
    private Events eventId;

}
