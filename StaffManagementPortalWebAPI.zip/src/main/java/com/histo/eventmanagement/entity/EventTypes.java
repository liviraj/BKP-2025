package com.histo.eventmanagement.entity;

import lombok.*;

import javax.persistence.*;

@Entity
@Table(name = "EventTypes")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class EventTypes {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EventTypeID")
    private Integer eventTypeID;

    @Column(name = "EventTypeDescription")
    private String eventTypeDescription;

}
