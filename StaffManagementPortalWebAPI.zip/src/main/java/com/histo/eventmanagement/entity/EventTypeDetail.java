package com.histo.eventmanagement.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "EventTypeDetail")
@Data
@NoArgsConstructor
public class EventTypeDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EventTypeDetailID")
    private Integer eventTypeDetailID;

    @Column(name = "EventTypeDetail")
    private String eventTypeDetail;

    @ManyToOne
    @JoinColumn(name = "EventTypeID", referencedColumnName = "EventTypeID", nullable = false)
    private EventTypes eventType;

}

