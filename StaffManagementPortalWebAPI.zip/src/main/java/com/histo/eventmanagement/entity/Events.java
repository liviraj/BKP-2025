package com.histo.eventmanagement.entity;

import com.histo.staffmanagementportal.util.InstantConverter;
import lombok.*;

import javax.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "Events")
@Data
public class Events {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EventID")
    private Integer eventID;

    @Column(name = "EventStartDate")
    private Instant eventStartDate;

    @Column(name = "EventEndDate")
    private Instant eventEndDate;

    @ManyToOne
    @JoinColumn(name = "EventTypeID", referencedColumnName = "EventTypeID", nullable = false)
    private EventTypes eventTypeId;

    @Column(name = "EventTypeDetailID")
    private Integer eventTypeDetailID;

    @Column(name = "EventTopic", nullable = false, length = 100)
    private String eventTopic;

    @Column(name = "EventDescription", length = 6000)
    private String eventDescription;

    @Column(name = "DurationMin", nullable = false)
    private Integer durationMin;

    @Column(name = "IsPartOfContinousEducation", nullable = false)
    private String isPartOfContinuousEducation;

    @Column(name = "DepartmentID")
    private Integer departmentID;

    @Column(name = "modifiedOn")
    @Convert(converter = InstantConverter.class)
    private Instant modifiedOn;

    @Column(name = "fileName")
    private String fileName;

    @Column(name = "fileImageBinary")
    private byte[] fileImageBinary;

    @Column(name = "createdOn")
    @Convert(converter = InstantConverter.class)
    private Instant createdOn;

    @Column(name = "createdBy")
    private Integer createdBy;

    @Column(name = "modifiedBy")
    private Integer modifiedBy;

    @Column(name = "guestName")
    private String guestName;

    @Column(name = "duration")
    private String duration;

    @Column(name = "eventLocationId")
    private Integer eventLocationId;

}
