package com.histo.eventmanagement.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "EventParticipationLevel")
@Data
@NoArgsConstructor
public class EventParticipationLevel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "participationLevelID", nullable = false)
    private Integer id;

    @Column(name = "participationLevel")
    private String participationLevel;

}
