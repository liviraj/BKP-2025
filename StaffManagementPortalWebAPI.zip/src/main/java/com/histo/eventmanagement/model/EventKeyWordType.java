package com.histo.eventmanagement.model;

public enum EventKeyWordType {

    Type("Type"),
    Topic("Topic"),
    Description("Description");
    private String value;
    public String getValue() {
        return value;
    }
    EventKeyWordType(String value) {
        this.value = value;
    }
}
