package com.histo.eventmanagement.model;

public record EventDetails(Integer modifiedBy,String modifiedDate,Integer EventId) {
}
