package com.histo.eventmanagement.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EventAttendeeView {

    private Integer eventId;
    private Integer employeeId;
    private Integer participationLevelID;
    private String eventAttendeeType;
    private Integer eventAttendeeID;
    private String employeeName;
}
