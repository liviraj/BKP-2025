package com.histo.eventmanagement.model;

import lombok.Data;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import java.util.List;

@Data
public class OrganizationChart {
    private String country;
    private List<DepartmentName> departments;

    public void sortOrganizationChart() {
        // Sort departments by departmentName
        departments.sort(Comparator.comparing(DepartmentName::getDepartmentName));

        // Sort employees within each department by employeeId
        for (DepartmentName department : departments) {
            department.getEmployees().sort(Comparator.comparing(EmployeeDetails::getEmployeeName));
        }
    }

}

