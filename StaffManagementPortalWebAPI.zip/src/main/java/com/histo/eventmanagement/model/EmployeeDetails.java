package com.histo.eventmanagement.model;

import lombok.Data;

@Data
public class EmployeeDetails {

    private Integer departmentId;
    private Integer employeeId;
    private String employeeName;
    private Integer locationId;
    private String departmentName;
    private String isSupervisor;
    private String country;
}
