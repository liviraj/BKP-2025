package com.histo.eventmanagement.model;

import lombok.Data;

@Data
public class ViewEvents {

     private Integer eventID;
     private String eventStartDate;
     private String eventEndDate;
     private String isPartOfContinousEducation;
     private String eventType;
     private String eventTypeDetails;
     private String eventTopic;
     private String eventDescription;
     private String durationMin;
     private String createdBy;
     private String createdDate;
     private Integer createdByEmpId;

}
