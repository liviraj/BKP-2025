package com.histo.eventmanagement.model;

public enum EventsEnum {

    STUDENTS("Students"),
    INTERN("Intern"),
    EMPLOYEE("Staff");
    private String value;
    public String getValue() {
        return value;
    }
    EventsEnum(String value) {
        this.value = value;
    }
}
