package com.histo.eventmanagement.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FacilityPersonnelReport {

    private String lastName;
    private String firstName;
    private String qualification;
    private String majorSubject;
    private String courseEndDate;
    private String dateofJoin;
    private String relievingDate;
    private String DOJ;
    private String designationName;
    private String departmentName;
    private String shift1;
    private String shift2;
    private String shift3;
    private String shift;
    private String hrs;
    private String appr;
    private String comments;
    private String reviewedBy;
    private String reviewDate;
    private String yrsExp;

}
