package com.histo.eventmanagement.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EventFilterModel {

    private Integer employeeId;
    private String fromdate;
    private String toDate;
    private String eventKeyword;
    private String keyword;
    private Integer eventTypeId;
}
