package com.histo.eventmanagement.model;

import java.util.List;

public record EventTypesModel(

     Integer eventTypeId ,
     String eventTypeDescription,
    Boolean isPresentTypeDetails,
    List<?> eventTypeDetails){
}
