package com.histo.eventmanagement.model;

public record EventTypeDetailModel(  Integer eventTypeDetailId ,
                                     String eventTypeDetailDescription) {
}
