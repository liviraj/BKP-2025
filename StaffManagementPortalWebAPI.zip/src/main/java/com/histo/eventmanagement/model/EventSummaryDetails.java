package com.histo.eventmanagement.model;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class EventSummaryDetails {
    private int eventID;
    private String eventStartDate;
    private String eventEndDate;
    private String eventTopic;
    private String eventDescription;
    private float durationMin;
    private float durationInHrs;
    private int partHrs;
    private boolean isPartOfContinousEducation;
    private String fileName;
    private byte[] fileImageBinary;
    private String program;
    private String partLevel;
}

