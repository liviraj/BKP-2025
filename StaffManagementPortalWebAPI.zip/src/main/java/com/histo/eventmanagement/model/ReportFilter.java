package com.histo.eventmanagement.model;

import lombok.Data;

@Data
public class ReportFilter {

    private String reportType;
    private String fromDate;
    private String toDate;
    private Integer employeeId;
    private String reportCategory;
    private Integer locationId;
}
