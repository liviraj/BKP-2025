package com.histo.eventmanagement.model;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class EventLogDetails {

    private String eventLogId;
    private String eventId;
    private String eventStartDate;
    private String eventEndDate;
    private String eventType;
    private String eventTopic;
    private String lastModifiedBy;
    private String lastModifiedDate;
    private String modifiedColumn;


}
