package com.histo.eventmanagement.model;

import lombok.Data;

import java.util.List;

@Data
public class DepartmentName {
    private String departmentName;
    private List<EmployeeDetails> employees;
}
