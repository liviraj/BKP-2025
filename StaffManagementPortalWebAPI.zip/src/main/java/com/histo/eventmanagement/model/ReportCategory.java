package com.histo.eventmanagement.model;

import com.histo.staffmanagementportal.model.LocationEum;

public enum ReportCategory {

    GENERATE_REPORT("Generate Report"),
    GENERATE_DETAILS("Generate Details"),
    GENERATE_SUMMARY("Generate Summary");
    private String value;

    public String getValue() {
        return value;
    }

    ReportCategory(String value) {
        this.value = value;
    }

    public static ReportCategory getEnumFromString(String text) {
        for (ReportCategory category : ReportCategory.values()) {
            if (category.value.equalsIgnoreCase ( text)) {
                return category;
            }

        }
        return null;
    }
}
