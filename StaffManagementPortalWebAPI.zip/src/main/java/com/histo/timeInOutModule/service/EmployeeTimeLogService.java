package com.histo.timeInOutModule.service;

import com.histo.timeInOutModule.model.EmployeeTimeLogDTO;
import com.histo.indiapayroll.model.PayRollFilterModel;
import com.histo.timeInOutModule.model.TimeSheetDocumentsDTO;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface EmployeeTimeLogService {

    ResponseEntity<Object> addEmployeeTimeInOutDetails(List<EmployeeTimeLogDTO> employeeTimeLogDTO);
    ResponseEntity<Object> editEmployeeTimeInOutDetails(List<EmployeeTimeLogDTO> employeeTimeLogDTOS);
    ResponseEntity<Object> fetchEmployeeTimeInOutDetails(PayRollFilterModel payRollFilterModel);

    ResponseEntity<Object> getEmployeeTimeInOutDetails(PayRollFilterModel payRollFilterModel);

    ResponseEntity<Object> getTimeInOutSummaryDetails(PayRollFilterModel payRollFilterModel);

    ResponseEntity<Object> getEmployeeTimeInOutSummaryDetails(PayRollFilterModel payRollFilterModel);

    ResponseEntity<Object> getEmployeeTimeSheetDetails(PayRollFilterModel payRollFilterModel);

    ResponseEntity<Object> uploadUsEmployeeTimeInOutDetails(TimeSheetDocumentsDTO timeSheetDocumentsDTO);

    ResponseEntity<Object> getActiveEmployeeCode(PayRollFilterModel payRollFilterModel);
}
