package com.histo.timeInOutModule.service.impl;

import com.histo.timeInOutModule.entity.USEmployeeTimeSheetDetails;
import com.histo.timeInOutModule.entity.TimeSheetDocuments;
import com.histo.timeInOutModule.repository.TimeSheetDocumentsRepository;
import com.opencsv.CSVReader;
import com.histo.configuration.SqlConnectionSetup;
import com.histo.indiapayroll.model.PayRollFilterModel;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.intranet.entity.Holiday;
import com.histo.staffmanagementportal.intranet.entity.PayRollMaster;
import com.histo.staffmanagementportal.intranet.repository.HolidayRepository;
import com.histo.staffmanagementportal.intranet.repository.PayRollMasterRepository;
import com.histo.timeInOutModule.repository.USEmployeeTimeSheetDetailsRepo;
import com.histo.staffmanagementportal.model.LocationEum;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.model.ResultSetMapper;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;
import com.histo.timeInOutModule.entity.EmployeeTimeLog;
import com.histo.timeInOutModule.model.*;
import com.histo.timeInOutModule.repository.EmployeeTimeLogRepository;
import com.histo.timeInOutModule.service.EmployeeTimeLogService;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.DayOfWeek;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class EmployeeTimeLogServiceImpl implements EmployeeTimeLogService {

    private static final Logger logger = LogManager.getLogger(EmployeeTimeLogServiceImpl.class);
    private static final String STATUS = "status";
    private final ResponseModel response;
    private MappingJacksonValue mappingJacksonValue;

    private final EmployeeTimeLogRepository employeeTimeLogRepo;

    private final HolidayRepository holidayRepository;

    private final PayRollMasterRepository payRollMasterRepo;

    private final USEmployeeTimeSheetDetailsRepo usEmployeeTimeSheetDetailsRepo;

    private final TimeSheetDocumentsRepository timeSheetDocumentsRepository;

    public EmployeeTimeLogServiceImpl(ResponseModel response, EmployeeTimeLogRepository employeeTimeLogRepo, HolidayRepository holidayRepository,
                                      PayRollMasterRepository payRollMasterRepo, USEmployeeTimeSheetDetailsRepo usEmployeeTimeSheetDetailsRepo,
                                      TimeSheetDocumentsRepository timeSheetDocumentsRepository) {
        this.response = response;
        this.employeeTimeLogRepo = employeeTimeLogRepo;
        this.holidayRepository = holidayRepository;
        this.payRollMasterRepo = payRollMasterRepo;
        this.usEmployeeTimeSheetDetailsRepo = usEmployeeTimeSheetDetailsRepo;
        this.timeSheetDocumentsRepository = timeSheetDocumentsRepository;
    }


    @Override
    public ResponseEntity<Object> addEmployeeTimeInOutDetails(List<EmployeeTimeLogDTO> employeeTimeLogDTODetails) {
        try{

            Instant workDate = InstantFormatter.InstantFormat (employeeTimeLogDTODetails.get (0).getWorkDate ());

            Optional<Holiday> employeeHoliday = holidayRepository
                    .findHolidayByLocationidAndDate (workDate.toString (), LocationEum.USA.getValue ());

            Boolean isHoliday = employeeHoliday.isPresent ();

            DayOfWeek dayOfWeek = InstantFormatter.getWeek (workDate);

            if (dayOfWeek.equals (DayOfWeek.SUNDAY)
                    || Boolean.TRUE.equals (isHoliday)) {
                return catchException ("addEmployeeCheckInOutDetails",null,"Not Valid date","Selected date is holiday. Please select valid date.");

            }

            for(EmployeeTimeLogDTO employeeTimeLogDTO : employeeTimeLogDTODetails){

                long timeInOutCount = employeeTimeLogRepo.getTimeInOutCount (employeeTimeLogDTO.getEmployeeId (), workDate, employeeTimeLogDTO.getLogType ());

                if(timeInOutCount>=4){
                    return catchException ("addEmployeeCheckInOutDetails",null,"Exceed Maximum count",
                            String.format ("Already taken maximum Time %s for given date.",employeeTimeLogDTO.getLogType ()));
                }

                LoginAction loginAction = LoginAction.getEnumValueFromString (employeeTimeLogDTO.getLogType ());

                Optional<EmployeeTimeLog> latestTimeLog = employeeTimeLogRepo.findFirstByEmployeeIdAndWorkDateOrderByLogIdDesc (employeeTimeLogDTO.getEmployeeId (),workDate);

                Instant logTime = InstantFormatter.InstantFormat (employeeTimeLogDTO.getLogTime ());

                switch(loginAction){

                    case TIME_IN -> {

                        if(latestTimeLog.isPresent ()){

                            FormattedDetails formattedDetails = employeeTimeLogRepo.findByLogId (latestTimeLog.get ().getLogId ())
                                    .orElseThrow (() -> new IllegalArgumentException ("Unable to get format datetime for Time logId " + latestTimeLog.get ().getLogId () ));

                            if(latestTimeLog.get ().getLogType ().equalsIgnoreCase (LoginAction.TIME_IN.getValue ())){
                                return catchException ("addEmployeeCheckInOutDetails",null,"Failed",
                                        String.format ("Please add Time Out details for %s", formattedDetails.getFormattedTime ()));
                            }
                            else if(latestTimeLog.get ().getLogTime ().isAfter (logTime)){
                                return catchException ("addEmployeeCheckInOutDetails",null,"Failed",
                                        String.format ("Given Time In should not be before time out %s.Please add valid Time In details for date.",
                                                formattedDetails.getFormattedTime ()));
                            }
                        }

                    }
                    case TIME_OUT -> {

                        if(latestTimeLog.isEmpty ()){
                            return catchException ("addEmployeeCheckInOutDetails",null,"Failed","Please add In Time details for given date and try adding time Out details.");
                        }

                        FormattedDetails formattedDetails = employeeTimeLogRepo.findByLogId (latestTimeLog.get ().getLogId ())
                                .orElseThrow (() -> new IllegalArgumentException ("Unable to get format datetime for Time logId " + latestTimeLog.get ().getLogId () ));

                        if(latestTimeLog.get ().getLogType ().equalsIgnoreCase (LoginAction.TIME_OUT.getValue ())){
                            return catchException ("addEmployeeCheckInOutDetails",null,"Failed","Please add In Time details for given date.");
                        }
                        else if(latestTimeLog.get ().getLogType ().equalsIgnoreCase (LoginAction.TIME_IN.getValue ())
                                && !latestTimeLog.get ().getWorkDate ().equals (workDate)){
                            return catchException ("addEmployeeCheckInOutDetails",null,"Failed",
                                    String.format ("Please add Time Out details for %s and try to add Time In details for given date.",formattedDetails.getFormattedTime ()));
                        }
                        else if(latestTimeLog.get ().getLogTime ().isAfter (logTime)){
                            return catchException ("addEmployeeCheckInOutDetails",null,"Failed",
                                    String.format ("Given Time Out should be after time In %s .Please add valid Time out details for date.",formattedDetails.getFormattedTime ()));
                        }

                    }
                    default -> {return catchException ("addEmployeeCheckInOutDetails",null,"Failed","please select valid log action.");}
                }

                EmployeeTimeLog employeeTimeLog = new EmployeeTimeLog ();

                employeeTimeLog.setEmployeeId (employeeTimeLogDTO.getEmployeeId ());
                employeeTimeLog.setLogType (employeeTimeLogDTO.getLogType ());
                employeeTimeLog.setWorkDate (workDate);
                employeeTimeLog.setCreatedBy (employeeTimeLogDTO.getCreatedBy ());
                employeeTimeLog.setCreatedOn (InstantFormatter.InstantFormat (employeeTimeLogDTO.getCreatedOn ()));
                employeeTimeLog.setLogTime (logTime);

                EmployeeTimeLog timeLog = employeeTimeLogRepo.save (employeeTimeLog);
            }

            response.setMessage ("Employee Time In - Out details added successfully.");
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
       catch(Exception e){
           return catchException ("addEmployeeCheckInOutDetails",e,"Failed","Unable to add Time In - Out details.");
       }
    }

    @Override
    public ResponseEntity<Object> editEmployeeTimeInOutDetails( List<EmployeeTimeLogDTO> employeeTimeLogDTOS) {
        try{

            Instant workDate = InstantFormatter.InstantFormat (employeeTimeLogDTOS.get (0).getWorkDate ());
            Instant modifiedDate = InstantFormatter.InstantFormat (employeeTimeLogDTOS.get (0).getLastModifiedOn ());

            List<EmployeeTimeLog> currentTimelogDetails = employeeTimeLogRepo
                    .findByEmployeeIdAndWorkDateOrderByLogIdAscLogTimeAsc (employeeTimeLogDTOS.get (0).getEmployeeId (), workDate);

            if(currentTimelogDetails.isEmpty ()){
                return catchException ("editEmployeeTimeInOutDetails",null,"Failed","Unable to edit Time In - Out details. No value present");
            }

            for(int i = 0; i < employeeTimeLogDTOS.size ()-1;i++){

                Instant timeInLog = InstantFormatter.InstantFormat (employeeTimeLogDTOS.get (i).getLogTime ());
                Instant timeOutLog = InstantFormatter.InstantFormat (employeeTimeLogDTOS.get (i+1).getLogTime ());

                if (timeInLog.isAfter (timeOutLog)) {

                    return catchException ("editEmployeeTimeInOutDetails",null,"Failed",
                            String.format ("Given Time In %s should not be before time out %s.Please add valid Time In details for date.",
                                    InstantFormatter.FormattedDateTime (timeInLog),InstantFormatter.FormattedDateTime (timeOutLog)));
                }
            }

            Optional<PayRollMaster> payRollDetails = payRollMasterRepo.findByLocationIdAndDateBetween(LocationEum.USA.getValue (), workDate);
            Optional<PayRollMaster> currentPayRollDetails = payRollMasterRepo.findByLocationIdAndDateBetween(LocationEum.USA.getValue (), modifiedDate);

            if(payRollDetails.isPresent() && currentPayRollDetails.isPresent()) {

                if((currentPayRollDetails.get().getFromDate().compareTo(workDate) <= 0 &&
                        currentPayRollDetails.get().getToDate().compareTo(workDate) >= 0 &&
                        currentPayRollDetails.get().getPayrollDate().compareTo(modifiedDate) >= 0 ) ||
                        (currentPayRollDetails.get().getToDate().compareTo(workDate) < 0)) // if current payroll check for payroll process end date
                {

                   // update validation and process

                    response.setMessage ("Employee Time In - Out details updated successfully.");

                }
                else if(currentPayRollDetails.get().getFromDate().compareTo(payRollDetails.get().getPayrollDate()) <= 0 &&
                        currentPayRollDetails.get().getFromDate().compareTo(modifiedDate)<=0 &&
                        payRollDetails.get().getPayrollDate().compareTo(modifiedDate) >= 0  ) {

                   // update process with validation

                    response.setMessage("Employee Time In - Out details updated successfully.<br/>You should edit time IN - OUT details 2 days before payroll process "
                            + ".<br/>Please ensure from next time onwards");
                }
                else {
                    return catchException("editEmployeeTimeInOutDetails()", null, "Error", "Payroll already in progress. Please contact HR.");
                }
            }
            else {
                return catchException("editEmployeeTimeInOutDetails()", null, "Error", "Payroll details not found");
            }

            Set<Long> existingLogIds = employeeTimeLogDTOS.stream()
                    .filter(data -> ObjectUtils.notEqual (data.getLogId (),Long.valueOf (0)))
                    .map(EmployeeTimeLogDTO::getLogId)
                    .collect(Collectors.toSet());

            List<EmployeeTimeLogDTO> newTimeLogRecord = employeeTimeLogDTOS.stream ().filter (data -> !ObjectUtils.notEqual (data.getLogId (),Long.valueOf (0))).toList ();

//            if(!employeeTimeLogList.isEmpty ()){
//                // delete exist one
//              employeeTimeLogRepo.deleteAll (employeeTimeLogList);
//
//            }
             if(!newTimeLogRecord.isEmpty ()){
                // add new record
                for(EmployeeTimeLogDTO employeeTimeLog :newTimeLogRecord ){

                    EmployeeTimeLog employeeTimeLogNew = new EmployeeTimeLog ();

                    employeeTimeLogNew.setEmployeeId (employeeTimeLog.getEmployeeId ());
                    employeeTimeLogNew.setLogType (employeeTimeLog.getLogType ());
                    employeeTimeLogNew.setWorkDate (workDate);
                    employeeTimeLogNew.setCreatedBy (employeeTimeLog.getLastModifiedBy ());
                    employeeTimeLogNew.setCreatedOn (modifiedDate);
                    employeeTimeLogNew.setLogTime (InstantFormatter.InstantFormat (employeeTimeLog.getLogTime ()));

                    EmployeeTimeLog timeLog = employeeTimeLogRepo.save (employeeTimeLogNew);
                }

            }

            List<EmployeeTimeLogDTO> existingRecord = employeeTimeLogDTOS.stream ().filter (data -> ObjectUtils.notEqual (data.getLogId (),Long.valueOf (0))).toList ();

            for(EmployeeTimeLogDTO employeeTimeLog : existingRecord){

                Optional<EmployeeTimeLog> byLogIdAndEmployeeId = employeeTimeLogRepo.findByLogIdAndEmployeeId (employeeTimeLog.getLogId (), employeeTimeLog.getEmployeeId ());

                if(byLogIdAndEmployeeId.isEmpty ()){
                    return catchException ("editEmployeeTimeInOutDetails",null,"Failed","Unable to edit Time In - Out details. No value present");
                }

                byLogIdAndEmployeeId.get().setLastModifiedBy (employeeTimeLog.getLastModifiedBy ());
                byLogIdAndEmployeeId.get().setLastModifiedOn (modifiedDate);
                byLogIdAndEmployeeId.get().setLogTime (InstantFormatter.InstantFormat (employeeTimeLog.getLogTime ()));

                EmployeeTimeLog timeLog = employeeTimeLogRepo.save (byLogIdAndEmployeeId.get ());

            }

            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
        catch(Exception e){
            return catchException ("addEmployeeCheckInOutDetails",e,"Failed","Unable to add Time In - Out details.");
        }
    }

    @Override
    public ResponseEntity<Object> fetchEmployeeTimeInOutDetails(PayRollFilterModel filterModel) {
        try{
            Map<String,List<EmployeeTimeInOutView> > empTimeInoutDetails = new HashMap<> ();

            List<EmployeeTimeInOutView> employeeTimeInOutViews = SqlConnectionSetup.getJdbcConnection ().query ("EXEC getEmployeeTimeInOut ?,?,?",
                    BeanPropertyRowMapper.newInstance (EmployeeTimeInOutView.class),
                    filterModel.getEmployeeId (),
                    filterModel.getFromDate (),
                    filterModel.getToDate ()
            );
            
            if(!employeeTimeInOutViews.isEmpty ()){
                List<EmployeeTimeInOutView> totalWorkHour = employeeTimeInOutViews.stream ().filter (data -> ObjectUtils.equals (data.getLogId (), Long.valueOf (0))).toList ();

                employeeTimeInOutViews = employeeTimeInOutViews.stream ().filter (data -> ObjectUtils.notEqual (data.getLogId (), Long.valueOf (0))).toList ();

                empTimeInoutDetails.putIfAbsent ("TotalHours", totalWorkHour);
                empTimeInoutDetails.putIfAbsent ("History", employeeTimeInOutViews);
            }

            response.setData (empTimeInoutDetails);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
        catch(Exception e){
            return catchException ("getEmployeeCheckInOutDetails",e,"Failed","Unable to get Time In - Out details.");
        }
    }

    @Override
    public ResponseEntity<Object> getEmployeeTimeInOutDetails(PayRollFilterModel payRollFilterModel) {
        try{

            List<EmployeeTimeLog> employeeTimeLog = employeeTimeLogRepo.findByEmployeeIdAndWorkDateOrderByLogIdAscLogTimeAsc (payRollFilterModel.getEmployeeId (),
                    InstantFormatter.InstantFormat (payRollFilterModel.getFromDate ()));

            response.setData (employeeTimeLog);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
        catch(Exception e){
            return catchException ("getEmployeeTimeInOutDetails",e,"Failed","Unable to get Time In - Out details.");
        }
    }

    @Override
    public ResponseEntity<Object> getTimeInOutSummaryDetails(PayRollFilterModel payRollFilterModel) {
        try{

            List<TimeInOutSummaryDetails> employeeTimeInOutViews = SqlConnectionSetup.getJdbcConnection ().query ("EXEC getTimeInOutSummary ?,?,?,?",
                    BeanPropertyRowMapper.newInstance (TimeInOutSummaryDetails.class),
                    payRollFilterModel.getEmployeeId (),
                    payRollFilterModel.getFromDate (),
                    payRollFilterModel.getToDate (),
                    "Summary Details"
            );

            response.setData (employeeTimeInOutViews);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
        catch(Exception e){
            return catchException ("getTimeInOutSummaryDetails",e,"Failed","Unable to get Time In - Out Summary details.");
        }
    }

    @Override
    public ResponseEntity<Object> getEmployeeTimeInOutSummaryDetails(PayRollFilterModel payRollFilterModel) {
        try{
            Map<String, Object> combinedEmpTimeInoutDetails = new HashMap<>();

            List<SummaryView> employeeTimeInOutViews = SqlConnectionSetup.getJdbcConnection ().query ("EXEC getTimeInOutSummary ?,?,?,?",
                    BeanPropertyRowMapper.newInstance (SummaryView.class),
                    payRollFilterModel.getEmployeeId (),
                    payRollFilterModel.getFromDate (),
                    payRollFilterModel.getToDate (),
                    "Summary View"
            );

            if(!employeeTimeInOutViews.isEmpty ()){

                employeeTimeInOutViews = employeeTimeInOutViews.stream().filter(data -> data.getRemarksType().equalsIgnoreCase("Leave Requested")).toList();

                combinedEmpTimeInoutDetails.putIfAbsent ("leaveHistory", employeeTimeInOutViews);

            }

            List<EmployeeTimeInOutView> employeeTimeInOutHistoryViews = SqlConnectionSetup.getJdbcConnection ().query ("EXEC getEmployeeSheetView ?,?,?",
                    BeanPropertyRowMapper.newInstance (EmployeeTimeInOutView.class),
                    payRollFilterModel.getEmployeeId (),
                    payRollFilterModel.getFromDate (),
                    payRollFilterModel.getToDate ()
            );

            if(!employeeTimeInOutHistoryViews.isEmpty ()){

                List<EmployeeTimeInOutView> totalWorkHour = employeeTimeInOutHistoryViews.stream ().filter (data -> ObjectUtils.equals (data.getEmployeeName (), "Total Hours")).toList ();

                employeeTimeInOutHistoryViews = employeeTimeInOutHistoryViews.stream ().filter (data -> ObjectUtils.notEqual (data.getEmployeeName (), "Total Hours")).toList ();

                combinedEmpTimeInoutDetails.putIfAbsent ("totalHours", totalWorkHour);
                combinedEmpTimeInoutDetails.putIfAbsent ("timeInOutDetails", employeeTimeInOutHistoryViews);
            }

            response.setData (combinedEmpTimeInoutDetails);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
        catch(Exception e){
            return catchException ("getEmployeeTimeInOutSummaryDetails",e,"Failed","Unable to get employee Time In - Out Summary details.");
        }
    }

    @Override
    public ResponseEntity<Object> getEmployeeTimeSheetDetails(PayRollFilterModel payRollFilterModel) {
        try{

            List<Object> employeeTimeInOutViews = new ArrayList<>();
            
            employeeTimeInOutViews = SqlConnectionSetup.getJdbcConnection ().query ("EXEC getTimeSheetSummary ?,?,?",
                    new ResultSetMapper(),
                    payRollFilterModel.getEmployeeId (),
                    payRollFilterModel.getFromDate (),
                    payRollFilterModel.getToDate ()
            );

            response.setData (employeeTimeInOutViews);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
        catch(Exception e){
            return catchException ("getEmployeeTimeSheetDetails",e,"Failed","Unable to get employee Time sheet details.");
        }
    }

    @Override
    public ResponseEntity<Object> uploadUsEmployeeTimeInOutDetails(TimeSheetDocumentsDTO documentDetails) {
        try{
            Optional<TimeSheetDocuments> timeSheetDocuments = timeSheetDocumentsRepository
                    .findByFromDateAndToDate(documentDetails.getFromDate(), documentDetails.getToDate());

            List<USEmployeeTimeSheetDetails> usEmployeeTimeSheetDetails = csvToList(documentDetails);

            if(timeSheetDocuments.isPresent()){
                List<USEmployeeTimeSheetDetails> existingUsEmployeeTimeSheetDetails = usEmployeeTimeSheetDetailsRepo
                        .findByDate(documentDetails.getFromDate(), documentDetails.getToDate());

                List<USEmployeeTimeSheetDetails> missingDetails = usEmployeeTimeSheetDetails.stream()
                        .filter(detail -> !existingUsEmployeeTimeSheetDetails.contains(detail))
                        .toList();

                if(missingDetails.isEmpty()){
                    return catchException ("uploadUsEmployeeTimeInOutDetails",null,"Validation Warning","Already uploaded document for given period. Please Check.");
                }
            }

            List<TimeSheetActiveUSAEmployee> usaActiveEmployee = SqlConnectionSetup.getJdbcConnection().query("EXEC spGetActiveUSAEmpCode ?,?;",
                    BeanPropertyRowMapper.newInstance(TimeSheetActiveUSAEmployee.class),
                    documentDetails.getFromDate(),
                    documentDetails.getToDate());

            // Extract employee codes from timesheet details
            Set<String> timesheetEmployeeCodes = usEmployeeTimeSheetDetails.stream()
                    .map(USEmployeeTimeSheetDetails::getEmployeeNumber)
                    .collect(Collectors.toSet());

            // Check if all active employee codes are in the timesheet list
            boolean allMatch = usaActiveEmployee.stream()
                    .map(TimeSheetActiveUSAEmployee::getEmployeeCode)
                    .allMatch(timesheetEmployeeCodes::contains);

            if (!allMatch) {

                List<String> missingEmployeeCodes = usaActiveEmployee.stream()
                        .map(TimeSheetActiveUSAEmployee::getEmployeeCode)
                        .filter(code -> !timesheetEmployeeCodes.contains(code))   // keep only the “not‑matched” ones
                        .toList();

                return catchException ("uploadUsEmployeeTimeInOutDetails",null,"Validation Warning","Missing Active employee code. ".concat(missingEmployeeCodes.toString()));
            }
            TimeSheetDocuments timeSheetDocumentDetails = new TimeSheetDocuments();

            timeSheetDocumentDetails.setFromDate(documentDetails.getFromDate());
            timeSheetDocumentDetails.setToDate(documentDetails.getToDate());
            timeSheetDocumentDetails.setDocumentName(documentDetails.getFileName());
            timeSheetDocumentDetails.setDocumentImage(documentDetails.getFileImageBinary());
            timeSheetDocumentDetails.setCreatedBy(documentDetails.getUploadedBy());
            timeSheetDocumentDetails.setCreatedOn(new Date());

            TimeSheetDocuments savedSheetDocuments = timeSheetDocumentsRepository.save(timeSheetDocumentDetails);

            List<EmployeeTimeLogDTO> employeeTimeLogDTOList =  new ArrayList<>();

            if(savedSheetDocuments != null || ObjectUtils.isEmpty(savedSheetDocuments)){

//                List<USEmployeeTimeSheetDetails> usEmployeeTimeSheetDetails = csvToList(documentDetails);

                List<USEmployeeTimeSheetDetails> usEmployeeTimeSheetDetailsList = usEmployeeTimeSheetDetailsRepo.saveAll(usEmployeeTimeSheetDetails);

                if(!usEmployeeTimeSheetDetailsList.isEmpty()){

                    employeeTimeLogDTOList = SqlConnectionSetup.getJdbcConnection().query("exec spAddEmployeeTimeInOutDetails",
                            BeanPropertyRowMapper.newInstance(EmployeeTimeLogDTO.class));
                }
            }

            response.setMessage ("Uploaded and Added Time Punch In - Out details Successfully.");
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

        }
        catch(Exception e){
            return catchException ("uploadUsEmployeeTimeInOutDetails",e,"Failed","Unable to upload employee Time sheet details.");
        }

    }

    @Override
    public ResponseEntity<Object> getActiveEmployeeCode(PayRollFilterModel payRollFilterModel) {
        try{
            List<TimeSheetActiveUSAEmployee> usaActiveEmployee = SqlConnectionSetup.getJdbcConnection().query("EXEC spGetActiveUSAEmpCode ?,?;",
                    BeanPropertyRowMapper.newInstance(TimeSheetActiveUSAEmployee.class),
                    payRollFilterModel.getFromDate(),
                    payRollFilterModel.getToDate());

            List<String> employeeCode = usaActiveEmployee.stream().map(TimeSheetActiveUSAEmployee::getEmployeeCode).toList();

            response.setData (employeeCode);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

        }
        catch(Exception e){
            return catchException ("getActiveEmployeeCode",e,"Failed","Unable to get active employee details.");
        }
    }

    private List<USEmployeeTimeSheetDetails> csvToList(TimeSheetDocumentsDTO file) {

        List<USEmployeeTimeSheetDetails> timesheets = new ArrayList<>();

        try (CSVReader csvReader = new CSVReader(new InputStreamReader(new ByteArrayInputStream(file.getFileImageBinary()), StandardCharsets.UTF_8))) {

            List<String[]> records = csvReader.readAll();
            records.remove(0); // Remove header row

            for (String[] record : records) {
                USEmployeeTimeSheetDetails timesheet = new USEmployeeTimeSheetDetails();

                timesheet.setDate(record[0]);
                timesheet.setEmployeeName(record[1]);
                timesheet.setEmployeeNumber(record[2]);
                timesheet.setDepartmentWorked(record[3]);
                timesheet.setCategory(record[4]);
                timesheet.setHours(Double.valueOf(record[5].isEmpty() ? "0" : record[5]));
                timesheet.setTimeIn(record[6]);
                timesheet.setTimeOut(record[7]);
                timesheet.setDollars(String.valueOf(new BigDecimal(record[8].isEmpty() ? "0" : record[8])));

                timesheets.add(timesheet);
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to parse CSV file: " + e.getMessage(), e);
        }
        return timesheets;
    }

    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
        logger.error("{} Error : {}" , methodName, e);
        response.setStatus(false);
        response.setInformation(new ExceptionBean (Instant.now(), message, description));
        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }


}


