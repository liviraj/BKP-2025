package com.histo.timeInOutModule.entity;

import javax.persistence.*;

import lombok.Data;
import java.util.Date;

@Data
@Entity
@Table
public class TimeSheetDocuments {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "documentId")
    private Integer documentId;

    @Column(name = "FromDate", nullable = false, length = 500)
    private String fromDate;

    @Column(name = "ToDate", nullable = false, length = 500)
    private String toDate;

    @Column(name = "documentName", length = 500)
    private String documentName;

    @Lob
    @Column(name = "documentImage")
    private byte[] documentImage;

    @Column(name = "createdBy")
    private Integer createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "createdOn")
    private Date createdOn;
}
