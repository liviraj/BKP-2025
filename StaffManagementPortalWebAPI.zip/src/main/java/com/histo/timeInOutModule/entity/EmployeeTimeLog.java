package com.histo.timeInOutModule.entity;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.histo.staffmanagementportal.util.InstantConverter;
import lombok.Data;

import java.time.Instant;

@Data
@Entity
@Table(name = "EmployeeTimeLogs")
public class EmployeeTimeLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long logId;

    @Column(nullable = false)
    private Integer employeeId;

    @Column
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS",timezone = "UTC")
    @Convert(converter = InstantConverter.class)
    private Instant workDate;

    @Column(length = 10)
    private String logType;

    @Column
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS",timezone = "UTC")
    @Convert(converter = InstantConverter.class)
    private Instant logTime;

    @Column
    private Integer createdBy;

    @Column
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS",timezone = "UTC")
    @Convert(converter = InstantConverter.class)
    private Instant createdOn;

    @Column
    private Integer lastModifiedBy;

    @Column
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS",timezone = "UTC")
    @Convert(converter = InstantConverter.class)
    private Instant lastModifiedOn;

}
