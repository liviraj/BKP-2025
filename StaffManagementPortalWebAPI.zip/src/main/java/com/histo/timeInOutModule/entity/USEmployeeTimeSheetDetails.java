package com.histo.timeInOutModule.entity;

import javax.persistence.*;

import com.histo.staffmanagementportal.util.InstantConverter;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.Instant;
import java.util.Arrays;
import java.util.Objects;

@Getter
@Setter
@ToString
@Entity
@Table(name = "USEmployeeTimesheetDetails")
public class USEmployeeTimeSheetDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "documentdetailsId")
    private Integer documentDetailsId;

    @Column(name = "Date")
    private String date;

    @Column(name = "EmployeeName")
    private String employeeName;

    @Column(name = "EmployeeNumber")
    private String employeeNumber;

    @Column(name = "DepartmentWorked")
    private String departmentWorked;

    @Column(name = "Category", nullable = false)
    private String category;

    @Column(name = "Hours")
    private Double hours;

    @Column(name = "[In]")
    private String timeIn;

    @Column(name = "[Out]")
    private String timeOut;

    @Column(name = "Dollars")
    private String dollars;

    @Column(name = "documentName")
    private String documentName;

    @Column(name = "documentImage")
    private byte[] documentImage;

    @Column(name = "createdBy")
    private Integer createdBy;

    @Column(name = "createdOn")
    @Convert(converter = InstantConverter.class)
    private Instant createdOn;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof USEmployeeTimeSheetDetails that)) return false;
        return Objects.equals(getDocumentDetailsId(), that.getDocumentDetailsId())
                && Objects.equals(getDate(), that.getDate())
                && Objects.equals(getEmployeeName(), that.getEmployeeName())
                && Objects.equals(getEmployeeNumber(), that.getEmployeeNumber())
                && Objects.equals(getDepartmentWorked(), that.getDepartmentWorked())
                && Objects.equals(getCategory(), that.getCategory())
                && Objects.equals(getHours(), that.getHours())
                && Objects.equals(getTimeIn(), that.getTimeIn())
                && Objects.equals(getTimeOut(), that.getTimeOut())
                && Objects.equals(getDollars(), that.getDollars())
                && Objects.equals(getDocumentName(), that.getDocumentName())
                && Arrays.equals(getDocumentImage(), that.getDocumentImage())
                && Objects.equals(getCreatedBy(), that.getCreatedBy())
                && Objects.equals(getCreatedOn(), that.getCreatedOn());
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(getDocumentDetailsId(), getDate(), getEmployeeName(), getEmployeeNumber(), getDepartmentWorked(), getCategory(), getHours(), getTimeIn(), getTimeOut(), getDollars(), getDocumentName(), getCreatedBy(), getCreatedOn());
        result = 31 * result + Arrays.hashCode(getDocumentImage());
        return result;
    }
}
