package com.histo.timeInOutModule.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class SummaryView {

        private Integer employeeId;
        private String employeeName;
        private String workDate;
        private String summaryOrStatus;
        private String leaveType;
        private String fullOrHalfDay;
        private String remarksType;

}
