package com.histo.timeInOutModule.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class TimeSheetDocumentsDTO {

    private Integer documentId;
    private String fromDate;
    private String toDate;
    private String fileName;
    private byte[] fileImageBinary;
    private Integer uploadedBy;
    private String uploadedDate;
}
