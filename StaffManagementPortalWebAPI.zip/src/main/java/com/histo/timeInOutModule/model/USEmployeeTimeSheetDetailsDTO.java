package com.histo.timeInOutModule.model;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class USEmployeeTimeSheetDetailsDTO {
    private Integer documentDetailsId;
    private String date;
    private String employeeName;
    private String employeeNumber;
    private String departmentWorked;
    private String category;
    private Double hours;
    private String timeIn;
    private String timeOut;
    private String dollars;
}
