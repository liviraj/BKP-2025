package com.histo.timeInOutModule.model;

public interface FormattedDetails {
     Integer getLogId();
     Integer getEmployeeId();
     String getWorkDate();
     String getLogType();
     String getLogTime();
     Integer getCreatedBy();
     String getCreatedOn();
     Integer getLastModifiedBy();
     String getLastModifiedOn();

     String getFormattedTime();
}
