package com.histo.timeInOutModule.model;

public enum LoginAction {
    TIME_IN("In"),
    TIME_OUT("Out");

    private String value;

    public String getValue() {
        return value;
    }

    LoginAction(String value) {
        this.value = value;
    }

    public static LoginAction getEnumValueFromString(String text) {
        for (LoginAction status : LoginAction.values()) {
            if (status.value.equalsIgnoreCase( text)) {
                return status;
            }

        }
        return null;
    }
}
