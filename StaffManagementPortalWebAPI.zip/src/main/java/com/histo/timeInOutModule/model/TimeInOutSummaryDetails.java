package com.histo.timeInOutModule.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class TimeInOutSummaryDetails {

    private Integer employeeId;
    private String employeeName;
    private String totalWorkHours;
    private String totalHoursCalculation;
    private String totalWorkminutes;
    private String remarks;
    private String fromDate;
    private String toDate;
}
