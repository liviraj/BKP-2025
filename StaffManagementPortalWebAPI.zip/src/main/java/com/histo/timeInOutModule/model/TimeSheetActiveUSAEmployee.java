package com.histo.timeInOutModule.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TimeSheetActiveUSAEmployee {

    private int employeeId;
    private int locationId;
    private String empName;
    private String employeeCode;
    private String employeementStatus;
    private String dateOfJoining;
    private String relievingDate;
}
