package com.histo.timeInOutModule.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class EmployeeTimeInOutView {

    private Long logId;
    private Integer employeeId;
    private String employeeName;
    private String workDate;
    private String timeIn1;
    private String timeOut1;
    private String timeIn2;
    private String timeOut2;
    private String timeIn3;
    private String timeOut3;
    private String timeIn4;
    private String timeOut4;
    private String workhours;
    private String totalHoursCalculation;
    private String workminutes;
    private String holiday;
    private String weekName;
    private String dateCategory;
    private String overTime;
    private String vacationLeaveTaken;
    private String sickLeaveTaken;
    private String regular;

}
