package com.histo.timeInOutModule.model;


import lombok.Data;

@Data
public class EmployeeTimeLogDTO {

    private Long logId;
    private Integer employeeId;
    private String workDate;
    private String logType;
    private String logTime;
    private Integer createdBy;
    private String createdOn;
    private Integer lastModifiedBy;
    private String lastModifiedOn;

}