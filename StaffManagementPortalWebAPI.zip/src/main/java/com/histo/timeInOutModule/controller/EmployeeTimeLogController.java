package com.histo.timeInOutModule.controller;

import com.azure.core.annotation.QueryParam;
import com.histo.timeInOutModule.model.EmployeeTimeLogDTO;
import com.histo.timeInOutModule.model.TimeSheetDocumentsDTO;
import com.histo.timeInOutModule.service.EmployeeTimeLogService;
import com.histo.indiapayroll.model.PayRollFilterModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/timeInOut")
public class EmployeeTimeLogController {

    private final EmployeeTimeLogService employeeTimeLogService;

    public EmployeeTimeLogController(EmployeeTimeLogService employeeTimeLogService) {
        this.employeeTimeLogService = employeeTimeLogService;
    }

    @GetMapping
    ResponseEntity<Object> getEmployeeTimeInOutDetails(@QueryParam ("input")PayRollFilterModel filterModel){
        return employeeTimeLogService.fetchEmployeeTimeInOutDetails (filterModel);
    }

    @PostMapping
    ResponseEntity<Object> addTimeInOutDetails(@RequestBody List<EmployeeTimeLogDTO> employeeTimeLogDTO){
        return employeeTimeLogService.addEmployeeTimeInOutDetails (employeeTimeLogDTO);
    }

    @GetMapping("/details")
    ResponseEntity<Object> getTimeInOutDetailsById(@QueryParam ("input")PayRollFilterModel filterModel){
        return employeeTimeLogService.getEmployeeTimeInOutDetails (filterModel);
    }

    @GetMapping("/summary")
    ResponseEntity<Object> getTimeInOutSummary(@QueryParam ("input")PayRollFilterModel filterModel){
        return employeeTimeLogService.getTimeInOutSummaryDetails (filterModel);
    }

    @GetMapping("/summary-view")
    ResponseEntity<Object> getTimeInOutSummaryView(@QueryParam ("input")PayRollFilterModel filterModel){
        return employeeTimeLogService.getEmployeeTimeInOutSummaryDetails (filterModel);
    }

    @GetMapping("/timeSheet")
    ResponseEntity<Object> getTimeSheetSummaryView(@QueryParam ("input")PayRollFilterModel filterModel){
        return employeeTimeLogService.getEmployeeTimeSheetDetails (filterModel);
    }
    @PutMapping
    ResponseEntity<Object> editTimeInOutDetails(@RequestBody List<EmployeeTimeLogDTO> employeeTimeLogDTOS){
        return employeeTimeLogService.editEmployeeTimeInOutDetails (employeeTimeLogDTOS);
    }

    @PostMapping("/upload")
    ResponseEntity<Object> uploadTimeInOutDetails(@RequestBody TimeSheetDocumentsDTO timeSheetDocumentsDTO)  {
        return employeeTimeLogService.uploadUsEmployeeTimeInOutDetails (timeSheetDocumentsDTO);
    }
    @GetMapping("/activeEmployee")
    ResponseEntity<Object> getActiveEmployee(@QueryParam ("input")PayRollFilterModel filterModel){
        return employeeTimeLogService.getActiveEmployeeCode (filterModel);
    }
}
