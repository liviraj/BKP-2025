package com.histo.timeInOutModule.repository;

import com.histo.timeInOutModule.entity.EmployeeTimeLog;
import com.histo.timeInOutModule.model.FormattedDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface EmployeeTimeLogRepository extends JpaRepository<EmployeeTimeLog, Long> {
    Optional<EmployeeTimeLog> findByLogIdAndEmployeeId(Long logId, Integer employeeId);
    List<EmployeeTimeLog> findByEmployeeIdAndWorkDateOrderByLogIdAscLogTimeAsc(Integer employeeId, Instant workDate);
    @Query(value = """
            SELECT logId,	
            employeeId,	
            CONVERT(VARCHAR(100),WorkDate , 101) As workDate,
            logType,
            FORMAT(LogTime , 'hh:mm tt') As logTime,
            createdBy,
            createdOn,
            lastModifiedBy,
            lastModifiedOn,
            CONVERT(VARCHAR(100),WorkDate , 101) + ' '+
            FORMAT(LogTime , 'hh:mm tt') As formattedTime FROM EmployeeTimeLogs
            WHERE LogId = :logId
            """, nativeQuery = true)
    Optional<FormattedDetails> findByLogId(@Param ("logId") Long logId);

    @Query("select count(e) from EmployeeTimeLog e where e.employeeId = ?1 and e.workDate = ?2 and e.logType = ?3")
    long getTimeInOutCount(Integer employeeId, Instant workDate, String logType);

    Optional<EmployeeTimeLog> findFirstByEmployeeIdAndWorkDateOrderByLogIdDesc(Integer employeeId, Instant workDate);
}