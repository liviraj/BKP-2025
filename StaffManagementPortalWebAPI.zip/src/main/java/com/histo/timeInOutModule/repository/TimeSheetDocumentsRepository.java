package com.histo.timeInOutModule.repository;

import com.histo.timeInOutModule.entity.TimeSheetDocuments;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface TimeSheetDocumentsRepository extends JpaRepository<TimeSheetDocuments, Integer> {
    @Query("select t from TimeSheetDocuments t where t.fromDate = ?1 and t.toDate = ?2")
    Optional<TimeSheetDocuments> findByFromDateAndToDate(String fromDate, String toDate);
}
