package com.histo.timeInOutModule.repository;

import com.histo.timeInOutModule.entity.USEmployeeTimeSheetDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface USEmployeeTimeSheetDetailsRepo extends JpaRepository<USEmployeeTimeSheetDetails,Integer> {
    @Query(value = "select * from USEmployeeTimeSheetDetails where date between ?1 and ?2",nativeQuery = true)
    List<USEmployeeTimeSheetDetails> findByDate(String fromDate,String toDate);


}
