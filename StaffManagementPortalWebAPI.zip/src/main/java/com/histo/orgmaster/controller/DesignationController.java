package com.histo.orgmaster.controller;

import com.azure.core.annotation.QueryParam;
import com.histo.orgmaster.model.MasterFilter;
import com.histo.orgmaster.model.DesignationMasterDTO;
import com.histo.orgmaster.service.DesignationService;
import com.histo.staffmanagementportal.model.DeleteDetails;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/designation")
public class DesignationController {

    private final DesignationService designationService;

    public DesignationController(DesignationService designationService) {
        this.designationService = designationService;
    }

    @GetMapping
    public ResponseEntity<Object> viewDesignationDetails(@QueryParam ("input") MasterFilter designationFilter){
        return designationService.getDesignationDetails (designationFilter);
    }

    @GetMapping("{designationId}")
     public ResponseEntity<Object> viewDesignationDetailsById(@PathVariable Integer designationId){
        return designationService.getDesignationDetailsById (designationId);
    }

    @PostMapping
    public ResponseEntity<Object> createDesignationDetails(@Valid @RequestBody DesignationMasterDTO designationMasterDTO){
        return designationService.addDesignationDetails (designationMasterDTO);
    }

    @PutMapping("{designationMasterId}")
    public ResponseEntity<Object> updateDesignationDetails(@Valid @RequestBody DesignationMasterDTO designationMasterDTO
            ,@PathVariable("designationMasterId") Integer designationMasterId){
        return designationService.editDesignationDetails (designationMasterId, designationMasterDTO);
    }

    @DeleteMapping
    public ResponseEntity<Object> deleteDesignationId(@RequestBody DeleteDetails deleteDetails){
        return designationService.deleteDesignationDetails (deleteDetails);
    }
}
