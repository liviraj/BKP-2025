package com.histo.orgmaster.controller;

import com.azure.core.annotation.QueryParam;
import com.histo.orgmaster.model.DepartmentModelCreate;
import com.histo.orgmaster.model.DepartmentModelUpdate;
import com.histo.orgmaster.model.MasterFilter;
import com.histo.orgmaster.model.SupervisorModel;
import com.histo.orgmaster.service.DepartmentService;
import com.histo.staffmanagementportal.model.DeleteDetails;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/department")
public class DepartmentController {

    private final DepartmentService departmentService;

    public DepartmentController(DepartmentService departmentService) {
        this.departmentService = departmentService;
    }

    @GetMapping
    private ResponseEntity<Object> viewDepartmentDetails(@QueryParam("input") MasterFilter designationFilter){
        return departmentService.getDepartmentDetails (designationFilter);
    }

    @GetMapping("/supervisor")
    private ResponseEntity<Object> viewDepartmenSupervisortDetails(@QueryParam("input") MasterFilter designationFilter){
        return departmentService.getDepartmentSupervisorDetails (designationFilter);
    }

    @PostMapping
    public ResponseEntity<Object> addDepartmentDetails(@RequestBody DepartmentModelCreate departmentModel){
        return departmentService.addDepartmentDetails (departmentModel);
    }

    @PutMapping("/{departmentId}")
    public ResponseEntity<Object> editDepartmentDetails(@PathVariable("departmentId") Integer departmentId, @RequestBody DepartmentModelUpdate departmentModel){
        return departmentService.editDepartmentDetails (departmentId, departmentModel);
    }

    @DeleteMapping
    public ResponseEntity<Object> deleteDepartmentById(@RequestBody DeleteDetails deleteDetails){
        return departmentService.deleteDepartmentDetails (deleteDetails);
    }

    @PostMapping("/supervisor")
    public ResponseEntity<Object> addDepartmentSupervisorDetails(@RequestBody SupervisorModel departmentModel){
        return departmentService.addDepartmentSupervisorDetails (departmentModel);
    }

    @DeleteMapping("/supervisor")
    public ResponseEntity<Object> deleteDepartmentSupervisorById(@RequestBody DeleteDetails deleteDetails){
        return departmentService.deleteDepartmentSupervisorDetails (deleteDetails);
    }

    @PutMapping("/supervisor/{supervisorDetailId}")
    public ResponseEntity<Object> editDepartmentDetails(@PathVariable("supervisorDetailId") Integer supervisorDetailId, @RequestBody SupervisorModel supervisorModel){
        return departmentService.editDepartmentSupervisorDetails (supervisorDetailId, supervisorModel);
    }
}
 