package com.histo.orgmaster.repository;

import com.histo.orgmaster.entity.Department;
import com.histo.staffmanagementportal.model.DepartmentName;

import java.time.Instant;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface DepartmentRepository extends JpaRepository<Department,Integer> {
	@Query(value = """
			select d.DepartmentID
			          ,d.DepartmentName
			          ,d.Description
			          ,d.ModifiedBy
			          ,d.ModifiedDate
			          ,CASE WHEN d.RecordStatus = 'A' THEN 'Active' ELSE 'InActive' END AS RecordStatus
			          ,d.HierarchyOrder
			          ,d.ParentDepartmentID
			          ,d.SortOrder
			          ,d.createdBy
			          ,d.createdOn from Department d where (d.RecordStatus = CASE WHEN ?1 = 'Active' THEN 'A'ELSE 'D' END OR ?1 = 'All' )order by d.DepartmentName
			""",nativeQuery = true)
    List<Department> findByRecordStatus(String recordStatus);

    @Query(value = """
			select du.LocationID from Department d,  DepartmentSupervisors du, Employee e where d.Hierarchyorder is not null and 
			d.DepartmentID=du.DepartmentID and du.EmployeeID=e.EmployeeID and e.RecordStatus='A' and d.RecordStatus = 'A' and d.DepartmentID=?1 order by d.DepartmentName 
			""",nativeQuery = true)
    public List<Integer> findLocationIdByDepartmentId(Integer departmentId);

    @Query(value = """
			select distinct d.departmentid, d.DepartmentName,d.SortOrder from Department d,  DepartmentSupervisors du, Employee e where d.Hierarchyorder is not null 
			and d.DepartmentID=du.DepartmentID and du.EmployeeID=e.EmployeeID and e.RecordStatus='A' and d.RecordStatus = 'A' order by d.DepartmentName
			""",nativeQuery = true)
    public List<DepartmentName> findDepartmentName();

	Department findByDepartmentName(String departmentName);

	@Transactional
	@Modifying
	@Query("update Department e set e.recordStatus = :recordStatus,e.modifiedBy = :modifiedBy ,e.modifiedDate = :modifiedDate where e.id = :id and e.recordStatus = 'A'")
	int updateRecordStatusById(@Param("recordStatus") String recordStatus, @Param("id") Integer id, @Param("modifiedBy") Integer modifiedBy,
							   @Param("modifiedDate") Instant modifiedDate);
}
