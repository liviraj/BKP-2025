package com.histo.orgmaster.repository;

import com.histo.orgmaster.entity.DesignationMaster;
import com.histo.staffmanagementportal.model.DesignationName;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

public interface DesignationMasterRepository extends JpaRepository<DesignationMaster, Integer> {
    List<DesignationMaster> findByDesignationNameLikeAndRecordStatusAndLocationID(String designationName, String recordStatus, Byte locationID);
    @Transactional
    @Modifying
    @Query("update DesignationMaster e set e.recordStatus = :recordStatus,e.modifiedBy = :modifiedBy ,e.modifiedDate = :modifiedDate where e.id = :id and e.recordStatus = 'A'")
    int updateRecordStatusById(@Param("recordStatus") String recordStatus, @Param("id") Integer id, @Param("modifiedBy") Integer modifiedBy,
                               @Param("modifiedDate") Instant modifiedDate);

    @Query("select new com.histo.staffmanagementportal.model.DesignationName(id,designationName) from DesignationMaster where recordStatus='A' Order by designationName")
    List<DesignationName> findDesignation();

}