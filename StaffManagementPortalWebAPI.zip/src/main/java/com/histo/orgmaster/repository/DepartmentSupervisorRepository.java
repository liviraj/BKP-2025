package com.histo.orgmaster.repository;

import com.histo.orgmaster.entity.DepartmentSupervisors;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface DepartmentSupervisorRepository extends JpaRepository<DepartmentSupervisors, Integer> {
    List<DepartmentSupervisors> findByEmployeeId(Integer employeeId);
    Optional<DepartmentSupervisors> findByDepartmentIdAndLocationId(Integer departmentId, Integer locationId);

    Optional<DepartmentSupervisors> findByDepartmentIdAndLocationIdAndAutoIdNot(Integer departmentId, Integer locationId,Integer autoId);

    @Transactional
    @Modifying
    @Query("update DepartmentSupervisors e set e.modifiedBy = :modifiedBy ,e.modifiedOn = :modifiedOn where e.autoId = :id")
    int updateModifiedByById( @Param("id") Integer id, @Param("modifiedBy") Integer modifiedBy,@Param("modifiedOn") Instant modifiedDate);
}
