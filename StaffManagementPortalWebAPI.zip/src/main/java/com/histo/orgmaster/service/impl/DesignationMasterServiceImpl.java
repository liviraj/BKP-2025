package com.histo.orgmaster.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.orgmaster.entity.DesignationMaster;
import com.histo.orgmaster.model.DesignationDetails;
import com.histo.orgmaster.model.MasterFilter;
import com.histo.orgmaster.model.DesignationMasterDTO;
import com.histo.orgmaster.repository.DesignationMasterRepository;
import com.histo.orgmaster.service.DesignationService;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.model.Constants;
import com.histo.staffmanagementportal.model.DeleteDetails;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class DesignationMasterServiceImpl implements DesignationService {

    private static final Logger logger = LogManager.getLogger(DesignationMasterServiceImpl.class);
    private static final String STATUS = "status";
    private final ResponseModel response;
    private MappingJacksonValue mappingJacksonValue;

    private final DesignationMasterRepository designationMasterRepository;


    public DesignationMasterServiceImpl(ResponseModel response, DesignationMasterRepository designationMasterRepository) {
        this.response = response;
        this.designationMasterRepository = designationMasterRepository;
    }


    @Override
    public ResponseEntity<Object> getDesignationDetails(MasterFilter designationFilter) {
       try{

           List<DesignationDetails> designationDetails = SqlConnectionSetup.getJdbcConnection ()
                   .query ("exec spGetDesignationDetails ?,?;", BeanPropertyRowMapper.newInstance (DesignationDetails.class),
                   designationFilter.getLocationId (),
                   designationFilter.getStatus ()
           );

           response.setStatus (true);
           response.setData (designationDetails);
           mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
           return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
       }
       catch(Exception e){
           return catchException ("getDesignationDetails()", e, "Failed", "Unable to get designation master details.");
       }
    }

    @Override
    public ResponseEntity<Object> getDesignationDetailsById(Integer designationId) {
        try{

            Optional<DesignationMaster> designationMaster = designationMasterRepository.findById(designationId);

            response.setStatus (true);
            response.setData (designationMaster);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        }
        catch(Exception e){
            return catchException ("getDesignationDetailsById()", e, "Failed", "Unable to get designation master details by id.");
        }
    }

    @Override
    public ResponseEntity<Object> addDesignationDetails(DesignationMasterDTO designationMasterDTO) {
        try{

            List<DesignationMaster> designationAlreadyExist = designationMasterRepository.findByDesignationNameLikeAndRecordStatusAndLocationID (
                    designationMasterDTO.getDesignationName (),
                    Constants.ACTIVE_RECORD_STATUS,
                    designationMasterDTO.getLocationID ());

            if(!designationAlreadyExist.isEmpty ()){
                return catchException("addDesignationDetails()",null,"Error","Designation details already exist for given location");
            }
            DesignationMaster designationMaster = toEntity (designationMasterDTO);
            DesignationMaster savedDetails = designationMasterRepository.save (designationMaster);

            response.setStatus (true);
            response.setData (savedDetails);
            response.setMessage ("Designation details saved successfully");
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        }
        catch(Exception e){
            return catchException("addDesignationDetails()",null,"Error","Unable to add designation details.");
        }

    }

    @Override
    public ResponseEntity<Object> editDesignationDetails(Integer designationId, DesignationMasterDTO designationMasterDTO) {
        try{
            Optional<DesignationMaster> designationDetailsById = designationMasterRepository.findById (designationId);

            if(designationDetailsById.isEmpty ()){
                return catchException("editDesignationDetails()",null,"Error","Designation details not found");
            }
            else if(designationDetailsById.get ().getRecordStatus ().equalsIgnoreCase (String.valueOf (Constants.DELETED_RECORD_STATUS)))
            {
                return catchException("editDesignationDetails()",null,"Error","Cannot edit deleted designation details.");
            }
            List<DesignationMaster> designationAlreadyExist = designationMasterRepository.saveAll (designationMasterRepository.findByDesignationNameLikeAndRecordStatusAndLocationID (
                    designationMasterDTO.getDesignationName (),
                    Constants.ACTIVE_RECORD_STATUS,
                    designationMasterDTO.getLocationID ()))
                    .stream ().filter (data -> !Objects.equals (data.getDesignationID (), designationId))
                    .toList ();

            if(!designationAlreadyExist.isEmpty ()){
                return catchException("editDesignationDetails()",null,"Error","Designation details already exist for given location");
            }

            designationDetailsById.get().setDesignationName(designationMasterDTO.getDesignationName());
            designationDetailsById.get().setDescription(designationMasterDTO.getDescription());
            designationDetailsById.get().setDocumentName(designationMasterDTO.getDocumentName());
            designationDetailsById.get().setDocumentImage(designationMasterDTO.getDocumentImage());
            designationDetailsById.get().setModifiedDate(InstantFormatter.InstantFormat (designationMasterDTO.getModifiedDate()));
            designationDetailsById.get().setModifiedBy(designationMasterDTO.getModifiedBy());
            designationDetailsById.get().setModifiedDate(InstantFormatter.InstantFormat (designationMasterDTO.getModifiedDate()));
            designationDetailsById.get().setLocationID(designationMasterDTO.getLocationID());

            DesignationMaster savedDetails = designationMasterRepository.save (designationDetailsById.get ());
            response.setStatus (true);
            response.setData (savedDetails);
            response.setMessage ("Designation details updated successfully");
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        }
        catch(Exception e){
            return catchException("editDesignationDetails()",null,"Error","Unable to edit designation details.");
        }
    }

    @Override
    public ResponseEntity<Object> deleteDesignationDetails(DeleteDetails deleteDetails) {
        try {
            Optional<DesignationMaster> designationMaster = designationMasterRepository.findById (deleteDetails.id ());

            if(designationMaster.isEmpty ()){
                return catchException("deleteDesignationDetails()",null,"Error","Designation details not found");
            }
            else if(designationMaster.get ().getRecordStatus ().equalsIgnoreCase (String.valueOf (Constants.DELETED_RECORD_STATUS))){
                return catchException("deleteDesignationDetails()",null,"Error","Given Designation details already deleted");
            }
            Integer designationDetails = SqlConnectionSetup.getJdbcConnection()
                    .queryForObject("exec spDesignationDetailsForDelete ?;", Integer.class,
                            deleteDetails.id()
                    );
            if(designationDetails >0){
                return catchException("deleteDesignationDetails()", null, "Error",
                        String.format("Given Designation details already mapped to %s employees. Please check and try later.", designationDetails));
            }
            int updateRecordStatusById = designationMasterRepository.updateRecordStatusById(String.valueOf (Constants.DELETED_RECORD_STATUS)
                    ,deleteDetails.id (),deleteDetails.modifiedBy()
                    , InstantFormatter.InstantFormat(deleteDetails.modifiedDate()));

            if(updateRecordStatusById <= 0) {
                return catchException("deleteDesignationDetails()",null,"Error","Designation details not deleted");

            }

            response.setStatus(true);
            response.setMessage("Designation detail deleted successfully");
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"message",STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
        catch(Exception e) {
            return catchException("deleteDesignationDetails()", e, "Error", "Cannot delete given designation details");
        }
    }

    public DesignationMaster toEntity(DesignationMasterDTO dto) {
        DesignationMaster entity = new DesignationMaster();

        entity.setDesignationName(dto.getDesignationName());
        entity.setDescription(dto.getDescription());
        entity.setDocumentName(dto.getDocumentName());
        entity.setDocumentImage(dto.getDocumentImage());
        entity.setCreatedOn (InstantFormatter.InstantFormat (dto.getCreatedDate ()));
        entity.setCreatedBy (dto.getCreatedBy ());
        entity.setRecordStatus(Constants.ACTIVE_RECORD_STATUS);
        entity.setLocationID(dto.getLocationID());
        return entity;
    }

    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
        logger.error("{} Error : {}" , methodName, e);
        response.setStatus(false);
        response.setInformation(new ExceptionBean (Instant.now(), message, description));
        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }
}
