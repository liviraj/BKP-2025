package com.histo.orgmaster.service;

import com.histo.orgmaster.model.MasterFilter;
import com.histo.orgmaster.model.DesignationMasterDTO;
import com.histo.staffmanagementportal.model.DeleteDetails;
import org.springframework.http.ResponseEntity;

public interface DesignationService {

    ResponseEntity<Object> getDesignationDetails(MasterFilter designationFilter);

    ResponseEntity<Object> getDesignationDetailsById(Integer designationId);
    ResponseEntity<Object> addDesignationDetails(DesignationMasterDTO designationMasterDTO);
    ResponseEntity<Object> editDesignationDetails(Integer designationId, DesignationMasterDTO designationMasterDTO);
    ResponseEntity<Object> deleteDesignationDetails(DeleteDetails deleteDetails);
}
