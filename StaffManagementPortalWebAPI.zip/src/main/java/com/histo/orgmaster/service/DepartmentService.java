package com.histo.orgmaster.service;

import com.histo.orgmaster.model.DepartmentModelCreate;
import com.histo.orgmaster.model.DepartmentModelUpdate;
import com.histo.orgmaster.model.MasterFilter;
import com.histo.orgmaster.model.SupervisorModel;
import com.histo.staffmanagementportal.model.DeleteDetails;
import org.springframework.http.ResponseEntity;

public interface DepartmentService {

    ResponseEntity<Object> getDepartmentDetails(MasterFilter filter);
    ResponseEntity<Object> getDepartmentSupervisorDetails(MasterFilter filter);
    ResponseEntity<Object> addDepartmentDetails(DepartmentModelCreate departmentModel);
    ResponseEntity<Object> editDepartmentDetails(Integer departmentId, DepartmentModelUpdate departmentModel);
    ResponseEntity<Object> deleteDepartmentDetails(DeleteDetails deleteDetails);

    ResponseEntity<Object> addDepartmentSupervisorDetails(SupervisorModel departmentModel);
    ResponseEntity<Object> editDepartmentSupervisorDetails(Integer departmentId, SupervisorModel departmentModel);
    ResponseEntity<Object> deleteDepartmentSupervisorDetails(DeleteDetails deleteDetails);
}
