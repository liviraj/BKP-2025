package com.histo.orgmaster.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.orgmaster.entity.Department;

import com.histo.orgmaster.entity.DepartmentSupervisors;
import com.histo.orgmaster.model.*;
import com.histo.orgmaster.model.DepartmentModelCreate;
import com.histo.orgmaster.model.MasterFilter;
import com.histo.orgmaster.repository.DepartmentRepository;
import com.histo.orgmaster.repository.DepartmentSupervisorRepository;
import com.histo.orgmaster.service.DepartmentService;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.model.Constants;
import com.histo.staffmanagementportal.model.DeleteDetails;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Service
public class DepartmentServiceImpl implements DepartmentService {

    private static final Logger logger = LogManager.getLogger(DepartmentServiceImpl.class);
    private static final String STATUS = "status";
    private static final String OPTIONAL_TYPE = "Optional type";
    private final ResponseModel response;
    private MappingJacksonValue mappingJacksonValue;

    private final DepartmentRepository departmentRepository;

    private final DepartmentSupervisorRepository departmentSupervisorRepository;


    public DepartmentServiceImpl(ResponseModel response, DepartmentRepository departmentRepository, DepartmentSupervisorRepository departmentSupervisorRepository) {
        this.response = response;
        this.departmentRepository = departmentRepository;
        this.departmentSupervisorRepository = departmentSupervisorRepository;
    }

    @Override
    public ResponseEntity<Object> getDepartmentDetails(MasterFilter filter) {
        try{

            List<Department> departmentDetails = departmentRepository.findByRecordStatus (filter.getStatus ());

            response.setStatus (true);
            response.setData (departmentDetails);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        }
        catch(Exception e){
            return catchException ("getDepartmentDetails()", e, "Failed", "Unable to get designation master details.");
        }
    }

    @Override
    public ResponseEntity<Object> getDepartmentSupervisorDetails(MasterFilter filter) {
        try{

            List<DepartmentSupervisorDetails> departmentSupervisorDetails = SqlConnectionSetup.getJdbcConnection ()
                    .query ("exec spGetDepartmentSupervisorDetails ?;", BeanPropertyRowMapper.newInstance (DepartmentSupervisorDetails.class),
                            filter.getLocationId ()
                    );

            response.setStatus (true);
            response.setData (departmentSupervisorDetails);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        }
        catch(Exception e){
            return catchException ("getDepartmentDetails()", e, "Failed", "Unable to get department master details.");
        }
    }

    @Override
    public ResponseEntity<Object> addDepartmentDetails(DepartmentModelCreate departmentModel) {
        try {
            Department departmentByName = departmentRepository.findByDepartmentName(departmentModel.getDepartmentName());
            if (departmentByName != null) {
                response.setStatus(false);
                response.setInformation(new ExceptionBean (Instant.now(), "Already Exist", "Department name already exists."));
                mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
            }

            Department department = new Department();
            department.setDepartmentName(departmentModel.getDepartmentName());
            department.setDescription(departmentModel.getDescription());
            department.setModifiedBy(departmentModel.getCreatedBy());
            department.setModifiedDate(InstantFormatter.InstantFormat(departmentModel.getCreatedDate()));
            department.setRecordStatus("A");

            departmentRepository.save(department);
            response.setStatus (true);
            response.setInformation(new ExceptionBean (Instant.now(), "Saved", "Department details added successfully."));
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"information", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            logger.error(e);
            return catchException("addDepartmentDetails()", e, "Failed", "Unable to add department details.");
        }
    }

    @Override
    public ResponseEntity<Object> editDepartmentDetails(Integer departmentId, DepartmentModelUpdate departmentModel) {
        try {
            Department department = departmentRepository.findById(departmentId).orElse(null);
            if (department == null) {
                response.setStatus(false);
                response.setInformation(new ExceptionBean (Instant.now(), "Not Found", "Department details not found."));
                mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.NOT_FOUND);
            }

            Department departmentByName = departmentRepository.findByDepartmentName(departmentModel.getDepartmentName());
            if (departmentByName != null && !departmentByName.getId().equals(departmentId)) {
                response.setStatus(false);
                response.setInformation(new ExceptionBean (Instant.now(), "Already Exist", "Department name already exists."));
                mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
            }
            department.setDepartmentName(departmentModel.getDepartmentName());
            department.setDescription(departmentModel.getDescription());
            department.setModifiedBy(department.getModifiedBy());
            department.setModifiedDate(InstantFormatter.InstantFormat(departmentModel.getModifiedDate()));

            departmentRepository.save(department);
            response.setStatus(true);
            response.setInformation(new ExceptionBean (Instant.now(), "Updated", "Department details updated successfully."));
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }catch (Exception e){
            return catchException("editDepartmentDetails()", e, "Failed", "Unable to edit department details.");
        }
    }

    @Override
    public ResponseEntity<Object> deleteDepartmentDetails(DeleteDetails deleteDetails) {
        try {
            Optional<Department> departmentById = departmentRepository.findById (deleteDetails.id ());

            if(departmentById.isEmpty ()){
                return catchException("deleteDepartmentDetails()",null,"Error","Department details not found");
            }
            else if(departmentById.get ().getRecordStatus ().equalsIgnoreCase (String.valueOf (Constants.DELETED_RECORD_STATUS))){
                return catchException("deleteDepartmentDetails()",null,"Error","Given Department details already deleted");
            }

            Integer departmentDetails = SqlConnectionSetup.getJdbcConnection()
                    .queryForObject("exec spDepartmentDetailsForDelete ?;", Integer.class,
                            deleteDetails.id()
                    );
            if(departmentDetails != null && departmentDetails >0){
                return catchException("deleteDepartmentDetails()", null, "Error",
                        String.format("Given Department details already mapped to %s employees. Please check and try later.", departmentDetails));
            }
            int updateRecordStatusById = departmentRepository.updateRecordStatusById(String.valueOf (Constants.DELETED_RECORD_STATUS)
                    ,deleteDetails.id (),deleteDetails.modifiedBy()
                    , InstantFormatter.InstantFormat(deleteDetails.modifiedDate()));

            if(updateRecordStatusById <= 0) {
                return catchException("deleteDepartmentDetails()",null,"Error","Department details not deleted");

            }

            response.setStatus(true);
            response.setMessage("Department detail deleted successfully");
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"message",STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
        catch(Exception e) {
            return catchException("deleteDepartmentDetails()", e, "Error", "Cannot delete given department details");
        }
    }

    @Override
    public ResponseEntity<Object> addDepartmentSupervisorDetails(SupervisorModel departmentModel) {
        try {
            Optional<DepartmentSupervisors> isAlreadyExist = departmentSupervisorRepository.findByDepartmentIdAndLocationId (departmentModel.getDepartmentId ()
                    , departmentModel.getLocationId ());

            if (isAlreadyExist.isPresent ()) {
                return catchException("addDepartmentSupervisorDetails()",null,"Error","Department supervisor details exists for given department and location.");
            }

            List<DepartmentSupervisors> supervisorAlreadyExist = departmentSupervisorRepository.findByEmployeeId (departmentModel.getSupervisorId ());

            if (!supervisorAlreadyExist.isEmpty () && !departmentModel.getIsNewSupervisor()) {

                response.setStatus(false);
                response.setInformation(new ExceptionBean(Instant.now(), OPTIONAL_TYPE,
                        "Given supervisor already added as supervisor for another department. </br> Are you sure you want save?"));
                mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
            }

            DepartmentSupervisors department = new DepartmentSupervisors ();
            department.setDepartmentId (departmentModel.getDepartmentId ());
            department.setEmployeeId (departmentModel.getSupervisorId ());
            department.setLocationId (departmentModel.getLocationId ());
            department.setCreatedBy (departmentModel.getLastModifiedby ());
            department.setCreatedOn (InstantFormatter.InstantFormat(departmentModel.getLastModifiedOn ()));
//            department.setRecordStatus(Constants.ACTIVE_RECORD_STATUS);

            departmentSupervisorRepository.save(department);
            response.setStatus(true);
            response.setMessage("Department supervisor details added successfully");
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"message",STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException("addDepartmentSupervisorDetails()", e, "Failed", "Unable to add department supervisor details.");
        }
    }

    public ResponseEntity<Object> editDepartmentSupervisorDetails(Integer supervisorDetailId, SupervisorModel departmentModel) {
        try {

            Optional<DepartmentSupervisors> departmentSupervisorById = departmentSupervisorRepository.findById (supervisorDetailId);

            if (departmentSupervisorById.isEmpty ()) {
                return catchException("editDepartmentSupervisorDetails()",null,"Error","Department supervisor details not foumd.");
            }

            Optional<DepartmentSupervisors> isAlreadyExist = departmentSupervisorRepository.findByDepartmentIdAndLocationIdAndAutoIdNot (departmentModel.getDepartmentId ()
                    , departmentModel.getLocationId (),supervisorDetailId);

            if (isAlreadyExist.isPresent ()) {
                return catchException("editDepartmentSupervisorDetails()",null,"Error","Department supervisor details exists for given department and location.");
            }

            List<DepartmentSupervisors> supervisorAlreadyExist = departmentSupervisorRepository.findByEmployeeId (departmentModel.getSupervisorId ());

            boolean duplicateValue = supervisorAlreadyExist.stream ().anyMatch (data -> !data.getAutoId ().equals (supervisorDetailId));

            if (!supervisorAlreadyExist.isEmpty () && duplicateValue && !departmentModel.getIsNewSupervisor()) {
                response.setStatus(false);
                response.setInformation(new ExceptionBean(Instant.now(), OPTIONAL_TYPE,
                        "Given supervisor already added as supervisor for another department. </br> Are you sure you want save?"));
                mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
            }

            departmentSupervisorById.get().setEmployeeId (departmentModel.getSupervisorId ());
            departmentSupervisorById.get().setDepartmentId (departmentModel.getDepartmentId ());
            departmentSupervisorById.get().setModifiedBy (departmentModel.getLastModifiedby ());
            departmentSupervisorById.get().setModifiedOn (InstantFormatter.InstantFormat(departmentModel.getLastModifiedOn ()));

            departmentSupervisorRepository.save(departmentSupervisorById.get ());
            response.setStatus(true);
            response.setMessage("Updated Department supervisor details successfully");
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"message",STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException("editDepartmentSupervisorDetails()", e, "Failed", "Unable to edit department supervisor details.");
        }
    }

    @Override
    public ResponseEntity<Object> deleteDepartmentSupervisorDetails(DeleteDetails deleteDetails) {
        try {
            Optional<DepartmentSupervisors> departmentById = departmentSupervisorRepository.findById (deleteDetails.id ());

            if(departmentById.isEmpty ()){
                return catchException("deleteDepartmentSupervisorDetails()",null,"Error","Department supervisor details not found");
            }

            int updateRecordStatusById = departmentSupervisorRepository.updateModifiedByById(deleteDetails.id (),deleteDetails.modifiedBy()
                    , InstantFormatter.InstantFormat(deleteDetails.modifiedDate()));

            if(updateRecordStatusById <= 0) {
                return catchException("deleteDepartmentSupervisorDetails()",null,"Error","Department supervisor details not deleted");

            }

            departmentSupervisorRepository.delete (departmentById.get ());

            response.setStatus(true);
            response.setMessage("Department Supervisor detail deleted successfully");
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"message",STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
        catch(Exception e) {
            return catchException("deleteDepartmentSupervisorDetails()", e, "Error", "Cannot delete given department supervisor details");
        }
    }

    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
        logger.error("{} Error : {}" , methodName, e);
        response.setStatus(false);
        response.setInformation(new ExceptionBean (Instant.now(), message, description));
        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }
}
