package com.histo.orgmaster.entity;

import com.histo.staffmanagementportal.util.InstantConverter;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "DesignationMaster")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DesignationMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer designationID;

    @Column(nullable = false, length = 500)
    private String designationName;

    @Column(length = 5000)
    private String description;

    @Column(nullable = false)
    private Integer modifiedBy;

    @Column(nullable = false)
    @Convert(converter = InstantConverter.class)
    private Instant modifiedDate;

    @Column(nullable = false)
    private Integer createdBy;

    @Column(nullable = false)
    @Convert(converter = InstantConverter.class)
    private Instant createdOn;

    @Column(nullable = false, length = 1)
    private String recordStatus;

    private Byte locationID;

    @Column(name = "DocumentName")
    private String documentName;

    @Lob
    @Column(name = "DocumentImage")
    private byte[] documentImage;

    // Getters and Setters
}
