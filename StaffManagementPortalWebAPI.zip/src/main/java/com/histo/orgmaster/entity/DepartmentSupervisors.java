package com.histo.orgmaster.entity;

import javax.persistence.*;

import com.histo.staffmanagementportal.util.InstantConverter;
import lombok.*;

import java.time.Instant;

@Entity
@Table(name = "DepartmentSupervisors")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DepartmentSupervisors {



    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "AutoID")
    private Integer autoId;

    @Column(name = "EmployeeID")
    private Integer employeeId;

    @Column(name = "DepartmentID")
    private Integer departmentId;

    @Column(name = "LocationID")
    private Integer locationId;

    @Column(name = "secondarySupervisorEmployeeId")
    private Integer secondarySupervisorEmployeeId;

    @Column(name = "createdOn")
    @Convert(converter = InstantConverter.class)
    private Instant createdOn;

    @Column(name = "modifiedOn")
    @Convert(converter = InstantConverter.class)
    private Instant modifiedOn;

    @Column(name = "createdBy")
    private Integer createdBy;

    @Column(name = "modifiedBy")
    private Integer modifiedBy;
    
//    @Column(name = "RecordStatus", nullable = false)
//    private String recordStatus;
}
