package com.histo.orgmaster.entity;


import com.histo.staffmanagementportal.util.InstantConverter;
import lombok.*;

import javax.persistence.*;

import java.time.Instant;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Department {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DepartmentID", nullable = false)
    private Integer id;

    @Column(name = "DepartmentName", nullable = false, length = 50)
    private String departmentName;

    @Column(name = "Description", length = 500)
    private String description;

    @Column(nullable = false)
    private Integer modifiedBy;

    @Column(nullable = false)
    @Convert(converter = InstantConverter.class)
    private Instant modifiedDate;

    @Column(nullable = false)
    private Integer createdBy;

    @Column(nullable = false)
    @Convert(converter = InstantConverter.class)
    private Instant createdOn;

    @Column(name = "RecordStatus", nullable = false)
    private String recordStatus;

    @Column(name = "HierarchyOrder")
    private Integer hierarchyOrder;

    @Column(name = "ParentDepartmentID")
    private Integer parentDepartmentID;

    @Column(name = "SortOrder")
    private Integer sortOrder;

}