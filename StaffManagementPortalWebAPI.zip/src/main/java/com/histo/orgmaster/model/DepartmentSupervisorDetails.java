package com.histo.orgmaster.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DepartmentSupervisorDetails {

    private Integer autoId;
    private Integer employeeId;
    private Integer departmentID;
    private String departmentName;
    private String description;
    private String supervisorName;
    private String location;

}
