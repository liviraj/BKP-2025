package com.histo.orgmaster.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DesignationMasterDTO {

    private Integer designationID;
    private String designationName;
    private String description;
    private Integer modifiedBy;
    private String modifiedDate;
    private Integer createdBy;
    private String createdDate;
    private String recordStatus;
    private Byte locationID;
    private Byte displayOrder;
    private String roleAndResponsibilities;
    private String documentName;
    private byte[] documentImage;
    private Boolean isFileView;
}