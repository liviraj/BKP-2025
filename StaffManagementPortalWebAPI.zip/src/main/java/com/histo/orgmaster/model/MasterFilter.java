package com.histo.orgmaster.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class MasterFilter {

    private Integer locationId;
    private String status;
}
