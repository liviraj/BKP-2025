package com.histo.orgmaster.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class SupervisorModel {

    private Integer departmentId;
    private Integer supervisorId;
    private Integer locationId;
    private Integer lastModifiedby;
    private String lastModifiedOn;
    private Boolean isNewSupervisor;
}
