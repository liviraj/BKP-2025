package com.histo.orgmaster.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DepartmentModelCreate {
    private String departmentName;
    private String description;
    private Integer createdBy;
    private String createdDate;
}
