package com.histo.orgmaster.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DepartmentModelUpdate {
    private String departmentName;
    private String description;
    private Integer modifiedBy;
    private String modifiedDate;
}
