package com.histo.orgmaster.model;

public class DepartmentDetails {

    private String departmentName;
    private String description;
    private String status;
}
