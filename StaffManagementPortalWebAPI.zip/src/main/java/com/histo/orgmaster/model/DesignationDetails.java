package com.histo.orgmaster.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DesignationDetails {

    private Integer designationId;
    private String designationName;
    private String description;
    private String modifiedBy;
    private String modifiedDate;
    private String createdBy;
    private String createdOn;
    private String recordStatus;
    private Integer locationID;
    private String locationName;
    private Integer displayOrder;
    private String roleAndResponsibilities;
    private String documentName;
    private Boolean isFileView;
}
