package com.histo.deputation.repository;

import com.histo.deputation.entity.DeputationHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface DeputationHistoryRepository extends JpaRepository<DeputationHistory, Integer> {

    @Query("select d from DeputationHistory d where employeeId = ?1 and ?2 between DeputationFrom and DeputationTo")
    Optional<DeputationHistory> findByEmployeeIDAndDeputationDate(Integer employeeID, Instant deputationDate);

    @Transactional
    @Modifying
    @Query( """
    		update DeputationHistory set recordStatus = ?1, modifiedBy = ?2 , modifiedOn =?3 where deputationId = ?4
    		""" )
    int updateDepuationDetails(String recordStatus, Integer modifiedBy, LocalDateTime modifiedOn, Integer deputationId);

    List<DeputationHistory> findByEmployeeIdAndDeputationLocationIdAndDeputationFromAndRecordStatus(Integer employeeId, Integer deputationLocationId, LocalDateTime deputationFrom,String recordStatus);


}