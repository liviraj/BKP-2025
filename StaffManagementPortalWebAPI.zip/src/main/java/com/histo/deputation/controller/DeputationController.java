package com.histo.deputation.controller;

import com.azure.core.annotation.QueryParam;
import com.histo.deputation.model.DeputationFilterModel;
import com.histo.deputation.model.DeputationHistoryDTO;
import com.histo.deputation.service.DeputationService;
import com.histo.staffmanagementportal.model.DeleteDetails;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/deputation")
public class DeputationController {

    private  final DeputationService deputationService;

    public DeputationController(DeputationService deputationService) {
        this.deputationService = deputationService;
    }


    @GetMapping
    public ResponseEntity<Object> getDeputationDetails(@QueryParam ("input")DeputationFilterModel filterModel){
        return deputationService.getDeptutationHistory (filterModel);
    }

    @GetMapping("{deputationId}")
    public ResponseEntity<Object> getDeputationDetailsById(@PathVariable("deputationId")Integer deputationId){
        return deputationService.getDeputationDetailsForUpdate (deputationId);
    }

    @PostMapping
    ResponseEntity<Object> addEmployeeDeputationDetails(@RequestBody DeputationHistoryDTO deputationHistoryDTO){
        return  deputationService.addDeputationDetails (deputationHistoryDTO);
    }
    @PutMapping("{deputationId}")
    ResponseEntity<Object> editEmployeeDeputationDetails(@PathVariable("deputationId")Integer deputationId, @RequestBody DeputationHistoryDTO deputationHistoryDTO){
        return  deputationService.editDeputationDetails (deputationId,deputationHistoryDTO);
    }
    @DeleteMapping("{deputationId}")
    ResponseEntity<Object> deleteEmployeeDeputationDetails(@PathVariable("deputationId")Integer deputationId, @RequestBody DeleteDetails deleteDetails){
        return  deputationService.deleteDeputationDetails (deputationId,deleteDetails);
    }

}
