package com.histo.deputation.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DeputationFilterModel {

    private String fromDate;
    private String toDate;
    private Integer employeeId;
    private Integer deputationLocationId;
    private String status;

}
