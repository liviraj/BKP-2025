package com.histo.deputation.model;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Data
public class DeputationHistoryDTO {

    private Integer deputationId;
    private Integer locationId;
    private Integer employeeId;
    private String deputationLocation;
    private String deputationSite;
    @NotNull
    private String deputationFrom;
    @NotNull
    private String deputationTo;
    private String departureDate;
    private String arrivalDate;
    private String visaValidityFrom;
    private String visaValidityTo;
    private String travelDocumentName;
    private byte[] travelDocument;
    private String remarks;
    private Integer deputationLocationId;
    private Integer addedBy;
    private String addedOn;
    private Integer modifiedBy;
    private String modifiedOn;
}
