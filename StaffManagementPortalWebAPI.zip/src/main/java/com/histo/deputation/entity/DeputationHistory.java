package com.histo.deputation.entity;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.histo.staffmanagementportal.util.InstantConverter;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.Instant;
import java.time.LocalDateTime;

@Entity
@Table(name = "DeputationHistory")
@Data
@NoArgsConstructor
public class DeputationHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DeputationID", nullable = false)
    private Integer deputationId;

    @Column(name = "LocationID")
    private Integer locationId;

    @Column(name = "EmployeeID", nullable = false)
    private Integer employeeId;

    @Column(name = "DeputationLocation", nullable = false, length = 100)
    private String deputationLocation;

    @Column(name = "DeputationSite", nullable = false, length = 100)
    private String deputationSite;

    @Column(name = "DeputationFrom", nullable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private LocalDateTime deputationFrom;

    @Column(name = "DeputationTo", nullable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private LocalDateTime deputationTo;

    @Column(name = "DepartureDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private LocalDateTime departureDate;

    @Column(name = "ArrivalDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private LocalDateTime arrivalDate;

    @Column(name = "VisaValidityFrom")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private LocalDateTime visaValidityFrom;

    @Column(name = "VisaValidityTo")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private LocalDateTime visaValidityTo;

    @Column(name = "TravelDocumentName", length = 100)
    private String travelDocumentName;

    @Lob
    @Column(name = "TravelDocument")
    private byte[] travelDocument;

    @Column(name = "Remarks", columnDefinition = "TEXT")
    private String remarks;

    @Column(name = "DeputationLocationId")
    private Integer deputationLocationId;

    @Column(name = "RecordStatus",nullable = false)
    private String recordStatus;

    @Column(name = "AddedBy")
    private Integer addedBy;

    @Column(name = "AddedOn")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private LocalDateTime addedOn;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @Column(name = "ModifiedOn")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private LocalDateTime modifiedOn;
}

