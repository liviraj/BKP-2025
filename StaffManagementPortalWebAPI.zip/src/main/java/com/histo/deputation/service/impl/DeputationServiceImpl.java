package com.histo.deputation.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.deputation.entity.DeputationHistory;
import com.histo.deputation.model.DeputationFilterModel;
import com.histo.deputation.model.DeputationHistoryDTO;
import com.histo.deputation.repository.DeputationHistoryRepository;
import com.histo.deputation.service.DeputationService;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.model.Constants;
import com.histo.staffmanagementportal.model.DeleteDetails;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.model.ResultSetMapper;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class DeputationServiceImpl implements DeputationService {

    private static final Logger logger = LogManager.getLogger (DeputationServiceImpl.class);
    private static final String STATUS = "status";
    private final ResponseModel response;
    private MappingJacksonValue mappingJacksonValue;
    private final DeputationHistoryRepository deputationHistoryRepository;

    public DeputationServiceImpl(ResponseModel response, DeputationHistoryRepository deputationHistoryRepository) {
        this.response = response;
        this.deputationHistoryRepository = deputationHistoryRepository;
    }

    @Override
    public ResponseEntity<Object> getDeptutationHistory(DeputationFilterModel filterModel) {
        try {
            List<Object> deputationDetails = SqlConnectionSetup.getJdbcConnection ().query ("exec spGetEmployeeDeputationHistory ?,?,?,?,?;", new ResultSetMapper (),
                    filterModel.getEmployeeId (),
                    filterModel.getFromDate (),
                    filterModel.getToDate (),
                    filterModel.getDeputationLocationId (),
                    filterModel.getStatus ());

            response.setStatus (true);
            response.setData (deputationDetails);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("getDeptutationHistory()", e, "Failed", "Unable to get deputationDetails types");
        }
    }

    @Override
    public ResponseEntity<Object> getDeputationDetailsForUpdate(Integer deputationId) {
        try{
            Optional<DeputationHistory> deputationHistory = deputationHistoryRepository.findById (deputationId);

            if(deputationHistory.isEmpty ()){
                return catchException ("getDeputationDetailsForUpdate()", null, "Failed", "Deputation Details not present.");
            }


            response.setStatus (true);
            response.setData (deputationHistory);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("getDeputationDetailsForUpdate()", e, "Failed", "Unable to get Deputation Details");
        }
    }

    @Override
    public ResponseEntity<Object> addDeputationDetails(DeputationHistoryDTO deputationHistoryDTO) {
        try {
            return addOrEditDeputationDetail (0, new DeputationHistory (), deputationHistoryDTO);

        } catch (Exception e) {
            return catchException ("addDeputationDetails()", e, "Failed", "Cannot add employee deputation details.");
        }
    }

    @Override
    public ResponseEntity<Object> editDeputationDetails(Integer deputationId, DeputationHistoryDTO deputationHistoryDTO) {
        try {

            Optional<DeputationHistory> deputationHistory = deputationHistoryRepository.findById (deputationId);

            if (deputationHistory.isEmpty ()) {
                return catchException ("editDeputationDetails()", null, "Failed", "Deputation details not found for given Id.");
            }

            return addOrEditDeputationDetail (deputationId, deputationHistory.get (), deputationHistoryDTO);

        } catch (Exception e) {
            return catchException ("editDeputationDetails()", e, "Failed", "Cannot add employee deputation details.");
        }
    }

    @Override
    public ResponseEntity<Object> deleteDeputationDetails(Integer deputationId, DeleteDetails deleteDetails) {
        try {
            Optional<DeputationHistory> deputationHistoryById = deputationHistoryRepository.findById (deputationId);
            if (deputationHistoryById.isEmpty ()) {
                return catchException ("deleteDeputationDetails()", null, "Failed", "No value present for given id.");
            }

            if (!Constants.ACTIVE_RECORD_STATUS.equalsIgnoreCase (deputationHistoryById.get ().getRecordStatus ())) {
                return catchException ("deleteDeputationDetails()", null, "Failed", "Already deleted given deputation details.");
            }

            int updateDepuationDetails = deputationHistoryRepository
                    .updateDepuationDetails (
                            String.valueOf (Constants.DELETED_RECORD_STATUS),
                            deleteDetails.modifiedBy (),
                            InstantFormatter.localDateTimeFormat (deleteDetails.modifiedDate ()),
                            deputationId);

            if (updateDepuationDetails <= 0) {
                return catchException ("deleteDeputationDetails()", null, "Error", "unable to delete deputation details.");
            }

            response.setStatus (true);
            response.setMessage ("Employee deputation details deleted successfully");
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("deleteDeputationDetails()", e, "Failed", "Unable to delete employee deputation details.");
        }
    }

    private ResponseEntity<Object>  addOrEditDeputationDetail(Integer deputationId, DeputationHistory deputationHistory, DeputationHistoryDTO deputationHistoryDTO) {
        try {
            LocalDateTime deputationFrom = InstantFormatter.localDateTimeFormat (deputationHistoryDTO.getDeputationFrom ());
            LocalDateTime deputationTo = InstantFormatter.localDateTimeFormat (deputationHistoryDTO.getDeputationTo ());
            LocalDateTime departureDate = InstantFormatter.localDateTimeFormat (deputationHistoryDTO.getDepartureDate ());
            LocalDateTime arrivalDate = InstantFormatter.localDateTimeFormat (deputationHistoryDTO.getArrivalDate ());
            LocalDateTime visaValidFrom = InstantFormatter.localDateTimeFormat (deputationHistoryDTO.getVisaValidityFrom ());
            LocalDateTime visaValidTo = InstantFormatter.localDateTimeFormat (deputationHistoryDTO.getVisaValidityTo ());

            List<DeputationHistory> deputationDetails = deputationHistoryRepository.findByEmployeeIdAndDeputationLocationIdAndDeputationFromAndRecordStatus (
                    deputationHistoryDTO.getEmployeeId (),
                    deputationHistoryDTO.getDeputationLocationId (),
                    deputationFrom,
                    Constants.ACTIVE_RECORD_STATUS);

            boolean isAlreadyExist = deputationDetails.stream ().filter (data -> !data.getDeputationId ().equals (deputationId)).findFirst ().isPresent ();

            if (!deputationDetails.isEmpty () && isAlreadyExist) {
                return catchException ("addOrEditDeputationDetail()", null, "Failed", "Deputation details already exist for given deputation period.");
            }

            if (deputationFrom.isAfter (deputationTo)) {
                return catchException ("addOrEditDeputationDetail()", null, "Failed", "Deputation From Date should be before Deputation To Date.");
            } else if (departureDate != null && arrivalDate !=  null &&  departureDate.isAfter (arrivalDate)) {
                return catchException ("addOrEditDeputationDetail()", null, "Failed", "Departure Date should be before arrival Date.");
            } else if (visaValidFrom != null && visaValidTo != null && visaValidFrom.isAfter (visaValidTo)) {
                return catchException ("addOrEditDeputationDetail()", null, "Failed", "Visa Valid FromDate should be before Visa valid ToDate.");
            } else if (deputationHistoryDTO.getLocationId ().equals (deputationHistoryDTO.getDeputationLocationId ())) {
                return catchException ("addOrEditDeputationDetail()", null, "Failed", "Employee Work location should not be same as employee deputation location.");
            }

            deputationHistory.setDeputationId (deputationHistoryDTO.getDeputationId ());
            deputationHistory.setLocationId (deputationHistoryDTO.getLocationId ());
            deputationHistory.setEmployeeId (deputationHistoryDTO.getEmployeeId ());
            deputationHistory.setDeputationLocation (deputationHistoryDTO.getDeputationLocation ());
            deputationHistory.setDeputationSite (deputationHistoryDTO.getDeputationSite ());
            deputationHistory.setDeputationFrom (deputationFrom);
            deputationHistory.setDeputationTo (deputationTo);
            deputationHistory.setDepartureDate (departureDate);
            deputationHistory.setArrivalDate (arrivalDate);
            deputationHistory.setVisaValidityFrom (visaValidFrom);
            deputationHistory.setVisaValidityTo (visaValidTo);
            deputationHistory.setTravelDocumentName (deputationHistoryDTO.getTravelDocumentName ());
            deputationHistory.setTravelDocument (deputationHistoryDTO.getTravelDocument ());
            deputationHistory.setRemarks (deputationHistoryDTO.getRemarks ());
            deputationHistory.setDeputationLocationId (deputationHistoryDTO.getDeputationLocationId ());
            deputationHistory.setAddedBy (deputationHistoryDTO.getAddedBy ());
            deputationHistory.setAddedOn (InstantFormatter.localDateTimeFormat (deputationHistoryDTO.getAddedOn ()));
            deputationHistory.setModifiedBy (deputationHistoryDTO.getModifiedBy ());
            deputationHistory.setModifiedOn (InstantFormatter.localDateTimeFormat (deputationHistoryDTO.getModifiedOn ()));
            deputationHistory.setRecordStatus (Constants.ACTIVE_RECORD_STATUS);

            DeputationHistory savedDeputationDetails = deputationHistoryRepository.save (deputationHistory);

            response.setStatus (true);
            response.setData (savedDeputationDetails);
            response.setMessage (deputationId.equals (0) ? "Deputation details added successfully." : "Deputation details updated successfully.");
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException ("addOrEditDeputationDetail()", e, "Failed", "Cannot add/edit employee deputation details.");
        }
    }

    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
        logger.error ("{} Error : {}", methodName, e);
        response.setStatus (false);
        response.setInformation (new ExceptionBean (Instant.now (), message, description));
        mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"information", STATUS});
        return new ResponseEntity<> (mappingJacksonValue, HttpStatus.CONFLICT);
    }
}
