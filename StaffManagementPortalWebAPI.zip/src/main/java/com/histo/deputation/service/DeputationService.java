package com.histo.deputation.service;

import com.histo.deputation.model.DeputationFilterModel;
import com.histo.deputation.model.DeputationHistoryDTO;
import com.histo.staffmanagementportal.model.DeleteDetails;
import org.springframework.http.ResponseEntity;

public interface DeputationService {

    ResponseEntity<Object> getDeptutationHistory(DeputationFilterModel filterModel);
    ResponseEntity<Object> getDeputationDetailsForUpdate(Integer deputationId);
    ResponseEntity<Object> addDeputationDetails(DeputationHistoryDTO deputationHistoryDTO);
    ResponseEntity<Object> editDeputationDetails(Integer deputationId,DeputationHistoryDTO deputationHistoryDTO);
    ResponseEntity<Object> deleteDeputationDetails(Integer deputationId, DeleteDetails deleteDetails);
}
