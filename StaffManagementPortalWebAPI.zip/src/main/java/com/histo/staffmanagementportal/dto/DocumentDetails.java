package com.histo.staffmanagementportal.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@NoArgsConstructor
@ToString
public class DocumentDetails {

    private Integer documentDetailId;
    private String documentName;
    private byte[] documentBinary;
    private String documentType;
    private Character recordStatus;
}
