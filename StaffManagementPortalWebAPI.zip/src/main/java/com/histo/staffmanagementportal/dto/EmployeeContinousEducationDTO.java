package com.histo.staffmanagementportal.dto;

import java.util.Arrays;
import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.histo.staffmanagementportal.intranet.entity.Document;
import io.swagger.annotations.ApiModelProperty;

public class EmployeeContinousEducationDTO {

	@NotNull
	 private Integer employeeId;
	@NotBlank
	 private String courseName;
	@NotBlank
	 private String conductedBy;
	@NotBlank
	 private String sponsoredBy;
	@NotBlank
	@ApiModelProperty(example = "23/01/2022~20/01/2023")
	 private String courseDuration;
	
	 private String courseDescription;
	@NotBlank
	 private String courseCategory;
	 private Integer modifiedBy;
	 private String employeeImage;
	 private byte[] employeeImageBinary;

	 private List<Document> documentDetails;

	 private Integer continuousEducationId;
	 
	public EmployeeContinousEducationDTO() {
		super();
	}

	public List<Document> getDocumentList() {
		return documentDetails;
	}

	public void setDocumentList(List<Document> documentList) {
		this.documentDetails = documentList;
	}

	public Integer getContinuousEducationId() {
		return continuousEducationId;
	}

	public void setContinuousEducationId(Integer continuousEducationId) {
		this.continuousEducationId = continuousEducationId;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getConductedBy() {
		return conductedBy;
	}

	public void setConductedBy(String conductedBy) {
		this.conductedBy = conductedBy;
	}

	public String getSponsoredBy() {
		return sponsoredBy;
	}

	public void setSponsoredBy(String sponsoredBy) {
		this.sponsoredBy = sponsoredBy;
	}

	public String getCourseDuration() {
		return courseDuration;
	}

	public void setCourseDuration(String courseDuration) {
		this.courseDuration = courseDuration;
	}

	public String getCourseDescription() {
		return courseDescription;
	}

	public void setCourseDescription(String courseDescription) {
		this.courseDescription = courseDescription;
	}

	public String getCourseCategory() {
		return courseCategory;
	}

	public void setCourseCategory(String courseCategory) {
		this.courseCategory = courseCategory;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getEmployeeImage() {
		return employeeImage;
	}

	public void setEmployeeImage(String employeeImage) {
		this.employeeImage = employeeImage;
	}

	public byte[] getEmployeeImageBinary() {
		return employeeImageBinary;
	}

	public void setEmployeeImageBinary(byte[] employeeImageBinary) {
		this.employeeImageBinary = employeeImageBinary;
	}

	@Override
	public String toString() {
		return String.format(
				"EmployeeContinuousEducationDTO [employeeId=%s, courseName=%s, conductedBy=%s, sponsoredBy=%s, courseDuration=%s, courseDescription=%s, courseCategory=%s, modifiedBy=%s, employeeImage=%s, employeeImageBinary=%s]",
				employeeId, courseName, conductedBy, sponsoredBy, courseDuration, courseDescription, courseCategory,
				modifiedBy, employeeImage, Arrays.toString(employeeImageBinary));
	}
	
	 
}
