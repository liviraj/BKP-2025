package com.histo.staffmanagementportal.dto;

import javax.validation.constraints.NotNull;

public class EmployeeLeaveRequestDTO {
	
	@NotNull
    private Integer employeeId;

	@NotNull
    private String leaveFrom;
	@NotNull
    private String leaveTo;
    private Integer typeofLeave;
    private String remarks;
    private Integer leaveEnteredBy;
    @NotNull
    private String leaveFromForH;
    @NotNull
    private String leaveToForH;
    private String status;
    private Integer leaveModifiedBy;
    private Character isCompensatory;
    private String leaveEnteredOn;
    private Integer leaveRequestDetailId;
    private String modifiedOn;
    
	public EmployeeLeaveRequestDTO() {
		super();
	}

	public EmployeeLeaveRequestDTO( Integer employeeId,  String leaveFrom,  String leaveTo,
			 String leaveFromForH,  String leaveToForH) {
		super();
		this.employeeId = employeeId;
		this.leaveFrom = leaveFrom;
		this.leaveTo = leaveTo;
		this.leaveFromForH = leaveFromForH;
		this.leaveToForH = leaveToForH;
	}

	public Integer getLeaveRequestDetailId() {
		return leaveRequestDetailId;
	}

	public void setLeaveRequestDetailId(Integer leaveRequestDetailId) {
		this.leaveRequestDetailId = leaveRequestDetailId;
	}

	public String getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getLeaveFrom() {
		return leaveFrom;
	}

	public void setLeaveFrom(String leaveFrom) {
		this.leaveFrom = leaveFrom;
	}

	public String getLeaveTo() {
		return leaveTo;
	}

	public void setLeaveTo(String leaveTo) {
		this.leaveTo = leaveTo;
	}

	public Integer getTypeofLeave() {
		return typeofLeave;
	}

	public void setTypeofLeave(Integer typeofLeave) {
		this.typeofLeave = typeofLeave;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getLeaveEnteredBy() {
		return leaveEnteredBy;
	}

	public void setLeaveEnteredBy(Integer leaveEnteredBy) {
		this.leaveEnteredBy = leaveEnteredBy;
	}

	public String getLeaveFromForH() {
		return leaveFromForH;
	}

	public void setLeaveFromForH(String leaveFromForH) {
		this.leaveFromForH = leaveFromForH;
	}

	public String getLeaveToForH() {
		return leaveToForH;
	}

	public void setLeaveToForH(String leaveToForH) {
		this.leaveToForH = leaveToForH;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getLeaveModifiedBy() {
		return leaveModifiedBy;
	}

	public void setLeaveModifiedBy(Integer leaveModifiedBy) {
		this.leaveModifiedBy = leaveModifiedBy;
	}

	public Character getIsCompensatory() {
		return isCompensatory;
	}

	public void setIsCompensatory(Character isCompensatory) {
		this.isCompensatory = isCompensatory;
	}

	public String getLeaveEnteredOn() {
		return leaveEnteredOn;
	}

	public void setLeaveEnteredOn(String leaveEnteredOn) {
		this.leaveEnteredOn = leaveEnteredOn;
	}    

}
