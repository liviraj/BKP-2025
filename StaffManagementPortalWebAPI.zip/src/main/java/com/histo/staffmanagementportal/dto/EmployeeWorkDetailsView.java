package com.histo.staffmanagementportal.dto;

public class EmployeeWorkDetailsView {

	private Integer employeeWorkId;
    private Integer employeeID;  
    private String doj;
    private Integer designationID;
    private Integer gradeID;
    private String workStationID;
    private String systemID;
    private String laptopID;
    private Integer reportingTo;
    private Integer departmentID;
    private Character recordStatus;
    private Integer locationID;
    private Integer employmentType;
    private String visaType;
    private String placeofIssue;
    private String issueDateWork;
    private String expiryDateWork;
    private String countryIssued;
    private Integer currentLocation;
    private String confirmationDate;
    private String relievingDate;
    private String employmentStatus;
    private Boolean clinicalHandler;
    private String roleName;
    
	public EmployeeWorkDetailsView() {
		super();
	}

	public Integer getEmployeeWorkId() {
		return employeeWorkId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public void setEmployeeWorkId(Integer employeeWorkId) {
		this.employeeWorkId = employeeWorkId;
	}

	public Integer getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(Integer employeeID) {
		this.employeeID = employeeID;
	}

	public String getDoj() {
		return doj;
	}

	public void setDoj(String doj) {
		this.doj = doj;
	}

	public Integer getDesignationID() {
		return designationID;
	}

	public void setDesignationID(Integer designationID) {
		this.designationID = designationID;
	}

	public Integer getGradeID() {
		return gradeID;
	}

	public void setGradeID(Integer gradeID) {
		this.gradeID = gradeID;
	}

	public String getWorkStationID() {
		return workStationID;
	}

	public void setWorkStationID(String workStationID) {
		this.workStationID = workStationID;
	}

	public String getSystemID() {
		return systemID;
	}

	public void setSystemID(String systemID) {
		this.systemID = systemID;
	}

	public String getLaptopID() {
		return laptopID;
	}

	public void setLaptopID(String laptopID) {
		this.laptopID = laptopID;
	}

	public Integer getReportingTo() {
		return reportingTo;
	}

	public void setReportingTo(Integer reportingTo) {
		this.reportingTo = reportingTo;
	}

	public Integer getDepartmentID() {
		return departmentID;
	}

	public void setDepartmentID(Integer departmentID) {
		this.departmentID = departmentID;
	}
	
	public Character getRecordStatus() {
		return recordStatus;
	}

	public void setRecordStatus(Character recordStatus) {
		this.recordStatus = recordStatus;
	}

	public Integer getLocationID() {
		return locationID;
	}

	public void setLocationID(Integer locationID) {
		this.locationID = locationID;
	}

	public Integer getEmploymentType() {
		return employmentType;
	}

	public void setEmploymentType(Integer employmentType) {
		this.employmentType = employmentType;
	}

	public String getVisaType() {
		return visaType;
	}

	public void setVisaType(String visaType) {
		this.visaType = visaType;
	}

	public String getPlaceofIssue() {
		return placeofIssue;
	}

	public void setPlaceofIssue(String placeofIssue) {
		this.placeofIssue = placeofIssue;
	}

	public String getIssueDateWork() {
		return issueDateWork;
	}

	public void setIssueDateWork(String issueDateWork) {
		this.issueDateWork = issueDateWork;
	}

	public String getExpiryDateWork() {
		return expiryDateWork;
	}

	public void setExpiryDateWork(String expiryDateWork) {
		this.expiryDateWork = expiryDateWork;
	}

	public String getCountryIssued() {
		return countryIssued;
	}

	public void setCountryIssued(String countryIssued) {
		this.countryIssued = countryIssued;
	}

	public Integer getCurrentLocation() {
		return currentLocation;
	}

	public void setCurrentLocation(Integer currentLocation) {
		this.currentLocation = currentLocation;
	}

	public String getConfirmationDate() {
		return confirmationDate;
	}

	public void setConfirmationDate(String confirmationDate) {
		this.confirmationDate = confirmationDate;
	}

	public String getRelievingDate() {
		return relievingDate;
	}

	public void setRelievingDate(String relievingDate) {
		this.relievingDate = relievingDate;
	}

	public String getEmploymentStatus() {
		return employmentStatus;
	}

	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}

	public Boolean getClinicalHandler() {
		return clinicalHandler;
	}

	public void setClinicalHandler(Boolean clinicalHandler) {
		this.clinicalHandler = clinicalHandler;
	}
	
}
