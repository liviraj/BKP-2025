package com.histo.staffmanagementportal.dto;

public class EmployeeQualificationViewDTO {
	
    private Integer employeeid;             
    private String qualification;         
    private String institution;            
    private String majorSubject;           
    private String type;                   
    private String value;                  
    private String courseDuration;        
    private String courseStartDate;        
    private String courseEndDate;          
    private String university;                                     
    private Integer empQualificationId;                   
    private String isPartOfCLEP;
    private String location;               
 
    
	public EmployeeQualificationViewDTO() {
		super();
	}

	public Integer getEmployeeid() {
		return employeeid;
	}

	public void setEmployeeid(Integer employeeid) {
		this.employeeid = employeeid;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getInstitution() {
		return institution;
	}

	public void setInstitution(String institution) {
		this.institution = institution;
	}

	public String getMajorSubject() {
		return majorSubject;
	}

	public void setMajorSubject(String majorSubject) {
		this.majorSubject = majorSubject;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getCourseDuration() {
		return courseDuration;
	}

	public void setCourseDuration(String courseDuration) {
		this.courseDuration = courseDuration;
	}

	public String getCourseStartDate() {
		return courseStartDate;
	}

	public void setCourseStartDate(String courseStartDate) {
		this.courseStartDate = courseStartDate;
	}

	public String getCourseEndDate() {
		return courseEndDate;
	}

	public void setCourseEndDate(String courseEndDate) {
		this.courseEndDate = courseEndDate;
	}

	public String getUniversity() {
		return university;
	}

	public void setUniversity(String university) {
		this.university = university;
	}

	public Integer getEmpQualificationId() {
		return empQualificationId;
	}

	public void setEmpQualificationId(Integer empQualificationId) {
		this.empQualificationId = empQualificationId;
	}

	public String getIsPartOfCLEP() {
		return isPartOfCLEP;
	}

	public void setIsPartOfCLEP(String isPartOfCLEP) {
		this.isPartOfCLEP = isPartOfCLEP;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
    
    
}
