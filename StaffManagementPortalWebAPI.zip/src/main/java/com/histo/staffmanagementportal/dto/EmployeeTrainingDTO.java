package com.histo.staffmanagementportal.dto;

import com.histo.staffmanagementportal.intranet.entity.Document;

import javax.validation.constraints.NotNull;
import java.util.List;

public class EmployeeTrainingDTO {
	
	@NotNull
    private Integer employeeID;
	@NotNull
    private Integer employeeTrainingCategoryID;
	@NotNull
    private String trainingFrom;
	@NotNull
    private String trainingTo;
	
    private String purpose;
    private String trainingDocumentName;
    private byte[] trainingDocBinary;
    private Integer modifiedBy;
	private List<Document> documentList;
	private Integer employeeTrainingID;
    
	public EmployeeTrainingDTO() {
		super();
	}

	public List<Document> getDocumentList() {
		return documentList;
	}

	public void setDocumentList(List<Document> documentList) {
		this.documentList = documentList;
	}

	public Integer getEmployeeTrainingID() {
		return employeeTrainingID;
	}

	public void setEmployeeTrainingID(Integer employeeTrainingID) {
		this.employeeTrainingID = employeeTrainingID;
	}

	public Integer getEmployeeID() {
		return employeeID;
	}

	public String getTrainingDocumentName() {
		return trainingDocumentName;
	}

	public void setTrainingDocumentName(String trainingDocumentName) {
		this.trainingDocumentName = trainingDocumentName;
	}

	public void setEmployeeID(Integer employeeID) {
		this.employeeID = employeeID;
	}

	public Integer getEmployeeTrainingCategoryID() {
		return employeeTrainingCategoryID;
	}

	public void setEmployeeTrainingCategoryID(Integer employeeTrainingCategoryID) {
		this.employeeTrainingCategoryID = employeeTrainingCategoryID;
	}

	public String getTrainingFrom() {
		return trainingFrom;
	}

	public void setTrainingFrom(String trainingFrom) {
		this.trainingFrom = trainingFrom;
	}

	public String getTrainingTo() {
		return trainingTo;
	}

	public void setTrainingTo(String trainingTo) {
		this.trainingTo = trainingTo;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public byte[] getTrainingDocBinary() {
		return trainingDocBinary;
	}

	public void setTrainingDocBinary(byte[] trainingDocBinary) {
		this.trainingDocBinary = trainingDocBinary;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
