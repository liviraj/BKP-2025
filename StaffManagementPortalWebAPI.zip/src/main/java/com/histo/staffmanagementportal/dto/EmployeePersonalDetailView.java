package com.histo.staffmanagementportal.dto;

import java.math.BigDecimal;

public class EmployeePersonalDetailView {
	
	private Integer employeeId;
    private String firstName;
    private String middleName;
    private String lastName;
    private String gender;
    private String panSsn;
    private String dob;
    private String fatherName;
    private String motherName;
    
    private String maritalStatus;
    private String spouseName;
    private BigDecimal childNos;
    private String childName;
    private Integer modifiedBy;
    private String modifiedDate;
    private Integer createdBy;
    private String createdDate;
    private Character recordStatus;
    private String nationality;
    private String issuePlace;
    private String issueDate;
    private String expiryDate;
    private String employeeCode;
    private String panSsnNumber;
    private String passportNo;
    private String image;
    private byte[] photoImageBinary;
    private String employmentstatus;
    
	public EmployeePersonalDetailView() {
		super();
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public byte[] getPhotoImageBinary() {
		return photoImageBinary;
	}

	public void setPhotoImageBinary(byte[] photoImageBinary) {
		this.photoImageBinary = photoImageBinary;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPanSsn() {
		return panSsn;
	}
	public void setPanSsn(String panSsn) {
		this.panSsn = panSsn;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Character getRecordStatus() {
		return recordStatus;
	}
	public void setRecordStatus(Character recordStatus) {
		this.recordStatus = recordStatus;
	}
	
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public String getIssuePlace() {
		return issuePlace;
	}
	public void setIssuePlace(String issuePlace) {
		this.issuePlace = issuePlace;
	}
	public String getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	public String getEmployeeCode() {
		return employeeCode;
	}
	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}
	
	public String getPanSsnNumber() {
		return panSsnNumber;
	}
	public void setPanSsnNumber(String panSsnNumber) {
		this.panSsnNumber = panSsnNumber;
	}
	public String getPassportNo() {
		return passportNo;
	}
	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getSpouseName() {
		return spouseName;
	}

	public void setSpouseName(String spouseName) {
		this.spouseName = spouseName;
	}

	public BigDecimal getChildNos() {
		return childNos;
	}

	public void setChildNos(BigDecimal childNos) {
		this.childNos = childNos;
	}

	public String getChildName() {
		return childName;
	}

	public void setChildName(String childName) {
		this.childName = childName;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getEmploymentstatus() {
		return employmentstatus;
	}

	public void setEmploymentstatus(String employmentstatus) {
		this.employmentstatus = employmentstatus;
	}
	
	
}
