package com.histo.staffmanagementportal.dto;


public record HolidayIdDetails(Integer holidayDetailId,Integer employeeHolidayId) {

//    private Integer holidayDetailId;
//    private Integer employeeHolidayId;
}
