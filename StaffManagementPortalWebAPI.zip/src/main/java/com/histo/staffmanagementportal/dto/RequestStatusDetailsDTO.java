package com.histo.staffmanagementportal.dto;

import lombok.Data;

@Data
public class RequestStatusDetailsDTO {

    private Integer requestId;
    private String comments;
    private Integer reviewedBy;
    private String reviewedOn;
    private String requestStatus;
}
