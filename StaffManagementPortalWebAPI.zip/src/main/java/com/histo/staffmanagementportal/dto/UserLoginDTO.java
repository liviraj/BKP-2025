package com.histo.staffmanagementportal.dto;

public class UserLoginDTO {
    private String emailAddress;

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
    
}
