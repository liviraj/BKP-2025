package com.histo.staffmanagementportal.dto;

public class EmployeeWorkHistoryView {

	private Integer employeeWorkHistoryId;
	private String employerName;
	private String designation;
	private String dateOfJoin;
	private String relievingDate;
	private String reportingTo;
	
	public EmployeeWorkHistoryView() {
		super();
	}
	
	 

	public EmployeeWorkHistoryView(Integer employeeWorkHistoryId, String employerName, String designation,
			String dateOfJoin, String relievingDate, String reportingTo) {
		super();
		this.employeeWorkHistoryId = employeeWorkHistoryId;
		this.employerName = employerName;
		this.designation = designation;
		this.dateOfJoin = dateOfJoin;
		this.relievingDate = relievingDate;
		this.reportingTo = reportingTo;
	}



	public Integer getEmployeeWorkHistoryId() {
		return employeeWorkHistoryId;
	}

	public void setEmployeeWorkHistoryId(Integer employeeWorkHistoryId) {
		this.employeeWorkHistoryId = employeeWorkHistoryId;
	}

	public String getEmployerName() {
		return employerName;
	}
	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getDateOfJoin() {
		return dateOfJoin;
	}
	public void setDateOfJoin(String dateOfJoin) {
		this.dateOfJoin = dateOfJoin;
	}
	public String getRelievingDate() {
		return relievingDate;
	}
	public void setRelievingDate(String relievingDate) {
		this.relievingDate = relievingDate;
	}
	public String getReportingTo() {
		return reportingTo;
	}
	public void setReportingTo(String reportingTo) {
		this.reportingTo = reportingTo;
	}
	
}
