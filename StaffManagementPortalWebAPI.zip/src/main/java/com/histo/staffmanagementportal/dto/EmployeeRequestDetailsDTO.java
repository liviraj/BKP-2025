package com.histo.staffmanagementportal.dto;

import lombok.Data;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class EmployeeRequestDetailsDTO {

    private Integer requestId;
    @NotNull
    private Integer employeeId;
    @NotNull
    private Integer requestTypeId;
    @NotBlank
    private String description;
    private String imageName;
    private byte[] imageBinary;
    private Integer modifiedBy;
    private String modifiedOn;
    private Integer createdBy;
    private String createdOn;
    private String recordStatus;

}

