package com.histo.staffmanagementportal.dto;

public class LeaveLedgerModifyDTO {
    private Integer employeeId;
    private Double creditDays;
    private Double debitDays;
    private Double balanceDays;
    private String comments;
    private Integer modifiedBy;
    private String modifiedOn;
    private String leaveType;
    private String locationId;

    public String getLeaveType() {
        return leaveType;
    }

    public void setLeaveType(String leaveType) {
        this.leaveType = leaveType;
    }

    public String getLocationId() {
        return locationId;
    }

    public void setLocationId(String locationId) {
        this.locationId = locationId;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public Double getCreditDays() {
        return creditDays;
    }

    public void setCreditDays(Double creditDays) {
        this.creditDays = creditDays;
    }

    public Double getDebitDays() {
        return debitDays;
    }

    public void setDebitDays(Double debitDays) {
        this.debitDays = debitDays;
    }

    public Double getBalanceDays() {
        return balanceDays;
    }

    public void setBalanceDays(Double balanceDays) {
        this.balanceDays = balanceDays;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    @Override
    public String toString() {
        return "LeaveLedgerModifyDTO{" +
                "employeeId=" + employeeId +
                ", creditDays=" + creditDays +
                ", debitDays=" + debitDays +
                ", balanceDays=" + balanceDays +
                ", comments='" + comments + '\'' +
                '}';
    }

    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public String getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
}
