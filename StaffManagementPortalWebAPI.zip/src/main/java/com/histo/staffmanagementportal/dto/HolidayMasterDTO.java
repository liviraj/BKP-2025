package com.histo.staffmanagementportal.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class HolidayMasterDTO {

    private String holidayName;
    private Integer locationId;
    private Integer addedByEmpId;
    private String addedOn;
    private Integer modifiedByEmpId;
    private String modifiedOn;

    // Below is for view purpose in holiday list
    private Integer holidayId;
    private String addedBy;
    private String modifiedBy;
    private String locationName;
    private String recordStatus;

}
