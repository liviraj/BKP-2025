package com.histo.staffmanagementportal.dto;

import java.math.BigDecimal;
import java.util.Arrays;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import com.histo.staffmanagementportal.model.GenderEnum;
import com.histo.staffmanagementportal.model.IdProofTypeEnum;

public class EmployeeDTO{
	
	@NotBlank
    private String firstName;
    private String middleName;
    @NotBlank
    private String lastName;
    @NotNull
    private String gender;
    
    private String panSsn;
    @NotNull
	private String dob;
    private String fatherName;
    private String motherName;
    @NotNull
    private String maritalStatus;
    private String spouseName;
    private BigDecimal childNos;
    private Integer siblingsNo;
    private String childName;
    private Integer modifiedBy;
    private Character recordStatus;
    private String image;
    @NotNull
    private String nationality;
    private String issuePlace;
    private String issueDate;
    private String expiryDate;
    private String idProofImg;
    private String employeeCode;
    private String timePunchId;
    private String passportImage;
    private byte[] photoImageBinary;
    private byte[] idProofImageBinary;
    private byte[] passportImageBinary;
    private String panSsnNumber;
    private String passportNo;
    private Integer createdBy;
    private Integer locationId;
    private String employmentStatus;
	private String employmentType;
    
	public EmployeeDTO() {
		super();
	}

	public String getEmploymentType() {
		return employmentType;
	}

	public void setEmploymentType(String employmentType) {
		this.employmentType = employmentType;
	}

	public String getEmploymentStatus() {
		return employmentStatus;
	}

	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}

	public Integer getLocationId() {
		return locationId;
	}

	public void setLocationId(Integer locationId) {
		this.locationId = locationId;
	}

	public Integer getSiblingsNo() {
		return siblingsNo;
	}

	public void setSiblingsNo(Integer siblingsNo) {
		this.siblingsNo = siblingsNo;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPanSsn() {
		return panSsn;
	}
	public void setPanSsn(String panSsn) {
		this.panSsn = panSsn;
	}
	public @NotNull String getDob() {
		return dob;
	}
	public void setDob(@NotNull String dob) {
		this.dob = dob;
	}
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	public String getMotherName() {
		return motherName;
	}
	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalstatus) {
		this.maritalStatus = maritalstatus;
	}
	public String getSpouseName() {
		return spouseName;
	}
	public void setSpouseName(String spouseName) {
		this.spouseName = spouseName;
	}
	public BigDecimal getChildNos() {
		return childNos;
	}
	public void setChildNos(BigDecimal childnos) {
		this.childNos = childnos;
	}
	public String getChildName() {
		return childName;
	}
	public void setChildName(String childName) {
		this.childName = childName;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Character getRecordStatus() {
		return recordStatus;
	}
	public void setRecordStatus(Character recordStatus) {
		this.recordStatus = recordStatus;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public String getIssuePlace() {
		return issuePlace;
	}
	public void setIssuePlace(String issuePlace) {
		this.issuePlace = issuePlace;
	}
	public String getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getIdProofImg() {
		return idProofImg;
	}
	public void setIdProofImg(String idProofImg) {
		this.idProofImg = idProofImg;
	}
	public String getEmployeeCode() {
		return employeeCode;
	}
	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}
	public String getTimePunchId() {
		return timePunchId;
	}
	public void setTimePunchId(String timePunchId) {
		this.timePunchId = timePunchId;
	}
	public String getPassportImage() {
		return passportImage;
	}
	public void setPassportImage(String passportImage) {
		this.passportImage = passportImage;
	}
	public byte[] getPhotoImageBinary() {
		return photoImageBinary;
	}
	public void setPhotoImageBinary(byte[] photoImageBinary) {
		this.photoImageBinary = photoImageBinary;
	}
	public byte[] getIdProofImageBinary() {
		return idProofImageBinary;
	}
	public void setIdProofImageBinary(byte[] idProofImageBinary) {
		this.idProofImageBinary = idProofImageBinary;
	}
	public byte[] getPassportImageBinary() {
		return passportImageBinary;
	}
	public void setPassportImageBinary(byte[] passportImageBinary) {
		this.passportImageBinary = passportImageBinary;
	}
	public String getPanSsnNumber() {
		return panSsnNumber;
	}
	public void setPanSsnNumber(String panSsnNumber) {
		this.panSsnNumber = panSsnNumber;
	}
	public String getPassportNo() {
		return passportNo;
	}
	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}
	public String getPanSsnDlValue(String panSsn) {
	if(panSsn!=null) {	
		if(panSsn.equalsIgnoreCase(IdProofTypeEnum.PAN.toString())) {
			return IdProofTypeEnum.PAN.getValue();
		}
		else if(panSsn.equalsIgnoreCase(IdProofTypeEnum.SSN.toString())) {
			return IdProofTypeEnum.SSN.getValue();
		}
		else if(panSsn.equalsIgnoreCase(IdProofTypeEnum.DL.toString())) {
			return IdProofTypeEnum.DL.getValue();
		}
	}
	return "";
	}
	
	public String getGenderCharValue(String gender) {
		if(gender!=null)
		{
		if(gender.equalsIgnoreCase(GenderEnum.FEMALE.toString())) {
			return GenderEnum.FEMALE.getValue();
		}
		else if (gender.equalsIgnoreCase(GenderEnum.MALE.toString())) {
			return GenderEnum.MALE.getValue();
		}
		}
		return "";
	}
	@Override
	public String toString() {
		return "EmployeeDTO [firstName=" + firstName + ", middleName=" + middleName + ", lastName=" + lastName
				+ ", gender=" + gender + ", panSsn=" + panSsn + ", dob=" + dob + ", fatherName=" + fatherName
				+ ", motherName=" + motherName + ", maritalStatus=" + maritalStatus + ", spouseName=" + spouseName
				+ ", childNos=" + childNos + ", childName=" + childName + ", modifiedBy=" + modifiedBy
				+ ", recordStatus=" + recordStatus + ", image=" + image
				+ ", nationality=" + nationality + ", issuePlace=" + issuePlace + ", issueDate=" + issueDate
				+ ", expiryDate=" + expiryDate + ", idProofImg=" + idProofImg + ", employeeCode=" + employeeCode
				+ ", timePunchId=" + timePunchId + ", passportImage=" + passportImage + ", photoImageBinary="
				+ Arrays.toString(photoImageBinary) + ", idProofImageBinary=" + Arrays.toString(idProofImageBinary)
				+ ", passportImageBinary=" + Arrays.toString(passportImageBinary) + ", panSsnNumber=" + panSsnNumber
				+ ", passportNo=" + passportNo + "]";
	}
	
}