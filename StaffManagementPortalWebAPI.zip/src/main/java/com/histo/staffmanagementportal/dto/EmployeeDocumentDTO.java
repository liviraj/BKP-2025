package com.histo.staffmanagementportal.dto;

import com.histo.staffmanagementportal.intranet.entity.Document;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotNull;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class EmployeeDocumentDTO {

	@NotNull
	private Integer employeeId;
	@NotNull
	private String documentDate;
	private String  description;
	private String  documentName;
	private byte[]  documentImage;
	private Integer  modifiedBy;
	private String expiryDate;
	private Integer documentTypeId;
	private List<Document> documentList;
	private Integer documentId;

	
}
