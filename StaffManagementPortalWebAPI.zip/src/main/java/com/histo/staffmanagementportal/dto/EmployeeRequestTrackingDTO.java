package com.histo.staffmanagementportal.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeRequestTrackingDTO {

    private Integer autoId;
    private Integer requestId;
    private Integer employeeId;
    private Integer assignedTo;
    private Integer requestStatusId;
    private Integer modifiedBy;
    private String modifiedDate;
    private String description;
}
