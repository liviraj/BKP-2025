package com.histo.staffmanagementportal.dto;

import com.histo.staffmanagementportal.intranet.entity.Document;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class EmployeeWorkHistoryDTO {

	@NotNull
	private Integer employeeId;
	@NotBlank
	private String employerName;
	@NotBlank
	private String designation;
	@NotNull
	private String dateofJoin;
	@NotNull
	private String relievingDate;
	@NotNull
	private String reportingTo;
	private Integer modifiedBy;
	private String employeeImage;
	private byte[] employeeImageBinary;
	private List<Document> documentDetails;

}
