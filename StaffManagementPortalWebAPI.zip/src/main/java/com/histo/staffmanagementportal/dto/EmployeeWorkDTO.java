package com.histo.staffmanagementportal.dto;

import javax.validation.constraints.NotNull;


public class EmployeeWorkDTO {

    private Integer employeeID;
    @NotNull
    private String doj;
    @NotNull
    private Integer designationID;
    @NotNull
    private Integer gradeID;
    private String workStationID;
    private String systemID;
    private String laptopID;
    @NotNull
    private Integer reportingTo;
    @NotNull
    private Integer departmentID;
    private Integer modifiedBy;
    private Integer createdBy;
    private Character recordStatus;
    @NotNull
    private Integer locationID;
    @NotNull
    private Integer employmentType;
    private String visaType;
    private String placeofIssue;
    private String issueDateWork;
    private String expiryDateWork;
    private String countryIssued;
    private Integer currentLocation;
    private String confirmationDate;
    private String relievingDate;
    private String employmentStatus;
    private Boolean clinicalHandler;
	public EmployeeWorkDTO() {
		super();
	}
	
	public Integer getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(Integer employeeID) {
		this.employeeID = employeeID;
	}
	public String getDoj() {
		return doj;
	}
	public void setDoj(String doj) {
		this.doj = doj;
	}
	public Integer getDesignationID() {
		return designationID;
	}
	public void setDesignationID(Integer designationID) {
		this.designationID = designationID;
	}
	public Integer getGradeID() {
		return gradeID;
	}
	public void setGradeID(Integer gradeID) {
		this.gradeID = gradeID;
	}
	public String getWorkStationID() {
		return workStationID;
	}
	public void setWorkStationID(String workStationID) {
		this.workStationID = workStationID;
	}
	public String getSystemID() {
		return systemID;
	}
	public void setSystemID(String systemID) {
		this.systemID = systemID;
	}
	public String getLaptopID() {
		return laptopID;
	}
	public void setLaptopID(String laptopID) {
		this.laptopID = laptopID;
	}
	public Integer getReportingTo() {
		return reportingTo;
	}
	public void setReportingTo(Integer reportingTo) {
		this.reportingTo = reportingTo;
	}
	public Integer getDepartmentID() {
		return departmentID;
	}
	public void setDepartmentID(Integer departmentID) {
		this.departmentID = departmentID;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Character getRecordStatus() {
		return recordStatus;
	}
	public void setRecordStatus(Character recordStatus) {
		this.recordStatus = recordStatus;
	}
	public Integer getLocationID() {
		return locationID;
	}
	public void setLocationID(Integer locationID) {
		this.locationID = locationID;
	}
	public Integer getEmploymentType() {
		return employmentType;
	}
	public void setEmploymentType(Integer employmentType) {
		this.employmentType = employmentType;
	}
	public String getVisaType() {
		return visaType;
	}
	public void setVisaType(String visaType) {
		this.visaType = visaType;
	}
	public String getPlaceofIssue() {
		return placeofIssue;
	}
	public void setPlaceofIssue(String placeofIssue) {
		this.placeofIssue = placeofIssue;
	}
	public String getIssueDateWork() {
		return issueDateWork;
	}
	public void setIssueDateWork(String issueDateWork) {
		this.issueDateWork = issueDateWork;
	}
	public String getExpiryDateWork() {
		return expiryDateWork;
	}
	public void setExpiryDateWork(String expiryDateWork) {
		this.expiryDateWork = expiryDateWork;
	}
	public String getCountryIssued() {
		return countryIssued;
	}
	public void setCountryIssued(String countryIssued) {
		this.countryIssued = countryIssued;
	}
	public Integer getCurrentLocation() {
		return currentLocation;
	}
	public void setCurrentLocation(Integer currentLocation) {
		this.currentLocation = currentLocation;
	}
	public String getConfirmationDate() {
		return confirmationDate;
	}
	public void setConfirmationDate(String confirmationDate) {
		this.confirmationDate = confirmationDate;
	}
	public String getRelievingDate() {
		return relievingDate;
	}
	public void setRelievingDate(String relievingDate) {
		this.relievingDate = relievingDate;
	}
	public String getEmploymentStatus() {
		return employmentStatus;
	}
	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}
	public Boolean getClinicalHandler() {
		return clinicalHandler;
	}
	public void setClinicalHandler(Boolean clinicalHandler) {
		this.clinicalHandler = clinicalHandler;
	}   
    
}
