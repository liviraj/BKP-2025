package com.histo.staffmanagementportal.dto;

public class LeaveLedgerDTO {
    private int leaveLedgerId;
    private int employeeId;
    private String employeeName;
    private String entryDate;
    private String comments;
    private Double creditDays;
    private Double debitDays;
    private Double balanceDays;
    private int locationId;
    private String locationCountry;
    private String employmentStatus;
    private String leaveType;

    
    public String getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

	public int getLeaveLedgerId() {
        return leaveLedgerId;
    }

    public void setLeaveLedgerId(int leaveLedgerId) {
        this.leaveLedgerId = leaveLedgerId;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(String entryDate) {
        this.entryDate = entryDate;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Double getCreditDays() {
        return creditDays;
    }

    public void setCreditDays(Double creditDays) {
        this.creditDays = creditDays;
    }

    public Double getDebitDays() {
        return debitDays;
    }

    public void setDebitDays(Double debitDays) {
        this.debitDays = debitDays;
    }

    public Double getBalanceDays() {
        return balanceDays;
    }

    public void setBalanceDays(Double balanceDays) {
        this.balanceDays = balanceDays;
    }

    public int getLocationId() {
        return locationId;
    }

    public void setLocationId(int locationId) {
        this.locationId = locationId;
    }

    public String getLocationCountry() {
        return locationCountry;
    }

    public void setLocationCountry(String locationCountry) {
        this.locationCountry = locationCountry;
    }

    public String getEmploymentStatus() {
        return employmentStatus;
    }

    public void setEmploymentStatus(String employmentStatus) {
        this.employmentStatus = employmentStatus;
    }

    @Override
    public String toString() {
        return "LeaveLedgerDTO{" +
                "leaveLedgerId=" + leaveLedgerId +
                ", employeeId=" + employeeId +
                ", employeeName='" + employeeName + '\'' +
                ", entryDate='" + entryDate + '\'' +
                ", comments='" + comments + '\'' +
                ", creditDays=" + creditDays +
                ", debitDays=" + debitDays +
                ", balanceDays=" + balanceDays +
                ", locationId=" + locationId +
                ", locationCountry='" + locationCountry + '\'' +
                ", employmentStatus='" + employmentStatus + '\'' +
                '}';
    }
}
