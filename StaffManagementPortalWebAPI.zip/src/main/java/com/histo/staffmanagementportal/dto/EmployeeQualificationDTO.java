package com.histo.staffmanagementportal.dto;

import com.histo.staffmanagementportal.intranet.entity.Document;
import lombok.*;

import java.util.List;
import javax.validation.constraints.NotBlank;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class EmployeeQualificationDTO {
   

    private Integer employeeId;   
    @NotBlank
    private String qualification;
    @NotBlank
    private String institution;            
    private String majorSubject;           
    private String type;                   
    private String value;                  
    private String courseDuration;

    private String courseStartDate;

    private String courseEndDate;          
    private String university;             
    private Integer modifiedBy;                               
    private String employeeImage;          
    private String isPartOfCLEP;
    private String location;               
    private byte[] employeeImageBinary;
	private List<Document> documentDetails;
    private Integer empQualificationID;
    
}