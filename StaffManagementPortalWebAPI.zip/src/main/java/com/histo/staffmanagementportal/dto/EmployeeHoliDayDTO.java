package com.histo.staffmanagementportal.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class EmployeeHoliDayDTO {

    private Integer employeeId;
    private Integer modifiedByEmpId;
    private String modifiedOn;
    private List<HolidayIdDetails> holidayIdDetailsList;
}
