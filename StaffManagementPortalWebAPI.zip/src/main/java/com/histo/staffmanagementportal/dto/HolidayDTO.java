package com.histo.staffmanagementportal.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class HolidayDTO {

    private Integer holidayID;
    private String name;
    private String startDate;
    private String endDate;
    private Integer numberOfDays;
    private Integer alternateHolidayId = 0;
    private String modifiedBy;
    private String modifiedOn;
    private String recordStatus;
    private Integer locationId;
    private String isOptional;
    private Integer holidayMasterId;
    private Integer modifiedByEmpId;
    private Integer addedByEmpId;
    private String addedOn;
    private String createdBy;
    private String locationName;
    private String governmentHolidayDate;
    private String isSetAsFloatingHoliday;
}
