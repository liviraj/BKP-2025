package com.histo.staffmanagementportal.dto;

import com.histo.staffmanagementportal.intranet.entity.Document;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;


@Getter
@Setter
@NoArgsConstructor
@ToString
public class EmployeeComplianceDTO {

    @NotNull
    private Integer employeeID;
    @NotNull
    private Integer createdBy;
    @NotNull
    private Integer complianceCategoryID;
    @NotBlank
    private String compliancePeriod;
    @NotNull
    private String complianceDate;
    private String description;
    private String documentName;
    private byte[] documentImage;
    @NotNull
    private String expiryDate;
    private List<Document> documentDetails;
    private Integer EmployeeComplianceID;
    private String authenticateUserRole;
}
