package com.histo.staffmanagementportal.helper;

import java.util.regex.Pattern;

public class EmployeeCodeIncrementer {
	
	private EmployeeCodeIncrementer() {
		super();
	}
	static final Pattern NUMBER = Pattern.compile("\\d+");
	public static String increment(String input) {
		 return NUMBER.matcher(input)
		            .replaceFirst(s -> String.format(
		                "%0" + s.group().length() + "d",
		                Integer.parseInt(s.group()) + 1));
    }
}
