package com.histo.staffmanagementportal.helper;

import java.time.Instant;

import org.apache.commons.lang3.ObjectUtils;

import com.histo.staffmanagementportal.util.InstantFormatter;

public class DateValidation {

	private DateValidation() {
		super();
	}

	public static boolean validateDate(String issueDate,String expiryDate) {
		Instant empIssueDate = InstantFormatter.InstantFormat(issueDate);
		Instant empExpiryDate = InstantFormatter.InstantFormat(expiryDate);
		boolean isValid = ObjectUtils.isNotEmpty(empIssueDate)&& ObjectUtils.isNotEmpty(empExpiryDate)  
	       		 && empExpiryDate.isBefore(empIssueDate);
		return isValid;
	}
}
