package com.histo.staffmanagementportal.controller;
import javax.validation.Valid;

import com.histo.staffmanagementportal.model.EmployeeRequestWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.histo.staffmanagementportal.dto.EmployeeWorkDTO;
import com.histo.staffmanagementportal.service.impl.EmployeeWorkServiceImpl;

@RestController
@RequestMapping("/work")
public class WorkController {
    @Autowired
    private EmployeeWorkServiceImpl service;
    
    @GetMapping("{employeeId}")
    public ResponseEntity<Object> getEmployeeworkById(@PathVariable Integer employeeId){
        return service.getEmployeeWorkByEmployeeId(employeeId);
    }
    
    @PostMapping("{loginId}")
    public ResponseEntity<Object> addEmployeeWork(@Valid @RequestBody EmployeeRequestWrapper employeeRequestWrapper, @PathVariable Integer loginId){
    	return service.addEmployeeWorkDetails(employeeRequestWrapper.getWorkDto() ,employeeRequestWrapper.getEmployee(),loginId);
    }
    
    @PutMapping("{employeeWorkId}")
    public ResponseEntity<Object> updateEmployeeWork(@Valid @RequestBody EmployeeWorkDTO workDto,@PathVariable Integer employeeWorkId){
    	return service.updateEmployeeWorkDetails(employeeWorkId,workDto);
    }
    
    @GetMapping("/gradeName")
    public ResponseEntity<Object> getGradeDetails(){
        return service.getGradeName();
    }
}