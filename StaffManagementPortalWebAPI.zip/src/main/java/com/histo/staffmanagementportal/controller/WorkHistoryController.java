package com.histo.staffmanagementportal.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.histo.staffmanagementportal.dto.EmployeeWorkDTO;
import com.histo.staffmanagementportal.dto.EmployeeWorkHistoryDTO;
import com.histo.staffmanagementportal.model.ModifiedDetails;
import com.histo.staffmanagementportal.service.EmployeeWorkHistoryService;

@RestController
@RequestMapping("workHistory")
public class WorkHistoryController {

	@Autowired
	private EmployeeWorkHistoryService service;
	
	@GetMapping("/details/{employeeId}")
    public ResponseEntity<Object> getEmployeeworkByEmployeeId(@PathVariable Integer employeeId){
        return service.getWorkHistoryByEmployeeId(employeeId);
    }
	@GetMapping("{workHistoryId}")
    public ResponseEntity<Object> getEmployeeworkById(@PathVariable Integer workHistoryId){
        return service.getWorkHistoryById(workHistoryId);
    }
    @PostMapping
    public ResponseEntity<Object> addEmployeeWork(@Valid @RequestBody EmployeeWorkHistoryDTO workHistoryDto){
    	return service.addEmployeeWorkHistory(workHistoryDto);
    }
    
    @PutMapping("{workHistoryId}")
    public ResponseEntity<Object> updateEmployeeWork(@Valid @RequestBody EmployeeWorkHistoryDTO workHistoryDto,@PathVariable Integer workHistoryId){
    	return service.updateEmployeeWorkHistory(workHistoryDto,workHistoryId);
    }
    
    @DeleteMapping("{workHistoryId}")
	public ResponseEntity<Object> deleteWorkHistory(@PathVariable("workHistoryId") Integer workHistoryId, @RequestBody ModifiedDetails modifiedDetails){
		return service.deleteEmployeeWorkHistoryById(workHistoryId,modifiedDetails);
	}
}
