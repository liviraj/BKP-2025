package com.histo.staffmanagementportal.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.histo.staffmanagementportal.dto.EmployeeTrainingDTO;
import com.histo.staffmanagementportal.model.ModifiedDetails;
import com.histo.staffmanagementportal.service.EmployeeTrainingService;

@RestController
@RequestMapping("/training")
public class TrainingController {
	
	@Autowired
	private EmployeeTrainingService employeeTrainingService;
	

	@GetMapping("{trainingId}")
	public ResponseEntity<Object> getTrainingDetailByID(@PathVariable("trainingId") Integer trainingId){
		return employeeTrainingService.getEmployeeTrainingById(trainingId);
	}
	
	@GetMapping("/details/{employeeId}")
	public ResponseEntity<Object> getTrainingDetailByEmployeeID(@PathVariable("employeeId") Integer employeeId){
		return employeeTrainingService.getEmployeeTrainingByEmployeeId(employeeId);
	}
	
	@GetMapping("/category")
	public ResponseEntity<Object> getTrainingCategory(){
		return employeeTrainingService.getTrainingCategory();
	}
	
	@PostMapping
	public ResponseEntity<Object> addEmployeeTraining(@Valid @RequestBody EmployeeTrainingDTO trainingDTO){
		return employeeTrainingService.addEmployeeTrainingDetails(trainingDTO);
	}
	
	@PutMapping("{trainingId}")
	public ResponseEntity<Object> updateEmployeeTraining(@Valid @RequestBody EmployeeTrainingDTO trainingDTO,@PathVariable("trainingId") Integer trainingId){
		return employeeTrainingService.updateEmployeeTraining(trainingDTO, trainingId);
	}
	
	@DeleteMapping("{trainingId}")
	public ResponseEntity<Object> deleteTraining(@PathVariable("trainingId") Integer trainingId,@RequestBody ModifiedDetails modifiedDetails){
		return employeeTrainingService.deleteEmployeeTrainingById(trainingId,modifiedDetails);
	}
}
