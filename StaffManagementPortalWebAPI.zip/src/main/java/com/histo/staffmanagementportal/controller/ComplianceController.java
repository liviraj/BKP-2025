package com.histo.staffmanagementportal.controller;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.histo.staffmanagementportal.dto.EmployeeComplianceDTO;
import com.histo.staffmanagementportal.model.ModifiedDetails;
import com.histo.staffmanagementportal.service.EmployeeComplianceService;

@RestController
@RequestMapping("/compliance")
public class ComplianceController {

	private final EmployeeComplianceService service;

	public ComplianceController(EmployeeComplianceService service) {
		this.service = service;
	}

	@GetMapping("/details/{employeeId}")
	public ResponseEntity<Object> getComplianceByEmployeeId(@PathVariable("employeeId") Integer employeeId){
		return service.getEmployeeComplianceByEmployeeId(employeeId);
	}
	
	@GetMapping("{complianceId}")
	public ResponseEntity<Object> getComplianceById(@PathVariable("complianceId") Integer complianceId){
		return service.getEmployeeComplianceById(complianceId);
	}
	
	@PostMapping
	public ResponseEntity<Object> addCompliance(@Valid @RequestBody EmployeeComplianceDTO complianceDTO){
		return service.addEmployeeCompliance(complianceDTO);
	}
	
	@PutMapping("{complianceId}")
	public ResponseEntity<Object> updateCompliance(@Valid @RequestBody EmployeeComplianceDTO complianceDTO,@PathVariable("complianceId") Integer complianceId){
		return service.updateEmployeeCompliance(complianceDTO,complianceId);
	}
	@GetMapping("/category")
	public ResponseEntity<Object> getComplianceCategory(){
		return service.getComplianceCategory();
	}
	
	@GetMapping("/period")
	public ResponseEntity<Object> getCompliancePeriod(){
		return service.getCompliancePeriod();
	}
	
	@DeleteMapping("{complianceId}")
	public ResponseEntity<Object> deleteCompliance(@PathVariable("complianceId") Integer complianceId,@RequestBody ModifiedDetails modifiedDetails){
		return service.deleteEmployeeComplianceById(complianceId,modifiedDetails);
	}

}
