package com.histo.staffmanagementportal.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.azure.core.annotation.QueryParam;
import com.histo.staffmanagementportal.model.ComplianceCertificateInfo;
import com.histo.staffmanagementportal.model.ComplianceReportFilter;
import com.histo.staffmanagementportal.service.ComplianceReportService;

@RestController
@RequestMapping("/complianceReports")
public class ComplianceReportController {

	private final ComplianceReportService service;

    public ComplianceReportController(ComplianceReportService service) {
        this.service = service;
    }

    @GetMapping("/compliance")
    public ResponseEntity<Object> getComplianceReport(@QueryParam(value = "input") ComplianceReportFilter reportFilter) {
        return service.getComplianceReport(reportFilter);
    }
	@GetMapping("/employeeType")
    public ResponseEntity<Object> getEmployeeType() {
        return service.getEmployeeType();
    }
	
	@GetMapping
    public ResponseEntity<Object> getComplianceCertificate(@QueryParam(value = "certificateDetails") ComplianceCertificateInfo complianceDocument) {
        return service.getComplianceDocument(complianceDocument);
    }

    @PostMapping("/emailNotify")
    public ResponseEntity<Object> sendComplianceExpiryEmail(@RequestBody ComplianceReportFilter reportFilter) {
        return service.complianceExpiryEmailNotification (reportFilter);
    }

    @GetMapping("/expiry-email-template")
    public ResponseEntity<Object> getComplianceEmailTemplate(@QueryParam(value = "certificateDetails") ComplianceReportFilter reportFilter) {
        return service.complianceExpiryEmailTemplate (reportFilter);
    }

}
