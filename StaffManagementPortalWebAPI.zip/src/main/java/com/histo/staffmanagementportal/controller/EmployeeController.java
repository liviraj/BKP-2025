package com.histo.staffmanagementportal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.azure.core.annotation.QueryParam;
import com.histo.staffmanagementportal.dto.EmployeeDTO;
import com.histo.staffmanagementportal.model.EmployeeSearchModel;
import com.histo.staffmanagementportal.service.EmployeeService;

import javax.validation.Valid;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	
	@Autowired
	private EmployeeService service;

    @GetMapping
    public ResponseEntity<Object> getEmployees(@QueryParam(value="input") EmployeeSearchModel employeeSearchModel) {
        return service.getEmployeeByFilter(employeeSearchModel);
    }

    @GetMapping("{employeeId}")
    public ResponseEntity<Object> findEmployeeById(@PathVariable Integer employeeId) {
        return service.getEmployeeById(employeeId);
    }
    
    @PostMapping("{loginId}")
	public ResponseEntity<Object> createEmployee(@Valid @RequestBody EmployeeDTO employee,@PathVariable Integer loginId) {
		return service.saveEmployee(employee,loginId);
	}
    
    @GetMapping("/employeeCode/{loginId}")
    public ResponseEntity<Object> getEmployee(@PathVariable Integer loginId) {
        return service.getEmployeeNameFromLogin(loginId);
    }
    
	@PutMapping("{employeeId}")
	public ResponseEntity<Object> updateEmployee(@Valid @RequestBody EmployeeDTO employee,@PathVariable Integer employeeId ) {
		return service.updateEmployee(employee, employeeId);
	}
	
}
