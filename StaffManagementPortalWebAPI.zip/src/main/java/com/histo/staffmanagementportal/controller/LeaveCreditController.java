package com.histo.staffmanagementportal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.histo.staffmanagementportal.service.EmailService;
import com.histo.staffmanagementportal.service.PayRollProcessService;
import com.histo.staffmanagementportal.service.impl.LeaveCreditServiceImpl;

@RestController
@RequestMapping("/leave/credit")
public class LeaveCreditController {

	private final LeaveCreditServiceImpl leaveCredit;
	private final EmailService emailService;
	private final PayRollProcessService payRollProcessService;
	

	public LeaveCreditController(LeaveCreditServiceImpl leaveCredit, EmailService emailService,
			PayRollProcessService payRollProcessService) {
		super();
		this.leaveCredit = leaveCredit;
		this.emailService = emailService;
		this.payRollProcessService = payRollProcessService;
	}

	@GetMapping("/india/specialLeave")
	public ResponseEntity<Object> runYearlyIndiaLeaveCredit(@RequestParam("entrydate") String date) {
		ResponseEntity<Object> IndiaEmployeeSickLeaveCredit = leaveCredit.getSpecialDebitLeaveCredit(date);
		if(IndiaEmployeeSickLeaveCredit.getStatusCode() == HttpStatus.OK) {
        	emailService.sendLeaveCreditEmail(IndiaEmployeeSickLeaveCredit.getBody());
        }
		return IndiaEmployeeSickLeaveCredit;
	}

	@GetMapping("/us/vacation")
	public ResponseEntity<Object> runUSvacationLeaveCredit(@RequestParam("entrydate") String date) {
		return leaveCredit.getUSEmployeeLeaveCredit(date);
	}

	@GetMapping("/india/vacation")
	public ResponseEntity<Object> runIndiavacationLeaveCredit(@RequestParam("entrydate") String date) {
		return leaveCredit.getIndianEmpoyeeLeaveCredit(date);
	}

	@GetMapping("/us/sickLeave")
	public ResponseEntity<Object> runUSSickLeaveCredit(@RequestParam("entrydate") String date) {
		return leaveCredit.getUSSickLeaveCredit(date);
	}

	@GetMapping("/leaveEncashment")
	public ResponseEntity<Object> runLeaveEncashment(@RequestParam("entrydate") String date) {
		return leaveCredit.leaveEncashment(date);
	}
	
	@GetMapping("/payRoll/{locationId}")
	public ResponseEntity<Object> getPayRoll(@PathVariable("locationId") Integer locationId){
		return payRollProcessService.generatePayrollDates(locationId);
	}
}
