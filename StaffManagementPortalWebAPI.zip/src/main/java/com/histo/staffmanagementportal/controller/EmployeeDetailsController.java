package com.histo.staffmanagementportal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.histo.staffmanagementportal.service.EmployeeDetailsService;

@RestController
@RequestMapping("/employeeDetails")
public class EmployeeDetailsController {

	@Autowired
	private EmployeeDetailsService service;

	@GetMapping("{employeeId}")
	public ResponseEntity<Object> findEmployeeDetails(@PathVariable Integer employeeId) {
		return service.getEmployeeDetails(employeeId);
	}

	@GetMapping
	public ResponseEntity<Object> getEmployeeImage(@RequestParam(value = "type") String imageType,
			@RequestParam(value = "employeeId") Integer employeeId) {
		return service.getEmployeeDocument(employeeId, imageType);
	}

	@GetMapping("/qualificationCertificate/{qualificationId}")
	public ResponseEntity<Object> getEmployeeQualificationCertificate(@PathVariable Integer qualificationId) {
		return service.getQualificationCertificate(qualificationId);
	}

	@GetMapping("/continuousEducationCertificate/{continuousEducationId}")
	public ResponseEntity<Object> getEmployeeContinuoueEduCertificate(@PathVariable Integer continuousEducationId) {
		return service.getContinuousEducationCertificate(continuousEducationId);
	}

	@GetMapping("/workHistoryProof/{workHistoryId}")
	public ResponseEntity<Object> getEmployeeWorkHistoryDoc(@PathVariable Integer workHistoryId) {
		return service.getWorkHistoryProof(workHistoryId);
	}

	@GetMapping("/requestDocument/{requestId}")
	public ResponseEntity<Object> getEmployeeRequestDoc(@PathVariable Integer requestId) {
		return service.getEmployeeRequestDocument (requestId);
	}

	@GetMapping("/policyDocument/{policyId}")
	public ResponseEntity<Object> getEmployeePolicyDoc(@PathVariable Integer policyId) {
		return service.getEmployeepolicyDocument (policyId);
	}

	@GetMapping("/designationDocument/{designationId}")
	public ResponseEntity<Object> getEmployeeDesignationDoc(@PathVariable Integer designationId) {
		return service.getEmployeeDesignationDocument (designationId);
	}
}
