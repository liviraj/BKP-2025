package com.histo.staffmanagementportal.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.histo.staffmanagementportal.dto.EmployeeQualificationDTO;
import com.histo.staffmanagementportal.model.ModifiedDetails;
import com.histo.staffmanagementportal.service.EmployeeQualificationService;



@RestController
@RequestMapping("/qualification")
public class QualificationController {

	@Autowired
	private EmployeeQualificationService service;
	
	@GetMapping("/details/{employeeId}")
	public ResponseEntity<Object> getEmployeequalificationByEmployeeId(@PathVariable("employeeId") Integer employeeId) {
		return service.getEmployeeQualificationByEmployeeId(employeeId);
	}
	@GetMapping
	public ResponseEntity<Object> getqualifications() {
		return service.getQualificationName();
	}
	@GetMapping("{qualificationId}")
	public ResponseEntity<Object> getEmployeequalificationById(@PathVariable("qualificationId") Integer qualificationId) {
		return service.getEmployeeQualificationById(qualificationId);
	}
	@PostMapping
	public ResponseEntity<Object> addQualificationDetail(@Valid @RequestBody EmployeeQualificationDTO qualificationDTO){
		return service.addEmployeeQualification(qualificationDTO);
	}
	
	@PutMapping("{qualificationId}")
	public ResponseEntity<Object> updateQualificationDetail(@Valid @RequestBody EmployeeQualificationDTO qualificationDTO,@PathVariable("qualificationId") Integer qualificationId){
		return service.updateEmployeeQualification(qualificationDTO,qualificationId);
	}
	
	@DeleteMapping("{qualificationId}")
	public ResponseEntity<Object> deleteQualification(@PathVariable("qualificationId") Integer qualificationId,@RequestBody ModifiedDetails modifiedDetails){
		return service.deleteEmployeeQualificationById(qualificationId,modifiedDetails);
	}
}
