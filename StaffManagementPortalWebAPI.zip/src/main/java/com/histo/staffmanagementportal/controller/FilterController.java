package com.histo.staffmanagementportal.controller;

import com.azure.core.annotation.QueryParam;
import com.histo.staffmanagementportal.model.FilterModel;
import com.histo.staffmanagementportal.service.FilterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/filter")
public class FilterController {
	@Autowired
	private FilterService service;
	@GetMapping("/employeeName")
	public ResponseEntity<Object> getEmployeeName(){
		return service.getEmployeeName();
	}
	
	@GetMapping("/location")
	public ResponseEntity<Object> getLocations(){
		return service.getLocation();
	}
	
	@GetMapping("/role")
	public ResponseEntity<Object> getRoles(){
		return service.getRoleName();
	}
	
	@GetMapping("/mappingStatus")
	public ResponseEntity<Object> getStatus(){
		return service.getSatus();
	}
	
	@GetMapping("/employeeStatus")
	public ResponseEntity<Object> getEmployeeStatus(){
		return service.getEmployeeStatus();
	}
	
	@GetMapping("/employmentType")
	public ResponseEntity<Object> getEmploymentType(){
		return service.getEmploymentType();
	}
	
	@GetMapping("/section")
	public ResponseEntity<Object> getSection(){
		return service.getSection();
	}
	
	@GetMapping("/designation")
	public ResponseEntity<Object> getDesignation(){
		return service.getDesignation();
	}
	
	@GetMapping("/clinicalHandler")
	public ResponseEntity<Object> getClinicalHandler(){
		return service.getClinicalHandler();
	}
	
	@GetMapping("/loginName")
	public ResponseEntity<Object> getEmployeeNameFromLogin(){
		return service.getEmployeeNameFromLogin();
	}

	@GetMapping("/leaveStatus")
	public ResponseEntity<Object> getLeaveStatus(){
		return service.getLeaveStatus();
	}
	
	@GetMapping("/payRoll")
	public ResponseEntity<Object> getPayRollPeriod(){
		return service.getPayRollDetails();
	}

	@GetMapping("/requestStatus")
	public ResponseEntity<Object> getRequestStatus(){
		return service.getRequestStatus ();
	}

	@GetMapping("/holiday")
	public ResponseEntity<Object> getHolidayListFoLeaveRequest(@QueryParam ("input")FilterModel filterModel){
		return service.getHolidayDetails (filterModel);
	}
}
