package com.histo.staffmanagementportal.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.azure.core.annotation.QueryParam;
import com.histo.staffmanagementportal.model.CancelRequestModel;
import com.histo.staffmanagementportal.model.Constants;
import com.histo.staffmanagementportal.model.LeaveHistoryFilter;
import com.histo.staffmanagementportal.model.LeaveRequestDetails;
import com.histo.staffmanagementportal.service.EmailService;
import com.histo.staffmanagementportal.service.EmployeeLeaveHistoryService;

@RestController
@RequestMapping("/leaveManagement")
public class LeaveManagementController {

	private final EmployeeLeaveHistoryService service;
	private final EmailService emailService;

	public LeaveManagementController(EmployeeLeaveHistoryService service, EmailService emailService) {
		this.service = service;
		this.emailService = emailService;
	}
	
	@GetMapping
	public ResponseEntity<Object> getLeaveRequestQueue(@QueryParam(value="input") LeaveHistoryFilter leaveHistoryFilter){
		return service.getEmployeeLeaveHistory(leaveHistoryFilter);
	}
	@GetMapping("{leaveRequestId}")
	public ResponseEntity<Object> getLeaveRequestDetailsForEmail(@PathVariable("leaveRequestId") Integer leaveRequestId){
		return service.getEmployeeLeaveDetailsForEmail(leaveRequestId);
	}
	@GetMapping("/cancelRequest/{leaveRequestId}")
	public ResponseEntity<Object> getLeaveRequestDetails(@PathVariable("leaveRequestId") Integer leaveRequestId){
		return service.getEmployeeLeaveDetails(leaveRequestId);
	}
	@PostMapping("/cancelRequest")
	public ResponseEntity<Object> cancellationRequest(@RequestBody CancelRequestModel cancelRequestModel){
		 
		 ResponseEntity<Object> cancellationLeaveRequest = service.cancelRequest(cancelRequestModel);
		 if(cancellationLeaveRequest.getStatusCode() == HttpStatus.OK) {
			 ResponseEntity<Object> responseEntity = emailService.sendEmail(cancellationLeaveRequest.getBody(),Constants.LEAVE_CANCELLED);
		 }
		 return cancellationLeaveRequest;
	}
	@PostMapping
	public ResponseEntity<Object> approveLeaveRequest(@RequestBody LeaveRequestDetails leaveRequestDetails
			,@RequestParam(value = "isLossOfPay") Boolean isLossOfPay){
		 ResponseEntity<Object> approveLeaveRequest = service.approveLeaveRequest(leaveRequestDetails,isLossOfPay);
		 if(approveLeaveRequest.getStatusCode() == HttpStatus.OK) {
			 ResponseEntity<Object> responseEntity = emailService.sendEmail(leaveRequestDetails);
		 }
		 return approveLeaveRequest;
	}
}
