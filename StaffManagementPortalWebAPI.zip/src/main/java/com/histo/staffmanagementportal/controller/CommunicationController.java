package com.histo.staffmanagementportal.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.histo.staffmanagementportal.dto.EmployeeCommunicationDTO;
import com.histo.staffmanagementportal.service.EmployeeCommunicationService;

@RestController
@RequestMapping("/communication")
public class CommunicationController {

	@Autowired
	private EmployeeCommunicationService service;
	
	@GetMapping("{employeeId}")
	public ResponseEntity<Object> getEmployeeCommunication(@PathVariable Integer employeeId){
		return service.getCommunicationByEmployeeId(employeeId);
	}
	
	@PostMapping
	public ResponseEntity<Object> createEmployeeCommunication(@Valid @RequestBody EmployeeCommunicationDTO employeeCommunicationDto){
		return service.saveCommunicationDetails(employeeCommunicationDto);
	}
	
	@PutMapping("{employeeCommunicationId}")
	public ResponseEntity<Object> updateEmployeeCommunication(@Valid @RequestBody EmployeeCommunicationDTO employeeCommunicationDto,
			@PathVariable Integer employeeCommunicationId){
		return service.updateCommunicationDetails(employeeCommunicationDto, employeeCommunicationId);
	}
}
