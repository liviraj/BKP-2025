package com.histo.staffmanagementportal.controller;

import com.azure.core.annotation.QueryParam;
import com.histo.staffmanagementportal.model.AttendanceFilter;
import com.histo.staffmanagementportal.service.AttdanceService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/attendance")
public class AttendanceController {

    private final AttdanceService attdanceService;

    public AttendanceController(AttdanceService attdanceService) {
        this.attdanceService = attdanceService;
    }

    @GetMapping("/reportsByPeriod")
    public ResponseEntity<Object> getReportsByPeriod(@QueryParam ("input")AttendanceFilter attendanceFilter){
        return attdanceService.getEmployeeAttendanceforReportbyPeriod (attendanceFilter);
    }

    @GetMapping("/monthlyReport")
    public ResponseEntity<Object> getMonthlyReport(@QueryParam ("input")AttendanceFilter attendanceFilter){
        return attdanceService.getEmployeeMonthlyAttendanceReport (attendanceFilter);
    }

    @GetMapping("/timingReport")
    public ResponseEntity<Object> getEmployeeTimingReport(@QueryParam ("input")AttendanceFilter attendanceFilter){
        return attdanceService.getEmployeeTimingDetailsByPeriod (attendanceFilter);
    }
}
