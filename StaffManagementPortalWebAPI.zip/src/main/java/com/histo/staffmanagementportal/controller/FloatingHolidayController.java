package com.histo.staffmanagementportal.controller;

import com.azure.core.annotation.QueryParam;
import com.histo.staffmanagementportal.dto.EmployeeHoliDayDTO;
import com.histo.staffmanagementportal.dto.HolidayDTO;
import com.histo.staffmanagementportal.dto.HolidayMasterDTO;
import com.histo.staffmanagementportal.model.FilterModel;
import com.histo.staffmanagementportal.model.FloatingHolidayFilter;
import com.histo.staffmanagementportal.service.FloatingHolidayService;
import com.histo.staffmanagementportal.service.HolidayService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/floating/holiday")
public class FloatingHolidayController {

    private final FloatingHolidayService holidayServiceImpl;

    public FloatingHolidayController(FloatingHolidayService holidayServiceImpl) {
        this.holidayServiceImpl = holidayServiceImpl;
    }

    @GetMapping("{year}")
    public ResponseEntity<Object> getHolidayList(@PathVariable("year") Integer year){
        return holidayServiceImpl.getFloatingHolidayList (year);
    }
    @GetMapping
    public ResponseEntity<Object> getEmployeeFloatingHoliday(@QueryParam (value = "input")FloatingHolidayFilter floatingHolidayFilter){
        return holidayServiceImpl.getEmployeeFloatingHoliday (floatingHolidayFilter);
    }
    @GetMapping("/list")
    public ResponseEntity<Object> getFloatingHolidayList(@QueryParam (value = "input") FilterModel filterModel){
        return holidayServiceImpl.getFloatingHoliday (filterModel);
    }

    @PutMapping
    public ResponseEntity<Object> editFloatingHolidayDetails(@RequestBody EmployeeHoliDayDTO holidayDTO){
        return holidayServiceImpl.addEmployeeFloatingHoliday (holidayDTO);
    }

}

