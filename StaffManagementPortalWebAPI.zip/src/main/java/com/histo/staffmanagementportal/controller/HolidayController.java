package com.histo.staffmanagementportal.controller;

import com.azure.core.annotation.QueryParam;
import com.histo.staffmanagementportal.dto.HolidayDTO;
import com.histo.staffmanagementportal.dto.HolidayMasterDTO;
import com.histo.staffmanagementportal.model.DeleteDetails;
import com.histo.staffmanagementportal.model.FilterModel;
import com.histo.staffmanagementportal.service.HolidayService;
import com.histo.staffmanagementportal.util.UsFederalHolidayResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/holiday")
public class HolidayController {

    private final HolidayService holidayServiceImpl;

    public HolidayController(HolidayService holidayServiceImpl) {
        this.holidayServiceImpl = holidayServiceImpl;
    }

    private final Map<String, UsFederalHolidayResponse> usFederalHoliday = new HashMap<> ();

    // POST Endpoint: Save data
    @PostMapping("/usFederal-holiday/{year}")
    public ResponseEntity<Object> saveData(@PathVariable("year") Integer holidayYear, @RequestBody UsFederalHolidayResponse usFederalHolidayResponse) {
        usFederalHoliday.put("usFederalHoliday", usFederalHolidayResponse);
        return holidayServiceImpl.getUSHolidayList (holidayYear,usFederalHoliday.get ("usFederalHoliday"));
    }

    @GetMapping("/list")
        public ResponseEntity<Object> getHolidayList(@QueryParam (value = "input") FilterModel filterModel){
            return holidayServiceImpl.getHolidayDetails (filterModel);
        }
    @GetMapping("/master")
    public ResponseEntity<Object> getHolidayMasterList(@QueryParam (value = "locationId") FilterModel filterModel){
        return holidayServiceImpl.getHolidayMasterList (filterModel);
    }

    @GetMapping("/floating/list")
    public ResponseEntity<Object> getFloatingHolidayMasterList(@QueryParam (value = "input") FilterModel filterModel){
        return holidayServiceImpl.getFloatingHolidayMasterList (filterModel);
    }

    @PostMapping
    public ResponseEntity<Object> addHolidayDetails(@RequestBody List<HolidayDTO> holidayDTO){
        return holidayServiceImpl.addHoliday (holidayDTO);
    }

    @PutMapping("{holidayId}")
    public ResponseEntity<Object> editHolidayDetails(@RequestBody HolidayDTO holidayDTO, @PathVariable("holidayId") Integer holidayId){
        return holidayServiceImpl.editHoliday (holidayId,holidayDTO);
    }

    @DeleteMapping("{holidayDetailId}")
    public ResponseEntity<Object> deleteHolidayDetails(@RequestBody DeleteDetails deleteDetails){
        return holidayServiceImpl.deleteHoliday (deleteDetails);
    }

    @DeleteMapping("/master/{holidayId}")
    public ResponseEntity<Object> deleteHolidayMaster(@RequestBody DeleteDetails deleteDetails){
        return holidayServiceImpl.deleteHolidayMaster (deleteDetails);
    }

    @PostMapping("/master")
    public ResponseEntity<Object> addHolidayMasterDetails(@RequestBody HolidayMasterDTO holidayDTO){
        return holidayServiceImpl.addHoliday (holidayDTO);
    }

    @PutMapping("/master/{holidayId}")
    public ResponseEntity<Object> editHolidayMasterDetails(@RequestBody HolidayMasterDTO holidayDTO, @PathVariable("holidayId") Integer holidayId){
        return holidayServiceImpl.editHoliday (holidayId,holidayDTO);
    }

}

