package com.histo.staffmanagementportal.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.azure.core.annotation.QueryParam;
import com.histo.staffmanagementportal.dto.EmployeeLeaveRequestDTO;
import com.histo.staffmanagementportal.model.Constants;
import com.histo.staffmanagementportal.model.LeaveHistoryFilterModel;
import com.histo.staffmanagementportal.service.EmailService;
import com.histo.staffmanagementportal.service.EmployeeLeaveRequestService;
import com.histo.staffmanagementportal.util.ResponseUtil;

@RestController
@RequestMapping("/leave")
public class LeaveRequestController {

	private final EmployeeLeaveRequestService service;
	private final EmailService emailService;

	public LeaveRequestController(EmployeeLeaveRequestService service, EmailService emailService) {
		this.service = service;
		this.emailService = emailService;
	}
	@GetMapping("/type/{locationId}")
	public ResponseEntity<Object> getLeaveTypeByLocationId(@PathVariable("locationId") Integer locationId){
		return service.getLeaveType(locationId);
	}
	@GetMapping("/balance/{employeeId}")
	public ResponseEntity<Object> getLeaveBalanceByEmployeeId(@PathVariable("employeeId") Integer employeeId){
		return service.getLastLeaveAvailed(employeeId);
	}
	
	@PostMapping("/request/{employeeId}")
	public ResponseEntity<Object> addLeaveRequest(@RequestBody EmployeeLeaveRequestDTO employeeLeaveRequestDTO,@PathVariable("employeeId") Integer employeeId
			,@RequestParam(value = "isLossOfPay") Boolean isLossOfPay){
		ResponseEntity<Object> leaveRequest = service.addLeaveRequest(employeeLeaveRequestDTO,employeeId,isLossOfPay);
		if(leaveRequest.getStatusCode() == HttpStatus.OK) {
			ResponseEntity<Object> responseEntity = emailService.sendEmail( leaveRequest.getBody(),Constants.LEDGER_ADD);
		}
		return leaveRequest;
	}
	@PutMapping("/request/{leaveRequestId}")
	public ResponseEntity<Object> editLeaveRequest(@RequestBody EmployeeLeaveRequestDTO employeeLeaveRequestDTO,@PathVariable("leaveRequestId") Integer leaveRequestId
			,@RequestParam(value = "isLossOfPay") Boolean isLossOfPay){
		ResponseEntity<Object> leaveRequest = service.editLeaveRequest(employeeLeaveRequestDTO,leaveRequestId,isLossOfPay);
		if(leaveRequest.getStatusCode() == HttpStatus.OK) {
			ResponseEntity<Object> responseEntity = emailService.sendEmail( leaveRequest.getBody(),Constants.LEDGER_UPDATE);
		}
		return leaveRequest;
	}
	@GetMapping("/history")
	public ResponseEntity<Object> getEmployeeLeaveHistory(@QueryParam(value = "input") LeaveHistoryFilterModel filterModel){
		return service.getEmployeeLeaveHistory(filterModel);
	}
}
