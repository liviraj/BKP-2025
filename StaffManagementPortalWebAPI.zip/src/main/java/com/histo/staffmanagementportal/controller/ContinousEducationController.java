package com.histo.staffmanagementportal.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.histo.staffmanagementportal.dto.EmployeeContinousEducationDTO;
import com.histo.staffmanagementportal.model.ModifiedDetails;
import com.histo.staffmanagementportal.service.EmployeeContinousEducationService;

@RestController
@RequestMapping("/continousEducation")
public class ContinousEducationController {

	@Autowired
	private EmployeeContinousEducationService service;
	
	@GetMapping("/details/{employeeId}")
	public ResponseEntity<Object> getContinousEducationByEmployeeId(@PathVariable("employeeId") Integer employeeId){
		return service.getContinousEducationByEmployeeId(employeeId);
	}
	
	@GetMapping("{continousEducationId}")
	public ResponseEntity<Object> getContinousEducationById(@PathVariable("continousEducationId") Integer continousEducationId){
		return service.getContinousEducationById(continousEducationId);
	}
	
	@PostMapping
	public ResponseEntity<Object> createEmployeeContinousEducation(@Valid @RequestBody EmployeeContinousEducationDTO continousEducationDTO){
		return service.addContinousEducation(continousEducationDTO);
	}
	
	@PutMapping("{continousEducationId}")
	public ResponseEntity<Object> updateEmployeeContinousEducation(@Valid @RequestBody EmployeeContinousEducationDTO continousEducationDTO
			,@PathVariable("continousEducationId") Integer continousEducationId){
		return service.updateContinousEducationById(continousEducationDTO,continousEducationId);
	}
	
	@DeleteMapping("{continousEducationId}")
	public ResponseEntity<Object> deletecontinousEducationId(@PathVariable("continousEducationId") Integer continousEducationId,@RequestBody ModifiedDetails modifiedDetails){
		return service.deleteEmployeeContinousEducationById(continousEducationId,modifiedDetails);
	}
}
