package com.histo.staffmanagementportal.controller;

import com.azure.core.annotation.QueryParam;
import com.histo.staffmanagementportal.dto.EmployeeRequestDetailsDTO;
import com.histo.staffmanagementportal.dto.EmployeeRequestTrackingDTO;
import com.histo.staffmanagementportal.dto.RequestStatusDetailsDTO;
import com.histo.staffmanagementportal.model.RequestFilterModel;
import com.histo.staffmanagementportal.model.RequestFilterValue;
import com.histo.staffmanagementportal.service.EmailService;
import com.histo.staffmanagementportal.service.EmployeeRequestService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/requests")
public class EmployeeRequestController {

    private final EmployeeRequestService employeeRequestService;

    private final EmailService emailService;

    public EmployeeRequestController(EmployeeRequestService employeeRequestService, EmailService emailService) {
        this.employeeRequestService = employeeRequestService;
        this.emailService = emailService;
    }
    @GetMapping()
    ResponseEntity<Object> getAllRequestTypes(){
        return employeeRequestService.getRequestTypes ();
    }

    @GetMapping("/assign")
    ResponseEntity<Object> getAllAssigneeDetails(){
        return employeeRequestService.getAssigneeDetails ();
    }

    @GetMapping("/details")
    ResponseEntity<Object> getEmployeeRequestDetails(@QueryParam ("values")RequestFilterValue filterValue){
        return employeeRequestService.getEmployeeRequestDetails (filterValue);
    }

    @GetMapping("/status")
    ResponseEntity<Object> getAllRequestStatus(){
        return employeeRequestService.requestStatus ();
    }

    @GetMapping("/approved/details")
    ResponseEntity<Object> getRequestDetails(@QueryParam ("values") RequestFilterModel filterValue){
        return employeeRequestService.requestTracking (filterValue);
    }

    @GetMapping("/details/{requestId}")
    ResponseEntity<Object> getEmployeeRequestDetailById(@PathVariable("requestId") Integer requestId){
        return employeeRequestService.getRequestDetailsById (requestId);
    }
    @PostMapping
    ResponseEntity<Object> addEmployeeRequests(@RequestBody EmployeeRequestDetailsDTO employeeRequestDetailsDTO){
        ResponseEntity<Object> responseEntity = employeeRequestService.addNewRequest (employeeRequestDetailsDTO);
        if(responseEntity.getStatusCode () == HttpStatus.OK){
            ResponseEntity<Object> sendMyRequestEmail = emailService.sendMyRequestEmail (responseEntity.getBody ());
        }
        return responseEntity;
    }

    @PutMapping("{requestId}")
    ResponseEntity<Object> editEmployeeRequests(@RequestBody EmployeeRequestDetailsDTO employeeRequestDetailsDTO, @PathVariable("requestId") Integer requestId){
        ResponseEntity<Object> responseEntity = employeeRequestService.updateRequestDetails (employeeRequestDetailsDTO, requestId);
        if(responseEntity.getStatusCode () == HttpStatus.OK){
            ResponseEntity<Object> sendMyRequestEmail = emailService.sendMyRequestEmail (responseEntity.getBody ());
        }
        return responseEntity;
    }

    @PostMapping("/approve")
    ResponseEntity<Object> approveOrRejectEmployeeRequest(@RequestBody RequestStatusDetailsDTO requestStatusDetailsDTO){
        ResponseEntity<Object> responseEntity = employeeRequestService.approveOrRejectRequest (requestStatusDetailsDTO);
        if(responseEntity.getStatusCode () == HttpStatus.OK){
            ResponseEntity<Object> sendMyRequestEmail = emailService.sendMyRequestEmail (responseEntity.getBody ());
        }
        return responseEntity;
    }

    @PutMapping("/tracking/{trackingId}")
    ResponseEntity<Object> updateTrackingStatus(@RequestBody EmployeeRequestTrackingDTO employeeRequestTrackingDTO, @PathVariable("trackingId") Integer trackingId){
        ResponseEntity<Object> responseEntity = employeeRequestService.updateAssignee (employeeRequestTrackingDTO,trackingId);
        if(responseEntity.getStatusCode () == HttpStatus.OK){
            ResponseEntity<Object> sendMyRequestEmail = emailService.sendMyRequestAssigneeEmail (responseEntity.getBody ());
        }
        return responseEntity;
    }
}
