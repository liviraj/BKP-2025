package com.histo.staffmanagementportal.controller;

import com.azure.core.annotation.QueryParam;
import com.histo.staffmanagementportal.dto.LeaveLedgerModifyDTO;
import com.histo.staffmanagementportal.model.*;
import com.histo.staffmanagementportal.service.EmailService;
import com.histo.staffmanagementportal.service.LeaveLedgerService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/leave/ledger")
public class LeaveLedgerController {

    private final LeaveLedgerService leaveLedgerService;
    
    private final EmailService emailService;

    public LeaveLedgerController(LeaveLedgerService leaveLedgerService, EmailService emailService) {
        this.leaveLedgerService = leaveLedgerService;
		this.emailService = emailService;
    }

    @GetMapping("/filter")
    public ResponseEntity<Object> doFilterInLeaveLedger(@QueryParam(value = "input") LeaveLedgerFilterModel ledgerFilterModel) {
        return leaveLedgerService.doFilterInLaveLedger(ledgerFilterModel);
    }
    
	@GetMapping("/balance")
	public ResponseEntity<Object> getLeaveBalance(@QueryParam(value = "input") LeaveSummaryFilter leaveFilter) {
		return leaveLedgerService.getLeaveBalance(leaveFilter);
	}

	@GetMapping("/summary")
	public ResponseEntity<Object> getLeaveSummary(@QueryParam(value = "input") LeaveSummaryFilter leaveFilter) {
		return leaveLedgerService.getLeaveSummary(leaveFilter);
	}
	
    @PutMapping("/{ledgerId}")
    public ResponseEntity<Object> editLeaveLedger(@PathVariable Integer ledgerId, @RequestBody LeaveLedgerModifyDTO leaveLedger) {
    	
    	ResponseEntity<Object> responseEntity = leaveLedgerService.editLeaveLedger(ledgerId, leaveLedger);
    	 if(responseEntity.getStatusCode() == HttpStatus.OK) {
			 ResponseEntity<Object> emailResponseEntity = emailService.sendLedgerUpdateEmail(responseEntity.getBody());
		 }
        return responseEntity;
    }

    @DeleteMapping("/{ledgerId}")
    public ResponseEntity<Object> deleteLeaveLedger(@PathVariable Integer ledgerId,@RequestBody LedgerDetails ledgerDetails) {
    	ResponseEntity<Object> responseEntity = leaveLedgerService.deleteLeaveLedger(ledgerId,ledgerDetails);
   	    if(responseEntity.getStatusCode() == HttpStatus.OK) {
		 ResponseEntity<Object> emailResponseEntity = emailService.sendLedgerUpdateEmail(responseEntity.getBody());
	 }
     return responseEntity;
    }
    
    @PostMapping
    public ResponseEntity<Object> addLeaveLedger(@RequestBody LedgerCreditModel ledgerCreditModel) {
    	
    	ResponseEntity<Object> responseEntity = leaveLedgerService.addLeaveCredit(ledgerCreditModel);
   	 if(responseEntity.getStatusCode() == HttpStatus.OK) {
		 ResponseEntity<Object> emailResponseEntity = emailService.sendLedgerUpdateEmail(responseEntity.getBody());
	 }
    return responseEntity;
 
    }
    
}
