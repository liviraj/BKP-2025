package com.histo.staffmanagementportal.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import com.histo.staffmanagementportal.dto.LoginDTO;
import com.histo.staffmanagementportal.dto.UserLoginDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.azure.core.annotation.QueryParam;
import com.histo.staffmanagementportal.model.LoginFilterModel;
import com.histo.staffmanagementportal.model.ModifiedDetails;
import com.histo.staffmanagementportal.service.EmailService;
import com.histo.staffmanagementportal.service.UserService;


@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService service;
    
    @Autowired
	private EmailService emailService;

    @GetMapping
    public ResponseEntity<Object> getLoginDetails(@QueryParam(value = "input") LoginFilterModel loginFilter) {
        return service.findAllLogins(loginFilter);
    }

    @GetMapping("{loginId}")
    public ResponseEntity<Object> getUserByLoginId(@PathVariable Integer loginId) {
        return service.findByLoginId(loginId);
    }

    @PostMapping
    public ResponseEntity<Object> createUser(@Valid @RequestBody LoginDTO logindto,@RequestParam(value = "isNewUser") Boolean isNewUser) {
    	ResponseEntity<Object> responseEntity = service.createUser(logindto,isNewUser);
    	if(responseEntity.getStatusCode() == HttpStatus.CREATED) {
    		ResponseEntity<Object> responseEntity2 = emailService.sendNewLoginDetailsEmail(responseEntity.getBody());
    	}
        return responseEntity;
    }

    @PutMapping("{loginId}")
    public ResponseEntity<Object> updateUser(@Valid @RequestBody LoginDTO logindto, @PathVariable Integer loginId) {
        return service.updateUser(loginId, logindto);
    }

    @GetMapping("/login")
    public ResponseEntity<Object> loginUser() {
        return service.loginUser();
    }
    
    @DeleteMapping("{loginId}")
    public ResponseEntity<Object> deteleLoginDetails(@PathVariable("loginId") Integer loginId,@RequestBody ModifiedDetails modifiedDetails){
    	return service.deleteByLoginId(loginId,modifiedDetails);
    }
 
}
