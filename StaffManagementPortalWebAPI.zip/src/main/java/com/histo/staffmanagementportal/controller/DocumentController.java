package com.histo.staffmanagementportal.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.histo.staffmanagementportal.dto.EmployeeDocumentDTO;
import com.histo.staffmanagementportal.model.ModifiedDetails;
import com.histo.staffmanagementportal.service.EmployeeDocumentService;

@RestController
@RequestMapping("/hrDocument")
public class DocumentController {

	@Autowired
	private EmployeeDocumentService service;
	
	@GetMapping("{documentId}")
	public ResponseEntity<Object> getHrDocumentById(@PathVariable("documentId") Integer documentId){
		return service.getEmployeeDocumentById(documentId);
	}
	
	@GetMapping("/details/{employeeId}")
	public ResponseEntity<Object> getHrDocumentByEmployeeId(@PathVariable("employeeId") Integer employeeId){
		return service.getEmployeeDocumentByEmployeeId(employeeId);
	}
	
	@PostMapping
	public ResponseEntity<Object> addEmployeeDocument(@Valid @RequestBody EmployeeDocumentDTO documentDTO){
		return service.addEmployeeHrDocument(documentDTO);
	}
	
	@PutMapping("{documentId}")
	public ResponseEntity<Object> updateEmployeeDocument(@Valid @RequestBody EmployeeDocumentDTO documentDTO,@PathVariable("documentId") Integer documentId){
		return service.updateEmployeeHrDocument(documentDTO, documentId);
	}
	
	@GetMapping("/type")
	public ResponseEntity<Object> getEmployeeDocumentType(){
		return service.getDocumentType();
	}
	
	@DeleteMapping("{documentId}")
	public ResponseEntity<Object> deleteDocument(@PathVariable("documentId") Integer documentId,@RequestBody ModifiedDetails modifiedDetails){
		return service.deleteEmployeeDocumentById(documentId,modifiedDetails);
	}
}
