package com.histo.staffmanagementportal.intranet.entity;

import com.histo.staffmanagementportal.util.InstantConverter;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.Instant;

@Entity
public class EmployeeHoliDay {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EmployeeHoliDayID", nullable = false)
    private Integer id;

    @NotNull
    @Column(name = "EmployeeID", nullable = false)
    private Integer employeeId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "HoliDayID", nullable = false)
    private Holiday holiDayId;

    @NotNull
    @Column(name = "\"Year\"", nullable = false)
    private Integer year;

	@Column(name = "AddedBy", nullable = false)
	private Integer addedBy;

	@Column(name = "ModifiedBy", nullable = false)
	private Integer modifiedBy;

	@Column(name = "AddedOn")
	@Convert(converter = InstantConverter.class)
	private Instant addedOn;

	@Column(name = "ModifiedOn")
	@Convert(converter = InstantConverter.class)
	private Instant modifiedOn;

	public Integer getAddedBy() {
		return addedBy;
	}

	public void setAddedBy(Integer addedBy) {
		this.addedBy = addedBy;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Instant getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Instant addedOn) {
		this.addedOn = addedOn;
	}

	public Instant getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Instant modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public Holiday getHoliDayId() {
		return holiDayId;
	}

	public void setHoliDayId(Holiday holiDayId) {
		this.holiDayId = holiDayId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

    
}