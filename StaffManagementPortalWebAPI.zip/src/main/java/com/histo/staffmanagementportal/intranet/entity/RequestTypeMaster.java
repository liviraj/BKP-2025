package com.histo.staffmanagementportal.intranet.entity;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "RequestTypeMaster")
public class RequestTypeMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "RequestTypeId")
    private Integer requestTypeId;

    @Column(name = "Request")
    private String request;

    @Column(name = "Description")
    private String description;

    @Column(name = "RecordStatus")
    private String recordStatus;

    @Column(name = "LocationId")
    private Integer locationId;
}
