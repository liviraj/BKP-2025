package com.histo.staffmanagementportal.intranet.repository;

import com.histo.staffmanagementportal.intranet.entity.HolidayMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface HolidayMasterRepository extends JpaRepository<HolidayMaster, Integer> {
    Optional<HolidayMaster> findByHolidayNameLikeIgnoreCaseAndLocationIdAndRecordStatus(String holidayName, Integer locationId, String recordStatus);

    @Transactional
    @Modifying
    @Query("update HolidayMaster h set h.recordStatus = ?2, h.modifiedBy = ?3, h.modifiedOn = ?4 where h.holidayId = ?1 and h.recordStatus = 'A'")
    int updateRecordStatusByHolidayIdAndRecordStatus( Integer holidayId, String recordStatus, Integer modifiedBy, Timestamp modifiedOn);

    Optional<HolidayMaster> findByHolidayIdAndRecordStatus(Integer holidayId, String recordStatus);



}
