package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "Attributes")
public class Attribute {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "AttributeID", nullable = false)	
	private Integer id;
	
	@Column(name = "AttributeName")	
	private String attributeName;
	
	@Column(name = "AttributeValue")	
	private String attributeValue;
	
	@Column(name = "Category")	
	private String category;
	
	@Column(name = "EmployeeID")	
	private Integer employeeId;

	public Attribute() {
		super();
	}

	public Attribute(Integer id, String attributeName, String attributeValue, String category, Integer employeeId) {
		super();
		this.id = id;
		this.attributeName = attributeName;
		this.attributeValue = attributeValue;
		this.category = category;
		this.employeeId = employeeId;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAttributeName() {
		return attributeName;
	}

	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	public String getAttributeValue() {
		return attributeValue;
	}

	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

}
