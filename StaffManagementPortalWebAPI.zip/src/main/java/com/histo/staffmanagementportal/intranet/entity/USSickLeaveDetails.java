package com.histo.staffmanagementportal.intranet.entity;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Size;

import com.histo.staffmanagementportal.util.InstantConverter;

@Entity(name = "USSickLeaveDetails")
public class USSickLeaveDetails {
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "USSickleaveDetailID", nullable = false)
    private Integer id;

    @Column(name = "EmployeeID")
    private Integer employeeId;

    @Column(name = "CreditHrs")
    private Double creditHrs = 0.0;

    @Column(name = "CreditDays")
    private Double creditDays = 0.0;

    @Column(name = "DebitHrs")
    private Double debitHrs = 0.0;

    @Column(name = "DebitDays")
    private Double debitDays = 0.0;

    @Column(name = "Balance")
    private Double balance = 0.0;

    @Column(name = "EntryDate")
    @Convert(converter = InstantConverter.class)
    private Instant entryDate;
    
    @Column(name = "RunDate")
    @Convert(converter = InstantConverter.class)
    private Instant runDate;

    @Size(max = 500)
    @Column(name = "Comment", length = 500)
    private String comment;

    @Column(name = "BalanceHours")
    private Double balanceHours = 0.0;

    @Column(name = "LeaveAddedBy")
    private Integer leaveAddedBy;
    
    @Column(name = "ModifiedOn")
    @Convert(converter = InstantConverter.class)
    private Instant modifiedOn;
    
    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    
	public USSickLeaveDetails() {
		super();
	}

	public USSickLeaveDetails(Integer employeeId, Double creditHrs, Double creditDays, Double balance, Instant entryDate, Instant runDate, String comment,
			Double balanceHours, Integer leaveAddedBy, Double debitHrs, Double debitDays) {
		super();
		this.employeeId = employeeId;
		this.creditHrs = creditHrs;
		this.creditDays = creditDays;
		this.debitHrs = debitHrs;
		this.debitDays = debitDays;
		this.balance = balance;
		this.entryDate = entryDate;
		this.runDate = runDate;
		this.comment = comment;
		this.balanceHours = balanceHours;
		this.leaveAddedBy = leaveAddedBy;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer uSSickleaveDetailID) {
		this.id = uSSickleaveDetailID;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeID) {
		this.employeeId = employeeID;
	}

	public Double getCreditHrs() {
		return creditHrs;
	}

	public void setCreditHrs(Double creditHrs) {
		this.creditHrs = creditHrs;
	}

	public Double getCreditDays() {
		return creditDays;
	}

	public void setCreditDays(Double creditDays) {
		this.creditDays = creditDays;
	}

	public Double getDebitHrs() {
		return debitHrs;
	}

	public void setDebitHrs(Double debitHrs) {
		this.debitHrs = debitHrs;
	}

	public Double getDebitDays() {
		return debitDays;
	}

	public void setDebitDays(Double debitDays) {
		this.debitDays = debitDays;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public Instant getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(Instant entryDate) {
		this.entryDate = entryDate;
	}

	public Instant getRunDate() {
		return runDate;
	}

	public void setRunDate(Instant runDate) {
		this.runDate = runDate;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Double getBalanceHours() {
		return balanceHours;
	}

	public void setBalanceHours(Double balanceHours) {
		this.balanceHours = balanceHours;
	}

	public Integer getLeaveAddedBy() {
		return leaveAddedBy;
	}

	public void setLeaveAddedBy(Integer leaveAddedBy) {
		this.leaveAddedBy = leaveAddedBy;
	}

	public Instant getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Instant modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
   

}