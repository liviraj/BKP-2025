package com.histo.staffmanagementportal.intranet.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.histo.staffmanagementportal.intranet.entity.EmployeeWorkSchedule;
import com.histo.staffmanagementportal.model.EmployeeWorkScheduleModel;

public interface EmployeeWorkScheduleRepository extends JpaRepository<EmployeeWorkSchedule, Integer> {

	@Query("""
			select new com.histo.staffmanagementportal.model.EmployeeWorkScheduleModel(
			fromDate,workDays,toDate,activity,recordStatus,totalhrsperday)
			from EmployeeWorkSchedule where employeeId=:employeeId
			""")
	List<EmployeeWorkScheduleModel> findWorkSchedule(@Param("employeeId") Integer employeeId);
}