package com.histo.staffmanagementportal.intranet.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.histo.staffmanagementportal.intranet.entity.EmployeeLeaveRequestMaster;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface EmployeeLeaveRequestMasterRepository extends JpaRepository<EmployeeLeaveRequestMaster, Integer>{

	List<EmployeeLeaveRequestMaster> findByEmployeeIdOrderByLeaveFromDesc(Integer employeeId);

	List<EmployeeLeaveRequestMaster> findByLeaveFromAndLeaveToAndEmployeeId(Instant leaveFrom,Instant leaveTo,Integer employeeId);

	@Query(value = """
	 		SELECT ISNULL(sum(Debit),0) FROM EmployeeLeaveRequestMaster ELM, EmployeeleaveDetails LD,  LeaveTypeMaster L, SpecialLeavesDebitDetails SD  
	 		WHERE TypeOfLeave = L.LeaveTypeID
	 		AND L.LeaveTypeName = 'Casual Leave'
	 		AND ELM.LeaveRequestID = LD.LeaveRequestID
	 		AND LD.EmployeeId=SD.EmployeeId AND LD.LeaveDate=SD.LeaveDate
	 		AND (MONTH(LD.LeaveDate) = MONTH(:fromDate) OR MONTH(LD.LeaveDate) = MONTH(:toDate))
	 		AND (YEAR(LD.LeaveDate) = YEAR(:fromDate) OR YEAR(LD.LeaveDate) = YEAR(:toDate))
	 		AND ELM.EmployeeID=:employeeId AND LD.ApprovalStatus='A' 
	 		""",nativeQuery = true)
	public Integer getTotalClTaken(@Param("employeeId") Integer employeeId,@Param("fromDate") Instant fromDate,@Param("toDate") Instant toDate);

	Optional<EmployeeLeaveRequestMaster> findFirstByEmployeeIdOrderByLeaveEnteredOnDesc(Integer employeeId);

	Optional<EmployeeLeaveRequestMaster> findFirstById(Integer id);

}
