package com.histo.staffmanagementportal.intranet.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.histo.staffmanagementportal.intranet.entity.EmployeeCompensation;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Optional;

public interface EmployeeCompensationRepository extends JpaRepository<EmployeeCompensation, Integer>{

    Optional<EmployeeCompensation> findByEmployeeIDAndLeaveDateAndCompensationDateNotNull(Integer employeeID, Instant leaveDate);

    Optional<EmployeeCompensation> findByEmployeeIDAndCompensationDate(Integer employeeID, Instant compensationDate);

    @Transactional
    @Modifying
    @Query("""
    		update EmployeeCompensation e set e.isCompensated = ?1 where  e.employeeID = ?2 and e.compensationDate = ?3
    		""" )
    int updateIsCompensatedByEmployeeIDAndCompensationDate(Boolean isCompensated, Integer employeeID, Instant compensationDate);




}
