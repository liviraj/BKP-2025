package com.histo.staffmanagementportal.intranet.repository;

import com.histo.staffmanagementportal.intranet.entity.Document;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface DocumentRepository extends JpaRepository<Document,Integer> {
    Optional<Document> findByIdAndRecordStatusAndDocumentType(Integer id, String recordStatus, String documentType);

    List<Document> findByDocumentIdAndRecordStatusAndDocumentType(Integer documentId, String recordStatus, String documentType);


}
