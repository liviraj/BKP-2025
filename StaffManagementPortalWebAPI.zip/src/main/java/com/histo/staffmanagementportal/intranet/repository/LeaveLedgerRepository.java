package com.histo.staffmanagementportal.intranet.repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.histo.staffmanagementportal.intranet.entity.LeaveLedger;

public interface LeaveLedgerRepository extends JpaRepository<LeaveLedger, Integer>{

    @Query("""
            Select l from LeaveLedger l where l.employeeId = ?1 and year(EntryDate) >= year(getDate())
            and  l.id not in (select id from LeaveLedger where entryDate in
	        (select entryDate from LeaveLedger where employeeId = ?1 and comments like '%Cancelled%')
	        and creditdays = 0) order by 1 desc
            """)
    List<LeaveLedger> findLeaveBalance(Integer employeeID);
    
    List<LeaveLedger> findByEmployeeIdOrderByIdDesc(Integer employeeId);

    List<LeaveLedger> findByEmployeeIdOrderByIdAsc(Integer employeeId);
    
    Optional<LeaveLedger> findByIdAndCommentsEndsWith(Integer id, String comments);
    
    Optional<LeaveLedger> findByEmployeeIdAndEntryDate(Integer employeeId,Instant entryDate);
    
    LeaveLedger findFirstByEmployeeIdOrderByIdDesc(Integer employeeId);
    
    

}
