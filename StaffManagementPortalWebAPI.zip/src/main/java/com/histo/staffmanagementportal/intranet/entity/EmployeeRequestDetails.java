package com.histo.staffmanagementportal.intranet.entity;

import com.histo.staffmanagementportal.intranet.entity.RequestTypeMaster;
import com.histo.staffmanagementportal.util.InstantConverter;
import lombok.Data;

import javax.persistence.*;
import java.time.Instant;

@Data
@Entity
@Table(name = "EmployeeRequestDetails")
public class EmployeeRequestDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "RequestId")
    private Integer requestId;

    @Column(name = "EmployeeID")
    private Integer employeeId;

    @ManyToOne
    @JoinColumn(name = "RequestTypeId", referencedColumnName = "RequestTypeId")
    private RequestTypeMaster requestType;

    @Column(name = "Description")
    private String description;

    @Column(name = "ImageName")
    private String imageName;

    @Lob
    @Column(name = "ImageBinary")
    private byte[] imageBinary;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @Column(name = "ModifiedOn")
    @Convert(converter = InstantConverter.class)
    private Instant modifiedOn;

    @Column(name = "CreatedBy")
    private Integer createdBy;

    @Column(name = "CreatedOn")
    @Convert(converter = InstantConverter.class)
    private Instant createdOn;

    @Column(name = "RecordStatus")
    private String recordStatus;
}
