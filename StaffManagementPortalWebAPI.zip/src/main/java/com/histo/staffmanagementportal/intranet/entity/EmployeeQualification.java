package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.*;

import com.histo.staffmanagementportal.util.InstantConverter;

import java.time.Instant;

@Entity(name = "EmployeeQualification")
public class EmployeeQualification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EmpQualificationID", nullable = false)
    private Integer id;

    @Column(name = "Employeeid", nullable = false)
    private Integer employeeid;

    @Column(name = "Qualification", nullable = false, length = 50)
    private String qualification;

    @Column(name = "Institution", nullable = false, length = 50)
    private String institution;

    @Column(name = "MajorSubject", length = 50)
    private String majorSubject;

    @Column(name = "Type")
    private Character type;

    @Column(name = "\"Value\"", length = 10)
    private String value;

    @Column(name = "CourseDuration", length = 15)
    private String courseDuration;

    @Column(name = "CourseStartDate")
    private Instant courseStartDate;

    @Column(name = "CourseEndDate")
    private Instant courseEndDate;

    @Column(name = "University", length = 50)
    private String university;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @Column(name = "ModifiedDate")
    @Convert(converter = InstantConverter.class)
    private Instant modifiedDate;
    
    @Column(name = "CreatedBy", nullable = false)
    private Integer createdBy;

    @Column(name = "CreatedOn", nullable = false)
    private Instant createdOn;

    @Column(name = "RecordStatus")
    private Character recordStatus;

    @Column(name = "EmployeeImage")
    private String employeeImage;

    @Column(name = "IsPartOfCLEP")
    private Character isPartOfCLEP;

    @Column(name = "Location", length = 50)
    private String location;

    @Column(name = "EmployeeImageBinary")
    private byte[] employeeImageBinary;

    public Integer getId() {
        return id;
    }

    public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Instant getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Instant createdOn) {
		this.createdOn = createdOn;
	}

	public void setId(Integer id) {
        this.id = id;
    }

    public Integer getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(Integer employeeid) {
        this.employeeid = employeeid;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getInstitution() {
        return institution;
    }

    public void setInstitution(String institution) {
        this.institution = institution;
    }

    public String getMajorSubject() {
        return majorSubject;
    }

    public void setMajorSubject(String majorSubject) {
        this.majorSubject = majorSubject;
    }

    public Character getType() {
        return type;
    }

    public void setType(Character type) {
        this.type = type;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getCourseDuration() {
        return courseDuration;
    }

    public void setCourseDuration(String courseDuration) {
        this.courseDuration = courseDuration;
    }

    public Instant getCourseStartDate() {
        return courseStartDate;
    }

    public void setCourseStartDate(Instant courseStartDate) {
        this.courseStartDate = courseStartDate;
    }

    public Instant getCourseEndDate() {
        return courseEndDate;
    }

    public void setCourseEndDate(Instant courseEndDate) {
        this.courseEndDate = courseEndDate;
    }

    public String getUniversity() {
        return university;
    }

    public void setUniversity(String university) {
        this.university = university;
    }

    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Character getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(Character recordStatus) {
        this.recordStatus = recordStatus;
    }

    public String getEmployeeImage() {
        return employeeImage;
    }

    public void setEmployeeImage(String employeeImage) {
        this.employeeImage = employeeImage;
    }

    public Character getIsPartOfCLEP() {
        return isPartOfCLEP;
    }

    public void setIsPartOfCLEP(Character isPartOfCLEP) {
        this.isPartOfCLEP = isPartOfCLEP;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public byte[] getEmployeeImageBinary() {
        return employeeImageBinary;
    }

    public void setEmployeeImageBinary(byte[] employeeImageBinary) {
        this.employeeImageBinary = employeeImageBinary;
    }

}