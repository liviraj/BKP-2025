package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.Instant;

@Entity
public class Role {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "RoleID", nullable = false)
    private Integer id;

    @Size(max = 50)
    @NotNull
    @Column(name = "RoleName", nullable = false, length = 50)
    private String roleName;

    @Size(max = 500)
    @NotNull
    @Column(name = "RoleDescription", nullable = false, length = 500)
    private String roleDescription;

    @NotNull
    @Column(name = "ModifiedBy", nullable = false)
    private Integer modifiedBy;

    @NotNull
    @Column(name = "ModifiedDate", nullable = false)
    private Instant modifiedDate;

    @NotNull
    @Column(name = "RecordStatus", nullable = false)
    private Character recordStatus;

    @Column(name = "RoleStatus")
    private Character roleStatus;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getRoleDescription() {
        return roleDescription;
    }

    public void setRoleDescription(String roleDescription) {
        this.roleDescription = roleDescription;
    }

    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Character getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(Character recordStatus) {
        this.recordStatus = recordStatus;
    }

    public Character getRoleStatus() {
        return roleStatus;
    }

    public void setRoleStatus(Character roleStatus) {
        this.roleStatus = roleStatus;
    }

}