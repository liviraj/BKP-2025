package com.histo.staffmanagementportal.intranet.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.histo.staffmanagementportal.intranet.entity.LeaveEncashment;

import java.time.Instant;
import java.util.Optional;

public interface LeaveEncashmentRepository extends JpaRepository<LeaveEncashment, Integer> {
    Optional<LeaveEncashment> findByEmployeeIdAndEncashmentDate(Integer employeeId, Instant encashmentDate);

}
