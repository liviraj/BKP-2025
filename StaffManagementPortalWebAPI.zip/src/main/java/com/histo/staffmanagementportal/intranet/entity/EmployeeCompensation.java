package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.Instant;

@Entity
public class EmployeeCompensation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EmployeeCompensationID", nullable = false)
    private Integer id;

    @NotNull
    @Column(name = "EmployeeID", nullable = false)
    private Integer employeeID;

    @Column(name = "CompensationTypeID")
    private Integer compensationTypeID;

    @Size(max = 500)
    @Column(name = "Reason", length = 500)
    private String reason;

    @Column(name = "LeaveDate")
    private Instant leaveDate;

    @Column(name = "CompensationDate")
    private Instant compensationDate;

    @Column(name = "IsCompensated")
    private Boolean isCompensated;

	/**
	 * 
	 */
	public EmployeeCompensation() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(Integer employeeID) {
		this.employeeID = employeeID;
	}

	public Integer getCompensationTypeID() {
		return compensationTypeID;
	}

	public void setCompensationTypeID(Integer compensationTypeID) {
		this.compensationTypeID = compensationTypeID;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Instant getLeaveDate() {
		return leaveDate;
	}

	public void setLeaveDate(Instant leaveDate) {
		this.leaveDate = leaveDate;
	}

	public Instant getCompensationDate() {
		return compensationDate;
	}

	public void setCompensationDate(Instant compensationDate) {
		this.compensationDate = compensationDate;
	}

	public Boolean getIsCompensated() {
		return isCompensated;
	}

	public void setIsCompensated(Boolean isCompensated) {
		this.isCompensated = isCompensated;
	}

}