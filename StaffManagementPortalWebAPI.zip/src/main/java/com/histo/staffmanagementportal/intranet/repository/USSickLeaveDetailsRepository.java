package com.histo.staffmanagementportal.intranet.repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.histo.staffmanagementportal.intranet.entity.USSickLeaveDetails;
import org.springframework.data.jpa.repository.Query;

public interface USSickLeaveDetailsRepository extends JpaRepository<USSickLeaveDetails, Integer> {

	List<USSickLeaveDetails> findByEmployeeIdOrderByIdDesc(Integer employeeId);

	@Query("""
   Select s from USSickLeaveDetails s where s.employeeId = ?1 and year(EntryDate) >= year(GetDate())
   and s.id not in (select id from USSickLeaveDetails where entryDate in
   (select entryDate from USSickLeaveDetails where employeeId = ?1 and comment LIKE '%Cancelled%')
   and creditDays = 0) order by 1 desc
			""")
	List<USSickLeaveDetails> getLeaveBalance(Integer employeeId);

	USSickLeaveDetails findFirstByEmployeeIdOrderByIdDesc(Integer employeeId);

	Optional<USSickLeaveDetails> findByEmployeeIdAndEntryDate(Integer employeeId, Instant entryDate);

	List<USSickLeaveDetails> findByEmployeeIdOrderByIdAsc(Integer employeeId);

	List<USSickLeaveDetails> findByEmployeeIdAndIdGreaterThanOrderByIdAsc(Integer employeeId, Integer id);

	Optional<USSickLeaveDetails> findByIdAndCommentEndsWith(Integer id, String comment);

	List<USSickLeaveDetails> findByEmployeeIdAndIdGreaterThanEqualOrderByIdAsc(Integer id, Integer employeeId);

	USSickLeaveDetails findFirstByEmployeeIdAndIdLessThanOrderByIdDesc(Integer employeeId, Integer id);


}
