package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.histo.staffmanagementportal.util.InstantConverter;

import java.time.Instant;

@Entity
public class EmployeeLeaveDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "LeaveRequestDetailsId", nullable = false)
    private Integer id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "LeaveRequestId", nullable = false)
    private EmployeeLeaveRequestMaster leaveRequestId;

    @NotNull
    @Column(name = "EmployeeId", nullable = false)
    private Integer employeeId;

    @NotNull
    @Column(name = "LeaveDate", nullable = false)
    @Convert(converter = InstantConverter.class)
    private Instant leaveDate;

    @Size(max = 1)
    @Column(name = "PaidorLossofPay", length = 1)
    private String paidorLossofPay;

    @Column(name = "ReviewedBy")
    private Integer reviewedBy;

    @Column(name = "ReviewedOn")
    @Convert(converter = InstantConverter.class)
    private Instant reviewedOn;

    @Column(name = "ApproverComments")
    private String approverComments;

    @Size(max = 1)
    @Column(name = "Availed", length = 1)
    private String availed;

    @Size(max = 255)
    @Column(name = "ApprovalStatus")
    private String approvalStatus;

    @Column(name = "IsIntimated")
    private Character isIntimated;

    @Column(name = "JobStatus")
    private Boolean jobStatus;
    
    @Column(name = "ModifiedBy")
    private Integer modifiedBy;
    
    @Column(name = "ModifiedOn")
    private Instant modifiedOn;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public EmployeeLeaveRequestMaster getLeaveRequestId() {
		return leaveRequestId;
	}

	public void setLeaveRequestId(EmployeeLeaveRequestMaster leaveRequestId) {
		this.leaveRequestId = leaveRequestId;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public Instant getLeaveDate() {
		return leaveDate;
	}

	public void setLeaveDate(Instant leaveDate) {
		this.leaveDate = leaveDate;
	}

	public String getPaidorLossofPay() {
		return paidorLossofPay;
	}

	public void setPaidorLossofPay(String paidorLossofPay) {
		this.paidorLossofPay = paidorLossofPay;
	}

	public Integer getReviewedBy() {
		return reviewedBy;
	}

	public void setReviewedBy(Integer reviewedBy) {
		this.reviewedBy = reviewedBy;
	}

	public Instant getReviewedOn() {
		return reviewedOn;
	}

	public void setReviewedOn(Instant reviewedOn) {
		this.reviewedOn = reviewedOn;
	}

	public String getApproverComments() {
		return approverComments;
	}

	public void setApproverComments(String approverComments) {
		this.approverComments = approverComments;
	}

	public String getAvailed() {
		return availed;
	}

	public void setAvailed(String availed) {
		this.availed = availed;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public Character getIsIntimated() {
		return isIntimated;
	}

	public void setIsIntimated(Character isIntimated) {
		this.isIntimated = isIntimated;
	}

	public Boolean getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(Boolean jobStatus) {
		this.jobStatus = jobStatus;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Instant getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Instant modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	
}