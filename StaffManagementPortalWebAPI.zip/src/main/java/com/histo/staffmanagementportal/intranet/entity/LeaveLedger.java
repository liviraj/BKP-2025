package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.histo.staffmanagementportal.util.InstantConverter;

import java.time.Instant;


@Entity
public class LeaveLedger {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "LeaveLedgerID", nullable = false)
    private Integer id;

    @NotNull
    @Column(name = "EmployeeId", nullable = false)
    private Integer employeeId;

    @NotNull
    @Column(name = "EntryDate", nullable = false)
    @Convert(converter = InstantConverter.class)
    private Instant entryDate;

    @Column(name = "CreditDays")
    private Double creditDays = 0.0;

    @Column(name = "DebitDays")
    private Double debitDays = 0.0;

    @Column(name = "BalanceDays")
    private Double balanceDays = 0.0;

    @Size(max = 500)
    @Column(name = "Comments", length = 500)
    private String comments;

    @Column(name = "RunDate")
    @Convert(converter = InstantConverter.class)
    private Instant runDate;
    
    @Column(name = "ModifiedOn")
    @Convert(converter = InstantConverter.class)
    private Instant modifiedDate;
    
    @Column(name = "ModifiedBy")
    private Integer modifiedBy;
    
	public Instant getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Instant modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public Instant getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(Instant entryDate) {
		this.entryDate = entryDate;
	}

	public Double getCreditDays() {
		return creditDays;
	}

	public void setCreditDays(Double creditDays) {
		this.creditDays = creditDays;
	}

	public Double getDebitDays() {
		return debitDays;
	}

	public void setDebitDays(Double debitDays) {
		this.debitDays = debitDays;
	}

	public Double getBalanceDays() {
		return balanceDays;
	}

	public void setBalanceDays(Double balanceDays) {
		this.balanceDays = balanceDays;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Instant getRunDate() {
		return runDate;
	}

	public void setRunDate(Instant runDate) {
		this.runDate = runDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}