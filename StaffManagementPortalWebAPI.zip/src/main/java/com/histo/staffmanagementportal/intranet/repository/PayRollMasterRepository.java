package com.histo.staffmanagementportal.intranet.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.histo.staffmanagementportal.intranet.entity.PayRollMaster;
import org.springframework.data.jpa.repository.Query;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface PayRollMasterRepository extends JpaRepository<PayRollMaster, Integer> {

    Optional<PayRollMaster> findFirstByLocationIdOrderByIdDesc(Integer locationId);

    List<PayRollMaster> findByLocationIdOrderByIdAsc(Integer locationId);

    @Query(value = "select p.* from PayRollMaster p where p.locationId = ?1 and CAST(?2 AS Date) between CAST(p.fromDate AS Date) and CAST(p.toDate AS Date)",
    	   nativeQuery = true)
    Optional<PayRollMaster> findByLocationIdAndDateBetween(Integer locationId, Instant startDate);

    @Query(value = "select p.* from PayRollMaster p where cast(getDate() as date) between p.fromDate AND p.toDate", nativeQuery = true)
    List<PayRollMaster> findByCurrentDate();

    Optional<PayRollMaster> findFirstByIdLessThanAndLocationIdOrderByIdDesc(Integer id, Integer locationId);

    Optional<PayRollMaster> findFirstByIdGreaterThanAndLocationIdOrderByIdAsc(Integer id, Integer locationId);


}
