package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.Instant;

@Entity
public class CompanyLeavePolicy {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "LeavePolicyID", nullable = false)
    private Integer id;

    @NotNull
    @Column(name = "LocationId", nullable = false)
    private Integer locationId;

    @Column(name = "ActiveFrom")
    private Instant activeFrom;

    @Column(name = "ActiveTo")
    private Instant activeTo;

    @NotNull
    @Column(name = "LeaveCreditDays", nullable = false)
    private Double leaveCreditDays;

    @Size(max = 255)
    @NotNull
    @Column(name = "LeaveCreditBasedOn", nullable = false)
    private String leaveCreditBasedOn;

    @Size(max = 1)
    @NotNull
    @Column(name = "ExcludeHolidaysFromLeave", nullable = false, length = 1)
    private String excludeHolidaysFromLeave;

    @Size(max = 50)
    @NotNull
    @Column(name = "LeaveResetDate", nullable = false, length = 50)
    private String leaveResetDate;

    @Size(max = 255)
    @NotNull
    @Column(name = "EligibleEmploymentStatus", nullable = false)
    private String eligibleEmploymentStatus;

    @Size(max = 1)
    @NotNull
    @Column(name = "ProcessPayroll", nullable = false, length = 1)
    private String processPayroll;

    @Size(max = 1)
    @Column(name = "RecordStatus", length = 1)
    private String recordStatus;

    @Size(max = 100)
    @Column(name = "LedgerDebitFrequency", length = 100)
    private String ledgerDebitFrequency;

    @Column(name = "LastPayrollDate")
    private Instant lastPayrollDate;

    @Column(name = "LeaveCreditDaysForSeniors")
    private Double leaveCreditDaysForSeniors;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getLocationId() {
		return locationId;
	}

	public void setLocationId(Integer locationId) {
		this.locationId = locationId;
	}

	public Instant getActiveFrom() {
		return activeFrom;
	}

	public void setActiveFrom(Instant activeFrom) {
		this.activeFrom = activeFrom;
	}

	public Instant getActiveTo() {
		return activeTo;
	}

	public void setActiveTo(Instant activeTo) {
		this.activeTo = activeTo;
	}

	public Double getLeaveCreditDays() {
		return leaveCreditDays;
	}

	public void setLeaveCreditDays(Double leaveCreditDays) {
		this.leaveCreditDays = leaveCreditDays;
	}

	public String getLeaveCreditBasedOn() {
		return leaveCreditBasedOn;
	}

	public void setLeaveCreditBasedOn(String leaveCreditBasedOn) {
		this.leaveCreditBasedOn = leaveCreditBasedOn;
	}

	public String getExcludeHolidaysFromLeave() {
		return excludeHolidaysFromLeave;
	}

	public void setExcludeHolidaysFromLeave(String excludeHolidaysFromLeave) {
		this.excludeHolidaysFromLeave = excludeHolidaysFromLeave;
	}

	public String getLeaveResetDate() {
		return leaveResetDate;
	}

	public void setLeaveResetDate(String leaveResetDate) {
		this.leaveResetDate = leaveResetDate;
	}

	public String getEligibleEmploymentStatus() {
		return eligibleEmploymentStatus;
	}

	public void setEligibleEmploymentStatus(String eligibleEmploymentStatus) {
		this.eligibleEmploymentStatus = eligibleEmploymentStatus;
	}

	public String getProcessPayroll() {
		return processPayroll;
	}

	public void setProcessPayroll(String processPayroll) {
		this.processPayroll = processPayroll;
	}

	public String getRecordStatus() {
		return recordStatus;
	}

	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}

	public String getLedgerDebitFrequency() {
		return ledgerDebitFrequency;
	}

	public void setLedgerDebitFrequency(String ledgerDebitFrequency) {
		this.ledgerDebitFrequency = ledgerDebitFrequency;
	}

	public Instant getLastPayrollDate() {
		return lastPayrollDate;
	}

	public void setLastPayrollDate(Instant lastPayrollDate) {
		this.lastPayrollDate = lastPayrollDate;
	}

	public Double getLeaveCreditDaysForSeniors() {
		return leaveCreditDaysForSeniors;
	}

	public void setLeaveCreditDaysForSeniors(Double leaveCreditDaysForSeniors) {
		this.leaveCreditDaysForSeniors = leaveCreditDaysForSeniors;
	}

	@Override
	public String toString() {
		return "CompanyLeavePolicy [id=" + id + ", locationId=" + locationId + ", activeFrom=" + activeFrom
				+ ", activeTo=" + activeTo + ", leaveCreditDays=" + leaveCreditDays + ", leaveCreditBasedOn="
				+ leaveCreditBasedOn + ", excludeHolidaysFromLeave=" + excludeHolidaysFromLeave + ", leaveResetDate="
				+ leaveResetDate + ", eligibleEmploymentStatus=" + eligibleEmploymentStatus + ", processPayroll="
				+ processPayroll + ", recordStatus=" + recordStatus + ", ledgerDebitFrequency=" + ledgerDebitFrequency
				+ ", lastPayrollDate=" + lastPayrollDate + ", leaveCreditDaysForSeniors=" + leaveCreditDaysForSeniors
				+ "]";
	}
    
}