package com.histo.staffmanagementportal.intranet.repository;

import com.histo.staffmanagementportal.intranet.entity.EmployeeRequestDetails;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeeRequestDetailsRepository extends JpaRepository<EmployeeRequestDetails, Integer> {
    List<EmployeeRequestDetails> findByEmployeeIdAndRecordStatus(Integer employeeId, String recordStatus);


}