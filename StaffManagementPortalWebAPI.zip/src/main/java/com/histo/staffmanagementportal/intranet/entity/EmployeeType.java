package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class EmployeeType {

	@Id
    @Column(name = "EmployeeTypeID", nullable = false)
    private Integer employeeTypeId;

    @Column(name = "EmployeeType", length = 50)
    private String type;

    @Column(name = "EmployeeTypeValue", length = 10)
    private String employeeTypeValue;

	public EmployeeType() {
		super();
	}

	public EmployeeType(Integer employeeTypeId, String employeeType, String employeeTypeValue) {
		super();
		this.employeeTypeId = employeeTypeId;
		this.type = employeeType;
		this.employeeTypeValue = employeeTypeValue;
	}

	public Integer getEmployeeTypeId() {
		return employeeTypeId;
	}

	public void setEmployeeTypeId(Integer employeeTypeId) {
		this.employeeTypeId = employeeTypeId;
	}

	public String gettType() {
		return type;
	}

	public void settType(String employeeType) {
		this.type = employeeType;
	}

	public String getEmployeeTypeValue() {
		return employeeTypeValue;
	}

	public void setEmployeeTypeValue(String employeeTypeValue) {
		this.employeeTypeValue = employeeTypeValue;
	} 
   
}
