package com.histo.staffmanagementportal.intranet.entity;


import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.histo.staffmanagementportal.util.InstantConverter;

import java.time.Instant;

@Entity
@Table(name = "SpecialLeaveLedger")
public class SpecialLeaveLedger {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "LedgerId", nullable = false)
    private Integer id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "SLDebitMasterID", nullable = false)
    private SpecialLeavesDebitMaster SLDebitMasterID;

    @Column(name = "EmployeeID")
    private Integer employeeID;

    @Column(name = "Debit")
    private Double debit = 0.0;

    @Column(name = "Balance")
    private Double balance = 0.0;

    @Size(max = 100)
    @Column(name = "Remarks", length = 100)
    private String remarks;

    @Column(name = "EntryDate")
    @Convert(converter = InstantConverter.class)
    private Instant entryDate;

    @Column(name = "RunDate")
    @Convert(converter = InstantConverter.class)
    private Instant runDate;

    @Column(name = "Credit")
    private Double creditDays = 0.0;
    
    @Size(max = 500)
    @Column(name = "Comments", length = 500)
    private String comments;

	@Column(name = "lastModifiedOn")
	@Convert(converter = InstantConverter.class)
	private Instant lastModifiedOn;

	@Column(name = "lastModifiedBy")
	private Integer lastModifiedBy;

	@Column(name = "lastModifiedRowCount")
	private Integer lastModifiedRowCount;
    
	public SpecialLeaveLedger() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public SpecialLeavesDebitMaster getSLDebitMasterID() {
		return SLDebitMasterID;
	}

	public void setSLDebitMasterID(SpecialLeavesDebitMaster sLDebitMasterID) {
		this.SLDebitMasterID = sLDebitMasterID;
	}

	public Integer getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(Integer employeeID) {
		this.employeeID = employeeID;
	}

	public Double getDebit() {
		return debit;
	}

	public void setDebit(Double debit) {
		this.debit = debit;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Instant getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(Instant entryDate) {
		this.entryDate = entryDate;
	}

	public Double getCreditDays() {
		return creditDays;
	}

	public void setCreditDays(Double creditDays) {
		this.creditDays = creditDays;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Instant getRunDate() {
		return runDate;
	}

	public void setRunDate(Instant runDate) {
		this.runDate = runDate;
	}

	public Instant getLastModifiedOn() {
		return lastModifiedOn;
	}

	public void setLastModifiedOn(Instant lastModifiedOn) {
		this.lastModifiedOn = lastModifiedOn;
	}

	public Integer getLastModifiedRowCount() {
		return lastModifiedRowCount;
	}

	public void setLastModifiedRowCount(Integer lastModifiedRowCount) {
		this.lastModifiedRowCount = lastModifiedRowCount;
	}

	public Integer getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(Integer lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
}