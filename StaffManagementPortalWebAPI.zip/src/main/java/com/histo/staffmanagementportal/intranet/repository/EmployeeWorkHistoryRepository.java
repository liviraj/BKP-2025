package com.histo.staffmanagementportal.intranet.repository;

import java.time.Instant;

import org.springframework.data.jpa.repository.JpaRepository;
import com.histo.staffmanagementportal.intranet.entity.EmployeeWorkHistory;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface EmployeeWorkHistoryRepository extends JpaRepository<EmployeeWorkHistory, Integer> {
    @Transactional
    @Modifying
    @Query("update EmployeeWorkHistory e set e.recordStatus = :recordStatus,e.modifiedBy = :modifiedBy ,e.modifiedDate = :modifiedDate where e.id = :id and e.recordStatus = 'A'")
    int updateRecordStatusById(@Param("recordStatus") Character recordStatus, @Param("id") Integer id,@Param("modifiedBy") Integer modifiedBy,
    		@Param("modifiedDate") Instant modifiedDate);

}