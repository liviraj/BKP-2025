package com.histo.staffmanagementportal.intranet.entity;

import lombok.*;

import javax.persistence.*;
import java.sql.Timestamp;
import java.time.Instant;

@Entity
@Getter
@Setter
@NoArgsConstructor
@ToString
@Table(name = "HolidayMaster")
public class HolidayMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "HolidayId")
    private Integer holidayId;

    @Column(name = "HolidayName", length = 1000, nullable = false)
    private String holidayName;

    @Column(name = "LocationId", nullable = false)
    private Integer locationId;

    @Column(name = "RecordStatus", length = 5, nullable = false)
    private String recordStatus;

    @Column(name = "AddedBy")
    private Integer addedBy;

    @Column(name = "AddedOn", columnDefinition = "datetime DEFAULT GETDATE()")
    private Timestamp addedOn;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @Column(name = "ModifiedOn", columnDefinition = "datetime DEFAULT GETDATE()")
    private Timestamp modifiedOn;


}
