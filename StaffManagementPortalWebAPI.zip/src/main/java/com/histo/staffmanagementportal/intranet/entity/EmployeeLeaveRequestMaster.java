package com.histo.staffmanagementportal.intranet.entity;

import java.time.Instant;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.histo.staffmanagementportal.dto.EmployeeLeaveRequestDTO;
import com.histo.staffmanagementportal.util.InstantConverter;

@Entity
public class EmployeeLeaveRequestMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "LeaveRequestId", nullable = false)
    private Integer id;

    @NotNull
    @Column(name = "EmployeeId", nullable = false)
    private Integer employeeId;

    @NotNull
    @Column(name = "LeaveRequestDate", nullable = false)
    @Convert(converter = InstantConverter.class)
    private Instant leaveRequestDate;

    @NotNull
    @Column(name = "LeaveFrom", nullable = false)
    @Convert(converter = InstantConverter.class)
    private Instant leaveFrom;

    @NotNull
    @Column(name = "LeaveTo", nullable = false)
    @Convert(converter = InstantConverter.class)
    private Instant leaveTo;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "typeofLeave", nullable = false)
    private LeaveTypeMaster typeofLeave;

    @Column(name = "Remarks")
    private String remarks;

    @NotNull
    @Column(name = "LeaveEnteredBy", nullable = false)
    private Integer leaveEnteredBy;

    @Column(name = "LeaveEnteredOn")
    @Convert(converter = InstantConverter.class)
    private Instant leaveEnteredOn;

    @Size(max = 5)
    @NotNull
    @Column(name = "LeaveFromForH", nullable = false, length = 5)
    private String leaveFromForH;

    @Size(max = 5)
    @NotNull
    @Column(name = "LeaveToForH", nullable = false, length = 5)
    private String leaveToForH;

    @Size(max = 255)
    @Column(name = "Status")
    private String status;

    @Column(name = "LeaveModifiedBy")
    private Integer leaveModifiedBy;

    @Column(name = "IsCompensatory")
    private Character isCompensatory;
    
    @Column(name = "ModifiedOn")
    private Instant modifiedOn;

    
	public EmployeeLeaveRequestMaster() {
		super();
	}

	public Instant getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Instant modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public Instant getLeaveRequestDate() {
		return leaveRequestDate;
	}

	public void setLeaveRequestDate(Instant leaveRequestDate) {
		this.leaveRequestDate = leaveRequestDate;
	}

	public Instant getLeaveFrom() {
		return leaveFrom;
	}

	public void setLeaveFrom(Instant leaveFrom) {
		this.leaveFrom = leaveFrom;
	}

	public Instant getLeaveTo() {
		return leaveTo;
	}

	public void setLeaveTo(Instant leaveTo) {
		this.leaveTo = leaveTo;
	}

	public LeaveTypeMaster getTypeofLeave() {
		return typeofLeave;
	}

	public void setTypeofLeave(  LeaveTypeMaster typeofLeave) {
		this.typeofLeave = typeofLeave;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getLeaveEnteredBy() {
		return leaveEnteredBy;
	}

	public void setLeaveEnteredBy(Integer leaveEnteredBy) {
		this.leaveEnteredBy = leaveEnteredBy;
	}

	public Instant getLeaveEnteredOn() {
		return leaveEnteredOn;
	}

	public void setLeaveEnteredOn(Instant leaveEnteredOn) {
		this.leaveEnteredOn = leaveEnteredOn;
	}

	public String getLeaveFromForH() {
		return leaveFromForH;
	}



	public void setLeaveFromForH(String leaveFromForH) {
		this.leaveFromForH = leaveFromForH;
	}

	public String getLeaveToForH() {
		return leaveToForH;
	}

	public void setLeaveToForH(String leaveToForH) {
		this.leaveToForH = leaveToForH;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getLeaveModifiedBy() {
		return leaveModifiedBy;
	}

	public void setLeaveModifiedBy(Integer leaveModifiedBy) {
		this.leaveModifiedBy = leaveModifiedBy;
	}

	public Character getIsCompensatory() {
		return isCompensatory;
	}

	public void setIsCompensatory(Character isCompensatory) {
		this.isCompensatory = isCompensatory;
	}

	public boolean equals(EmployeeLeaveRequestDTO leaveRequestDto) {

		return Objects.equals(leaveRequestDto.getLeaveFrom(), leaveRequestDto.getLeaveTo()) 
				&& Objects.equals(leaveRequestDto.getLeaveFromForH(), leaveRequestDto.getLeaveToForH())
				&& Objects.equals(leaveRequestDto.getLeaveFromForH(),"H");
	}

	@Override
	public String toString() {
		return "EmployeeLeaveRequestMaster {id=" + id + ", employeeId=" + employeeId + ", leaveRequestDate="
				+ leaveRequestDate + ", leaveFrom=" + leaveFrom + ", leaveTo=" + leaveTo + ", typeofLeave="
				+ typeofLeave + ", remarks=" + remarks + ", leaveEnteredBy=" + leaveEnteredBy + ", leaveEnteredOn="
				+ leaveEnteredOn + ", leaveFromForH=" + leaveFromForH + ", leaveToForH=" + leaveToForH + ", status="
				+ status + ", leaveModifiedBy=" + leaveModifiedBy + ", isCompensatory=" + isCompensatory + "}";
	}

}