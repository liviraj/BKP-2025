package com.histo.staffmanagementportal.intranet.repository;

import com.histo.staffmanagementportal.intranet.entity.Login;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface LoginRepository extends JpaRepository<Login, Integer> {

    @Query(value="select distinct locationId from login where EmployeeID=?1 and recordStatus = 'A'",
            nativeQuery = true)
    public Integer findLocationIdByEmployeeId(Integer employeeId);

    @Transactional
    @Modifying
    @Query("update Login l set l.recordStatus = :recordStatus, l.modifiedBy = :modifiedBy ,l.modifiedDate = :modifiedDate where l.loginId = :loginId and l.recordStatus = 'A'")
    int updateRecordStatusByLoginId(@Param("recordStatus") Character recordStatus, @Param("loginId") Integer loginId,
                                    @Param("modifiedBy") Integer modifiedBy, @Param("modifiedDate") Instant modifiedDate);

    @Query(value = "select r.RoleName from Login l, Role r where l.employeeId = ?1 and l.recordStatus = 'A' and l.roleId = r.roleId",nativeQuery = true)
    Optional<String> findRoleNameByEmployeeId(Integer employeeId);
    
}