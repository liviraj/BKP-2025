package com.histo.staffmanagementportal.intranet.repository;

import com.histo.staffmanagementportal.intranet.entity.RequestTypeMaster;
import com.histo.staffmanagementportal.model.RequestTypeDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface RequestTypeMasterRepository extends JpaRepository<RequestTypeMaster, Integer> {

    @Query(value = "select r.requestTypeId, r.request,r.locationId from RequestTypeMaster r where  r.recordStatus = ?1 order by r.request",
    nativeQuery = true)
    List<RequestTypeDetails> findAll(String recordStatus);

    Optional<RequestTypeMaster> findByRequestTypeIdAndRecordStatus(Integer requestTypeId, String recordStatus);


}