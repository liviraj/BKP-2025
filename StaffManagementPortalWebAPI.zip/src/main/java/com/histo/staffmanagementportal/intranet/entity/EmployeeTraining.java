package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.*;

import com.histo.staffmanagementportal.util.InstantConverter;

import java.time.Instant;

@Entity(name = "EmployeeTraining")
public class EmployeeTraining {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EmployeeTrainingID", nullable = false)
    private Integer id;

    @Column(name = "EmployeeID", nullable = false)
    private Integer employeeID;

    @Column(name = "EmployeeTrainingCategoryID", nullable = false)
    private Integer employeeTrainingCategoryID;

    @Column(name = "TrainingFrom", nullable = false)
    private Instant trainingFrom;

    @Column(name = "TrainingTo", nullable = false)
    private Instant trainingTo;

    @Column(name = "Purpose", nullable = false)
    private String purpose;

    @Column(name = "TrainingDocumentName", length = 500)
    private String trainingDocumentName;

    @Column(name = "TrainingDocBinary")
    private byte[] trainingDocBinary;

    @Column(name = "ModifiedBy", nullable = false)
    private Integer modifiedBy;

    @Column(name = "ModifiedDate", nullable = false)
    @Convert(converter = InstantConverter.class)
    private Instant modifiedDate;
    
    @Column(name = "CreatedBy", nullable = false)
    private Integer createdBy;

    @Column(name = "CreatedOn", nullable = false)
    private Instant createdOn;


    @Column(name = "RecordStatus", nullable = false)
    private Character recordStatus;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getEmployeeID() {
        return employeeID;
    }

    public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Instant getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Instant createdOn) {
		this.createdOn = createdOn;
	}

	public void setEmployeeID(Integer employeeID) {
        this.employeeID = employeeID;
    }

    public Integer getEmployeeTrainingCategoryID() {
        return employeeTrainingCategoryID;
    }

    public void setEmployeeTrainingCategoryID(Integer employeeTrainingCategoryID) {
        this.employeeTrainingCategoryID = employeeTrainingCategoryID;
    }

    public Instant getTrainingFrom() {
        return trainingFrom;
    }

    public void setTrainingFrom(Instant trainingFrom) {
        this.trainingFrom = trainingFrom;
    }

    public Instant getTrainingTo() {
        return trainingTo;
    }

    public void setTrainingTo(Instant trainingTo) {
        this.trainingTo = trainingTo;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public String getTrainingDocumentName() {
        return trainingDocumentName;
    }

    public void setTrainingDocumentName(String trainingDocumentName) {
        this.trainingDocumentName = trainingDocumentName;
    }

    public byte[] getTrainingDocBinary() {
        return trainingDocBinary;
    }

    public void setTrainingDocBinary(byte[] trainingDocBinary) {
        this.trainingDocBinary = trainingDocBinary;
    }

    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Character getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(Character recordStatus) {
        this.recordStatus = recordStatus;
    }

}