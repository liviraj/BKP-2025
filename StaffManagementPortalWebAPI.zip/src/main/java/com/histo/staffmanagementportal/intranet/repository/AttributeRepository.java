package com.histo.staffmanagementportal.intranet.repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.histo.staffmanagementportal.intranet.entity.Attribute;

public interface AttributeRepository extends JpaRepository<Attribute,Integer>{


	public  List<Attribute> findByCategoryAndAttributeNameIn(String category,Collection<String> attributeName);

	Optional<Attribute> findByAttributeNameAndCategory(String attributeName, String category);



}
