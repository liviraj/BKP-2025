package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.*;

import java.time.Instant;

@Entity
public class EmployeeWorkSchedule {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "WorkScheduleID", nullable = false)
    private Integer id;

    @Column(name = "EmployeeID", nullable = false)
    private Integer employeeID;

    @Column(name = "FromDate", nullable = false)
    private Instant fromDate;

    @Column(name = "ToDate")
    private Instant toDate;

    @Column(name = "WorkDays", nullable = false, length = 50)
    private String workDays;

    @Column(name = "Activity")
    private Integer activity;

    @Column(name = "ModifiedBy", nullable = false)
    private Integer modifiedBy;

    @Column(name = "ModifiedDate", nullable = false)
    private Instant modifiedDate;

    @Column(name = "RecordStatus", nullable = false)
    private Character recordStatus;

    @Column(name = "totalhrsperday")
    private Double totalhrsperday;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(Integer employeeID) {
        this.employeeID = employeeID;
    }

    public Instant getFromDate() {
        return fromDate;
    }

    public void setFromDate(Instant fromDate) {
        this.fromDate = fromDate;
    }

    public Instant getToDate() {
        return toDate;
    }

    public void setToDate(Instant toDate) {
        this.toDate = toDate;
    }

    public String getWorkDays() {
        return workDays;
    }

    public void setWorkDays(String workDays) {
        this.workDays = workDays;
    }

    public Integer getActivity() {
        return activity;
    }

    public void setActivity(Integer activity) {
        this.activity = activity;
    }

    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Character getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(Character recordStatus) {
        this.recordStatus = recordStatus;
    }

    public Double getTotalhrsperday() {
        return totalhrsperday;
    }

    public void setTotalhrsperday(Double totalhrsperday) {
        this.totalhrsperday = totalhrsperday;
    }

}