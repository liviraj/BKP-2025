package com.histo.staffmanagementportal.intranet.entity;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.histo.staffmanagementportal.util.InstantConverter;

@Entity
public class PayRollMaster {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PayrollId", nullable = false)
	private Integer id;
	
	@Column(name = "locationId", nullable = false)
	private Integer locationId;
	

	@Column(name = "fromDate", nullable = false)
	@Convert(converter = InstantConverter.class)
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "UTC")
	private Instant fromDate;
	
	@Column(name = "toDate", nullable = false)
	@Convert(converter = InstantConverter.class)
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "UTC")
	private Instant toDate;
	
	@Column(name = "noofWorkingDays", nullable = false)
	private Double noofWorkingDays;
	
	@Column(name = "noofHolidays", nullable = false)
	private Double noofHolidays;
	
	@Column(name = "payrollDate")
	@Convert(converter = InstantConverter.class)
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "UTC")
	private Instant payrollDate;
	
	@Column(name = "isProcessed", nullable = false)
	private String isProcessed;

	public PayRollMaster(Integer id, Integer locationId, Instant fromDate, Instant toDate, Double noofWorkingDays,
			Double noofHolidays, Instant payrollDate, String isProcessed) {
		super();
		this.id = id;
		this.locationId = locationId;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.noofWorkingDays = noofWorkingDays;
		this.noofHolidays = noofHolidays;
		this.payrollDate = payrollDate;
		this.isProcessed = isProcessed;
	}

	public PayRollMaster() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getLocationId() {
		return locationId;
	}

	public void setLocationId(Integer locationId) {
		this.locationId = locationId;
	}

	public Instant getFromDate() {
		return fromDate;
	}

	public void setFromDate(Instant fromDate) {
		this.fromDate = fromDate;
	}

	public Instant getToDate() {
		return toDate;
	}

	public void setToDate(Instant toDate) {
		this.toDate = toDate;
	}

	public Double getNoofWorkingDays() {
		return noofWorkingDays;
	}

	public void setNoofWorkingDays(Double noofWorkingDays) {
		this.noofWorkingDays = noofWorkingDays;
	}

	public Double getNoofHolidays() {
		return noofHolidays;
	}

	public void setNoofHolidays(Double noofHolidays) {
		this.noofHolidays = noofHolidays;
	}

	public Instant getPayrollDate() {
		return payrollDate;
	}

	public void setPayrollDate(Instant payrollDate) {
		this.payrollDate = payrollDate;
	}

	public String getIsProcessed() {
		return isProcessed;
	}

	public void setIsProcessed(String isProcessed) {
		this.isProcessed = isProcessed;
	}
	

}
