package com.histo.staffmanagementportal.intranet.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.histo.staffmanagementportal.intranet.entity.Holiday;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface HolidayRepository extends JpaRepository<Holiday, Integer> {
    @Query("""
            select h from Holiday h
            where h.locationid = ?1 and (h.startDate between ?2 and ?3 or h.endDate between ?2 and ?3)
            AND h.recordStatus = 'A'""")
    List<Holiday> findByLocationidAndStartDateBetweenAndEndDateBetween(Integer locationid, Instant startDate, Instant endDate);

    @Query(value = """
            SELECT h.* FROM holiday h WHERE CAST(:date AS Date) BETWEEN CAST(h.startdate AS date) AND CAST(h.enddate AS date)
            AND h.locationId = :locationId
            AND h.recordStatus = 'A'
            AND IsOptional = :isOptional """,nativeQuery = true )
    Optional<Holiday> findHolidayByLocationidAndStartDate(@Param("date") String date,@Param("locationId") Integer locationId,@Param("isOptional") String isOptional);

    @Query(value = """
            SELECT h.* FROM holiday h WHERE CAST(:date AS Date) BETWEEN CAST(h.startdate AS date) AND CAST(h.enddate AS date)
            AND h.locationId = :locationId
            AND h.recordStatus = 'A'
            """,nativeQuery = true )
    Optional<Holiday> findHolidayByLocationidAndDate(@Param("date") String date,@Param("locationId") Integer locationId);


    @Transactional
    @Modifying
    @Query("update Holiday h set h.recordStatus = ?2 , h.modifiedDate = ?3 , h.modifiedBy = ?4 where h.holidayDetailId = ?1 and h.recordStatus = 'A'")
    int updateRecordStatusByHolidayDetailIdAndRecordStatus(Integer holidayDetailId, String recordStatus, Instant modifiedDate, Integer modifiedBy);

    Optional<Holiday> findByHolidayDetailIdAndRecordStatusAndIsOptional(Integer holidayDetailId, String recordStatus, String isOptional);

    @Query(value = "select ISNULL(year(startdate),0) as year from Holiday h where h.holidayDetailId = ?1",nativeQuery = true)
    Integer findYearByHolidayDetailId(Integer holidayDetailId);

    interface FloatingHolidayList {
        Integer getHolidayId();
        String getHolidayName();
    }
    @Query(value = """
    select hm.HolidayName,h.holidayDetailId as holidayId from Holiday h, HolidayMaster hm where h.holidayId =hm.holidayId 
    AND YEAR(h.startDate) = ?1 AND h.Locationid = 1 AND IsOptional = 'true' AND h.RecordStatus = 'A' AND hm.RecordStatus = 'A'
    """, nativeQuery = true)
    List<FloatingHolidayList> findFloatingHolidayList( Integer year);

    @Query("""
            select count(h) from Holiday h
            where YEAR(h.startDate) = YEAR(?1) and h.isOptional = 'True' and h.locationid = ?2 and h.recordStatus = 'A' 
            and h.holidayId.locationId = ?2 and h.holidayId.recordStatus = 'A'""")
    long GetTotalCountOfFloatingHoliday(String year, Integer locationid);

    @Query("""
            select h from Holiday h
            where (h.holidayId.holidayId = ?1 OR h.alternateHolidayID = ?1) and h.recordStatus = ?2 """)
    List<Holiday> findByHolidayId_HolidayIdAndRecordStatusAndAlternateHolidayID(Integer holidayId, String recordStatus);

    @Query(value = """
            SELECT h.* FROM Holiday h, HolidayMaster hm
            WHERE h.HolidayId = hm.HolidayId
            AND h.HolidayId = ?1 AND  ?1 <> 0
            AND YEAR(startDate) = YEAR(?2)
            AND h.RecordStatus = 'A'
            AND hm.RecordStatus = 'A'
            AND h.locationid = ?3
            """, nativeQuery = true)
    List<Holiday> getFloatingHolidayIfExist(Integer holidayId,String startDate,Integer locationId);

    @Query(value = """
            SELECT h.* FROM Holiday h, HolidayMaster hm
            WHERE h.AlternateHolidayID = hm.HolidayId
            AND h.AlternateHolidayID = ?1
            AND YEAR(startDate) = YEAR(?2)
            AND h.RecordStatus = 'A'
            AND hm.RecordStatus = 'A'
            AND h.locationid = ?3
            """, nativeQuery = true)
    Optional<Holiday> getHolidayIsFloatingIfExist(Integer holidayId,String startDate,Integer locationId);

    long countByHolidayId_HolidayIdAndIsOptionalAndRecordStatus(Integer holidayId, String isOptional, String recordStatus);


}
