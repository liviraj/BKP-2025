package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.*;

import java.time.Instant;

@Entity
public class GradeMaster {
    @Id
    @Column(name = "GradeID", nullable = false)
    private Integer id;

    @Column(name = "GradeName", nullable = false, length = 50)
    private String gradeName;

    @Column(name = "ModifiedBy", nullable = false)
    private Integer modifiedBy;

    @Column(name = "ModifiedDate", nullable = false)
    private Instant modifiedDate;

    @Column(name = "RecordStatus", nullable = false)
    private Character recordStatus;

    @Column(name = "Description", length = 500)
    private String description;

    @Column(name = "locationid", nullable = false)
    private Integer locationid;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getGradeName() {
        return gradeName;
    }

    public void setGradeName(String gradeName) {
        this.gradeName = gradeName;
    }

    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Character getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(Character recordStatus) {
        this.recordStatus = recordStatus;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getLocationid() {
        return locationid;
    }

    public void setLocationid(Integer locationid) {
        this.locationid = locationid;
    }

}