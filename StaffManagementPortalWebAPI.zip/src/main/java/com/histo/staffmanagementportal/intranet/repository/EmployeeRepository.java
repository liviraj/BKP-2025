package com.histo.staffmanagementportal.intranet.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.histo.staffmanagementportal.intranet.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

    
}