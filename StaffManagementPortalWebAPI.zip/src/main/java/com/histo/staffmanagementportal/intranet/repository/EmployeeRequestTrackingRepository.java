package com.histo.staffmanagementportal.intranet.repository;

import com.histo.staffmanagementportal.intranet.entity.EmployeeRequestTracking;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRequestTrackingRepository extends JpaRepository<EmployeeRequestTracking, Integer> {
}