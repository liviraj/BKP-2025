package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.Instant;

@Entity
@Table(name = "SickLeaveCredits")
public class SickLeaveCredit {
    @Id
    @Column(name = "USSickleaveCreditID", nullable = false)
    private Long uSSickleaveCreditID;

    @Column(name = "EmployeeID")
    private Long employeeID;

    @Column(name = "CreditHrs")
    private Double creditHrs;

    @Column(name = "EntryDate")
    private Instant entryDate;

    @Column(name = "lastRunDate")
    private Instant lastRunDate;

	public Long getuSSickleaveCreditID() {
		return uSSickleaveCreditID;
	}

	public void setuSSickleaveCreditID(Long uSSickleaveCreditID) {
		this.uSSickleaveCreditID = uSSickleaveCreditID;
	}

	public Long getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(Long employeeID) {
		this.employeeID = employeeID;
	}

	public Double getCreditHrs() {
		return creditHrs;
	}

	public void setCreditHrs(Double creditHrs) {
		this.creditHrs = creditHrs;
	}

	public Instant getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(Instant entryDate) {
		this.entryDate = entryDate;
	}

	public Instant getLastRunDate() {
		return lastRunDate;
	}

	public void setLastRunDate(Instant lastRunDate) {
		this.lastRunDate = lastRunDate;
	}
    
    

}