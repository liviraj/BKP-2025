package com.histo.staffmanagementportal.intranet.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.histo.staffmanagementportal.intranet.entity.CompanyLeavePolicy;

public interface CompanyLeavePolicyRepository extends JpaRepository<CompanyLeavePolicy, Integer>{

}
