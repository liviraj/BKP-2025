package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.*;

import com.histo.staffmanagementportal.util.InstantConverter;

import java.time.Instant;

@Entity(name = "EmployeeDocument")
public class EmployeeDocument {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DocumentID", nullable = false)
    private Integer id;

    @Column(name = "EmployeeId", nullable = false)
    private Integer employeeId;

    @Column(name = "DocumentDate", nullable = false)
    private Instant documentDate;

    @Column(name = "Description", length = 1000)
    private String description;

    @Column(name = "DocumentName", nullable = false, length = 200)
    private String documentName;

    @Column(name = "DocumentImage")
    private byte[] documentImage;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @Column(name = "ModifiedDate")
    @Convert(converter = InstantConverter.class)
    private Instant modifiedDate;
    
    @Column(name = "CreatedBy", nullable = false)
    private Integer createdBy;

    @Column(name = "CreatedOn", nullable = false)
    private Instant createdOn;

    @Column(name = "RecordStatus")
    private Character recordStatus;

    @Column(name = "ExpiryDate")
    private Instant expiryDate;
    
    @Column(name = "DocumentTypeId")
    private Integer documentTypeId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getDocumentTypeId() {
		return documentTypeId;
	}

	public void setDocumentTypeId(Integer documentTypeId) {
		this.documentTypeId = documentTypeId;
	}

	public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public Instant getDocumentDate() {
        return documentDate;
    }

    public void setDocumentDate(Instant documentDate) {
        this.documentDate = documentDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public byte[] getDocumentImage() {
        return documentImage;
    }

    public void setDocumentImage(byte[] documentImage) {
        this.documentImage = documentImage;
    }

    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modidfiedDate) {
        this.modifiedDate = modidfiedDate;
    }

    public Character getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(Character recordStatus) {
        this.recordStatus = recordStatus;
    }

    public Instant getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Instant expiryDate) {
        this.expiryDate = expiryDate;
    }

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Instant getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Instant createdOn) {
		this.createdOn = createdOn;
	}

}