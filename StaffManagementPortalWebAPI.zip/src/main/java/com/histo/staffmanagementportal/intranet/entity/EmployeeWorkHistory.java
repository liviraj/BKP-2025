package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.*;

import com.histo.staffmanagementportal.util.InstantConverter;

import java.time.Instant;

@Entity(name = "EmployeeWorkHistory")
public class EmployeeWorkHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "WorkHistoryID", nullable = false)
    private Integer id;

    @Column(name = "Employeeid", nullable = false)
    private Integer employeeId;

    @Column(name = "EmployerName", nullable = false, length = 50)
    private String employerName;

    @Column(name = "Designation", nullable = false, length = 50)
    private String designation;

    @Column(name = "DateofJoin", nullable = false)
    private Instant dateofJoin;

    @Column(name = "RelievingDate", nullable = false)
    private Instant relievingDate;

    @Column(name = "ReportingTo", nullable = false, length = 50)
    private String reportingTo;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @Column(name = "ModifiedDate")
    @Convert(converter = InstantConverter.class)
    private Instant modifiedDate;
    
    @Column(name = "CreatedBy", nullable = false)
    private Integer createdBy;

    @Column(name = "CreatedOn", nullable = false)
    private Instant createdOn;

    @Column(name = "RecordStatus")
    private Character recordStatus;

    @Column(name = "EmployeeImage", nullable = false)
    private String employeeImage;

    @Column(name = "EmployeeImageBinary")
    private byte[] employeeImageBinary;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeid) {
        this.employeeId = employeeid;
    }

    public String getEmployerName() {
        return employerName;
    }

    public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Instant getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Instant createdOn) {
		this.createdOn = createdOn;
	}

	public void setEmployerName(String employerName) {
        this.employerName = employerName;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public Instant getDateofJoin() {
        return dateofJoin;
    }

    public void setDateofJoin(Instant dateofJoin) {
        this.dateofJoin = dateofJoin;
    }

    public Instant getRelievingDate() {
        return relievingDate;
    }

    public void setRelievingDate(Instant relievingDate) {
        this.relievingDate = relievingDate;
    }

    public String getReportingTo() {
        return reportingTo;
    }

    public void setReportingTo(String reportingTo) {
        this.reportingTo = reportingTo;
    }

    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Character getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(Character recordStatus) {
        this.recordStatus = recordStatus;
    }

    public String getEmployeeImage() {
        return employeeImage;
    }

    public void setEmployeeImage(String employeeImage) {
        this.employeeImage = employeeImage;
    }

    public byte[] getEmployeeImageBinary() {
        return employeeImageBinary;
    }

    public void setEmployeeImageBinary(byte[] employeeImageBinary) {
        this.employeeImageBinary = employeeImageBinary;
    }

}