package com.histo.staffmanagementportal.intranet.entity;

import com.histo.orgmaster.entity.Department;

import javax.persistence.*;

import java.time.Instant;

@Entity(name = "EmployeeWork")
public class EmployeeWork {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EmployeeWorkID", nullable = false)
    private Integer id;

    @Column(name = "EmployeeID", nullable = false)
    private Integer employeeID;

    @Column(name = "DOJ", nullable = false)
    private Instant doj;

    @Column(name = "DesignationID", nullable = false)
    private Integer designationID;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "GradeID", nullable = false)
    private GradeMaster gradeID;

    @Column(name = "WorkStationID", length = 50)
    private String workStationID;

    @Column(name = "SystemID", length = 50)
    private String systemID;

    @Column(name = "LaptopID", length = 50)
    private String laptopID;

    @Column(name = "ReportingTo")
    private Integer reportingTo;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "DepartmentID", nullable = false)
    private Department departmentID;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @Column(name = "ModifiedDate")
    private Instant modifiedDate;
    
    @Column(name = "createdBy", nullable = false)
    private Integer createdBy;

    @Column(name = "createdDate", nullable = false)
    private Instant createdDate;

    @Column(name = "RecordStatus", nullable = false)
    private Character recordStatus;

    @Column(name = "LocationID", nullable = false)
    private Integer locationID;

    @Column(name = "EmploymentType")
    private Integer employmentType;

    @Column(name = "VisaType", length = 25)
    private String visaType;

    @Column(name = "PlaceofIssue", length = 25)
    private String placeofIssue;

    @Column(name = "IssueDateWork")
    private Instant issueDateWork;

    @Column(name = "ExpiryDateWork")
    private Instant expiryDateWork;

    @Column(name = "CountryIssued", length = 25)
    private String countryIssued;

    @Column(name = "CurrentLocation")
    private Integer currentLocation;

    @Column(name = "ConfirmationDate", length = 25)
    private String confirmationDate;

    @Column(name = "RelievingDate", length = 25)
    private String relievingDate;

    @Column(name = "EmploymentStatus", length = 25)
    private String employmentStatus;

    @Column(name = "ClinicalHandler")
    private Boolean clinicalHandler;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(Integer employeeID) {
        this.employeeID = employeeID;
    }

    public Instant getDoj() {
        return doj;
    }

    public void setDoj(Instant doj) {
        this.doj = doj;
    }

    public Integer getDesignationID() {
        return designationID;
    }

    public void setDesignationID(Integer designationID) {
        this.designationID = designationID;
    }

    public GradeMaster getGradeID() {
        return gradeID;
    }

    public void setGradeID(GradeMaster gradeID) {
        this.gradeID = gradeID;
    }

    public String getWorkStationID() {
        return workStationID;
    }

    public void setWorkStationID(String workStationID) {
        this.workStationID = workStationID;
    }

    public String getSystemID() {
        return systemID;
    }

    public void setSystemID(String systemID) {
        this.systemID = systemID;
    }

    public String getLaptopID() {
        return laptopID;
    }

    public void setLaptopID(String laptopID) {
        this.laptopID = laptopID;
    }

    public Integer getReportingTo() {
        return reportingTo;
    }

    public void setReportingTo(Integer reportingTo) {
        this.reportingTo = reportingTo;
    }

    public Department getDepartmentID() {
        return departmentID;
    }

    public void setDepartmentID(Department departmentID) {
        this.departmentID = departmentID;
    }

    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Character getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(Character recordStatus) {
        this.recordStatus = recordStatus;
    }

    public Integer getLocationID() {
        return locationID;
    }

    public void setLocationID(Integer locationID) {
        this.locationID = locationID;
    }

    public Integer getEmploymentType() {
        return employmentType;
    }

    public void setEmploymentType(Integer employmentType) {
        this.employmentType = employmentType;
    }

    public String getVisaType() {
        return visaType;
    }

    public void setVisaType(String visaType) {
        this.visaType = visaType;
    }

    public String getPlaceofIssue() {
        return placeofIssue;
    }

    public void setPlaceofIssue(String placeofIssue) {
        this.placeofIssue = placeofIssue;
    }

    public Instant getIssueDateWork() {
        return issueDateWork;
    }

    public void setIssueDateWork(Instant issueDateWork) {
        this.issueDateWork = issueDateWork;
    }

    public Instant getExpiryDateWork() {
        return expiryDateWork;
    }

    public void setExpiryDateWork(Instant expiryDateWork) {
        this.expiryDateWork = expiryDateWork;
    }

    public String getCountryIssued() {
        return countryIssued;
    }

    public void setCountryIssued(String countryIssued) {
        this.countryIssued = countryIssued;
    }

    public Integer getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(Integer currentLocation) {
        this.currentLocation = currentLocation;
    }

    public String getConfirmationDate() {
        return confirmationDate;
    }

    public void setConfirmationDate(String confirmationDate) {
        this.confirmationDate = confirmationDate;
    }

    public String getRelievingDate() {
        return relievingDate;
    }

    public void setRelievingDate(String relievingDate) {
        this.relievingDate = relievingDate;
    }

    public String getEmploymentStatus() {
        return employmentStatus;
    }

    public void setEmploymentStatus(String employmentStatus) {
        this.employmentStatus = employmentStatus;
    }

    public Boolean getClinicalHandler() {
        return clinicalHandler;
    }

    public void setClinicalHandler(Boolean clinicalHandler) {
        this.clinicalHandler = clinicalHandler;
    }

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Instant getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Instant createdDate) {
		this.createdDate = createdDate;
	}

}