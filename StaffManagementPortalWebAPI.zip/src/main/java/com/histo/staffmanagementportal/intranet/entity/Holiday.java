package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.histo.staffmanagementportal.util.InstantConverter;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Getter
@Setter
@NoArgsConstructor
@ToString
public class Holiday {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "HolidayDetailId", nullable = false)
    private Integer holidayDetailId;

    @Size(max = 50)
    @NotNull
    @Column(name = "Name", nullable = false)
    private String name;

    @NotNull
    @Column(name = "StartDate", nullable = false)
    @Convert(converter = InstantConverter.class)
    private Instant startDate;

    @NotNull
    @Column(name = "EndDate", nullable = false)
    @Convert(converter = InstantConverter.class)
    private Instant endDate;

    @Column(name = "NumberOfDays")
    private Integer numberOfDays;

    @Column(name = "AlternateHolidayID", precision = 18)
    private Integer alternateHolidayID;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @Column(name = "ModifiedDate")
    @Convert(converter = InstantConverter.class)
    private Instant modifiedDate;

    @Column(name = "RecordStatus")
    private String recordStatus;

    @NotNull
    @Column(name = "Locationid", nullable = false)
    private Integer locationid;

    @Column(name = "IsOptional")
    private String isOptional;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "holidayId", nullable = false)
	private HolidayMaster holidayId;

    @Column(name = "AddedBy")
    private Integer addedBy;

    @Column(name = "AddedOn")
    @Convert(converter = InstantConverter.class)
    private Instant addedOn;


    
}