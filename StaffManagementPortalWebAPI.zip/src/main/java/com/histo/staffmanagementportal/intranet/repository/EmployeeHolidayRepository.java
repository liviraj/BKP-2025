package com.histo.staffmanagementportal.intranet.repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.histo.staffmanagementportal.intranet.entity.EmployeeHoliDay;

public interface EmployeeHolidayRepository extends JpaRepository<EmployeeHoliDay, Integer>{
    Optional<EmployeeHoliDay> findByEmployeeIdAndHoliDayId_HolidayDetailId(Integer employeeId, Integer holidayDetailId);

    List<EmployeeHoliDay> findByHoliDayId_HolidayDetailId(Integer holidayDetailId);


}
