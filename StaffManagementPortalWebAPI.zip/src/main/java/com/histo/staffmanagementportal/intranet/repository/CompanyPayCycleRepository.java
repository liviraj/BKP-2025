package com.histo.staffmanagementportal.intranet.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.histo.staffmanagementportal.intranet.entity.CompanyPayCycle;

public interface CompanyPayCycleRepository extends JpaRepository<CompanyPayCycle, Integer>{

}
