package com.histo.staffmanagementportal.intranet.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.histo.staffmanagementportal.intranet.entity.EmployeeType;

public interface EmployeeTypeRepository extends JpaRepository<EmployeeType, Integer>{

	@Query(value = """
			Select  employeeTypeId,employeeTypeValue, Case When EmployeeType = 'Employee' then 'Full Time Employee'  
			else  EmployeeType  end as 'employeeType' From  EmployeeType order by EmployeeType asc  
			""",nativeQuery = true)
	public List<EmployeeType> findAll();
	
	@Query(" select employeeTypeId from EmployeeType where employeeTypeValue=?1")
	public Integer findByEmployeeTypeValue(String employeeTypeValue);

}
