package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.*;

import java.time.Instant;

@Entity(name = "EmployeeCommunication")
public class EmployeeCommunication {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EmployeeCommunicationID", nullable = false)
    private Integer id;

    @Column(name = "EmployeeID", nullable = false)
    private Integer employeeID;

    @Column(name = "Address1", nullable = false, length = 50)
    private String address1;

    @Column(name = "Address2", length = 50)
    private String address2;

    @Column(name = "Address3", length = 50)
    private String address3;

    @Column(name = "City", nullable = false, length = 50)
    private String city;

    @Column(name = "Pin", nullable = false, length = 25)
    private String pin;

    @Column(name = "State", nullable = false, length = 50)
    private String state;

    @Column(name = "Country", nullable = false, length = 50)
    private String country;

    @Column(name = "PermAdd1", nullable = false, length = 50)
    private String permAdd1;

    @Column(name = "PermAdd2", length = 50)
    private String permAdd2;

    @Column(name = "PermAdd3", length = 50)
    private String permAdd3;

    @Column(name = "PermCity", nullable = false, length = 50)
    private String permCity;

    @Column(name = "PermPin", nullable = false, length = 50)
    private String permPin;

    @Column(name = "PermState", nullable = false, length = 50)
    private String permState;

    @Column(name = "PermCountry", nullable = false, length = 50)
    private String permCountry;

    @Column(name = "Phoneno", length = 50)
    private String phoneno;

    @Column(name = "AlternateContactNumber", length = 15)
    private String alternateContactNumber;

    @Column(name = "EmergencyContactName", nullable = false, length = 30)
    private String emergencyContactName;

    @Column(name = "EmergencyContactRelation", nullable = false, length = 15)
    private String emergencyContactRelation;

    @Column(name = "EmergencyContactNumber", nullable = false, length = 15)
    private String emergencyContactNumber;

    @Column(name = "EmergencyContactAddress1", nullable = false, length = 50)
    private String emergencyContactAddress1;

    @Column(name = "EmergencyContactAddress2", length = 50)
    private String emergencyContactAddress2;

    @Column(name = "EmergencyContactAddress3", length = 50)
    private String emergencyContactAddress3;

    @Column(name = "Cellno", length = 15)
    private String cellno;

    @Column(name = "WorkPhoneNo", nullable = false, length = 15)
    private String workPhoneNo;

    @Column(name = "Extension", length = 10)
    private String extension;

    @Column(name = "EmailID", nullable = false)
    private String emailID;

    @Column(name = "CreatedBy", nullable = false)
    private Integer createdBy;

    @Column(name = "CreatedDate", nullable = false)
    private Instant createdDate;
    
    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @Column(name = "ModifiedDate")
    private Instant modifiedDate;

    @Column(name = "RecordStatus", nullable = false)
    private Character recordStatus;

    
    public EmployeeCommunication() {
		super();
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Instant getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Instant createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(Integer employeeID) {
        this.employeeID = employeeID;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getAddress3() {
        return address3;
    }

    public void setAddress3(String address3) {
        this.address3 = address3;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPermAdd1() {
        return permAdd1;
    }

    public void setPermAdd1(String permAdd1) {
        this.permAdd1 = permAdd1;
    }

    public String getPermAdd2() {
        return permAdd2;
    }

    public void setPermAdd2(String permAdd2) {
        this.permAdd2 = permAdd2;
    }

    public String getPermAdd3() {
        return permAdd3;
    }

    public void setPermAdd3(String permAdd3) {
        this.permAdd3 = permAdd3;
    }

    public String getPermCity() {
        return permCity;
    }

    public void setPermCity(String permCity) {
        this.permCity = permCity;
    }

    public String getPermPin() {
        return permPin;
    }

    public void setPermPin(String permPin) {
        this.permPin = permPin;
    }

    public String getPermState() {
        return permState;
    }

    public void setPermState(String permState) {
        this.permState = permState;
    }

    public String getPermCountry() {
        return permCountry;
    }

    public void setPermCountry(String permCountry) {
        this.permCountry = permCountry;
    }

    public String getPhoneno() {
        return phoneno;
    }

    public void setPhoneno(String phoneno) {
        this.phoneno = phoneno;
    }

    public String getAlternateContactNumber() {
        return alternateContactNumber;
    }

    public void setAlternateContactNumber(String alternateContactNumber) {
        this.alternateContactNumber = alternateContactNumber;
    }

    public String getEmergencyContactName() {
        return emergencyContactName;
    }

    public void setEmergencyContactName(String emergencyContactName) {
        this.emergencyContactName = emergencyContactName;
    }

    public String getEmergencyContactRelation() {
        return emergencyContactRelation;
    }

    public void setEmergencyContactRelation(String emergencyContactRelation) {
        this.emergencyContactRelation = emergencyContactRelation;
    }

    public String getEmergencyContactNumber() {
        return emergencyContactNumber;
    }

    public void setEmergencyContactNumber(String emergencyContactNumber) {
        this.emergencyContactNumber = emergencyContactNumber;
    }

    public String getEmergencyContactAddress1() {
        return emergencyContactAddress1;
    }

    public void setEmergencyContactAddress1(String emergencyContactAddress1) {
        this.emergencyContactAddress1 = emergencyContactAddress1;
    }

    public String getEmergencyContactAddress2() {
        return emergencyContactAddress2;
    }

    public void setEmergencyContactAddress2(String emergencyContactAddress2) {
        this.emergencyContactAddress2 = emergencyContactAddress2;
    }

    public String getEmergencyContactAddress3() {
        return emergencyContactAddress3;
    }

    public void setEmergencyContactAddress3(String emergencyContactAddress3) {
        this.emergencyContactAddress3 = emergencyContactAddress3;
    }

    public String getCellno() {
        return cellno;
    }

    public void setCellno(String cellno) {
        this.cellno = cellno;
    }

    public String getWorkPhoneNo() {
        return workPhoneNo;
    }

    public void setWorkPhoneNo(String workPhoneNo) {
        this.workPhoneNo = workPhoneNo;
    }

    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }

    public String getEmailID() {
        return emailID;
    }

    public void setEmailID(String emailID) {
        this.emailID = emailID;
    }

    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Character getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(Character recordStatus) {
        this.recordStatus = recordStatus;
    }

}