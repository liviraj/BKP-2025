package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;

@Entity(name = "Employee")
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EmployeeID", nullable = false)
    private Integer id;

    @Column(name = "FirstName", nullable = false, length = 25)
    private String firstName;

    @Column(name = "MiddleName", length = 25)
    private String middleName;

    @Column(name = "LastName", nullable = false, length = 25)
    private String lastName;

    @Column(name = "Gender", nullable = false)
    private Character gender;

    @Column(name = "Pan_Ssn")
    private Character panSsn;

    @Column(name = "Dob", nullable = false)
    private Instant dob;

    @Column(name = "Fathername", nullable = false, length = 50)
    private String fatherName;

    @Column(name = "Mothername", nullable = false, length = 50)
    private String motherName;

    @Column(name = "Maritalstatus", nullable = false, length = 50)
    private String maritalStatus;

    @Column(name = "Spousename", length = 50)
    private String spouseName;

    @Column(name = "Childnos", precision = 18)
    private BigDecimal childNos;

    @Column(name = "Childname", length = 50)
    private String childName;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @Column(name = "ModifiedDate")
    private Instant modifiedDate;
    
    @Column(name = "CreatedBy", nullable = false)
    private Integer createdBy;

    @Column(name = "CreatedDate", nullable = false)
    private Instant createdDate;

    @Column(name = "RecordStatus", nullable = false)
    private Character recordStatus;

    @Lob
    @Column(name = "Image")
    private String image;

    @Column(name = "Nationality", nullable = false, length = 25)
    private String nationality;

    @Column(name = "IssuePlace", length = 25)
    private String issuePlace;

    @Column(name = "IssueDate")
    private Instant issueDate;

    @Column(name = "ExpiryDate")
    private Instant expiryDate;

    @Column(name = "IdProofImg", length = 500)
    private String idProofImg;

    @Column(name = "EmployeeCode", nullable = false, length = 50)
    private String employeeCode;

    @Column(name = "TimePunchId", length = 20)
    private String timePunchId;

    @Lob
    @Column(name = "PassportImage")
    private String passportImage;

    @Column(name = "PhotoImageBinary")
    private byte[] photoImageBinary;

    @Column(name = "IdProofImageBinary")
    private byte[] idProofImageBinary;

    @Column(name = "PassportImageBinary")
    private byte[] passportImageBinary;

    @Column(name = "Pan_Ssn_Number")
    private byte[] panSsnNumber;

    @Column(name = "PassportNo")
    private byte[] passportNo;

    @Column(name = "siblingsNo")
    private Integer siblingsNo;
    
	public Integer getCreatedBy() {
		return createdBy;
	}

	public Integer getSiblingsNo() {
		return siblingsNo;
	}

	public void setSiblingsNo(Integer siblingsNo) {
		this.siblingsNo = siblingsNo;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Instant getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Instant createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Character getGender() {
		return gender;
	}

	public void setGender(Character gender) {
		this.gender = gender;
	}

	public Character getPanSsn() {
		return panSsn;
	}

	public void setPanSsn(Character panSsn) {
		this.panSsn = panSsn;
	}

	public Instant getDob() {
		return dob;
	}

	public void setDob(Instant dob) {
		this.dob = dob;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getSpouseName() {
		return spouseName;
	}

	public void setSpouseName(String spouseName) {
		this.spouseName = spouseName;
	}

	public BigDecimal getChildNos() {
		return childNos;
	}

	public void setChildNos(BigDecimal childNos) {
		this.childNos = childNos;
	}

	public String getChildName() {
		return childName;
	}

	public void setChildName(String childName) {
		this.childName = childName;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Instant getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Instant modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Character getRecordStatus() {
		return recordStatus;
	}

	public void setRecordStatus(Character recordStatus) {
		this.recordStatus = recordStatus;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getIssuePlace() {
		return issuePlace;
	}

	public void setIssuePlace(String issuePlace) {
		this.issuePlace = issuePlace;
	}

	public Instant getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(Instant issueDate) {
		this.issueDate = issueDate;
	}

	public Instant getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Instant expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getIdProofImg() {
		return idProofImg;
	}

	public void setIdProofImg(String idProofImg) {
		this.idProofImg = idProofImg;
	}

	public String getEmployeeCode() {
		return employeeCode;
	}

	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}

	public String getTimePunchId() {
		return timePunchId;
	}

	public void setTimePunchId(String timePunchId) {
		this.timePunchId = timePunchId;
	}

	public String getPassportImage() {
		return passportImage;
	}

	public void setPassportImage(String passportImage) {
		this.passportImage = passportImage;
	}

	public byte[] getPhotoImageBinary() {
		return photoImageBinary;
	}

	public void setPhotoImageBinary(byte[] photoImageBinary) {
		this.photoImageBinary = photoImageBinary;
	}

	public byte[] getIdProofImageBinary() {
		return idProofImageBinary;
	}

	public void setIdProofImageBinary(byte[] idProofImageBinary) {
		this.idProofImageBinary = idProofImageBinary;
	}

	public byte[] getPassportImageBinary() {
		return passportImageBinary;
	}

	public void setPassportImageBinary(byte[] passportImageBinary) {
		this.passportImageBinary = passportImageBinary;
	}

	public byte[] getPanSsnNumber() {
		return panSsnNumber;
	}

	public void setPanSsnNumber(byte[] panSsnNumber) {
		this.panSsnNumber = panSsnNumber;
	}

	public byte[] getPassportNo() {
		return passportNo;
	}

	public void setPassportNo(byte[] passportNo) {
		this.passportNo = passportNo;
	}
}