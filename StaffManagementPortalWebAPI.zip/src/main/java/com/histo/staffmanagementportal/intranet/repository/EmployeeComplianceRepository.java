package com.histo.staffmanagementportal.intranet.repository;

import java.time.Instant;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import com.histo.staffmanagementportal.intranet.entity.EmployeeCompliance;
import com.histo.staffmanagementportal.model.CompliancePeriodProjector;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface EmployeeComplianceRepository extends JpaRepository<EmployeeCompliance, Integer> {

	public interface ComplianceCategory {
		Integer getComplianceCategoryId();

		String getComplianceCategory();
		String getIsPolicyAgreement();
		String getComplianceType();
	}

	@Query(value = """
			Select ComplainceCategoryID as complianceCategoryId,ComplainceCategory as complianceCategory,isPolicyAgreement,complianceType  from EmployeeComplainceCategory where RecordStatus = 'A' order by ComplainceCategory asc
			""" ,nativeQuery = true)
	public List<ComplianceCategory> getComplianceCategory();

	@Query(value = """
			Select  ComplaincePeriodID as compliancePeriodId,ComplaincePeriod as compliancePeriod  from ComplaincePeriodMaster  where RecordStatus = 'A'
			""" ,nativeQuery = true)
	public List<CompliancePeriodProjector> getCompliancePeriod();

	@Query(value = """
			select cp.ComplaincePeriodID as compliancePeriodId from ComplaincePeriodMaster cm,ComplaincePeriod cp where ComplainceCategoryID = ?1 and cm.ComplaincePeriodID = cp.ComplaincePeriodID
			AND cm.RecordStatus = 'A' AND cp.RecordStatus = 'A'
			""",nativeQuery = true)
	public List<Integer> getCompliancePeriodIdByCategoryId(Integer complianceCategoryId);

	@Transactional
	@Modifying
	@Query("update EmployeeCompliance e set e.recordStatus = :recordStatus , e.modifiedBy = :modifiedBy ,e.modifiedDate = :modifiedDate where e.id = :id and e.recordStatus = 'A'")
	int updateRecordStatusById(@Param("recordStatus") Character recordStatus, @Param("id") Integer id
			,@Param("modifiedBy") Integer modifiedBy, @Param("modifiedDate") Instant modifiedDate);



}