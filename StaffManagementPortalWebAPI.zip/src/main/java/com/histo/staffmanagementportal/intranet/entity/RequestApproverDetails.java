package com.histo.staffmanagementportal.intranet.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "RequestApproverDetails")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RequestApproverDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "autoId")
    private Integer autoId;

    @Column(name = "employeeId")
    private Integer employeeId;

    @Column(name = "locationId")
    private Integer locationId;
}