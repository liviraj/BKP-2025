package com.histo.staffmanagementportal.intranet.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.histo.staffmanagementportal.intranet.entity.CompanyLocation;

public interface CompanyLocationRepositoy extends JpaRepository<CompanyLocation, Integer> {
	
	public List<CompanyLocation> findDistinctByRecordStatusOrderByIdLocationIDAsc(Character recordStatus);

}
