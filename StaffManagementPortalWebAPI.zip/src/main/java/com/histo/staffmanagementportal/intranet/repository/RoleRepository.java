package com.histo.staffmanagementportal.intranet.repository;

import com.histo.staffmanagementportal.intranet.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface RoleRepository extends JpaRepository<Role, Integer> {
	
	 @Query(
	            value = """
	                    select r.RoleName from Employee e, login l, Role r where e.EmployeeID = l.EmployeeID and l.roleid = r.RoleID and 
	                   e.employeeId =?1
	                    """,
	            nativeQuery = true)
    public List<String> getRoleByEmployeeId(Integer employeeId);

    List<Role> findDistinctByRecordStatusOrderByIdAscRoleNameAsc(Character recordStatus);
    
    Optional<Role> findByRoleName(String roleName);
}