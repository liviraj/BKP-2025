package com.histo.staffmanagementportal.intranet.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.histo.staffmanagementportal.intranet.entity.SpecialLeaveLedger;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface SpecialLeaveLedgerRepository extends JpaRepository<SpecialLeaveLedger, Integer>{

	public List<SpecialLeaveLedger> findByEmployeeIDAndSLDebitMasterIDLeaveTypeIDAndSLDebitMasterIDLocationIDOrderByIdDesc(Integer employeeID, Integer leaveTypeID, Integer locationID);

	@Query("""
			select s from SpecialLeaveLedger s
			where s.SLDebitMasterID.leaveTypeID = ?2 and s.SLDebitMasterID.locationID = ?3 and s.employeeID = ?1
			and year(entryDate) >= year(getdate()) and s.id not in
			(select id from SpecialLeaveLedger where entryDate in 
			(select entryDate from SpecialLeaveLedger where employeeId = ?1 and remarks LIKE '%cancelled%')
			and creditDays=0)order by s.id DESC""")
	List<SpecialLeaveLedger> getLeaveBalance(Integer employeeID, Integer leaveTypeID, Integer locationID);

	SpecialLeaveLedger findFirstByEmployeeIDOrderByEntryDateDesc(Integer employeeID);

	Optional<SpecialLeaveLedger> findByEmployeeIDAndEntryDate(Integer employeeID, Instant leaveDate);

	SpecialLeaveLedger findFirstByEmployeeIDOrderByIdDesc(Integer employeeID);

	List<SpecialLeaveLedger> findByEmployeeIDAndSLDebitMasterIDLeaveTypeIDOrderByEntryDateDesc(Integer employeeID, Integer leaveTypeID);

	List<SpecialLeaveLedger> findByEmployeeIDAndSLDebitMasterIDIdAndIdGreaterThanOrderByIdAsc(Integer employeeID, Integer slMasterId, Integer slDebitId);

	Optional<SpecialLeaveLedger> findByEmployeeIDAndEntryDateAndSLDebitMasterID_LeaveTypeIDAndCreditDaysGreaterThanEqual(Integer employeeID, Instant leaveDate, Integer leaveTypeID, Double creditDays);

	SpecialLeaveLedger findFirstByEmployeeIDAndSLDebitMasterID_LeaveTypeIDOrderByIdDesc(Integer employeeID, Integer leaveTypeID);

	@Query("""
			select s from SpecialLeaveLedger s
			where s.remarks like concat('%', ?1, '%') and year(s.entryDate) = year(?2)""")
	List<SpecialLeaveLedger> findByRemarksContainsAndEntryDate(String remarks, String year);

	Collection<Object> findByIdAndRemarksEndsWith(Integer id, String comments);
}
