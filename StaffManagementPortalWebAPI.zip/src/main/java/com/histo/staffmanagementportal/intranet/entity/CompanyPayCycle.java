package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Size;

@Entity
public class CompanyPayCycle {
    @Id
    @Column(name = "PayCycleID", nullable = false)
    private Integer id;

    @Column(name = "LocationID")
    private Integer locationID;

    @Size(max = 500)
    @Column(name = "CreditPolicy", length = 500)
    private String creditPolicy;

    @Size(max = 10)
    @Column(name = "CycleStartDate", length = 10)
    private String cycleStartDate;

    @Size(max = 10)
    @Column(name = "CycleEndDate", length = 10)
    private String cycleEndDate;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getLocationID() {
		return locationID;
	}

	public void setLocationID(Integer locationID) {
		this.locationID = locationID;
	}

	public String getCreditPolicy() {
		return creditPolicy;
	}

	public void setCreditPolicy(String creditPolicy) {
		this.creditPolicy = creditPolicy;
	}

	public String getCycleStartDate() {
		return cycleStartDate;
	}

	public void setCycleStartDate(String cycleStartDate) {
		this.cycleStartDate = cycleStartDate;
	}

	public String getCycleEndDate() {
		return cycleEndDate;
	}

	public void setCycleEndDate(String cycleEndDate) {
		this.cycleEndDate = cycleEndDate;
	}

	@Override
	public String toString() {
		return "CompanyPayCycle [id=" + id + ", locationID=" + locationID + ", creditPolicy=" + creditPolicy
				+ ", cycleStartDate=" + cycleStartDate + ", cycleEndDate=" + cycleEndDate + "]";
	}

}