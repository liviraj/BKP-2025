package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


@Entity
public class LeaveTypeMaster {
    @Id
    @Column(name = "LeaveTypeId", nullable = false)
    private Integer leaveTypeId;

    @Size(max = 50)
    @NotNull
    @Column(name = "LeaveTypeName", nullable = false, length = 50)
    private String leaveTypeName;

    @Column(name = "LocationID")
    private Integer locationID;

	public LeaveTypeMaster() {
		super();
	}

	public LeaveTypeMaster(Integer leaveTypeId, @Size(max = 50) @NotNull String leaveTypeName, Integer locationID) {
		super();
		this.leaveTypeId = leaveTypeId;
		this.leaveTypeName = leaveTypeName;
		this.locationID = locationID;
	}

	public Integer getLeaveTypeId() {
		return leaveTypeId;
	}

	public void setLeaveTypeId(Integer leaveTypeId) {
		this.leaveTypeId = leaveTypeId;
	}

	public String getLeaveTypeName() {
		return leaveTypeName;
	}

	public void setLeaveTypeName(String leaveTypeName) {
		this.leaveTypeName = leaveTypeName;
	}

	public Integer getLocationID() {
		return locationID;
	}

	public void setLocationID(Integer locationID) {
		this.locationID = locationID;
	}
    

}