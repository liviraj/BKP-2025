package com.histo.staffmanagementportal.intranet.repository;

import com.histo.staffmanagementportal.intranet.entity.RequestStatusDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface RequestStatusDetailsRepository extends JpaRepository<RequestStatusDetails, Integer> {

    Optional<RequestStatusDetails> findByEmployeeRequestDetails_EmployeeIdAndEmployeeRequestDetails_RequestType_RequestTypeIdAndRequestStatus(Integer employeeId, Integer requestId, String requestStatus);

    Optional<RequestStatusDetails> findByEmployeeRequestDetails_RequestIdAndRequestStatus(Integer requestId, String requestStatus);

    List<RequestStatusDetails> findByEmployeeRequestDetails_RequestType_RequestTypeIdInAndRequestStatus(Collection<Integer> requestTypeIds, String requestStatus);

    Optional<RequestStatusDetails> findByEmployeeRequestDetails_RequestId(Integer requestId);



}