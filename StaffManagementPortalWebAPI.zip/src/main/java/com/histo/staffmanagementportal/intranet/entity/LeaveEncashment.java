package com.histo.staffmanagementportal.intranet.entity;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.histo.staffmanagementportal.util.InstantConverter;

@Entity
public class LeaveEncashment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "LeaveEncashmentID", nullable = false)
	private Integer leaveEncashmentId;
	
	@Column(name = "EmployeeID", nullable = false)
	private Integer employeeId;
	
	@Column(name = "LeaveEncashed")
	private Double leaveEncashed;
	
	@Column(name = "EncashmentDate")
	@Convert(converter = InstantConverter.class)
	private Instant encashmentDate;
	
	@Column(name = "IsLedgerReset")
	private Boolean isLedgerReset;
	
	@Column(name = "Remarks")
	private String remarks;
	
	@Column(name = "RunDate")
	@Convert(converter = InstantConverter.class)
	private Instant runDate;

	public LeaveEncashment() {
		super();
	}

	public Integer getLeaveEncashmentId() {
		return leaveEncashmentId;
	}

	public void setLeaveEncashmentId(Integer leaveEncashmentId) {
		this.leaveEncashmentId = leaveEncashmentId;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public Double getLeaveEncashed() {
		return leaveEncashed;
	}

	public void setLeaveEncashed(Double leaveEncashed) {
		this.leaveEncashed = leaveEncashed;
	}

	public Instant getEncashmentDate() {
		return encashmentDate;
	}

	public void setEncashmentDate(Instant encashmentDate) {
		this.encashmentDate = encashmentDate;
	}

	public Boolean getIsLedgerReset() {
		return isLedgerReset;
	}

	public void setIsLedgerReset(Boolean isLedgerReset) {
		this.isLedgerReset = isLedgerReset;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Instant getRunDate() {
		return runDate;
	}

	public void setRunDate(Instant runDate) {
		this.runDate = runDate;
	}

}
