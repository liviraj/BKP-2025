package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.*;

import com.histo.staffmanagementportal.util.InstantConverter;

import java.time.Instant;

@Entity
public class Login {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "LoginID", nullable = false, length = 10)
    private Integer loginId;

    @Column(name = "employeeId")
    private Integer employeeId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "roleid", nullable = false)
    private Role roleId;

    @Column(name = "firstname", nullable = false, length = 100)
    private String firstName;

    @Column(name = "middlename", length = 100)
    private String middleName;

    @Column(name = "lastname", nullable = false, length = 100)
    private String lastName;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @Column(name = "ModifiedDate")
    @Convert(converter = InstantConverter.class)
    private Instant modifiedDate;

    @Column(name = "RecordStatus", nullable = false)
    private Character recordStatus;

    @Column(name = "locationid")
    private Integer locationID;

    @Column(name = "EmployeeType")
    private String employeeType;

    @Column(name = "emailId", nullable = false)
    private String emailId;
    
    @Column(name = "createdBy", nullable = false)
    private Integer createdBy;
    
    @Column(name = "createdDate",nullable = false)
    private Instant createdDate;
    
    public Integer getCreatedBy() {
		return createdBy;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Instant getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Instant createdDate) {
		this.createdDate = createdDate;
	}

    public Integer getLoginId() {
		return loginId;
	}

	public void setLoginId(Integer loginId) {
		this.loginId = loginId;
	}

	public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public Role getRoleId() {
        return roleId;
    }

    public void setRoleId(Role roleId) {
        this.roleId = roleId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Character getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(Character recordStatus) {
        this.recordStatus = recordStatus;
    }

    public Integer getLocationID() {
        return locationID;
    }

    public void setLocationID(Integer locationID) {
        this.locationID = locationID;
    }

    public String getEmployeeType() {
        return employeeType;
    }

    public void setEmployeeType(String employeeType) {
        this.employeeType = employeeType;
    }

	@Override
	public String toString() {
		return "Login [loginId=" + loginId + ", employeeId=" + employeeId + ", roleId=" + roleId + ", firstName="
				+ firstName + ", middleName=" + middleName + ", lastName=" + lastName + ", modifiedBy=" + modifiedBy
				+ ", modifiedDate=" + modifiedDate + ", recordStatus=" + recordStatus + ", locationID=" + locationID
				+ ", employeeType=" + employeeType + ", emailId=" + emailId + ", createdBy=" + createdBy
				+ ", createdDate=" + createdDate + "]";
	}

}