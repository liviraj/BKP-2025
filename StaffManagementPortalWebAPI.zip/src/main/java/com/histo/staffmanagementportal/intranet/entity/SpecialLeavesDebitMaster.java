package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.*;
import javax.validation.constraints.Size;

@Entity
public class SpecialLeavesDebitMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SLDebitMasterID", nullable = false)
    private Integer id;

    @Column(name = "LocationID")
    private Integer locationID;

    @Column(name = "LeaveTypeID")
    private Integer leaveTypeID;

    @Column(name = "TotalCredits")
    private Integer totalCredits;

    @Size(max = 25)
    @Column(name = "CreditResetOn", length = 25)
    private String creditResetOn;

    @Size(max = 15)
    @Column(name = "MonthOfJoining", length = 15)
    private String monthOfJoining;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getLocationID() {
		return locationID;
	}

	public void setLocationID(Integer locationID) {
		this.locationID = locationID;
	}

	public Integer getLeaveTypeID() {
		return leaveTypeID;
	}

	public void setLeaveTypeID(Integer leaveTypeID) {
		this.leaveTypeID = leaveTypeID;
	}

	public Integer getTotalCredits() {
		return totalCredits;
	}

	public double getTotalCreditsinDouble() {
		return totalCredits;
	}

	public void setTotalCredits(Integer totalCredits) {
		this.totalCredits = totalCredits;
	}

	public String getCreditResetOn() {
		return creditResetOn;
	}

	public void setCreditResetOn(String creditResetOn) {
		this.creditResetOn = creditResetOn;
	}

	public String getMonthOfJoining() {
		return monthOfJoining;
	}

	public void setMonthOfJoining(String monthOfJoining) {
		this.monthOfJoining = monthOfJoining;
	}

}