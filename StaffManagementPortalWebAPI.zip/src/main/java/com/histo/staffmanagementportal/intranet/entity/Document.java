package com.histo.staffmanagementportal.intranet.entity;

import lombok.*;

import javax.persistence.*;
import java.time.Instant;

@Entity
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Document {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DocumentDetailId", nullable = false)
    private Integer id;

    @Column(name = "DocumentName", nullable = false)
    private String documentName;

    @Column(name = "DocumentId", nullable = false)
    private Integer documentId;

    @Column(name = "DocumentImage")
    private byte[] documentBinary;

    @Column(name = "DocumentType", nullable = false)
    private String documentType;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @Column(name = "CreatedBy", nullable = false)
    private Integer createdBy;

    @Column(name = "RecordStatus", nullable = false)
    private String recordStatus;
}
