package com.histo.staffmanagementportal.intranet.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.histo.staffmanagementportal.intranet.entity.SpecialLeavesDebitMaster;

import java.util.List;
import java.util.Optional;

public interface SpecialLeavesDebitMasterRepository extends JpaRepository<SpecialLeavesDebitMaster, Integer>{
	
    List<SpecialLeavesDebitMaster> findByLocationIDAndLeaveTypeID(Integer locationID, Integer leaveTypeID);
    
   @Query(value = """
   		select top 1 s.* from SpecialLeavesDebitMaster s,LeaveTypeMaster l where l.LocationID = ?1 and l.LeaveTypeId = s.LeaveTypeID and l.LeaveTypeName = ?2
   		""",nativeQuery = true)
   Optional<SpecialLeavesDebitMaster> getLeaveDetail(Integer locationId,String leavetype);
    

}
