package com.histo.staffmanagementportal.intranet.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.histo.staffmanagementportal.intranet.entity.GradeMaster;
import com.histo.staffmanagementportal.model.GradeName;

public interface GradeMasterRepository extends JpaRepository<GradeMaster,Integer>{

	@Query("select  new com.histo.staffmanagementportal.model.GradeName(id as gradeId,gradeName) from GradeMaster where recordStatus='A'")
	public List<GradeName> getGradeNameByRecordStatus();
}
