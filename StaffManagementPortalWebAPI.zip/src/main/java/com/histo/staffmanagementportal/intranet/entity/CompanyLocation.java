package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.Instant;

@Entity
public class CompanyLocation {
    @EmbeddedId
    private CompanyLocationId id;

    @Size(max = 50)
    @NotNull
    @Column(name = "LocationCity", nullable = false, length = 50)
    private String locationCity;

    @Size(max = 50)
    @NotNull
    @Column(name = "LocationCountry", nullable = false, length = 50)
    private String locationCountry;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @Column(name = "ModifiedDate")
    private Instant modifiedDate;

    @Column(name = "RecordStatus")
    private Character recordStatus;

    @Size(max = 7)
    @Column(name = "EmployeeIDPrefix", length = 7)
    private String employeeIdPrefix;

    public CompanyLocationId getId() {
        return id;
    }

    public void setId(CompanyLocationId id) {
        this.id = id;
    }

    public String getLocationCity() {
        return locationCity;
    }

    public void setLocationCity(String locationCity) {
        this.locationCity = locationCity;
    }

    public String getLocationCountry() {
        return locationCountry;
    }

    public void setLocationCountry(String locationCountry) {
        this.locationCountry = locationCountry;
    }

    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Character getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(Character recordStatus) {
        this.recordStatus = recordStatus;
    }

    public String getEmployeeIDPrefix() {
        return employeeIdPrefix;
    }

    public void setEmployeeIDPrefix(String employeeIDPrefix) {
        this.employeeIdPrefix = employeeIDPrefix;
    }

}