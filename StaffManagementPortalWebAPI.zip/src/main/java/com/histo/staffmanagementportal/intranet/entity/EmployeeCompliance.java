package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.*;

import com.histo.staffmanagementportal.util.InstantConverter;

import java.time.Instant;

@Entity(name = "EmployeeCompliance")
public class EmployeeCompliance {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EmployeeComplianceID", nullable = false)
    private Integer id;

    @Column(name = "EmployeeID", nullable = false)
    private Integer employeeID;

    @Column(name = "CreatedOn", nullable = false)
    private Instant createdOn;

    @Column(name = "CreatedBy", nullable = false)
    private Integer createdBy;

    @Column(name = "ModifiedDate")
    @Convert(converter = InstantConverter.class)
    private Instant modifiedDate;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;
    
    @Column(name = "ComplianceCategoryID", nullable = false)
    private Integer complianceCategoryID;

    @Column(name = "CompliancePeriod", nullable = false, length = 50)
    private String compliancePeriod;

    @Column(name = "ComplianceDate", nullable = false)
    private Instant complianceDate;

    @Column(name = "Description", nullable = false)
    private String description;

    @Column(name = "DocumentName", nullable = false, length = 500)
    private String documentName;

    @Column(name = "DocumentImage", nullable = false)
    private byte[] documentImage;

    @Column(name = "RecordStatus", nullable = false)
    private Character recordStatus;

    @Column(name = "ExpiryDate")
    private Instant expiryDate;

    public Integer getId() {
        return id;
    }

    public Instant getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Instant modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public void setId(Integer id) {
        this.id = id;
    }

    public Integer getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(Integer employeeID) {
        this.employeeID = employeeID;
    }

    public Instant getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Instant createdOn) {
        this.createdOn = createdOn;
    }

    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getComplianceCategoryID() {
        return complianceCategoryID;
    }

    public void setComplianceCategoryID(Integer complianceCategoryID) {
        this.complianceCategoryID = complianceCategoryID;
    }

    public String getCompliancePeriod() {
        return compliancePeriod;
    }

    public void setCompliancePeriod(String compliancePeriod) {
        this.compliancePeriod = compliancePeriod;
    }

    public Instant getComplianceDate() {
        return complianceDate;
    }

    public void setComplianceDate(Instant complianceDate) {
        this.complianceDate = complianceDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public byte[] getDocumentImage() {
        return documentImage;
    }

    public void setDocumentImage(byte[] documentImage) {
        this.documentImage = documentImage;
    }

    public Character getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(Character recordStatus) {
        this.recordStatus = recordStatus;
    }

    public Instant getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Instant expiryDate) {
        this.expiryDate = expiryDate;
    }

}