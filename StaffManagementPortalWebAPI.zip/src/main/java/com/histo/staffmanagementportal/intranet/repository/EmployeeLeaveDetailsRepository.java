package com.histo.staffmanagementportal.intranet.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.histo.staffmanagementportal.intranet.entity.EmployeeLeaveDetails;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface EmployeeLeaveDetailsRepository extends JpaRepository<EmployeeLeaveDetails, Integer> {

	List<EmployeeLeaveDetails> findByEmployeeId(Integer employeeId);

	List<EmployeeLeaveDetails> findByLeaveRequestId_IdAndAvailedOrderByLeaveDateDesc(Integer id, String availed);

	List<EmployeeLeaveDetails> findByLeaveRequestId_IdAndApprovalStatusNotIn(Integer id, Collection<String> approvalStatuses);

	List<EmployeeLeaveDetails> findByEmployeeIdAndLeaveDateBetween(Integer employeeId, Instant leaveDateStart,
																   Instant leaveDateEnd);

	List<EmployeeLeaveDetails> findByIdIn(Collection<Integer> ids);

	List<EmployeeLeaveDetails> findByEmployeeIdAndLeaveDateBetweenAndLeaveRequestIdTypeofLeaveLeaveTypeId(Integer employeeId, Instant leaveDateStart, Instant leaveDateEnd, Integer leaveTypeId);


	List<EmployeeLeaveDetails> findByIdInAndApprovalStatusIn(Collection<Integer> ids,
															 Collection<String> approvalStatuses);

	@Query(value = """
			select top 1 case when ApprovalStatus='A' then 'Approved'when ApprovalStatus='R' then 'Rejected' when ApprovalStatus='N' then 'Un Expected Request'
			else 'Partially Approved' end as 'ApprovalStatus' from EmployeeLeaveDetails where leaverequestId = ?1 and Availed = 'Y'
			""", nativeQuery = true)
	String getApprovalStatus(Integer leaveRequestId);

	List<EmployeeLeaveDetails> findByLeaveRequestId_Id(Integer id);

	Optional<EmployeeLeaveDetails> findByLeaveRequestId_TypeofLeave_LeaveTypeNameAndLeaveRequestId_TypeofLeave_LocationIDAndEmployeeIdAndLeaveDate(
			String leaveTypeName, Integer locationID, Integer employeeId, Instant leaveDate);

	Optional<EmployeeLeaveDetails> findByEmployeeIdAndLeaveDate(Integer employeeId, Instant leaveDate);

	Optional<EmployeeLeaveDetails> findByLeaveRequestId_TypeofLeave_LeaveTypeIdAndLeaveRequestId_TypeofLeave_LocationIDAndEmployeeIdAndLeaveDate(
			Integer leaveTypeId, Integer locationID, Integer employeeId, Instant leaveDate);

	List<EmployeeLeaveDetails> findByLeaveRequestId_IdAndApprovalStatus(Integer id, String approvalStatus);


}
