package com.histo.staffmanagementportal.intranet.entity;

import com.histo.staffmanagementportal.util.InstantConverter;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "EmployeeRequestTracking")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeRequestTracking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "autoId")
    private Integer autoId;

    @ManyToOne
    @JoinColumn(name = "RequestId", referencedColumnName = "RequestId", nullable = false)
    private EmployeeRequestDetails requestId;

    @Column(name = "employeeId")
    private Integer employeeId;

    @Column(name = "RequestStatus", nullable = false)
    private Integer requestStatus;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @Column(name = "modifiedDate")
    @Convert(converter = InstantConverter.class)
    private Instant modifiedDate;

    @Column(name = "AssignedTo")
    private Integer assignedTo;

    @Column(name = "description")
    private String description;
}