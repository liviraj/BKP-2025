package com.histo.staffmanagementportal.intranet.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.histo.staffmanagementportal.intranet.entity.EmployeeCommunication;

public interface EmployeeCommunicationRepository extends JpaRepository<EmployeeCommunication, Integer> {
	
	@Query("select id from EmployeeCommunication where employeeId=:employeeId and recordStatus='A'")
	public Integer getEmployeeCommunicationId(@Param("employeeId") Integer employeeId);
  
}