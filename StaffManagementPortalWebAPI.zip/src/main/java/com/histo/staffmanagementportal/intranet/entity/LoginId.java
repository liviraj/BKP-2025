package com.histo.staffmanagementportal.intranet.entity;

import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class LoginId implements Serializable {
    private static final long serialVersionUID = 1292043057693478668L;
    @Size(max = 10)
    @NotNull
    @Column(name = "LoginID", nullable = false, length = 10)
    private String loginId;

    @NotNull
    @Column(name = "roleid", nullable = false)
    private Integer roleid;

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginID) {
        this.loginId = loginID;
    }

    public Integer getRoleid() {
        return roleid;
    }

    public void setRoleid(Integer roleid) {
        this.roleid = roleid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        LoginId entity = (LoginId) o;
        return Objects.equals(this.loginId, entity.loginId) &&
                Objects.equals(this.roleid, entity.roleid);
    }

    @Override
    public int hashCode() {
        return Objects.hash(loginId, roleid);
    }

}