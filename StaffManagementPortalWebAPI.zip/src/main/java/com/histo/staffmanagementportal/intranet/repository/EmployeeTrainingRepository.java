package com.histo.staffmanagementportal.intranet.repository;

import java.time.Instant;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.histo.staffmanagementportal.intranet.entity.EmployeeTraining;
import com.histo.staffmanagementportal.model.TrainingCategoryProjector;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface EmployeeTrainingRepository extends JpaRepository<EmployeeTraining, Integer> {

	@Query(value = "select TrainingCategoryID,TrainingCategory from TrainingCategory where RecordStatus='A'  ",
			nativeQuery = true)
	public List<TrainingCategoryProjector> getTrainingCategory();

	@Transactional
	@Modifying
	@Query("update EmployeeTraining e set e.recordStatus = :recordStatus,e.modifiedBy = :modifiedBy ,e.modifiedDate = :modifiedDate where e.id = :id and e.recordStatus = 'A'")
	int updateRecordStatusById(@Param("recordStatus") Character recordStatus, @Param("id") Integer id,@Param("modifiedBy") Integer modifiedBy,
			@Param("modifiedDate") Instant modifiedDate);



}