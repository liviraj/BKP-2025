package com.histo.staffmanagementportal.intranet.entity;

import com.histo.staffmanagementportal.util.InstantConverter;
import lombok.Data;

import javax.persistence.*;
import java.time.Instant;

@Data
@Entity
@Table(name = "RequestStatusDetails")
public class RequestStatusDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "RequestDetailId")
    private Integer requestDetailId;

    @Column(name = "RequestStatus")
    private String requestStatus;

    @Column(name = "Comments")
    private String comments;

    @Column(name = "ReviewedBy")
    private Integer reviewedBy;

    @Column(name = "ReviewedOn")
    @Convert(converter = InstantConverter.class)
    private Instant reviewedOn;

    @ManyToOne
    @JoinColumn(name = "RequestId", referencedColumnName = "RequestId")
    private EmployeeRequestDetails employeeRequestDetails;

}

