package com.histo.staffmanagementportal.intranet.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.histo.staffmanagementportal.intranet.entity.EmployeeWork;

public interface EmployeeWorkRepository extends JpaRepository<EmployeeWork, Integer> {
	
    public static interface EmployeeWorkDetails{
        String getdesignationName();      
        String getdepartmentName();       
        String getemployeeType();     
        String getemploymentStatus();   
        String getlocationCountry();         
        String getDoj();             
        String getrelievingDate();   
        String getconfirmationDate();
    }
	String query = """
			select dbo.formatdate(dbo.fn_DecryptText(EW.DOJ)) as DOJ,DM.DesignationName,D.DepartmentName,Cl.LocationCountry,dbo.fn_DecryptText(EW.relievingdate) as relievingdate,
			dbo.fn_DecryptText(EW.confirmationdate) as confirmationdate,dbo.fn_DecryptText(EW.EmploymentStatus) as EmploymentStatus,ET.EmployeeType from Employee E,EmployeeWork EW,
			DesignationMaster DM,Department D,CompanyLocation CL,EmployeeType ET where EW.employeeId=:employeeId and dbo.fn_DecryptText(EW.DesignationID) = DM.DesignationID and 
			dbo.fn_DecryptText(EW.DepartmentID )= D.DepartmentID and dbo.fn_DecryptText(EW.LocationID) = CL.LocationID and EW.EmploymentType = ET.EmployeeTypeID
			group by EW.DOJ,DM.DesignationName,D.DepartmentName,Cl.LocationCountry,EW.relievingdate,EW.confirmationdate,EW.EmploymentStatus,ET.EmployeeType
			""";
	@Query(value=query,nativeQuery=true)
	EmployeeWorkDetails findEmployeeWorkDetails(@Param("employeeId") Integer employeeId);
	@Query(value = "select dbo.fn_DecryptText(employmentStatus) from EmployeeWork where employeeid=:employeeId",
			nativeQuery = true)
	String findByEmployeeID(@Param("employeeId")Integer employeeId);
	
	@Query(value = "select dbo.fn_DecryptText(locationId) from EmployeeWork where employeeid=:employeeId",
			nativeQuery = true)
	Integer getLocationID(@Param("employeeId")Integer employeeId);
}