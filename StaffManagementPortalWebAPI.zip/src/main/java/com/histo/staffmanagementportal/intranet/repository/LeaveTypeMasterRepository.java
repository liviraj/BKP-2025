package com.histo.staffmanagementportal.intranet.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.histo.staffmanagementportal.intranet.entity.LeaveTypeMaster;

public interface LeaveTypeMasterRepository extends JpaRepository<LeaveTypeMaster, Integer>{

	 public List<LeaveTypeMaster> findByLocationID( Integer locationID);
	
	 public Optional<LeaveTypeMaster> findByLocationIDAndLeaveTypeName( Integer locationID,String leaveTypeName);
	 
	 @Query("select leaveTypeName from LeaveTypeMaster where leaveTypeId=?1")
	 public String findLeaveTypeNameByLeaveTypeId(Integer leaveTypeId);
}
