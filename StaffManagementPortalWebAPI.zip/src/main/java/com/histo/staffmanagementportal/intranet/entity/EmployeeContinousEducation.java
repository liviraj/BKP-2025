package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.*;

import com.histo.staffmanagementportal.util.InstantConverter;

import java.time.Instant;

@Entity(name = "EmployeeContinousEducation")
public class EmployeeContinousEducation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ContinousID", nullable = false)
    private Integer id;

    @Column(name = "Employeeid", nullable = false)
    private Integer employeeId;

    @Column(name = "CourseName", nullable = false, length = 50)
    private String courseName;

    @Column(name = "ConductedBy", nullable = false, length = 50)
    private String conductedBy;

    @Column(name = "SponsoredBy", nullable = false, length = 50)
    private String sponsoredBy;

    @Column(name = "CourseDuration", nullable = false, length = 50)
    private String courseDuration;

    @Column(name = "CourseDescription", length = 500)
    private String courseDescription;

    @Column(name = "CourseCategory", nullable = false, length = 50)
    private String courseCategory;

    @Column(name = "ModifiedBy")
    private Integer modifiedBy;

    @Column(name = "ModifiedDate")
    @Convert(converter = InstantConverter.class)
    private Instant modifiedDate;
    
    @Column(name = "CreatedBy", nullable = false)
    private Integer createdBy;

    @Column(name = "CreatedOn", nullable = false)
    private Instant createdOn;

    @Column(name = "RecordStatus", nullable = false)
    private Character recordStatus;

    @Lob
    @Column(name = "EmployeeImage", nullable = false)
    private String employeeImage;

    @Column(name = "EmployeeImageBinary")
    private byte[] employeeImageBinary;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeid(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getConductedBy() {
        return conductedBy;
    }

    public void setConductedBy(String conductedBy) {
        this.conductedBy = conductedBy;
    }

    public String getSponsoredBy() {
        return sponsoredBy;
    }

    public void setSponsoredBy(String sponsoredBy) {
        this.sponsoredBy = sponsoredBy;
    }

    public String getCourseDuration() {
        return courseDuration;
    }

    public void setCourseDuration(String courseDuration) {
        this.courseDuration = courseDuration;
    }

    public String getCourseDescription() {
        return courseDescription;
    }

    public void setCourseDescription(String courseDescription) {
        this.courseDescription = courseDescription;
    }

    public String getCourseCategory() {
        return courseCategory;
    }

    public void setCourseCategory(String courseCategory) {
        this.courseCategory = courseCategory;
    }

    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Instant getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Instant createdOn) {
		this.createdOn = createdOn;
	}

	public Character getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(Character recordStatus) {
        this.recordStatus = recordStatus;
    }

    public String getEmployeeImage() {
        return employeeImage;
    }

    public void setEmployeeImage(String employeeImage) {
        this.employeeImage = employeeImage;
    }

    public byte[] getEmployeeImageBinary() {
        return employeeImageBinary;
    }

    public void setEmployeeImageBinary(byte[] employeeImageBinary) {
        this.employeeImageBinary = employeeImageBinary;
    }

}