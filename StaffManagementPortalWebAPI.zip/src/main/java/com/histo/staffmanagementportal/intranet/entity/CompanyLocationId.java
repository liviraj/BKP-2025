package com.histo.staffmanagementportal.intranet.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Embeddable
public class CompanyLocationId implements Serializable {
    private static final long serialVersionUID = 263674375611941128L;
    @NotNull
    @Column(name = "LocationID", nullable = false)
    private Integer locationID;

    @NotNull
    @Column(name = "Locationcitycode", nullable = false)
    private Integer locationcitycode;

    public Integer getLocationID() {
        return locationID;
    }

    public void setLocationID(Integer locationID) {
        this.locationID = locationID;
    }

    public Integer getLocationcitycode() {
        return locationcitycode;
    }

    public void setLocationcitycode(Integer locationcitycode) {
        this.locationcitycode = locationcitycode;
    }


}