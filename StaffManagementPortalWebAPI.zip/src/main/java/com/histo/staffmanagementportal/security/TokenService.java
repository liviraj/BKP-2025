package com.histo.staffmanagementportal.security;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.util.Date;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.nimbusds.jwt.JWT;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.JWTParser;

@Service
public class TokenService {
	private static final Logger logger = LogManager.getLogger(TokenService.class.getName());

	public String getEmailByToken(String token) {
		String emailId = "";
		try {
			if (StringUtils.isNotBlank(token)) {

				try {
	                OkHttpClient client = new OkHttpClient();
	                
	                // Define the API endpoint for retrieving emails
	                String apiUrl = "https://graph.microsoft.com/v1.0/me";
	                
	                Request request = new Request.Builder()
	                        .url(apiUrl)
	                        .header("Authorization", "Bearer " + token)
	                        .build();
	                        
					Response response = client.newCall(request).execute();
					if (response.isSuccessful()) {
						String responseBody = response.body().string();
						JSONObject jsonResponse = new JSONObject(responseBody);
						
						emailId = jsonResponse.getString("userPrincipalName");
					} else {
						logger.error("Error response: {}", response);
					}
				}

				catch (java.net.UnknownHostException e) { 
					JWT jwt = JWTParser.parse(token);
					JWTClaimsSet claimsSet = jwt.getJWTClaimsSet();
					if (isTokenExpire(claimsSet.getExpirationTime())) {
						emailId = "";
					} else {
						emailId = (String) claimsSet.getClaim("unique_name");
					}
				} 
			}
		} catch (Exception e) {
			logger.error("Exception message: {}", e);
		}
		return emailId;
	}
	
	private boolean isTokenExpire(Date expiryDate) {
        // Extract the expiration time claim

        return expiryDate != null && expiryDate.before( new Date());
    }
}
