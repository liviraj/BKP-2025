package com.histo.staffmanagementportal.security;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.model.RoleEnum;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import java.sql.Connection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Configuration
public class UserDetailConfig {

	@Bean
    
    public UserDetailsService userDetailsService() throws AuthenticationException {
        return username -> {

            Connection histoIntranetcon = SqlConnectionSetup.getConnection();
            JdbcTemplate histoIntranetJdbcTemplate = new JdbcTemplate(new SingleConnectionDataSource(histoIntranetcon, true));
            
            String roles = "";
            
            List<String> roleName = histoIntranetJdbcTemplate.queryForList("exec GetEmployeeId ?;"
            			,String.class, new Object[] {username.toLowerCase()});
               
                if(!roleName.isEmpty()) {
                	if(roleName.contains(RoleEnum.ADMINISTRATOR.getValue()))
                		roles=RoleEnum.ADMINISTRATOR.getValue();
                	else if(roleName.contains(RoleEnum.HUMAN_RESOURCE.getValue()))
                		roles=RoleEnum.HUMAN_RESOURCE.getValue();
                	else if(roleName.contains(RoleEnum.SECTION_SUPERVISOR.getValue()))
                		roles=RoleEnum.SECTION_SUPERVISOR.getValue();
                	else
                		roles=RoleEnum.EMPLOYEE.getValue();
                }
                else {
                	  throw new UsernameNotFoundException("Invalid credentials");
                }
   
            
            // todo handle multiple roles
//            return new User(userInformation.getEmailAddress(), "", getAuthority(roles.toUpperCase()));
                return new User(username, "", getAuthority(roles.toUpperCase()));        };
    }

    private Set<SimpleGrantedAuthority> getAuthority(String role) {
        Set<SimpleGrantedAuthority> authorities = new HashSet<>();
        authorities.add(new SimpleGrantedAuthority(role));
        return authorities;
    }

    @Bean
    public AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService());
        // provider.setPasswordEncoder(passwordEncoder());
        return provider;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }
}
