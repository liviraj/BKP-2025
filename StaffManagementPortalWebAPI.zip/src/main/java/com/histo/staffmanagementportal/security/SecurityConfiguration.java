package com.histo.staffmanagementportal.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true, jsr250Enabled = true)
public class SecurityConfiguration {
    private final TokenAuthenticationFilter tokenAuthenticationFilter;
    private final AuthenticationProvider authenticationProvider;

    public SecurityConfiguration(TokenAuthenticationFilter tokenAuthenticationFilter,
			AuthenticationProvider authenticationProvider) {
		this.tokenAuthenticationFilter = tokenAuthenticationFilter;
		this.authenticationProvider = authenticationProvider;
	}

	boolean securityDebug = false;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf()
                .disable()
                .cors()
                .and()
                .authorizeHttpRequests()
                .antMatchers( "/css/**", "/js/**", "/img/**", "/lib/**", "/favicon.ico"
                        , "/v2/api-docs", "/swagger-resources/**", "/swagger-ui.html", "/configuration/**"
                        , "webjars/**", "/public/**"
                        , "/v3/api-docs/**",
                        "/swagger-ui/**",
                        "/v2/api-docs/**",
                        "/swagger-resources/**",
                        "/webjars/springfox-swagger-ui/**")
                .permitAll()
                .and()
                .authorizeHttpRequests()
                .antMatchers("/filter/**"
                		, "/users/login"
                		, "/leave/type/**"
                		,"/leave/request/**"
                		,"/leave/balance/**"
                		,"/leave/history/**"
                		,"/leaveManagement/cancelRequest/**"
                		,"/leave/ledger/filter/**"
				        ,"/employeeDetails/requestDocument/**"
				        ,"/requests/**"
				        , "/events/**"
						,"/permissions/**"
						,"/holiday/list/**"
						,"/floating/holiday/**"
						,"/complianceReports/**"
						, "/dashboard/**"
						,"/workRequest/**"
						,"/timeInOut/**"
						,"/policy/review/**"
						,"/compliance/**")
                .hasAnyAuthority("EMPLOYEE", "ADMINISTRATOR", "HUMAN RESOURCE","SECTION SUPERVISOR")
                .and()
                .authorizeHttpRequests()
                .antMatchers( "/leaveManagement/**")
                .hasAnyAuthority("SECTION SUPERVISOR","ADMINISTRATOR", "HUMAN RESOURCE")
                .and()
                .authorizeHttpRequests()
                .antMatchers("/**","/leave/**")
                .hasAnyAuthority("ADMINISTRATOR", "HUMAN RESOURCE")
                .anyRequest()
                .authenticated()
                .and()
                .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .authenticationProvider(authenticationProvider)
                .addFilterBefore(tokenAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
