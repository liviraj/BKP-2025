package com.histo.staffmanagementportal.exception;

import java.time.Instant;

public class ExceptionBean {
	private Instant timestamp;
	private String message;
	private String description;
	
	public ExceptionBean() {
		// TODO Auto-generated constructor stub
	}

	public ExceptionBean(Instant timestamp, String message, String description) {
		super();
		this.timestamp = timestamp;
		this.message = message;
		this.description = description;
	}

	public Instant getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Instant timestamp) {
		this.timestamp = timestamp;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "ExceptionBean [timestamp=" + timestamp + ", message=" + message + ", description=" + description + "]";
	}
}
