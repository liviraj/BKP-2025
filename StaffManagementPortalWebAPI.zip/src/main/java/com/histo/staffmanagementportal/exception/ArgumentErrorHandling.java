package com.histo.staffmanagementportal.exception;

import java.time.Instant;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.util.ResponseUtil;

@ControllerAdvice
class ArgumentErrorHandling {
	@Autowired
	 private ResponseModel response ;
	  
     MappingJacksonValue mappingJacksonValue;
     
     @ExceptionHandler(ConstraintViolationException.class)
     ResponseEntity<Object> onConstraintValidationException(ConstraintViolationException e) {
	    ValidationErrorResponse error = new ValidationErrorResponse();
	    for (ConstraintViolation<?> violation : e.getConstraintViolations()) {
	      error.getViolations().add(new Violation(violation.getPropertyPath().toString(), violation.getMessage()));
	    }
	    response.setStatus(false);
	    response.setInformation(new ExceptionBean(Instant.now(), "Error", error.toString()));
		mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{ "status","information"});
		
		return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
	  
	}
	@ExceptionHandler(MethodArgumentNotValidException.class)
	ResponseEntity<Object> onMethodArgumentNotValidException(MethodArgumentNotValidException e) {
		ValidationErrorResponse error = new ValidationErrorResponse();
		for (FieldError fieldError : e.getBindingResult().getFieldErrors()) {
			error.getViolations().add(new Violation(fieldError.getField(), fieldError.getDefaultMessage()));
		}
		response.setStatus(false);
		response.setInformation(new ExceptionBean(Instant.now(), "Error", error.toString()));
		mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{ "status","information"});
		return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
	}
	
}
