package com.histo.staffmanagementportal.service.impl;

import java.text.SimpleDateFormat;
import java.time.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.intranet.entity.LeaveEncashment;
import com.histo.staffmanagementportal.intranet.entity.LeaveLedger;
import com.histo.staffmanagementportal.intranet.entity.SpecialLeaveLedger;
import com.histo.staffmanagementportal.intranet.entity.SpecialLeavesDebitMaster;
import com.histo.staffmanagementportal.intranet.repository.LeaveEncashmentRepository;
import com.histo.staffmanagementportal.intranet.repository.LeaveLedgerRepository;
import com.histo.staffmanagementportal.intranet.repository.SpecialLeaveLedgerRepository;
import com.histo.staffmanagementportal.intranet.repository.SpecialLeavesDebitMasterRepository;
import com.histo.staffmanagementportal.model.Constants;
import com.histo.staffmanagementportal.model.LCResponse;
import com.histo.staffmanagementportal.model.LeaveCreditDetail;
import com.histo.staffmanagementportal.model.LeaveEncashmentEmployee;
import com.histo.staffmanagementportal.model.LeaveTypeEnum;
import com.histo.staffmanagementportal.model.LocationEum;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.model.ResultSetMapper;
import com.histo.staffmanagementportal.model.SpecialLeaveCreditDetail;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;

@Service
public class LeaveCredit {

	private static final Logger logger = LogManager.getLogger(LeaveCredit.class);

	private final ResponseModel response;

	private static final String STATUS = "status";

	private MappingJacksonValue mappingJacksonValue;

	private final SpecialLeaveLedgerRepository debitDetailRepository;

	private final SpecialLeavesDebitMasterRepository specialLeavesDebitMasterRepo;

	private final LeaveEncashmentRepository encashmentRepository;

	private final LeaveLedgerRepository leaveLedgerRepository;

	public LeaveCredit(ResponseModel response, SpecialLeaveLedgerRepository debitDetailRepository,
			SpecialLeavesDebitMasterRepository specialLeavesDebitMasterRepo,
			LeaveLedgerRepository leaveLedgerRepository, LeaveEncashmentRepository encashmentRepository) {
		this.response = response;
		this.debitDetailRepository = debitDetailRepository;
		this.specialLeavesDebitMasterRepo = specialLeavesDebitMasterRepo;
		this.encashmentRepository = encashmentRepository;
		this.leaveLedgerRepository = leaveLedgerRepository;
	}

	public ResponseEntity<Object> getIndianEmpoyeeLeaveCredit() {
		try {

			List<LCResponse> leaveCreditResponse = SqlConnectionSetup.getJdbcConnection().query(
					"exec RunLeaveCreditIfApplicable ?", BeanPropertyRowMapper.newInstance(LCResponse.class),
					new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
			response.setStatus(true);
			response.setData(leaveCreditResponse);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch (Exception e) {
			return catchException("getIndianEmpoyeeLeaveCredit()", e, "Failed", "Unable to add leave credit");
		}
	}

	public ResponseEntity<Object> getUSEmployeeLeaveCredit() {
		try {
			
			List<LCResponse> leaveCreditResponse = new ArrayList<>();
			leaveCreditResponse = SqlConnectionSetup.getJdbcConnection().query("exec RunUSLeaveCreditIfApplicable ?",
					BeanPropertyRowMapper.newInstance(LCResponse.class),
					new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
			response.setStatus(true);
			response.setData(leaveCreditResponse);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch (Exception e) {
			return catchException("getUSEmployeeLeaveCredit()", e, "Failed", "Unable to add leave credit");
		}
	}

	public ResponseEntity<Object> getUSSickLeaveCredit() {
		try {
	
			List<Object> leaveCreditResponse = SqlConnectionSetup.getJdbcConnection().query(
					"exec SickLeaveCreditCalculationJob ?", new ResultSetMapper(),
					new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
			response.setStatus(true);
			response.setData(leaveCreditResponse);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch (Exception e) {
			return catchException("getUSSickLeaveCredit()", e, "Failed", "Unable to add sick leave credit");
		}
	}

	public ResponseEntity<Object> getSpecialDebitLeaveCredit() {
		try {
			
			String entryDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

			List<SpecialLeaveLedger> leaveCreditByRundate = debitDetailRepository
					.findByRemarksContainsAndEntryDate(Constants.LEAVE_CREDIT, entryDate);

			if (ObjectUtils.isEmpty(leaveCreditByRundate)) {

				List<LeaveCreditDetail> leaveCreditDetail = SqlConnectionSetup.getJdbcConnection().query(
						"exec spGetLeaveCreditEmployees", BeanPropertyRowMapper.newInstance(LeaveCreditDetail.class));

				List<SpecialLeaveCreditDetail> leaveCreditContent = new ArrayList<>();

				Optional<SpecialLeavesDebitMaster> sickleaveType = specialLeavesDebitMasterRepo
						.getLeaveDetail(LocationEum.INDIA.getValue(), LeaveTypeEnum.SICKLEAVE.getValue());

				Optional<SpecialLeavesDebitMaster> casualleaveType = specialLeavesDebitMasterRepo
						.getLeaveDetail(LocationEum.INDIA.getValue(), LeaveTypeEnum.CASUALLEAVE.getValue());

				leaveCreditDetail.forEach(leaveCredit -> {

					Optional<SpecialLeaveLedger> sickLeaveCreditByLeaveDate = debitDetailRepository
							.findByEmployeeIDAndEntryDateAndSLDebitMasterID_LeaveTypeIDAndCreditDaysGreaterThanEqual(
									leaveCredit.getEmployeeId(), InstantFormatter.InstantFormat(entryDate),
									sickleaveType.get().getLeaveTypeID(), 0.0);

					SpecialLeaveLedger sickLeavesDebitDetail = new SpecialLeaveLedger ();

					if (sickLeaveCreditByLeaveDate.isEmpty()) {

						sickLeavesDebitDetail.setEmployeeID(leaveCredit.getEmployeeId());
						sickLeavesDebitDetail.setCreditDays(sickleaveType.get().getTotalCreditsinDouble());
						sickLeavesDebitDetail.setBalance(sickleaveType.get().getTotalCreditsinDouble());
						sickLeavesDebitDetail.setRemarks(Constants.SICK_LEAVE_CREDIT_COMMENT);
						sickLeavesDebitDetail.setEntryDate (InstantFormatter.InstantFormat(entryDate));
						sickLeavesDebitDetail.setRunDate (InstantFormatter.InstantFormat(entryDate));
						sickLeavesDebitDetail.setComments(Constants.SICK_LEAVE_CREDIT_COMMENT);
						sickLeavesDebitDetail.setSLDebitMasterID(sickleaveType.get());

						SpecialLeaveLedger creditedSickLeaveDetail = debitDetailRepository
								.save(sickLeavesDebitDetail);
					}

					Optional<SpecialLeaveLedger> casualLeaveCreditByLeaveDate = debitDetailRepository
							.findByEmployeeIDAndEntryDateAndSLDebitMasterID_LeaveTypeIDAndCreditDaysGreaterThanEqual(
									leaveCredit.getEmployeeId(), InstantFormatter.InstantFormat(entryDate),
									casualleaveType.get().getLeaveTypeID(), 0.0);

					SpecialLeaveLedger casualLeavesDebitDetail = new SpecialLeaveLedger ();

					if (casualLeaveCreditByLeaveDate.isEmpty()) {

						casualLeavesDebitDetail.setEmployeeID(leaveCredit.getEmployeeId());
						casualLeavesDebitDetail.setCreditDays(casualleaveType.get().getTotalCreditsinDouble());
						casualLeavesDebitDetail.setBalance(casualleaveType.get().getTotalCreditsinDouble());
						casualLeavesDebitDetail.setRemarks(Constants.CASUAL_LEAVE_CREDIT_COMMENT);
						casualLeavesDebitDetail.setEntryDate (InstantFormatter.InstantFormat(entryDate));
						casualLeavesDebitDetail.setRunDate(InstantFormatter.InstantFormat(entryDate));
						casualLeavesDebitDetail.setComments(Constants.CASUAL_LEAVE_CREDIT_COMMENT);
						casualLeavesDebitDetail.setSLDebitMasterID(casualleaveType.get());

						SpecialLeaveLedger creditedCasualLeaveDetail = debitDetailRepository
								.save(casualLeavesDebitDetail);

					}

					leaveCreditContent
							.add(new SpecialLeaveCreditDetail(leaveCredit.getEmployeeName(), new SimpleDateFormat("MM/dd/yyyy").format(new Date()),
									sickLeavesDebitDetail.getCreditDays(),sickLeavesDebitDetail.getBalance()
									, casualLeavesDebitDetail.getCreditDays(), casualLeavesDebitDetail.getBalance()));
				});
				response.setStatus(true);
				response.setData(leaveCreditContent);
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
			}
			response.setStatus(false);
			response.setData("Leave credit already run successfully for given year");
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);

		} catch (Exception e) {
			return catchException("getSpecialDebitLeaveCredit()", e, "Failed",
					"Unable to add casual and sick leave credit");
		}
	}

	public ResponseEntity<Object> leaveEncashment() {
		try {
			String entryDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

			Instant encashmentDate = InstantFormatter.InstantFormat(entryDate)
					.minus (Duration.ofDays (1));
			
			LocalDate localDate = new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			
	        if (localDate.getMonthValue() == 12 && localDate.getDayOfMonth() == 24) {

			List<LeaveEncashmentEmployee> leaveEncashmentEmployee = SqlConnectionSetup.getJdbcConnection().query(
					"exec EmployeeEligibleForEncash", BeanPropertyRowMapper.newInstance(LeaveEncashmentEmployee.class));

			List<LeaveEncashmentEmployee> eligibleEmployeeDetails = leaveEncashmentEmployee.stream()
					.filter(employee -> encashmentRepository
							.findByEmployeeIdAndEncashmentDate(employee.getEmployeeId(), encashmentDate).isEmpty())
					.toList();

			eligibleEmployeeDetails.forEach(employee -> {
				LeaveEncashment encashment = new LeaveEncashment();
				encashment.setEmployeeId(employee.getEmployeeId());
				encashment.setEncashmentDate(encashmentDate);
				encashment.setIsLedgerReset(true);
				encashment.setLeaveEncashed(employee.getBalanceDays() - Constants.MAX_ENCASH_LEAVE);
				encashment.setRemarks("Leave Encashment");
				encashment.setRunDate(InstantFormatter.InstantFormat(entryDate));

				encashmentRepository.save(encashment);

				LeaveLedger leaveLedger = new LeaveLedger();
				leaveLedger.setDebitDays(employee.getBalanceDays() - Constants.MAX_ENCASH_LEAVE);
				leaveLedger.setBalanceDays(Constants.MAX_ENCASH_LEAVE);
				leaveLedger.setEmployeeId(employee.getEmployeeId());
				leaveLedger.setEntryDate(InstantFormatter.InstantFormat(entryDate));
				leaveLedger.setComments("Leave Encashment");
				leaveLedger.setRunDate(InstantFormatter.InstantFormat(entryDate));

				leaveLedgerRepository.save(leaveLedger);
			});

			String status = SqlConnectionSetup.getJdbcConnection().queryForObject("exec SendEmailOnLeaveEncash ?",
					BeanPropertyRowMapper.newInstance(String.class)
					,entryDate);
			response.setStatus(true);
			response.setData(status);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
	        }
			else {
	        	return catchException("leaveEncashment()", null, "Invalid date", "Failed to run leave encashment schedular");
	        }
		} catch (Exception e) {
			return catchException("leaveEncashment()", e, "Error", "Failed to run leave encashment schedular");
		}
	}

	private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
		logger.error("{} Error : {}" + methodName, e);
		response.setStatus(false);
		response.setInformation(new ExceptionBean(Instant.now(), message, description));
		mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
		return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
	}
}
