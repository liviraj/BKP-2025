package com.histo.staffmanagementportal.service.impl;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.histo.orgmaster.entity.DesignationMaster;
import com.histo.orgmaster.repository.DesignationMasterRepository;
import com.histo.policyagreement.entity.ReviewedPolicyDetails;
import com.histo.policyagreement.repository.ReviewedPolicyDetailsRepository;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.dto.*;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.intranet.entity.*;
import com.histo.staffmanagementportal.intranet.repository.*;
import com.histo.staffmanagementportal.model.*;

import com.histo.staffmanagementportal.service.EmployeeDetailsService;
import com.histo.staffmanagementportal.util.ResponseUtil;

@Service
public class EmployeeDetailsServiceImpl implements EmployeeDetailsService {

	private static final Logger logger = LogManager.getLogger(EmployeeDetailsServiceImpl.class);
	private static final String STATUS = "status";
	private static final String MESSAGE = "Image not found";

	private final EmployeeWorkScheduleRepository employeeWorkScheduleRepo;

	private final EmployeeCommunicationRepository employeeCommunicationRepo;

	private final EmployeeRequestDetailsRepository employeeRequestDetailsRepo;

	private final DocumentRepository documentRepository;

	private final ReviewedPolicyDetailsRepository reviewedPolicyDetailsRepo;

	private final DesignationMasterRepository designationMasterRepository;

	private final ResponseModel response;
 
    private MappingJacksonValue mappingJacksonValue;

	public EmployeeDetailsServiceImpl(EmployeeWorkScheduleRepository employeeWorkScheduleRepo, EmployeeCommunicationRepository employeeCommunicationRepo, EmployeeRequestDetailsRepository employeeRequestDetailsRepo, DocumentRepository documentRepository, ReviewedPolicyDetailsRepository reviewedPolicyDetailsRepo, DesignationMasterRepository designationMasterRepository, ResponseModel response) {
		this.employeeWorkScheduleRepo = employeeWorkScheduleRepo;
		this.employeeCommunicationRepo = employeeCommunicationRepo;
		this.employeeRequestDetailsRepo = employeeRequestDetailsRepo;
		this.documentRepository = documentRepository;
		this.reviewedPolicyDetailsRepo = reviewedPolicyDetailsRepo;
		this.designationMasterRepository = designationMasterRepository;
		this.response = response;
	}

	@Override
	public ResponseEntity<Object> getEmployeeDetails(Integer employeeId) {
		try {
			EmployeeDetails employeeDetail = new EmployeeDetails();
			String employeeCodeByEmployeeId = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetEmployeeCodeByEmpId ?",
					String.class,
					employeeId);
			if(ObjectUtils.isNotEmpty(employeeCodeByEmployeeId)) {
				EmployeePersonalDetails employeeDetailsView = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetEmployeeDetailByEmployeeId ?",
						BeanPropertyRowMapper.newInstance(EmployeePersonalDetails.class),
						employeeId);

				employeeDetail.setPersonalDetail(employeeDetailsView);
			} else {
				employeeDetail.setPersonalDetail(new EmployeePersonalDetails());
			}

			List<EmployeeWorkDetails> employeeWorkDetails = SqlConnectionSetup.getJdbcConnection()
					.query("exec spGetEmployeeWorkDetails ?", BeanPropertyRowMapper.newInstance(EmployeeWorkDetails.class),employeeId);

			Integer employeeCommunicationId = employeeCommunicationRepo.getEmployeeCommunicationId(employeeId);
			List<EmployeeCommunication> employeeCommunication = SqlConnectionSetup.getJdbcConnection().query("exec spGetEmployeeCommunicationById ?;",
					BeanPropertyRowMapper.newInstance(EmployeeCommunication.class), employeeCommunicationId);
			if(ObjectUtils.isNotEmpty(employeeCommunication)) {

				EmployeeCommunicationDetails employeeCommunicationView = employeeCommunication.stream().map(communication ->
						new EmployeeCommunicationDetails((communication.getAddress1()+" "+
								communication.getAddress2()+" "+
								communication.getAddress3()+" "+
								communication.getCity()+" "+
								communication.getPin()+" "+
								communication.getState()+" "+
								(communication.getCountry().equals("1") ?"India":"USA")),
								communication.getAlternateContactNumber(),
								communication.getEmailID(),
								communication.getEmergencyContactName(),
								communication.getEmergencyContactNumber(),
								communication.getEmergencyContactRelation(),
								communication.getPhoneno(),
								communication.getCellno(),
								communication.getEmergencyContactAddress1()+" "+
										communication.getEmergencyContactAddress2()+" "+
										communication.getEmergencyContactAddress3())).findFirst().get();

				employeeDetail.setCommunicationDetail(employeeCommunicationView);
			} else {
				employeeDetail.setCommunicationDetail(new EmployeeCommunicationDetails());
			}

			List<EmployeeWorkHistoryModel> employeeWorkHistoryDetail =  SqlConnectionSetup.getJdbcConnection()
					.query("exec spGetWorkHistoryByEmpId ?", BeanPropertyRowMapper.newInstance(EmployeeWorkHistoryModel.class),employeeId);
//			List<EmployeeWorkHistoryModel> employeeWorkHistoryDetail = employeeWorkHistory.stream().map(workHistory -> new EmployeeWorkHistoryModel(
//					workHistory.getId(), workHistory.getEmployerName(), workHistory.getDesignation(), workHistory.getDateofJoin()
//					,workHistory.getRelievingDate())).toList();

			List<EmployeeQualificationViewDTO> employeeQualification = SqlConnectionSetup.getJdbcConnection().query("exec GetEmployeeQualificationEmployeeID ?", BeanPropertyRowMapper.newInstance(EmployeeQualificationViewDTO.class)
					, employeeId);
            List<EmployeeQualificationDetails> employeeQualificationDetails=employeeQualification.stream().map(qualification -> new EmployeeQualificationDetails(
                    qualification.getEmpQualificationId(), qualification.getQualification(), qualification.getInstitution()
                    ,qualification.getCourseEndDate())).toList();

			List<EmployeeContinousEducationViewDTO> employeeContinousEducation = SqlConnectionSetup.getJdbcConnection().query("exec spGetContinousEducationByEmpId ?"
					, BeanPropertyRowMapper.newInstance(EmployeeContinousEducationViewDTO.class)
					,employeeId);
			List<EmployeeContinuousEducationModel> employeeContinuousEducationDetails = employeeContinousEducation.stream().map(continousEducation -> new EmployeeContinuousEducationModel(continousEducation.getId(),
					continousEducation.getCourseDuration(), continousEducation.getCourseName(), continousEducation.getConductedBy(), continousEducation.getCourseCategory())).toList();

			List<EmployeeWorkScheduleModel> employeeWorkSchedule = employeeWorkScheduleRepo.findWorkSchedule(employeeId);


			employeeDetail.setWorkDetail(employeeWorkDetails);
			employeeDetail.setQualification(employeeQualificationDetails);
			employeeDetail.setContinuousEducation(employeeContinuousEducationDetails);
			employeeDetail.setWorkHistory(employeeWorkHistoryDetail);
			employeeDetail.setWorkSchedule(employeeWorkSchedule);

			response.setStatus(true);
			response.setData(employeeDetail);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch (Exception e) {
			return catchException("getEmployeeDetails()", e, "Error", "Failed to get employee detail");
		}
	}

	@Override
	public ResponseEntity<Object> getEmployeeDocument(Integer employeeId,String imageType) {
		try {
			EmployeeDTO employeeDetail = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetEmployeeByEmployeeId ?;", BeanPropertyRowMapper.newInstance(EmployeeDTO.class),
					employeeId);
			ImageViewModel imageViewModel = new ImageViewModel();
			if(imageType.equalsIgnoreCase(ImageTypeEnum.IDPROOF.getValue()) &&
					employeeDetail.getIdProofImg()!=null && employeeDetail.getIdProofImageBinary()!=null ) {
				imageViewModel.setDocumentName(employeeDetail.getIdProofImg());
				imageViewModel.setDocumentBinary(employeeDetail.getIdProofImageBinary());
				response.setStatus(true);
				response.setData(imageViewModel);
				mappingJacksonValue = ResponseUtil.responseFilter(response,new String[]{"data",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
			} else if(imageType.equalsIgnoreCase(ImageTypeEnum.PASSPORT_IMAGE.getValue()) &&
					employeeDetail.getPassportImage()!=null && employeeDetail.getPassportImageBinary()!=null) {
				imageViewModel.setDocumentName(employeeDetail.getPassportImage());
				imageViewModel.setDocumentBinary(employeeDetail.getPassportImageBinary());
				response.setStatus(true);
				response.setData(imageViewModel);
				mappingJacksonValue = ResponseUtil.responseFilter(response,new String[]{"data",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
			} else if(imageType.equalsIgnoreCase(ImageTypeEnum.IMAGE.getValue()) &&
					employeeDetail.getImage()!=null && employeeDetail.getPhotoImageBinary()!=null) {
				imageViewModel.setDocumentName(employeeDetail.getImage());
				imageViewModel.setDocumentBinary(employeeDetail.getPhotoImageBinary());
				response.setStatus(true);
				response.setData(imageViewModel);
				mappingJacksonValue = ResponseUtil.responseFilter(response,new String[]{"data",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
			}
			response.setStatus(false);
                response.setInformation(new ExceptionBean(Instant.now(), "Failed", MESSAGE));
                mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);

		}catch(Exception e) {
			return catchException("getEmployeeDocument()",e,"Error","Employee Not Found");
		}
	}

	@Override
	public ResponseEntity<Object> getQualificationCertificate(Integer qualificationId) {
		try {

			List<Document> employeeQualification = documentRepository.findByDocumentIdAndRecordStatusAndDocumentType (qualificationId, Constants.ACTIVE_RECORD_STATUS,
					StaffModuleName.QUALIFICATION.getValue ());

			if(employeeQualification.isEmpty ()) {
				response.setStatus(false);
                response.setInformation(new ExceptionBean(Instant.now(), "Failed", MESSAGE));
                mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}

			response.setStatus(true);
			response.setData(employeeQualification);
			mappingJacksonValue = ResponseUtil.responseFilter(response,new String[]{"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

		}catch(Exception e) {
			return catchException("getQualificationCertificate()",e,"Error","Failed to get employee passport image");
		}
	}

	@Override
	public ResponseEntity<Object> getContinuousEducationCertificate(Integer continuousEducationId) {
		try {
			List<Document> continuouEducationCertificate = documentRepository.findByDocumentIdAndRecordStatusAndDocumentType
					(continuousEducationId, Constants.ACTIVE_RECORD_STATUS, StaffModuleName.CONTINOUSEDUCATION.getValue ());

			if(continuouEducationCertificate.isEmpty ()) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(), "Failed", MESSAGE));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}

			response.setStatus(true);
			response.setData(continuouEducationCertificate);
			mappingJacksonValue = ResponseUtil.responseFilter(response,new String[]{"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

		}catch(Exception e) {
			return catchException("getContinuousEducationCertificate()",e,"Error","Failed to get employee continous education certificate");
		}
	}

	@Override
	public ResponseEntity<Object> getWorkHistoryProof(Integer workHistoryId) {
		try {
			List<Document> employeeWorkHistory = documentRepository.findByDocumentIdAndRecordStatusAndDocumentType
					(workHistoryId, Constants.ACTIVE_RECORD_STATUS, StaffModuleName.WORKHISTORY.getValue ());

			if(employeeWorkHistory.isEmpty ()) {
				response.setStatus(false);
                response.setInformation(new ExceptionBean(Instant.now(), "Failed", MESSAGE));
                mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}

			response.setStatus(true);
			response.setData(employeeWorkHistory);
			mappingJacksonValue = ResponseUtil.responseFilter(response,new String[]{"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

		}catch(Exception e) {
			return catchException("getWorkHistoryProof()",e,"Failed","Unable to fetch employee work history document");
		}
	}

	@Override
	public ResponseEntity<Object> getEmployeeRequestDocument(Integer requestId) {
		try {
			Optional<EmployeeRequestDetails> employeeRequestDetails = employeeRequestDetailsRepo.findById (requestId);

			if(employeeRequestDetails.isEmpty () || (employeeRequestDetails.get ().getImageName ()==null && employeeRequestDetails.get ().getImageBinary ()==null)) {

				return catchException ("getEmployeeRequestDocument()",null,"Data not found",employeeRequestDetails.isEmpty ()
						?"Employee request not found":MESSAGE);
			}
			ImageViewModel requestDocument = new ImageViewModel();
			requestDocument.setDocumentName(employeeRequestDetails.get ().getImageName ());
			requestDocument.setDocumentBinary(employeeRequestDetails.get ().getImageBinary ());
			response.setStatus(true);
			response.setData(requestDocument);
			mappingJacksonValue = ResponseUtil.responseFilter(response,new String[]{"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

		}catch(Exception e) {
			return catchException("getEmployeeRequestDocument()",e,"Failed","Unable to fetch employee request document");
		}
	}

	@Override
	public ResponseEntity<Object> getEmployeepolicyDocument(Integer policyId) {
		try {
			Optional<ReviewedPolicyDetails> policyDetailsRepoById = reviewedPolicyDetailsRepo.findById(policyId);

			if(policyDetailsRepoById.isEmpty () || (policyDetailsRepoById.get ().getDocumentName ()==null && policyDetailsRepoById.get ().getDocumentImage ()==null)) {

				return catchException ("getEmployeepolicyDocument()",null,"Data not found",policyDetailsRepoById.isEmpty ()
						?"Employee reviewed policy document not found":MESSAGE);
			}
			ImageViewModel requestDocument = new ImageViewModel();
			requestDocument.setDocumentName(policyDetailsRepoById.get ().getDocumentName ());
			requestDocument.setDocumentBinary(policyDetailsRepoById.get ().getDocumentImage ());
			response.setStatus(true);
			response.setData(requestDocument);
			mappingJacksonValue = ResponseUtil.responseFilter(response,new String[]{"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

		}catch(Exception e) {
			return catchException("getEmployeepolicyDocument()",e,"Failed","Unable to fetch employee request document");
		}
	}

	@Override
	public ResponseEntity<Object> getEmployeeDesignationDocument(Integer designationId) {
		try {
			Optional<DesignationMaster> designationMasterById = designationMasterRepository.findById(designationId);

			if(designationMasterById.isEmpty ()) {

				return catchException ("getEmployeeDesignationDocument()",null,"Data not found",designationMasterById.isEmpty ()
						?"Designation document details not found":MESSAGE);
			}
			ImageViewModel requestDocument = new ImageViewModel();
			requestDocument.setDocumentName(designationMasterById.get ().getDocumentName ());
			requestDocument.setDocumentBinary(designationMasterById.get ().getDocumentImage ());
			response.setStatus(true);
			response.setData(Arrays.asList(requestDocument));
			mappingJacksonValue = ResponseUtil.responseFilter(response,new String[]{"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

		}catch(Exception e) {
			return catchException("getEmployeeDesignationDocument()",e,"Failed","Unable to fetch designation document details.");
		}
	}

	private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
		logger.error("{} Error : {}" , methodName, e);
        response.setStatus(false);
        response.setInformation(new ExceptionBean(Instant.now(), message, description));
        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
	}
}
