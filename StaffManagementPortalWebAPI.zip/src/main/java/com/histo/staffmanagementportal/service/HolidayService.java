package com.histo.staffmanagementportal.service;

import com.histo.staffmanagementportal.dto.EmployeeHoliDayDTO;
import com.histo.staffmanagementportal.dto.HolidayDTO;
import com.histo.staffmanagementportal.dto.HolidayMasterDTO;
import com.histo.staffmanagementportal.intranet.entity.EmployeeHoliDay;
import com.histo.staffmanagementportal.model.DeleteDetails;
import com.histo.staffmanagementportal.model.FilterModel;
import com.histo.staffmanagementportal.util.UsFederalHolidayResponse;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface HolidayService {

    ResponseEntity<Object> getHolidayDetails(FilterModel filterModel);

    ResponseEntity<Object> getUSHolidayList(Integer year, UsFederalHolidayResponse usFederalHolidayResponse);

    ResponseEntity<Object> getHolidayMasterList(FilterModel filterModel);

    ResponseEntity<Object> getFloatingHolidayMasterList(FilterModel filterModel);

    ResponseEntity<Object> addHoliday(List<HolidayDTO> holidayDTO);

    ResponseEntity<Object> editHoliday(Integer Id, HolidayDTO holidayDTO);

    ResponseEntity<Object> addHoliday(HolidayMasterDTO holidayDTO);

    ResponseEntity<Object> editHoliday(Integer Id, HolidayMasterDTO holidayDTO);

    ResponseEntity<Object> deleteHoliday(DeleteDetails deleteDetails);

    ResponseEntity<Object> deleteHolidayMaster(DeleteDetails deleteDetails);

}
