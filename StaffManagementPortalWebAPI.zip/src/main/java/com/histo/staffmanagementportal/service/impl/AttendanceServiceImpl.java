package com.histo.staffmanagementportal.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.model.AttendanceFilter;
import com.histo.staffmanagementportal.model.AttendanceReport;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.model.ResultSetMapper;
import com.histo.staffmanagementportal.service.AttdanceService;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.stereotype.Service;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.Instant;
import java.util.List;

@Service
public class AttendanceServiceImpl implements AttdanceService {
    private static final Logger logger = LogManager.getLogger(AttendanceServiceImpl.class);
    private static final String STATUS = "status";
    private final ResponseModel response;
    private MappingJacksonValue mappingJacksonValue;
    public AttendanceServiceImpl(ResponseModel response) {
        this.response = response;
    }
    @Override
    public ResponseEntity<Object> getEmployeeAttendanceforReportbyPeriod(AttendanceFilter reportFilter) {
        try{
        List<Object> attendanceReport = SqlConnectionSetup.getJdbcConnection().query("exec GetEmployeeAttendanceforReportbyPeriod ?,?,?;",
                new ResultSetMapper ()
                ,reportFilter.getFromDate (),
                reportFilter.getToDate (),
                reportFilter.getLocationId ());

        if(attendanceReport.isEmpty ()){
            return catchException("getEmployeeAttendanceforReportbyPeriod()", null, "No value", "No value present");
        }

        response.setStatus(true);
        response.setData(attendanceReport);
        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException("getEmployeeAttendanceforReportbyPeriod()", e, "Error", "Cannot fetch employee attendance report");
        }
    }

    @Override
    public ResponseEntity<Object> getEmployeeMonthlyAttendanceReport(AttendanceFilter reportFilter) {
        try{
            List<Object> attendanceReport = SqlConnectionSetup.getJdbcConnection().query("exec GetLeavesAvailedDetailsforEmployeesNew ?,?,?,?;",
                    new ResultSetMapper ()
                    ,reportFilter.getLocationId ()
                    ,reportFilter.getFromDate ()
                    ,reportFilter.getToDate ()
                    ,reportFilter.getEmployeeId ());

            List<Object> attendanceReportDates = SqlConnectionSetup.getJdbcConnection().query("exec GetLatestReviewedAttendancenLedgerDate ?;",
                    new ResultSetMapper ()
                    ,reportFilter.getToDate ());

            if(attendanceReport.isEmpty ()){
                return catchException("getEmployeeMonthlyAttendanceReport()", null, "No value", "No value present");
            }
            AttendanceReport attendanceReports = new AttendanceReport ();
            attendanceReports.setAttendanceReports (attendanceReport);
            attendanceReports.setAttendanceAndLeaveReportsDate (attendanceReportDates.get (0));

            response.setStatus(true);
            response.setData(attendanceReports);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

    } catch (Exception e) {
        return catchException("getEmployeeMonthlyAttendanceReport()", e, "Error", "Cannot fetch employee monthly attendance report");
    }
    }

    @Override
    public ResponseEntity<Object> getEmployeeTimingDetailsByPeriod(AttendanceFilter reportFilter) {
        try{
            List<Object> employeeTimingReport = SqlConnectionSetup.getJdbcConnection().query("exec GetEmpTimeInOutDetailsByPeriod ?,?,?,?;",
                    new ResultSetMapper ()
                    ,reportFilter.getFromDate ()
                    ,reportFilter.getToDate ()
                    ,reportFilter.getLocationId ()
                    ,reportFilter.getEmployeetype ());

            if((employeeTimingReport.isEmpty ())){
                return catchException("getEmployeeTimingDetailsByPeriod()", null, "No value", "No value present");
            }

            response.setStatus(true);
            response.setData(employeeTimingReport);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
     catch (Exception e) {
        return catchException("getEmployeeTimingDetailsByPeriod()", e, "Error", "Cannot fetch employee timing details report");
    }

    }
        private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
            logger.error("{} Error : {}" + methodName, e);
            ExceptionBean exception = new ExceptionBean(Instant.now(), message, description);
            response.setStatus(false);
            response.setInformation(exception);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
        }
}
