package com.histo.staffmanagementportal.service.impl;

import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.histo.staffmanagementportal.intranet.entity.Document;
import com.histo.staffmanagementportal.intranet.repository.DocumentRepository;
import com.histo.staffmanagementportal.intranet.repository.EmployeeTrainingRepository;
import com.histo.staffmanagementportal.model.*;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.dto.EmployeeTrainingDTO;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.helper.DateValidation;
import com.histo.staffmanagementportal.service.EmployeeTrainingService;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;


@Service
public class EmployeeTrainingServiceImpl implements EmployeeTrainingService{
	
	private static final Logger logger = LogManager.getLogger(EmployeeTrainingServiceImpl.class);

	private static final String STATUS = "status";
	
	@Autowired
    private ResponseModel response;

    private MappingJacksonValue mappingJacksonValue;
    private final DocumentRepository documentRepository;

	private final EmployeeTrainingRepository trainingRepository;

	public EmployeeTrainingServiceImpl(DocumentRepository documentRepository, EmployeeTrainingRepository trainingRepository) {
		this.documentRepository = documentRepository;
		this.trainingRepository = trainingRepository;
	}


	@Override
	public ResponseEntity<Object> getEmployeeTrainingById(Integer trainingId) {
		try {
			List<EmployeeTrainingDTO> employeetraining = SqlConnectionSetup.getJdbcConnection()
					.query("exec spGetEmployeeTrainingById ?", BeanPropertyRowMapper.newInstance(EmployeeTrainingDTO.class),trainingId);
			if(employeetraining.isEmpty()) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(),"Error","Employee training not found"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"information",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT); 
			}

			List<Document> documentDetails = documentRepository.findByDocumentIdAndRecordStatusAndDocumentType (trainingId,
					Constants.ACTIVE_RECORD_STATUS,
					StaffModuleName.TRAINING.getValue ());

			employeetraining.get (0).setDocumentList (documentDetails);

			response.setStatus(true);
			response.setData(employeetraining.get(0));
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK); 
		}
		catch(Exception e) {
				return catchException("getEmployeeTrainingById()", e, "Error", "Employee training not found");
		}
		}

	@Override
	public ResponseEntity<Object> getEmployeeTrainingByEmployeeId(Integer employeeId) {
		try {
			List<EmployeeTrainingDetails> employeeTraining = SqlConnectionSetup.getJdbcConnection()
					.query("exec spGetTrainingByEmpId ?", BeanPropertyRowMapper.newInstance(EmployeeTrainingDetails.class),employeeId);
			response.setStatus(true);
			response.setData(employeeTraining);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK); 
		}
		catch(Exception e) {
				return catchException("getEmployeeTrainingByEmployeeId()", e, "Error", "Employee training not found");
		}		
		}
	@Override
	public ResponseEntity<Object> addEmployeeTrainingDetails(EmployeeTrainingDTO trainingDTO) {
		try {
			if(DateValidation.validateDate(trainingDTO.getTrainingFrom(), trainingDTO.getTrainingTo())) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(),"Invalid date","Training start date should not lesser than Training end date"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"information",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT); 
			}
			EmployeeTrainingDTO employeeTrainingDTO = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spInsertEmployeeTraining ?,?,?,?,?,?,?,?,?; ", BeanPropertyRowMapper.newInstance(EmployeeTrainingDTO.class),
					new Object[] {
							0,
							trainingDTO.getEmployeeID(), 
							trainingDTO.getEmployeeTrainingCategoryID(),  
							trainingDTO.getTrainingFrom(),  
							trainingDTO.getTrainingTo(),  
							trainingDTO.getPurpose(),  
							trainingDTO.getTrainingDocumentName(), 
							trainingDTO.getTrainingDocBinary(),  
							trainingDTO.getModifiedBy()
	
					});

			if(ObjectUtils.isNotEmpty (employeeTrainingDTO)){
				for(Document documentDetails : trainingDTO.getDocumentList ()){

					documentDetails.setDocumentId (employeeTrainingDTO.getEmployeeTrainingID ());
					documentDetails.setDocumentType (StaffModuleName.TRAINING.getValue ());
					Document savedDocumentDetails = documentRepository.save (documentDetails);
				}

			}
			response.setStatus(true);
			response.setData(employeeTrainingDTO);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK); 
		}
		catch(Exception e) {
				return catchException("addEmployeeTrainingDetails()", e, "Error", "Cannot add employee training details");
		}		
	}

	@Override
	public ResponseEntity<Object> updateEmployeeTraining(EmployeeTrainingDTO employeeTrainingDTO, Integer trainingId) {
		try {
			List<EmployeeTrainingDTO> employeetraining = SqlConnectionSetup.getJdbcConnection()
					.query("exec spGetEmployeeTrainingById ?", BeanPropertyRowMapper.newInstance(EmployeeTrainingDTO.class),trainingId);
			if(employeetraining.isEmpty()) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(),"Error","Employee training details not found"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"information",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT); 
			}
			else if(DateValidation.validateDate(employeeTrainingDTO.getTrainingFrom(), employeeTrainingDTO.getTrainingTo())) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(),"Invalid date","Training start date should not lesser than Training end date"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"information",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT); 
			}
			String employeeWorkStatus = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetEmploymentStatusByEmpId ?", String.class,employeeTrainingDTO.getEmployeeID());
			if(ObjectUtils.equals(employeeWorkStatus, Constants.RELIEVED_STATUS)) {
				return catchException("updateEmployeeTraining()", null, "Not a active employee", "Cannot update relieved employee details");
			}
			EmployeeTrainingDTO trainingDTO = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spUpdateEmployeeTraining ?,?,?,?,?,?,?,?,?; ", BeanPropertyRowMapper.newInstance(EmployeeTrainingDTO.class),
					new Object[] {
							trainingId, 
							employeeTrainingDTO.getEmployeeTrainingCategoryID(),  
							employeeTrainingDTO.getTrainingFrom(),  
							employeeTrainingDTO.getTrainingTo(),  
							employeeTrainingDTO.getPurpose(),  
							employeeTrainingDTO.getTrainingDocumentName(), 
							employeeTrainingDTO.getTrainingDocBinary(),  
							employeeTrainingDTO.getModifiedBy(),
							Constants.ACTIVE_RECORD_STATUS
	
					});

			if(ObjectUtils.isNotEmpty (trainingDTO)){
				employeeTrainingDTO.getDocumentList ().stream ().forEach (document ->{
					if(document.getId () == null){

						document.setDocumentId (trainingDTO.getEmployeeTrainingID ());
						document.setDocumentType (StaffModuleName.TRAINING.getValue ());
						document.setCreatedBy (employeeTrainingDTO.getModifiedBy ());
						Document savedDocumentDetails = documentRepository.save (document);

					}
					else{

						Optional<Document> existingDocumentDetails = documentRepository.findByIdAndRecordStatusAndDocumentType (
								document.getId (),
								Constants.ACTIVE_RECORD_STATUS,
								StaffModuleName.TRAINING.getValue ());

						existingDocumentDetails.get ().setRecordStatus (document.getRecordStatus ());
						existingDocumentDetails.get ().setModifiedBy (employeeTrainingDTO.getModifiedBy ());
						documentRepository.save (existingDocumentDetails.get ());
					}
				});


			}

			response.setStatus(true);
			response.setData(trainingDTO);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK); 
		}
		catch(Exception e) {
				return catchException("updateEmployeeTraining()", e, "Error", "Cannot update employee training details");
		}		
	}

	@Override
	public ResponseEntity<Object> getTrainingCategory() {
		try {
			List<TrainingCategoryProjector> trainingCategory = trainingRepository.getTrainingCategory();
			response.setStatus(true);
			response.setData(trainingCategory);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK); 
		}
		catch(Exception e) {
			return catchException("getTrainingCategory()", e, "Error", "Cannot get training category");
	}
	}
	
	private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
		logger.error("{} Error : {}" + methodName, e);
		ExceptionBean exception = new ExceptionBean(Instant.now(), message, description);
		response.setStatus(false);
		response.setInformation(exception);
		mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information",STATUS});
		return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
	}

	@Override
	public ResponseEntity<Object> deleteEmployeeTrainingById(Integer trainingId, ModifiedDetails modifiedDetails) {
		try {
			int updateRecordStatusById = trainingRepository.updateRecordStatusById(Constants.DELETED_RECORD_STATUS,trainingId,modifiedDetails.modifiedBy(),
					InstantFormatter.InstantFormat(modifiedDetails.modifiedDate()));
			
			if(updateRecordStatusById <= 0) {
		
				return catchException("deleteEmployeeTrainingById()",null,"Error","Employee training not found");

			}

			response.setStatus(true);
			response.setMessage("Training details deleted successfully");
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"message",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK); 
		}
		catch(Exception e) {
				return catchException("deleteEmployeeTrainingById()", e, "Error", "Cannot delete Employee training details");
		}
	}

}
