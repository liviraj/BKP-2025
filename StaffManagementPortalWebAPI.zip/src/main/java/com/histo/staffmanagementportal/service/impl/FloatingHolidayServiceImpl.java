package com.histo.staffmanagementportal.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.dto.EmployeeHoliDayDTO;
import com.histo.staffmanagementportal.dto.HolidayIdDetails;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.intranet.entity.EmployeeHoliDay;
import com.histo.staffmanagementportal.intranet.entity.Holiday;
import com.histo.staffmanagementportal.intranet.repository.EmployeeHolidayRepository;
import com.histo.staffmanagementportal.intranet.repository.HolidayRepository;
import com.histo.staffmanagementportal.model.*;
import com.histo.staffmanagementportal.service.FloatingHolidayService;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class FloatingHolidayServiceImpl implements FloatingHolidayService {

    private static final Logger logger = LogManager.getLogger (FloatingHolidayServiceImpl.class);

    private static final String STATUS = "status";

    private final EmployeeHolidayRepository employeeHolidayRepo;

    private final HolidayRepository holidayRepository;


    private MappingJacksonValue mappingJacksonValue;

    private final ResponseModel response;

    public FloatingHolidayServiceImpl(EmployeeHolidayRepository employeeHolidayRepo, HolidayRepository holidayRepository, ResponseModel response) {
        this.employeeHolidayRepo = employeeHolidayRepo;
        this.holidayRepository = holidayRepository;
        this.response = response;
    }

    @Override
    public ResponseEntity<Object> getFloatingHoliday(FilterModel filterModel){

        try {

            List<FloatingHolidayDetails> employeeHoliday = SqlConnectionSetup.getJdbcConnection ().query ("exec spGetEmployeeFloatingHolidays ?,?,?;"
                    , BeanPropertyRowMapper.newInstance (FloatingHolidayDetails.class)
                    ,filterModel.getYear (), filterModel.getLocationId (), filterModel.getEmployeeId ());

            Map<Integer, List<FloatingHolidayDetails>> groupedByEmployee = employeeHoliday.stream()
                    .collect(Collectors.groupingBy(FloatingHolidayDetails::getEmployeeId));

            // Convert the grouped data into the desired format
            List<FloatingHolidayModel> floatingHolidayList = new ArrayList<> ();

            for (Map.Entry<Integer, List<FloatingHolidayDetails>> entry : groupedByEmployee.entrySet()) {

                FloatingHolidayModel floatingHolidayModel = new FloatingHolidayModel();
                floatingHolidayModel.setEmployeeId(entry.getKey());
                floatingHolidayModel.setEmployeeName(entry.getValue().get(0).getEmployeeName());

                List<List<FloatingHolidays>> holidays = entry.getValue().stream()
                        .map(holidayDetail -> {

                            List<FloatingHolidays> floatingHolidays = new ArrayList<> ();
                            FloatingHolidays floatingHoliday = new FloatingHolidays ();
                            FloatingHolidays alternateHoliday = new FloatingHolidays ();
                            floatingHoliday.setEmployeeHolidayId (holidayDetail.getEmployeeHolidayDetailId ()); // value from EmployeeHoliday table
                            floatingHoliday.setHolidayDetailId (holidayDetail.getHolidayDetailId ()); // value from holiday table
                            floatingHoliday.setHolidayName(holidayDetail.getHolidayName());
                            floatingHoliday.setIsUsed (holidayDetail.getIsAddedFloatingHoliday ());
                            floatingHoliday.setIsDisabled (holidayDetail.getIsdisabled ());

                            floatingHolidays.add (floatingHoliday);

                            if(holidayDetail.getAlternateHolidayDetailsID () != 0){
                                alternateHoliday.setEmployeeHolidayId (holidayDetail.getEmployeeHolidayDetailId ());
                                alternateHoliday.setHolidayDetailId (holidayDetail.getAlternateHolidayDetailsID ());
                                alternateHoliday.setHolidayName(holidayDetail.getAlternateHolidayName ());
                                alternateHoliday.setIsUsed (holidayDetail.getAlternateIsAddedFloatingHoliday ());
                                alternateHoliday.setIsDisabled (holidayDetail.getIsdisabled ());

                                floatingHolidays.add (alternateHoliday);
                            }

                            return floatingHolidays;
                        })
                        .toList ();

                floatingHolidayModel.setFloatingHolidays (holidays);
                floatingHolidayList.add(floatingHolidayModel);
            }

            Collections.sort(floatingHolidayList, Comparator.comparing(FloatingHolidayModel::getEmployeeName));
            response.setStatus (true);
            response.setData (floatingHolidayList);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("getHolidayDetails()", e, "Failed", "Unable to get holiday details");
        }
    }

    @Override
    public ResponseEntity<Object> addEmployeeFloatingHoliday(EmployeeHoliDayDTO employeeHoliDayDTO) {

        try{

            for (HolidayIdDetails holidayIdDetails : employeeHoliDayDTO.getHolidayIdDetailsList ()) {

                Optional<Holiday> holiday = holidayRepository.findByHolidayDetailIdAndRecordStatusAndIsOptional
                        (holidayIdDetails.holidayDetailId (),Constants.ACTIVE_RECORD_STATUS,Boolean.TRUE.toString ());

                if(holiday.isEmpty ()){
                    return catchException ("addEmployeeFloatingHoliday()", null, "Not Found", "Please select valid holiday details.<br> " +
                            "Given holiday details is not floating holiday or is not active ");

                }

                if(ObjectUtils.isEmpty (holidayIdDetails.employeeHolidayId ()) || holidayIdDetails.employeeHolidayId () == 0 ){

                    Integer yearByHolidayDetailId = holidayRepository.findYearByHolidayDetailId (holidayIdDetails.holidayDetailId ());
                    // add new reord in employee holiday table
                    EmployeeHoliDay employeeHoliDay = new EmployeeHoliDay ();
                    employeeHoliDay.setEmployeeId (employeeHoliDayDTO.getEmployeeId ());
                    employeeHoliDay.setHoliDayId (holiday.get ());
                    employeeHoliDay.setAddedBy (employeeHoliDayDTO.getModifiedByEmpId ());
                    employeeHoliDay.setAddedOn (InstantFormatter.InstantFormat (employeeHoliDayDTO.getModifiedOn ()));
                    employeeHoliDay.setYear (yearByHolidayDetailId);

                    EmployeeHoliDay employeeHoliDayDetails = employeeHolidayRepo.save (employeeHoliDay);
                    response.setMessage ("Employee floating Holiday details added successfully");
                }


                else if(holidayIdDetails.employeeHolidayId () != 0 ){

                    Optional<EmployeeHoliDay> employeeHolidayDetails = employeeHolidayRepo.findById (holidayIdDetails.employeeHolidayId ());
                    //update existing record in employee holiday table
                    if( employeeHolidayDetails.isEmpty ()){
                        return catchException ("addEmployeeFloatingHoliday()", null, "Not found", "Floating holiday details not found.");
                    }

                    employeeHolidayDetails.get ().setHoliDayId (holiday.get ());
                    employeeHolidayDetails.get ().setModifiedBy (employeeHoliDayDTO.getModifiedByEmpId ());
                    employeeHolidayDetails.get ().setAddedOn (InstantFormatter.InstantFormat (employeeHoliDayDTO.getModifiedOn ()));

                    EmployeeHoliDay employeeHoliDayDetails = employeeHolidayRepo.save (employeeHolidayDetails.get ());
                    response.setMessage ("Employee floating Holiday details updated successfully");

                }

            }

            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);

        }
        catch(Exception e) {
            return catchException("addEmployeeFloatingHoliday()",e,"Failed","Unable to add employee floating holiday details");
        }
    }


    @Override
    public ResponseEntity<Object> getFloatingHolidayList(Integer year) {
        try {
            List<HolidayRepository.FloatingHolidayList> floatingHolidayList = holidayRepository.findFloatingHolidayList (year);

            response.setStatus (true);
            response.setData (floatingHolidayList);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("getFloatingHolidayList()", e, "Failed", "Unable to get holiday details");
        }
    }

    @Override
    public ResponseEntity<Object> getEmployeeFloatingHoliday(FloatingHolidayFilter floatingHolidayFilter) {
        try{
            List<EmployeeFloatingHolidayList> floatingHolidayLists = SqlConnectionSetup.getJdbcConnection ().query ("exec spGetFloatingHolidayList ?,?,?;", BeanPropertyRowMapper.newInstance (EmployeeFloatingHolidayList.class),
                    floatingHolidayFilter.getYear (),
                    floatingHolidayFilter.getFloatingHolidayId (),
                    floatingHolidayFilter.getEmployeeId ());

            response.setStatus (true);
            response.setData (floatingHolidayLists);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        }
        catch (Exception e) {
            return catchException ("getEmployeeFloatingHoliday()", e, "Failed", "Unable to get holiday details");
        }
    }

    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
        logger.error ("{} Error : {}", methodName, e);
        response.setStatus (false);
        response.setInformation (new ExceptionBean (Instant.now (), message, description));
        mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"information", STATUS});
        return new ResponseEntity<> (mappingJacksonValue, HttpStatus.CONFLICT);
    }

}
