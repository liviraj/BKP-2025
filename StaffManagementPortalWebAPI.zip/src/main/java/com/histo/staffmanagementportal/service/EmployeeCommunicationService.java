package com.histo.staffmanagementportal.service;

import org.springframework.http.ResponseEntity;

import com.histo.staffmanagementportal.dto.EmployeeCommunicationDTO;

public interface EmployeeCommunicationService {

	public ResponseEntity<Object> getCommunicationByEmployeeId(Integer employeeId);
	public ResponseEntity<Object> saveCommunicationDetails(EmployeeCommunicationDTO communicationDto);
	public ResponseEntity<Object> updateCommunicationDetails(EmployeeCommunicationDTO communicationDto,Integer employeeId);
}
