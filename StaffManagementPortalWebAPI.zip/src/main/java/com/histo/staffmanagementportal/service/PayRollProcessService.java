package com.histo.staffmanagementportal.service;

import org.springframework.http.ResponseEntity;

public interface PayRollProcessService {

	ResponseEntity<Object> generatePayrollDates(Integer locationId);
}
