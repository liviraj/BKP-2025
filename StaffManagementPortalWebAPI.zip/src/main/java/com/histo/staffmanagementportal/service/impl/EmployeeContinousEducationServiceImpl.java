package com.histo.staffmanagementportal.service.impl;

import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.histo.staffmanagementportal.intranet.entity.Document;
import com.histo.staffmanagementportal.intranet.repository.DocumentRepository;
import com.histo.staffmanagementportal.model.StaffModuleName;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.dto.EmployeeContinousEducationDTO;
import com.histo.staffmanagementportal.dto.EmployeeContinousEducationViewDTO;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.intranet.repository.EmployeeContinousEducationRepository;
import com.histo.staffmanagementportal.model.Constants;
import com.histo.staffmanagementportal.model.ModifiedDetails;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.service.EmployeeContinousEducationService;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;

@Service
public class EmployeeContinousEducationServiceImpl implements EmployeeContinousEducationService {

	private static final Logger logger = LogManager.getLogger(EmployeeContinousEducationServiceImpl.class);

	private static final String STATUS = "status";
	
	@Autowired
    private ResponseModel response;

    private MappingJacksonValue mappingJacksonValue;
    private final EmployeeContinousEducationRepository continousEducationRepository;

	private final DocumentRepository documentRepository;

	public EmployeeContinousEducationServiceImpl(EmployeeContinousEducationRepository continousEducationRepository, DocumentRepository documentRepository) {
		this.continousEducationRepository = continousEducationRepository;
		this.documentRepository = documentRepository;
	}

	@Override
	public ResponseEntity<Object> getContinousEducationByEmployeeId(Integer employeeId) {
		try {
			List<EmployeeContinousEducationViewDTO> employeeContinousEducation = SqlConnectionSetup.getJdbcConnection().query("exec spGetContinousEducationByEmpId ?"
					, BeanPropertyRowMapper.newInstance(EmployeeContinousEducationViewDTO.class)
					,employeeId);

			response.setStatus(true);
			response.setData(employeeContinousEducation);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK); 
		}
		catch(Exception e) {
			return catchException("getContinousEducationByEmployeeId()", e, "Error", "Cannot fetch employee continuous education");
		}
	}

	@Override
	public ResponseEntity<Object> getContinousEducationById(Integer continousEducationId) {
		try {
			EmployeeContinousEducationDTO employeeContinousEducation = SqlConnectionSetup.getJdbcConnection()
					.queryForObject ("exec spGetEmployeeContinuousEducationById ?", BeanPropertyRowMapper.newInstance(EmployeeContinousEducationDTO.class),continousEducationId);
			if(ObjectUtils.isEmpty (employeeContinousEducation)){
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(), "Failed", "Employee continous education details not found"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"information",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT); 
			}

			List<Document> documentDetails = documentRepository.findByDocumentIdAndRecordStatusAndDocumentType (continousEducationId,
					Constants.ACTIVE_RECORD_STATUS,
					StaffModuleName.CONTINOUSEDUCATION.getValue ());

			employeeContinousEducation.setDocumentList (documentDetails);
			response.setStatus(true);
			response.setData(employeeContinousEducation);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK); 
		}
		catch(Exception e) {
			return catchException("getContinousEducationById()", e, "Error", "Cannot fetch employee continuous education");
		}
	}

	@Override
	public ResponseEntity<Object> addContinousEducation(EmployeeContinousEducationDTO continuousEducationDTO) {
		try {
			EmployeeContinousEducationDTO continousEducationDTO = SqlConnectionSetup.getJdbcConnection().queryForObject("exec EmployeeContinousEducationInsert ?,?,?,?,?,?,?,?,?,?,?;"
					, BeanPropertyRowMapper.newInstance(EmployeeContinousEducationDTO.class)
					, new Object[] {
							0,
							continuousEducationDTO.getEmployeeId(),
							continuousEducationDTO.getCourseName(),
							continuousEducationDTO.getConductedBy(),
							continuousEducationDTO.getSponsoredBy(),
							continuousEducationDTO.getCourseDuration(),
							continuousEducationDTO.getCourseDescription(),
							continuousEducationDTO.getCourseCategory(),
							continuousEducationDTO.getModifiedBy(),
							continuousEducationDTO.getEmployeeImage(),
							continuousEducationDTO.getEmployeeImageBinary()
					});

			if(ObjectUtils.isNotEmpty (continousEducationDTO)){
				for(Document documentDetails : continuousEducationDTO.getDocumentList ()){

					documentDetails.setDocumentId (continousEducationDTO.getContinuousEducationId ());
					documentDetails.setDocumentType (StaffModuleName.CONTINOUSEDUCATION.getValue ());
					documentDetails.setCreatedBy (continuousEducationDTO.getModifiedBy());

					Document savedDocumentDetails = documentRepository.save (documentDetails);
				}

			}
			response.setStatus(true);
			response.setData(continousEducationDTO);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}
		catch(Exception e) {
			return catchException("addContinousEducation()", e, "Error", "Cannot add employee continuous education");
		}
	}

	@Override
	public ResponseEntity<Object> updateContinousEducationById(EmployeeContinousEducationDTO continuousEducationDTO,
			Integer continuousEducationId) {
		try {
			List<EmployeeContinousEducationDTO> employeeContinousEducationById = SqlConnectionSetup.getJdbcConnection()
					.query("exec spGetEmployeeContinuousEducationById ?", BeanPropertyRowMapper.newInstance(EmployeeContinousEducationDTO.class),continuousEducationId);
			if(employeeContinousEducationById.isEmpty()) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(), "Failed", "Employee continous education details not found"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"information",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT); 
			}
			String employeeWorkStatus = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetEmploymentStatusByEmpId ?", String.class,continuousEducationDTO.getEmployeeId());
			if(ObjectUtils.equals(employeeWorkStatus, Constants.RELIEVED_STATUS)) {
				return catchException("updateContinousEducationById()", null, "Not a active employee", "Cannot update relieved employee details");
			}
			SqlConnectionSetup.getJdbcConnection().queryForObject("exec EmployeeContinousEducationUpdate ?,?,?,?,?,?,?,?,?,?,?,?;", String.class
					, new Object[] {
							continuousEducationId,
							continuousEducationDTO.getEmployeeId(),
							continuousEducationDTO.getCourseName(),
							continuousEducationDTO.getConductedBy(),
							continuousEducationDTO.getSponsoredBy(),
							continuousEducationDTO.getCourseDuration(),
							continuousEducationDTO.getCourseDescription(),
							continuousEducationDTO.getCourseCategory(),
							continuousEducationDTO.getModifiedBy(),
							continuousEducationDTO.getEmployeeImage(),
							continuousEducationDTO.getEmployeeImageBinary(),
							Constants.ACTIVE_RECORD_STATUS
					});

			continuousEducationDTO.getDocumentList ().stream ().forEach (document ->{
					if(document.getId () == null){
						document.setDocumentId (continuousEducationId);
						document.setDocumentType (StaffModuleName.CONTINOUSEDUCATION.getValue ());
						document.setCreatedBy (continuousEducationDTO.getModifiedBy ());
						Document savedDocumentDetails = documentRepository.save (document);
					}
					else{

						Optional<Document> existingDocumentDetails = documentRepository.findByIdAndRecordStatusAndDocumentType (
								document.getId (),
								Constants.ACTIVE_RECORD_STATUS,
								StaffModuleName.CONTINOUSEDUCATION.getValue ());

						existingDocumentDetails.get ().setRecordStatus (document.getRecordStatus ());
						existingDocumentDetails.get ().setModifiedBy (continuousEducationDTO.getModifiedBy ());
						documentRepository.save (existingDocumentDetails.get ());
					}
				});

			response.setStatus(true);
			response.setData("Updated employee continous education");
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}
		catch(Exception e) {
			return catchException("updateContinousEducationById()", e, "Error", "Cannot update employee continuous education");
		}
	}
	private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
		logger.error("{} Error : {}" + methodName, e);
		ExceptionBean exception = new ExceptionBean(Instant.now(), message, description);
		response.setStatus(false);
		response.setInformation(exception);
		mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information",STATUS});
		return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
	}

	@Override
	public ResponseEntity<Object> deleteEmployeeContinousEducationById(Integer continousEducationId,ModifiedDetails modifiedDetails) {
		try {
			int updateRecordStatusById = continousEducationRepository.updateRecordStatusById(Constants.DELETED_RECORD_STATUS,continousEducationId
					,modifiedDetails.modifiedBy(),InstantFormatter.InstantFormat(modifiedDetails.modifiedDate()));
			
			if(updateRecordStatusById <= 0){
				
				return catchException("deleteEmployeeContinousEducationById()", null,"Failed", "Employee continous education details not found");	
			}
			
			response.setStatus(true);
			response.setMessage("Continous education deleted successfully");
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"message",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK); 
		}
		catch(Exception e) {
			return catchException("deleteEmployeeContinousEducationById()", e, "Error", "Cannot delete employee continuous education");
		}
	}
}
