package com.histo.staffmanagementportal.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.dto.EmployeePersonalDetailView;
import com.histo.staffmanagementportal.dto.EmployeeViewDTO;
import com.histo.staffmanagementportal.dto.LoginDTO;
import com.histo.staffmanagementportal.dto.UserLoginViewDTO;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.helper.EmployeeCodeIncrementer;
import com.histo.staffmanagementportal.intranet.entity.Login;
import com.histo.staffmanagementportal.intranet.entity.Role;
import com.histo.staffmanagementportal.intranet.repository.LoginRepository;
import com.histo.staffmanagementportal.intranet.repository.RoleRepository;
import com.histo.staffmanagementportal.model.Constants;
import com.histo.staffmanagementportal.model.LoginDetails;
import com.histo.staffmanagementportal.model.LoginFilterModel;
import com.histo.staffmanagementportal.model.ModifiedDetails;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.model.RoleEnum;
import com.histo.staffmanagementportal.security.TokenService;
import com.histo.staffmanagementportal.service.UserService;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class UserserviceImpl implements UserService {

	private static final Logger logger = LogManager.getLogger(UserserviceImpl.class);
	private static final String STATUS = "status";

	private static final String OPTIONAL_TYPE = "Optional type";

	private final LoginRepository loginRepo;
	private final RoleRepository roleRepository;
	private final ResponseModel response;
	private final TokenService tokenService;
	private final HttpServletRequest request;
	

	MappingJacksonValue mappingJacksonValue;

	public UserserviceImpl(LoginRepository loginRepo
			, RoleRepository roleRepository
			, ResponseModel response
			, TokenService tokenService
			, HttpServletRequest request) {
		this.loginRepo = loginRepo;
		this.roleRepository = roleRepository;
		this.response = response;
		this.tokenService = tokenService;
		this.request = request;
	
	}

	@Override
	public ResponseEntity<Object> findAllLogins(LoginFilterModel loginFilter) {
		try {
			List<LoginDetails> loginDetails = SqlConnectionSetup.getJdbcConnection().query("exec spUserFilter ?,?,?,?,?,?",
					BeanPropertyRowMapper.newInstance(LoginDetails.class),
					loginFilter.getMappingStatus(),
					loginFilter.getRole(),
					loginFilter.getLocation(),
					loginFilter.getStatus(),
					loginFilter.getEmployeeId(),
					loginFilter.getLoginId());

			response.setStatus(true);
			response.setData(loginDetails);

			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { STATUS, "data" });

			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch (Exception e) {
			return catchException("findAllLogins()", e, "Failed", "No value present");
		}
	}

	@Override
	public ResponseEntity<Object> findByLoginId(Integer loginId) {
		try {
			List<LoginDTO> user = SqlConnectionSetup.getJdbcConnection().query("exec spGetLoginDetails ?", BeanPropertyRowMapper.newInstance(LoginDTO.class),loginId);
			if (ObjectUtils.isEmpty(user)) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(), "Data Not Found", "User not Found"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
			response.setStatus(true);
			response.setData(user.get(0));
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { STATUS, "data" });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

		} catch (Exception e) {
			return catchException("findByLoginId()", e, "Error", "Cannot fetch user details");
		}
	}

	private EmployeeViewDTO createLogin(LoginDTO loginDto) {
		EmployeeViewDTO employeeViewDTO = null;
		try {
			List<LoginDTO> user = SqlConnectionSetup.getJdbcConnection().query("exec spGetLoginDetails ?", BeanPropertyRowMapper.newInstance(LoginDTO.class),loginDto.getLoginId());
			if(user.isEmpty()) {
				employeeViewDTO = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spInsertLogin ?,?,?,?,?,?,?,?,?,?;", BeanPropertyRowMapper.newInstance(EmployeeViewDTO.class),
//						loginDto.getLoginId(),
						loginDto.getEmployeeId(),
						loginDto.getFirstName(),
						loginDto.getMiddleName(),
						loginDto.getLastName(),
						loginDto.getEmailId().toLowerCase(),
						loginDto.getRoleId(),
						loginDto.getLocationID(),
						loginDto.getEmployeeType(),
						loginDto.getModifiedBy(),
						loginDto.getCreatedBy());
			}
			
		} catch (Exception e) {
			catchException("createLogin()", e, "Failed", "User not created");
		}
		return employeeViewDTO;
	}
	private Boolean getEmploymentStatus(List<Login> loginDetails){
		boolean employeeActiveStatus = false;
		try {
			List<String> employmentStatus=new ArrayList<>();
			if (ObjectUtils.isNotEmpty(loginDetails)) {
				List<Login> login = loginDetails.stream().filter(loginValue -> loginValue.getEmployeeId()!=0).toList();
				for(Login loginDetail:login) {
					String employeeWorkStatus = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetEmploymentStatusByEmpId ?", String.class,loginDetail.getEmployeeId());
					 employmentStatus.add(ObjectUtils.isNotEmpty(employeeWorkStatus)? employeeWorkStatus:"");
				}
			}
			employeeActiveStatus = employmentStatus.stream().anyMatch(status -> !status.equalsIgnoreCase("Relieved"));
		}catch (Exception e) {
			 catchException("getEmploymentStatus()", e, "Error", "Cannot get employment status");
		}
		return employeeActiveStatus;
	}
	@Override
	public ResponseEntity<Object> createUser(LoginDTO loginDto,Boolean isNewUser) {
		try {
	
			if(Boolean.FALSE.equals(isNewUser)) {
			List<Login> loginDetails = SqlConnectionSetup.getJdbcConnection().query("exec spGetLoginByEmailAndLocationId ?,?"
					,BeanPropertyRowMapper.newInstance(Login.class),loginDto.getEmailId(),loginDto.getLocationID());
			List<Login> newLogin = loginDetails.stream().filter(loginValue -> loginValue.getEmployeeId()==0).toList();
			Boolean employmentStatus = getEmploymentStatus(loginDetails);
			
            if (!loginDetails.isEmpty()) {
			if (ObjectUtils.isNotEmpty(newLogin)) {
				response.setStatus(false);
				response.setInformation(
						new ExceptionBean(Instant.now(), "Error", "Unable to create login! EmailId already exist"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
			else if (ObjectUtils.isEmpty(newLogin) && Boolean.TRUE.equals(employmentStatus)) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(), "Error",
						"Unable to create login! Employee already exist"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			} else {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(), OPTIONAL_TYPE,
						"The login information provided is already exists but mapped to a relieved employee"
								+ ".Are you sure want to add new login?"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
            }
			}
			Role roleName = roleRepository.findById(loginDto.getRoleId()).orElseThrow();
			
			boolean isEmailValid = loginDto.getEmailId().split("@")[1].equalsIgnoreCase("histogenetics.com");
			 if(!isEmailValid) {
				  response.setStatus(false);
		           response.setInformation(new ExceptionBean(Instant.now(), "Invalid Email", "EmailId is not valid"));
		           mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
		           return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			 }
			 EmployeeViewDTO employeeViewDTO = createLogin(loginDto);
			if (ObjectUtils.isEmpty(employeeViewDTO)) {
	            response.setStatus(false);
	            response.setInformation(new ExceptionBean(Instant.now(), "Error", "User already exists"));
	            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
	            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
			
			String employeeCode = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spEmpCodeMaxCount ?,?", String.class,
					employeeViewDTO.getLocationId(), employeeViewDTO.getEmployeeType());
			employeeCode = EmployeeCodeIncrementer.increment(employeeCode);
		 
			employeeViewDTO.setEmployeeCode(employeeCode);
			employeeViewDTO.setRoleName(roleName.getRoleName());
			
	        response.setStatus(true);
	        response.setData(employeeViewDTO);
	        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{ STATUS,"data"});
	        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CREATED);
		} catch (Exception e) {
			return catchException("createUser()", e, "Failed", "Unable to create user");
		}
	}

	@Override
	public ResponseEntity<Object> updateUser(Integer loginId, LoginDTO loginDto) {
		try {
			List<LoginDTO> user = SqlConnectionSetup.getJdbcConnection().query("exec spGetLoginDetails ?", BeanPropertyRowMapper.newInstance(LoginDTO.class),loginId);

			if (user.isEmpty()) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(), "Error", "User not found"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
			List<LoginDTO> loginDetails =  SqlConnectionSetup.getJdbcConnection().query("exec spGetLoginByEmailAndLocationId ?,?"
					,BeanPropertyRowMapper.newInstance(LoginDTO.class),loginDto.getEmailId(),loginDto.getLocationID());
			Optional<LoginDTO> login = loginDetails.stream().filter(loginValue -> Objects.equals(loginValue.getLoginId(), (loginId))).findFirst();
			if (ObjectUtils.isNotEmpty(loginDetails) && login.isEmpty()) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(), "Error", "EmailId already exist"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
			boolean isEmailValid = loginDto.getEmailId().split("@")[1].equalsIgnoreCase("histogenetics.com");
			 if(!isEmailValid) {
				  response.setStatus(false);
		          response.setInformation(new ExceptionBean(Instant.now(), "Invalid Email", "EmailId is not valid"));
		          mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
		          return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			 }
			 String employeeWorkStatus = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetEmploymentStatusByEmpId ?", String.class,loginDto.getEmployeeId());
			if(ObjectUtils.equals(employeeWorkStatus, Constants.RELIEVED_STATUS)) {
					return catchException("updateUser()", null, "Not a active employee", "Cannot update relieved employee details");
			}
			
			 SqlConnectionSetup.getJdbcConnection().queryForObject("exec spUpdateLogin ?,?,?,?,?,?,?,?,?,?,?;", String.class, loginDto.getEmployeeId(),
					loginDto.getFirstName(),
					loginDto.getMiddleName(),
					loginDto.getLastName(),
					loginId,
					loginDto.getEmailId().toLowerCase(),
					loginDto.getRoleId(),
					loginDto.getLocationID(),
					loginDto.getEmployeeType(),
					loginDto.getModifiedBy(),
					Constants.ACTIVE_RECORD_STATUS);
			
			response.setData("User credentials updated");
			response.setStatus(true);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

		} catch (Exception e) {
			return catchException("updateUser()", e, "Failed", "Unable to update user");
		}
	}

	@Override
	public ResponseEntity<Object> loginUser() {
		try {
			final String authToken = request.getHeader("Authorization");
			if (StringUtils.isBlank(authToken)) {
				response.setStatus(false);
				response.setInformation(
						new ExceptionBean(Instant.now(), "Unauthorized", "Authorization token not present"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.UNAUTHORIZED);
			}
			String emailId = tokenService.getEmailByToken(authToken.replace("Bearer", ""));

			List<EmployeePersonalDetailView> employee = SqlConnectionSetup.getJdbcConnection().query("exec sp_EmployeeSelect ?", 
					BeanPropertyRowMapper.newInstance(EmployeePersonalDetailView.class),
					emailId);

			if (ObjectUtils.isEmpty(employee)) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(), "Unauthorized", "Employee not found"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.UNAUTHORIZED);
			}
			
			Optional<EmployeePersonalDetailView> employeeDetail = employee.stream().filter(value -> !value.getEmploymentstatus().equalsIgnoreCase("Relieved") ).findFirst();
			
			if (employeeDetail.isPresent() && employeeDetail.get().getEmploymentstatus().equalsIgnoreCase("Relieved")) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(), "Unauthorized",
						"Employee is relieved and login is no more valid."));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.UNAUTHORIZED);
			}
            Integer locationId = loginRepo.findLocationIdByEmployeeId(employeeDetail.get().getEmployeeId());
			UserLoginViewDTO loginView = new UserLoginViewDTO();
			List<String> roleName = SqlConnectionSetup.getJdbcConnection().queryForList("exec GetEmployeeId ?;"
        			,String.class, new Object[] {emailId.toLowerCase()});
			String ifEmployeeServiceRequestApprover = SqlConnectionSetup.getJdbcConnection ().queryForObject ("exec spGetIfEmpServiceRequestApprover ?;"
					, String.class, new Object[]{employeeDetail.get ().getEmployeeId ()});
			if (ObjectUtils.isNotEmpty(roleName)) {
				if(roleName.contains(RoleEnum.ADMINISTRATOR.getValue())) {
                    loginView.setRoleName(RoleEnum.ADMINISTRATOR.getValue());
				}
                else if(roleName.contains(RoleEnum.HUMAN_RESOURCE.getValue())) {
                    loginView.setRoleName(RoleEnum.HUMAN_RESOURCE.getValue());
                }
                else if(roleName.contains(RoleEnum.SECTION_SUPERVISOR.getValue())) {
                    loginView.setRoleName(RoleEnum.SECTION_SUPERVISOR.getValue());
                }
                else {
                    loginView.setRoleName(RoleEnum.EMPLOYEE.getValue());
                }
			}
			loginView.setEmployeeCode(employeeDetail.get().getEmployeeCode());
			loginView.setFirstName(employeeDetail.get().getFirstName());
			loginView.setLastName(employeeDetail.get().getLastName());
			loginView.setMiddleName(employeeDetail.get().getMiddleName());
			loginView.setImageName(employeeDetail.get().getImage() == null ? "" : employeeDetail.get().getImage());
			loginView.setImageBinary(
					employeeDetail.get().getPhotoImageBinary() == null ? new byte[0] : employeeDetail.get().getPhotoImageBinary());
			loginView.setEmployeeId(employeeDetail.get().getEmployeeId());
			loginView.setLocationId(locationId);
			loginView.setApprover (ifEmployeeServiceRequestApprover);

			response.setStatus(true);
			response.setData(loginView);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch (Exception e) {
			return catchException("loginUser()", e, "Failed", "Employee not found");
		}

	}

	@Override
	public ResponseEntity<Object> deleteByLoginId(Integer loginId,ModifiedDetails modifiedDetails) {
		try {
			int updateRecordStatusByLoginId = loginRepo.updateRecordStatusByLoginId(Constants.DELETED_RECORD_STATUS,loginId, modifiedDetails.modifiedBy()
					, InstantFormatter.InstantFormat(modifiedDetails.modifiedDate()));
			
			if (updateRecordStatusByLoginId <= 0) {
				
				return catchException("deleteByLoginId()",null, "Data Not Found", "User not Found");
			
			}
			
			response.setStatus(true);
			response.setMessage("Login details deleted successfully");
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { STATUS, "message" });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

		} catch (Exception e) {
			return catchException("deleteByLoginId()", e, "Error", "Cannot fetch user details");
		}
	}
	
	private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
		logger.error("{} Error : {}" , methodName, e);
		response.setStatus(false);
		response.setInformation(new ExceptionBean(Instant.now(), message, description));
		mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
		return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);

	}

}
