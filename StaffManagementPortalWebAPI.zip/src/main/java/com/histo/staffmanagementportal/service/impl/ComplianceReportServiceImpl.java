package com.histo.staffmanagementportal.service.impl;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import com.histo.staffmanagementportal.intranet.entity.Attribute;
import com.histo.staffmanagementportal.intranet.repository.AttributeRepository;
import com.histo.staffmanagementportal.model.*;
import com.histo.staffmanagementportal.service.EmailService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.service.ComplianceReportService;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.springframework.util.ObjectUtils;

@Service
public class ComplianceReportServiceImpl implements ComplianceReportService {

	private static final Logger logger = LogManager.getLogger(ComplianceReportServiceImpl.class);

	private static final String STATUS = "status";

	private final ResponseModel response;

	private MappingJacksonValue mappingJacksonValue;

	private final EmailService emailService;
	private final AttributeRepository attributeRepository;

	public ComplianceReportServiceImpl(ResponseModel response, EmailService emailService, AttributeRepository attributeRepository) {
		this.response = response;
		this.emailService = emailService;
		this.attributeRepository = attributeRepository;
	}

	@Override
	public ResponseEntity<Object> getComplianceReport(ComplianceReportFilter reportFilter) {
		try {

			List<Object> complianceReport = SqlConnectionSetup.getJdbcConnection().query("exec GetEmployeeComplianceDetails ?,?,?,?,?,?;",
					new ResultSetMapper()
					, reportFilter.getFilter(),
					reportFilter.getYear(),
					reportFilter.getEmployeeId(),
					reportFilter.getDesignationId(),
					reportFilter.getDoj(),
					reportFilter.getSupervisorEmpId());

			response.setStatus(true);
			response.setData(complianceReport);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

		} catch (Exception e) {
			return catchException("getComplianceReport()", e, "Error", "Cannot fetch compliance report");
		}
	}

	@Override
	public ResponseEntity<Object> getEmployeeType() {
		try {
			List<String> employeeType = Arrays.asList("All Technologist", "Clinical Lab Technologist", "All Employees");
			response.setStatus(true);
			response.setData(employeeType);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch (Exception e) {
			return catchException("getEmployeeType()", e, "Failed", "Unable to get employee type");
		}
	}

	@Override
	public ResponseEntity<Object> getComplianceDocument(ComplianceCertificateInfo complianceDocument) {
		try {
			List<ImageViewModel> complianceCertificate = SqlConnectionSetup.getJdbcConnection().query("exec spGetComplianceDocument ?,?,?,?;"
					, BeanPropertyRowMapper.newInstance(ImageViewModel.class)
					, complianceDocument.getEmployeeId(), complianceDocument.getComplianceCategory(),
					complianceDocument.getExpiryDate(),
					complianceDocument.getIsNoExpiry ());
			response.setStatus(true);
			response.setData(complianceCertificate);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus .OK);
		} catch (Exception e) {
			return catchException("getComplianceDocument()", e, "Failed", "Certificate not found");
		}
	}

	@Override
	public ResponseEntity<Object> complianceExpiryEmailNotification(ComplianceReportFilter reportFilter) {
		try {

			String employeeID = reportFilter.getEmpId ().stream ()
					.map (String::valueOf)
					.collect (Collectors.joining (","));

			List<ComplianceEmailModel> complianceCertificate = SqlConnectionSetup.getJdbcConnection().query("exec GetEmployeeComplianceDetailsForExpiryEmail ?,?;"
					, BeanPropertyRowMapper.newInstance(ComplianceEmailModel.class)
					, employeeID
					,reportFilter.getYear ());

			if(ObjectUtils.isEmpty (complianceCertificate)){
				return catchException("complianceExpiryEmailNotification()", null, "Failed", "No document is expired for given year.");
			}

			ResponseEntity<Object> responseEntity = emailService.sendComplianceExpiryEmail (complianceCertificate);


			response.setStatus(true);
			response.setMessage ("Compliance Email notification send successfully.");

			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "message", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus .OK);
		} catch (Exception e) {
			return catchException("complianceExpiryEmailNotification()", e, "Failed", "Compliance expiry details not found.");
		}
	}

	@Override
	public ResponseEntity<Object> complianceExpiryEmailTemplate(ComplianceReportFilter reportFilter) {
		try {

			String employeeID = reportFilter.getEmployeeId ().replace ('~',',');

			List<ComplianceEmailModel> complianceEmailModels = SqlConnectionSetup.getJdbcConnection().query("exec GetEmployeeComplianceDetailsForExpiryEmail ?,?;"
					, BeanPropertyRowMapper.newInstance(ComplianceEmailModel.class)
					, employeeID
					,reportFilter.getYear ());

			if(ObjectUtils.isEmpty (complianceEmailModels)){
				return catchException("complianceExpiryEmailTemplate()", null, "Failed", "No document is expired for given year.");
			}


			Optional<Attribute> ccEmailDetails = attributeRepository.findByAttributeNameAndCategory
					(AttributeEnum.US_HR.getValue (), StaffModuleName.LEAVEMANAGEMENT.getValue ());

			Map<Integer, EmployeeResponseForComplianceExpiry> employeeMap = new HashMap<> ();

			for (ComplianceEmailModel model : complianceEmailModels) {
				EmployeeResponseForComplianceExpiry employee = employeeMap.computeIfAbsent(model.getEmployeeID(), id -> {
					EmployeeResponseForComplianceExpiry newEmployee = new EmployeeResponseForComplianceExpiry();
					newEmployee.setEmployeeID(model.getEmployeeID());
					newEmployee.setEmployeeName(model.getEmployeeName());
					newEmployee.setEmailId(model.getEmailId());
					newEmployee.setCcEmailId (ccEmailDetails.get ().getAttributeValue ());
					newEmployee.setSubject (Constants.COMPLIANCE_EXPIRY_EMAIL_SUBJECT);
					newEmployee.setData(new ArrayList<>());

					return newEmployee;
				});

				// Add compliance data
				EmployeeResponseForComplianceExpiry.ComplianceData complianceData = new EmployeeResponseForComplianceExpiry.ComplianceData();
				complianceData.setCompliance(model.getCompliance());
				complianceData.setCompliancePeriod(model.getCompliancePeriod());
				complianceData.setDisplayName(model.getDisplayName());
				complianceData.setExpirydate(model.getExpirydate());
				employee.getData().add(complianceData);
			}


			response.setStatus(true);
			response.setData (new ArrayList<>(employeeMap.values()));

			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus .OK);
		} catch (Exception e) {
			return catchException("complianceExpiryEmailTemplate()", e, "Failed", "Compliance expiry details not found.");
		}
	}

	private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
		logger.error("{} Error : {}" , methodName, e);
		ExceptionBean exception = new ExceptionBean(Instant.now(), message, description);
		response.setStatus(false);
		response.setInformation(exception);
		mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
		return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
	}

}
