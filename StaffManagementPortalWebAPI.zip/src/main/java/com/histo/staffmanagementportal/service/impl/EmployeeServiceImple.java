package com.histo.staffmanagementportal.service.impl;

import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.List;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.dto.EmployeeDTO;
import com.histo.staffmanagementportal.dto.EmployeePersonalDetailView;
import com.histo.staffmanagementportal.dto.EmployeeViewDTO;
import com.histo.staffmanagementportal.dto.LoginDTO;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.helper.DateValidation;
import com.histo.staffmanagementportal.helper.EmployeeCodeIncrementer;
import com.histo.staffmanagementportal.intranet.entity.Role;
import com.histo.staffmanagementportal.intranet.repository.EmployeeTypeRepository;
import com.histo.staffmanagementportal.intranet.repository.RoleRepository;
import com.histo.staffmanagementportal.model.Constants;
import com.histo.staffmanagementportal.model.EmployeeDetailsList;
import com.histo.staffmanagementportal.model.EmployeeSearchModel;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.service.EmployeeService;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;

@Service
public class EmployeeServiceImple implements EmployeeService {

	private static final Logger logger = LogManager.getLogger(EmployeeServiceImple.class);
	private static final String STATUS = "status";

	private final EmployeeTypeRepository employeeTypeRepository;
	private final RoleRepository roleRepository;
	
	public EmployeeServiceImple(EmployeeTypeRepository employeeTypeRepository, RoleRepository roleRepository) {
		super();
		this.employeeTypeRepository = employeeTypeRepository;
		this.roleRepository = roleRepository;
	}

	@Autowired
    private ResponseModel response;
 
    private MappingJacksonValue mappingJacksonValue;

	@Override
	public ResponseEntity<Object> getEmployeeById(Integer employeeId) {
		try {
			EmployeeDTO employeeDetailsView = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetEmployeeByEmployeeId ?",
					BeanPropertyRowMapper.newInstance(EmployeeDTO.class),
					employeeId);
			response.setStatus(true);
	        response.setData(employeeDetailsView);
	        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
	        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch (Exception e) {
			return catchException("getEmployeeById()", e, "Failed", "Employee not found");
		}
	}

	@Override
	public ResponseEntity<Object> saveEmployee(EmployeeDTO employee, Integer loginId) {
		try {
			LoginDTO loginDetails = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetLoginDetails ?", BeanPropertyRowMapper.newInstance(LoginDTO.class),loginId);
			String employeeId = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetEmpIdByEmployeeCode ?",String.class,employee.getEmployeeCode());
			if (ObjectUtils.isNotEmpty(employeeId)) {
				response.setStatus(false);
		        response.setInformation(new ExceptionBean(Instant.now(), "Error", "Employee already exist"));
		        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
		        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
			else if(loginDetails == null || ObjectUtils.isEmpty (loginDetails)){
				return catchException("saveEmployee()", null, "Error", "Login details not found.");
			}
			else if (!InstantFormatter.InstantFormat(employee.getDob()).isBefore(ZonedDateTime.now().minusYears(18).toInstant())) {
				response.setStatus(false);
			    response.setInformation(new ExceptionBean(Instant.now(),"Invalid Dob","Date of birth should not be lesser than 18"));
		        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
	         else if (InstantFormatter.InstantFormat(employee.getExpiryDate())!=null 
	        		 && InstantFormatter.InstantFormat(employee.getIssueDate()) !=null 
	        		 && InstantFormatter.InstantFormat(employee.getExpiryDate()).isBefore(InstantFormatter.InstantFormat(employee.getIssueDate()))) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(),"Invalid Date","Expiry date should not be lesser than issue date"));
			    mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
	        	return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
				
			EmployeePersonalDetailView employeeDetail = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spEmployeePersonalInsert ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?;"
						,BeanPropertyRowMapper.newInstance(EmployeePersonalDetailView.class)
						, 0,
					employee.getFirstName(),
					employee.getMiddleName(),
					employee.getLastName(),
					employee.getGenderCharValue(employee.getGender()),
					employee.getPanSsnDlValue(employee.getPanSsn()),
					employee.getPanSsnNumber(),
				    employee.getDob(),
					employee.getFatherName(),
					employee.getMotherName(),
					employee.getMaritalStatus(),
					employee.getSpouseName(),
					employee.getChildNos(),
					employee.getSiblingsNo(),
					employee.getCreatedBy(),
					employee.getImage(),
					employee.getNationality(),
					employee.getPassportNo(),
					employee.getIssuePlace(),
					employee.getIssueDate(),
					employee.getExpiryDate(),
					employee.getIdProofImg(),
					employee.getEmployeeCode(),
					employee.getPassportImage(),
					employee.getPhotoImageBinary(),
					employee.getIdProofImageBinary(),
					employee.getPassportImageBinary());

		if(employeeDetail != null && ObjectUtils.isNotEmpty(employeeDetail))
			{	
			SqlConnectionSetup.getJdbcConnection().queryForObject("exec spUpdateLogin ?,?,?,?,?,?,?,?,?,?,?;", String.class, employeeDetail.getEmployeeId(),
						loginDetails.getFirstName(),
						loginDetails.getMiddleName(),
						loginDetails.getLastName(),
						loginId,
						loginDetails.getEmailId(),
						loginDetails.getRoleId(),
						loginDetails.getLocationID(),
						loginDetails.getEmployeeType(),
						employee.getCreatedBy(),
						Constants.ACTIVE_RECORD_STATUS);
		}

				response.setStatus(true);
				response.setData(employeeDetail);
		        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
		        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
			
		} catch (Exception e) {
			return catchException("saveEmployee()", e, "Error", "Employee details is not created");
		}
	}

	@Override
	public ResponseEntity<Object> updateEmployee(EmployeeDTO employee, Integer employeeId) {
		try {
			List<EmployeeDTO> employeeDTO = SqlConnectionSetup.getJdbcConnection().query("exec spGetEmployeeByEmployeeId ?", BeanPropertyRowMapper.newInstance(EmployeeDTO.class), employeeId);
			if (ObjectUtils.isEmpty(employeeDTO)) {
				response.setStatus(false);
		        response.setInformation(new ExceptionBean(Instant.now(), "Error", "Employee not found"));
		        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
		        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);

			}
			else if (!InstantFormatter.InstantFormat(employee.getDob()).isBefore(ZonedDateTime.now().minusYears(18).toInstant())) {
				response.setStatus(false);
			    response.setInformation(new ExceptionBean(Instant.now(),"Invalid Dob","Date of birth should not be lesser than 18"));
		        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
	         else if (DateValidation.validateDate(employee.getIssueDate(),employee.getExpiryDate())) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(),"Invalid Date","Expiry date should not be lesser than issue date"));
			    mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
	        	return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
			
			String employeeWorkStatus = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetEmploymentStatusByEmpId ?", String.class,employeeId);
			if(ObjectUtils.equals(employeeWorkStatus, Constants.RELIEVED_STATUS)) {
				return catchException("updateEmployee()", null, "Not a active employee", "Cannot update relieved employee details");
			}
			EmployeePersonalDetailView employeeDetail = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spUpdateEmployeePersonal ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?;"
					,BeanPropertyRowMapper.newInstance(EmployeePersonalDetailView.class)
					, employeeId,
					employee.getFirstName(),
					employee.getMiddleName(),
					employee.getLastName(),
					employee.getGenderCharValue(employee.getGender()),
					employee.getPanSsnDlValue(employee.getPanSsn()),
					employee.getPanSsnNumber(),
					employee.getDob(),
					employee.getFatherName(),
					employee.getMotherName(),
					employee.getMaritalStatus(),
					employee.getSpouseName(),
					employee.getChildNos(),
					employee.getSiblingsNo(),
					employee.getModifiedBy(),
					employee.getImage(),
					employee.getNationality(),
					employee.getPassportNo(),
					employee.getIssuePlace(),
					employee.getIssueDate(),
					employee.getExpiryDate(),
					employee.getIdProofImg(),
					employee.getEmployeeCode(),
					employee.getPassportImage(),
					employee.getPhotoImageBinary(),
					employee.getIdProofImageBinary(),
					employee.getPassportImageBinary());
			
			response.setStatus(true);
			response.setData(employeeDetail);
	        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
	        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
			
		} catch (Exception e) {
			return catchException("updateEmployee()", e, "Error", "Failed to update employee detail");
		}
	}

	@Override
	public ResponseEntity<Object> getEmployeeByFilter(EmployeeSearchModel employeeSearchModel) {
		try {
			List<EmployeeDetailsList> employeeList = SqlConnectionSetup.getJdbcConnection().query("exec spSearchEmployee_temp ?,?,?,?,?,?",
					BeanPropertyRowMapper.newInstance(EmployeeDetailsList.class),
					employeeSearchModel.getDepartmentId()==null || employeeSearchModel.getDepartmentId().equals("0") ? ""
							: employeeSearchModel.getDepartmentId(),
					employeeSearchModel.getDesignationId()==null || employeeSearchModel.getDesignationId().equals("0") ? ""
							: employeeSearchModel.getDesignationId(),
					employeeSearchModel.getEmployeeId()==null || employeeSearchModel.getEmployeeId().equals("0") ? ""
							: employeeSearchModel.getEmployeeId(),
					employeeSearchModel.getLocationId()==null || employeeSearchModel.getLocationId().equals("0") ? ""
							: employeeSearchModel.getLocationId(),
					employeeSearchModel.getEmployeeType(),
					employeeSearchModel.getEmployeeStatus()==null || employeeSearchModel.getEmployeeStatus().equalsIgnoreCase("All")? ""
							: employeeSearchModel.getEmployeeStatus());
			if (employeeSearchModel.getClinicalHandler() != null) {
				if (employeeSearchModel.getClinicalHandler().equalsIgnoreCase("yes")) {

					employeeList = employeeList.stream()
							.filter(employee -> employee.getClinicalHandler() != null && employee.getClinicalHandler())
							.toList();
				} else if (employeeSearchModel.getClinicalHandler().equalsIgnoreCase("no")) {
					employeeList = employeeList.stream()
							.filter(employee -> employee.getClinicalHandler() != null && !employee.getClinicalHandler())
							.toList();
				}
			}

			response.setStatus(true);
	        response.setData(employeeList);
	        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
	        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch (Exception e) {
			return catchException("getEmployeeByFilter()", e, "Error", "Employee details not found");
		}
	}

	@Override
	public ResponseEntity<Object> getEmployeeNameFromLogin(Integer loginId) {
		try {
			List<LoginDTO> loginDetails = SqlConnectionSetup.getJdbcConnection().query("exec spGetLoginDetails ?", BeanPropertyRowMapper.newInstance(LoginDTO.class),loginId);
			if (loginDetails.isEmpty()) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(),"Failed","User not found"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
			Role roleName = roleRepository.findById(loginDetails.get(0).getRoleId()).orElseThrow();
			Integer employeeTypeValue = employeeTypeRepository
					.findByEmployeeTypeValue(ObjectUtils.isNotEmpty(loginDetails.get(0).getEmployeeType())?loginDetails.get(0).getEmployeeType():"E");
			String employeeCode = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spEmpCodeMaxCount ?,?", String.class,
					loginDetails.get(0).getLocationID(), loginDetails.get(0).getEmployeeType());
			employeeCode = EmployeeCodeIncrementer.increment(employeeCode);
			
			EmployeeViewDTO employeeViewDTO = new EmployeeViewDTO();
			employeeViewDTO.setFirstName(loginDetails.get(0).getFirstName());
			employeeViewDTO.setMiddleName(loginDetails.get(0).getMiddleName());
			employeeViewDTO.setLastName(loginDetails.get(0).getLastName());
			employeeViewDTO.setEmployeeCode(employeeCode);
			employeeViewDTO.setLocationId(loginDetails.get(0).getLocationID());
			employeeViewDTO.setLoginId(loginId);
			employeeViewDTO.setEmployeeType(
					ObjectUtils.isNotEmpty(loginDetails.get(0).getEmployeeType())?loginDetails.get(0).getEmployeeType():"E");
			employeeViewDTO.setEmploymentType(employeeTypeValue);
			employeeViewDTO.setRoleName(roleName.getRoleName());
			
			response.setStatus(true);
			response.setData(employeeViewDTO);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch (Exception e) {
			return catchException("getEmployeeNameFromLogin()", e, "Error", "cannot fetch employee details");
		}
	}

	  private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
	    	 logger.error("{} Error : {}" + methodName, e);
	        response.setStatus(false);
	        response.setInformation(new ExceptionBean(Instant.now(), message, description));
	        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
	        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);

	    }
}
