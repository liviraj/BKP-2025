package com.histo.staffmanagementportal.service.impl;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import com.histo.indiapayroll.model.WorkRequestHistoryForEmail;
import com.histo.permissionrequest.model.PermisisonHistory;
import com.histo.permissionrequest.model.PermissionEmailDetails;

import com.histo.permissionrequest.model.WorkRequestEmailDetails;
import com.histo.staffmanagementportal.model.*;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.histo.configuration.PropertyConfig;
import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.dto.EmployeeLeaveRequestDTO;
import com.histo.staffmanagementportal.dto.EmployeeViewDTO;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.intranet.entity.Attribute;
import com.histo.staffmanagementportal.intranet.entity.EmployeeLeaveDetails;
import com.histo.staffmanagementportal.intranet.entity.EmployeeLeaveRequestMaster;
import com.histo.staffmanagementportal.intranet.repository.AttributeRepository;
import com.histo.staffmanagementportal.intranet.repository.EmployeeLeaveDetailsRepository;
import com.histo.staffmanagementportal.intranet.repository.EmployeeLeaveRequestMasterRepository;
import com.histo.staffmanagementportal.intranet.repository.LeaveTypeMasterRepository;
import com.histo.staffmanagementportal.intranet.repository.LoginRepository;
import com.histo.staffmanagementportal.service.EmailService;
import com.histo.staffmanagementportal.service.EmployeeLeaveRequestService;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;

@Service
@Async
public class EmailServiceImpl implements EmailService {

	private static final Logger logger = LogManager.getLogger(EmailServiceImpl.class);

	private static final String STATUS = "status";

	private final ResponseModel response;

	private MappingJacksonValue mappingJacksonValue;

	private final TemplateEngine templateEngine;

	private final AttributeRepository attributeRepository;

	private final LeaveTypeMasterRepository leaveTypeRepository;

	private final EmployeeLeaveRequestMasterRepository leaveRequestMasterRepo;

	private final EmployeeLeaveDetailsRepository leaveDetailsRepository;

	private final EmployeeLeaveRequestService employeeLeaveRequestService;

	private final LoginRepository loginRepo;

	private final RestTemplate restTemplate;

	private final PropertyConfig propertyConfig;

	public EmailServiceImpl(ResponseModel response, TemplateEngine templateEngine,
							AttributeRepository attributeRepository, LeaveTypeMasterRepository leaveTypeRepository,
							EmployeeLeaveRequestMasterRepository leaveRequestMasterRepo,
							EmployeeLeaveDetailsRepository leaveDetailsRepository, LoginRepository loginRepo,
							PropertyConfig propertyConfig, EmployeeLeaveRequestService employeeLeaveRequestService) {
		this.response = response;
		this.templateEngine = templateEngine;
		this.attributeRepository = attributeRepository;
		this.leaveTypeRepository = leaveTypeRepository;
		this.leaveRequestMasterRepo = leaveRequestMasterRepo;
		this.leaveDetailsRepository = leaveDetailsRepository;
		this.employeeLeaveRequestService = employeeLeaveRequestService;
		this.loginRepo = loginRepo;
		this.restTemplate = new RestTemplate();
		this.propertyConfig = propertyConfig;
	}

	@Override
	public ResponseEntity<Object> sendEmail(LeaveRequestDetails leaveRequestDetails) {
		try {

			Optional<EmployeeLeaveRequestMaster> employeeLeaveRequest = leaveRequestMasterRepo
					.findById(leaveRequestDetails.getRequestId());

			List<EmployeeLeaveDetails> leaveDetails = leaveDetailsRepository
					.findByIdIn(leaveRequestDetails.getLeaveRequestDetailId());

			if(employeeLeaveRequest.isEmpty () || ObjectUtils.isEmpty (leaveDetails)){
				return catchException("sendEmail()", null, "Failed", "Email not sent. Employee leave request details mot found.");
			}

			String emailSubject = "Leave %s for %s - %s";

			double noOfDaysApplied = leaveDetails.size();

			for (EmployeeLeaveDetails details : leaveDetails) {
				if (employeeLeaveRequest.get().getLeaveFromForH().equalsIgnoreCase("H")
						&& details.getLeaveDate().equals(employeeLeaveRequest.get().getLeaveFrom())) {
					noOfDaysApplied = noOfDaysApplied - 0.5;
				} else if (employeeLeaveRequest.get().getLeaveToForH().equalsIgnoreCase("H")
						&& details.getLeaveDate().equals(employeeLeaveRequest.get().getLeaveTo())) {
					noOfDaysApplied = noOfDaysApplied - 0.5;
				}
			}

			Integer locationId = loginRepo.findLocationIdByEmployeeId(employeeLeaveRequest.get().getEmployeeId());

			String sql = locationId.equals(LocationEum.INDIA.getValue()) ? "exec GetIndiaEmployeeApproverMails ?"
					: "exec GetUSEmployeeLeaveApprovers ?";

			String fromDate = locationId.equals(LocationEum.INDIA.getValue()) ? InstantFormatter.indiaDateFormat (employeeLeaveRequest.get().getLeaveFrom())
					: InstantFormatter.dateFormat(employeeLeaveRequest.get().getLeaveFrom());

			String toDate = locationId.equals(LocationEum.INDIA.getValue()) ? InstantFormatter.indiaDateFormat (employeeLeaveRequest.get().getLeaveTo ())
					: InstantFormatter.dateFormat(employeeLeaveRequest.get().getLeaveTo());

			String leaveTypeName = leaveTypeRepository
					.findLeaveTypeNameByLeaveTypeId(employeeLeaveRequest.get().getTypeofLeave().getLeaveTypeId());

			List<EmailContent> emailContent = SqlConnectionSetup.getJdbcConnection().query(
					"exec GetDojAndDepartment ?;", BeanPropertyRowMapper.newInstance(EmailContent.class),
					employeeLeaveRequest.get().getEmployeeId());

			List<ApproverDetails> approverDetails = SqlConnectionSetup.getJdbcConnection().query(sql,
					BeanPropertyRowMapper.newInstance(ApproverDetails.class),
					employeeLeaveRequest.get().getEmployeeId());

			String reviewerName = SqlConnectionSetup.getJdbcConnection().queryForObject("EXEC spGetEmployeeNameById ?;",
					String.class, leaveRequestDetails.getApprovedBy());

			String subject =  String.format (emailSubject,LeaveStatusEnum.getEnumValueFromString (leaveRequestDetails.getStatus())
					, emailContent.get(0).getEmployeeName() , leaveTypeName);

			EmailLeaveRequestDetail emailLeaveRequestDetail = new EmailLeaveRequestDetail();

			emailLeaveRequestDetail.setSection(emailContent.get(0).getDepartment());
			emailLeaveRequestDetail.setDayOfJoining(emailContent.get(0).getDoj());
			emailLeaveRequestDetail.setLeaveFrom(fromDate + " to " + toDate);
			emailLeaveRequestDetail.setLeaveType(leaveTypeName);
			emailLeaveRequestDetail.setPurpose(employeeLeaveRequest.get().getRemarks());
			emailLeaveRequestDetail.setRemarks(leaveRequestDetails.getApproverComments());
			emailLeaveRequestDetail.setNoOfDaysApproved(
					leaveRequestDetails.getStatus().equalsIgnoreCase(Constants.APPROVED_STATUS) ? noOfDaysApplied : 0);
			emailLeaveRequestDetail.setNoOfDaysRejected(
					leaveRequestDetails.getStatus().equalsIgnoreCase(Constants.REJECTED_STATUS) ? noOfDaysApplied : 0);
			emailLeaveRequestDetail.setNoOfDaysCancelled(
					leaveRequestDetails.getStatus().equalsIgnoreCase(Constants.CANCELLED_STATUS) ? noOfDaysApplied : 0);
			emailLeaveRequestDetail.setVacationLeaveBalance(emailContent.get(0).getVacationLeaveBalance());
			emailLeaveRequestDetail.setSickLeaveBalance(emailContent.get(0).getSickLeaveBalance());
			emailLeaveRequestDetail.setCasualLeaveBalance(emailContent.get(0).getCasualLeaveBalance());
			emailLeaveRequestDetail.setRequestedDate(leaveRequestDetails.getStatus().equalsIgnoreCase("A")
					? "Your leave request has been approved. Given below are the details : "
					: leaveRequestDetails.getStatus().equalsIgnoreCase("R")
					? "Your leave request has been rejected. Given below are the details : "
					: "Your leave request has been cancelled. Given below are the details : ");
			emailLeaveRequestDetail.setEmployeeName(emailContent.get(0).getEmployeeName());
			emailLeaveRequestDetail.setReviewerName(reviewerName);

			String[] emailId = approverDetails.stream()
					.filter(approver -> approver.getEmailIdType().equals("FromEmail")).findFirst()
					.map(s -> s.getEmailId().split(";")).orElse(ArrayUtils.EMPTY_STRING_ARRAY);

			String[] bcc = new String[] {};

			String[] cc = approverDetails.stream().filter(approver -> !approver.getEmailIdType().equals("FromEmail"))
					.flatMap(approver -> Arrays.stream(approver.getEmailId().split(";"))).toArray(String[]::new);

			String emailString = generateHtmlContent(emailContent.get(0).getEmployeeID(), emailLeaveRequestDetail,
					false);
			EmailDetailModel emailDetail = new EmailDetailModel(subject, emailString, emailId, cc, bcc);

			String emailUrl = propertyConfig.getHistosupportLink ();

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<EmailDetailModel> request = new HttpEntity<>(emailDetail, headers);

			return restTemplate.postForEntity(emailUrl, request, Object.class);
		} catch (Exception e) {
			return catchException("sendEmail()", e, "Failed", "Email not sent");
		}
	}

	@Override
	public ResponseEntity<Object> sendEmail(Object object,String leaveRequested) {
		try {

			ResponseModel value = (ResponseModel) ((MappingJacksonValue) object).getValue();
			EmployeeLeaveRequestMaster leaveRequestDTO = (EmployeeLeaveRequestMaster) value.getData();

			List<EmailContent> emailContent = SqlConnectionSetup.getJdbcConnection().query(
					"exec GetDojAndDepartment ?;", BeanPropertyRowMapper.newInstance(EmailContent.class),
					leaveRequestDTO.getEmployeeId());

			String leaveRequestSub = "I request you to kindly approve my leave request which I posted on ";
			String leaveCancelSub = "I request you to kindly cancel my leave request which I posted on ";
			String updatedLeaveReqSub = "I request you to kindly approve my updated leave request which I posted on ";

			String subject = "Leave Requisition - %s of %s between %s and %s";

			String cancellationSubject = "Leave Cancellation Requisition - %s of %s between %s and %s";

			String updatedReqSubject = "Updated Leave Requisition - %s of %s between %s and %s";

			List<EmployeeLeaveDetails> leaveDetails = leaveDetailsRepository
					.findByLeaveRequestId_IdAndApprovalStatus(leaveRequestDTO.getId(),Constants.TO_BE_CANCELLED);

			double noOfDaysApplied = leaveDetails.size();

			for (EmployeeLeaveDetails details : leaveDetails) {
				if (leaveRequestDTO.getLeaveFromForH().equalsIgnoreCase("H")
						&& details.getLeaveDate().equals(leaveRequestDTO.getLeaveFrom())) {
					noOfDaysApplied = noOfDaysApplied - 0.5;
				} else if (leaveRequestDTO.getLeaveToForH().equalsIgnoreCase("H")
						&& details.getLeaveDate().equals(leaveRequestDTO.getLeaveTo())) {
					noOfDaysApplied = noOfDaysApplied - 0.5;
				}
			}
			String leaveTypeName = leaveTypeRepository
					.findLeaveTypeNameByLeaveTypeId(leaveRequestDTO.getTypeofLeave().getLeaveTypeId());

			Integer locationId = loginRepo.findLocationIdByEmployeeId(leaveRequestDTO.getEmployeeId());

			LeaveDatesModel excludeHoliday = employeeLeaveRequestService.excludeHoliday(new EmployeeLeaveRequestDTO(
					leaveRequestDTO.getEmployeeId(), InstantFormatter.InstantFormat(leaveRequestDTO.getLeaveFrom()),
					InstantFormatter.InstantFormat(leaveRequestDTO.getLeaveTo()), leaveRequestDTO.getLeaveFromForH(),
					leaveRequestDTO.getLeaveToForH()), locationId);

			String sql = locationId.equals(LocationEum.INDIA.getValue()) ? "exec GetIndiaEmployeeApproverMails ?"
					: "exec GetUSEmployeeLeaveApprovers ?";

			String fromDate = locationId.equals(LocationEum.INDIA.getValue()) ? InstantFormatter.indiaDateFormat (leaveRequestDTO.getLeaveFrom()):
					InstantFormatter.dateFormat(leaveRequestDTO.getLeaveFrom());

			String toDate = locationId.equals(LocationEum.INDIA.getValue()) ? InstantFormatter.indiaDateFormat (leaveRequestDTO.getLeaveTo ()):
					InstantFormatter.dateFormat(leaveRequestDTO.getLeaveTo());

			List<ApproverDetails> approverDetails = SqlConnectionSetup.getJdbcConnection().query(sql,
					BeanPropertyRowMapper.newInstance(ApproverDetails.class), leaveRequestDTO.getEmployeeId());

			EmailLeaveRequestDetail emailLeaveRequestDetail = new EmailLeaveRequestDetail();

			emailLeaveRequestDetail.setSection(emailContent.get(0).getDepartment());
			emailLeaveRequestDetail.setDayOfJoining(emailContent.get(0).getDoj());
			emailLeaveRequestDetail.setLeaveFrom(
					fromDate + " to " + toDate);
			emailLeaveRequestDetail.setLeaveType(leaveTypeName);
			emailLeaveRequestDetail.setPurpose(leaveRequestDTO.getRemarks());
			emailLeaveRequestDetail.setNoOfDaysRequested(leaveRequested.equalsIgnoreCase(Constants.LEAVE_CANCELLED)?noOfDaysApplied :excludeHoliday.noOfDaysApplied());
			emailLeaveRequestDetail.setVacationLeaveBalance(emailContent.get(0).getVacationLeaveBalance());
			emailLeaveRequestDetail.setSickLeaveBalance(emailContent.get(0).getSickLeaveBalance());
			emailLeaveRequestDetail.setCasualLeaveBalance(emailContent.get(0).getCasualLeaveBalance());
			emailLeaveRequestDetail
					.setRequestedDate((leaveRequested.equalsIgnoreCase(Constants.LEAVE_CANCELLED)?
							leaveCancelSub
							:leaveRequested.equalsIgnoreCase(Constants.LEDGER_ADD)?leaveRequestSub : updatedLeaveReqSub)
							+ emailContent.get (0).getCurrentDate () + " for");
			emailLeaveRequestDetail.setEmployeeName(emailContent.get(0).getEmployeeName());
			emailLeaveRequestDetail.setRequestId(leaveRequestDTO.getId());
			emailLeaveRequestDetail.setStatus(leaveRequested.equalsIgnoreCase(Constants.LEAVE_CANCELLED)?
					Constants.CANCELLED_STATUS
					:Constants.APPROVED_STATUS);

			String[] emailId = approverDetails.stream()
					.filter(approver -> approver.getEmailIdType().equals("FromEmail")).findFirst()
					.map(s -> s.getEmailId().split(";")).orElse(ArrayUtils.EMPTY_STRING_ARRAY);

			String[] approverEmailId = approverDetails.stream()
					.filter(approver -> approver.getEmailIdType().equals("Approver"))
					.flatMap(approver -> Arrays.stream(approver.getEmailId().split(";"))).toArray(String[]::new);

			String[] bcc = new String[] {};
			String[] cc = new String[] {};

			String[] approverCc = approverDetails.stream()
					.filter(approver -> !approver.getEmailIdType().equals("FromEmail"))
					.filter(approver -> !approver.getEmailIdType().equals("Approver"))
					.flatMap(approver -> Arrays.stream(approver.getEmailId().split(";"))).toArray(String[]::new);


			String emailString = generateHtmlContent(emailContent.get(0).getEmployeeID(), emailLeaveRequestDetail,
					false);
			EmailDetailModel emailDetail = new EmailDetailModel();
			emailDetail.setBcc(bcc);
			emailDetail.setCc(cc);
			emailDetail.setTo(emailId);
			emailDetail.setBody(emailString);
			emailDetail.setSubject(leaveRequested.equalsIgnoreCase(Constants.LEAVE_CANCELLED)?
					String.format (cancellationSubject,  leaveTypeName , emailContent.get(0).getEmployeeName(),fromDate, toDate)
					:leaveRequested.equalsIgnoreCase(Constants.LEDGER_ADD)?
					String.format (subject,  leaveTypeName , emailContent.get(0).getEmployeeName(),fromDate, toDate) :
					String.format (updatedReqSubject,  leaveTypeName , emailContent.get(0).getEmployeeName(),fromDate, toDate));

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<EmailDetailModel> request = new HttpEntity<>(emailDetail, headers);

			String emailUrl = propertyConfig.getHistosupportLink ();

			ResponseEntity<Object> responseEntity = restTemplate.postForEntity(emailUrl, request, Object.class);

			String approverEmailString = generateHtmlContent(emailContent.get(0).getEmployeeID(),
					emailLeaveRequestDetail, true);
			EmailDetailModel approverEmailDetail = new EmailDetailModel();
			approverEmailDetail.setBcc(bcc);
			approverEmailDetail.setCc(approverCc);
			approverEmailDetail.setTo(approverEmailId);
			approverEmailDetail.setBody(approverEmailString);
			approverEmailDetail.setSubject(leaveRequested.equalsIgnoreCase(Constants.LEAVE_CANCELLED)?
					String.format (cancellationSubject,  leaveTypeName , emailContent.get(0).getEmployeeName(),fromDate, toDate)
					:leaveRequested.equalsIgnoreCase(Constants.LEDGER_ADD)?
					String.format (subject,  leaveTypeName , emailContent.get(0).getEmployeeName(),fromDate, toDate) :
					String.format (updatedReqSubject,  leaveTypeName , emailContent.get(0).getEmployeeName(),fromDate, toDate));

			HttpEntity<EmailDetailModel> emailRequest = new HttpEntity<>(approverEmailDetail, headers);
			return restTemplate.postForEntity(emailUrl, emailRequest, Object.class);

		} catch (Exception e) {
			return catchException("sendEmail()", e, "Failed", "Email not sent");
		}
	}


	private String generateHtmlContent(Integer employeeID, EmailLeaveRequestDetail emailLeaveRequestDetail,
									   boolean isApprover) throws UnsupportedEncodingException {

		Context context = new Context();

		Integer locationId = loginRepo.findLocationIdByEmployeeId(employeeID);

		List<LeaveFrequencyDetail> leaveFrequency = SqlConnectionSetup.getJdbcConnection().query(
				"exec GetLeaveAvailedCountofanEmployee ?;",
				BeanPropertyRowMapper.newInstance(LeaveFrequencyDetail.class), employeeID);

		List<LeaveHistoryDetail> leaveHistory = SqlConnectionSetup.getJdbcConnection().query(
				"exec GetLeaveRequestedDetailsofEmployee ?;",
				BeanPropertyRowMapper.newInstance(LeaveHistoryDetail.class), employeeID);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("requestId", emailLeaveRequestDetail.getRequestId());
		jsonObject.put(STATUS, emailLeaveRequestDetail.getStatus());

		String encodedJson = URLEncoder.encode(jsonObject.toString(), "UTF-8").replace("+", "");
		String approveLink = propertyConfig.getApproveLink().concat(encodedJson);

		context.setVariable("leaveFrequency", leaveFrequency);
		context.setVariable("leaveHistory", leaveHistory);
		context.setVariable("leaveDetail", emailLeaveRequestDetail);
		context.setVariable("isApprover", isApprover);
		context.setVariable("approveLink", approveLink);
		context.setVariable("location", locationId);
		return templateEngine.process("EmailTemplate", context);
	}

	@Override
	public ResponseEntity<Object> sendLedgerUpdateEmail(Object data) {
		try {

			ResponseModel value = (ResponseModel) ((MappingJacksonValue) data).getValue();
			LedgerEmailModel ledgerEmailModel = (LedgerEmailModel) value.getData();

			LedgerUpdateModel ledgerUpdateModel = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetEmployeeNameAndEmailById ?,?",
					BeanPropertyRowMapper.newInstance(LedgerUpdateModel.class), ledgerEmailModel.getUpdatedBy(),ledgerEmailModel.getEmployeeId());

			if(ledgerUpdateModel == null || ObjectUtils.isEmpty (ledgerUpdateModel)){
				return catchException("sendLedgerUpdateEmail()", null, "Failed", "Updated login details not found.");
			}

			ledgerEmailModel.setEmployeeName(ledgerUpdateModel.getEmployeeName());

			String ledgerComment = ledgerEmailModel.getLedgerAction().equals( Constants.LEDGER_UPDATE)?
					"Your leave ledger detail has been updated by "+ledgerUpdateModel.getUpdatedBy()+" on "+ledgerEmailModel.getUpdatedOn()+", Given below are ledger details"
					: ledgerEmailModel.getLedgerAction().equals( Constants.LEDGER_DELETE)?
					"Your leave ledger detail has been deleted by "+ledgerUpdateModel.getUpdatedBy()+" on "+ledgerEmailModel.getUpdatedOn()+", Given below are ledger details"
					: "Additional Leave credit added successfully by "+ledgerUpdateModel.getUpdatedBy()+" on "+ledgerEmailModel.getUpdatedOn()+", Given below are ledger details" ;

			Integer locationId = loginRepo.findLocationIdByEmployeeId(ledgerEmailModel.getEmployeeId());

			String sql = locationId.equals(LocationEum.INDIA.getValue()) ? "exec GetIndiaEmployeeApproverMails ?"
					: "exec GetUSEmployeeLeaveApprovers ?";

			List<ApproverDetails> approverDetails = SqlConnectionSetup.getJdbcConnection().query(sql,
					BeanPropertyRowMapper.newInstance(ApproverDetails.class), ledgerEmailModel.getEmployeeId());

			String[] emailId = approverDetails.stream()
					.filter(approver -> approver.getEmailIdType().equals("FromEmail")).findFirst()
					.map(s -> s.getEmailId().split(";")).orElse(ArrayUtils.EMPTY_STRING_ARRAY);

			String[] bcc = new String[] {};

			String[] cc = approverDetails.stream()
					.filter(approver -> !approver.getEmailIdType().equals("FromEmail"))
					.flatMap(approver -> Arrays.stream(approver.getEmailId().split(";")))
					.toArray(String[]::new);

			Context context = new Context();

			context.setVariable("comments", ledgerComment);
			context.setVariable("ledgerDetail", ledgerEmailModel);

			String emailContent = templateEngine.process("LedgerUpdateTemplate", context);

			EmailDetailModel emailDetail = new EmailDetailModel();
			emailDetail.setBcc(bcc);
			emailDetail.setCc(cc);
			emailDetail.setTo(emailId);
			emailDetail.setBody(emailContent);
			emailDetail.setSubject("Ledger update notify");
			String emailUrl = propertyConfig.getHistoAppsLink ();

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<EmailDetailModel> request = new HttpEntity<>(emailDetail, headers);

			return restTemplate.postForEntity(emailUrl, request, Object.class);
		} catch (Exception e) {
			return catchException("sendLedgerUpdateEmail()", e, "Failed", "Email not sent");
		}
	}

	private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
		logger.error("{} Error : {}" + methodName, e);
		response.setStatus(false);
		response.setInformation(new ExceptionBean(Instant.now(), message, description));
		mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
		return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
	}

	@Override
	public ResponseEntity<Object> sendLeaveCreditEmail(Object content) {
		try {
			Emailmodel emailmodel = new Emailmodel();
			ResponseModel value = (ResponseModel) ((MappingJacksonValue) content).getValue();
			List<SpecialLeaveCreditDetail> leaveCreditDetail = (List<SpecialLeaveCreditDetail>) value.getData();
			List<Attribute> attributeName = attributeRepository.findByCategoryAndAttributeNameIn("LeaveManagement",
					Arrays.asList("cc", "bcc", "to"));
			EmailLeaveRequestDetail emailLeaveRequestDetail = value.getEmailLeaveRequestDetail();
			attributeName.stream().forEach(attribute -> {
				if (attribute.getAttributeName().equalsIgnoreCase("cc")) {
					emailmodel.setBcc(attribute.getAttributeValue().split(";"));
				} else if (attribute.getAttributeName().equalsIgnoreCase("bcc")) {
					emailmodel.setCc(attribute.getAttributeValue().split(";"));
				} else {
					emailmodel.setEmailId(attribute.getAttributeValue().split(";"));
				}
			});

			Context context = new Context();
			context.setVariable("creditDate", " Leave Credit Process ran successfully On "
					+ new SimpleDateFormat("dd/MM/yyyy").format(new Date()));
			context.setVariable("leaveCredit", leaveCreditDetail);

			String emailContent = templateEngine.process("LeaveCreditEmailTemplate", context);

			EmailDetailModel emailDetail = new EmailDetailModel("Leave credit Status for India", emailContent,
					emailmodel.getEmailId(), emailmodel.getCc(), emailmodel.getBcc());

			String emailUrl = propertyConfig.getHistoAppsLink ();

			return restTemplate.postForEntity(emailUrl, emailDetail, Object.class);
		} catch (Exception e) {
			return catchException("sendLeaveCreditEmail()", e, "Failed", "Email not sent");
		}
	}

	@Override
	public ResponseEntity<Object> sendNewLoginDetailsEmail(Object object){
		try {

			Emailmodel emailmodel = new Emailmodel();

			ResponseModel value = (ResponseModel) ((MappingJacksonValue) object).getValue();
			EmployeeViewDTO employeeViewDTO = (EmployeeViewDTO) value.getData();

			NewLoginEmailModel login = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetLoginCredentials ?",
					BeanPropertyRowMapper.newInstance(NewLoginEmailModel.class), employeeViewDTO.getLoginId());

			if(login == null || ObjectUtils.isEmpty (login)){
				return catchException("sendNewLoginDetailsEmail()", null, "Failed", "Email not sent. New login details added but unable to get value for email template.");
			}

			if(Objects.equals(employeeViewDTO.getLocationId(), LocationEum.INDIA.getValue())) {
				List<Attribute> attributeName = attributeRepository.findByCategoryAndAttributeNameIn("LeaveManagement",
						Arrays.asList(AttributeEnum.INDIA_HR.getValue(),AttributeEnum.INDIA_ADMIN.getValue()));
				EmailLeaveRequestDetail emailLeaveRequestDetail = value.getEmailLeaveRequestDetail();
				attributeName.stream().forEach(attribute -> {
					if (attribute.getAttributeName().equalsIgnoreCase(AttributeEnum.INDIA_ADMIN.getValue())) {
						emailmodel.setBcc(attribute.getAttributeValue().split(";"));
					} else if (attribute.getAttributeName().equalsIgnoreCase(AttributeEnum.INDIA_HR.getValue())) {
						emailmodel.setCc(attribute.getAttributeValue().split(";"));
					}
				});
				emailmodel.setEmailId(new String[] {login.getEmailId()});
			} else {
				List<Attribute> attributeName = attributeRepository.findByCategoryAndAttributeNameIn("LeaveManagement",
						Arrays.asList(AttributeEnum.US_HR.getValue(),AttributeEnum.US_ADMIN.getValue()));
				EmailLeaveRequestDetail emailLeaveRequestDetail = value.getEmailLeaveRequestDetail();
				attributeName.stream().forEach(attribute -> {
					if (attribute.getAttributeName().equalsIgnoreCase(AttributeEnum.US_HR.getValue())) {
						emailmodel.setBcc(attribute.getAttributeValue().split(";"));
					} else if (attribute.getAttributeName().equalsIgnoreCase(AttributeEnum.US_ADMIN.getValue())) {
						emailmodel.setCc(attribute.getAttributeValue().split(";"));
					}
				});
				emailmodel.setEmailId(new String[] {login.getEmailId()});
			}

			Context context = new Context();

			context.setVariable("login", login);

			String emailContent = templateEngine.process("NewLoginTemplate", context);

			EmailDetailModel emailDetail = new EmailDetailModel("Login Credential", emailContent,
					emailmodel.getEmailId(), emailmodel.getCc(), emailmodel.getBcc());

			String emailUrl = propertyConfig.getHistoAppsLink ();

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<EmailDetailModel> request = new HttpEntity<>(emailDetail, headers);

			return restTemplate.postForEntity(emailUrl, request, Object.class);

		} catch(Exception e) {
			return catchException("sendNewLoginDetailsEmail()", e, "Failed", "Email not sent");
		}
	}

	@Override
	public ResponseEntity<Object> sendMyRequestEmail(Object emailModel) {
		try {

			ResponseModel value = (ResponseModel) ((MappingJacksonValue) emailModel).getValue();
			MyRequestEmailParams myRequestEmailParams = (MyRequestEmailParams) value.getData();

			String ledgerComment = myRequestEmailParams.getRequestAction ().equals( Constants.LEDGER_UPDATE)?
					"I request you to kindly approve the below updated request. "
					: myRequestEmailParams.getRequestAction ().equals( Constants.LEDGER_ADD)?
					"I request you to kindly approve the below request. "
					:"Your below request detail has been "+myRequestEmailParams.getStatus () + " by "
					+myRequestEmailParams.getReviewedBy ()+" on "+ myRequestEmailParams.getReviewedOn () ;

			String sql = myRequestEmailParams.getLocationId ().equals(LocationEum.INDIA.getValue()) ? "exec GetIndiaEmployeeApproverMails ?"
					: "exec GetUSEmployeeLeaveApprovers ?";

			List<ApproverDetails> approverDetails = SqlConnectionSetup.getJdbcConnection().query(sql,
					BeanPropertyRowMapper.newInstance(ApproverDetails.class), myRequestEmailParams.getEmployeeId());

			String[] emailId = approverDetails.stream()
					.filter(approver -> approver.getEmailIdType().equals("FromEmail")).findFirst()
					.map(s -> s.getEmailId().split(";")).orElse(ArrayUtils.EMPTY_STRING_ARRAY);

			String[] bcc = new String[] {};

			String[] cc = approverDetails.stream()
					.filter(approver -> !approver.getEmailIdType().equals("FromEmail"))
					.flatMap(approver -> Arrays.stream(approver.getEmailId().split(";")))
					.toArray(String[]::new);
			boolean isReviewed = !(ObjectUtils.equals (myRequestEmailParams.getRequestAction (), Constants.LEDGER_UPDATE) ||
					ObjectUtils.equals (myRequestEmailParams.getRequestAction (), Constants.LEDGER_ADD));
			Context context = new Context();

			context.setVariable("comments", ledgerComment);
			context.setVariable ("isReviewed", isReviewed);
			context.setVariable("requestDetail", myRequestEmailParams);

			String emailContent = templateEngine.process("EmployeeRequestEmailTemplate", context);

			EmailDetailModel emailDetail = new EmailDetailModel();
			emailDetail.setBcc(bcc);
			emailDetail.setCc(cc);
			emailDetail.setTo(emailId);
			emailDetail.setBody(emailContent);
			emailDetail.setSubject("Employee Service Request - "+ myRequestEmailParams.getRequestType ());
			String emailUrl = propertyConfig.getHistosupportLink ();

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<EmailDetailModel> request = new HttpEntity<>(emailDetail, headers);

			return restTemplate.postForEntity(emailUrl, request, Object.class);
		} catch (Exception e) {
			return catchException("sendMyRequestEmail()", e, "Failed", "Email not sent");
		}
	}

	@Override
	public ResponseEntity<Object> sendMyRequestAssigneeEmail(Object emailModel) {
		try {

			ResponseModel value = (ResponseModel) ((MappingJacksonValue) emailModel).getValue();
			ApproverEmailDetails approverEmailDetails = (ApproverEmailDetails) value.getData ();

			String comment = approverEmailDetails.getRequestStatus ().equalsIgnoreCase( RequestStatus.OPEN.toString ())?
					"Below request has been approved by "+approverEmailDetails.getReviewedBy ()+". Kindly review and Approve to proceed further."
					: approverEmailDetails.getRequestStatus ().equalsIgnoreCase ( RequestStatus.INPROGRESS.toString ())?
					"Below request has been verified and its under process."
					:"Below request has been reviewed and approved.";


			String[] emailId = approverEmailDetails.getEmailId ().split (";");

			String[] bcc = new String[] {};

			String[] cc = approverEmailDetails.getCc ().split (";");
			boolean isReviewed = approverEmailDetails.getRequestStatus ().equalsIgnoreCase ( RequestStatus.OPEN.getValue ())?Boolean.FALSE : Boolean.TRUE;

			Context context = new Context();

			context.setVariable("comments", comment);
			context.setVariable ("isReviewed", isReviewed);
			context.setVariable("requestDetail", approverEmailDetails);

			String emailContent = templateEngine.process("MyRequestApproverTemplate", context);

			EmailDetailModel emailDetail = new EmailDetailModel();
			emailDetail.setBcc(bcc);
			emailDetail.setCc(cc);
			emailDetail.setTo(emailId);
			emailDetail.setBody(emailContent);
			emailDetail.setSubject("Employee Service Request - "+ approverEmailDetails.getRequestType ());
			String emailUrl = propertyConfig.getHistosupportLink ();

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<EmailDetailModel> request = new HttpEntity<>(emailDetail, headers);

			return restTemplate.postForEntity(emailUrl, request, Object.class);
		} catch (Exception e) {
			return catchException("sendMyRequestAssigneeEmail()", e, "Failed", "Email not sent");
		}
	}

	@Override
	public ResponseEntity<Object> sendPermissionRequestEmail(Object emailDetails) {
		try {

			ResponseModel value = (ResponseModel) ((MappingJacksonValue) emailDetails).getValue();
			PermissionEmailDetails permissionEmailDetails = (PermissionEmailDetails) value.getData();

			String permissionRequestSub = "I request you to kindly approve my permission request which I posted on ";
			String permissionCancelSub = "I request you to kindly cancel my permission request which I posted on ";
			String updatedPermissionReqSub = "I request you to kindly approve my updated permission request which I posted on ";

			String content = (permissionEmailDetails.getPermissionAction ().equals( Constants.LEDGER_UPDATE)?
					updatedPermissionReqSub
					: permissionEmailDetails.getPermissionAction ().equals( Constants.LEDGER_ADD)?
					permissionRequestSub
					:permissionCancelSub)+permissionEmailDetails.getRequestedDate ();

			String sql = permissionEmailDetails.getLocationId ().equals(LocationEum.INDIA.getValue()) ? "exec GetIndiaEmployeeApproverMails ?"
					: "exec GetUSEmployeeLeaveApprovers ?";

			List<PermisisonHistory> permissionDetails = SqlConnectionSetup.getJdbcConnection ().query ("exec GetPermissionHistoryForEmail ?,?;"
					, BeanPropertyRowMapper.newInstance (PermisisonHistory.class),
					0,
					permissionEmailDetails.getEmployeeId ());

			List<ApproverDetails> approverDetails = SqlConnectionSetup.getJdbcConnection().query(sql,
					BeanPropertyRowMapper.newInstance(ApproverDetails.class), permissionEmailDetails.getEmployeeId());

			String[] emailId = approverDetails.stream()
					.filter(approver -> approver.getEmailIdType().equals("FromEmail")).findFirst()
					.map(s -> s.getEmailId().split(";")).orElse(ArrayUtils.EMPTY_STRING_ARRAY);

			String[] approverEmailId = approverDetails.stream()
					.filter(approver -> approver.getEmailIdType().equals("Approver"))
					.flatMap(approver -> Arrays.stream(approver.getEmailId().split(";"))).toArray(String[]::new);

			String[] bcc = new String[] {};
			String[] cc = new String[] {};

			String[] approverCc = approverDetails.stream()
					.filter(approver -> !approver.getEmailIdType().equals("FromEmail"))
					.filter(approver -> !approver.getEmailIdType().equals("Approver"))
					.flatMap(approver -> Arrays.stream(approver.getEmailId().split(";"))).toArray(String[]::new);

			Context context = new Context();

			context.setVariable("permissionDetail", permissionEmailDetails);
			context.setVariable("content", content);
			context.setVariable("permissionHistory", permissionDetails);
			context.setVariable("approveLink", null);

			String emailContent = templateEngine.process("PermissionRequestEmailTemplate", context);

			EmailDetailModel emailDetail = new EmailDetailModel();
			emailDetail.setBcc(bcc);
			emailDetail.setCc(cc);
			emailDetail.setTo(emailId);
			emailDetail.setBody(emailContent);
			emailDetail.setSubject("Employee Permission Request - "+ permissionEmailDetails.getPermissionType ());
			String emailUrl = propertyConfig.getHistosupportLink ();

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<EmailDetailModel> request = new HttpEntity<>(emailDetail, headers);

			ResponseEntity<Object> responseEntity = restTemplate.postForEntity (emailUrl, request, Object.class);


			JSONObject jsonObject = new JSONObject();
			jsonObject.put("permissionId", permissionEmailDetails.getPermissionId ());
			jsonObject.put(STATUS, permissionEmailDetails.getPermissionStatus ().equalsIgnoreCase (LeaveStatusEnum.TC.getValue ())
					?LeaveStatusEnum.C : LeaveStatusEnum.A);
			jsonObject.put("employeeId", permissionEmailDetails.getEmployeeId ());


			String encodedJson = URLEncoder.encode(jsonObject.toString(), "UTF-8").replace ("+", "");
			String approveLink = propertyConfig.getPermissionRedirectLink().concat(encodedJson);

			context.setVariable("isApprover", Boolean.TRUE);
			context.setVariable("approveLink", approveLink);


			String approverEmailString = templateEngine.process("PermissionRequestEmailTemplate", context);
			EmailDetailModel approverEmailDetail = new EmailDetailModel();
			approverEmailDetail.setBcc(bcc);
			approverEmailDetail.setCc(approverCc);
			approverEmailDetail.setTo(approverEmailId);
			approverEmailDetail.setBody(approverEmailString);
			approverEmailDetail.setSubject("Employee Permission Request - "+ permissionEmailDetails.getPermissionType ());

			HttpEntity<EmailDetailModel> approverRequest = new HttpEntity<>(approverEmailDetail, headers);

			ResponseEntity<Object> responseEntity1 = restTemplate.postForEntity (emailUrl, approverRequest, Object.class);
			return responseEntity1;

		} catch (Exception e) {
			return catchException("sendEmail()", e, "Failed", "Email not sent");
		}
	}

	@Override
	public ResponseEntity<Object> sendPermissionRequestApprovalEmail(Object emailDetails) {
		try {

			ResponseModel value = (ResponseModel) ((MappingJacksonValue) emailDetails).getValue();
			PermissionEmailDetails permissionEmailDetails = (PermissionEmailDetails) value.getData();

			String approvedContents = "Your below request detail has been " + permissionEmailDetails.getPermissionStatus () + " by "
					+ permissionEmailDetails.getReviewerName () + " on " + permissionEmailDetails.getReviewedOn ();

			String sql = permissionEmailDetails.getLocationId ().equals(LocationEum.INDIA.getValue()) ? "exec GetIndiaEmployeeApproverMails ?"
					: "exec GetUSEmployeeLeaveApprovers ?";

			List<PermisisonHistory> permissionDetails = SqlConnectionSetup.getJdbcConnection ().query ("exec GetPermissionHistoryForEmail ?,?;"
					, BeanPropertyRowMapper.newInstance (PermisisonHistory.class),
					0,
					permissionEmailDetails.getEmployeeId ());

			List<ApproverDetails> approverDetails = SqlConnectionSetup.getJdbcConnection().query(sql,
					BeanPropertyRowMapper.newInstance(ApproverDetails.class), permissionEmailDetails.getEmployeeId());

			String[] emailId = approverDetails.stream()
					.filter(approver -> approver.getEmailIdType().equals("FromEmail")).findFirst()
					.map(s -> s.getEmailId().split(";")).orElse(ArrayUtils.EMPTY_STRING_ARRAY);


			String[] approverCc = approverDetails.stream()
					.filter(approver -> !approver.getEmailIdType().equals("FromEmail"))
					.flatMap(approver -> Arrays.stream(approver.getEmailId().split(";"))).toArray(String[]::new);

			String[] bcc = new String[] {};

			Context context = new Context();

			context.setVariable("permissionDetail", permissionEmailDetails);
			context.setVariable("content", approvedContents);
			context.setVariable("approveLink", null);
			context.setVariable("permissionHistory", permissionDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			String emailUrl = propertyConfig.getHistosupportLink ();

			String approverEmailString = templateEngine.process("PermissionRequestEmailTemplate", context);
			EmailDetailModel approverEmailDetail = new EmailDetailModel();
			approverEmailDetail.setBcc(bcc);
			approverEmailDetail.setCc(approverCc);
			approverEmailDetail.setTo(emailId);
			approverEmailDetail.setBody(approverEmailString);
			approverEmailDetail.setSubject("Employee Permission Request - "+ permissionEmailDetails.getPermissionType ());

			HttpEntity<EmailDetailModel> approverRequest = new HttpEntity<>(approverEmailDetail, headers);

			ResponseEntity<Object> responseEntity1 = restTemplate.postForEntity (emailUrl, approverRequest, Object.class);
			return responseEntity1;

		} catch (Exception e) {
			return catchException("sendEmail()", e, "Failed", "Email not sent");
		}
	}

	@Override
	public ResponseEntity<Object> sendComplianceExpiryEmail(List<ComplianceEmailModel> emailModels) {
		try {

			Optional<Attribute> ccEmailDetails = attributeRepository.findByAttributeNameAndCategory
					(AttributeEnum.US_HR.getValue (), StaffModuleName.LEAVEMANAGEMENT.getValue ());

			final boolean[] allSuccess = {true};

			String[] cc = ccEmailDetails.stream ().findFirst ().map(s -> s.getAttributeValue ()
					.split(";")).orElse(ArrayUtils.EMPTY_STRING_ARRAY);

			String[] bcc = new String[] {};

			Context context = new Context();

			Map<Integer, List<ComplianceEmailModel>> groupedById = emailModels.stream()
					.collect(Collectors.groupingBy(ComplianceEmailModel::getEmployeeID));

			groupedById.forEach ((id,data) -> {

				String[] emailId = data.stream ().findFirst ().map(s -> s.getEmailId()
						.split(";")).orElse(ArrayUtils.EMPTY_STRING_ARRAY);
				context.setVariable("complianceList", data);
				context.setVariable("employeeName", data.get (0).getEmployeeName ());

				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				String emailUrl = propertyConfig.getHistosupportLink ();

				String emailString = templateEngine.process("ComplianceDocumentExpiryAlert", context);
				EmailDetailModel complianceEmailDetail = new EmailDetailModel();
				complianceEmailDetail.setBcc(bcc);
				complianceEmailDetail.setCc(cc);
				complianceEmailDetail.setTo(emailId);
				complianceEmailDetail.setBody(emailString);
				complianceEmailDetail.setSubject(Constants.COMPLIANCE_EXPIRY_EMAIL_SUBJECT);

				HttpEntity<EmailDetailModel> complianceTemplate = new HttpEntity<>(complianceEmailDetail, headers);

				ResponseEntity<Object> responseEntity = restTemplate.postForEntity (emailUrl, complianceTemplate, Object.class);
				if (!responseEntity.getStatusCode().is2xxSuccessful()) {
					allSuccess[0] = false;
				}

			});

			return allSuccess[0] ? ResponseEntity.ok("All emails sent successfully")
					: ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Some emails failed");

		} catch (Exception e) {
			return catchException("sendComplianceExpiryEmail()", e, "Failed", "Compliance expiry notify email not sent");
		}
	}

	@Override
	public ResponseEntity<Object> sendEmployeeWorkRequestEmail(Object emailDetails) {
		try {

			ResponseModel value = (ResponseModel) ((MappingJacksonValue) emailDetails).getValue();
			WorkRequestEmailDetails workRequestEmailDetails = (WorkRequestEmailDetails) value.getData();

			String workRequestSub = "I request you to kindly approve my work from home request which I posted on ";
			String workRequestCancelSub = "I request you to kindly cancel my work home request request which I posted on ";
			String updatedWorkReqSub = "I request you to kindly approve my updated work from home request which I posted on ";

			String content = (workRequestEmailDetails.getRequestAction ().equals( Constants.LEDGER_UPDATE)?
					updatedWorkReqSub
					: workRequestEmailDetails.getRequestAction ().equals( Constants.LEDGER_ADD)?
					workRequestSub
					:workRequestCancelSub)+workRequestEmailDetails.getRequestedDate ();

			List<WorkRequestHistoryForEmail> workHistoryDetails = SqlConnectionSetup.getJdbcConnection ()
					.query ("exec GetWorkRequestHistoryForEmail ?;"
							, BeanPropertyRowMapper.newInstance (WorkRequestHistoryForEmail.class),
							workRequestEmailDetails.getEmployeeId ());

			List<ApproverDetails> approverDetails = SqlConnectionSetup.getJdbcConnection().query("exec GetIndiaEmployeeApproverMails ?",
					BeanPropertyRowMapper.newInstance(ApproverDetails.class), workRequestEmailDetails.getEmployeeId());

			if(approverDetails.isEmpty()){
				return catchException("sendEmployeeWorkRequestEmail()", null, "Failed", "Approver email details not found.");
			}

				String[] emailId = approverDetails.stream()
						.filter(approver -> approver.getEmailIdType().equals("FromEmail")).findFirst()
						.map(s -> s.getEmailId().split(";")).orElse(ArrayUtils.EMPTY_STRING_ARRAY);

			String[] leaveApproverCc = approverDetails.stream()
					.filter(approver -> !approver.getEmailIdType().equals("FromEmail"))
					.flatMap(approver -> Arrays.stream(approver.getEmailId().split(";"))).toArray(String[]::new);

			String[] adminApproverCc = attributeRepository
					.findByAttributeNameAndCategory (AttributeEnum.INDIA_REQUEST_APPROVER.getValue (), "LeaveManagement")
					.stream ().flatMap (approver -> Arrays.stream(approver.getAttributeValue ().split(";"))).toArray(String[]::new);

			String[] approverCc = Arrays.stream(adminApproverCc)
					.collect(LinkedHashSet::new, LinkedHashSet::add, LinkedHashSet::addAll) // Maintain order
					.toArray(String[]::new);

			String[] finalApproverCc = approverCc;
			approverCc = Arrays.stream(leaveApproverCc)
					.collect(() -> new LinkedHashSet<>(Arrays.asList(finalApproverCc)), LinkedHashSet::add, LinkedHashSet::addAll)
					.toArray(String[]::new);


			String[] bcc = new String[] {};

			Context context = new Context();

			context.setVariable("workRequestDetail", workRequestEmailDetails);
			context.setVariable("content", content);
			context.setVariable("workRequestHistory", workHistoryDetails);

			String emailContent = templateEngine.process("WorkRequestEmailTemplate", context);

			EmailDetailModel emailDetail = new EmailDetailModel();
			emailDetail.setBcc(bcc);
			emailDetail.setCc(approverCc);
			emailDetail.setTo(emailId);
			emailDetail.setBody(emailContent);
			emailDetail.setSubject("Work From Request for - "+ workRequestEmailDetails.getEmployeeName ());
			String emailUrl = propertyConfig.getHistosupportLink ();

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<EmailDetailModel> request = new HttpEntity<>(emailDetail, headers);

			ResponseEntity<Object> responseEntity = restTemplate.postForEntity (emailUrl, request, Object.class);

			return responseEntity;

		} catch (Exception e) {
			return catchException("sendEmployeeWorkRequestEmail()", e, "Failed", "Email not sent");
		}
	}

	@Override
	public ResponseEntity<Object> sendEmployeeWorkRequestApprovalEmail(Object emailDetails) {

		try{

			ResponseModel value = (ResponseModel) ((MappingJacksonValue) emailDetails).getValue();
			WorkRequestEmailDetails workRequestEmailDetails = (WorkRequestEmailDetails) value.getData();

			String approvedContents = "Your below request detail has been " + workRequestEmailDetails.getStatus () + " by "
					+ workRequestEmailDetails.getReviewerName () + " on " + workRequestEmailDetails.getReviewedOn ();

			List<WorkRequestHistoryForEmail> permissionDetails = SqlConnectionSetup.getJdbcConnection ()
					.query ("exec GetWorkRequestHistoryForEmail ?;"
							, BeanPropertyRowMapper.newInstance (WorkRequestHistoryForEmail.class),
							workRequestEmailDetails.getEmployeeId ());

			List<ApproverDetails> approverDetails = SqlConnectionSetup.getJdbcConnection().query("exec GetIndiaEmployeeApproverMails ?",
					BeanPropertyRowMapper.newInstance(ApproverDetails.class), workRequestEmailDetails.getEmployeeId());

			if(approverDetails.isEmpty()){
				return catchException("sendEmployeeWorkRequestApprovalEmail()", null, "Email not sent", "Approver email details not found.");
			}

			String[] emailId = approverDetails.stream()
					.filter(approver -> approver.getEmailIdType().equals("FromEmail")).findFirst()
					.map(s -> s.getEmailId().split(";")).orElse(ArrayUtils.EMPTY_STRING_ARRAY);


			String[] leaveApproverCc = approverDetails.stream()
					.filter(approver -> !approver.getEmailIdType().equals("FromEmail"))
					.flatMap(approver -> Arrays.stream(approver.getEmailId().split(";"))).toArray(String[]::new);

			String[] adminApproverCc = attributeRepository
					.findByAttributeNameAndCategory (AttributeEnum.INDIA_REQUEST_APPROVER.getValue (), "LeaveManagement")
					.stream ().flatMap (approver -> Arrays.stream(approver.getAttributeValue ().split(";"))).toArray(String[]::new);

			String[] approverCc = Arrays.stream(adminApproverCc)
					.collect(LinkedHashSet::new, LinkedHashSet::add, LinkedHashSet::addAll) // Maintain order
					.toArray(String[]::new);

			String[] finalApproverCc = approverCc;
			approverCc = Arrays.stream(leaveApproverCc)
					.collect(() -> new LinkedHashSet<>(Arrays.asList(finalApproverCc)), LinkedHashSet::add, LinkedHashSet::addAll)
					.toArray(String[]::new);

			String[] bcc = new String[] {};
			Context context = new Context();

			context.setVariable("workRequestDetail", workRequestEmailDetails);
			context.setVariable("content", approvedContents);
			context.setVariable("workRequestHistory", permissionDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			String emailUrl = propertyConfig.getHistosupportLink ();

			String approverEmailString = templateEngine.process("WorkRequestEmailTemplate", context);
			EmailDetailModel approverEmailDetail = new EmailDetailModel();
			approverEmailDetail.setBcc(bcc);
			approverEmailDetail.setCc(approverCc);
			approverEmailDetail.setTo(emailId);
			approverEmailDetail.setBody(approverEmailString);
			approverEmailDetail.setSubject("Work From Request for - "+ workRequestEmailDetails.getEmployeeName ());

			HttpEntity<EmailDetailModel> approverRequest = new HttpEntity<>(approverEmailDetail, headers);

			ResponseEntity<Object> responseEntity1 = restTemplate.postForEntity (emailUrl, approverRequest, Object.class);
			return responseEntity1;

		} catch (Exception e) {
			return catchException("sendEmployeeWorkRequestApprovalEmail()", e, "Failed", "Email not sent");
		}
	}

	@Override
	public ResponseEntity<Object> sendHipaaEmailForNewJoinee(Integer employeeId) {
		try{
			List<String> htmlData = SqlConnectionSetup.getJdbcConnection().query("exec spAssignHipaaDocToNewJoinee ?", BeanPropertyRowMapper.newInstance(String.class), employeeId);

			response.setStatus(true);
			response.setMessage("Email sent successfully");
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch (Exception e) {
			return catchException("sendHipaaEmailForNewJoinee()", e, "Failed", "Email not sent");
		}
	}


}
