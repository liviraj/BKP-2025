package com.histo.staffmanagementportal.service.impl;

import com.histo.staffmanagementportal.dto.LeaveLedgerModifyDTO;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.intranet.entity.EmployeeLeaveDetails;
import com.histo.staffmanagementportal.intranet.entity.LeaveLedger;
import com.histo.staffmanagementportal.intranet.repository.EmployeeLeaveDetailsRepository;
import com.histo.staffmanagementportal.intranet.repository.EmployeeLeaveRequestMasterRepository;
import com.histo.staffmanagementportal.intranet.repository.LeaveLedgerRepository;
import com.histo.staffmanagementportal.intranet.repository.LoginRepository;
import com.histo.staffmanagementportal.model.*;
import com.histo.staffmanagementportal.service.LeaveLedgerInterface;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class VacationLedgerImpl implements LeaveLedgerInterface {

    private static final Logger LOGGER = LogManager.getLogger(VacationLedgerImpl.class);
    private static final String STATUS = "status";

    private final ResponseModel response;
    private MappingJacksonValue mappingJacksonValue;
    private final LeaveLedgerRepository leaveLedgerRepository;

    private final EmployeeLeaveDetailsRepository employeeLeaveDetailsRepository;

    private final LoginRepository loginRepository;

    public VacationLedgerImpl(ResponseModel response, LeaveLedgerRepository leaveLedgerRepository
            , EmployeeLeaveDetailsRepository employeeLeaveDetailsRepository
            , LoginRepository loginRepository) {
        this.response = response;
        this.leaveLedgerRepository = leaveLedgerRepository;
        this.employeeLeaveDetailsRepository = employeeLeaveDetailsRepository;
        this.loginRepository = loginRepository;
    }
    @Override
    public ResponseEntity<Object> addLeaveCredit(LedgerCreditModel ledgerCreditModel) {
        try {
            LeaveLedger ledgerDetail = leaveLedgerRepository.findFirstByEmployeeIdOrderByIdDesc(ledgerCreditModel.getEmployeeId());

            LeaveLedger leaveLedger = new LeaveLedger();

            leaveLedger.setEmployeeId(ledgerCreditModel.getEmployeeId());
            leaveLedger.setCreditDays(ledgerCreditModel.getCreditDays());
            leaveLedger.setDebitDays(0.0);
            leaveLedger.setComments(ledgerCreditModel.getComments());
            leaveLedger.setBalanceDays(ObjectUtils.isEmpty(ledgerDetail)?0+ledgerCreditModel.getCreditDays():
            	ledgerDetail.getBalanceDays()+ledgerCreditModel.getCreditDays());
            leaveLedger.setEntryDate(InstantFormatter.InstantFormat(ledgerCreditModel.getEntryDate()));
            leaveLedger.setRunDate(InstantFormatter.InstantFormat(ledgerCreditModel.getCreditAddedOn()));
            leaveLedger.setModifiedBy(ledgerCreditModel.getCreditAddedBy());
            leaveLedger.setModifiedDate(InstantFormatter.InstantFormat(ledgerCreditModel.getCreditAddedOn()));

            LeaveLedger ledger = leaveLedgerRepository.save(leaveLedger);

            LedgerEmailModel emailModel = new LedgerEmailModel(ledger.getEmployeeId()
            		, ledgerCreditModel.getCreditAddedBy()
            		, new SimpleDateFormat("MM/dd/yyyy").format(Date.from(leaveLedger.getRunDate()))
            		, new SimpleDateFormat("MM/dd/yyyy").format(Date.from(leaveLedger.getEntryDate()))
            		, ledger.getCreditDays()
            		, ledger.getDebitDays()
            		, ledger.getBalanceDays()
            		, Constants.LEDGER_ADD);
            
            response.setStatus(true);
            response.setMessage("Leave credit added successfully");
            response.setData(emailModel);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
        catch (Exception e) {
            return catchException("addLeaveCredit()", e, "Error", "Something went wrong");
        }
    }

    @Override
    public ResponseEntity<Object> editLeaveLedger(Integer ledgerId, LeaveLedgerModifyDTO leaveLedger) {
        try {

            Optional<LeaveLedger> leaveLedgerById = leaveLedgerRepository.findById(ledgerId);

            if (leaveLedgerById.isEmpty() || leaveLedgerById.get().getComments().contains(Constants.LOP)) {
                return catchException("editLeaveLedger()", null, "NOT FOUND", "Leave ledger is not found or Cannot edit loss of pay record");
            }
            Optional<EmployeeLeaveDetails> employeeLeaveDetails = employeeLeaveDetailsRepository
                    .findByEmployeeIdAndLeaveDate(leaveLedgerById.get().getEmployeeId(), leaveLedgerById.get().getEntryDate());

            if(leaveLedgerById.get().getCreditDays() == 0.0 && leaveLedgerById.get().getDebitDays() != 0.0
                    && !Objects.equals(leaveLedgerById.get().getDebitDays(), leaveLedger.getDebitDays()) && employeeLeaveDetails.isPresent()) {

//            	Optional<EmployeeLeaveRequestMaster> leaveRequest = leaveRequestMasterRepository.findById(employeeLeaveDetails.get().getLeaveRequestId());
//
//            	leaveRequest.get().setLeaveFromForH("H");
                employeeLeaveDetails.get().setApprovalStatus(leaveLedger.getDebitDays() ==0.0 ? Constants.CANCELLED_STATUS : employeeLeaveDetails.get().getApprovalStatus());
                employeeLeaveDetails.get().setApproverComments(employeeLeaveDetails.get().getApproverComments() +" - Edit in Ledger");
                employeeLeaveDetailsRepository.save(employeeLeaveDetails.get());
            }

            Double prevBalance = leaveLedgerById.get().getBalanceDays() - leaveLedgerById.get().getCreditDays() + leaveLedgerById.get().getDebitDays();
            Double balance = prevBalance + leaveLedger.getCreditDays() - leaveLedger.getDebitDays();

            List<LeaveLedger> ledgerBalancedList = leaveLedgerRepository.findByEmployeeIdOrderByIdAsc(leaveLedgerById.get().getEmployeeId())
                    .stream()
                    .filter(l -> l.getId()>leaveLedgerById.get().getId())
                    .toList();

            leaveLedgerById.get().setBalanceDays(balance);
            leaveLedgerById.get().setCreditDays(leaveLedger.getCreditDays());
            leaveLedgerById.get().setDebitDays(leaveLedger.getDebitDays());
            leaveLedgerById.get().setModifiedDate(InstantFormatter.InstantFormat(leaveLedger.getModifiedOn()));
            leaveLedgerById.get().setModifiedBy(leaveLedger.getModifiedBy());

            LeaveLedger ledger = leaveLedgerRepository.save(leaveLedgerById.get());

            for(LeaveLedger leave : ledgerBalancedList) {

                double finalBalance = leaveLedgerRepository.findByIdAndCommentsEndsWith(leave.getId(), Constants.LOP).isEmpty()?
                        balance+ leave.getCreditDays() - leave.getDebitDays() : balance;

                leave.setBalanceDays(finalBalance);
                leave.setModifiedDate(InstantFormatter.InstantFormat(leaveLedger.getModifiedOn()));
                leave.setModifiedBy(leaveLedger.getModifiedBy());
                leaveLedgerRepository.save(leave);

                balance = finalBalance;

            }
            
            LedgerEmailModel emailModel = new LedgerEmailModel(ledger.getEmployeeId()
            		, leaveLedger.getModifiedBy()
            		, new SimpleDateFormat("MM/dd/yyyy").format(Date.from(ledger.getModifiedDate()))
            		, new SimpleDateFormat("MM/dd/yyyy").format(Date.from(ledger.getEntryDate()))
            		, ledger.getCreditDays()
            		, ledger.getDebitDays()
            		, ledger.getBalanceDays()
            		, Constants.LEDGER_UPDATE);

            response.setStatus(true);
            response.setMessage("Leave ledger updated successfully");
            response.setData(emailModel);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }catch (Exception e) {
            return catchException("editLeaveLedger()", e, "Error", "Something went wrong");
        }
    }

    @Override
    public ResponseEntity<Object> deleteLeaveLedger(Integer ledgerId, LedgerDetails ledgerDetails) {
        try{
            Optional<LeaveLedger> leaveLedger = leaveLedgerRepository.findById(ledgerId);

            if (leaveLedger.isEmpty() || leaveLedger.get().getComments().contains(Constants.LOP)) {
                return catchException("deleteLeaveLedger()", null, "NOT FOUND", "Leave ledger not found or Cannot delete loss of pay record");
            }

            Integer locationId = loginRepository.findLocationIdByEmployeeId(leaveLedger.get().getEmployeeId());

            Optional<EmployeeLeaveDetails> employeeLeaveDetail = employeeLeaveDetailsRepository
                    .findByLeaveRequestId_TypeofLeave_LeaveTypeNameAndLeaveRequestId_TypeofLeave_LocationIDAndEmployeeIdAndLeaveDate
                    (ledgerDetails.getLeaveType(),locationId,leaveLedger.get().getEmployeeId(), leaveLedger.get().getEntryDate());

            if(employeeLeaveDetail.isPresent() && leaveLedger.get().getDebitDays() > 0
					&& employeeLeaveDetail.get().getApprovalStatus().equalsIgnoreCase(LeaveStatusEnum.APPROVED_STATUS.getValue())) {
				employeeLeaveDetail.get().setApprovalStatus(LeaveStatusEnum.REJECTED_STATUS.getValue());
				EmployeeLeaveDetails employeeLeaveDetails = employeeLeaveDetailsRepository.save(employeeLeaveDetail.get());
			}
			else if(employeeLeaveDetail.isPresent() && leaveLedger.get().getCreditDays() > 0
					&& employeeLeaveDetail.get().getApprovalStatus().equalsIgnoreCase(LeaveStatusEnum.CANCELLED_STATUS.getValue())) {
				employeeLeaveDetail.get().setApprovalStatus(LeaveStatusEnum.APPROVED_STATUS.getValue());
				EmployeeLeaveDetails employeeLeaveDetails = employeeLeaveDetailsRepository.save(employeeLeaveDetail.get());
			}

            Double balance = leaveLedger.get().getBalanceDays() - leaveLedger.get().getCreditDays() + leaveLedger.get().getDebitDays();

             List<LeaveLedger> ledgerBalancedList = leaveLedgerRepository.findByEmployeeIdOrderByIdAsc(leaveLedger.get().getEmployeeId())
            		                          .stream()
            		                          .filter(l -> l.getId()>leaveLedger.get().getId())
            		                          .toList();

             for(LeaveLedger leave : ledgerBalancedList) {

            	 double finalBalance = leaveLedgerRepository.findByIdAndCommentsEndsWith(leave.getId(), Constants.LOP).isEmpty()?
               	 balance+ leave.getCreditDays() - leave.getDebitDays() : balance;

               	leave.setBalanceDays(finalBalance);
               	leave.setModifiedDate(Instant.now());
               	leaveLedgerRepository.save(leave);

               	balance = finalBalance;

             }

            LedgerEmailModel emailModel = new LedgerEmailModel(leaveLedger.get().getEmployeeId()
            		, ledgerDetails.getUpdatedBy()
            		, new SimpleDateFormat("MM/dd/yyyy").format(new Date())
            		, new SimpleDateFormat("MM/dd/yyyy").format(Date.from(leaveLedger.get().getEntryDate()))
            		, leaveLedger.get().getCreditDays()
            		, leaveLedger.get().getDebitDays()
            		, leaveLedger.get().getBalanceDays()
            		, Constants.LEDGER_DELETE);
            
            leaveLedgerRepository.delete(leaveLedger.get());
            
            response.setStatus(true);
            response.setMessage("Leave ledger deleted successfully");
            response.setData(emailModel);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException("deleteLeaveLedger()", e, "Error", "Something went wrong");
        }
    }

    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
        LOGGER.error("{} Error : {}" + methodName, e);
        ExceptionBean exception = new ExceptionBean(Instant.now(), message, description);
        response.setStatus(false);
        response.setInformation(exception);
        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }

}
