package com.histo.staffmanagementportal.service;

import org.springframework.http.ResponseEntity;

import com.histo.staffmanagementportal.dto.EmployeeDocumentDTO;
import com.histo.staffmanagementportal.model.ModifiedDetails;

public interface EmployeeDocumentService {

	public ResponseEntity<Object> getEmployeeDocumentByEmployeeId(Integer employeeId);
	public ResponseEntity<Object> getEmployeeDocumentById(Integer documentId);
	public ResponseEntity<Object> addEmployeeHrDocument(EmployeeDocumentDTO documentDTO);
	public ResponseEntity<Object> updateEmployeeHrDocument(EmployeeDocumentDTO documentDTO,Integer documentId);
	public ResponseEntity<Object> deleteEmployeeDocumentById(Integer documentId,ModifiedDetails modifiedDetails);
	public ResponseEntity<Object> getDocumentType();
}
