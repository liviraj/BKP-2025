package com.histo.staffmanagementportal.service;

import org.springframework.http.ResponseEntity;

import com.histo.staffmanagementportal.dto.LoginDTO;
import com.histo.staffmanagementportal.model.LoginFilterModel;
import com.histo.staffmanagementportal.model.ModifiedDetails;

public interface UserService {

	public ResponseEntity<Object> findAllLogins(LoginFilterModel loginFilter);
	public ResponseEntity<Object> findByLoginId(Integer loginId);
	public ResponseEntity<Object> createUser(LoginDTO loginDto,Boolean isNewUser);
	public ResponseEntity<Object> updateUser(Integer loginId,LoginDTO loginDto);
	public ResponseEntity<Object> loginUser();
	public ResponseEntity<Object> deleteByLoginId(Integer loginId,ModifiedDetails modifiedDetails);
	
}
