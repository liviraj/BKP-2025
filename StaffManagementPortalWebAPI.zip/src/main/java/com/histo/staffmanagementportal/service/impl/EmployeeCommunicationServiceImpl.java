package com.histo.staffmanagementportal.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.dto.EmployeeCommunicationDTO;
import com.histo.staffmanagementportal.dto.EmployeeCommunicationViewDTO;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.intranet.repository.EmployeeCommunicationRepository;
import com.histo.staffmanagementportal.model.Constants;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.service.EmployeeCommunicationService;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

@Service
public class EmployeeCommunicationServiceImpl implements EmployeeCommunicationService {

	private static final Logger logger = LogManager.getLogger(EmployeeCommunicationServiceImpl.class);

	private static final String STATUS = "status";

	private final ResponseModel response;
 
    private MappingJacksonValue mappingJacksonValue;

	private final EmployeeCommunicationRepository communicationRepository;

	public EmployeeCommunicationServiceImpl(ResponseModel response, EmployeeCommunicationRepository communicationRepository) {
		this.response = response;
		this.communicationRepository = communicationRepository;
	}

	@Override
	public ResponseEntity<Object> getCommunicationByEmployeeId(Integer employeeId) {
		try {
			List<EmployeeCommunicationViewDTO> employeeCommunication = SqlConnectionSetup.getJdbcConnection().query("exec spGetEmployeeCommunicationByEmployeeId ?", BeanPropertyRowMapper.newInstance(EmployeeCommunicationViewDTO.class)
					, employeeId);

			response.setStatus(true);
			response.setData(employeeCommunication);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK		);
		} catch (Exception e) {
			return catchException("getCommunicationById()", e, "Failed", "Employee communication details not found");
		}
	}

	@Override
	public ResponseEntity<Object> saveCommunicationDetails(EmployeeCommunicationDTO communicationDto) {

		try {
			Integer employeeCommunicationId = communicationRepository.getEmployeeCommunicationId(communicationDto.getEmployeeId());
			List<EmployeeCommunicationDTO> employeeCommunicationDTO = SqlConnectionSetup.getJdbcConnection().query("exec spGetEmployeeCommunicationById ?", BeanPropertyRowMapper.newInstance(EmployeeCommunicationDTO.class)
					, employeeCommunicationId);
			if (ObjectUtils.isNotEmpty(employeeCommunicationDTO)) {
				response.setStatus(false);
		        response.setInformation(new ExceptionBean(Instant.now(), "Error", "Employee communication details exists"));
		        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
		        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
	
			}
			
			 SqlConnectionSetup.getJdbcConnection().queryForObject("exec spEmployeeCommunicationInsert ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?;",
					BeanPropertyRowMapper.newInstance(EmployeeCommunicationDTO.class),
					0,
					communicationDto.getEmployeeId(),
					communicationDto.getAddress1(),
					communicationDto.getAddress2(),
					communicationDto.getAddress3(),
					communicationDto.getCity(),
					communicationDto.getPin(),
					communicationDto.getState(),
					communicationDto.getCountry(),
					communicationDto.getPermAdd1(),
					communicationDto.getPermAdd2(),
					communicationDto.getAddress3(),
					communicationDto.getPermCity(),
					communicationDto.getPermPin(),
					communicationDto.getPermState(),
					communicationDto.getPermCountry(),
					communicationDto.getPhoneno(),
					communicationDto.getAlternateContactNumber(),
					communicationDto.getEmergencyContactName(),
					communicationDto.getEmergencyContactRelation(),
					communicationDto.getEmergencyContactNumber(),
					communicationDto.getEmergencyContactAddress1(),
					communicationDto.getEmergencyContactAddress2(),
					communicationDto.getEmergencyContactAddress3(),
					communicationDto.getCellno(),
					communicationDto.getWorkPhoneNo(),
					communicationDto.getExtension(),
					communicationDto.getEmailID(),
					communicationDto.getCreatedBy());
		
			response.setStatus(true);
			response.setData("Employee communication details created");
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CREATED);
		} catch (Exception e) {
			return catchException("saveCommunicationDetails()", e, "Error",
					"Cannot save employee communication details");
		}
	}

	@Override
	public ResponseEntity<Object> updateCommunicationDetails(EmployeeCommunicationDTO communicationDto,
			Integer communicationId) {
		try {
			EmployeeCommunicationDTO employeeCommunicationDTO = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetEmployeeCommunicationById ?", BeanPropertyRowMapper.newInstance(EmployeeCommunicationDTO.class)
					, communicationId);

			if (ObjectUtils.isEmpty(employeeCommunicationDTO)) {
				response.setStatus(false);
		        response.setInformation(new ExceptionBean(Instant.now(), "Error", "Employee communication not found"));
		        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
		        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
	
			}
			String employeeWorkStatus = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetEmploymentStatusByEmpId ?", String.class,communicationDto.getEmployeeId());
			if(ObjectUtils.equals(employeeWorkStatus, Constants.RELIEVED_STATUS)) {
				return catchException("updateCommunicationDetails()", null, "Not a active employee", "Cannot update relieved employee details");
			}
			String communicationDetail = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spEmployeeCommunicationUpdate ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?;",
					String.class,
					communicationId,
					communicationDto.getEmployeeId(),
					communicationDto.getAddress1(),
					communicationDto.getAddress2(),
					communicationDto.getAddress3(),
					communicationDto.getCity(),
					communicationDto.getPin(),
					communicationDto.getState(),
					communicationDto.getCountry(),
					communicationDto.getPermAdd1(),
					communicationDto.getPermAdd2(),
					communicationDto.getAddress3(),
					communicationDto.getPermCity(),
					communicationDto.getPermPin(),
					communicationDto.getPermState(),
					communicationDto.getPermCountry(),
					communicationDto.getPhoneno(),
					communicationDto.getAlternateContactNumber(),
					communicationDto.getEmergencyContactName(),
					communicationDto.getEmergencyContactRelation(),
					communicationDto.getEmergencyContactNumber(),
					communicationDto.getEmergencyContactAddress1(),
					communicationDto.getEmergencyContactAddress2(),
					communicationDto.getEmergencyContactAddress3(),
					communicationDto.getCellno(),
					communicationDto.getWorkPhoneNo(),
					communicationDto.getExtension(),
					communicationDto.getEmailID(),
					communicationDto.getModifiedBy());
			response.setStatus(true);
			response.setData(communicationDetail);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}catch(Exception e) {
			return catchException("updateCommunicationDetails()", e, "Failed", "Unable to update employee communication details");
		}
	}

	private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
		logger.error("{} Error : {}" + methodName, e);
		response.setStatus(false);
        response.setInformation(new ExceptionBean(Instant.now(), message, description));
        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);

	}

}
