package com.histo.staffmanagementportal.service;

import org.springframework.http.ResponseEntity;

import com.histo.staffmanagementportal.model.ComplianceCertificateInfo;
import com.histo.staffmanagementportal.model.ComplianceReportFilter;

import java.util.List;

public interface ComplianceReportService {

	public ResponseEntity<Object> getComplianceReport(ComplianceReportFilter reportFilter);
	public ResponseEntity<Object> getEmployeeType();
	public ResponseEntity<Object> getComplianceDocument(ComplianceCertificateInfo complianceDocument);

	ResponseEntity<Object> complianceExpiryEmailNotification(ComplianceReportFilter reportFilter);

	ResponseEntity<Object> complianceExpiryEmailTemplate(ComplianceReportFilter reportFilter);

}
