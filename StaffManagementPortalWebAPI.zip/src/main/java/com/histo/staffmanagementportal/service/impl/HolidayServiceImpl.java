package com.histo.staffmanagementportal.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.dto.HolidayDTO;
import com.histo.staffmanagementportal.dto.HolidayMasterDTO;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.intranet.entity.Attribute;
import com.histo.staffmanagementportal.intranet.entity.EmployeeHoliDay;
import com.histo.staffmanagementportal.intranet.entity.Holiday;
import com.histo.staffmanagementportal.intranet.entity.HolidayMaster;
import com.histo.staffmanagementportal.intranet.repository.AttributeRepository;
import com.histo.staffmanagementportal.intranet.repository.EmployeeHolidayRepository;
import com.histo.staffmanagementportal.intranet.repository.HolidayMasterRepository;
import com.histo.staffmanagementportal.intranet.repository.HolidayRepository;
import com.histo.staffmanagementportal.model.*;
import com.histo.staffmanagementportal.service.HolidayService;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;
import com.histo.staffmanagementportal.util.UsFederalHolidayResponse;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;


@Service("holidayServiceImpl")
public class HolidayServiceImpl implements HolidayService {

    private static final Logger logger = LogManager.getLogger (HolidayServiceImpl.class);

    private static final String STATUS = "status";
    private static final String OPTIONAL_TYPE = "Optional type";

    private final HolidayRepository holidayRepository;

    private final HolidayMasterRepository holidayMasterRepo;

    private MappingJacksonValue mappingJacksonValue;

    private final ResponseModel response;
    private final EmployeeHolidayRepository employeeHolidayRepository;

    private final AttributeRepository attributeRepository;

    public HolidayServiceImpl(HolidayRepository holidayRepository, HolidayMasterRepository holidayMasterRepo
            , ResponseModel response,
                              EmployeeHolidayRepository employeeHolidayRepository, AttributeRepository attributeRepository) {
        this.holidayRepository = holidayRepository;
        this.holidayMasterRepo = holidayMasterRepo;
        this.response = response;
        this.employeeHolidayRepository = employeeHolidayRepository;
        this.attributeRepository = attributeRepository;

    }

    @Override
    public ResponseEntity<Object> getHolidayDetails(FilterModel filterModel) {

        try {
            List<HolidayDTO> holidayDetailsList = SqlConnectionSetup.getJdbcConnection ().query ("exec spGetHolidays ?,?,?;",
                    BeanPropertyRowMapper.newInstance (HolidayDTO.class),
                    filterModel.getYear (),
                    filterModel.getLocationId (),
                    filterModel.getEmployeeId ());

            response.setStatus (true);
            response.setData (holidayDetailsList);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException ("getHolidayDetails()", e, "Failed", "Unable to get holiday details");
        }
    }

    @Override
    public ResponseEntity<Object> getUSHolidayList(Integer year, UsFederalHolidayResponse usFederalHolidayResponse) {

        try{
            List<HolidayDTO> holidayDetailsList = SqlConnectionSetup.getJdbcConnection ().query ("exec spGetHolidays ?,?,?;",
                BeanPropertyRowMapper.newInstance (HolidayDTO.class),
                    year,
                LocationEum.USA.getValue (),
                0);

            if (ObjectUtils.isEmpty (usFederalHolidayResponse)) {
                return catchException ("getUSHolidayList()", null, "Failed", "No valid US federal holidays found for the specified range.");
            }

            List<UsFederalHolidayResponse.HolidayData> usFedralHolidayByFilter = usFederalHolidayResponse.getData ();

            usFedralHolidayByFilter = usFedralHolidayByFilter.stream ()
                    .filter (filterValue -> holidayDetailsList.stream ()
                            .noneMatch (value -> value.getName ().equalsIgnoreCase (filterValue.getName ())))
                    .toList ();

            holidayDetailsList.clear ();

            usFedralHolidayByFilter.stream ().forEach (value -> {

                HolidayDTO holidayDTO = new HolidayDTO ();
                holidayDTO.setName (value.getName ());
                holidayDTO.setStartDate (value.getDateString ());
                holidayDTO.setEndDate (value.getDateString ());
                holidayDTO.setGovernmentHolidayDate (value.getDateString ());
                holidayDTO.setLocationName (LocationEum.USA.toString ());
                holidayDTO.setLocationId (LocationEum.USA.getValue ());
                holidayDTO.setHolidayID (0);
                holidayDTO.setHolidayMasterId (0);

                Optional<HolidayMaster> holidayMaster = holidayMasterRepo
                        .findByHolidayNameLikeIgnoreCaseAndLocationIdAndRecordStatus (
                                value.getName (),
                                LocationEum.USA.getValue (),
                                Constants.ACTIVE_RECORD_STATUS);
                if (holidayMaster.isPresent ()) {
                    holidayDTO.setHolidayMasterId (holidayMaster.get ().getHolidayId ());
                }

                holidayDetailsList.add (holidayDTO);
            });

            response.setStatus (true);
        response.setData (holidayDetailsList);
        mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
        return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
    } catch (Exception e) {
        return catchException ("getUSHolidayList()", e, "Failed", "Unable to get holiday details");
    }
    }

    @Override
    public ResponseEntity<Object> getHolidayMasterList(FilterModel filterModel) {
        try {
            List<HolidayMasterDTO> allActiveHolidayList = SqlConnectionSetup.getJdbcConnection ().query ("exec spGetHolidayMasterList ?,?;",
                    BeanPropertyRowMapper.newInstance (HolidayMasterDTO.class),
                    filterModel.getLocationId (),
                    filterModel.getStatus ());

            response.setStatus (true);
            response.setData (allActiveHolidayList);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException ("getHolidayMasterList()", e, "Failed", "Unable to get holiday details");
        }
    }

    @Override
    public ResponseEntity<Object> getFloatingHolidayMasterList(FilterModel filterModel) {
        try {
            List<HolidayMaster> allActiveHolidayList = SqlConnectionSetup.getJdbcConnection ().query ("exec spGetFloatingHolidayMasterList ?,?;",
                    BeanPropertyRowMapper.newInstance (HolidayMaster.class),
                    filterModel.getHolidayId (),
                    filterModel.getYear ());

            response.setStatus (true);
            response.setData (allActiveHolidayList);
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"data", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException ("getFloatingHolidayMasterList()", e, "Failed", "Unable to get holiday details");
        }
    }

    @Override
    public ResponseEntity<Object> addHoliday(List<HolidayDTO> holidayDTO) {
        try {

            LocationEum locationEum = LocationEum.getEnumFromString (String.valueOf (holidayDTO.get (0).getLocationId ()));
            switch (locationEum) {
                case INDIA:
                    return addHolidayDetail (0, holidayDTO.get (0), "addHoliday", new Holiday ());
                case USA:
                    return addUSHolidayDetail (0, holidayDTO, "addHoliday", null);
                default:
                    return catchException ("addHoliday()", null, "Failed", "Please select valid location.");
            }

        } catch (Exception e) {
            return catchException ("addHoliday()", e, "Failed", "Unable to add holiday details");
        }
    }

    @Override
    public ResponseEntity<Object> editHoliday(Integer id, HolidayDTO holidayDTO) {
        try {

            Optional<Holiday> holidayDetailsById = holidayRepository.findById (id);

            if (holidayDetailsById.isEmpty ()) {
                return catchException ("editHolidayDetails()", null, "Not Found", "Holiday details not found");
            }
            holidayDTO.setAddedByEmpId (holidayDetailsById.get ().getAddedBy ());
            holidayDTO.setAddedOn (InstantFormatter.InstantFormat (holidayDetailsById.get ().getAddedOn ()));

            LocationEum locationEum = LocationEum.getEnumFromString (String.valueOf (holidayDTO.getLocationId ()));

            switch (locationEum) {
                case INDIA:
                    return addHolidayDetail (id, holidayDTO, "editHolidayDetails", holidayDetailsById.get ());
                case USA:
                    return addUSHolidayDetail (id, Arrays.asList (holidayDTO), "editHolidayDetails", holidayDetailsById);
                default:
                    return catchException ("editHolidayDetails()", null, "Failed", "Please select valid location.");

            }


        } catch (Exception e) {
            return catchException ("editHolidayDetails()", e, "Failed", "Unable to edit holiday details");
        }
    }

    private ResponseEntity<Object> addUSHolidayDetail(Integer id, List<HolidayDTO> holidayDTO, String methodName, Optional<Holiday> holiday) {
        try {

            List<Holiday> overAllHolidayList = new ArrayList<> ();

            for (HolidayDTO holidayDetails : holidayDTO) {

                Instant startDate = InstantFormatter.InstantFormat (holidayDetails.getStartDate ());
                Instant endDate = InstantFormatter.InstantFormat (holidayDetails.getEndDate ());

                List<Holiday> overlapDetails = holidayRepository.findByLocationidAndStartDateBetweenAndEndDateBetween
                        (holidayDetails.getLocationId (), startDate, endDate);

                boolean isAlreadyExist = overlapDetails.stream ().anyMatch (data -> ObjectUtils.notEqual (data.getHolidayDetailId (), id));

                if (startDate.isAfter (endDate)) {
                    return catchException (methodName, null, "Failed", "Please select valid date. Start date should be before Or equal to end date");
                } else if (isAlreadyExist) {
                    return catchException (methodName, null, "Failed", String.format ("Holiday details already existing for given period StartDate(%s) and EndDate(%s)",
                            InstantFormatter.dateFormat (startDate), InstantFormatter.dateFormat (endDate)));
                }

                int noOfDays = (int) ChronoUnit.DAYS.between (startDate, endDate) + 1;

                Optional<HolidayMaster> holidayMasterRepoById = holidayMasterRepo.findByHolidayIdAndRecordStatus (holidayDetails.getHolidayMasterId (),Constants.ACTIVE_RECORD_STATUS);

                if (holidayMasterRepoById.isEmpty ()) {

                    holidayMasterRepoById = holidayMasterRepo.findByHolidayNameLikeIgnoreCaseAndLocationIdAndRecordStatus
                            (holidayDetails.getName (), holidayDetails.getLocationId (), Constants.ACTIVE_RECORD_STATUS);

                    if (holidayMasterRepoById.isEmpty ()) {

                        HolidayMaster holidayMaster = new HolidayMaster ();

                        holidayMaster.setHolidayName (holidayDetails.getName ());
                        holidayMaster.setLocationId (holidayDetails.getLocationId ());
                        holidayMaster.setAddedBy (holidayDetails.getAddedByEmpId ());
                        holidayMaster.setAddedOn (Timestamp.valueOf (holidayDetails.getAddedOn ()));
                        holidayMaster.setRecordStatus (Constants.ACTIVE_RECORD_STATUS);

                        holidayMasterRepoById = Optional.of (holidayMasterRepo.save (holidayMaster));

                    }
                }

                if (holiday.isEmpty () || (ObjectUtils.isEmpty (holiday) && id == 0)) {

                    Holiday holidayNew = new Holiday ();

                    holidayNew.setLocationid (holidayMasterRepoById.get ().getLocationId ());
                    holidayNew.setHolidayId (holidayMasterRepoById.get ());
                    holidayNew.setName (holidayMasterRepoById.get ().getHolidayName ());
                    holidayNew.setStartDate (startDate);
                    holidayNew.setEndDate (endDate);
                    holidayNew.setRecordStatus (Constants.ACTIVE_RECORD_STATUS);
                    holidayNew.setIsOptional (holidayDetails.getIsOptional ());
                    holidayNew.setModifiedBy (holidayDetails.getModifiedByEmpId ());
                    holidayNew.setModifiedDate (InstantFormatter.InstantFormat (holidayDetails.getModifiedOn ()));
                    holidayNew.setNumberOfDays (noOfDays);
                    holidayNew.setAlternateHolidayID (holidayDetails.getAlternateHolidayId ());
                    holidayNew.setAddedBy (holidayDetails.getAddedByEmpId ());
                    holidayNew.setAddedOn (InstantFormatter.InstantFormat (holidayDetails.getAddedOn ()));

                    overAllHolidayList.add (holidayNew);

                } else {
                    holiday.get ().setLocationid (holidayMasterRepoById.get ().getLocationId ());
                    holiday.get ().setHolidayId (holidayMasterRepoById.get ());
                    holiday.get ().setName (holidayMasterRepoById.get ().getHolidayName ());
                    holiday.get ().setStartDate (startDate);
                    holiday.get ().setEndDate (endDate);
                    holiday.get ().setRecordStatus (Constants.ACTIVE_RECORD_STATUS);
                    holiday.get ().setIsOptional (holidayDetails.getIsOptional ());
                    holiday.get ().setModifiedBy (holidayDetails.getModifiedByEmpId ());
                    holiday.get ().setModifiedDate (InstantFormatter.InstantFormat (holidayDetails.getModifiedOn ()));
                    holiday.get ().setNumberOfDays (noOfDays);
                    holiday.get ().setAlternateHolidayID (holidayDetails.getAlternateHolidayId ());
                    holiday.get ().setAddedBy (holidayDetails.getAddedByEmpId ());
                    holiday.get ().setAddedOn (InstantFormatter.InstantFormat (holidayDetails.getAddedOn ()));

                    overAllHolidayList.add (holiday.get ());
                }
            }

            List<Holiday> savedHoliday = holidayRepository.saveAll (overAllHolidayList);

            response.setStatus (true);
            response.setMessage ((id == 0 ? "Holiday details added successfully. " : "Holiday details updated successfully. "));
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException ("addUSHolidayDetail()", e, "Failed", "Unable to add/edit holiday details");
        }
    }

    private ResponseEntity<Object> addHolidayDetail(Integer id, HolidayDTO holidayDTO, String methodName, Holiday holiday) {
        try {

            Instant startDate = InstantFormatter.InstantFormat (holidayDTO.getStartDate ());
            Instant endDate = InstantFormatter.InstantFormat (holidayDTO.getEndDate ());

            Attribute maxFloatingHoliday = attributeRepository.findByAttributeNameAndCategory
                            (Constants.MAXI_FLOATING_HOLIDAY_ATTRIBUTE_NAME, StaffModuleName.HOLIDAY.getValue ())
                    .orElseThrow (() -> new NullPointerException ("Cannot get value for maximun floationg holiday."));

            int noOfDays = (int) ChronoUnit.DAYS.between (startDate, endDate) + 1;

            Optional<HolidayMaster> holidayMasterRepoById = holidayMasterRepo.findByHolidayIdAndRecordStatus (holidayDTO.getHolidayMasterId (),Constants.ACTIVE_RECORD_STATUS);

            if (holidayMasterRepoById.isEmpty ()) {
                return catchException (methodName, null, "Failed", "Please select valid/Active holiday type");
            }

            List<Holiday> overlapDetails = holidayRepository.findByLocationidAndStartDateBetweenAndEndDateBetween
                    (holidayMasterRepoById.get ().getLocationId (), startDate, endDate);

            boolean isAlreadyExist = overlapDetails.stream ().anyMatch (data -> ObjectUtils.notEqual (data.getHolidayDetailId (), id));

            ResponseModel isFloatingHolidayValid = validatAlternateHoliday (holidayDTO.getAlternateHolidayId (),
                    holidayDTO.getHolidayMasterId (),
                    holidayDTO.getStartDate ());

            if (startDate.isAfter (endDate)) {
                return catchException (methodName, null, "Failed", "Please select valid date. Start date should be before Or equal to end date");
            } else if (isAlreadyExist) {
                return catchException (methodName, null, "Failed", "Holiday details already existing for given period");
            } else if (ObjectUtils.notEqual (isFloatingHolidayValid.isStatus (), Boolean.TRUE)) {
                return catchException (methodName, null, "Failed", isFloatingHolidayValid.getMessage ());
            }

            long l = holidayRepository.GetTotalCountOfFloatingHoliday (holidayDTO.getStartDate (), LocationEum.INDIA.getValue ());

            if (l >= Long.parseLong (maxFloatingHoliday.getAttributeValue ())) {
                return catchException (methodName, null, "Failed", String.format ("Already added maximun of %s floating holidays for given year."
                        , maxFloatingHoliday.getAttributeValue ()));
            }

            holiday.setLocationid (holidayMasterRepoById.get ().getLocationId ());
            holiday.setHolidayId (holidayMasterRepoById.get ());
            holiday.setName (holidayMasterRepoById.get ().getHolidayName ());
            holiday.setStartDate (startDate);
            holiday.setEndDate (endDate);
            holiday.setRecordStatus (Constants.ACTIVE_RECORD_STATUS);
            holiday.setIsOptional (holidayDTO.getIsOptional ());
            holiday.setModifiedBy (holidayDTO.getModifiedByEmpId ());
            holiday.setModifiedDate (InstantFormatter.InstantFormat (holidayDTO.getModifiedOn ()));
            holiday.setNumberOfDays (noOfDays);
            holiday.setAlternateHolidayID (holidayDTO.getAlternateHolidayId ());
            holiday.setAddedBy (holidayDTO.getAddedByEmpId ());
            holiday.setAddedOn (InstantFormatter.InstantFormat (holidayDTO.getAddedOn ()));

            Holiday savedHoliday = holidayRepository.save (holiday);

            response.setStatus (true);
            response.setMessage ((id == 0 ? "Holiday details added successfully. " : "Holiday details updated successfully. ")
                    + isFloatingHolidayValid.getMessage ());
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException ("addHolidayDetail()", e, "Failed", "Unable to add/edit holiday details");
        }
    }

    private ResponseModel validatAlternateHoliday(Integer alternateHolidayId, Integer holidayId, String startDate) {
        ResponseModel responseModel = new ResponseModel ();
        responseModel.setMessage ("");
        try {

            Optional<Holiday> holidayIsFloatingIfExist = holidayRepository.getHolidayIsFloatingIfExist (holidayId, startDate, LocationEum.INDIA.getValue ()); // check if given holiday is already floating for any holiday

            if (holidayIsFloatingIfExist.isPresent ()) {
                if (alternateHolidayId == 0) {

                    long holidayCount = holidayRepository.countByHolidayId_HolidayIdAndIsOptionalAndRecordStatus (
                            holidayId,
                            Boolean.FALSE.toString (),
                            Constants.ACTIVE_RECORD_STATUS);

                    if (holidayCount > 0) {
                        responseModel.setStatus (false);
                        responseModel.setMessage (
                                String.format ("Please set %s as floating holiday for given holiday."
                                        , holidayIsFloatingIfExist.get ().getHolidayId ().getHolidayName ()));
                        return responseModel;
                    }

                } else if (!holidayIsFloatingIfExist.get ().getHolidayId ().getHolidayId ().equals (alternateHolidayId)) {
                    responseModel.setStatus (false);
                    responseModel.setMessage (
                            String.format ("Please select valid floating holiday.</br>Given holiday is already set as floating holiday for %s."
                                    , holidayIsFloatingIfExist.get ().getHolidayId ().getHolidayName ()));
                    return responseModel;
                }

            }

            if (alternateHolidayId == 0) {
                responseModel.setStatus (true);
                return responseModel;
            }

            List<Holiday> isAlternateHolidayAdded = holidayRepository.getFloatingHolidayIfExist (alternateHolidayId, startDate, LocationEum.INDIA.getValue ());

//                if(isAlternateHolidayAdded.isEmpty () && alternateHolidayId != 0){
            if (isAlternateHolidayAdded.isEmpty ()) {
                responseModel.setStatus (true);
                responseModel.setMessage ("Please set holiday details for given floating Holiday.");
                return responseModel;
            }

            Optional<Holiday> optionalFloatingHolidayList = isAlternateHolidayAdded.stream ()
                    .filter (data -> data.getIsOptional ().equalsIgnoreCase (String.valueOf (Boolean.TRUE)))
                    .findFirst ();

            Optional<HolidayMaster> alternateHolidayDetail = holidayMasterRepo
                    .findByHolidayIdAndRecordStatus (alternateHolidayId, Constants.ACTIVE_RECORD_STATUS);

            Optional<HolidayMaster> holidayDetail = holidayMasterRepo
                    .findByHolidayIdAndRecordStatus (holidayId, Constants.ACTIVE_RECORD_STATUS);

            if ( alternateHolidayDetail.isPresent () && holidayDetail.isPresent () && optionalFloatingHolidayList.isEmpty () ) {
                responseModel.setStatus (true);
                responseModel.setMessage (String.format ("Please %s as optional holiday for %s."
                        , holidayDetail.get ().getHolidayName (), alternateHolidayDetail.get ().getHolidayName ()));
                return responseModel;
            }

            if (!optionalFloatingHolidayList.get ().getAlternateHolidayID ().equals (holidayId)) {

                holidayDetail = holidayMasterRepo
                        .findByHolidayIdAndRecordStatus (optionalFloatingHolidayList.get ().getAlternateHolidayID ()
                                , Constants.ACTIVE_RECORD_STATUS);

                responseModel.setStatus (false);
                responseModel.setMessage (
                        String.format ("Given %s is already set as optional holiday for %s."
                                , alternateHolidayDetail.get ().getHolidayName (), holidayDetail.get ().getHolidayName ()));
                return responseModel;
            }

            responseModel.setStatus (true);
            return responseModel;

        } catch (Exception e) {
            catchException ("validatAlternateHoliday()", e, "Failed", "Unable to validate floating holiday details.");
            responseModel.setStatus (false);
            responseModel.setMessage ("Unable to validate floating holiday details.");
            return responseModel;
        }

    }

    @Override
    public ResponseEntity<Object> deleteHoliday(DeleteDetails deleteDetails) {
        try {
            Optional<Holiday> holidayDetails = holidayRepository.findById (deleteDetails.id ());

            if (holidayDetails.isEmpty ()) {
                return catchException (Thread.currentThread ().getStackTrace ()[1].getMethodName (), null, "Failed", "Holiday details not found.");
            }

            if(deleteDetails.locationId ().equals (LocationEum.USA.getValue ())){
                int updateRecordStatusById = holidayRepository.updateRecordStatusByHolidayDetailIdAndRecordStatus (deleteDetails.id (),
                        String.valueOf (Constants.DELETED_RECORD_STATUS),
                        InstantFormatter.InstantFormat (deleteDetails.modifiedDate ()),
                        deleteDetails.modifiedBy ());

                if (updateRecordStatusById <= 0) {
                    return catchException (Thread.currentThread ().getStackTrace ()[1].getMethodName (), null, "Failed", holidayDetails.get ().getRecordStatus ()
                            .equalsIgnoreCase (String.valueOf (Constants.DELETED_RECORD_STATUS)) ?
                            "Already deleted given holiday details" : "Unable to delete holiday details.");
                }
            }

            else{
                List<EmployeeHoliDay> isFloatingHolidayAdded = employeeHolidayRepository.findByHoliDayId_HolidayDetailId (deleteDetails.id ());

                if (ObjectUtils.isNotEmpty (isFloatingHolidayAdded) && deleteDetails.isExists ().equals (Boolean.FALSE)) {
                    response.setStatus (false);
                    response.setInformation (new ExceptionBean (Instant.now (), OPTIONAL_TYPE,
                            "Selected floating holiday is already used. </br>" +
                                    "Do you want to delete this floating holiday?</br>Note: If deleted, employee will be notified through email"));
                    mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"information", STATUS});
                    return new ResponseEntity<> (mappingJacksonValue, HttpStatus.CONFLICT);

                }

                int updateRecordStatusById = holidayRepository.updateRecordStatusByHolidayDetailIdAndRecordStatus (deleteDetails.id (),
                        String.valueOf (Constants.DELETED_RECORD_STATUS),
                        InstantFormatter.InstantFormat (deleteDetails.modifiedDate ()),
                        deleteDetails.modifiedBy ());

                if (updateRecordStatusById <= 0) {
                    return catchException (Thread.currentThread ().getStackTrace ()[1].getMethodName (), null, "Failed", holidayDetails.get ().getRecordStatus ()
                            .equalsIgnoreCase (String.valueOf (Constants.DELETED_RECORD_STATUS)) ?
                            "Already deleted given holiday details" : "Unable to delete holiday details.");
                }
                else if (Boolean.TRUE.equals (deleteDetails.isExists ())) {

                    String deletedMessage = SqlConnectionSetup.getJdbcConnection ().queryForObject ("exec spEmailToToDeleteEmployeeFloatingHoliday ?",
                            BeanPropertyRowMapper.newInstance (String.class),
                            deleteDetails.id ());

                    response.setStatus (true);
                    response.setMessage (String.format ("Holiday details deleted successfully. %s", deletedMessage));
                    mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
                    return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);
                }
            }

            response.setStatus (true);
            response.setMessage ("Holiday details deleted successfully");
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException (Thread.currentThread ().getStackTrace ()[1].getMethodName (), e, "Failed", "Unable to delete holiday details");
        }
    }

    @Override
    public ResponseEntity<Object> addHoliday(HolidayMasterDTO holidayDTO) {
        try {
            Optional<HolidayMaster> holidayDetails = holidayMasterRepo.findByHolidayNameLikeIgnoreCaseAndLocationIdAndRecordStatus
                    (holidayDTO.getHolidayName (), holidayDTO.getLocationId (), Constants.ACTIVE_RECORD_STATUS);

            if (holidayDetails.isPresent ()) {
                return catchException ("addHoliday()", null, "Failed", "Given holiday details already exist");
            }

            HolidayMaster holidayMaster = new HolidayMaster ();

            holidayMaster.setHolidayName (holidayDTO.getHolidayName ());
            holidayMaster.setLocationId (holidayDTO.getLocationId ());
            holidayMaster.setAddedBy (holidayDTO.getAddedByEmpId ());
            holidayMaster.setAddedOn (Timestamp.valueOf (holidayDTO.getAddedOn ()));
            holidayMaster.setRecordStatus (Constants.ACTIVE_RECORD_STATUS);

            HolidayMaster savedDetails = holidayMasterRepo.save (holidayMaster);

            response.setStatus (true);
            response.setMessage ("Holiday details added successfully. ");
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException ("addHoliday()", e, "Failed", "Unable to add holiday details");
        }
    }

    @Override
    public ResponseEntity<Object> editHoliday(Integer id, HolidayMasterDTO holidayDTO) {
        try {

            Optional<HolidayMaster> holidayMaster = holidayMasterRepo.findById (id);

            if (holidayMaster.isEmpty ()) {
                return catchException ("editHoliday()", null, "Failed", "No value present");
            }
            Optional<HolidayMaster> holidayDetails = holidayMasterRepo.findByHolidayNameLikeIgnoreCaseAndLocationIdAndRecordStatus
                    (holidayDTO.getHolidayName (), holidayDTO.getLocationId (), Constants.ACTIVE_RECORD_STATUS);

            boolean isAlreadyExist = holidayDetails.stream ().anyMatch (data -> !data.getHolidayId ().equals (id));

            if (isAlreadyExist) {
                return catchException ("editHoliday()", null, "Failed", "Given holiday details already exist");
            }

            holidayMaster.get ().setHolidayName (holidayDTO.getHolidayName ());
            holidayMaster.get ().setLocationId (holidayDTO.getLocationId ());
            holidayMaster.get ().setModifiedBy (holidayDTO.getModifiedByEmpId ());
            holidayMaster.get ().setModifiedOn (Timestamp.valueOf (holidayDTO.getModifiedOn ()));
            holidayMaster.get ().setRecordStatus (Constants.ACTIVE_RECORD_STATUS);

            HolidayMaster savedDetails = holidayMasterRepo.save (holidayMaster.get ());

            response.setStatus (true);
            response.setMessage ("Holiday details updated successfully");
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException ("editHoliday()", e, "Failed", "Unable to update holiday details");
        }
    }

    @Override
    public ResponseEntity<Object> deleteHolidayMaster(DeleteDetails deleteDetails) {
        try {
            Optional<HolidayMaster> holidayDetails = holidayMasterRepo.findById (deleteDetails.id ());

            List<Holiday> isHolidayAdded = holidayRepository
                    .findByHolidayId_HolidayIdAndRecordStatusAndAlternateHolidayID (deleteDetails.id (), Constants.ACTIVE_RECORD_STATUS);

            if (holidayDetails.isEmpty ()) {
                return catchException ("deleteHoliday()", null, "Failed", "Holiday details not found.");
            } else if (ObjectUtils.isNotEmpty (isHolidayAdded)) {
                return catchException ("deleteHoliday()", null, "Failed", "Holiday details added for selected holiday name.</br>" +
                        " Please delete holiday details( In ADD HOLIDAY screen) and try deleting here.");
            }

            int updateRecordStatusById = holidayMasterRepo
                    .updateRecordStatusByHolidayIdAndRecordStatus (
                            deleteDetails.id (),
                            String.valueOf (Constants.DELETED_RECORD_STATUS),
                            deleteDetails.modifiedBy (),
                            Timestamp.valueOf (deleteDetails.modifiedDate ()));

            if (updateRecordStatusById <= 0) {
                return catchException ("deleteHoliday()", null, "Failed", holidayDetails.get ().getRecordStatus ()
                        .equalsIgnoreCase (String.valueOf (Constants.DELETED_RECORD_STATUS)) ?
                        "Already deleted given holiday details" : "Unable to delete holiday details.");
            }

            response.setStatus (true);
            response.setMessage ("Holiday details deleted successfully");
            mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"message", STATUS});
            return new ResponseEntity<> (mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            return catchException ("deleteHoliday()", e, "Failed", "Unable to delete holiday details");
        }
    }


    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
        logger.error ("{} Error : {}", methodName, e);
        response.setStatus (false);
        response.setInformation (new ExceptionBean (Instant.now (), message, description));
        mappingJacksonValue = ResponseUtil.responseFilter (response, new String[]{"information", STATUS});
        return new ResponseEntity<> (mappingJacksonValue, HttpStatus.CONFLICT);
    }
}
