package com.histo.staffmanagementportal.service;

import com.histo.staffmanagementportal.model.FilterModel;
import org.springframework.http.ResponseEntity;

public interface FilterService {
	public ResponseEntity<Object> getEmployeeName();
	public ResponseEntity<Object> getLocation();
	public ResponseEntity<Object> getRoleName();
	public ResponseEntity<Object> getSatus();
	public ResponseEntity<Object> getEmployeeStatus();
	public ResponseEntity<Object> getEmploymentType();
	public ResponseEntity<Object> getSection();
	public ResponseEntity<Object> getDesignation();
	public ResponseEntity<Object> getClinicalHandler();
	public ResponseEntity<Object> getEmployeeNameFromLogin();
	public ResponseEntity<Object> getLeaveStatus();
	ResponseEntity<Object> getPayRollDetails();
	ResponseEntity<Object> getRequestStatus();

	ResponseEntity<Object> getHolidayDetails(FilterModel filterModel);

}
