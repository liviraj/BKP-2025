package com.histo.staffmanagementportal.service.impl;

import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.histo.staffmanagementportal.intranet.entity.Document;
import com.histo.staffmanagementportal.intranet.repository.DocumentRepository;
import com.histo.staffmanagementportal.model.*;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.dto.EmployeeDocumentDTO;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.helper.DateValidation;
import com.histo.staffmanagementportal.intranet.repository.EmployeeDocumentRepository;
import com.histo.staffmanagementportal.service.EmployeeDocumentService;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;


@Service
public class EmployeeDocumentServiceImpl implements EmployeeDocumentService {

	private static final Logger logger = LogManager.getLogger(EmployeeDocumentServiceImpl.class);

	private static final String STATUS = "status";

	@Autowired
    private ResponseModel response;

    private MappingJacksonValue mappingJacksonValue;

    private final EmployeeDocumentRepository documentRepository;

	private final DocumentRepository documentDetailRepository;

	public EmployeeDocumentServiceImpl(EmployeeDocumentRepository documentRepository, DocumentRepository documentDetailRepository) {
		this.documentRepository = documentRepository;
		this.documentDetailRepository = documentDetailRepository;
	}

	@Override
	public ResponseEntity<Object> getEmployeeDocumentByEmployeeId(Integer employeeId) {
	 try {
		List<EmployeeDocumentList> employeeDocuments = SqlConnectionSetup.getJdbcConnection().query("exec spGetEmployeeDocumentList ?;",
				BeanPropertyRowMapper.newInstance(EmployeeDocumentList.class),
				employeeId);
		response.setStatus(true);
		response.setData(employeeDocuments);
		mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
		return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
	}
	 catch(Exception e) {
		return catchException("getEmployeeDocumentByEmployeeId()", e, "Error", "Employee documents not found");
	}
	}

	@Override
	public ResponseEntity<Object> getEmployeeDocumentById(Integer documentId) {
		try {
			List<EmployeeDocumentDTO> employeeDocument = SqlConnectionSetup.getJdbcConnection().query("exec spGetDocumentById ?;",
					BeanPropertyRowMapper.newInstance(EmployeeDocumentDTO.class),
					documentId);
			if(ObjectUtils.isEmpty(employeeDocument)) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(),"Error","Employee document not found"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"information",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}

			List<Document> documentDetails = documentDetailRepository.findByDocumentIdAndRecordStatusAndDocumentType (documentId,
					Constants.ACTIVE_RECORD_STATUS,
					StaffModuleName.HRDOCUMENT.getValue ());

			employeeDocument.get (0).setDocumentList (documentDetails);
			response.setStatus(true);
			response.setData(employeeDocument.get(0));
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}
		catch(Exception e) {
				return catchException("getEmployeeDocumentByEmployeeId()", e, "Error", "Employee documents not found");
		}
	}

	@Override
	public ResponseEntity<Object> addEmployeeHrDocument(EmployeeDocumentDTO documentDTO) {
		try {
			if(DateValidation.validateDate(documentDTO.getDocumentDate(), documentDTO.getExpiryDate())) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(),"Invalid date","Expiry date should not lesser than document date"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"information",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
			EmployeeDocumentDTO employeeDocument = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spEmployeeDocumentInsert ?,?,?,?,?,?,?,?,?;", BeanPropertyRowMapper.newInstance(EmployeeDocumentDTO.class) ,
					0,
					documentDTO.getEmployeeId(),
					ObjectUtils.isNotEmpty(documentDTO.getDocumentDate())?documentDTO.getDocumentDate()
							:"",
					documentDTO.getDocumentTypeId(),
					documentDTO.getDescription(),
					documentDTO.getDocumentName(),
					documentDTO.getDocumentImage(),
					documentDTO.getModifiedBy(),
					ObjectUtils.isNotEmpty(documentDTO.getExpiryDate())?documentDTO.getExpiryDate()
							:"");

			if(ObjectUtils.isNotEmpty (employeeDocument)){
				for(Document documentDetails : documentDTO.getDocumentList ()){

					documentDetails.setDocumentId (employeeDocument.getDocumentId ());
					documentDetails.setDocumentType (StaffModuleName.HRDOCUMENT.getValue ());
					documentDetails.setCreatedBy (documentDTO.getModifiedBy());
					documentDetails.setRecordStatus(Constants.ACTIVE_RECORD_STATUS);

					Document savedDocumentDetails = documentDetailRepository.save (documentDetails);
				}

			}

			response.setStatus(true);
			response.setData(employeeDocument);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}
		catch(Exception e) {
			return catchException("addEmployeeHrDocument()", e, "Error", "Cannot add employee documents");
	}
	}

	@Override
	public ResponseEntity<Object> updateEmployeeHrDocument(EmployeeDocumentDTO documentDTO, Integer documentId) {
		try {
			List<EmployeeDocumentDTO> employeeDocument = SqlConnectionSetup.getJdbcConnection().query("exec spGetDocumentById ?;",
					BeanPropertyRowMapper.newInstance(EmployeeDocumentDTO.class),
					documentId);
			if(ObjectUtils.isEmpty(employeeDocument)) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(),"Error","Employee document not found"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"information",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
			else if(DateValidation.validateDate(documentDTO.getDocumentDate(), documentDTO.getExpiryDate())) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(),"Invalid date","Expiry date should not lesser than document date"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"information",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
			String employeeWorkStatus = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetEmploymentStatusByEmpId ?", String.class,documentDTO.getEmployeeId());
			if(ObjectUtils.equals(employeeWorkStatus, Constants.RELIEVED_STATUS)) {
				return catchException("updateEmployeeHrDocument()", null, "Not a active employee", "Cannot update relieved employee details");
			}
			 SqlConnectionSetup.getJdbcConnection().queryForObject("exec spEmployeeDocumentUpdate ?,?,?,?,?,?,?,?,?,?", BeanPropertyRowMapper.newInstance(EmployeeDocumentDTO.class) ,
					documentId,
					documentDTO.getEmployeeId(),
					ObjectUtils.isNotEmpty(documentDTO.getDocumentDate())?documentDTO.getDocumentDate()
							:"",
					documentDTO.getDescription(),
					documentDTO.getDocumentTypeId(),
					documentDTO.getDocumentName(),
					documentDTO.getDocumentImage(),
					documentDTO.getModifiedBy(),
					ObjectUtils.isNotEmpty(documentDTO.getExpiryDate())?documentDTO.getExpiryDate()
							:"",
					Constants.ACTIVE_RECORD_STATUS);

			documentDTO.getDocumentList ().stream ().forEach (document ->{
					if(document.getId () == null){

						document.setDocumentId (documentId);
						document.setDocumentType (StaffModuleName.HRDOCUMENT.getValue ());
						document.setCreatedBy (documentDTO.getModifiedBy ());
						Document savedDocumentDetails = documentDetailRepository.save (document);

					}
					else{
						Optional<Document> existingDocumentDetails = documentDetailRepository.findByIdAndRecordStatusAndDocumentType (
								document.getId (),
								Constants.ACTIVE_RECORD_STATUS,
								StaffModuleName.HRDOCUMENT.getValue ());

						existingDocumentDetails.get ().setRecordStatus (document.getRecordStatus ());
						existingDocumentDetails.get ().setModifiedBy (documentDTO.getModifiedBy ());
						documentDetailRepository.save (existingDocumentDetails.get ());

					}
				});


			response.setStatus(true);
			response.setData("Employee document updated successfully");
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}
		catch(Exception e) {
			return catchException("updateEmployeeHrDocument()", e, "Error", "Cannot update employee document");
		}
	}

	@Override
	public ResponseEntity<Object> getDocumentType() {
		try {
			List<DocumentType> documentType = SqlConnectionSetup.getJdbcConnection().query("exec spGetDocumentType", BeanPropertyRowMapper.newInstance(DocumentType.class) );
			response.setStatus(true);
			response.setData(documentType);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}catch(Exception e) {
			return catchException("getDocumentType()", e, "Error", "Unable get employee document type");
		}
	}
	private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
		logger.error("{} Error : {}" + methodName, e);
		ExceptionBean exception = new ExceptionBean(Instant.now(), message, description);
		response.setStatus(false);
		response.setInformation(exception);
		mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information",STATUS});
		return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
	}

	@Override
	public ResponseEntity<Object> deleteEmployeeDocumentById(Integer documentId,ModifiedDetails modifiedDetails) {
		try {
			int updateRecordStatusById = documentRepository.updateRecordStatusById(Constants.DELETED_RECORD_STATUS,documentId,modifiedDetails.modifiedBy(),
					InstantFormatter.InstantFormat(modifiedDetails.modifiedDate()));
			if(updateRecordStatusById <= 0) {
				
				return catchException("deleteEmployeeDocumentById()", null,"Error","Employee document not found");
				
			}

			response.setStatus(true);
			response.setMessage("Employee document deleted successfully");
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"message",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}
		catch(Exception e) {
				return catchException("deleteEmployeeDocumentById()", e, "Error", "Cannot delete Employee document");
		}
	}

}
