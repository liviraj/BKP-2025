package com.histo.staffmanagementportal.service;

import org.springframework.http.ResponseEntity;
import com.histo.staffmanagementportal.dto.EmployeeDTO;
import com.histo.staffmanagementportal.model.EmployeeSearchModel;

public interface EmployeeService {
	
	public ResponseEntity<Object> getEmployeeByFilter(EmployeeSearchModel employeeSearchModel);
	public ResponseEntity<Object> getEmployeeById(Integer id);
	public ResponseEntity<Object> saveEmployee(EmployeeDTO employee,Integer loginId);
	public ResponseEntity<Object> updateEmployee(EmployeeDTO employee,Integer id);
	public ResponseEntity<Object> getEmployeeNameFromLogin(Integer loginId);
	
}
