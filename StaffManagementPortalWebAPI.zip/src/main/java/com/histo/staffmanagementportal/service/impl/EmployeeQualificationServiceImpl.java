package com.histo.staffmanagementportal.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.dto.EmployeeQualificationDTO;
import com.histo.staffmanagementportal.dto.EmployeeQualificationViewDTO;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.helper.DateValidation;
import com.histo.staffmanagementportal.intranet.entity.Document;
import com.histo.staffmanagementportal.intranet.repository.DocumentRepository;
import com.histo.staffmanagementportal.intranet.repository.EmployeeQualificationRepository;
import com.histo.staffmanagementportal.model.*;
import com.histo.staffmanagementportal.service.EmployeeQualificationService;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeQualificationServiceImpl implements EmployeeQualificationService{

	private static final Logger logger = LogManager.getLogger(EmployeeQualificationServiceImpl.class);

	private static final String STATUS = "status";

	@Autowired
	private ResponseModel response;

	private MappingJacksonValue mappingJacksonValue;

	private final EmployeeQualificationRepository qualificationRepo;

	private final DocumentRepository documentRepository;

	public EmployeeQualificationServiceImpl(EmployeeQualificationRepository qualificationRepo, DocumentRepository documentRepository) {
		this.qualificationRepo = qualificationRepo;
		this.documentRepository = documentRepository;
	}

	@Override
	public ResponseEntity<Object> getEmployeeQualificationByEmployeeId(Integer employeeId) {
		try {
			List<EmployeeQualificationViewDTO> employeeQualificationViewDTO = SqlConnectionSetup.getJdbcConnection().query("exec GetEmployeeQualificationEmployeeID ?", BeanPropertyRowMapper.newInstance(EmployeeQualificationViewDTO.class)
					, employeeId);
			response.setStatus(true);
			response.setData(employeeQualificationViewDTO);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}
		catch(Exception e) {
			return catchException("getEmployeeQualificationByEmployeeId()", e, "Employee qualification details not found");
		}
	}

	@Override
	public ResponseEntity<Object> addEmployeeQualification(EmployeeQualificationDTO qualificationDTO) {
		try {

			if(DateValidation.validateDate(qualificationDTO.getCourseStartDate(), qualificationDTO.getCourseEndDate())) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(),"Error","Course end date should not be lesser than start date"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"information",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
			EmployeeQualificationDTO employeeQualificationDTO = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spEmployeeQualificationInsert ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?", BeanPropertyRowMapper.newInstance(EmployeeQualificationDTO.class),
					0,
					qualificationDTO.getEmployeeId()
					,qualificationDTO.getQualification()
					,qualificationDTO.getInstitution()
					,qualificationDTO.getMajorSubject()
					,qualificationDTO.getType()
					,qualificationDTO.getValue()
					,qualificationDTO.getCourseDuration()
					, qualificationDTO.getCourseStartDate()
					,qualificationDTO.getCourseEndDate()
					,qualificationDTO.getUniversity()
					,qualificationDTO.getModifiedBy()
					,qualificationDTO.getEmployeeImage()
					,qualificationDTO.getIsPartOfCLEP()
					,qualificationDTO.getLocation()
					,qualificationDTO.getEmployeeImageBinary());

			if(ObjectUtils.isNotEmpty (employeeQualificationDTO)){
				for(Document documentDetails : qualificationDTO.getDocumentDetails ()){

					documentDetails.setDocumentId (employeeQualificationDTO.getEmpQualificationID ());
					documentDetails.setDocumentType (StaffModuleName.QUALIFICATION.getValue ());

					Document savedDocumentDetails = documentRepository.save (documentDetails);
				}

			}

			response.setStatus(true);
			response.setData(employeeQualificationDTO);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}catch(Exception e) {
			return catchException("addEmployeeQualification()", e, "Cannot save employee qualification details");
		}
	}

	@Override
	public ResponseEntity<Object> updateEmployeeQualification(EmployeeQualificationDTO qualificationDTO,
															  Integer qualificationId) {
		try {
			List<EmployeeQualificationDTO> employeeQualificationById = SqlConnectionSetup.getJdbcConnection().query("exec GetEmployeeQualificationByID ?", BeanPropertyRowMapper.newInstance(EmployeeQualificationDTO.class)
					, qualificationId);
			if(employeeQualificationById.isEmpty()) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(),"Error","Qualification details not found"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"information",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
			else if(DateValidation.validateDate(qualificationDTO.getCourseStartDate(), qualificationDTO.getCourseEndDate())) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(),"Error","Course end date must be greater than start date"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"information",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
			String employeeWorkStatus = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetEmploymentStatusByEmpId ?", String.class,qualificationDTO.getEmployeeId());
			if(ObjectUtils.equals(employeeWorkStatus, Constants.RELIEVED_STATUS)) {
				return catchException("updateEmployeeQualification()", null, "Cannot update relieved employee details");
			}
			EmployeeQualificationDTO employeeQualificationDTO = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spEmployeeQualificationUpdate ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?", BeanPropertyRowMapper.newInstance(EmployeeQualificationDTO.class),
					qualificationId
					,qualificationDTO.getEmployeeId()
					,qualificationDTO.getQualification()
					,qualificationDTO.getInstitution()
					,qualificationDTO.getMajorSubject()
					,qualificationDTO.getType()
					,qualificationDTO.getValue()
					,qualificationDTO.getCourseDuration()
					,qualificationDTO.getCourseStartDate()
					,qualificationDTO.getCourseEndDate()
					,qualificationDTO.getUniversity()
					,qualificationDTO.getModifiedBy()
					,qualificationDTO.getEmployeeImage()
					,qualificationDTO.getIsPartOfCLEP()
					,qualificationDTO.getLocation()
					,qualificationDTO.getEmployeeImageBinary()
					,Constants.ACTIVE_RECORD_STATUS);

			if(ObjectUtils.isNotEmpty (employeeQualificationDTO)){
				qualificationDTO.getDocumentDetails ().stream ().forEach (document ->{
					if(document.getId () == null){
						document.setDocumentId (employeeQualificationDTO.getEmpQualificationID ());
						document.setDocumentType (StaffModuleName.QUALIFICATION.getValue ());
						document.setCreatedBy (qualificationDTO.getModifiedBy ());

						Document savedDocumentDetails = documentRepository.save (document);

					}
					else{

						Optional<Document> existingDocumentDetails = documentRepository.findByIdAndRecordStatusAndDocumentType (
								document.getId (),
								Constants.ACTIVE_RECORD_STATUS,
								StaffModuleName.QUALIFICATION.getValue ());

						existingDocumentDetails.get ().setRecordStatus (document.getRecordStatus ());
						existingDocumentDetails.get ().setModifiedBy (qualificationDTO.getModifiedBy ());

						documentRepository.save (existingDocumentDetails.get ());
					}
				});


			}
			response.setStatus(true);
			response.setData(employeeQualificationDTO);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}catch(Exception e) {
			return catchException("updateEmployeeQualification()", e, "Cannot update employee qualification details");
		}
	}
	@Override
	public ResponseEntity<Object> getEmployeeQualificationById(Integer qualificationId) {
		try {
			EmployeeQualificationDTO employeeQualificationDTO = SqlConnectionSetup.getJdbcConnection().queryForObject("exec GetEmployeeQualificationByID ?"
					, BeanPropertyRowMapper.newInstance(EmployeeQualificationDTO.class)
					, qualificationId);

			if(employeeQualificationDTO == null ||ObjectUtils.isEmpty (employeeQualificationDTO) ){
				return catchException("getEmployeeQualificationByEmployeeId()", null, "Employee qualification details not found");
			}

			List<Document> documentDetails = documentRepository.findByDocumentIdAndRecordStatusAndDocumentType (qualificationId,
					Constants.ACTIVE_RECORD_STATUS,
					StaffModuleName.QUALIFICATION.getValue ());

			employeeQualificationDTO.setDocumentDetails (documentDetails);

			response.setStatus(true);
			response.setData(employeeQualificationDTO);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}
		catch(Exception e) {
			return catchException("getEmployeeQualificationByEmployeeId()", e, "Employee qualification details not found");
		}
	}
	@Override
	public ResponseEntity<Object> getQualificationName() {
		try {
			List<QualificationName> qualificationName = SqlConnectionSetup.getJdbcConnection().query("exec spFetchQualificationDetails", BeanPropertyRowMapper.newInstance(QualificationName.class));
			response.setStatus(true);
			response.setData(qualificationName);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}
		catch(Exception e) {
			return catchException("getQualificationName()", e, "Cannot fetch qualification value");
		}
	}
	@Override
	public ResponseEntity<Object> deleteEmployeeQualificationById(Integer qualificationId,ModifiedDetails modifiedDetails) {
		try {
			int updateRecordStatusById = qualificationRepo.updateRecordStatusById(Constants.DELETED_RECORD_STATUS,qualificationId,modifiedDetails.modifiedBy(),
					InstantFormatter.InstantFormat(modifiedDetails.modifiedDate()));

			if(updateRecordStatusById <= 0) {
				return catchException("deleteEmployeeQualificationById()", null, "Employee Qualification details not found");
			}

			response.setStatus(true);
			response.setMessage("Qualification details deleted successfully");
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"message",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}
		catch(Exception e) {
			return catchException("deleteEmployeeQualificationById()", e, "Cannot delete qualification value");
		}
	}
	private ResponseEntity<Object> catchException(String methodName, Exception e, String description) {
		logger.error("{} Error : {}" + methodName, e);
		ExceptionBean exception = new ExceptionBean(Instant.now(), "Error", description);
		response.setStatus(false);
		response.setInformation(exception);
		mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information",STATUS});
		return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
	}


}
