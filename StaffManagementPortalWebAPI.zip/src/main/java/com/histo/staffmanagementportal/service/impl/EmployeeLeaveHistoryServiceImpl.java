package com.histo.staffmanagementportal.service.impl;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import javax.transaction.Transactional;

import com.histo.deputation.entity.DeputationHistory;
import com.histo.deputation.repository.DeputationHistoryRepository;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.intranet.entity.EmployeeLeaveDetails;
import com.histo.staffmanagementportal.intranet.entity.EmployeeLeaveRequestMaster;
import com.histo.staffmanagementportal.intranet.entity.LeaveLedger;
import com.histo.staffmanagementportal.intranet.entity.LeaveTypeMaster;
import com.histo.staffmanagementportal.intranet.entity.PayRollMaster;
import com.histo.staffmanagementportal.intranet.entity.SpecialLeaveLedger;
import com.histo.staffmanagementportal.intranet.entity.USSickLeaveDetails;
import com.histo.staffmanagementportal.intranet.repository.CompanyLeavePolicyRepository;
import com.histo.staffmanagementportal.intranet.repository.CompanyPayCycleRepository;
import com.histo.staffmanagementportal.intranet.repository.EmployeeCompensationRepository;
import com.histo.staffmanagementportal.intranet.repository.EmployeeLeaveDetailsRepository;
import com.histo.staffmanagementportal.intranet.repository.EmployeeLeaveRequestMasterRepository;
import com.histo.staffmanagementportal.intranet.repository.LeaveLedgerRepository;
import com.histo.staffmanagementportal.intranet.repository.LeaveTypeMasterRepository;
import com.histo.staffmanagementportal.intranet.repository.LoginRepository;
import com.histo.staffmanagementportal.intranet.repository.PayRollMasterRepository;
import com.histo.staffmanagementportal.intranet.repository.SpecialLeaveLedgerRepository;
import com.histo.staffmanagementportal.intranet.repository.SpecialLeavesDebitMasterRepository;
import com.histo.staffmanagementportal.intranet.repository.USSickLeaveDetailsRepository;
import com.histo.staffmanagementportal.model.ApproveOrRejectLeaveDetails;
import com.histo.staffmanagementportal.model.CancelRequestModel;
import com.histo.staffmanagementportal.model.Constants;
import com.histo.staffmanagementportal.model.LeaveDebitModel;
import com.histo.staffmanagementportal.model.LeaveDetailsRecord;
import com.histo.staffmanagementportal.model.LeaveHistoryFilter;
import com.histo.staffmanagementportal.model.LeaveRequestDetails;
import com.histo.staffmanagementportal.model.LeaveRequestQueue;
import com.histo.staffmanagementportal.model.LeaveStatusEnum;
import com.histo.staffmanagementportal.model.LeaveTypeEnum;
import com.histo.staffmanagementportal.model.LocationEum;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.service.EmployeeLeaveHistoryService;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;

@Service
public class EmployeeLeaveHistoryServiceImpl implements EmployeeLeaveHistoryService {

	private static final Logger logger = LogManager.getLogger(EmployeeLeaveHistoryServiceImpl.class);
	private static final String STATUS = "status";


	private final ResponseModel response;
	private final EmployeeLeaveRequestServiceImpl employeeLeaveRequestServiceImpl;
	private final EmployeeLeaveRequestMasterRepository leaveRequestMasterRepo;
	private final EmployeeLeaveDetailsRepository leaveDetailsRepository;
	private final LeaveTypeMasterRepository leaveTypeMasterRepo;
	private final LeaveLedgerRepository leaveLedgerRepository;
	private final DeputationHistoryRepository deputationHistoryRepository;
	private final USSickLeaveDetailsRepository usSickLeaveDetailsRepository;
	private final SpecialLeaveLedgerRepository leavesDebitDetailRepository;
	private final SpecialLeavesDebitMasterRepository leavesDebitMasterRepository;
	private final PayRollMasterRepository payRollMasterRepo;
	private final LoginRepository loginRepository;
	MappingJacksonValue mappingJacksonValue;

	public EmployeeLeaveHistoryServiceImpl(ResponseModel response,
			EmployeeLeaveRequestServiceImpl employeeLeaveRequestServiceImpl,
			EmployeeLeaveRequestMasterRepository leaveRequestMasterRepo, LeaveTypeMasterRepository leaveTypeMasterRepo,
			EmployeeLeaveDetailsRepository leaveDetailsRepository,
			LeaveLedgerRepository leaveLedgerRepository, DeputationHistoryRepository deputationHistoryRepository,
			CompanyLeavePolicyRepository companyLeavePolicyRepository,
			EmployeeCompensationRepository employeeCompensationRepository,
			CompanyPayCycleRepository companyPayCycleRepository,
			SpecialLeaveLedgerRepository leavesDebitDetailRepository,
			SpecialLeavesDebitMasterRepository leavesDebitMasterRepository,
			USSickLeaveDetailsRepository usSickLeaveDetailsRepository, LoginRepository loginRepository, PayRollMasterRepository payRollMasterRepo) {
		super();
		this.response = response;
		this.employeeLeaveRequestServiceImpl = employeeLeaveRequestServiceImpl;
		this.leaveRequestMasterRepo = leaveRequestMasterRepo;
		this.leaveDetailsRepository = leaveDetailsRepository;
		this.leaveTypeMasterRepo = leaveTypeMasterRepo;
		this.leaveLedgerRepository = leaveLedgerRepository;
		this.deputationHistoryRepository = deputationHistoryRepository;
		this.usSickLeaveDetailsRepository = usSickLeaveDetailsRepository;
		this.leavesDebitDetailRepository = leavesDebitDetailRepository;
		this.leavesDebitMasterRepository = leavesDebitMasterRepository;
		this.payRollMasterRepo = payRollMasterRepo;
		this.loginRepository = loginRepository;

	}

	@Override
	public ResponseEntity<Object> getEmployeeLeaveHistory(LeaveHistoryFilter leaveHistoryFilter) {
		try {
			List<LeaveRequestQueue> leaveRequestQueue = SqlConnectionSetup.getJdbcConnection().query(
					"exec GetleaveRequestQueue ?,?,?,?,?,?,?;", BeanPropertyRowMapper.newInstance(LeaveRequestQueue.class),
					leaveHistoryFilter.getLocationId(), leaveHistoryFilter.getEmployeeId(),
					leaveHistoryFilter.getFromDate(), leaveHistoryFilter.getToDate(), leaveHistoryFilter.getStatus(),
					leaveHistoryFilter.getLeaveType(),
					leaveHistoryFilter.getSupervisorEmployeeId());

			response.setData(leaveRequestQueue);
			response.setStatus(true);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch (Exception e) {
			return catchException("getEmployeeLeaveHistory()", e, "Failed", "Cannot fetch leave request queue");
		}
	}

	@Override
	public ResponseEntity<Object> getEmployeeLeaveDetails(Integer leaveRequestId) {
		try {
			List<EmployeeLeaveDetails> employeeLeaveDetails = leaveDetailsRepository
					.findByLeaveRequestId_Id(leaveRequestId);
			
			boolean isPartiallyApproved = employeeLeaveDetails.stream()
					.allMatch(l -> l.getApprovalStatus().equalsIgnoreCase(Constants.CANCELLED_STATUS)
							|| l.getApprovalStatus().equalsIgnoreCase(Constants.REJECTED_STATUS));

			if (isPartiallyApproved) {
				String message = employeeLeaveDetails.stream()
						.allMatch(l -> l.getApprovalStatus().equalsIgnoreCase(Constants.CANCELLED_STATUS))
								? "Leave Request has been already cancelled"
								: employeeLeaveDetails.stream().allMatch(
										l -> l.getApprovalStatus().equalsIgnoreCase(Constants.REJECTED_STATUS))
												? "Leave Request has been already rejected"
												: "Unexpected request";

				response.setInformation(new ExceptionBean(Instant.now(), "Already reviewed", message));
				response.setStatus(false);
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}

			List<LeaveDetailsRecord> leaveDetailsRecord = new ArrayList<>();
			ApproveOrRejectLeaveDetails leaveDetail = new ApproveOrRejectLeaveDetails();

			EmployeeLeaveRequestMaster employeeLeaveRequest = leaveRequestMasterRepo.findById(leaveRequestId)
					.orElseThrow (() -> new NullPointerException ("Employee leave request for given id ids not found."));

			String employeeName = SqlConnectionSetup.getJdbcConnection().queryForObject(
					"EXEC spGetEmployeeNameById ?", String.class, employeeLeaveRequest.getEmployeeId());
			employeeLeaveDetails.stream().forEach(employeeLeaveDetail -> {

				if (employeeLeaveRequest.getLeaveFrom().equals(employeeLeaveDetail.getLeaveDate())
						&& employeeLeaveRequest.getLeaveFromForH().equals("H")) {
					leaveDetailsRecord.add(new LeaveDetailsRecord(employeeLeaveDetail.getId(),
							InstantFormatter.InstantFormat(employeeLeaveDetail.getLeaveDate()), "Half Day",
							employeeLeaveDetail.getApprovalStatus(),LeaveStatusEnum.getEnumValueFromString(employeeLeaveDetail.getApprovalStatus())));
				} else if (employeeLeaveRequest.getLeaveTo().equals(employeeLeaveDetail.getLeaveDate())
						&& employeeLeaveRequest.getLeaveToForH().equals("H")) {
					leaveDetailsRecord.add(new LeaveDetailsRecord(employeeLeaveDetail.getId(),
							InstantFormatter.InstantFormat(employeeLeaveDetail.getLeaveDate()), "Half Day",
							employeeLeaveDetail.getApprovalStatus(),LeaveStatusEnum.getEnumValueFromString(employeeLeaveDetail.getApprovalStatus())));
				} else {
					leaveDetailsRecord.add(new LeaveDetailsRecord(employeeLeaveDetail.getId(),
							InstantFormatter.InstantFormat(employeeLeaveDetail.getLeaveDate()), "Full Day",
							employeeLeaveDetail.getApprovalStatus(),LeaveStatusEnum.getEnumValueFromString(employeeLeaveDetail.getApprovalStatus())));
				}

			});

			leaveDetail.setEmployeeName(employeeName);
			leaveDetail.setLeaveDetailsRecord(leaveDetailsRecord);
			response.setData(leaveDetail);
			response.setStatus(true);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch (Exception e) {
			return catchException("getEmployeeLeaveDetails()", e, "Failed", "Employee leave details not found");
		}
	}

	@Override
	@Transactional
	public ResponseEntity<Object> approveLeaveRequest(LeaveRequestDetails leaveRequestDetails, Boolean isLossOfPay) {
		try {

			Optional<EmployeeLeaveRequestMaster> employeeLeaveRequest = leaveRequestMasterRepo
					.findById(leaveRequestDetails.getRequestId());

			List<EmployeeLeaveDetails> employeeLeaveDetail = leaveDetailsRepository
					.findByIdIn(leaveRequestDetails.getLeaveRequestDetailId());

			List<EmployeeLeaveDetails> leaveDetails = leaveDetailsRepository
					.findByIdInAndApprovalStatusIn(leaveRequestDetails.getLeaveRequestDetailId(), Arrays.asList("T"));

			List<EmployeeLeaveDetails> ApprovedleaveDetails = leaveDetailsRepository
					.findByIdInAndApprovalStatusIn(leaveRequestDetails.getLeaveRequestDetailId(), Arrays.asList("A","TC"));

			if (employeeLeaveRequest.isEmpty() || ObjectUtils.isEmpty(leaveDetails)
					&& !leaveRequestDetails.getStatus().equals(Constants.CANCELLED_STATUS)) {

				String message = employeeLeaveDetail.stream().allMatch(
						l -> l.getApprovalStatus().equalsIgnoreCase(Constants.APPROVED_STATUS))
								? "Leave Request is approved already"
								: employeeLeaveDetail.stream()
										.allMatch(l -> l.getApprovalStatus()
												.equalsIgnoreCase(Constants.REJECTED_STATUS))
														? "Leave Request is rejected already"
														: employeeLeaveDetail.stream()
																.allMatch(l -> l.getApprovalStatus().equalsIgnoreCase(
																		Constants.CANCELLED_STATUS))
																				? "Leave Request is cancelled already"
																				: "Leave request not found";

				response.setInformation(new ExceptionBean(Instant.now(), "No value present", message));
				response.setStatus(false);
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}

			String message = "";
			
			switch (leaveRequestDetails.getStatus()) {

			case Constants.CANCELLED_STATUS -> {
				
				if (ObjectUtils.isEmpty(ApprovedleaveDetails) ) {
					
					response.setInformation(
							new ExceptionBean(Instant.now(), "No value present", "Leave request not found"));
					response.setStatus(false);
					mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
					return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
					
				}
				
				return cancelLeaveRequest(leaveRequestDetails, ApprovedleaveDetails);
				
			}

			case Constants.APPROVED_STATUS -> {

				double noOfDaysApplied = leaveDetails.size();

				for (EmployeeLeaveDetails l : leaveDetails) {
					if ((employeeLeaveRequest.get().getLeaveFrom().equals(l.getLeaveDate())
							&& "H".equals(employeeLeaveRequest.get().getLeaveFromForH()))
							|| (employeeLeaveRequest.get().getLeaveTo().equals(l.getLeaveDate())
									&& "H".equals(employeeLeaveRequest.get().getLeaveToForH()))) {
						noOfDaysApplied -= 0.5;
					}
				}

				 ResponseEntity<Object> responseEntity = employeeLeaveRequestServiceImpl.validateLeaveBalance(employeeLeaveRequest.get().getEmployeeId()
						,employeeLeaveRequest.get().getTypeofLeave().getLeaveTypeId(),noOfDaysApplied);
				if(ObjectUtils.notEqual(responseEntity.getStatusCode() ,HttpStatus.OK) && Boolean.FALSE.equals(isLossOfPay)) {
					return responseEntity;
				}

				for (EmployeeLeaveDetails leaveDetail : leaveDetails) {
					leaveDetail.setApprovalStatus(leaveRequestDetails.getStatus());
					leaveDetail.setPaidorLossofPay(ObjectUtils.equals (responseEntity.getStatusCode() ,HttpStatus.OK) ? "P"
							: Boolean.TRUE.equals(isLossOfPay) ? "L" : " ");
					leaveDetail.setApproverComments(leaveRequestDetails.getApproverComments());
					leaveDetail.setAvailed("Y");
					leaveDetail.setReviewedBy(leaveRequestDetails.getApprovedBy());
					leaveDetail.setReviewedOn(InstantFormatter.InstantFormat(leaveRequestDetails.getApprovedOn()));
					leaveDetailsRepository.save(leaveDetail);

					LeaveDebitModel debitModel = new LeaveDebitModel();
					debitModel.setEmployeeId(leaveDetail.getEmployeeId());
					debitModel.setEntryDate(leaveDetail.getLeaveDate());
					debitModel
							.setDebitDays((employeeLeaveRequest.get().getLeaveFrom().equals(leaveDetail.getLeaveDate())
									&& "H".equals(employeeLeaveRequest.get().getLeaveFromForH()))
											? 0.5
											: (employeeLeaveRequest.get().getLeaveTo()
													.equals(leaveDetail.getLeaveDate())
													&& "H".equals(employeeLeaveRequest.get().getLeaveToForH())) ? 0.5
															: 1.0);
					debitModel.setLeaveTypeId(employeeLeaveRequest.get().getTypeofLeave().getLeaveTypeId());
					debitModel.setComments(leaveRequestDetails.getApproverComments());
					debitModel.setIsLossofPay(isLossOfPay);
					debitModel.setLeaveEnteredBy(employeeLeaveRequest.get().getLeaveEnteredBy());
					debitModel.setApprovedOn(leaveRequestDetails.getApprovedOn());

					applyLeaveDebit(debitModel);

				}
				message = "Leave request approved successfully";
			}

			case Constants.REJECTED_STATUS -> {
				for (EmployeeLeaveDetails leaveDetail : leaveDetails) {

					leaveDetail.setApprovalStatus(leaveRequestDetails.getStatus());
					leaveDetail.setApproverComments(leaveRequestDetails.getApproverComments());
					leaveDetail.setAvailed("Y");
					leaveDetail.setReviewedBy(leaveRequestDetails.getApprovedBy());
					leaveDetail.setReviewedOn(InstantFormatter.InstantFormat(leaveRequestDetails.getApprovedOn()));
					leaveDetailsRepository.save(leaveDetail);
				}
				message = "Leave request rejected";
			}
			}

			employeeLeaveRequest.get().setStatus("Reviewed");
			leaveRequestMasterRepo.save(employeeLeaveRequest.get());
			response.setMessage(message);
			response.setStatus(true);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "message", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch (Exception e) {
			return catchException("approveLeaveRequest()", e, "Failed", "Cannot update leave request");
		}
	}

	private ResponseEntity<Object> cancelLeaveRequest(LeaveRequestDetails leaveRequestDetails,
			List<EmployeeLeaveDetails> leaveDetails) {

		try {

			String message = null;

			Optional<EmployeeLeaveRequestMaster> employeeLeaveRequest = leaveRequestMasterRepo
					.findById(leaveRequestDetails.getRequestId());
			
			if (ObjectUtils.isEmpty(leaveDetails) || employeeLeaveRequest.isEmpty()) {
				response.setInformation(
						new ExceptionBean(Instant.now(), "No value present", "Leave details not found"));
				response.setStatus(false);
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}

			String leaveTypeName = leaveTypeMasterRepo
					.findLeaveTypeNameByLeaveTypeId(employeeLeaveRequest.get().getTypeofLeave().getLeaveTypeId());

			Integer locationId = loginRepository.findLocationIdByEmployeeId(leaveDetails.get(0).getEmployeeId());

			LeaveTypeMaster leaveTypeDetails = leaveTypeMasterRepo
					.findByLocationIDAndLeaveTypeName(locationId, leaveTypeName).orElseThrow (() -> new NullPointerException ("Leave Type Details not found."));

			for (EmployeeLeaveDetails leaveDetail : leaveDetails) {

				leaveDetail.setApprovalStatus(leaveRequestDetails.getStatus());
				leaveDetail.setApproverComments(leaveRequestDetails.getApproverComments());
				leaveDetail.setAvailed("Y");
				leaveDetail.setReviewedBy(leaveRequestDetails.getApprovedBy());
				leaveDetail.setReviewedOn(InstantFormatter.InstantFormat(leaveRequestDetails.getApprovedOn()));
				leaveDetailsRepository.save(leaveDetail);

				if ((Objects.equals(locationId, LocationEum.INDIA.getValue()))
						&& (leaveTypeName.equalsIgnoreCase(LeaveTypeEnum.SICKLEAVE.getValue())
								|| leaveTypeName.equalsIgnoreCase(LeaveTypeEnum.CASUALLEAVE.getValue()))) {

					Optional<SpecialLeaveLedger> employeeLeaveDebitDetails = leavesDebitDetailRepository
							.findByEmployeeIDAndEntryDate(leaveDetail.getEmployeeId(), leaveDetail.getLeaveDate());

					if (!employeeLeaveDebitDetails.isEmpty()) {
						List<SpecialLeaveLedger> specialLeaveDetails = leavesDebitDetailRepository
								.findByEmployeeIDAndSLDebitMasterIDLeaveTypeIDAndSLDebitMasterIDLocationIDOrderByIdDesc(
										employeeLeaveDebitDetails.get().getEmployeeID(),
										leaveTypeDetails.getLeaveTypeId(), locationId);

						double balance = leaveDetail.getPaidorLossofPay().equalsIgnoreCase("L")
								? specialLeaveDetails.get(0).getBalance()
								: specialLeaveDetails.get(0).getBalance() + employeeLeaveDebitDetails.get().getDebit();

						SpecialLeaveLedger specialLeaveDebitDetails = new SpecialLeaveLedger ();

						specialLeaveDebitDetails.setDebit(0.0);
						specialLeaveDebitDetails.setBalance(balance);
						specialLeaveDebitDetails.setRemarks(leaveDetail.getPaidorLossofPay().equalsIgnoreCase("L")
								? "Cancelled Leave credit - " + Constants.LOP
								: "Cancelled Leave credit ");
						specialLeaveDebitDetails.setEntryDate (leaveDetail.getLeaveDate());
						specialLeaveDebitDetails.setRunDate (InstantFormatter.InstantFormat(leaveRequestDetails.getApprovedOn()));
						specialLeaveDebitDetails.setComments(leaveRequestDetails.getApproverComments());
						specialLeaveDebitDetails.setCreditDays(employeeLeaveDebitDetails.get().getDebit());
						specialLeaveDebitDetails
								.setSLDebitMasterID(employeeLeaveDebitDetails.get().getSLDebitMasterID());
						specialLeaveDebitDetails.setEmployeeID(employeeLeaveDebitDetails.get().getEmployeeID());

						SpecialLeaveLedger leavesDebitDetail = leavesDebitDetailRepository
								.save(specialLeaveDebitDetails);
					}

				} else if ((Objects.equals(locationId, LocationEum.USA.getValue()))
						&& (leaveTypeName.equalsIgnoreCase(LeaveTypeEnum.SICKLEAVE.getValue()))) {
					USSickLeaveDetails usSickLeaveDetail = usSickLeaveDetailsRepository
							.findFirstByEmployeeIdOrderByIdDesc(leaveDetail.getEmployeeId());

					Optional<USSickLeaveDetails> employeeSickLeaveDetail = usSickLeaveDetailsRepository
							.findByEmployeeIdAndEntryDate(leaveDetail.getEmployeeId(), leaveDetail.getLeaveDate());
					
					if(!employeeSickLeaveDetail.isEmpty()) {
						double balance = leaveDetail.getPaidorLossofPay().equalsIgnoreCase("L")
								? usSickLeaveDetail.getBalance()
								: usSickLeaveDetail.getBalance() + employeeSickLeaveDetail.get().getDebitDays();

						double balanceHrs = usSickLeaveDetail.getBalanceHours()
								+ employeeSickLeaveDetail.get().getDebitHrs();

						USSickLeaveDetails usSickLeaveDetails = new USSickLeaveDetails();

						usSickLeaveDetails.setEmployeeId(employeeSickLeaveDetail.get().getEmployeeId());
						usSickLeaveDetails.setDebitHrs(0.0);
						usSickLeaveDetails.setDebitDays(0.0);
						usSickLeaveDetails.setBalance(balance);
						usSickLeaveDetails.setEntryDate(employeeSickLeaveDetail.get().getEntryDate());
						usSickLeaveDetails.setComment(leaveDetail.getPaidorLossofPay().equalsIgnoreCase("L")
								? "Cancelled Leave credit - " + Constants.LOP
								: "Cancelled Leave credit");
						usSickLeaveDetails.setBalanceHours(balanceHrs);
						usSickLeaveDetails.setLeaveAddedBy(leaveDetail.getReviewedBy());
						usSickLeaveDetails.setRunDate(InstantFormatter.InstantFormat(leaveRequestDetails.getApprovedOn()));

						USSickLeaveDetails sickLeaveDetails = usSickLeaveDetailsRepository.save(usSickLeaveDetails);
					}
					
				} else if (leaveTypeName.equalsIgnoreCase(LeaveTypeEnum.VACATION.getValue()) || leaveTypeName.equalsIgnoreCase(LeaveTypeEnum.PRIVILEGELEAVE.getValue())) {

					List<LeaveLedger> employeeLedgerDetail = leaveLedgerRepository
							.findByEmployeeIdOrderByIdDesc(leaveDetail.getEmployeeId());

					Optional<LeaveLedger> usEmployeeLeavedetails = leaveLedgerRepository
							.findByEmployeeIdAndEntryDate(leaveDetail.getEmployeeId(), leaveDetail.getLeaveDate());
					
					if(!usEmployeeLeavedetails.isEmpty()) {
						double balanceDays = leaveDetail.getPaidorLossofPay().equalsIgnoreCase("L")
								? employeeLedgerDetail.get(0).getBalanceDays()
								: employeeLedgerDetail.get(0).getBalanceDays()
										+ usEmployeeLeavedetails.get().getDebitDays();

						LeaveLedger leaveLedger = new LeaveLedger();
						leaveLedger.setEmployeeId(usEmployeeLeavedetails.get().getEmployeeId());
						leaveLedger.setEntryDate(usEmployeeLeavedetails.get().getEntryDate());
						leaveLedger.setCreditDays(usEmployeeLeavedetails.get().getDebitDays());
						leaveLedger.setDebitDays(0.0);
						leaveLedger.setComments(leaveDetail.getPaidorLossofPay().equalsIgnoreCase("L")
								? "Cancelled Leave credit - " + Constants.LOP
								: "Cancelled Leave credit");
						leaveLedger.setBalanceDays(balanceDays);
						leaveLedger.setRunDate(InstantFormatter.InstantFormat(leaveRequestDetails.getApprovedOn()));
						leaveLedgerRepository.save(leaveLedger);

					}

				}
			}
			message = leaveTypeName.equalsIgnoreCase(LeaveTypeEnum.VACATION.getValue())?"Vacation Leave":leaveTypeName ;
			response.setMessage(message+ " request cancelled");
			response.setStatus(true);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "message", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

		} catch (Exception e) {
			return catchException("cancelLeaveRequest()", e, "Failed", "Cannot cancel leave request");

		}

	}

	private void applyLeaveDebit(LeaveDebitModel debitModel) {
		try {
			double balanceDays = 0;
			debitModel.getDebitDays();

			Integer locationId = SqlConnectionSetup.getJdbcConnection()
					.queryForObject("exec spGetLocationIdByEmployeeId ?", Integer.class, debitModel.getEmployeeId());

			String leaveType = leaveTypeMasterRepo.findLeaveTypeNameByLeaveTypeId(debitModel.getLeaveTypeId());

			LeaveTypeMaster leaveTypeDetails = leaveTypeMasterRepo.findByLocationIDAndLeaveTypeName(locationId, leaveType)
					.orElseThrow (() -> new NullPointerException ("Unable to get leave type details."));

			if (Objects.equals(LocationEum.INDIA.getValue(), locationId)) {

				Optional<DeputationHistory> deputationHistory = deputationHistoryRepository
						.findByEmployeeIDAndDeputationDate (debitModel.getEmployeeId(), debitModel.getEntryDate());

				if (deputationHistory.isPresent()) {
					deputationHistory.get().getRemarks();
				}

//				  Need to check compensation table
//				 Optional<EmployeeCompensation> employeeCompensation = employeeCompensationRepository.
//						 findByEmployeeIDAndLeaveDateAndCompensationDateNotNull(debitModel.getEmployeeId(), debitModel.getEntryDate());
//
//				 if(employeeCompensation.isPresent()) 
//				 {
//					 comments = "Compensation Availed";

//					 debitDays = 0.0;
//				 } 
//		
//				 Optional<EmployeeCompensation> compensationDetail = employeeCompensationRepository
//						 .findByEmployeeIDAndCompensationDate(debitModel.getEmployeeId(), debitModel.getEntryDate());
//				 
//				 if(compensationDetail.isPresent()) {
//					 int isUpdated = employeeCompensationRepository
//							 .updateIsCompensatedByEmployeeIDAndCompensationDate(false, debitModel.getEmployeeId(), debitModel.getEntryDate());
//				 }

				List<SpecialLeaveLedger> specialLeaveLedger = leavesDebitDetailRepository
						.findByEmployeeIDAndSLDebitMasterIDLeaveTypeIDAndSLDebitMasterIDLocationIDOrderByIdDesc(
								debitModel.getEmployeeId(), leaveTypeDetails.getLeaveTypeId(), locationId);

				if (!leaveType.equalsIgnoreCase(LeaveTypeEnum.PRIVILEGELEAVE.getValue())) {

					SpecialLeaveLedger specialLeaveDebitDetails = new SpecialLeaveLedger ();

					specialLeaveDebitDetails.setDebit(debitModel.getDebitDays());
					specialLeaveDebitDetails.setBalance(Boolean.TRUE.equals(debitModel.getIsLossofPay())
							? specialLeaveLedger.get(0).getBalance()
							: specialLeaveLedger.get(0).getBalance() - debitModel.getDebitDays());
					specialLeaveDebitDetails.setRemarks(Boolean.TRUE.equals(debitModel.getIsLossofPay()) ? Constants.LOP
							: leaveTypeMasterRepo.findLeaveTypeNameByLeaveTypeId(debitModel.getLeaveTypeId()));
					specialLeaveDebitDetails.setEntryDate (debitModel.getEntryDate());
					specialLeaveDebitDetails.setRunDate (InstantFormatter.InstantFormat(debitModel.getApprovedOn()));
					specialLeaveDebitDetails
							.setComments(debitModel.getIsLossofPay() ? debitModel.getComments() + " - " + Constants.LOP
									: debitModel.getComments());
					specialLeaveDebitDetails.setCreditDays(0.0);
					specialLeaveDebitDetails.setSLDebitMasterID(leavesDebitMasterRepository
							.findByLocationIDAndLeaveTypeID(locationId, debitModel.getLeaveTypeId()).get(0));
					specialLeaveDebitDetails.setEmployeeID(debitModel.getEmployeeId());

					SpecialLeaveLedger leavesDebitDetail = leavesDebitDetailRepository
							.save(specialLeaveDebitDetails);
					debitModel
							.setDebitDays(ObjectUtils.isNotEmpty(leavesDebitDetail) ? debitModel.getDebitDays() : 0.0);
				} else {

					List<LeaveLedger> leaveLedgerDetail = leaveLedgerRepository
							.findByEmployeeIdOrderByIdDesc(debitModel.getEmployeeId());

					balanceDays = ObjectUtils.isNotEmpty(leaveLedgerDetail) ? leaveLedgerDetail.get(0).getBalanceDays()
							: 0.0;
					balanceDays = Boolean.TRUE.equals(debitModel.getIsLossofPay()) ? balanceDays
							: balanceDays - debitModel.getDebitDays();
					LeaveLedger leaveLedger = new LeaveLedger();
					leaveLedger.setEmployeeId(debitModel.getEmployeeId());
					leaveLedger.setEntryDate(debitModel.getEntryDate());
					leaveLedger.setCreditDays(0.0);
					leaveLedger.setDebitDays(debitModel.getDebitDays());
					leaveLedger
							.setComments(debitModel.getIsLossofPay() ? debitModel.getComments() + " - " + Constants.LOP
									: debitModel.getComments());
					leaveLedger.setBalanceDays(balanceDays);
					leaveLedger.setRunDate(InstantFormatter.InstantFormat(debitModel.getApprovedOn()));
					leaveLedgerRepository.save(leaveLedger);

				}

			} else if (Objects.equals(LocationEum.USA.getValue(), locationId)) {

				if (leaveType.equalsIgnoreCase(LeaveTypeEnum.SICKLEAVE.getValue())) {

					List<USSickLeaveDetails> usSickLeaveDetail = usSickLeaveDetailsRepository
							.findByEmployeeIdOrderByIdDesc(debitModel.getEmployeeId());

					double debitHrs = debitModel.getDebitDays() == 1 ? Constants.TOTAL_WORKING_HOURS
							: Constants.TOTAL_WORKING_HOURS / 2;
					double balanceHrs = Boolean.TRUE.equals(debitModel.getIsLossofPay())
							? usSickLeaveDetail.get(0).getBalanceHours()
							: usSickLeaveDetail.get(0).getBalanceHours() - debitHrs;

					USSickLeaveDetails usSickLeaveDetails = new USSickLeaveDetails();

					usSickLeaveDetails.setEmployeeId(debitModel.getEmployeeId());
					usSickLeaveDetails.setDebitHrs(debitModel.getDebitDays() == 1 ? Constants.TOTAL_WORKING_HOURS
							: Constants.TOTAL_WORKING_HOURS / 2);
					usSickLeaveDetails.setDebitDays(debitModel.getDebitDays());
					usSickLeaveDetails.setBalance(usSickLeaveDetail.get(0).getBalance() - debitModel.getDebitDays());
					usSickLeaveDetails.setEntryDate(debitModel.getEntryDate());
					usSickLeaveDetails
							.setComment(debitModel.getIsLossofPay() ? debitModel.getComments() + " - " + Constants.LOP
									: debitModel.getComments());
					usSickLeaveDetails.setBalanceHours(balanceHrs);
					usSickLeaveDetails.setLeaveAddedBy(debitModel.getLeaveEnteredBy());
					usSickLeaveDetails.setRunDate(InstantFormatter.InstantFormat(debitModel.getApprovedOn()));

					USSickLeaveDetails sickLeaveDetails = usSickLeaveDetailsRepository.save(usSickLeaveDetails);
				} else {
					List<LeaveLedger> usEmployeeLeavedetails = leaveLedgerRepository
							.findByEmployeeIdOrderByIdDesc(debitModel.getEmployeeId());

					balanceDays = ObjectUtils.isNotEmpty(usEmployeeLeavedetails)
							? usEmployeeLeavedetails.get(0).getBalanceDays()
							: 0.0;
					balanceDays = Boolean.TRUE.equals(debitModel.getIsLossofPay()) ? balanceDays
							: balanceDays - debitModel.getDebitDays();

					LeaveLedger leaveLedger = new LeaveLedger();
					leaveLedger.setEmployeeId(debitModel.getEmployeeId());
					leaveLedger.setEntryDate(debitModel.getEntryDate());
					leaveLedger.setCreditDays(0.0);
					leaveLedger.setDebitDays(debitModel.getDebitDays());
					leaveLedger
							.setComments(debitModel.getIsLossofPay() ? debitModel.getComments() + " - " + Constants.LOP
									: debitModel.getComments());
					leaveLedger.setBalanceDays(balanceDays);
					leaveLedger.setRunDate(InstantFormatter.InstantFormat(debitModel.getApprovedOn()));
					leaveLedgerRepository.save(leaveLedger);
				}

			}

		} catch (Exception e) {
			catchException("applyLeaveDebit()", e, "Failed", "Employee leave debit details not updated");
		}
	}

	@Override
	public ResponseEntity<Object> getEmployeeLeaveDetailsForEmail(Integer leaveRequestId) {
		try {
			List<EmployeeLeaveDetails> employeeLeaveDetails = leaveDetailsRepository
					.findByLeaveRequestId_Id(leaveRequestId);

			boolean isPartiallyApproved = employeeLeaveDetails.stream()
					.allMatch(l -> l.getApprovalStatus().equalsIgnoreCase(Constants.APPROVED_STATUS)
							|| l.getApprovalStatus().equalsIgnoreCase(Constants.CANCELLED_STATUS)
							|| l.getApprovalStatus().equalsIgnoreCase(Constants.REJECTED_STATUS));

			if (isPartiallyApproved) {
				String message = employeeLeaveDetails.stream()
						.allMatch(l -> l.getApprovalStatus().equalsIgnoreCase(Constants.CANCELLED_STATUS))
								? "Leave Request has been already cancelled"
								: employeeLeaveDetails.stream().allMatch(
										l -> l.getApprovalStatus().equalsIgnoreCase(Constants.REJECTED_STATUS))
												? "Leave Request has been already rejected"
												: "Leave Request has been already approved";

				response.setInformation(new ExceptionBean(Instant.now(), "Already reviewed", message));
				response.setStatus(false);
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}

			List<LeaveDetailsRecord> leaveDetailsRecord = new ArrayList<>();
			ApproveOrRejectLeaveDetails leaveDetail = new ApproveOrRejectLeaveDetails();

			EmployeeLeaveRequestMaster employeeLeaveRequest = leaveRequestMasterRepo.findById(leaveRequestId)
					.orElseThrow (() ->new NullPointerException ("Leave Request details not found."));

			String employeeName = SqlConnectionSetup.getJdbcConnection().queryForObject(
					"exec spGetEmployeeNameById ?", String.class, employeeLeaveRequest.getEmployeeId());
			employeeLeaveDetails.stream().forEach(employeeLeaveDetail -> {

				if (employeeLeaveRequest.getLeaveFrom().equals(employeeLeaveDetail.getLeaveDate())
						&& employeeLeaveRequest.getLeaveFromForH().equals("H")) {
					leaveDetailsRecord.add(new LeaveDetailsRecord(employeeLeaveDetail.getId(),
							InstantFormatter.InstantFormat(employeeLeaveDetail.getLeaveDate()), "Half Day",
							employeeLeaveDetail.getApprovalStatus(),LeaveStatusEnum.getEnumValueFromString(employeeLeaveDetail.getApprovalStatus())));
				} else if (employeeLeaveRequest.getLeaveTo().equals(employeeLeaveDetail.getLeaveDate())
						&& employeeLeaveRequest.getLeaveToForH().equals("H")) {
					leaveDetailsRecord.add(new LeaveDetailsRecord(employeeLeaveDetail.getId(),
							InstantFormatter.InstantFormat(employeeLeaveDetail.getLeaveDate()), "Half Day",
							employeeLeaveDetail.getApprovalStatus(),LeaveStatusEnum.getEnumValueFromString(employeeLeaveDetail.getApprovalStatus())));
				} else {
					leaveDetailsRecord.add(new LeaveDetailsRecord(employeeLeaveDetail.getId(),
							InstantFormatter.InstantFormat(employeeLeaveDetail.getLeaveDate()), "Full Day",
							employeeLeaveDetail.getApprovalStatus(),LeaveStatusEnum.getEnumValueFromString(employeeLeaveDetail.getApprovalStatus())));
				}

			});

			leaveDetail.setEmployeeName(employeeName);
			leaveDetail.setLeaveDetailsRecord(leaveDetailsRecord);
			response.setData(leaveDetail);
			response.setStatus(true);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch (Exception e) {
			return catchException("getEmployeeLeaveDetails()", e, "Failed", "Employee leave details not found");
		}
	}
	
	@Override
	public ResponseEntity<Object> cancelRequest(CancelRequestModel cancelRequestModel) {
		try {
			List<EmployeeLeaveDetails> leaveDetails = leaveDetailsRepository
					.findByIdInAndApprovalStatusIn(cancelRequestModel.leaveRequestDetailId(), Arrays.asList(Constants.APPROVED_STATUS,Constants.TO_BE_APPROVED));
			
			if(leaveDetails.isEmpty()) {
				return catchException("cancelRequest()", null, "No value present", "Cannot get employee leave details" );
			}
			Integer locationId = loginRepository.findLocationIdByEmployeeId(leaveDetails.get(0).getEmployeeId());
			
            Instant requestedOn = InstantFormatter.InstantFormat(cancelRequestModel.cancelRequestedOn());
			
			EmployeeLeaveRequestMaster employeeLeaveRequestMaster = leaveRequestMasterRepo.findById(leaveDetails.get(0).getLeaveRequestId().getId())
					.orElseThrow (() -> new NullPointerException ("Employee Leave request details not found for given Id."));
			
			for (EmployeeLeaveDetails leaveDetail : leaveDetails) {
				
				Optional<PayRollMaster> payRollDetails = payRollMasterRepo.findByLocationIdAndDateBetween(locationId, leaveDetail.getLeaveDate());
				Optional<PayRollMaster> currentPayRollDetails = payRollMasterRepo.findByLocationIdAndDateBetween(locationId, requestedOn);
				
				if(payRollDetails.isPresent() && currentPayRollDetails.isPresent()) {
			
				if((currentPayRollDetails.get().getFromDate().compareTo(leaveDetail.getLeaveDate()) <= 0 &&
				   currentPayRollDetails.get().getToDate().compareTo(leaveDetail.getLeaveDate()) >= 0 &&
				   currentPayRollDetails.get().getPayrollDate().compareTo(requestedOn) >= 0 ) || 
				   (currentPayRollDetails.get().getToDate().compareTo(leaveDetail.getLeaveDate()) < 0)) // if current payroll check for payroll process end date
				{
						
					leaveDetail.setApprovalStatus(Constants.TO_BE_CANCELLED);
					leaveDetail.setApproverComments(cancelRequestModel.cancelRequestComments());
					leaveDetail.setModifiedBy(cancelRequestModel.cancelRequestedBy());
					leaveDetail.setModifiedOn(InstantFormatter.InstantFormat(cancelRequestModel.cancelRequestedOn()));
					leaveDetailsRepository.save(leaveDetail);
					
					response.setMessage("Cancellation request submitted successfully");
					
				}
				else if(currentPayRollDetails.get().getFromDate().compareTo(payRollDetails.get().getPayrollDate()) <= 0 &&
						currentPayRollDetails.get().getFromDate().compareTo(requestedOn)<=0 &&
						payRollDetails.get().getPayrollDate().compareTo(requestedOn) >= 0  ) {
						
						leaveDetail.setApprovalStatus(Constants.TO_BE_CANCELLED);
						leaveDetail.setApproverComments(cancelRequestModel.cancelRequestComments());
						leaveDetail.setModifiedBy(cancelRequestModel.cancelRequestedBy());
						leaveDetail.setModifiedOn(InstantFormatter.InstantFormat(cancelRequestModel.cancelRequestedOn()));
						leaveDetailsRepository.save(leaveDetail);
						
						response.setMessage("Cancellation request submitted successfully.<br/>You should apply leave cancellation request 2 days before payroll process "
								+ ".<br/>Please ensure from next time onwards");
					}
				else {
						return catchException("cancelRequest()", null, "Error", "Payroll already in progress. Please contact HR.");
					}
				}
				else {
					return catchException("cancelRequest()", null, "Error", "Payroll details not found");
				}
			    
		}
	    response.setData(employeeLeaveRequestMaster);
		response.setStatus(true);
		mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "message", STATUS });
		return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}
		
		catch(Exception e) {
			return catchException("cancelRequest()", e, "Failed", "Employee leave details not found");
		}

	}

	private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
		logger.error("{} Error : {}" + methodName, e);
		response.setStatus(false);
		response.setInformation(new ExceptionBean(Instant.now(), message, description));
		mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
		return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
	}

}
