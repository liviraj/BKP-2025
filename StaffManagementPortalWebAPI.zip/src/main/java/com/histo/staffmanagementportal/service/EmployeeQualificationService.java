package com.histo.staffmanagementportal.service;

import org.springframework.http.ResponseEntity;

import com.histo.staffmanagementportal.dto.EmployeeQualificationDTO;
import com.histo.staffmanagementportal.model.ModifiedDetails;

public interface EmployeeQualificationService {
	
	public ResponseEntity<Object> getEmployeeQualificationByEmployeeId(Integer employeeId);
	public ResponseEntity<Object> addEmployeeQualification(EmployeeQualificationDTO qualificationDTO);
	public ResponseEntity<Object> updateEmployeeQualification(EmployeeQualificationDTO qualificationDTO,Integer qualificationId);
	public ResponseEntity<Object> deleteEmployeeQualificationById(Integer qualificationId,ModifiedDetails modifiedDetails);
	public ResponseEntity<Object> getEmployeeQualificationById(Integer qualificationId);
	public ResponseEntity<Object> getQualificationName();

}
