package com.histo.staffmanagementportal.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.orgmaster.repository.DepartmentRepository;
import com.histo.orgmaster.repository.DesignationMasterRepository;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.intranet.entity.EmployeeType;
import com.histo.staffmanagementportal.intranet.entity.PayRollMaster;
import com.histo.staffmanagementportal.intranet.entity.Role;
import com.histo.staffmanagementportal.intranet.repository.*;
import com.histo.staffmanagementportal.model.*;
import com.histo.staffmanagementportal.model.PayRollDetails.PayRollDates;
import com.histo.staffmanagementportal.model.PayRollDetails.PayRollPeriod;
import com.histo.staffmanagementportal.service.FilterService;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class FilterServiceImpl implements FilterService {

private static final Logger logger = LogManager.getLogger(FilterServiceImpl.class);
	
	private static final String STATUS = "status";
    
	private final RoleRepository roleRepository;
	
	private final DepartmentRepository departmentRepository;
	
	private final DesignationMasterRepository designationRepository;
	
	private final EmployeeTypeRepository employeeTypeRepo;
	
	private final ModelMapper modelMapper;
	
	private final ResponseModel response;
	
	private MappingJacksonValue mappingJacksonValue;
	
	private final PayRollMasterRepository payRollMasterRepo;

	private final HolidayRepository holidayRepository;

	public FilterServiceImpl(RoleRepository roleRepository
			, DepartmentRepository departmentRepository
			, DesignationMasterRepository designationRepository
			, EmployeeTypeRepository employeeTypeRepo
			, ModelMapper modelMapper
			, ResponseModel response, PayRollMasterRepository payRollMasterRepo, HolidayRepository holidayRepository) {
		this.roleRepository = roleRepository;
		this.departmentRepository = departmentRepository;
		this.designationRepository = designationRepository;
		this.employeeTypeRepo = employeeTypeRepo;
		this.modelMapper = modelMapper;
		this.response = response;
		this.payRollMasterRepo = payRollMasterRepo;
		this.holidayRepository = holidayRepository;
	}

	@Override
	public ResponseEntity<Object> getEmployeeName() {
		try {
			List<EmployeeName> employeeName = SqlConnectionSetup.getJdbcConnection().query("exec spGetEmployeeName", BeanPropertyRowMapper.newInstance(EmployeeName.class));
			employeeName.add(0,new EmployeeName(0,"All",0,"All","0","All",0));
			response.setStatus(true);
	        response.setData(employeeName);
	        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
	        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}catch(Exception e) {
			return catchException("findEmployeeName()",e,"Failed","Unable to get employee name");
		}
	}
	
	@Override
	public ResponseEntity<Object> getEmployeeNameFromLogin(){
			try {
				List<LoginEmployeeName> employeeName = SqlConnectionSetup.getJdbcConnection().query("exec spGetLoginName", BeanPropertyRowMapper.newInstance(LoginEmployeeName.class));
				employeeName.add(0,new LoginEmployeeName(0,0,"All",0,""));
				response.setStatus(true);
		        response.setData(employeeName);
		        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
		        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
			}catch(Exception e) {
				return catchException("getEmployeeNameFromLogin()",e,"Failed","Unable to get employee name");
			}
	}
	@Override
	public ResponseEntity<Object> getLocation() {
		try {
			List<LocationFilter> location = new ArrayList<>();
			location.add(new LocationFilter(LocationEum.All.getValue(),LocationEum.All.name()));
			location.add(new LocationFilter(LocationEum.USA.getValue(),LocationEum.USA.name()));
			location.add(new LocationFilter(LocationEum.INDIA.getValue(),LocationEum.INDIA.name()));
			
			response.setStatus(true);
	        response.setData(location);
	        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
	        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}catch(Exception e) {
			return catchException("getLocation()",e,"Failed","Unable to get location name");
		}
	}
	@Override
	public ResponseEntity<Object> getRoleName() {
		try {
			List<Role> roles = roleRepository.findDistinctByRecordStatusOrderByIdAscRoleNameAsc('A');
			List<RoleNames> roleNames = new ArrayList<>();
			roleNames.add(new RoleNames(0,"All"));
			roleNames.addAll(roles.stream()
					.map(role ->modelMapper.map(role,  RoleNames.class))
					.filter(role -> role.getRoleName().equalsIgnoreCase(RoleEnum.EMPLOYEE.getValue()) || 
							role.getRoleName().equalsIgnoreCase(RoleEnum.ADMINISTRATOR.getValue()) || 
							role.getRoleName().equalsIgnoreCase(RoleEnum.HUMAN_RESOURCE.getValue()) || 
							role.getRoleName().equalsIgnoreCase(RoleEnum.SECTION_SUPERVISOR.getValue()))
					.toList());
			response.setStatus(true);
	        response.setData(roleNames);
	        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
	        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}catch(Exception e) {
			return catchException("getRoleName()",e,"Failed","Unable to get roles");
		}
	}
	@Override
	public ResponseEntity<Object> getSatus() {
		try {
			List<String> mappingStatus =Arrays.asList("All","Existing","New");
			response.setStatus(true);
	        response.setData(mappingStatus);
	        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
	        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);		}catch(Exception e) {
			return catchException("getSatus()",e,"Failed","Unable to get mapping status");
		}
	}
	@Override
	public ResponseEntity<Object> getEmployeeStatus() {
		try {
			List<String> employeeStatus =Arrays.asList("All","Active","Confirmed","Relieved","Probation");
			response.setStatus(true);
	        response.setData(employeeStatus);
	        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
	        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}catch(Exception e) {
			return catchException("getEmployeeStatus()",e,"Failed","Unable to get employee status");
		}
	}
	@Override
	public ResponseEntity<Object> getEmploymentType() {
		try {
			List<EmployeeType> employeeType = employeeTypeRepo.findAll();
            List<EmployeeTypeModel> employeeTypeDTO = new ArrayList<>();
            employeeTypeDTO.add(new EmployeeTypeModel(0,"All","All"));
            employeeTypeDTO.addAll(employeeType.stream().map(type -> 
            new EmployeeTypeModel(type.getEmployeeTypeId(),type.gettType(),type.getEmployeeTypeValue()))
			.toList());
            response.setStatus(true);
	        response.setData(employeeTypeDTO);
	        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
	        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}
		catch(Exception e) {
			return catchException("getEmployeeType()",e,"Failed","Unable to get employee type");
		}
	}
	@Override
	public ResponseEntity<Object> getSection() {
		try {
           
			List<DepartmentName> departmentName = departmentRepository.findDepartmentName();
			
			List<SectionModel> sectionModels = departmentName.stream().map(depart -> 
			new SectionModel(depart.getDepartmentId(),depart.getDepartmentName(),
					departmentRepository.findLocationIdByDepartmentId(depart.getDepartmentId()),depart.getSortOrder())).collect(Collectors.toList());

			sectionModels.add(0,new SectionModel(0,"All", List.of(0),0));
			response.setStatus(true);
	        response.setData(sectionModels);
	        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
	        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}
		catch(Exception e) {
			return catchException("getDepartment()",e,"Failed","Unable to get departments");
		}
	}
	@Override
	public ResponseEntity<Object> getDesignation() {
		try {
			List<DesignationName> designationName = designationRepository.findDesignation();
			designationName.add(0,new DesignationName(0,"All"));
			response.setStatus(true);
	        response.setData(designationName);
	        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
	        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}catch(Exception e) {
			return catchException("getDesignation()",e,"Failed","Unable to get designations");
		}
	}
	@Override
	public ResponseEntity<Object> getClinicalHandler() {
		try {
			List<String> clinicalHandler =Arrays.asList("All","Yes","No");
			response.setStatus(true);
	        response.setData(clinicalHandler);
	        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
	        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);		}
		catch(Exception e) {
			return catchException("getClinicalHandler()",e,"Failed","Unable to get employee on clinical handler");
		}
	}
	
	@Override
	public ResponseEntity<Object> getLeaveStatus() {
		try {
			List<String> leaveStatus =Arrays.asList("All","To Be Approved","To Be Cancelled","Approved","Rejected","Cancelled","Partially Approved");
			response.setStatus(true);
	        response.setData(leaveStatus);
	        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
	        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);		}
		catch(Exception e) {
			return catchException("getLeaveStatus()",e,"Failed","Unable to get leave approval status");
		}
	}

	@Override
	public ResponseEntity<Object> getPayRollDetails() {
		try {
			List<PayRollMaster> currentPayRoll = payRollMasterRepo.findByCurrentDate();
			
			Optional<PayRollMaster> indiaCurrentPayroll = currentPayRoll.stream().filter(payroll -> 
			payroll.getLocationId().equals(LocationEum.INDIA.getValue())).findFirst();
			
			Optional<PayRollMaster> usCurrentPayroll = currentPayRoll.stream().filter(payroll -> 
			payroll.getLocationId().equals(LocationEum.USA.getValue())).findFirst();
			
			if(indiaCurrentPayroll.isEmpty() || usCurrentPayroll.isEmpty()) {
				return catchException("getPayRollDetails()",null,"No value present","Unable to get current payroll"); 
			}
	
			PayRollDetails payRollPeriod = new PayRollDetails();
			
			payRollPeriod .setIndiaPayRoll(findPayrollByLocation(indiaCurrentPayroll.get()));
			
			payRollPeriod.setUsPayRoll(findPayrollByLocation(usCurrentPayroll.get()));
			
			response.setStatus(true);
	        response.setData(payRollPeriod);
	        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
	        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);	
	        
		}catch(Exception e) {
			return catchException("getPayRollDetails()",e,"Failed","Unable to get payroll details");
		}
	}

	@Override
	public ResponseEntity<Object> getRequestStatus() {
		try{
			List<EnumViewModel> requestStatus = new ArrayList<> ();
			requestStatus.add (new EnumViewModel ("All","All"));
			requestStatus.add (new EnumViewModel (LeaveStatusEnum.TO_BE_APPROVED.getValue (),LeaveStatusEnum.T.getValue ()));
			requestStatus.add (new EnumViewModel (LeaveStatusEnum.APPROVED_STATUS.getValue (),LeaveStatusEnum.A.getValue ()));
			requestStatus.add (new EnumViewModel (LeaveStatusEnum.REJECTED_STATUS.getValue (),LeaveStatusEnum.R.getValue ()));

			requestStatus.sort (Comparator.comparing(EnumViewModel::value));

			response.setStatus(true);
			response.setData(requestStatus);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}
		catch(Exception e) {
			return catchException("getRequestStatus()",e,"Failed","Unable to get request status");
		}
	}

	@Override
	public ResponseEntity<Object> getHolidayDetails(FilterModel filterModel) {
		try{
			List<HolidayDetailsForLeaveRequest> holidayList = SqlConnectionSetup.getJdbcConnection ().query ("exec spGetHolidayForLeaveRequest ?,?,?;",
					BeanPropertyRowMapper.newInstance (HolidayDetailsForLeaveRequest.class),
					filterModel.getYear (),
					filterModel.getLocationId (),
					filterModel.getEmployeeId ());

			Map<String, Map<String, Object>> groupedHolidays = new LinkedHashMap<>();

			for (HolidayDetailsForLeaveRequest holiday : holidayList) {
				String key = holiday.getHolidayName();

				// Check if this holiday is already added
				Map<String, Object> holidayResponse = groupedHolidays.getOrDefault(key, new LinkedHashMap<>());

				// Set the holidayName and isOptional fields if not already set
				holidayResponse.putIfAbsent("holidayName", holiday.getHolidayName());
				holidayResponse.putIfAbsent("isOptional", holiday.getIsOptional ());
				holidayResponse.putIfAbsent("isEmployeeFloating", holiday.getIsEmployeeFloating ());

				// Add the holiday date to the list of holidayDate
				List<String> holidayDates = (List<String>) holidayResponse.getOrDefault("holidayDate", new ArrayList<>());
				holidayDates.add(holiday.getHolidayDate ());
				holidayResponse.put("holidayDate", holidayDates);

				// Put back the updated holiday response object
				groupedHolidays.put(key, holidayResponse);
			}

			// Return as a List of Maps
			ArrayList<Map<String, Object>> maps = new ArrayList<> (groupedHolidays.values ());

			response.setStatus(true);
			response.setData(maps);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}
		catch(Exception e) {
			return catchException("getHolidayDetails()",e,"Failed","Unable to get holiday details.");
		}

	}

	private PayRollPeriod findPayrollByLocation(PayRollMaster payRoll) {
		
		Optional<PayRollMaster> nextPayroll = payRollMasterRepo.findFirstByIdGreaterThanAndLocationIdOrderByIdAsc(payRoll.getId(),payRoll.getLocationId());
		
		Optional<PayRollMaster> previousPayroll = payRollMasterRepo.findFirstByIdLessThanAndLocationIdOrderByIdDesc(payRoll.getId(),payRoll.getLocationId()); 
		
		return new PayRollPeriod(
				  new PayRollDates(payRoll.getFromDate(), payRoll.getToDate(),payRoll.getPayrollDate()),
				  new PayRollDates(previousPayroll.map(PayRollMaster::getFromDate).orElse(null),
                          previousPayroll.map(PayRollMaster::getToDate).orElse(null),
						  previousPayroll.map(PayRollMaster::getPayrollDate).orElse(null)),
                  new PayRollDates(nextPayroll.map(PayRollMaster::getFromDate).orElse(null),
                          nextPayroll.map(PayRollMaster::getToDate).orElse(null),
						  previousPayroll.map(PayRollMaster::getPayrollDate).orElse(null)));
	}
	
	private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
   	 logger.error("{} Error : {}" , methodName, e);
     response.setStatus(false);
     response.setInformation(new ExceptionBean(Instant.now(), message, description));
     mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
     return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }

	
	
}
