package com.histo.staffmanagementportal.service;

import com.histo.staffmanagementportal.model.LeaveLedgerFilterModel;
import com.histo.staffmanagementportal.model.LeaveSummaryFilter;
import org.springframework.http.ResponseEntity;

public interface LeaveLedgerService extends LeaveLedgerInterface {

    public ResponseEntity<Object> doFilterInLaveLedger(LeaveLedgerFilterModel ledgerFilterModel);

    public ResponseEntity<Object> getLeaveSummary(LeaveSummaryFilter leaveSummaryFilter);

    public  ResponseEntity<Object> getLeaveBalance(LeaveSummaryFilter leaveSummaryFilter);

}
