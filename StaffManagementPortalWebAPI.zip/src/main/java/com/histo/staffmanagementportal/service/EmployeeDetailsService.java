package com.histo.staffmanagementportal.service;

import org.springframework.http.ResponseEntity;

public interface EmployeeDetailsService {
	
	 ResponseEntity<Object> getEmployeeDocument(Integer employeeId, String imageType);
	 ResponseEntity<Object> getEmployeeDetails(Integer employeeId);
	 ResponseEntity<Object> getQualificationCertificate(Integer qualificationId);
	 ResponseEntity<Object> getContinuousEducationCertificate(Integer continuousEducationId);
	 ResponseEntity<Object> getWorkHistoryProof(Integer workHistoryId);
	ResponseEntity<Object> getEmployeeRequestDocument(Integer requestId);
	ResponseEntity<Object> getEmployeepolicyDocument(Integer policyId);

	ResponseEntity<Object> getEmployeeDesignationDocument(Integer designationId);
}
