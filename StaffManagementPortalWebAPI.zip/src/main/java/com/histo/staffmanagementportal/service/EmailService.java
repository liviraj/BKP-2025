package com.histo.staffmanagementportal.service;

import com.histo.staffmanagementportal.model.ComplianceEmailModel;
import org.springframework.http.ResponseEntity;

import com.histo.staffmanagementportal.model.LeaveRequestDetails;

import java.util.List;

public interface EmailService {

	public ResponseEntity<Object> sendEmail(Object content,String leaveRequest);
	
	public ResponseEntity<Object> sendEmail(LeaveRequestDetails content);
	
	public ResponseEntity<Object> sendLeaveCreditEmail(Object content);
	
	public ResponseEntity<Object> sendLedgerUpdateEmail(Object emailModel);
	
	public ResponseEntity<Object> sendNewLoginDetailsEmail(Object emailModel);

	public ResponseEntity<Object> sendMyRequestEmail(Object emailModel);

	public ResponseEntity<Object> sendMyRequestAssigneeEmail(Object emailModel);

	ResponseEntity<Object> sendPermissionRequestEmail(Object emailDetails);


    ResponseEntity<Object> sendPermissionRequestApprovalEmail(Object emailDetails);

	ResponseEntity<Object> sendComplianceExpiryEmail(List<ComplianceEmailModel> emailModels);

	ResponseEntity<Object> sendEmployeeWorkRequestEmail(Object emailDetails);


	ResponseEntity<Object> sendEmployeeWorkRequestApprovalEmail(Object emailDetails);

	ResponseEntity<Object> sendHipaaEmailForNewJoinee(Integer employeeId);

}
