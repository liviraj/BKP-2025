package com.histo.staffmanagementportal.service;

import com.histo.staffmanagementportal.model.AttendanceFilter;

import org.springframework.http.ResponseEntity;

public interface AttdanceService {

     ResponseEntity<Object> getEmployeeAttendanceforReportbyPeriod(AttendanceFilter reportFilter);

     ResponseEntity<Object> getEmployeeMonthlyAttendanceReport(AttendanceFilter reportFilter);

     ResponseEntity<Object> getEmployeeTimingDetailsByPeriod(AttendanceFilter reportFilter);

}
