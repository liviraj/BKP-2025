package com.histo.staffmanagementportal.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.dto.EmployeeComplianceDTO;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.helper.DateValidation;
import com.histo.staffmanagementportal.intranet.entity.Document;
import com.histo.staffmanagementportal.intranet.entity.EmployeeCompliance;
import com.histo.staffmanagementportal.intranet.repository.DocumentRepository;
import com.histo.staffmanagementportal.intranet.repository.EmployeeComplianceRepository;
import com.histo.staffmanagementportal.intranet.repository.EmployeeComplianceRepository.ComplianceCategory;
import com.histo.staffmanagementportal.model.*;
import com.histo.staffmanagementportal.service.EmployeeComplianceService;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.Optional;


@Service
public class EmployeeComplianceServiceImpl implements EmployeeComplianceService{

	private static final Logger logger = LogManager.getLogger(EmployeeComplianceServiceImpl.class);

	private static final String STATUS = "status";

    private final ResponseModel response;
    private final EmployeeComplianceRepository complianceRepository;

	private final DocumentRepository documentRepository;
	private MappingJacksonValue mappingJacksonValue;

	public EmployeeComplianceServiceImpl(ResponseModel response, EmployeeComplianceRepository complianceRepository, DocumentRepository documentRepository) {
		this.response = response;
		this.complianceRepository = complianceRepository;
		this.documentRepository = documentRepository;
	}

	@Override
	public ResponseEntity<Object> getEmployeeComplianceByEmployeeId(Integer employeeId) {
		try {
			List<EmployeeComplianceModel> employeeCompliance = SqlConnectionSetup.getJdbcConnection().query("exec spEmployeeComplianceByEmployeeId ?;", BeanPropertyRowMapper.newInstance(EmployeeComplianceModel.class),
					employeeId);
			response.setStatus(true);
			response.setData(employeeCompliance);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch(Exception e) {
			return catchException("getEmployeeComplianceByEmployeeId()", e, "Cannot fetch employee compliance detail");
		}
	}

	@Override
	public ResponseEntity<Object> addEmployeeCompliance(EmployeeComplianceDTO complianceDTO) {
		try {

			Boolean isValidCompliance = checkIfAuthenticateUser(complianceDTO);

			if(!isValidCompliance){
				return catchException("addEmployeeCompliance()", null, "Do not have access to add selected compliance category.</br> Please select valid Compliance category");
			}

			if(DateValidation.validateDate(complianceDTO.getComplianceDate(), complianceDTO.getExpiryDate())) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(),"Error","Expiry date should not be lesser than compliance date"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"information",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
			EmployeeComplianceDTO employeeCompliance = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spInsertEmployeeCompliance ?,?,?,?,?,?,?,?,?,?;", BeanPropertyRowMapper.newInstance(EmployeeComplianceDTO.class),
					0,
					complianceDTO.getEmployeeID(),
					complianceDTO.getCreatedBy(),
					complianceDTO.getComplianceCategoryID(),
					complianceDTO.getCompliancePeriod(),
					complianceDTO.getComplianceDate(),
					complianceDTO.getDescription(),
					complianceDTO.getDocumentName(),
					complianceDTO.getDocumentImage(),
					complianceDTO.getExpiryDate());

			if(ObjectUtils.isNotEmpty (employeeCompliance)){
				for(Document documentDetails : complianceDTO.getDocumentDetails ()){

					documentDetails.setDocumentId (employeeCompliance.getEmployeeComplianceID ());
					documentDetails.setDocumentType (StaffModuleName.COMPLIANCE.getValue ());
					documentDetails.setCreatedBy (complianceDTO.getCreatedBy());

					Document savedDocumentDetails = documentRepository.save (documentDetails);
				}

			}

			response.setStatus(true);
			response.setData(employeeCompliance);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch(Exception e) {
			return catchException("addEmployeeCompliance()", e, "Cannot add employee compliance detail");
		}
	}

	@Override
	public ResponseEntity<Object> updateEmployeeCompliance(EmployeeComplianceDTO complianceDTO, Integer complianceId) {
		try {
			Boolean isValidCompliance = checkIfAuthenticateUser(complianceDTO);

			if(!isValidCompliance){
				return catchException("addEmployeeCompliance()", null, "Do not have access to add selected compliance category.</br> Please select valid Compliance category");
			}

			List<EmployeeCompliance> employeeCompliance = SqlConnectionSetup.getJdbcConnection().query("exec spGetEmployeeCompliance ?"
					,BeanPropertyRowMapper.newInstance(EmployeeCompliance.class),complianceId);
			if(employeeCompliance.isEmpty()) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(), "Failed", "Employee compliance details not found"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"information",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
			if(DateValidation.validateDate(complianceDTO.getComplianceDate(), complianceDTO.getExpiryDate())) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(),"Error","Expiry date should not be lesser than compliance date"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"information",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
			String employeeWorkStatus = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetEmploymentStatusByEmpId ?", String.class,complianceDTO.getEmployeeID());
			if(ObjectUtils.equals(employeeWorkStatus, Constants.RELIEVED_STATUS)) {
				return catchException("updateEmployeeCompliance()", null, "Cannot update relieved employee details");
			}
			EmployeeComplianceDTO employeeComplianceDTO = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spUpdateEmployeeCompliance ?,?,?,?,?,?,?,?,?,?,?;", BeanPropertyRowMapper.newInstance(EmployeeComplianceDTO.class),
					complianceId,
					complianceDTO.getEmployeeID(),
					complianceDTO.getCreatedBy(),
					complianceDTO.getComplianceCategoryID(),
					complianceDTO.getCompliancePeriod(),
					complianceDTO.getComplianceDate(),
					complianceDTO.getDescription(),
					complianceDTO.getDocumentName(),
					complianceDTO.getDocumentImage(),
					complianceDTO.getExpiryDate(),
					Constants.ACTIVE_RECORD_STATUS);

			if(ObjectUtils.isNotEmpty (employeeComplianceDTO)){
				complianceDTO.getDocumentDetails ().stream ().forEach (document ->{
					if(document.getId () == null){

						document.setDocumentId (complianceId);
						document.setDocumentType (StaffModuleName.COMPLIANCE.getValue ());
						document.setCreatedBy (complianceDTO.getCreatedBy ());

						Document savedDocumentDetails = documentRepository.save (document);

					} else{
							Optional<Document> existingDocumentDetails = documentRepository.findByIdAndRecordStatusAndDocumentType (
									document.getId (),
									Constants.ACTIVE_RECORD_STATUS,
									StaffModuleName.COMPLIANCE.getValue ());

							existingDocumentDetails.get ().setRecordStatus (document.getRecordStatus ());
							existingDocumentDetails.get ().setModifiedBy (complianceDTO.getCreatedBy());
							documentRepository.save (existingDocumentDetails.get ());

						}

					} );


			}

			response.setStatus(true);
			response.setData(employeeComplianceDTO);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch(Exception e) {
			return catchException("updateEmployeeCompliance()", e, "Cannot update employee compliance detail");
		}

	}

	@Override
	public ResponseEntity<Object> getEmployeeComplianceById(Integer complianceId) {
		try {
			EmployeeComplianceDTO employeeCompliance = SqlConnectionSetup.getJdbcConnection().queryForObject ("exec spGetEmployeeCompliance ?"
					,BeanPropertyRowMapper.newInstance(EmployeeComplianceDTO.class),complianceId);
			if(ObjectUtils.isEmpty (employeeCompliance)) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(), "Failed", "Employee compliance details not found"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"information",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}

        List<Document> documentDetails = documentRepository.findByDocumentIdAndRecordStatusAndDocumentType (complianceId,
				Constants.ACTIVE_RECORD_STATUS,
				StaffModuleName.COMPLIANCE.getValue ());

			employeeCompliance.setDocumentDetails (documentDetails);
			response.setStatus(true);
			response.setData(employeeCompliance);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch(Exception e) {
			return catchException("getEmployeeComplianceById()", e, "Cannot fetch employee compliance detail");
		}
	}

	@Override
	public ResponseEntity<Object> getComplianceCategory() {
		try {
			List<ComplianceCategory> complianceCategory = complianceRepository.getComplianceCategory();

			List<ComplianceCategoryProjector> complianceCategoryProjectors = complianceCategory.stream().map(category ->
					new ComplianceCategoryProjector(category.getComplianceCategoryId(),
							category.getComplianceCategory(),
							category.getIsPolicyAgreement(),
							category.getComplianceType(),
							complianceRepository.getCompliancePeriodIdByCategoryId(category.getComplianceCategoryId()))).toList();

			response.setStatus(true);
			response.setData(complianceCategoryProjectors);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch(Exception e) {
			return catchException("getComplianceCategory()", e, "Cannot fetch compliance category detail");
		}
	}

	@Override
	public ResponseEntity<Object> getCompliancePeriod() {
		try {
			List<CompliancePeriodProjector> compliancePeriod = complianceRepository.getCompliancePeriod();
			response.setStatus(true);
			response.setData(compliancePeriod);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch(Exception e) {
			return catchException("getCompliancePeriod()", e, "Cannot fetch compliance period detail");
		}
	}

	@Override
	public ResponseEntity<Object> deleteEmployeeComplianceById(Integer complianceId,ModifiedDetails modifiedDetails) {
		try {

			int updateRecordStatusById = complianceRepository.updateRecordStatusById(Constants.DELETED_RECORD_STATUS,complianceId,modifiedDetails.modifiedBy(),
					InstantFormatter.InstantFormat(modifiedDetails.modifiedDate()));

			if(updateRecordStatusById <= 0) {
				return catchException("deleteEmployeeComplianceById()", null, "Employee compliance details not found");
			}

			response.setStatus(true);
			response.setMessage("Compliance details deleted successfully");
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"message",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch(Exception e) {
			return catchException("deleteEmployeeComplianceById()", e, "Cannot delete Employee compliance details");
		}
	}

	private Boolean checkIfAuthenticateUser(EmployeeComplianceDTO complianceDTO){
		boolean isValidCompliance = Boolean.FALSE;
		try{
			String roleName = complianceDTO.getAuthenticateUserRole();

			List<ComplianceCategory> complianceCategory = complianceRepository.getComplianceCategory();

			if (ObjectUtils.isNotEmpty(roleName)) {
				if(roleName.contains(RoleEnum.EMPLOYEE.getValue())) {
					isValidCompliance = complianceCategory.stream().filter(data -> data.getComplianceType().equalsIgnoreCase("Course"))
							.anyMatch(data -> data.getComplianceCategoryId().equals(complianceDTO.getComplianceCategoryID()));
				}
				else if(roleName.contains(RoleEnum.SECTION_SUPERVISOR.getValue())) {
					isValidCompliance = complianceCategory.stream().filter(data -> (data.getComplianceType().equalsIgnoreCase("Course") ||
									data.getComplianceType().equalsIgnoreCase("Training")))
							.anyMatch(data -> data.getComplianceCategoryId().equals(complianceDTO.getComplianceCategoryID()));
				}
				else  {
					isValidCompliance = complianceCategory.stream().filter(data -> (data.getComplianceType().equalsIgnoreCase("Course") ||
									data.getComplianceType().equalsIgnoreCase("Training") ||
									(data.getComplianceType().equalsIgnoreCase("Agreement"))))
							.anyMatch(data -> data.getComplianceCategoryId().equals(complianceDTO.getComplianceCategoryID()));
				}
			}
		}
		catch(Exception e ){
			catchException("checkIfAuthenticateUser()", e, "Cannot validate Employee compliance details");
		}

		return isValidCompliance;
	}

	private ResponseEntity<Object> catchException(String methodName, Exception e, String description) {
		logger.error("{} Error : {}" + methodName, e);
		ExceptionBean exception = new ExceptionBean(Instant.now(), "Error", description);
		response.setStatus(false);
		response.setInformation(exception);
		mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information",STATUS});
		return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
	}

}
