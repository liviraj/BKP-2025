package com.histo.staffmanagementportal.service;

import org.springframework.http.ResponseEntity;

import com.histo.staffmanagementportal.dto.EmployeeLeaveRequestDTO;
import com.histo.staffmanagementportal.model.LeaveDatesModel;
import com.histo.staffmanagementportal.model.LeaveHistoryFilterModel;

public interface EmployeeLeaveRequestService {

	public ResponseEntity<Object> getLeaveType(Integer locationId);
	public ResponseEntity<Object> getLastLeaveAvailed(Integer employeeId);
	public ResponseEntity<Object> addLeaveRequest(EmployeeLeaveRequestDTO leaveRequestDTO,Integer employeeID,boolean isLossOfPay);
	public ResponseEntity<Object> getEmployeeLeaveHistory(LeaveHistoryFilterModel filterModel);
	public LeaveDatesModel excludeHoliday(EmployeeLeaveRequestDTO leaveRequestDTO, Integer locationId);
	public ResponseEntity<Object> validateLeaveBalance(Integer employeeId, Integer leaveTypeId, double noOfDaysApplied);
	public ResponseEntity<Object> editLeaveRequest(EmployeeLeaveRequestDTO leaveRequestDTO,Integer leaveRequestId,boolean isLossOfPay);

}
