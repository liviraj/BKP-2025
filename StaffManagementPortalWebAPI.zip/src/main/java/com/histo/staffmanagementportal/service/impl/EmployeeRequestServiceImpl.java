package com.histo.staffmanagementportal.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.dto.EmployeeRequestDetailsDTO;
import com.histo.staffmanagementportal.dto.EmployeeRequestTrackingDTO;
import com.histo.staffmanagementportal.dto.RequestStatusDetailsDTO;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.intranet.entity.*;
import com.histo.staffmanagementportal.intranet.repository.*;
import com.histo.staffmanagementportal.model.*;
import com.histo.staffmanagementportal.service.EmailService;
import com.histo.staffmanagementportal.service.EmployeeRequestService;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeRequestServiceImpl implements EmployeeRequestService {

    private static final Logger logger = LogManager.getLogger(EmployeeRequestServiceImpl.class);
    private static final String STATUS = "status";

    private final ResponseModel response;
    private final RequestTypeMasterRepository requestTypeMasterRepo;
    private final EmployeeRequestDetailsRepository employeeRequestDetailsRepo;
    private final RequestStatusDetailsRepository requestStatusDetailsRepo;

    private final EmployeeRequestTrackingRepository requestTrackingRepo;

    private final RequestApproverDetailsRepository approverDetailsRepo;

    private final LoginRepository loginRepository;

    private final EmailService emailService;

    private MappingJacksonValue mappingJacksonValue;
    private final ModelMapper modelMapper;

    public EmployeeRequestServiceImpl(ResponseModel response, RequestTypeMasterRepository requestTypeMasterRepo, EmployeeRequestDetailsRepository employeeRequestDetailsRepo
            , RequestStatusDetailsRepository requestStatusDetailsRepo, EmployeeRequestTrackingRepository requestTrackingRepo
            , RequestApproverDetailsRepository approverDetailsRepo, LoginRepository loginRepository, EmailService emailService, ModelMapper modelMapper) {
        this.response = response;
        this.requestTypeMasterRepo = requestTypeMasterRepo;
        this.employeeRequestDetailsRepo = employeeRequestDetailsRepo;
        this.requestStatusDetailsRepo = requestStatusDetailsRepo;
        this.requestTrackingRepo = requestTrackingRepo;
        this.approverDetailsRepo = approverDetailsRepo;
        this.loginRepository = loginRepository;
        this.emailService = emailService;
        this.modelMapper = modelMapper;
    }

    @Override
    public ResponseEntity<Object> getEmployeeRequestDetails(RequestFilterValue filterValue) {
       try{
           List<FilteredRequestDetails> requestDetailsList = SqlConnectionSetup.getJdbcConnection ().query ("exec spGetEmployeeRequestDetails ?,?,?,?", BeanPropertyRowMapper.newInstance (FilteredRequestDetails.class),
                   filterValue.getEmployeeId (),
                   filterValue.getStatus (),
                   filterValue.getRequestTypeId (),
                   filterValue.getLocationId ());

           response.setStatus (true);
           response.setData (requestDetailsList);
           mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
           return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
       }catch(Exception e) {
           return catchException("getEmployeeRequestDetails()",e,"Failed","Unable to get request details list");
       }
    }

    @Override
    public ResponseEntity<Object> getRequestTypes() {

        try{
            List<RequestTypeDetails> requestTypeMasters = requestTypeMasterRepo.findAll (Constants.ACTIVE_RECORD_STATUS);
            requestTypeMasters.add (0, new RequestTypeDetails () {
                @Override
                public Integer getRequestTypeId() {
                    return 0;
                }

                @Override
                public String getRequest() {
                    return "All";
                }

                @Override
                public Integer getLocationId() {
                    return 0;
                }
            });

            response.setStatus (true);
            response.setData (requestTypeMasters);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }catch(Exception e) {
            return catchException("getRequestTypes()",e,"Failed","Unable to get request types");
        }
    }

    @Override
    public ResponseEntity<Object> getRequestDetailsById(Integer requestId) {
        try{
            Optional<EmployeeRequestDetails> employeeRequestDetails = employeeRequestDetailsRepo.findById (requestId);

            if(employeeRequestDetails.isEmpty ()){
                return catchException ("getRequestDetailsById : {} ",null, "No value","Request details not found" );
            }
                Optional<EmployeeRequestDetailsDTO> employeeRequestDetailsDTO = employeeRequestDetails.stream()
                    .map(element -> {
                        EmployeeRequestDetailsDTO dto = modelMapper.map(element, EmployeeRequestDetailsDTO.class);
                        dto.setRequestTypeId(element.getRequestType().getRequestTypeId());
                        return dto;
                    })
                    .findFirst();

            response.setStatus (true);
            response.setData (employeeRequestDetailsDTO.get ());
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }catch(Exception e) {
            return catchException("getRequestDetailsById()",e,"Failed","Unable to get request details");
        }
    }

    @Override
    public ResponseEntity<Object> addNewRequest(EmployeeRequestDetailsDTO requestDTO) {

        try{
            Optional<RequestStatusDetails> requestDetails = requestStatusDetailsRepo.findByEmployeeRequestDetails_EmployeeIdAndEmployeeRequestDetails_RequestType_RequestTypeIdAndRequestStatus
                    (requestDTO.getEmployeeId (), requestDTO.getRequestTypeId (), LeaveStatusEnum.TO_BE_APPROVED.getValue ());

            Optional<RequestTypeMaster> requestTypeMaster = requestTypeMasterRepo.findByRequestTypeIdAndRecordStatus (requestDTO.getRequestTypeId (), Constants.ACTIVE_RECORD_STATUS);

            if(requestDetails.isPresent () || requestTypeMaster.isEmpty () ){
                String message = (requestDetails.isPresent () ? "Above request has been already raised. " : "Above requested type is not active. ") +
                        "</br> Can't create another request";
                return catchException ("addNewRequest : {} ",null, "Validation error",message );
            }

            EmployeeRequestDetails employeeRequestDetails = new EmployeeRequestDetails ();

            employeeRequestDetails.setRequestId (requestDTO.getRequestId ());
            employeeRequestDetails.setEmployeeId (requestDTO.getEmployeeId ());
            employeeRequestDetails.setDescription (requestDTO.getDescription ());
            employeeRequestDetails.setImageName (requestDTO.getImageName ());
            employeeRequestDetails.setImageBinary (requestDTO.getImageBinary ());
            employeeRequestDetails.setRequestType (requestTypeMaster.get ());
            employeeRequestDetails.setCreatedBy (requestDTO.getCreatedBy ());
            employeeRequestDetails.setModifiedBy (requestDTO.getModifiedBy ());
            employeeRequestDetails.setCreatedOn (InstantFormatter.InstantFormat (requestDTO.getCreatedOn ()));
            employeeRequestDetails.setModifiedOn (InstantFormatter.InstantFormat (requestDTO.getModifiedOn ()));
            employeeRequestDetails.setRecordStatus (Constants.ACTIVE_RECORD_STATUS);
            EmployeeRequestDetails employeeRequestDetail = employeeRequestDetailsRepo.save (employeeRequestDetails);

            RequestStatusDetails requestStatusDetails =new RequestStatusDetails ();

            requestStatusDetails.setEmployeeRequestDetails (employeeRequestDetail);
            requestStatusDetails.setRequestStatus (LeaveStatusEnum.TO_BE_APPROVED.getValue ());

            RequestStatusDetails statusDetails = requestStatusDetailsRepo.save (requestStatusDetails);

            if(ObjectUtils.isEmpty (employeeRequestDetail) || ObjectUtils.isEmpty (statusDetails)){
                return catchException ("addNewRequest : {} ",null, "Failed","Request details not saved. Please try again" );
            }

            MyRequestEmailParams myRequestEmailParams = SqlConnectionSetup.getJdbcConnection ().queryForObject ("Exec spGetRequestEmailDetails ?", BeanPropertyRowMapper.newInstance (MyRequestEmailParams.class)
                    , employeeRequestDetail.getRequestId ());

            if( myRequestEmailParams != null && ObjectUtils.isNotEmpty (myRequestEmailParams) ){
                myRequestEmailParams.setRequestAction (Constants.LEDGER_ADD);
                response.setData (myRequestEmailParams);
            }

            response.setStatus (true);
            response.setMessage ("Request submitted successfully");
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

        }catch(Exception e) {
            return catchException("addNewRequest()",e,"Failed","Cannot add request");
        }
    }

    @Override
    public ResponseEntity<Object> updateRequestDetails(EmployeeRequestDetailsDTO requestDTO, Integer requestId) {
        try{
            Optional<EmployeeRequestDetails> employeeRequestDetails = employeeRequestDetailsRepo.findById (requestId);

            if(employeeRequestDetails.isEmpty ()){
                return catchException ("updateRequestDetails : {} ",null, "No value","Request details not found" );
            }
            Optional<RequestStatusDetails> requestDetails = requestStatusDetailsRepo.findByEmployeeRequestDetails_RequestIdAndRequestStatus
                    (requestId, LeaveStatusEnum.TO_BE_APPROVED.getValue ());

            boolean isExists = ObjectUtils.notEqual (employeeRequestDetails.get ().getRequestType ().getRequestTypeId () ,requestDTO.getRequestTypeId ())?
                    requestStatusDetailsRepo.findByEmployeeRequestDetails_EmployeeIdAndEmployeeRequestDetails_RequestType_RequestTypeIdAndRequestStatus
                    (requestDTO.getEmployeeId (), requestDTO.getRequestTypeId (), LeaveStatusEnum.TO_BE_APPROVED.getValue ()).isPresent () : false;

            Optional<RequestTypeMaster> requestTypeMaster = requestTypeMasterRepo.findByRequestTypeIdAndRecordStatus (requestDTO.getRequestTypeId (), Constants.ACTIVE_RECORD_STATUS);

            if(requestDetails.isEmpty () || isExists || requestTypeMaster.isEmpty () ){
                String message = (requestDetails.isEmpty () ? "Above request has been reviewed. " : requestTypeMaster.isEmpty () ?"Above requested type is not active. "
                        :"Above request is already exist for provided request type, ") +
                        "</br> Can't edit request";
                return catchException ("updateRequestDetails : {} ",null, "Validation error",message );
            }

            employeeRequestDetails.get ().setEmployeeId (requestDTO.getEmployeeId ());
            employeeRequestDetails.get ().setDescription (requestDTO.getDescription ());
            employeeRequestDetails.get ().setImageName (requestDTO.getImageName ());
            employeeRequestDetails.get ().setImageBinary (requestDTO.getImageBinary ());
            employeeRequestDetails.get ().setRequestType (requestTypeMaster.get ());
            employeeRequestDetails.get ().setModifiedBy (requestDTO.getModifiedBy ());
            employeeRequestDetails.get ().setModifiedOn (InstantFormatter.InstantFormat (requestDTO.getModifiedOn ()));

            EmployeeRequestDetails employeeRequestDetail = employeeRequestDetailsRepo.save (employeeRequestDetails.get ());

            MyRequestEmailParams myRequestEmailParams = SqlConnectionSetup.getJdbcConnection ().queryForObject ("Exec spGetRequestEmailDetails ?", BeanPropertyRowMapper.newInstance (MyRequestEmailParams.class)
                    , employeeRequestDetail.getRequestId ());

            if(ObjectUtils.isNotEmpty (myRequestEmailParams) ){
                myRequestEmailParams.setRequestAction (Constants.LEDGER_UPDATE);
                response.setData (myRequestEmailParams);
            }

            response.setStatus (true);
            response.setMessage ("Request updated successfully");
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);


        }catch(Exception e) {
            return catchException("updateRequestDetails()",e,"Failed","Cannot edit employee request");
        }
    }

    @Override
    public ResponseEntity<Object> approveOrRejectRequest(RequestStatusDetailsDTO requestStatusDetailsDTO) {
       try{
           Optional<RequestStatusDetails> employeeRequestDetailsById = requestStatusDetailsRepo
                   .findByEmployeeRequestDetails_RequestId (requestStatusDetailsDTO.getRequestId ());

           Optional<RequestStatusDetails> requestStatusDetails = requestStatusDetailsRepo.findByEmployeeRequestDetails_RequestIdAndRequestStatus
                   (requestStatusDetailsDTO.getRequestId (), LeaveStatusEnum.TO_BE_APPROVED.getValue ());

           if(employeeRequestDetailsById.isEmpty () || requestStatusDetails.isEmpty ()){
               String message = (employeeRequestDetailsById.isEmpty () ? "Employee request details not found. " :"Above request has been reviewed already.") +
                       "</br> Can't approve/reject request";
               return catchException ("approveOrRejectRequest : {} ",null, "Validation error",message );
           }

           employeeRequestDetailsById.get ().setComments (requestStatusDetailsDTO.getComments ());
           employeeRequestDetailsById.get ().setRequestStatus (requestStatusDetailsDTO.getRequestStatus ());
           employeeRequestDetailsById.get ().setReviewedBy (requestStatusDetailsDTO.getReviewedBy ());
           employeeRequestDetailsById.get ().setReviewedOn (InstantFormatter.InstantFormat (requestStatusDetailsDTO.getReviewedOn ()));

           RequestStatusDetails statusDetails = requestStatusDetailsRepo.save (employeeRequestDetailsById.get ());
           MyRequestEmailParams myRequestEmailParams = SqlConnectionSetup.getJdbcConnection ().queryForObject ("Exec spGetRequestEmailDetails ?", BeanPropertyRowMapper.newInstance (MyRequestEmailParams.class)
                   , statusDetails.getEmployeeRequestDetails ().getRequestId ());

           response.setMessage ("Request has been "+ LeaveStatusEnum.getEnumValueFromString (requestStatusDetailsDTO.getRequestStatus ()) +" successfully");

           if(ObjectUtils.isNotEmpty (myRequestEmailParams) ){
               myRequestEmailParams.setRequestAction (statusDetails.getRequestStatus ());
               response.setData (myRequestEmailParams);
           }

           if(requestStatusDetailsDTO.getRequestStatus ().equalsIgnoreCase (LeaveStatusEnum.APPROVED_STATUS.getValue ())){
                   ResponseEntity<Object> addedApproverDetails = addApproverDetails (statusDetails.getEmployeeRequestDetails ().getRequestId ());
               if(addedApproverDetails.getStatusCode () == HttpStatus.OK){
                   ResponseEntity<Object> sendMyRequestEmail = emailService.sendMyRequestAssigneeEmail (addedApproverDetails.getBody ());
               }
//                   return addedApproverDetails;
               response.setMessage ("Request has been approved and notification sent to IT Support for further processing.");

           }

           response.setStatus (true);

           mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
           return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

       }
       catch(Exception e) {
           return catchException("approveOrRejectRequest()",e,"Failed","Cannot approve/reject request");
       }
    }

    @Override
    public ResponseEntity<Object> requestTracking(RequestFilterModel filterModel) {
       try{
           List<RequestDetails> requestDetails = SqlConnectionSetup.getJdbcConnection ().query ("exec spGetRequestStatusDetails ?,?,?,?,?,?;",
                   BeanPropertyRowMapper.newInstance (RequestDetails.class),
                   filterModel.getRequestTypeId (),
                   filterModel.getRequestStatusId (),
                   filterModel.getLocationId (),
                   filterModel.getEmployeeId (),
                   filterModel.getFromDate (),
                   filterModel.getToDate ()
           );

           response.setData (requestDetails);
           response.setStatus (true);
           mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
           return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

       }catch(Exception e) {
           return catchException("requestTracking()",e,"Failed","Unable to fetch request details");
       }
    }

    @Override
    public ResponseEntity<Object> requestStatus() {
       try{

           List<Object> statusDetails = SqlConnectionSetup.getJdbcConnection ().query ("exec spGetRequestStatus ;", new ResultSetMapper ()
           );

           response.setData (statusDetails);
           response.setStatus (true);
           mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
           return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

       }catch(Exception e) {
           return catchException("requestTracking()",e,"Failed","Unable to fetch request details");
       }
    }

    @Override
    public ResponseEntity<Object> getAssigneeDetails() {
        try{

            List<AssigneeDetails> assigneeDetails = SqlConnectionSetup.getJdbcConnection ().query ("exec spGetAssigneeDetails ;",
                    BeanPropertyRowMapper.newInstance (AssigneeDetails.class)
            );

            if(ObjectUtils.isEmpty (assigneeDetails)){
                return catchException("getAssigneeDetails()",null,"Failed","Assigned to relieved employee. Please contact HR.");
            }

            response.setData (assigneeDetails);
            response.setStatus (true);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

        }catch(Exception e) {
            return catchException("getAssigneeDetails()",e,"Failed","Unable to get assign details");
        }
    }

    @Override
    public ResponseEntity<Object> updateAssignee(EmployeeRequestTrackingDTO employeeRequestTrackingDTO, Integer trackingId) {
        try{

            Optional<EmployeeRequestTracking> requestTrackingDetailById = requestTrackingRepo.findById (trackingId);

            if(requestTrackingDetailById.isEmpty ()){
               return catchException ("updateAssign: {}",null,"Value not found","Unable to update assign detials. Please try again.");
           }

           requestTrackingDetailById.get ().setRequestStatus (employeeRequestTrackingDTO.getRequestStatusId ());
           requestTrackingDetailById.get ().setAssignedTo (employeeRequestTrackingDTO.getAssignedTo ());
           requestTrackingDetailById.get ().setModifiedBy (employeeRequestTrackingDTO.getModifiedBy ());
            requestTrackingDetailById.get ().setModifiedDate (InstantFormatter.InstantFormat (employeeRequestTrackingDTO.getModifiedDate ()));
            requestTrackingDetailById.get().setDescription (employeeRequestTrackingDTO.getDescription ());

            EmployeeRequestTracking employeeRequestTracking = requestTrackingRepo.save (requestTrackingDetailById.get ());

            ApproverEmailDetails approverEmailDetails = SqlConnectionSetup.getJdbcConnection ().queryForObject ("Exec spGetRequestApproverEmailDetails ?"
                    , BeanPropertyRowMapper.newInstance (ApproverEmailDetails.class)
                    , employeeRequestTracking.getRequestId ().getRequestId ());

            response.setData (approverEmailDetails);
            response.setStatus (true);
            response.setMessage ("Assignee details has been updated successfully.");
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
        catch (Exception e){
            return catchException ("updateAssign: {}",e,"Error","Unable to update assign detials. Please try again.");
        }
    }

    private ResponseEntity<Object> addApproverDetails(Integer requestId){
        try{
            Optional<EmployeeRequestDetails> employeeRequestDetails = employeeRequestDetailsRepo.findById (requestId);

            if(employeeRequestDetails.isEmpty () ){
                return catchException ("addApproverDetails : {} ",null, "Validation error","Employee request details not found. " );
            }
            Integer locationId = loginRepository.findLocationIdByEmployeeId(employeeRequestDetails.get ().getEmployeeId ());
            Optional<RequestApproverDetails> requestApproverDetails = approverDetailsRepo.findByLocationId (locationId);

            if(requestApproverDetails.isEmpty () ){
                return catchException ("addApproverDetails : {} ",null, "Validation error","Approver details mot found." );
            }

            EmployeeRequestTracking employeeRequestTracking =  new EmployeeRequestTracking ();

            employeeRequestTracking.setRequestId (employeeRequestDetails.get ());
            employeeRequestTracking.setAssignedTo (requestApproverDetails.get ().getEmployeeId ());
            employeeRequestTracking.setEmployeeId (employeeRequestDetails.get ().getEmployeeId ());
            employeeRequestTracking.setRequestStatus (Constants.INITIAL_REQUEST_STATUS_ID);

            EmployeeRequestTracking employeeRequestTrackingDetails = requestTrackingRepo.save (employeeRequestTracking);

            ApproverEmailDetails approverEmailDetails = SqlConnectionSetup.getJdbcConnection ().queryForObject ("Exec spGetRequestApproverEmailDetails ?"
                    , BeanPropertyRowMapper.newInstance (ApproverEmailDetails.class)
                    , requestId);



            response.setData (approverEmailDetails);
            response.setStatus (true);
            response.setMessage ("Request has been approved and notification sent to IT Support for further processing.");
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);


        }catch(Exception e) {
            return catchException("addApproverDetails()",e,"Failed","Unable to add approver details.");
        }
    }
    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
        logger.error("{} Error : {}" , methodName, e);
        response.setStatus(false);
        response.setInformation(new ExceptionBean (Instant.now(), message, description));
        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }
}
