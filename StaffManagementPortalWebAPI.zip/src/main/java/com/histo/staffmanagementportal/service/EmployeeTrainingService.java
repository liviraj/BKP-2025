package com.histo.staffmanagementportal.service;

import org.springframework.http.ResponseEntity;

import com.histo.staffmanagementportal.dto.EmployeeTrainingDTO;
import com.histo.staffmanagementportal.model.ModifiedDetails;

public interface EmployeeTrainingService {

	public ResponseEntity<Object> getEmployeeTrainingById(Integer trainingId);
	public ResponseEntity<Object> getEmployeeTrainingByEmployeeId(Integer employeeId);
	public ResponseEntity<Object> addEmployeeTrainingDetails(EmployeeTrainingDTO trainingDTO);
	public ResponseEntity<Object> updateEmployeeTraining(EmployeeTrainingDTO employeeTrainingDTO,Integer trainingId);
	public ResponseEntity<Object> deleteEmployeeTrainingById(Integer trainingId, ModifiedDetails modifiedDetails);
	public ResponseEntity<Object> getTrainingCategory();
	
}
