package com.histo.staffmanagementportal.service;

import com.histo.staffmanagementportal.dto.EmployeeHoliDayDTO;
import com.histo.staffmanagementportal.model.FilterModel;
import com.histo.staffmanagementportal.model.FloatingHolidayFilter;
import org.springframework.http.ResponseEntity;

public interface FloatingHolidayService {

    ResponseEntity<Object> getFloatingHoliday(FilterModel filterModel);
    ResponseEntity<Object> addEmployeeFloatingHoliday(EmployeeHoliDayDTO employeeHoliDayDTO);
    ResponseEntity<Object> getFloatingHolidayList(Integer year);

    ResponseEntity<Object> getEmployeeFloatingHoliday(FloatingHolidayFilter floatingHolidayFilter);

}
