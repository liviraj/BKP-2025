package com.histo.staffmanagementportal.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.dto.EmployeeLeaveRequestDTO;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.intranet.entity.*;
import com.histo.staffmanagementportal.intranet.repository.*;
import com.histo.staffmanagementportal.model.*;
import com.histo.staffmanagementportal.service.EmployeeLeaveRequestService;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.time.*;
import java.util.*;


@Service
public class EmployeeLeaveRequestServiceImpl implements EmployeeLeaveRequestService {

	private static final Logger logger = LogManager.getLogger(EmployeeLeaveRequestServiceImpl.class);
	private static final String STATUS = "status";
	private final ResponseModel response;
	private static final String OPTIONAL_TYPE = "Optional type";

	private final LeaveTypeMasterRepository leaveTypeRepository;
	private final EmployeeLeaveRequestMasterRepository leaveRequestMasterRepo;
	private final EmployeeLeaveDetailsRepository leaveDetailsRepo;
	private final SpecialLeaveLedgerRepository slddRepo;
	private final SpecialLeavesDebitMasterRepository leavesDebitMasterRepo;
	private final LeaveLedgerRepository leaveLedgerRepo;
	private final EmployeeHolidayRepository employeeHolidayRepo;
	private final USSickLeaveDetailsRepository usSickLeaveDetailsRepo;
	private final EmployeeWorkRepository employeeWorkRepo;
	private final LoginRepository loginRepository;
	private final HolidayRepository holidayRepository;

	MappingJacksonValue mappingJacksonValue;

	public EmployeeLeaveRequestServiceImpl(ResponseModel response, LeaveTypeMasterRepository leaveTypeRepository,
										   EmployeeLeaveRequestMasterRepository leaveRequestMasterRepo,
										   EmployeeLeaveDetailsRepository leaveDetailsRepo, SpecialLeaveLedgerRepository leavesDebitDetailRepo,
										   SpecialLeavesDebitMasterRepository leavesDebitMasterRepo, LeaveLedgerRepository leaveLedgerRepo,
										   EmployeeHolidayRepository employeeHolidayRepo, USSickLeaveDetailsRepository usSickLeaveDetailsRepo
			, EmployeeWorkRepository employeeWorkRepo, LoginRepository loginRepository, HolidayRepository holidayRepository
	) {
		this.response = response;
		this.leaveTypeRepository = leaveTypeRepository;
		this.leaveRequestMasterRepo = leaveRequestMasterRepo;
		this.leaveDetailsRepo = leaveDetailsRepo;
		this.slddRepo = leavesDebitDetailRepo;
		this.leavesDebitMasterRepo = leavesDebitMasterRepo;
		this.leaveLedgerRepo = leaveLedgerRepo;
		this.employeeHolidayRepo = employeeHolidayRepo;
		this.usSickLeaveDetailsRepo = usSickLeaveDetailsRepo;
		this.employeeWorkRepo = employeeWorkRepo;
		this.loginRepository = loginRepository;
		this.holidayRepository = holidayRepository;
	}

	@Override
	public ResponseEntity<Object> getLeaveType(Integer locationId) {
		try {
			List<LeaveTypeMaster> leaveTypeByLocationID = leaveTypeRepository.findByLocationID(locationId);
			response.setData(leaveTypeByLocationID);

			if(locationId == 0) {

				List<LeaveTypeMaster> leaveType = leaveTypeRepository.findByLocationID(LocationEum.INDIA.getValue());
				leaveType.addAll(leaveTypeRepository.findByLocationID(LocationEum.USA.getValue()));
				leaveType.add(new LeaveTypeMaster(0,"All",0));

				response.setData(leaveType);
			}
			response.setStatus(true);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);


		} catch (Exception e) {
			return catchException("getLeaveType()", e, "Failed", "Leave type not found");
		}
	}

	@Override
	public ResponseEntity<Object> getLastLeaveAvailed(Integer employeeId) {
		try {
			Integer locationId = loginRepository.findLocationIdByEmployeeId(employeeId);

			List<EmployeeLeaveRequestMaster> leaveRequestDetails = leaveRequestMasterRepo
					.findByEmployeeIdOrderByLeaveFromDesc(employeeId);

			EmployeeLastLeaveDetails employeeLeaveDetail = new EmployeeLastLeaveDetails();

			employeeLeaveDetail = Objects.equals(locationId, LocationEum.INDIA.getValue()) ?
					getIndiaEmpLastLeaveDetails(employeeId,locationId):getUsEmpLeaveBalance(employeeId);

			if(ObjectUtils.isNotEmpty(leaveRequestDetails)) {

				Optional<EmployeeLeaveRequestMaster> lastestLeaveDetails = leaveRequestMasterRepo.findFirstByEmployeeIdOrderByLeaveEnteredOnDesc(employeeId);

				employeeLeaveDetail.setLastLeaveFromDate(InstantFormatter.InstantFormat(lastestLeaveDetails.get().getLeaveFrom()));
				employeeLeaveDetail.setLastLeaveToDate(InstantFormatter.InstantFormat(lastestLeaveDetails.get().getLeaveTo()));

				Optional<EmployeeLeaveRequestMaster> leaveDetails = leaveRequestDetails.stream()
						.filter(request -> !leaveDetailsRepo
								.findByLeaveRequestId_IdAndAvailedOrderByLeaveDateDesc(request.getId(), "Y").isEmpty())
						.findFirst();
				if(leaveDetails.isPresent()) {

					String approvalStatus = leaveDetailsRepo.getApprovalStatus(leaveDetails.get().getId());

					employeeLeaveDetail.setLastLeaveAvailed(new LastLeaveAvailed(InstantFormatter.InstantFormat(leaveDetails.get().getLeaveTo()), approvalStatus));
				}

			}

			response.setStatus(true);
			response.setData(employeeLeaveDetail);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

		} catch (Exception e) {
			return catchException("getLastLeaveAvailed()", e, "Failed", "Leave details not found");
		}
	}

	private ResponseEntity<Object> addEmployeeLeaveRequest(EmployeeLeaveRequestDTO leaveRequestDTO,Integer employeeId,boolean isLossOfPay){
		try {
			Integer locationId = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetLocationIdByEmployeeId ?;",
					Integer.class,leaveRequestDTO.getEmployeeId());

			LeaveDatesModel leaveDates = excludeHoliday(leaveRequestDTO, locationId);
			double noOfDaysApplied = leaveDates.noOfDaysApplied();

			Instant leaveFrom = InstantFormatter.InstantFormat (leaveRequestDTO.getLeaveFrom ());  //16  11
			Instant leaveTo = InstantFormatter.InstantFormat (leaveRequestDTO.getLeaveTo ());

			ResponseEntity<Object> responseEntity = validateLeaveBalance(leaveRequestDTO.getEmployeeId(), leaveRequestDTO.getTypeofLeave(), noOfDaysApplied);
			if(responseEntity.getStatusCode() == HttpStatus.OK || Boolean.TRUE.equals(isLossOfPay)) {

				List<EmployeeLeaveDetails> employeeLeaveDetails = leaveDetailsRepo
						.findByEmployeeIdAndLeaveDateBetween (leaveRequestDTO.getEmployeeId ()
								, InstantFormatter.InstantFormat (leaveRequestDTO.getLeaveFrom ()), InstantFormatter.InstantFormat (leaveRequestDTO.getLeaveTo ()))
						.stream ()
						.filter (leaveDetail -> !Objects.equals (leaveDetail.getLeaveRequestId ().getId (), leaveRequestDTO.getLeaveRequestDetailId ()))
						.filter (leaveDetails -> !leaveDetailsRepo.findByLeaveRequestId_IdAndApprovalStatusNotIn (leaveDetails.getLeaveRequestId ().getId (),
								Arrays.asList (LeaveStatusEnum.CANCELLED_STATUS.getValue (), LeaveStatusEnum.REJECTED_STATUS.getValue ())).isEmpty ()).toList ();


				List<Instant> workDays = leaveDates.workDays();

				if(workDays.isEmpty()) {
					response.setStatus(false);
					response.setInformation(new ExceptionBean(Instant.now(), "Invalid date",
							"Requested dates is holiday, Please select valid date."));
					mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
					return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
				} else if (!employeeLeaveDetails.isEmpty()) {

					boolean isOverlapping = Boolean.TRUE;

					List<OverlapLeaveDetails> overlapLeaveDetails = new ArrayList<> ();

					employeeLeaveDetails.stream ().forEach (data -> {
						Instant existingLeaveFrom = data.getLeaveRequestId().getLeaveFrom();  //18	09
						Instant existingLeaveTo = data.getLeaveRequestId().getLeaveTo();  //20	11

						OverlapLeaveDetails leaveDetails = new OverlapLeaveDetails ();

						leaveDetails.setLeaveDate (data.getLeaveDate ());

						if (existingLeaveFrom.equals (existingLeaveTo)){
							leaveDetails.setFullOrHalfDay ((data.getLeaveRequestId ().getLeaveFromForH ().equalsIgnoreCase ("H")
									|| data.getLeaveRequestId ().getLeaveToForH ().equalsIgnoreCase ("H")) ? "H" : "F");
						} else{
							leaveDetails.setFullOrHalfDay (data.getLeaveDate ().equals (existingLeaveFrom)? data.getLeaveRequestId ().getLeaveFromForH ():
									data.getLeaveDate ().equals (existingLeaveTo)? data.getLeaveRequestId ().getLeaveToForH ():"F");
						}

						leaveDetails.setTypeOfLeave (data.getLeaveRequestId ().getTypeofLeave ().getLeaveTypeId ());

						overlapLeaveDetails.add (leaveDetails);
					});

					List<OverlapLeaveDetails> newLeaveDetails = new ArrayList<> ();

					workDays.stream ().forEach (data -> {

						OverlapLeaveDetails leaveDetails = new OverlapLeaveDetails ();

						leaveDetails.setLeaveDate (data);
						if (leaveFrom.equals (leaveTo)){
							leaveDetails.setFullOrHalfDay ((leaveRequestDTO.getLeaveFromForH ().equalsIgnoreCase ("H")
									|| leaveRequestDTO.getLeaveToForH ().equalsIgnoreCase ("H")) ? "H" : "F");
						} else{
							leaveDetails.setFullOrHalfDay (data.equals (leaveFrom)? leaveRequestDTO.getLeaveFromForH ():
									data.equals (leaveTo)? leaveRequestDTO.getLeaveToForH ():"F");
						}
						leaveDetails.setTypeOfLeave (leaveRequestDTO.getTypeofLeave ());
						newLeaveDetails.add (leaveDetails);
					});

					if(!overlapLeaveDetails.isEmpty () && overlapLeaveDetails.size () < 2){

						for(OverlapLeaveDetails leaveDetails : overlapLeaveDetails){
							isOverlapping = newLeaveDetails.stream().anyMatch(data ->
									data.getLeaveDate().equals(leaveDetails.getLeaveDate()) &&
											("F".equalsIgnoreCase(data.getFullOrHalfDay()) || "F".equalsIgnoreCase(leaveDetails.getFullOrHalfDay()))
							);

						}}

					if (isOverlapping) {
						response.setStatus(false);
						response.setInformation(new ExceptionBean(Instant.now(), "Failed",
								"Requested dates are overlapping with your previous requests. Please check."));
						mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
						return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
					}
				}else if(Objects.equals(locationId, LocationEum.INDIA.getValue())) {
					LeaveTypeMaster casualLeaveTypeId = leaveTypeRepository.findByLocationIDAndLeaveTypeName(locationId, LeaveTypeEnum.CASUALLEAVE.getValue())
							.orElseThrow (() -> new NullPointerException ("Casual leave type not found."));

					if ( noOfDaysApplied > 2 && casualLeaveTypeId.getLeaveTypeId().equals(leaveRequestDTO.getTypeofLeave()) ) {
						response.setStatus(false);
						response.setInformation(new ExceptionBean(Instant.now(), "Exceeded leave balance",
								"Only 2 casual leave availed for a month. Please contact HR!"));
						mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
						return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
					}

				}
				response.setStatus(true);
				response.setData(leaveDates);
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

			}
			return responseEntity;

		} catch (Exception e) {
			return catchException("addEmployeeLeaveRequest()", e, "Failed", "Error in processing the leave request, please try again!");
		}

	}

	@Override
	public ResponseEntity<Object> addLeaveRequest(EmployeeLeaveRequestDTO leaveRequestDTO,Integer employeeId,boolean isLossOfPay) {

		try {
			LeaveTypeMaster leaveType = leaveTypeRepository.findById(leaveRequestDTO.getTypeofLeave()).
					orElseThrow (() -> new NullPointerException ("Leave type not found. Please select valid leave type."));

			ResponseEntity<Object> responseEntity = addEmployeeLeaveRequest(leaveRequestDTO, leaveRequestDTO.getEmployeeId(), isLossOfPay);
			if(responseEntity.getStatusCode() == HttpStatus.OK) {

				ResponseModel value = (ResponseModel) ((MappingJacksonValue) responseEntity.getBody()).getValue();
				LeaveDatesModel leaveDatesDetail = (LeaveDatesModel) value.getData();

				EmployeeLeaveRequestMaster leaveRequestDetail = new EmployeeLeaveRequestMaster();

				leaveRequestDetail.setEmployeeId(leaveRequestDTO.getEmployeeId());
				leaveRequestDetail.setLeaveFrom(InstantFormatter.InstantFormat(leaveRequestDTO.getLeaveFrom()));
				leaveRequestDetail.setLeaveTo(InstantFormatter.InstantFormat(leaveRequestDTO.getLeaveTo()));
				leaveRequestDetail.setLeaveFromForH(Boolean.TRUE.equals(leaveRequestDetail.equals(leaveRequestDTO))?"F":leaveRequestDTO.getLeaveFromForH());
				leaveRequestDetail.setLeaveToForH(leaveRequestDTO.getLeaveToForH());
				leaveRequestDetail.setLeaveEnteredBy(employeeId);
				leaveRequestDetail.setLeaveEnteredOn(InstantFormatter.InstantFormat(leaveRequestDTO.getLeaveEnteredOn()));
				leaveRequestDetail.setTypeofLeave(leaveType);
				leaveRequestDetail.setRemarks(leaveRequestDTO.getRemarks());
				leaveRequestDetail.setStatus("To be Reviewed");
				leaveRequestDetail.setLeaveRequestDate(InstantFormatter.InstantFormat(leaveRequestDTO.getLeaveEnteredOn()));
				EmployeeLeaveRequestMaster employeeLeaveRequest = leaveRequestMasterRepo.save(leaveRequestDetail);

				List<Instant> workDays = leaveDatesDetail.workDays();

				for(Instant leaveDate : workDays) {
					EmployeeLeaveDetails employeeLeaveDetail = new EmployeeLeaveDetails();

					employeeLeaveDetail.setLeaveRequestId(employeeLeaveRequest);
					employeeLeaveDetail.setEmployeeId(leaveRequestDTO.getEmployeeId());
					employeeLeaveDetail.setLeaveDate(leaveDate);
					employeeLeaveDetail.setApprovalStatus(Constants.TO_BE_APPROVED);
					employeeLeaveDetail.setIsIntimated('Y');

					EmployeeLeaveDetails leaveDetail = leaveDetailsRepo.save(employeeLeaveDetail);
				}

				response.setStatus(true);
				response.setMessage("Your leave request applied Successfully");
				response.setData(employeeLeaveRequest);
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "message", STATUS });
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

			}

			return responseEntity;

		} catch (Exception e) {
			return catchException("addLeaveRequest()", e, "Failed", "Error in processing the leave request, please try again!");
		}
	}

	@Override
	public ResponseEntity<Object> getEmployeeLeaveHistory(LeaveHistoryFilterModel filterModel) {
		try {
			List<LeaveHistoryModel> employeeLeaveHistory = SqlConnectionSetup.getJdbcConnection()
					.query("exec spGetLeaveHistory ?,?,?,?", BeanPropertyRowMapper.newInstance(LeaveHistoryModel.class),
							filterModel.getEmployeeId(),
							filterModel.getFromDate(),
							filterModel.getToDate(),
							filterModel.getApprovalStatus());
			response.setData(employeeLeaveHistory);
			response.setStatus(true);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch (Exception e) {
			return catchException("getEmployeeLeaveHistory()", e, "Failed", "Employee leave history not found");
		}
	}

	public EmployeeLastLeaveDetails getIndiaEmpLastLeaveDetails(Integer employeeId,Integer locationId) {
		IndiaEmployeeLeaveDetails employeeLeaveDetail = new IndiaEmployeeLeaveDetails();
		try {
			SpecialLeavesDebitMaster clLeaveTypeId = leavesDebitMasterRepo.getLeaveDetail(locationId, LeaveTypeEnum.CASUALLEAVE.getValue())
					.orElseThrow (() -> new NullPointerException ("Casual Leave type details not found."));

			SpecialLeavesDebitMaster slLeaveTypeId = leavesDebitMasterRepo.getLeaveDetail(locationId, LeaveTypeEnum.SICKLEAVE.getValue())
					.orElseThrow (() -> new NullPointerException ("Sick Leave type details not found."));

			List<SpecialLeaveLedger> clDebitDetails = slddRepo
					.getLeaveBalance(employeeId, clLeaveTypeId.getLeaveTypeID(),
							locationId);

			List<SpecialLeaveLedger> slDebitDetails = slddRepo
					.getLeaveBalance(employeeId, slLeaveTypeId.getLeaveTypeID(),
							locationId);

			List<LeaveLedger> plDebitDetails = leaveLedgerRepo.findLeaveBalance (employeeId);

			LeaveLedger plBalance = leaveLedgerRepo.findFirstByEmployeeIdOrderByIdDesc(employeeId);

			double casualLeaveTaken = clDebitDetails.stream().mapToDouble(SpecialLeaveLedger::getDebit).sum();

			double sickLeaveTaken = slDebitDetails.stream().mapToDouble(SpecialLeaveLedger::getDebit).sum();

			double privilegeLeaveTaken = plDebitDetails.stream ()
					.filter (data -> !data.getComments ().equalsIgnoreCase (Constants.LEAVE_ENCASHMENT_COMMENT))
					.mapToDouble (LeaveLedger::getDebitDays).sum ();

			employeeLeaveDetail.setSickLeaveDetails(new LeaveDetails(sickLeaveTaken, slDebitDetails.isEmpty()?0:slDebitDetails.get(0).getBalance()));
			employeeLeaveDetail.setVacationLeaveDetails(new LeaveDetails(privilegeLeaveTaken, ObjectUtils.isEmpty(plBalance)?0:plBalance.getBalanceDays()));
			employeeLeaveDetail.setCasualLeaveDetails(new LeaveDetails(casualLeaveTaken, clDebitDetails.isEmpty() ? 0: clDebitDetails.get(0).getBalance()));

		} catch(Exception e) {
			catchException("getIndiaEmpLastLeaveDetails()", e, "Failed", "Employee leave details not found");
		}


		return employeeLeaveDetail;
	}

	public EmployeeLastLeaveDetails getUsEmpLeaveBalance(Integer employeeId) {
		EmployeeLastLeaveDetails employeeLeaveDetail = new EmployeeLastLeaveDetails();
		try {
			List<LeaveLedger> vacationLeaveDetails = leaveLedgerRepo.findLeaveBalance (employeeId);

			List<USSickLeaveDetails> usSickLeaveDetails = usSickLeaveDetailsRepo.getLeaveBalance(employeeId);

			LeaveLedger vacationBalance = leaveLedgerRepo.findFirstByEmployeeIdOrderByIdDesc(employeeId);

			double vacationLeaveBalance = ObjectUtils.isEmpty(vacationBalance)?0:vacationBalance.getBalanceDays();

			double sickLeavebalance = usSickLeaveDetails.isEmpty()?0:usSickLeaveDetails.get(0).getBalance();
			double vacationLeave = vacationLeaveDetails.stream().mapToDouble(LeaveLedger :: getDebitDays ).sum();
			double sickLeave = usSickLeaveDetails.stream().mapToDouble(USSickLeaveDetails::getDebitDays).sum();

			employeeLeaveDetail.setVacationLeaveDetails(new LeaveDetails(vacationLeave,vacationLeaveBalance ));
			employeeLeaveDetail.setSickLeaveDetails(new LeaveDetails(sickLeave,sickLeavebalance));
		} catch(Exception e) {
			catchException("getUsEmpLeaveBalance()", e, "Failed", "Employee leave details not found");
		}
		return employeeLeaveDetail;
	}

	@Override
	public LeaveDatesModel excludeHoliday(EmployeeLeaveRequestDTO leaveRequestDTO,Integer locationId) {

		ArrayList<Instant> workDays = new ArrayList<>();
		double noOfDaysApplied=0;
		LeaveDatesModel leaveDatesModel = new LeaveDatesModel(noOfDaysApplied, workDays);
		try {
			Instant date = InstantFormatter.InstantFormat(leaveRequestDTO.getLeaveFrom());
			if (!leaveRequestDTO.getLeaveFrom().equals(leaveRequestDTO.getLeaveTo())) {
				noOfDaysApplied = "F".equals(leaveRequestDTO.getLeaveToForH()) ? noOfDaysApplied + 1
						: noOfDaysApplied + 0.5;
				noOfDaysApplied = "F".equals(leaveRequestDTO.getLeaveFromForH()) ? noOfDaysApplied + 1
						: noOfDaysApplied + 0.5;
				noOfDaysApplied = noOfDaysApplied
						+ Duration.between(InstantFormatter.InstantFormat(leaveRequestDTO.getLeaveFrom())
						, InstantFormatter.InstantFormat(leaveRequestDTO.getLeaveTo())).toDays() - 1;
			} else {
				noOfDaysApplied = "H".equals(leaveRequestDTO.getLeaveFromForH()) ? 0.5 :"H".equals(leaveRequestDTO.getLeaveToForH()) ? 0.5 : 1;
			}
			while(!date.isAfter(InstantFormatter.InstantFormat(leaveRequestDTO.getLeaveTo()))) {
				Optional<Holiday> employeeHoliday = holidayRepository
						.findHolidayByLocationidAndStartDate(date.toString (), locationId,Boolean.FALSE.toString ());

				Boolean isHoliday = employeeHoliday.isPresent();

				DayOfWeek dayOfWeek = InstantFormatter.getWeek(date);

				if(dayOfWeek.equals(DayOfWeek.SATURDAY )
						|| dayOfWeek.equals(DayOfWeek.SUNDAY )
						|| Boolean.TRUE.equals(isHoliday)) {


					if(date.equals(leaveRequestDTO.getLeaveFrom()) && "H".equals(leaveRequestDTO.getLeaveFromForH()))
						noOfDaysApplied -= 0.5;
					else if(date.equals(leaveRequestDTO.getLeaveTo()) && "H".equals(leaveRequestDTO.getLeaveToForH()))
						noOfDaysApplied -= 0.5;
					else
						noOfDaysApplied -= 1;
				} else {
					workDays.add(date);
				}

				date = date.plus(Duration.ofDays(1));
				leaveDatesModel =  new LeaveDatesModel(noOfDaysApplied, workDays);
			}
		}catch(Exception e) {
			catchException("excludeHoliday()", e, "Failed", "Unable to get employee holiday details");
		}
		return leaveDatesModel;
	}

	@Override
	public ResponseEntity<Object> validateLeaveBalance(Integer employeeId,Integer leaveTypeId,double noOfDaysApplied) {

		try {
			double balance = 0;
			Optional<LeaveTypeMaster> leaveType = leaveTypeRepository.findById(leaveTypeId);
			Integer locationId = loginRepository.findLocationIdByEmployeeId(employeeId);

			EmployeeLastLeaveDetails employeeLastLeaveDetails = new EmployeeLastLeaveDetails();
			if (Objects.equals(locationId, LocationEum.INDIA.getValue())) {
				employeeLastLeaveDetails = getIndiaEmpLastLeaveDetails(employeeId, locationId);
			} else {
				employeeLastLeaveDetails = getUsEmpLeaveBalance(employeeId);
			}

			String leaveTypeName = leaveTypeRepository
					.findLeaveTypeNameByLeaveTypeId(leaveTypeId);
			switch (leaveTypeName) {

				case "Casual Leave":
					balance = ((IndiaEmployeeLeaveDetails) employeeLastLeaveDetails).getCasualLeaveDetails().balance();
					break;

				case "Vacation","Privilege Leave":
					balance = employeeLastLeaveDetails.getVacationLeaveDetails().balance();
					break;
				case "Sick Leave":
					balance = employeeLastLeaveDetails.getSickLeaveDetails().balance();
					break;
				default:
					balance = 0;
					break;
			}
			if(ObjectUtils.equals(balance,0.0) ) {
				if(ObjectUtils.equals(leaveTypeName,LeaveTypeEnum.VACATION.getValue()) || ObjectUtils.equals(leaveTypeName,LeaveTypeEnum.PRIVILEGELEAVE.getValue())){

					return catchException("validateLeaveBalance()", null, OPTIONAL_TYPE, "Employee not having sufficient leave balance" +
							". Are you sure want to add leave on loss of pay");
				}
				return catchException("validateLeaveBalance()", null, "InSufficient leave balance", "Employee not having sufficient leave balance.");

			} else if (balance < noOfDaysApplied ) {
				return catchException("validateLeaveBalance()", null, "Not having sufficient leave balance",
						"Employee having minimum "+balance + " days leave balance");
			}
			response.setData("Employee having sufficient leave balance");
			response.setStatus(true);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "data", STATUS });
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		} catch (Exception e) {
			return catchException("validateLeaveBalance()", e, "Failed", "Cannot get employee leave balance");
		}
	}


	@Override
	public ResponseEntity<Object> editLeaveRequest(EmployeeLeaveRequestDTO leaveRequestDTO, Integer leaveRequestId,boolean isLossOfPay) {
		try {
			LeaveTypeMaster leaveType = leaveTypeRepository.findById(leaveRequestDTO.getTypeofLeave())
					.orElseThrow (() -> new NullPointerException ("Leave Type details not found."));

			Optional<EmployeeLeaveRequestMaster> leaveRequestDetail = leaveRequestMasterRepo.findById(leaveRequestDTO.getLeaveRequestDetailId());
			if(leaveRequestDetail.isEmpty()) {
				return catchException("editLeaveRequest()", null, "Error", "Leave request details not found");
			}

			List<EmployeeLeaveDetails> leaveDetails = leaveDetailsRepo.findByLeaveRequestId_Id(leaveRequestDTO.getLeaveRequestDetailId());

			boolean isReviewed = leaveDetails.stream().anyMatch(leave -> leave.getApprovalStatus().equalsIgnoreCase(LeaveStatusEnum.APPROVED_STATUS.getValue()) ||
					leave.getApprovalStatus().equalsIgnoreCase(LeaveStatusEnum.CANCELLED_STATUS.getValue()) ||
					leave.getApprovalStatus().equalsIgnoreCase(LeaveStatusEnum.REJECTED_STATUS.getValue()));

			if(isReviewed) {
				return catchException("editLeaveRequest()", null, "Error", "Cannot edit Leave request </br> Request has been reviewed already");
			}

			ResponseEntity<Object> responseEntity = addEmployeeLeaveRequest(leaveRequestDTO, leaveRequestDTO.getEmployeeId(), isLossOfPay);
			if(responseEntity.getStatusCode() == HttpStatus.OK) {

				ResponseModel value = (ResponseModel) ((MappingJacksonValue) responseEntity.getBody()).getValue();
				LeaveDatesModel leaveDatesDetail = (LeaveDatesModel) value.getData();

				leaveRequestDetail.get().setEmployeeId(leaveRequestDTO.getEmployeeId());
				leaveRequestDetail.get().setLeaveFrom(InstantFormatter.InstantFormat(leaveRequestDTO.getLeaveFrom()));
				leaveRequestDetail.get().setLeaveTo(InstantFormatter.InstantFormat(leaveRequestDTO.getLeaveTo()));
				leaveRequestDetail.get().setLeaveFromForH(Boolean.TRUE.equals(leaveRequestDetail.equals(leaveRequestDTO))?"F":leaveRequestDTO.getLeaveFromForH());
				leaveRequestDetail.get().setLeaveToForH(leaveRequestDTO.getLeaveToForH());
				leaveRequestDetail.get().setModifiedOn(InstantFormatter.InstantFormat(leaveRequestDTO.getModifiedOn()));
				leaveRequestDetail.get().setLeaveModifiedBy(leaveRequestDTO.getLeaveModifiedBy());
				leaveRequestDetail.get().setTypeofLeave(leaveType);
				leaveRequestDetail.get().setRemarks(leaveRequestDTO.getRemarks());
				leaveRequestDetail.get().setStatus("To be Reviewed");

				EmployeeLeaveRequestMaster employeeLeaveRequest = leaveRequestMasterRepo.save(leaveRequestDetail.get());

				List<Instant> workDays = leaveDatesDetail.workDays();

				leaveDetails.forEach(leaveDetailsRepo::delete);
				for(Instant leaveDate : workDays) {
					EmployeeLeaveDetails employeeLeaveDetail = new EmployeeLeaveDetails();

					employeeLeaveDetail.setLeaveRequestId(employeeLeaveRequest);
					employeeLeaveDetail.setEmployeeId(leaveRequestDTO.getEmployeeId());
					employeeLeaveDetail.setLeaveDate(leaveDate);
					employeeLeaveDetail.setApprovalStatus(Constants.TO_BE_APPROVED);
					employeeLeaveDetail.setIsIntimated('Y');

					EmployeeLeaveDetails leaveDetail = leaveDetailsRepo.save(employeeLeaveDetail);
				}

				response.setStatus(true);
				response.setMessage("Updated leave request applied Successfully");
				response.setData(employeeLeaveRequest);
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "message", STATUS });
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

			}
			return responseEntity;

		} catch(Exception e) {
			return catchException("editLeaveRequest()", e, "Failed", "Unable to edit leave request");
		}
	}


	private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
		logger.error("{} Error : {}" + methodName, e);
		response.setStatus(false);
		response.setInformation(new ExceptionBean(Instant.now(), message, description));
		mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
		return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);

	}

}
