package com.histo.staffmanagementportal.service.impl;

import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.histo.staffmanagementportal.intranet.entity.Document;
import com.histo.staffmanagementportal.intranet.repository.DocumentRepository;
import com.histo.staffmanagementportal.model.StaffModuleName;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.dto.EmployeeWorkHistoryDTO;
import com.histo.staffmanagementportal.dto.EmployeeWorkHistoryView;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.helper.DateValidation;
import com.histo.staffmanagementportal.intranet.entity.EmployeeWorkHistory;
import com.histo.staffmanagementportal.intranet.repository.EmployeeWorkHistoryRepository;
import com.histo.staffmanagementportal.mapper.EmployeeMapper;
import com.histo.staffmanagementportal.model.Constants;
import com.histo.staffmanagementportal.model.ModifiedDetails;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.service.EmployeeWorkHistoryService;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;

@Service
public class EmployeeWorkHistoryServiceImpl implements EmployeeWorkHistoryService {

	private static final Logger logger = LogManager.getLogger(EmployeeWorkHistoryServiceImpl.class);

	private static final String STATUS = "status";
	
	@Autowired
    private ResponseModel response;

    private MappingJacksonValue mappingJacksonValue;

    private final EmployeeWorkHistoryRepository workHistoryRepository;
    
    @Autowired
    private EmployeeMapper mapper;

	private final DocumentRepository documentRepository;

	public EmployeeWorkHistoryServiceImpl(EmployeeWorkHistoryRepository workHistoryRepository, DocumentRepository documentRepository) {
		this.workHistoryRepository = workHistoryRepository;
		this.documentRepository = documentRepository;
	}


	@Override
	public ResponseEntity<Object> getWorkHistoryByEmployeeId(Integer employeeId) {
		try {
			List<EmployeeWorkHistoryView> employeeWorkHistory = SqlConnectionSetup.getJdbcConnection()
			.query("exec spGetWorkHistoryByEmpId ?" , BeanPropertyRowMapper.newInstance(EmployeeWorkHistoryView.class),
					           employeeId
					      );
			response.setStatus(true);
			response.setData(employeeWorkHistory);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK); 
		}
		catch(Exception e) {
			return catchException("getWorkHistoryByEmployeeId()", e, "Error", "Employee work history details not found");
		}
	}

	@Override
	public ResponseEntity<Object> getWorkHistoryById(Integer workHistoryId) {
		try {
			EmployeeWorkHistoryDTO workHistory = SqlConnectionSetup.getJdbcConnection()
					.queryForObject("exec spGetEmployeeWorkHistoryById ?", BeanPropertyRowMapper.newInstance(EmployeeWorkHistoryDTO.class),workHistoryId);

			if(workHistory == null || ObjectUtils.isEmpty (workHistory)){
				return catchException("getWorkHistoryById()", null, "Error", "Employee work history details not found");
			}

			List<Document> documentDetails = documentRepository.findByDocumentIdAndRecordStatusAndDocumentType (workHistoryId,
					Constants.ACTIVE_RECORD_STATUS,
					StaffModuleName.WORKHISTORY.getValue ());

			workHistory.setDocumentDetails (documentDetails);
			response.setStatus(true);
			response.setData(workHistory);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}
		catch(Exception e) {
			return catchException("getWorkHistoryById()", e, "Error", "Employee work history details not found");
		}
	}

	@Override
	public ResponseEntity<Object> addEmployeeWorkHistory(EmployeeWorkHistoryDTO workHistoryDTO) {
		try {
			if(DateValidation.validateDate(workHistoryDTO.getDateofJoin(), workHistoryDTO.getRelievingDate())) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(), "Invalid Date", "Relieving date should not be lesser than date of joining"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"information",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT); 
			}
			EmployeeWorkHistory employeeWorkHistory = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spInsertEmployeeWorkHistory ?,?,?,?,?,?,?,?,?,?;", BeanPropertyRowMapper.newInstance(EmployeeWorkHistory.class), 
					new Object[] {
							0,
							workHistoryDTO.getEmployeeId(),
							workHistoryDTO.getEmployerName(),
							workHistoryDTO.getDesignation(),
							workHistoryDTO.getDateofJoin(),
							workHistoryDTO.getRelievingDate(),
							workHistoryDTO.getReportingTo(),
							workHistoryDTO.getModifiedBy(),
							workHistoryDTO.getEmployeeImage(),
							workHistoryDTO.getEmployeeImageBinary()
					});
			EmployeeWorkHistoryDTO employeeWorkHistoryDto = mapper.employeeWorkHistoryToDto(employeeWorkHistory);

			if(ObjectUtils.isNotEmpty (employeeWorkHistory)){
				for(Document documentDetails : workHistoryDTO.getDocumentDetails ()){

					documentDetails.setDocumentId (employeeWorkHistory.getId ());
					documentDetails.setDocumentType (StaffModuleName.WORKHISTORY.getValue ());

					Document savedDocumentDetails = documentRepository.save (documentDetails);
				}

			}
			response.setStatus(true);
			response.setData(employeeWorkHistoryDto);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
			}
		catch (Exception e) {
			return catchException("addEmployeeWorkHistory()", e, "Error", "Unable to add new employee work history");
		}
	}

	@Override
	public ResponseEntity<Object> updateEmployeeWorkHistory(EmployeeWorkHistoryDTO workHistoryDTO, Integer workHistoryId) {
		try {
			
			List<EmployeeWorkHistory> workHistory = SqlConnectionSetup.getJdbcConnection()
					.query("exec spGetEmployeeWorkHistoryById ?", BeanPropertyRowMapper.newInstance(EmployeeWorkHistory.class),workHistoryId);
			if(workHistory.isEmpty()) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(), "Failed", "Employee Work history details not found"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"information",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT); 
			}
			if(DateValidation.validateDate(workHistoryDTO.getDateofJoin(), workHistoryDTO.getRelievingDate())) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(), "Invalid Date", "Relieving date should not be lesser than date of joining"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"information",STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT); 
			}
			String employeeWorkStatus = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetEmploymentStatusByEmpId ?", String.class,workHistoryDTO.getEmployeeId());
			if(ObjectUtils.equals(employeeWorkStatus, Constants.RELIEVED_STATUS)) {
				return catchException("updateEmployeeWorkHistory()", null, "Not a active employee", "Cannot update relieved employee details");
			}
			EmployeeWorkHistory employeeWorkHistory = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spUpdateEmployeeWorkHistory ?,?,?,?,?,?,?,?,?,?,?;", BeanPropertyRowMapper.newInstance(EmployeeWorkHistory.class), 
					new Object[] {
							workHistoryId,
							workHistoryDTO.getEmployeeId(),
							workHistoryDTO.getEmployerName(),
							workHistoryDTO.getDesignation(),
							workHistoryDTO.getDateofJoin(),
							workHistoryDTO.getRelievingDate(),
							workHistoryDTO.getReportingTo(),
							workHistoryDTO.getModifiedBy(),
							workHistoryDTO.getEmployeeImage(),
							workHistoryDTO.getEmployeeImageBinary(),
							Constants.ACTIVE_RECORD_STATUS
					});

			if(ObjectUtils.isNotEmpty (employeeWorkHistory)){
				workHistoryDTO.getDocumentDetails ().stream ().forEach (document ->{
					if(document.getId () == null){

						document.setDocumentId (workHistoryId);
						document.setDocumentType (StaffModuleName.WORKHISTORY.getValue ());
						document.setCreatedBy (workHistoryDTO.getModifiedBy ());

						Document savedDocumentDetails = documentRepository.save (document);

					}
					else{

						Optional<Document> existingDocumentDetails = documentRepository.findByIdAndRecordStatusAndDocumentType (
								document.getId (),
								Constants.ACTIVE_RECORD_STATUS,
								StaffModuleName.WORKHISTORY.getValue ());

						existingDocumentDetails.get ().setRecordStatus (document.getRecordStatus ());
						existingDocumentDetails.get ().setModifiedBy (workHistoryDTO.getModifiedBy ());

						documentRepository.save (existingDocumentDetails.get ());
					}
				});


			}
			response.setStatus(true);
			response.setMessage ("Updated employee work history");
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"message",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}
		catch (Exception e) {
			return catchException("", e, "Error", "Cannot update employee work history");
		}
	}
	
	private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
		logger.error("{} Error : {}" + methodName, e);
		ExceptionBean exception = new ExceptionBean(Instant.now(), message, description);
		response.setStatus(false);
		response.setInformation(exception);
		mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information",STATUS});
		return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
	}

	@Override
	public ResponseEntity<Object> deleteEmployeeWorkHistoryById(Integer workHistoryId, ModifiedDetails modifiedDetails) {
		try {
			int updateRecordStatusById = workHistoryRepository.updateRecordStatusById(Constants.DELETED_RECORD_STATUS,workHistoryId,modifiedDetails.modifiedBy()
					,InstantFormatter.InstantFormat(modifiedDetails.modifiedDate()));
			
			if(updateRecordStatusById <= 0) {
				
				return catchException("deleteEmployeeWorkHistoryById()",null,"Error","Employee work history details not found");

			}
			
			response.setStatus(true);
			response.setMessage("Work history deleted successfully");
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"message",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}
		catch(Exception e) {
			return catchException("deleteEmployeeWorkHistoryById()", e, "Error", "Cannot delete Employee work history details");
		}
	}

}
