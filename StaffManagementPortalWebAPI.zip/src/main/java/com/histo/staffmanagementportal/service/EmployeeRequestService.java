package com.histo.staffmanagementportal.service;

import com.histo.staffmanagementportal.dto.EmployeeRequestDetailsDTO;
import com.histo.staffmanagementportal.dto.EmployeeRequestTrackingDTO;
import com.histo.staffmanagementportal.dto.RequestStatusDetailsDTO;
import com.histo.staffmanagementportal.model.RequestFilterModel;
import com.histo.staffmanagementportal.model.RequestFilterValue;
import org.springframework.http.ResponseEntity;

public interface EmployeeRequestService {

    ResponseEntity<Object> getEmployeeRequestDetails(RequestFilterValue filterValue);
    ResponseEntity<Object> getRequestTypes();
    ResponseEntity<Object> getRequestDetailsById(Integer requestId);
    ResponseEntity<Object> addNewRequest(EmployeeRequestDetailsDTO requestDTO);
    ResponseEntity<Object> updateRequestDetails(EmployeeRequestDetailsDTO requestDTO, Integer requestId);
    ResponseEntity<Object> approveOrRejectRequest(RequestStatusDetailsDTO requestStatusDetailsDTO);

    ResponseEntity<Object> requestTracking(RequestFilterModel filterModel);
    ResponseEntity<Object> requestStatus();

    ResponseEntity<Object> getAssigneeDetails();

    ResponseEntity<Object> updateAssignee(EmployeeRequestTrackingDTO employeeRequestTrackingDTO, Integer trackingId);
}
