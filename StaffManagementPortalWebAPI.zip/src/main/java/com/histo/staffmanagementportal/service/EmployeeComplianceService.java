package com.histo.staffmanagementportal.service;

import org.springframework.http.ResponseEntity;

import com.histo.staffmanagementportal.dto.EmployeeComplianceDTO;
import com.histo.staffmanagementportal.model.ModifiedDetails;

public interface EmployeeComplianceService {

	ResponseEntity<Object> getEmployeeComplianceByEmployeeId(Integer employeeId);
	ResponseEntity<Object> addEmployeeCompliance(EmployeeComplianceDTO complianceDTO);
	ResponseEntity<Object> updateEmployeeCompliance(EmployeeComplianceDTO complianceDTO,Integer complianceId);
	ResponseEntity<Object> getEmployeeComplianceById(Integer complianceId);
	ResponseEntity<Object> getComplianceCategory();
	ResponseEntity<Object> getCompliancePeriod();
	ResponseEntity<Object> deleteEmployeeComplianceById(Integer nysComplianceId, ModifiedDetails modifiedDetails);
}
