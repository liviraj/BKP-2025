package com.histo.staffmanagementportal.service;

import com.histo.staffmanagementportal.dto.EmployeeDTO;
import org.springframework.http.ResponseEntity;

import com.histo.staffmanagementportal.dto.EmployeeWorkDTO;

public interface EmployeeWorkService {

	public ResponseEntity<Object> getEmployeeWorkByEmployeeId(Integer employeeId);
	public ResponseEntity<Object> addEmployeeWorkDetails(EmployeeWorkDTO workDto, EmployeeDTO employee, Integer loginId);
	public ResponseEntity<Object> updateEmployeeWorkDetails(Integer employeeWorkId,EmployeeWorkDTO workDto);
    public ResponseEntity<Object> getGradeName();
	
}
