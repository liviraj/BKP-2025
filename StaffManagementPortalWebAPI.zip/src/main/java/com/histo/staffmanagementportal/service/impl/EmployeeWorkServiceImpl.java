package com.histo.staffmanagementportal.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.dto.EmployeeDTO;
import com.histo.staffmanagementportal.dto.EmployeePersonalDetailView;
import com.histo.staffmanagementportal.dto.EmployeeWorkDTO;
import com.histo.staffmanagementportal.dto.EmployeeWorkDetailsView;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.helper.DateValidation;
import com.histo.staffmanagementportal.intranet.repository.GradeMasterRepository;
import com.histo.staffmanagementportal.model.Constants;
import com.histo.staffmanagementportal.model.GradeName;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.service.EmailService;
import com.histo.staffmanagementportal.service.EmployeeService;
import com.histo.staffmanagementportal.service.EmployeeWorkService;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

@Service
public class EmployeeWorkServiceImpl implements EmployeeWorkService {

	private static final Logger logger = LogManager.getLogger(EmployeeWorkServiceImpl.class);

	private static final String STATUS = "status";

	@Autowired
    private ResponseModel response;

    private MappingJacksonValue mappingJacksonValue;
    
    @Autowired
    private GradeMasterRepository gradeMasterRepository;

	private final EmployeeService employeeService;

	private final EmailService emailService;

	public EmployeeWorkServiceImpl(EmployeeService employeeService, EmailService emailService) {
		this.employeeService = employeeService;
		this.emailService = emailService;
	}


	@Override
	public ResponseEntity<Object> getEmployeeWorkByEmployeeId(Integer employeeId) {
		try {
			List<EmployeeWorkDetailsView> employeeWorkDetails = SqlConnectionSetup.getJdbcConnection().query ("exec spGetEmployeeWorkByEmployeeId ?",
					BeanPropertyRowMapper.newInstance(EmployeeWorkDetailsView.class),
					employeeId);
			response.setStatus(true);
			response.setData(employeeWorkDetails);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
		}catch(Exception e) {
			return catchException("getEmployeeWorkById()", e, "Failed", "Employee work details not found");
		}
	}

	@Override
	public ResponseEntity<Object> addEmployeeWorkDetails(EmployeeWorkDTO workDto, EmployeeDTO employee, Integer loginId) {
		try {

			EmployeePersonalDetailView employeeDetails = null;

			if (loginId != 0 && ObjectUtils.isNotEmpty(employee)) {
				ResponseEntity<Object> savedEmployee = employeeService.saveEmployee(employee, loginId);

				if (savedEmployee.getStatusCode() != HttpStatus.OK ) {
					return savedEmployee;
				}

				MappingJacksonValue body = (MappingJacksonValue) savedEmployee.getBody();
				ResponseModel value = null;
				if (body != null && body.getValue() instanceof ResponseModel responseModel) {
					value = responseModel;
				} else {
					return catchException("addEmployeeWork()", null, "Failed", "Unable to create employee work.Since employee personal details not created.");
				}

				employeeDetails = (EmployeePersonalDetailView) value.getData();
				workDto.setEmployeeID(employeeDetails.getEmployeeId());
			}

			List<EmployeeWorkDetailsView> employeeWorkDetails = SqlConnectionSetup.getJdbcConnection().query("exec spGetEmployeeWorkByEmployeeId ?", BeanPropertyRowMapper.newInstance(EmployeeWorkDetailsView.class),
					workDto.getEmployeeID());

			if (ObjectUtils.isNotEmpty(employeeWorkDetails)) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(), "Error", "Employee work details already exist"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			} else if (DateValidation.validateDate(workDto.getIssueDateWork(), workDto.getExpiryDateWork())) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(), "Error", "Expiry date should not be lesser than issue date"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
			EmployeeWorkDTO employeeWorkDTO = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spEmployeeWorkInsert ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?", BeanPropertyRowMapper.newInstance(EmployeeWorkDTO.class),
					0,
					workDto.getEmployeeID(),
					workDto.getDoj(),
					workDto.getDesignationID(),
					workDto.getGradeID(),
					workDto.getLaptopID(),
					workDto.getWorkStationID(),
					workDto.getSystemID(),
					workDto.getReportingTo(),
					workDto.getDepartmentID(),
					workDto.getLocationID(),
					workDto.getEmploymentType(),
					workDto.getVisaType(),
					workDto.getPlaceofIssue(),
					workDto.getIssueDateWork(),
					workDto.getExpiryDateWork(),
					workDto.getCountryIssued(),
					workDto.getCurrentLocation(),
					workDto.getConfirmationDate(),
					workDto.getRelievingDate(),
					workDto.getEmploymentStatus(),
					workDto.getClinicalHandler(),
					workDto.getCreatedBy());

			ResponseEntity<Object> sendHipaaEmailForNewJoinee = emailService.sendHipaaEmailForNewJoinee(workDto.getEmployeeID());

			response.setStatus(true);
			response.setData(ObjectUtils.isEmpty(employeeDetails)?employeeWorkDTO : employeeDetails);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CREATED);
		}catch(Exception e) {
			return catchException("addEmployeeWork()", e, "Failed", "Unable to create employee work");
		}
	}


	@Override
	public ResponseEntity<Object> updateEmployeeWorkDetails(Integer employeeWorkId, EmployeeWorkDTO workDto) {
		try {
			EmployeeWorkDTO employeeworkById = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetEmployeeWorkById ?", BeanPropertyRowMapper.newInstance(EmployeeWorkDTO.class),
					employeeWorkId);
			if(ObjectUtils.isEmpty(employeeworkById)) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(), "Failed", "Unable to find employee work detail"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			} else if (DateValidation.validateDate(workDto.getIssueDateWork(), workDto.getExpiryDateWork())) {
				response.setStatus(false);
				response.setInformation(new ExceptionBean(Instant.now(), "Error","Expiry date should not be lesser than issue date"));
				mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
				return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
			}
			String employeeWorkStatus = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spGetEmploymentStatusByEmpId ?", String.class,workDto.getEmployeeID());
			if(ObjectUtils.equals(employeeWorkStatus, Constants.RELIEVED_STATUS)) {
				return catchException("updateEmployeeWorkDetails()", null, "Not a active employee", "Cannot update relieved employee details");
			}
			EmployeeWorkDTO employeeWorkDTO = SqlConnectionSetup.getJdbcConnection().queryForObject("exec spEmployeeWorkUpdate ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?", BeanPropertyRowMapper.newInstance(EmployeeWorkDTO.class),
					employeeWorkId,
					workDto.getDoj(),
					workDto.getDesignationID(),
					workDto.getGradeID(),
					workDto.getLaptopID(),
					workDto.getWorkStationID(),
					workDto.getSystemID(),
					workDto.getReportingTo(),
					workDto.getDepartmentID(),
					workDto.getLocationID(),
					workDto.getEmploymentType(),
					workDto.getVisaType(),
					workDto.getPlaceofIssue(),
					workDto.getIssueDateWork(),
					workDto.getExpiryDateWork(),
					workDto.getCountryIssued(),
					workDto.getCurrentLocation(),
					workDto.getConfirmationDate(),
					workDto.getRelievingDate(),
					workDto.getEmploymentStatus(),
					workDto.getClinicalHandler(),
					workDto.getModifiedBy());
			response.setStatus(true);
			response.setData(employeeWorkDTO);
			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] {"data",STATUS});
			return new ResponseEntity<>(mappingJacksonValue,HttpStatus.OK);
		}catch(Exception e) {
			return catchException("updateEmployeeWorkDetails()", e, "Failed", "Unable to update employee work");
		}
	}

	@Override
    public ResponseEntity<Object> getGradeName() {
        try {
            List<GradeName> gradeName = gradeMasterRepository.getGradeNameByRecordStatus();
            response.setStatus(true);
            response.setData(gradeName);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);        }
        catch(Exception e) {
            return catchException("getGradeName()",e,"Failed","Unable to get grade details");
        }
    }

	private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
		logger.error("{} Error : {}" + methodName, e);
		ExceptionBean exception = new ExceptionBean(Instant.now(), message, description);
		response.setStatus(false);
		response.setInformation(exception);
		mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information",STATUS});
		return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
	}

}
