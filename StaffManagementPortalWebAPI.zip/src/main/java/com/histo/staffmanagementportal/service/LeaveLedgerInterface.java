package com.histo.staffmanagementportal.service;

import com.histo.staffmanagementportal.dto.LeaveLedgerModifyDTO;
import com.histo.staffmanagementportal.model.LedgerCreditModel;
import com.histo.staffmanagementportal.model.LedgerDetails;
import org.springframework.http.ResponseEntity;

public interface LeaveLedgerInterface {

    public ResponseEntity<Object> editLeaveLedger(Integer ledgerId, LeaveLedgerModifyDTO leaveLedger);
    public ResponseEntity<Object> deleteLeaveLedger(Integer ledgerId, LedgerDetails ledgerDetails);
    public ResponseEntity<Object> addLeaveCredit(LedgerCreditModel ledgerCreditModel);
}
