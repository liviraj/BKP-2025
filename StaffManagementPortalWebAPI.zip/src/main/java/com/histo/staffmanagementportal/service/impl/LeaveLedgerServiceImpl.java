package com.histo.staffmanagementportal.service.impl;

import com.histo.configuration.SqlConnectionSetup;
import com.histo.staffmanagementportal.dto.LeaveLedgerDTO;
import com.histo.staffmanagementportal.dto.LeaveLedgerModifyDTO;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.model.*;
import com.histo.staffmanagementportal.service.LeaveLedgerService;
import com.histo.staffmanagementportal.util.ResponseUtil;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

@Service
public class LeaveLedgerServiceImpl implements LeaveLedgerService {
    private static final Logger LOGGER = LogManager.getLogger(LeaveLedgerServiceImpl.class);
    private static final String STATUS = "status";

    private final ResponseModel response;
    private MappingJacksonValue mappingJacksonValue;

    private final USLeaveLedgerImpl usLeaveLedger;

    private final IndiaLeaveLedgerImpl indiaLeaveLedger;

    public LeaveLedgerServiceImpl(ResponseModel response, USLeaveLedgerImpl usLeaveLedger, IndiaLeaveLedgerImpl indiaLeaveLedger) {
    	
        this.response = response;
        this.usLeaveLedger = usLeaveLedger;
        this.indiaLeaveLedger = indiaLeaveLedger;
    }

    @Override
    public ResponseEntity<Object> doFilterInLaveLedger(LeaveLedgerFilterModel ledgerFilterModel) {
        try {
        	List<LeaveLedgerDTO> leaveLedgerDetail = new ArrayList<>();

    		if(ObjectUtils.isNotEmpty(ledgerFilterModel.getLeaveType())) {
        	ArrayList<String> filterSpName = getFilterSpNameByFilterType(ledgerFilterModel.getLeaveType(),ledgerFilterModel.getLocationId());
       
        	for(String sql : filterSpName) 
        	{
        		List<LeaveLedgerDTO> leaveLedger = SqlConnectionSetup.getJdbcConnection()
                        .query("EXEC "+sql+" ?,?,?,?,?,?,?,?;"
                                , BeanPropertyRowMapper.newInstance(LeaveLedgerDTO.class)
                                , ledgerFilterModel.getLocationId()
                                , ledgerFilterModel.getEmployeeId()
                                , ledgerFilterModel.getEmploymentStatus()
                                , ledgerFilterModel.getFromDate()
                                , ledgerFilterModel.getToDate()
                                , ledgerFilterModel.getLeaveType()
                                , ledgerFilterModel.getYear()
                                , LedgerFilterEnum.LEAVE_LEDGER.getValue()
                        );
        		leaveLedgerDetail.addAll(leaveLedger);
        	} }           
            
            response.setStatus(true);
            response.setData(leaveLedgerDetail);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException("doFilterInLaveLedger()", e, "Error", "Something went wrong");
        }
    }

    @Override
    public ResponseEntity<Object> getLeaveSummary(LeaveSummaryFilter leaveSummaryFilter) {
    	try {
    		List<LeaveLedgerDTO> leaveLedgerDetail = new ArrayList<>();

    		if(ObjectUtils.isNotEmpty(leaveSummaryFilter.getLeaveType())) {
    			
        	ArrayList<String> filterSpName = getFilterSpNameByFilterType(leaveSummaryFilter.getLeaveType(),leaveSummaryFilter.getLocationId());
        	
        	for(String sql : filterSpName) 
        	{
        		List<LeaveLedgerDTO> leaveLedger = SqlConnectionSetup.getJdbcConnection()
                        .query("EXEC "+sql+" ?,?,?,?,?,?,?,?;"
                                , BeanPropertyRowMapper.newInstance(LeaveLedgerDTO.class)
                                , leaveSummaryFilter.getLocationId()
                                , leaveSummaryFilter.getEmployeeId()
                                , leaveSummaryFilter.getEmploymentStatus()
                                , StringUtils.EMPTY
                                , StringUtils.EMPTY
                                , leaveSummaryFilter.getLeaveType()
                                , leaveSummaryFilter.getYear()
                                , LedgerFilterEnum.LEAVE_SUMMARY.getValue()
                        );
        		leaveLedgerDetail.addAll(leaveLedger);
        	} }           
            
            response.setStatus(true);
            response.setData(leaveLedgerDetail);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException("getLeaveSummary()", e, "Error", "Something went wrong");
        }
    }

    @Override
    public ResponseEntity<Object> getLeaveBalance(LeaveSummaryFilter leaveSummaryFilter) {
    	try {
        	
             List<Object> leaveLedgerDetail = SqlConnectionSetup.getJdbcConnection()
                        .query("EXEC LeaveBalanceSummary ?,?,?"
                                , new ResultSetMapper()
                                , leaveSummaryFilter.getLocationId()
                                , leaveSummaryFilter.getEmployeeId()
                                , leaveSummaryFilter.getYear()
                        );
        		
            response.setStatus(true);
            response.setData(leaveLedgerDetail);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"data", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException("getLeaveBalance()", e, "Error", "Something went wrong");
        }
    }

    @Override
    public ResponseEntity<Object> editLeaveLedger(Integer ledgerId, LeaveLedgerModifyDTO leaveLedger) {
        try{

            LocationEum locationEum = LocationEum.getEnumFromString(leaveLedger.getLocationId());

            switch(locationEum){
                case USA -> {
                    return usLeaveLedger.editLeaveLedger(ledgerId,leaveLedger);
                }

                case INDIA -> {
                    return indiaLeaveLedger.editLeaveLedger(ledgerId,leaveLedger);
                }

                default -> {
                    return catchException("editLeaveLedger()", null, "Invalid location", "Please select valid location");
                }
            }
        }
        catch(Exception e) {
            return catchException("editLeaveLedger()", e, "Error", "Something went wrong");
        }
    }

    @Override
    public ResponseEntity<Object> deleteLeaveLedger(Integer ledgerId, LedgerDetails ledgerDetails) {
        try{

            LocationEum locationEum = LocationEum.getEnumFromString(ledgerDetails.getLocationId());

            switch(locationEum){
                case USA -> {
                    return usLeaveLedger.deleteLeaveLedger(ledgerId,ledgerDetails);
                }

                case INDIA -> {
                    return indiaLeaveLedger.deleteLeaveLedger(ledgerId,ledgerDetails);
                }

                default -> {
                    return catchException("deleteLeaveLedger()", null, "Invalid location", "Please select valid location");
                }
            }
        }
        catch(Exception e) {
            return catchException("deleteLeaveLedger()", e, "Error", "Something went wrong");
        }
    }

    @Override
    public ResponseEntity<Object> addLeaveCredit(LedgerCreditModel ledgerCreditModel) {
        try{

            LocationEum locationEum = LocationEum.getEnumFromString(ledgerCreditModel.getLocationId());

            switch(locationEum){
                case USA -> {
                    return usLeaveLedger.addLeaveCredit(ledgerCreditModel);
                }

                case INDIA -> {
                    return indiaLeaveLedger.addLeaveCredit(ledgerCreditModel);
                }

                default -> {
                    return catchException("addLeaveCredit()", null, "Invalid location", "Please select valid location");
                }
            }
        }
        catch(Exception e) {
            return catchException("addLeaveCredit()", e, "Error", "Something went wrong");
        }
    }

    private ArrayList<String> getFilterSpNameByFilterType(String leaveType,Integer locationId) {
    	LeaveTypeEnum leaveTypeEnum = LeaveTypeEnum.getEnumFromString(leaveType);

    	ArrayList<String> filterSp = new ArrayList<>();
    	
    	switch(leaveTypeEnum) {
    	
    	case VACATION,PRIVILEGELEAVE  -> filterSp.add(LedgerFilterEnum.SP_VACATION.getValue());
    	
    	case SICKLEAVE -> {
    		if(Objects.equals(locationId, LocationEum.USA.getValue())) {
    			filterSp.add(LedgerFilterEnum.SP_US_SICKLEAVE.getValue());
    		}
    		else if(Objects.equals(locationId, LocationEum.INDIA.getValue())) {
    			filterSp.add(LedgerFilterEnum.SP_INDIA_SPECIALLEAVE.getValue());
    		}
    		else {
    			filterSp.addAll(Arrays.asList(LedgerFilterEnum.SP_INDIA_SPECIALLEAVE.getValue()
            			, LedgerFilterEnum.SP_US_SICKLEAVE.getValue()));
    		}
    	}
    	
    	case CASUALLEAVE -> filterSp.add(LedgerFilterEnum.SP_INDIA_SPECIALLEAVE.getValue());
    	
    	default -> filterSp.addAll(Arrays.asList(LedgerFilterEnum.SP_INDIA_SPECIALLEAVE.getValue()
    			, LedgerFilterEnum.SP_US_SICKLEAVE.getValue()
    			, LedgerFilterEnum.SP_VACATION.getValue()));
    		
    	}
    	
    	return filterSp;
    }
    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
        LOGGER.error("{} Error : {}" + methodName, e);
        ExceptionBean exception = new ExceptionBean(Instant.now(), message, description);
        response.setStatus(false);
        response.setInformation(exception);
        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }

}
