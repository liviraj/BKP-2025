package com.histo.staffmanagementportal.service.impl;

import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import com.histo.eventmanagement.entity.EventTypes;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.stereotype.Service;

import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.intranet.entity.Holiday;
import com.histo.staffmanagementportal.intranet.entity.PayRollMaster;
import com.histo.staffmanagementportal.intranet.repository.HolidayRepository;
import com.histo.staffmanagementportal.intranet.repository.PayRollMasterRepository;
import com.histo.staffmanagementportal.model.LocationEum;
import com.histo.staffmanagementportal.model.ResponseModel;
import com.histo.staffmanagementportal.service.PayRollProcessService;
import com.histo.staffmanagementportal.util.ResponseUtil;

@Service
public class PayRollProcess implements PayRollProcessService {
	
	private static final Logger logger = LogManager.getLogger(PayRollProcess.class);
	private static final String STATUS = "status";
	
    private final PayRollMasterRepository payRollMasterRepo;
    private final HolidayRepository holidayRepo;
    private final ResponseModel response;
    
    MappingJacksonValue mappingJacksonValue;

    public PayRollProcess(PayRollMasterRepository payRollMasterRepo, HolidayRepository holidayRepo, ResponseModel response) {
        super();
        this.payRollMasterRepo = payRollMasterRepo;
        this.holidayRepo = holidayRepo;
		this.response = response;
    }
     
    @Override
     public ResponseEntity<Object> generatePayrollDates(Integer locationId) {
    	 try {
    		 PayRollMaster lastPayRollDetails = payRollMasterRepo.findFirstByLocationIdOrderByIdDesc(locationId)
                     .orElseThrow (() -> new NullPointerException ("Cannot get last pay roll details."));

    		 if(Objects.equals(locationId, LocationEum.USA.getValue())) {

                  LocalDateTime payrollStartPeriod = LocalDateTime.ofInstant(
                		  lastPayRollDetails.getToDate(), ZoneOffset.systemDefault()).plus(1, ChronoUnit.DAYS);//15-01-2024
                  
                  LocalDateTime payrollEndPeriod = payrollStartPeriod.plusYears(1); // 15-01-2025    
                  
                  LocalDateTime endDate = payrollStartPeriod.plusDays(13);// 28-01-2024

                 while(!payrollStartPeriod.isAfter(payrollEndPeriod)){
                	 
                	 PayRollMaster payRollMaster = new PayRollMaster ();

                     List<Holiday> employeeHoliday = holidayRepo.findByLocationidAndStartDateBetweenAndEndDateBetween (locationId
                             ,payrollStartPeriod.atZone(ZoneId.systemDefault()).toInstant(),endDate.atZone(ZoneId.systemDefault()).toInstant());

                     double holidayCount = employeeHoliday.stream ().mapToDouble (Holiday::getNumberOfDays).sum ();

                     long workingDays = countWorkingDays(payrollStartPeriod, endDate);

                     Instant payRollProcessEndDate = getPayRollProcessEndDate (endDate);

                     payRollMaster.setFromDate (payrollStartPeriod.atZone(ZoneId.systemDefault()).toInstant());
                     payRollMaster.setToDate (endDate.atZone(ZoneId.systemDefault()).toInstant());
                     payRollMaster.setLocationId (locationId);
                     payRollMaster.setNoofHolidays (holidayCount);
                     payRollMaster.setNoofWorkingDays (workingDays-holidayCount);
                     payRollMaster.setPayrollDate (payRollProcessEndDate);
                     payRollMaster.setIsProcessed ("N");

                     PayRollMaster payRollMasterDetail = payRollMasterRepo.save (payRollMaster);

                     payrollStartPeriod = endDate.plusDays (1); // 29-01-2024
                     
                     endDate = payrollStartPeriod.plusDays (13); // 11-02-2024
                 }

    		 }
    		 
    		 else {

                 LocalDateTime payrollStartPeriod = LocalDateTime.ofInstant( lastPayRollDetails.getToDate(), ZoneOffset.systemDefault()).withDayOfMonth(24); //24-01-2024

                 LocalDateTime payrollEndPeriod = payrollStartPeriod.plusMonths(12).withDayOfMonth(23); // 23-01-2025

                 LocalDateTime startDate = payrollStartPeriod;
                 LocalDateTime endDate = startDate.plusMonths(1).withDayOfMonth(23); // 23-02-2024

                 while (!startDate.isAfter(payrollEndPeriod)) {
                	 
                	 PayRollMaster payRollMaster = new PayRollMaster ();

                     List<Holiday> employeeHoliday = holidayRepo.findByLocationidAndStartDateBetweenAndEndDateBetween (locationId
                             ,startDate.atZone(ZoneId.systemDefault()).toInstant(),endDate.atZone(ZoneId.systemDefault()).toInstant());

                     double holidayCount = employeeHoliday.stream ().mapToDouble (Holiday::getNumberOfDays).sum ();

                     long workingDays = countWorkingDays(startDate, endDate);

                     Instant payRollProcessEndDate = getPayRollProcessEndDate (endDate);

                     payRollMaster.setFromDate (startDate.atZone(ZoneId.systemDefault()).toInstant());
                     payRollMaster.setToDate (endDate.atZone(ZoneId.systemDefault()).toInstant());
                     payRollMaster.setLocationId (locationId);
                     payRollMaster.setNoofHolidays (holidayCount);
                     payRollMaster.setNoofWorkingDays (workingDays-holidayCount);
                     payRollMaster.setPayrollDate (payRollProcessEndDate);
                     payRollMaster.setIsProcessed ("N");

                     PayRollMaster payRollMasterDetail = payRollMasterRepo.save (payRollMaster);
                     
                      startDate = startDate.plusMonths(1);
                      endDate = endDate.plusMonths(1);
                 }
    		 }

             
            List<PayRollMaster> payRollDetails = payRollMasterRepo.findByLocationIdOrderByIdAsc(locationId);
            response.setStatus(true);
 			response.setData(payRollDetails);

 			mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { STATUS, "data" });

 			return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    	 }
    	 catch(Exception e) {
    		 return catchException("generatePayrollDates()", e, "Error", "Cannot generate payroll dates");
    	 }
 

            
     }
    private long countWorkingDays(LocalDateTime startDate, LocalDateTime endDate) {
        long workingDays = 0;
        LocalDateTime currentDate = startDate;

        while (!currentDate.isAfter(endDate)) {
            // Check if the current day is not a Saturday or Sunday
            if (currentDate.getDayOfWeek() != DayOfWeek.SATURDAY && currentDate.getDayOfWeek() != DayOfWeek.SUNDAY) {
                workingDays++;
            }

            // Move to the next day
            currentDate = currentDate.plus(1, ChronoUnit.DAYS);
        }

        return workingDays;
    }

    private Instant getPayRollProcessEndDate(LocalDateTime startDate) {
        long weekendCount = 0;
        LocalDateTime currentDate = startDate.plus(1, ChronoUnit.DAYS);
        LocalDateTime endDate = currentDate.plus(1, ChronoUnit.DAYS);


        while (weekendCount<2) {
            // Check if the current day is a Saturday or Sunday
       
            if (ObjectUtils.notEqual(currentDate.getDayOfWeek(), DayOfWeek.SATURDAY ) && ObjectUtils.notEqual(currentDate.getDayOfWeek(), DayOfWeek.SUNDAY )) {

                weekendCount++;
                endDate = currentDate;
            }

            // Move to the next day
            currentDate = currentDate.plus(1, ChronoUnit.DAYS);
        }

        return OffsetDateTime.of(endDate.withHour(17).withMinute(0), ZoneOffset.UTC).toInstant();
    }

    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
		logger.error("{} Error : {}" + methodName, e);
		response.setStatus(false);
		response.setInformation(new ExceptionBean(Instant.now(), message, description));
		mappingJacksonValue = ResponseUtil.responseFilter(response, new String[] { "information", STATUS });
		return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);

	}

    
   
}
