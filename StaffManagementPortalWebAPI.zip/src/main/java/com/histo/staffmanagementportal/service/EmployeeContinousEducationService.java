package com.histo.staffmanagementportal.service;

import org.springframework.http.ResponseEntity;

import com.histo.staffmanagementportal.dto.EmployeeContinousEducationDTO;
import com.histo.staffmanagementportal.model.ModifiedDetails;

public interface EmployeeContinousEducationService {

	public ResponseEntity<Object> getContinousEducationByEmployeeId(Integer employeeId);
	public ResponseEntity<Object> getContinousEducationById(Integer continousEducationId);
	public ResponseEntity<Object> addContinousEducation(EmployeeContinousEducationDTO continousEducationDTO);
	public ResponseEntity<Object> updateContinousEducationById(EmployeeContinousEducationDTO continousEducationDTO,Integer continousEducationId);
	public ResponseEntity<Object> deleteEmployeeContinousEducationById(Integer continousEducationId,ModifiedDetails modifiedDetails);
}
