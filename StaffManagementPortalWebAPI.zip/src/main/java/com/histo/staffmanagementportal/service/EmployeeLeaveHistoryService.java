package com.histo.staffmanagementportal.service;

import org.springframework.http.ResponseEntity;

import com.histo.staffmanagementportal.model.CancelRequestModel;
import com.histo.staffmanagementportal.model.LeaveHistoryFilter;
import com.histo.staffmanagementportal.model.LeaveRequestDetails;

public interface EmployeeLeaveHistoryService {
	public ResponseEntity<Object> getEmployeeLeaveHistory(LeaveHistoryFilter leaveHistoryFilter);
	public ResponseEntity<Object> getEmployeeLeaveDetails(Integer leaveRequestId);
	public ResponseEntity<Object> getEmployeeLeaveDetailsForEmail(Integer leaveRequestId);
	public ResponseEntity<Object> approveLeaveRequest(LeaveRequestDetails leaveRequestDetails, Boolean isLossOfPay);
	public ResponseEntity<Object> cancelRequest(CancelRequestModel cancelRequestModel);
}
