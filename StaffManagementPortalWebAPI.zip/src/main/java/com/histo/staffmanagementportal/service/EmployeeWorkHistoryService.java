package com.histo.staffmanagementportal.service;

import org.springframework.http.ResponseEntity;

import com.histo.staffmanagementportal.dto.EmployeeWorkHistoryDTO;
import com.histo.staffmanagementportal.model.ModifiedDetails;

public interface EmployeeWorkHistoryService {

	public ResponseEntity<Object> getWorkHistoryByEmployeeId(Integer employeeId);
	public ResponseEntity<Object> getWorkHistoryById(Integer workHistoryId);
	public ResponseEntity<Object> addEmployeeWorkHistory(EmployeeWorkHistoryDTO workHistoryDTO);
	public ResponseEntity<Object> updateEmployeeWorkHistory(EmployeeWorkHistoryDTO workHistoryDTO,Integer workHistoryId);
	public ResponseEntity<Object> deleteEmployeeWorkHistoryById(Integer workHistoryId,ModifiedDetails modifiedDetails);
}
