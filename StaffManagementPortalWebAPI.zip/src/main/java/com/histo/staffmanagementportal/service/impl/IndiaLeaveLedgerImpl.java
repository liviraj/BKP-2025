package com.histo.staffmanagementportal.service.impl;

import com.histo.staffmanagementportal.dto.LeaveLedgerModifyDTO;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.intranet.entity.EmployeeLeaveDetails;
import com.histo.staffmanagementportal.intranet.entity.SpecialLeaveLedger;
import com.histo.staffmanagementportal.intranet.repository.EmployeeLeaveDetailsRepository;
import com.histo.staffmanagementportal.intranet.repository.SpecialLeaveLedgerRepository;
import com.histo.staffmanagementportal.model.*;
import com.histo.staffmanagementportal.service.LeaveLedgerInterface;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class IndiaLeaveLedgerImpl implements LeaveLedgerInterface {
    private static final Logger LOGGER = LogManager.getLogger(IndiaLeaveLedgerImpl.class);
    private static final String STATUS = "status";

    private final ResponseModel response;
    private final VacationLedgerImpl leaveLedgerService;
    private MappingJacksonValue mappingJacksonValue;
    private final EmployeeLeaveDetailsRepository employeeLeaveDetailsRepo;

    private final SpecialLeaveLedgerRepository specialLeavesDebitDetailRepository;

    public IndiaLeaveLedgerImpl(ResponseModel response, VacationLedgerImpl leaveLedgerService, EmployeeLeaveDetailsRepository employeeLeaveDetailsRepo
            , SpecialLeaveLedgerRepository specialLeaveLedgerRepository) {
        this.response = response;
        this.leaveLedgerService = leaveLedgerService;
        this.employeeLeaveDetailsRepo = employeeLeaveDetailsRepo;
        this.specialLeavesDebitDetailRepository = specialLeaveLedgerRepository;
    }

    @Override
    public ResponseEntity<Object> editLeaveLedger(Integer ledgerId, LeaveLedgerModifyDTO leaveLedger) {
        try {
            LeaveTypeEnum leaveTypeEnum = LeaveTypeEnum.getEnumFromString(leaveLedger.getLeaveType());

            switch (leaveTypeEnum) {
                case PRIVILEGELEAVE: {
                    return leaveLedgerService.editLeaveLedger(ledgerId, leaveLedger);
                }
                case SICKLEAVE:
                case CASUALLEAVE: {
                    return editIndiaSickLeaveLedger(ledgerId, leaveLedger);
                }
                default: {
                    return catchException("editLeaveLedger()", null, "Invalid leave type", "Something went wrong");
                }
            }
        } catch (Exception e) {
            return catchException("editLeaveLedger()", e, "Error", "Something went wrong");
        }
    }

    @Override
    public ResponseEntity<Object> deleteLeaveLedger(Integer ledgerId, LedgerDetails ledgerDetails) {
        try {
            LeaveTypeEnum leaveTypeEnum = LeaveTypeEnum.getEnumFromString(ledgerDetails.getLeaveType());

            switch (leaveTypeEnum) {
                case PRIVILEGELEAVE : {
                    return leaveLedgerService.deleteLeaveLedger(ledgerId,ledgerDetails);
                }

                case SICKLEAVE:
                case CASUALLEAVE: {
                    return deleteIndiaSickLeaveLedger(ledgerId,ledgerDetails);
                }

                default : {
                    return catchException("deleteLeaveLedger()", null, "Invalid leave type", "Something went wrong");
                }
            }
        } catch (Exception e) {
            return catchException("deleteLeaveLedger()", e, "Error", "Something went wrong");
        }
    }

    @Override
    public ResponseEntity<Object> addLeaveCredit(LedgerCreditModel ledgerCreditModel) {
        try {
            LeaveTypeEnum leaveTypeEnum = LeaveTypeEnum.getEnumFromString(ledgerCreditModel.getLeaveType());

            switch (leaveTypeEnum) {
                case PRIVILEGELEAVE -> {
                    return leaveLedgerService.addLeaveCredit(ledgerCreditModel);
                }

                default -> {
                    return catchException("addLeaveCredit()", null, "Invalid leave type", "Cannot add Sick/Casual leave");
                }
            }
        } catch (Exception e) {
            return catchException("addLeaveCredit()", e, "Error", "Something went wrong");
        }
    }

    private ResponseEntity<Object> deleteIndiaSickLeaveLedger(Integer ledgerId,LedgerDetails ledgerDetails) {
        try {
            Optional<SpecialLeaveLedger> leaveById = specialLeavesDebitDetailRepository.findById(ledgerId);
            if (leaveById.isEmpty() || leaveById.get().getRemarks().endsWith(Constants.LOP)) {
                return catchException("deleteIndiaSickLeaveLedger()", null, "NOT FOUND", "Leave ledger not found or Cannot delete loss of pay record");
            }

            Optional<EmployeeLeaveDetails> employeeLeaveDetail = employeeLeaveDetailsRepo
                    .findByLeaveRequestId_TypeofLeave_LeaveTypeIdAndLeaveRequestId_TypeofLeave_LocationIDAndEmployeeIdAndLeaveDate
                            (leaveById.get().getSLDebitMasterID().getLeaveTypeID(), LocationEum.INDIA.getValue(), leaveById.get().getEmployeeID()
                                    , leaveById.get().getEntryDate ());

            if (employeeLeaveDetail.isPresent() && leaveById.get().getDebit() > 0
                    && employeeLeaveDetail.get().getApprovalStatus().equalsIgnoreCase(LeaveStatusEnum.APPROVED_STATUS.getValue())) {
                employeeLeaveDetail.get().setApprovalStatus(LeaveStatusEnum.REJECTED_STATUS.getValue());
                EmployeeLeaveDetails employeeLeaveDetails = employeeLeaveDetailsRepo.save(employeeLeaveDetail.get());
            } else if (employeeLeaveDetail.isPresent() && leaveById.get().getCreditDays() > 0
                    && employeeLeaveDetail.get().getApprovalStatus().equalsIgnoreCase(LeaveStatusEnum.CANCELLED_STATUS.getValue())) {
                employeeLeaveDetail.get().setApprovalStatus(LeaveStatusEnum.APPROVED_STATUS.getValue());
                EmployeeLeaveDetails employeeLeaveDetails = employeeLeaveDetailsRepo.save(employeeLeaveDetail.get());
            }

            Double balance = leaveById.get().getBalance() - leaveById.get().getCreditDays() + leaveById.get().getDebit();

            List<SpecialLeaveLedger> employeeLeave = specialLeavesDebitDetailRepository
                    .findByEmployeeIDAndSLDebitMasterIDIdAndIdGreaterThanOrderByIdAsc(leaveById.get().getEmployeeID(), leaveById.get().getSLDebitMasterID().getId(), ledgerId);

            for (SpecialLeaveLedger leave : employeeLeave) {

                Double finalBalance = specialLeavesDebitDetailRepository.findByIdAndRemarksEndsWith(leave.getId(), Constants.LOP).isEmpty() ?
                        balance + leave.getCreditDays() - leave.getDebit() : balance;

                leave.setBalance(finalBalance);
                specialLeavesDebitDetailRepository.save(leave);

                balance = finalBalance;
            }

            LedgerEmailModel emailModel = new LedgerEmailModel(leaveById.get().getEmployeeID()
            		, ledgerDetails.getUpdatedBy()
            		, new SimpleDateFormat("MM/dd/yyyy").format(new Date())
            		, new SimpleDateFormat("MM/dd/yyyy").format(Date.from(leaveById.get().getEntryDate()))
            		, leaveById.get().getCreditDays()
            		, leaveById.get().getDebit()
            		, leaveById.get().getBalance()
            		, Constants.LEDGER_DELETE);
            
            specialLeavesDebitDetailRepository.delete(leaveById.get());

            response.setStatus(true);
            response.setMessage("Leave ledger deleted successfully");
            response.setData(emailModel);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException("deleteSickLeaveLedger()", e, "Error", "Something went wrong");
        }
    }

    private ResponseEntity<Object> editIndiaSickLeaveLedger(Integer ledgerId, LeaveLedgerModifyDTO leaveLedger) {
        try {
            Optional<SpecialLeaveLedger> LeaveById = specialLeavesDebitDetailRepository.findById(ledgerId);
            if (LeaveById.isEmpty() || LeaveById.get().getRemarks().endsWith(Constants.LOP)) {
                return catchException("editIndiaSickLeaveLedger()", null, "NOT FOUND", "Sick Leave ledger not found or Cannot edit loss of pay record");
            }

            Double prevBalance = LeaveById.get().getBalance() - LeaveById.get().getCreditDays() + LeaveById.get().getDebit();

            Double balance = prevBalance + leaveLedger.getCreditDays() - leaveLedger.getDebitDays();

            List<SpecialLeaveLedger> employeeLeave = specialLeavesDebitDetailRepository
                    .findByEmployeeIDAndSLDebitMasterIDIdAndIdGreaterThanOrderByIdAsc(LeaveById.get().getEmployeeID(), LeaveById.get().getSLDebitMasterID().getId(), ledgerId);

            LeaveById.get().setCreditDays(leaveLedger.getCreditDays());
            LeaveById.get().setDebit(leaveLedger.getDebitDays());
            LeaveById.get().setBalance(balance);
            LeaveById.get().setLastModifiedOn(InstantFormatter.InstantFormat(leaveLedger.getModifiedOn()));
            LeaveById.get().setLastModifiedBy(leaveLedger.getModifiedBy());

            SpecialLeaveLedger specialLeaveDetails = specialLeavesDebitDetailRepository.save(LeaveById.get());


            for (SpecialLeaveLedger leave : employeeLeave) {

                Double finalBalance = specialLeavesDebitDetailRepository.findByIdAndRemarksEndsWith(leave.getId(), Constants.LOP).isEmpty() ?
                        balance + leave.getCreditDays() - leave.getDebit() : balance;

                leave.setBalance(finalBalance);
                leave.setLastModifiedOn(InstantFormatter.InstantFormat(leaveLedger.getModifiedOn()));
                leave.setLastModifiedBy(leaveLedger.getModifiedBy());
                specialLeavesDebitDetailRepository.save(leave);

                balance = finalBalance;
            }

            LedgerEmailModel emailModel = new LedgerEmailModel(specialLeaveDetails.getEmployeeID()
            		, specialLeaveDetails.getLastModifiedBy()
            		, new SimpleDateFormat("MM/dd/yyyy").format(Date.from(specialLeaveDetails.getLastModifiedOn()))
            		, new SimpleDateFormat("MM/dd/yyyy").format(Date.from(specialLeaveDetails.getEntryDate()))
            		, specialLeaveDetails.getCreditDays()
            		, specialLeaveDetails.getDebit()
            		, specialLeaveDetails.getBalance()
            		, Constants.LEDGER_UPDATE);
            
            response.setStatus(true);
            response.setMessage("Leave ledger updated successfully");
            response.setData(emailModel);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            return catchException("editIndiaSickLeaveLedger()", e, "Error", "Something went wrong");
        }
    }

    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
        LOGGER.error("{} Error : {}" + methodName, e);
        ExceptionBean exception = new ExceptionBean(Instant.now(), message, description);
        response.setStatus(false);
        response.setInformation(exception);
        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }
}
