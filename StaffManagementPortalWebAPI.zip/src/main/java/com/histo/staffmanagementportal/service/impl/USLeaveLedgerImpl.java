package com.histo.staffmanagementportal.service.impl;

import com.histo.staffmanagementportal.dto.LeaveLedgerModifyDTO;
import com.histo.staffmanagementportal.exception.ExceptionBean;
import com.histo.staffmanagementportal.intranet.entity.EmployeeLeaveDetails;
import com.histo.staffmanagementportal.intranet.entity.USSickLeaveDetails;
import com.histo.staffmanagementportal.intranet.repository.EmployeeLeaveDetailsRepository;
import com.histo.staffmanagementportal.intranet.repository.USSickLeaveDetailsRepository;
import com.histo.staffmanagementportal.model.*;
import com.histo.staffmanagementportal.service.LeaveLedgerInterface;
import com.histo.staffmanagementportal.util.InstantFormatter;
import com.histo.staffmanagementportal.util.ResponseUtil;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class USLeaveLedgerImpl implements LeaveLedgerInterface {

    private static final Logger LOGGER = LogManager.getLogger(USLeaveLedgerImpl.class);
    private static final String STATUS = "status";

    private final ResponseModel response;
    private final VacationLedgerImpl leaveLedgerService;
    private MappingJacksonValue mappingJacksonValue;
    private final USSickLeaveDetailsRepository sickLeaveDetailsRepository;
    private final EmployeeLeaveDetailsRepository employeeLeaveDetailsRepo;

    public USLeaveLedgerImpl(ResponseModel response, VacationLedgerImpl leaveLedgerService
            , USSickLeaveDetailsRepository sickLeaveDetailsRepository, EmployeeLeaveDetailsRepository employeeLeaveDetailsRepo) {
        this.response = response;
        this.leaveLedgerService = leaveLedgerService;
        this.sickLeaveDetailsRepository = sickLeaveDetailsRepository;
        this.employeeLeaveDetailsRepo = employeeLeaveDetailsRepo;
    }

    @Override
    public ResponseEntity<Object> editLeaveLedger(Integer ledgerId, LeaveLedgerModifyDTO leaveLedger) {
        try{
            LeaveTypeEnum leaveTypeEnum = LeaveTypeEnum.getEnumFromString(leaveLedger.getLeaveType());

            switch(leaveTypeEnum){
                case VACATION -> {
                    return leaveLedgerService.editLeaveLedger(ledgerId,leaveLedger);
                }

                case SICKLEAVE -> {
                    return editUSSickLeaveLedger(ledgerId,leaveLedger);
                }

                default -> {
                    return catchException("editLeaveLedger()", null, "Invalid leave type", "Something went wrong");
                }
            }
        }
        catch(Exception e) {
            return catchException("editLeaveLedger()", e, "Error", "Something went wrong");
        }
    }

    @Override
    public ResponseEntity<Object> deleteLeaveLedger(Integer ledgerId,LedgerDetails ledgerDetails) {
        try{
            LeaveTypeEnum leaveTypeEnum = LeaveTypeEnum.getEnumFromString(ledgerDetails.getLeaveType());

            switch(leaveTypeEnum){
                case VACATION -> {
                    return leaveLedgerService.deleteLeaveLedger(ledgerId,ledgerDetails);
                }

                case SICKLEAVE -> {
                    return deleteUSSickLeaveLedger(ledgerId,ledgerDetails);
                }

                default -> {
                    return catchException("deleteLeaveLedger()", null, "Invalid leave type", "Something went wrong");
                }
            }
        }
        catch(Exception e) {
            return catchException("deleteLeaveLedger()", e, "Error", "Something went wrong");
        }
    }

    @Override
    public ResponseEntity<Object> addLeaveCredit(LedgerCreditModel ledgerCreditModel) {
        try{
            LeaveTypeEnum leaveTypeEnum = LeaveTypeEnum.getEnumFromString(ledgerCreditModel.getLeaveType());

            switch(leaveTypeEnum){
                case VACATION -> {
                    return leaveLedgerService.addLeaveCredit(ledgerCreditModel);
                }

                case SICKLEAVE -> {
                    return addSickLeaveCredit(ledgerCreditModel);
                }

                default -> {
                    return catchException("addLeaveCredit()", null, "Invalid leave type", "Something went wrong");
                }
            }
        }
        catch(Exception e) {
            return catchException("addLeaveCredit()", e, "Error", "Something went wrong");
        }
    }

    private ResponseEntity<Object> editUSSickLeaveLedger(Integer ledgerId, LeaveLedgerModifyDTO leaveLedger) {

        try {
            Optional<USSickLeaveDetails> sickLeaveById = sickLeaveDetailsRepository.findById(ledgerId);
            if(sickLeaveById.isEmpty() || sickLeaveById.get().getComment().endsWith(Constants.LOP)) {
                return catchException("editSickLeaveLedger()", null, "NOT FOUND", "Sick Leave ledger not found or Cannot edit loss of pay record");
            }

            Double prevBalance = sickLeaveById.get().getBalance()-sickLeaveById.get().getCreditDays()+sickLeaveById.get().getDebitDays();

            Double prevBalanceHrs = sickLeaveById.get().getBalanceHours()-sickLeaveById.get().getCreditHrs()+sickLeaveById.get().getDebitHrs();

            Double balance = prevBalance + leaveLedger.getCreditDays() - leaveLedger.getDebitDays();

            Double balanceHrs = prevBalanceHrs + (leaveLedger.getCreditDays()*Constants.TOTAL_WORKING_HOURS) - (leaveLedger.getDebitDays()*Constants.TOTAL_WORKING_HOURS);

            List<USSickLeaveDetails> employeeSickLeave = sickLeaveDetailsRepository
                    .findByEmployeeIdAndIdGreaterThanOrderByIdAsc(sickLeaveById.get().getEmployeeId(),ledgerId);

            sickLeaveById.get().setCreditDays(leaveLedger.getCreditDays());
            sickLeaveById.get().setCreditHrs(leaveLedger.getCreditDays() * Constants.TOTAL_WORKING_HOURS);
            sickLeaveById.get().setDebitDays(leaveLedger.getDebitDays());
            sickLeaveById.get().setDebitHrs(leaveLedger.getDebitDays() * Constants.TOTAL_WORKING_HOURS);
            sickLeaveById.get().setBalance(balance);
            sickLeaveById.get().setBalanceHours(balanceHrs);
            sickLeaveById.get().setModifiedBy(leaveLedger.getModifiedBy());
            sickLeaveById.get().setModifiedOn(InstantFormatter.InstantFormat(leaveLedger.getModifiedOn()));

            USSickLeaveDetails sickLeaveDetails = sickLeaveDetailsRepository.save(sickLeaveById.get());


            for(USSickLeaveDetails leave : employeeSickLeave) {

                Double finalBalance = sickLeaveDetailsRepository.findByIdAndCommentEndsWith(leave.getId(), Constants.LOP).isEmpty()?
                        balance+ leave.getCreditDays() - leave.getDebitDays() : balance;

                Double finalBalanceHrs = sickLeaveDetailsRepository.findByIdAndCommentEndsWith(leave.getId(), Constants.LOP).isEmpty()?
                        balanceHrs+ leave.getCreditHrs() - leave.getDebitHrs() : balanceHrs;

                leave.setBalance(finalBalance);
                leave.setBalanceHours(finalBalanceHrs);
                leave.setModifiedBy(leaveLedger.getModifiedBy());
                leave.setModifiedOn(InstantFormatter.InstantFormat(leaveLedger.getModifiedOn()));
                sickLeaveDetailsRepository.save(leave);

                balance = finalBalance;
                balanceHrs = finalBalanceHrs;
            }

            LedgerEmailModel emailModel = new LedgerEmailModel(leaveLedger.getEmployeeId()
            		, leaveLedger.getModifiedBy()
            		, new SimpleDateFormat("MM/dd/yyyy").format(Date.from(sickLeaveDetails.getModifiedOn()))
            		, new SimpleDateFormat("MM/dd/yyyy").format(Date.from(sickLeaveDetails.getEntryDate()))
            		, sickLeaveDetails.getCreditDays()
            		, sickLeaveDetails.getDebitDays()
            		, sickLeaveDetails.getBalance()
            		, Constants.LEDGER_UPDATE);
            
            response.setStatus(true);
            response.setMessage("Sick leave ledger updated successfully");
            response.setData(emailModel);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
        catch(Exception e) {
            return catchException("editSickLeaveLedger()", e, "Error", "Something went wrong");
        }
    }

    private ResponseEntity<Object> deleteUSSickLeaveLedger(Integer ledgerId,LedgerDetails ledgerDetails) {
        try {
            Optional<USSickLeaveDetails> sickLeaveById = sickLeaveDetailsRepository.findById(ledgerId);
            if(sickLeaveById.isEmpty() || sickLeaveById.get().getComment().endsWith(Constants.LOP)) {
                return catchException("deleteSickLeaveLedger()", null, "NOT FOUND", "Sick Leave ledger not found or Cannot delete loss of pay record");
            }
            Optional<EmployeeLeaveDetails> employeeLeaveDetail = employeeLeaveDetailsRepo
                    .findByLeaveRequestId_TypeofLeave_LeaveTypeNameAndLeaveRequestId_TypeofLeave_LocationIDAndEmployeeIdAndLeaveDate
                            (LeaveTypeEnum.SICKLEAVE.getValue(), LocationEum.USA.getValue(),sickLeaveById.get().getEmployeeId()
                                    , sickLeaveById.get().getEntryDate());

            if(employeeLeaveDetail.isPresent() && sickLeaveById.get().getDebitDays() > 0
                    && employeeLeaveDetail.get().getApprovalStatus().equalsIgnoreCase(LeaveStatusEnum.APPROVED_STATUS.getValue())) {
                employeeLeaveDetail.get().setApprovalStatus(LeaveStatusEnum.REJECTED_STATUS.getValue());
                EmployeeLeaveDetails employeeLeaveDetails = employeeLeaveDetailsRepo.save(employeeLeaveDetail.get());
            }
            else if(employeeLeaveDetail.isPresent() && sickLeaveById.get().getCreditDays() > 0
                    && employeeLeaveDetail.get().getApprovalStatus().equalsIgnoreCase(LeaveStatusEnum.CANCELLED_STATUS.getValue())) {
                employeeLeaveDetail.get().setApprovalStatus(LeaveStatusEnum.APPROVED_STATUS.getValue());
                EmployeeLeaveDetails employeeLeaveDetails = employeeLeaveDetailsRepo.save(employeeLeaveDetail.get());
            }

            Double balance = sickLeaveById.get().getBalance()-sickLeaveById.get().getCreditDays()+sickLeaveById.get().getDebitDays();

            Double balanceHrs = sickLeaveById.get().getBalanceHours()-sickLeaveById.get().getCreditHrs()+sickLeaveById.get().getDebitHrs();

            List<USSickLeaveDetails> employeeSickLeave = sickLeaveDetailsRepository
                    .findByEmployeeIdAndIdGreaterThanOrderByIdAsc(sickLeaveById.get().getEmployeeId(),ledgerId);

            for(USSickLeaveDetails leave : employeeSickLeave) {

                Double finalBalance = sickLeaveDetailsRepository.findByIdAndCommentEndsWith(leave.getId(), Constants.LOP).isEmpty()?
                        balance+ leave.getCreditDays() - leave.getDebitDays() : balance;

                Double finalBalanceHrs = sickLeaveDetailsRepository.findByIdAndCommentEndsWith(leave.getId(), Constants.LOP).isEmpty()?
                        balanceHrs+ leave.getCreditHrs() - leave.getDebitHrs() : balanceHrs;

                leave.setBalance(finalBalance);
                leave.setBalanceHours(finalBalanceHrs);
                sickLeaveDetailsRepository.save(leave);

                balance = finalBalance;
                balanceHrs = finalBalanceHrs;
            }

            LedgerEmailModel emailModel = new LedgerEmailModel(sickLeaveById.get().getEmployeeId()
            		, ledgerDetails.getUpdatedBy()
            		, new SimpleDateFormat("MM/dd/yyyy").format(new Date())
            		, new SimpleDateFormat("MM/dd/yyyy").format(Date.from(sickLeaveById.get().getEntryDate()))
            		, sickLeaveById.get().getCreditDays()
            		, sickLeaveById.get().getDebitDays()
            		, sickLeaveById.get().getBalance()
            		, Constants.LEDGER_DELETE);
            
            sickLeaveDetailsRepository.delete(sickLeaveById.get());

            response.setStatus(true);
            response.setMessage("Sick leave ledger deleted successfully");
            response.setData(emailModel);
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
        catch(Exception e) {
            return catchException("deleteSickLeaveLedger()", e, "Error", "Something went wrong");
        }
    }

    private ResponseEntity<Object> addSickLeaveCredit(LedgerCreditModel leaveLedger) {
        try {
            USSickLeaveDetails sickLeaveDetails = sickLeaveDetailsRepository.findFirstByEmployeeIdOrderByIdDesc(leaveLedger.getEmployeeId());

            Double balance = ObjectUtils.isEmpty(sickLeaveDetails)?0+leaveLedger.getCreditDays():sickLeaveDetails.getBalance()+ leaveLedger.getCreditDays();
            
            if((ObjectUtils.isNotEmpty(sickLeaveDetails) && (sickLeaveDetails.getBalance() == Constants.MAX_SICK_LEAVE)) || balance>Constants.MAX_SICK_LEAVE) {
                return catchException("addSickLeaveCredit()", null, "Out of range", "Maximun sick leave added");
            }
 
            Double balanceHrs = ObjectUtils.isEmpty(sickLeaveDetails)?0+(leaveLedger.getCreditDays()* Constants.TOTAL_WORKING_HOURS):
            	sickLeaveDetails.getBalanceHours()+(leaveLedger.getCreditDays()* Constants.TOTAL_WORKING_HOURS);

            USSickLeaveDetails usSickLeaveDetails =  new USSickLeaveDetails();

            usSickLeaveDetails.setEmployeeId(leaveLedger.getEmployeeId());
            usSickLeaveDetails.setComment(leaveLedger.getComments());
            usSickLeaveDetails.setEntryDate(InstantFormatter.InstantFormat(leaveLedger.getEntryDate()));
            usSickLeaveDetails.setBalance(balance);
            usSickLeaveDetails.setBalanceHours(balanceHrs);
            usSickLeaveDetails.setCreditDays(leaveLedger.getCreditDays());
            usSickLeaveDetails.setCreditHrs(leaveLedger.getCreditDays() * Constants.TOTAL_WORKING_HOURS);
            usSickLeaveDetails.setLeaveAddedBy(leaveLedger.getCreditAddedBy());
            usSickLeaveDetails.setRunDate(InstantFormatter.InstantFormat(leaveLedger.getCreditAddedOn()));
            usSickLeaveDetails.setModifiedBy(leaveLedger.getCreditAddedBy());
            usSickLeaveDetails.setModifiedOn(InstantFormatter.InstantFormat(leaveLedger.getCreditAddedOn()));

            USSickLeaveDetails leaveDetails = sickLeaveDetailsRepository.save(usSickLeaveDetails);

            LedgerEmailModel emailModel = new LedgerEmailModel(leaveDetails.getEmployeeId()
            		, leaveLedger.getCreditAddedBy()
            		, new SimpleDateFormat("MM/dd/yyyy").format(Date.from(leaveDetails.getRunDate()))
            		, new SimpleDateFormat("MM/dd/yyyy").format(Date.from(leaveDetails.getEntryDate()))
            		, leaveDetails.getCreditDays()
            		, leaveDetails.getDebitDays()
            		, leaveDetails.getBalance()
            		, Constants.LEDGER_ADD);
            
            response.setStatus(true);
            response.setMessage("Sick leave credit added successfully");
            mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"message", STATUS});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        }
        catch(Exception e) {
            return catchException("addSickLeaveCredit()", e, "Error", "Cannot add leave credit");
        }
    }

    private ResponseEntity<Object> catchException(String methodName, Exception e, String message, String description) {
        LOGGER.error("{} Error : {}" + methodName, e);
        ExceptionBean exception = new ExceptionBean(Instant.now(), message, description);
        response.setStatus(false);
        response.setInformation(exception);
        mappingJacksonValue = ResponseUtil.responseFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }
}
