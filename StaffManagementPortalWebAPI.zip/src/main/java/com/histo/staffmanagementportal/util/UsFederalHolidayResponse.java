package com.histo.staffmanagementportal.util;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class UsFederalHolidayResponse {
    private boolean status;
    private String message;
    private List<HolidayData> data;

    @Getter
    @Setter
    @NoArgsConstructor
    public static class HolidayData {
        private String name;
        private String date;
        private String dateString;

        @JsonProperty("alsoObservedAs")
        private String alsoObservedAs;

    }
}