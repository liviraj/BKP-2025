package com.histo.staffmanagementportal.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class InstantFormatter {

	private static final String DATEFORMAT = "MM/dd/yyyy";
	private static final String INDIA_DATE_FORMAT = "dd/MM/yyyy";

	public static Instant InstantFormat(String instant) {
   	 if(instant != null && !instant.isEmpty()) {
   		 instant  = instant.replace(" ", "T") + "Z" ;
            return Instant.parse(instant);
        }
     	return null;
   }
    public static String InstantFormat(Instant instant) {
    	if(instant != null){
    		return String.valueOf(instant).replace("T", " ").replaceFirst("Z", "");
    	}
    	return null;
    }

	public static String dateFormat(Instant instant) throws ParseException {
		if(instant != null){

			String parsedInstant = InstantFormat(instant);
			// Format the date
			SimpleDateFormat simpleDateFormat =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = simpleDateFormat.parse(parsedInstant);
			return new SimpleDateFormat(DATEFORMAT).format(date);
		}
		return null;
	}

	public static String FormattedDateTime(Instant instant) throws ParseException {
		if(instant != null){

			String parsedInstant = InstantFormat(instant);
			// Format the date
			SimpleDateFormat simpleDateFormat =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = simpleDateFormat.parse(parsedInstant);

			SimpleDateFormat outputFormat = new SimpleDateFormat("MM/dd/yyyy hha");

			return outputFormat.format(date);
		}
		return null;
	}

	public static String indiaDateFormat(Instant instant) throws ParseException {
		if(instant != null){

			String parsedInstant = InstantFormat(instant);
			// Format the date
			SimpleDateFormat simpleDateFormat =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = simpleDateFormat.parse(parsedInstant);
			return new SimpleDateFormat(INDIA_DATE_FORMAT).format(date);
		}
		return null;
	}
	public static DayOfWeek getWeek(Instant instant)  {
		if(instant != null){

			String parsedInstant = InstantFormat(instant);
			// Format the date and get week name
			DateTimeFormatter format =  DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			LocalDate localDate = LocalDate.parse(parsedInstant, format);

			return localDate.getDayOfWeek();
		}
		return null;
	}

	public static LocalDateTime localDateTimeFormat(String date) {
		if(date != null && !date.isEmpty()) {
			date  = date.replace(" ", "T")  ;
			return LocalDateTime.parse(date);
		}
		return null;
	}
}
