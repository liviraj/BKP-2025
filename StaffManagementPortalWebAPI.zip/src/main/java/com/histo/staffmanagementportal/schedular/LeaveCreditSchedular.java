package com.histo.staffmanagementportal.schedular;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.histo.staffmanagementportal.model.LocationEum;
import com.histo.staffmanagementportal.service.EmailService;
import com.histo.staffmanagementportal.service.PayRollProcessService;
import com.histo.staffmanagementportal.service.impl.LeaveCredit;

@Service
public class LeaveCreditSchedular {
	
	private static final Logger logger = LogManager.getLogger(LeaveCreditSchedular.class);
	private final LeaveCredit leaveCredit;
	private final EmailService emailService;
	private final PayRollProcessService payRollProcessService;

    public LeaveCreditSchedular(LeaveCredit leaveCredit, EmailService emailService, PayRollProcessService payRollProcessService) {
		super();
		this.leaveCredit = leaveCredit;
		this.emailService = emailService;
		this.payRollProcessService = payRollProcessService;
	}
// Below schedular are configured in sql job
//	
//    @Scheduled(cron = "0 0 0 1 * ?",zone = "America/New_York") // Run at 0th hour on the 1st day of every monthh
//	    public void usLeaveCredit() {
//	        ResponseEntity<Object> usEmployeeLeaveCredit = leaveCredit.getUSEmployeeLeaveCredit();
//	    }
//
//    @Scheduled(cron = "0 0 0 * * ?",zone = "America/New_York") // Run at 0th hour every day
//    public void usSickLeaveCredit() {
//	        ResponseEntity<Object> usSickLeaveCredit = leaveCredit.getUSSickLeaveCredit();
//	    }
//
//    @Scheduled(cron = "0 40 03 24 * ?",zone = "America/New_York") // Run at 24th of every month at 3.40 AM
//	    public void indiaLeaveCredit() {
//	        ResponseEntity<Object> IndiaEmployeeLeaveCredit = leaveCredit.getIndianEmpoyeeLeaveCredit();
//	    }
	 
    @Scheduled(cron = "0 0 0 1 1 ?",zone = "America/New_York") // Run at 0th hour of every year
	    public void indiaSpecialLeaveCredit() {
	        ResponseEntity<Object> IndiaEmployeeSickLeaveCredit = leaveCredit.getSpecialDebitLeaveCredit();
	        if(IndiaEmployeeSickLeaveCredit.getStatusCode() == HttpStatus.OK) {
	        	emailService.sendLeaveCreditEmail(IndiaEmployeeSickLeaveCredit.getBody());
	        }
	    }
     
    @Scheduled(cron = "0 0 5 24 12 ?",zone = "America/New_York") // Run at December 24th, 5AM
        public void employeeLeaveEncashment() {
            ResponseEntity<Object> leaveEncashment = leaveCredit.leaveEncashment();
        }
    
    @Scheduled(cron = "0 0 5 25 12 ?",zone = "America/New_York") // Run at December 25th, 5AM
    public void generateIndiaPayRollPeriod() {
        ResponseEntity<Object> indiaPayRollDetails = payRollProcessService.generatePayrollDates(LocationEum.INDIA.getValue()) ;
    }
    
    @Scheduled(cron = "0 0 0 1 1 ?",zone = "America/New_York") // Run at 0th hour of every year
    public void generateUSPayRollPeriod() {
        ResponseEntity<Object> usPayRollDetails = payRollProcessService.generatePayrollDates(LocationEum.USA.getValue()) ;
    }
}
