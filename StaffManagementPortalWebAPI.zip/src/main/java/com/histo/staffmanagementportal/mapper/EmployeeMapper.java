package com.histo.staffmanagementportal.mapper;

import com.histo.staffmanagementportal.dto.EmployeeComplianceDTO;
import com.histo.staffmanagementportal.dto.EmployeeContinousEducationDTO;
import com.histo.staffmanagementportal.dto.EmployeeContinousEducationViewDTO;
import com.histo.staffmanagementportal.dto.EmployeeDocumentDTO;
import com.histo.staffmanagementportal.dto.EmployeeTrainingDTO;
import com.histo.staffmanagementportal.dto.EmployeeWorkHistoryDTO;
import com.histo.staffmanagementportal.intranet.entity.EmployeeCompliance;
import com.histo.staffmanagementportal.intranet.entity.EmployeeContinousEducation;
import com.histo.staffmanagementportal.intranet.entity.EmployeeDocument;
import com.histo.staffmanagementportal.intranet.entity.EmployeeTraining;
import com.histo.staffmanagementportal.intranet.entity.EmployeeWorkHistory;

public interface EmployeeMapper {
   
	EmployeeContinousEducationViewDTO continuousEducationEntityToViewDto(EmployeeContinousEducation continousEducation  );
	
	EmployeeContinousEducationDTO continuousEducationEntityToDto(EmployeeContinousEducation continousEducation  );
	
	EmployeeWorkHistoryDTO employeeWorkHistoryToDto(EmployeeWorkHistory employeeWorkHistory);
	
	EmployeeDocumentDTO employeeDocumentEntityToDto(EmployeeDocument employeeDocument);
	
	EmployeeDocument employeeDocumentDtoToEntity(EmployeeDocumentDTO employeeDocumentDto);
	
	EmployeeDocument updateEmployeeDocumentFromDto(EmployeeDocumentDTO employeeDocumentDto,EmployeeDocument employeeDocument);
	
	EmployeeComplianceDTO employeeComplianceToDto(EmployeeCompliance compliance);
	
	EmployeeTrainingDTO employeeTrainingToDto(EmployeeTraining employeeTraining);
	
}
