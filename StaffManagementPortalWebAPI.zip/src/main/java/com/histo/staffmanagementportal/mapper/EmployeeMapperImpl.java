package com.histo.staffmanagementportal.mapper;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.stereotype.Service;

import com.histo.staffmanagementportal.dto.EmployeeComplianceDTO;
import com.histo.staffmanagementportal.dto.EmployeeContinousEducationDTO;
import com.histo.staffmanagementportal.dto.EmployeeContinousEducationViewDTO;
import com.histo.staffmanagementportal.dto.EmployeeDocumentDTO;
import com.histo.staffmanagementportal.dto.EmployeeTrainingDTO;
import com.histo.staffmanagementportal.dto.EmployeeWorkHistoryDTO;
import com.histo.staffmanagementportal.intranet.entity.EmployeeCompliance;
import com.histo.staffmanagementportal.intranet.entity.EmployeeContinousEducation;
import com.histo.staffmanagementportal.intranet.entity.EmployeeDocument;
import com.histo.staffmanagementportal.intranet.entity.EmployeeTraining;
import com.histo.staffmanagementportal.intranet.entity.EmployeeWorkHistory;

@Service
public class EmployeeMapperImpl implements EmployeeMapper{

	private ModelMapper modelMapper;
	
	public EmployeeMapperImpl(ModelMapper modelMapper) {
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		this.modelMapper = modelMapper;
	}

	@Override
	public EmployeeContinousEducationDTO continuousEducationEntityToDto(
			EmployeeContinousEducation continousEducation) {
		return modelMapper.map(continousEducation, EmployeeContinousEducationDTO.class);
	}

	@Override
	public EmployeeContinousEducationViewDTO continuousEducationEntityToViewDto(
			EmployeeContinousEducation continousEducation) {
		return modelMapper.map(continousEducation, EmployeeContinousEducationViewDTO.class);	}

	@Override
	public EmployeeWorkHistoryDTO employeeWorkHistoryToDto(EmployeeWorkHistory employeeWorkHistory) {
		return modelMapper.map(employeeWorkHistory, EmployeeWorkHistoryDTO.class);
	}

	@Override
	public EmployeeDocumentDTO employeeDocumentEntityToDto(EmployeeDocument employeeDocument) {
		return modelMapper.map(employeeDocument, EmployeeDocumentDTO.class);
	}

	@Override
	public EmployeeDocument employeeDocumentDtoToEntity(EmployeeDocumentDTO employeeDocumentDto) {

		return modelMapper.map(employeeDocumentDto, EmployeeDocument.class);
	}

	@Override
	public EmployeeDocument updateEmployeeDocumentFromDto(EmployeeDocumentDTO employeeDocumentDto,
			EmployeeDocument employeeDocument) {
		modelMapper.map(employeeDocumentDto, employeeDocument);
		return employeeDocument;
	}

	@Override
	public EmployeeComplianceDTO employeeComplianceToDto(EmployeeCompliance compliance) {
		return modelMapper.map(compliance, EmployeeComplianceDTO.class);
	}

	@Override
	public EmployeeTrainingDTO employeeTrainingToDto(EmployeeTraining employeeTraining) {
		return modelMapper.map(employeeTraining, EmployeeTrainingDTO.class);
	}

	
}
