package com.histo.staffmanagementportal.model;

public class Constants {

	
	public static final double TOTAL_WORKING_HOURS = 8;
	
	public static final String REVIEW_COMMENT = "To be Reviewed";
	
	public static final String SICK_LEAVE_CREDIT_COMMENT = "Yearly Leave Credit - Sick";
	
	public static final String CASUAL_LEAVE_CREDIT_COMMENT = "Yearly Leave Credit - Casual";
	
	public static final String LOP = "Loss Of Pay";

	public static final String ACTIVE_RECORD_STATUS = "A";
	
	public static final Character DELETED_RECORD_STATUS = 'D';

	public static final double MAX_ENCASH_LEAVE = 15;
	
	public static final double MAX_SICK_LEAVE = 5;

	public static final String APPROVED_STATUS = "A";

	public static final String REJECTED_STATUS = "R";

	public static final String CANCELLED_STATUS = "C";

	public static final String TO_BE_APPROVED = "T";
	
	public static final String TO_BE_CANCELLED = "TC";
	
	public static final String LEAVE_CREDIT  = "Yearly Leave Credit";
	
	public static final String LEDGER_UPDATE = "Edited";
	
	public static final String LEDGER_DELETE = "Deleted";
	
	public static final String LEDGER_ADD = "Created";
	
	public static final String LEAVE_CANCELLED = "Cancelled";
	
	public static final String RELIEVED_STATUS = "Relieved";

	public static final Integer INITIAL_REQUEST_STATUS_ID = 1;// Based on RequestStatusMaster table value(Default its Open)

	public static final long MAXI_PERMISSION_COUNT_INDIA = 2;

	public static final long MAXI_PERMISSION_HRS = 2;

	public static final String MAXI_FLOATING_HOLIDAY_ATTRIBUTE_NAME = "MaxFloatingHoliday";

    public static final String COMPLIANCE_EXPIRY_EMAIL_SUBJECT = "Employee Compliance Expiry Alert.";

	public static final String LEAVE_ENCASHMENT_COMMENT = "Leave Encashment";
}
