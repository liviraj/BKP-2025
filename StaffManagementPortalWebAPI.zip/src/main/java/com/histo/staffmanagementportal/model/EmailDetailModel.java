package com.histo.staffmanagementportal.model;

import lombok.*;

import java.util.Arrays;


public class EmailDetailModel {
    private String subject;
    private String body;
    private String[] to;
    private String[] cc;
    private String[] bcc;
    private String applicationName = "StaffManagement";

    public EmailDetailModel() {
    }

    public EmailDetailModel(String subject, String body, String[] to, String[] cc, String[] bcc) {
		super();
		this.subject = subject;
		this.body = body;
		this.to = to;
		this.cc = cc;
		this.bcc = bcc;
        this.applicationName = "StaffManagement";
	}

	public String[] getTo() {
        return to;
    }

    public void setTo(String[] to) {
        this.to = to;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String[] getCc() {
        return cc;
    }

    public void setCc(String[] cc) {
        this.cc = cc;
    }

    public String[] getBcc() {
        return bcc;
    }

    public void setBcc(String[] bcc) {
        this.bcc = bcc;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    @Override
    public String toString() {
        return "EmailDetailModel{" +
                "subject='" + subject + '\'' +
                ", body='" + body + '\'' +
                ", to=" + Arrays.toString(to) +
                ", cc=" + Arrays.toString(cc) +
                ", bcc=" + Arrays.toString(bcc) +
                '}';
    }
}
