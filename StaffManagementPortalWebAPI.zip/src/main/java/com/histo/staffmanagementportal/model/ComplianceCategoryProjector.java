package com.histo.staffmanagementportal.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ComplianceCategoryProjector {
	
	private Integer complianceCategoryId;
	private String complianceCategory;
	private String isPolicyAgreement;
	private String complianceType;
	private List<Integer> compliancePeriodId;
	
}
