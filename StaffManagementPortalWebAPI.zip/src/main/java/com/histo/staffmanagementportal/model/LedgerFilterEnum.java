package com.histo.staffmanagementportal.model;

public enum LedgerFilterEnum {

	LEAVE_LEDGER("Leave Ledger"),
	LEAVE_BALANCE("Leave Balance"),
	LEAVE_SUMMARY("Leave Summary"),
	SP_US_SICKLEAVE("USSickLeaveLedgerFilter"),
	SP_VACATION("VacationLeaveLedgerFilter"),
	SP_INDIA_SPECIALLEAVE("IndiaLeaveLedgerFilter");

   private String value;
	
	public String getValue() {
		return value;
	}
	LedgerFilterEnum(String value) {
		this.value = value;
	}
}
