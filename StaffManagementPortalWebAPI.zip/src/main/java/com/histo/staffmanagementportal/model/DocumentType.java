package com.histo.staffmanagementportal.model;

public class DocumentType {

	private Integer documentTypeId;
	private String documentName;
	
	public DocumentType() {
		super();
	}
	public DocumentType(Integer documentTypeId, String documentName) {
		super();
		this.documentTypeId = documentTypeId;
		this.documentName = documentName;
	}
	public Integer getDocumentTypeId() {
		return documentTypeId;
	}
	public void setDocumentTypeId(Integer documentTypeId) {
		this.documentTypeId = documentTypeId;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	
}
