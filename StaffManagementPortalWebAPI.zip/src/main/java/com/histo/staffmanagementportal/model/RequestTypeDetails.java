package com.histo.staffmanagementportal.model;

public interface RequestTypeDetails {

    Integer getRequestTypeId();
    String getRequest();
    Integer getLocationId();

}
