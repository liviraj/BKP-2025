package com.histo.staffmanagementportal.model;

public enum ImageTypeEnum {
	IMAGE("Image"),
	IDPROOF("Id Proof"),
	PASSPORT_IMAGE("Passport Image"),
	QUALIFICATION_CERTIFICATE("Qualification Certificate"),
	CONTINUOUSEDUCATION_CERTIFICATE("ContinuousEducation Certificate"),
	WORKHISTORY_PROOF("WorkHistory Proof");
private String value;
	
	public String getValue() {
		return value;
	}

	ImageTypeEnum(String value) {
		this.value = value;
	}
}
