package com.histo.staffmanagementportal.model;

public class LeaveRequestQueue {

	private Integer employeeId;
	private Integer requestId;
	private String appliedDate;
	private String pendingSince;
	private String employeeName;
	private String fromDate;
	private String toDate;
	private String leaveToForH;
	private String leaveFromForH;
	private String leaveType;
	private String reason;
	private String shortReason;
	private String location;
	private String cancelApprovalStatus;
	private double noOfDaysApplied;
	
	public LeaveRequestQueue() {
		super();
	}

	public LeaveRequestQueue(Integer employeeId, Integer requestId, String appliedDate, String pendingSince,
			String employeeName, String fromDate, String toDate, String leaveToForH, String leaveFromForH,
			String leaveType, String reason, String shortReason, String location, String cancelApprovalStatus,
			double noOfDaysApplied) {
		super();
		this.employeeId = employeeId;
		this.requestId = requestId;
		this.appliedDate = appliedDate;
		this.pendingSince = pendingSince;
		this.employeeName = employeeName;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.leaveToForH = leaveToForH;
		this.leaveFromForH = leaveFromForH;
		this.leaveType = leaveType;
		this.reason = reason;
		this.shortReason = shortReason;
		this.location = location;
		this.cancelApprovalStatus = cancelApprovalStatus;
		this.noOfDaysApplied = noOfDaysApplied;
	}

	public String getLeaveToForH() {
		return leaveToForH;
	}

	public void setLeaveToForH(String leaveToForH) {
		this.leaveToForH = leaveToForH;
	}

	public String getLeaveFromForH() {
		return leaveFromForH;
	}

	public void setLeaveFromForH(String leaveFromForH) {
		this.leaveFromForH = leaveFromForH;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public Integer getRequestId() {
		return requestId;
	}

	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}

	public String getAppliedDate() {
		return appliedDate;
	}

	public void setAppliedDate(String appliedDate) {
		this.appliedDate = appliedDate;
	}

	public String getPendingSince() {
		return pendingSince;
	}

	public void setPendingSince(String pendingSince) {
		this.pendingSince = pendingSince;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getShortReason() {
		return shortReason;
	}

	public void setShortReason(String shortReason) {
		this.shortReason = shortReason;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getCancelApprovalStatus() {
		return cancelApprovalStatus;
	}

	public void setCancelApprovalStatus(String cancelApprovalStatus) {
		this.cancelApprovalStatus = cancelApprovalStatus;
	}

	public double getNoOfDaysApplied() {
		return noOfDaysApplied;
	}

	public void setNoOfDaysApplied(double noOfDaysApplied) {
		this.noOfDaysApplied = noOfDaysApplied;
	}

	@Override
	public String toString() {
		return "LeaveRequestQueue [employeeId=" + employeeId + ", requestId=" + requestId + ", appliedDate="
				+ appliedDate + ", pendingSince=" + pendingSince + ", employeeName=" + employeeName + ", fromDate="
				+ fromDate + ", toDate=" + toDate + ", leaveToForH=" + leaveToForH + ", leaveFromForH=" + leaveFromForH
				+ ", leaveType=" + leaveType + ", reason=" + reason + ", shortReason=" + shortReason + ", location="
				+ location + ", cancelApprovalStatus=" + cancelApprovalStatus + ", noOfDaysApplied=" + noOfDaysApplied
				+ "]";
	}
	
}
