package com.histo.staffmanagementportal.model;

import java.util.List;

public class EmployeeDetails {

	private EmployeePersonalDetails personalDetail;
	private EmployeeCommunicationDetails communicationDetail;
	private List<EmployeeWorkDetails> workDetail;
	private List<EmployeeQualificationDetails> qualification;
	private List<EmployeeWorkHistoryModel> workHistory;
	private List<EmployeeWorkScheduleModel> workSchedule;
	private List<EmployeeContinuousEducationModel> continuousEducation;
	
	public EmployeeDetails() {
		super();
	}
	public EmployeeDetails(EmployeePersonalDetails personalDetail, EmployeeCommunicationDetails communicationDetail,
			List<EmployeeWorkDetails> workDetail, List<EmployeeQualificationDetails> qualification,
			List<EmployeeWorkHistoryModel> workHistory, List<EmployeeWorkScheduleModel> workSchedule,
			List<EmployeeContinuousEducationModel> continuousEducation) {
		this.personalDetail = personalDetail;
		this.communicationDetail = communicationDetail;
		this.workDetail = workDetail;
		this.qualification = qualification;
		this.workHistory = workHistory;
		this.workSchedule = workSchedule;
		this.continuousEducation = continuousEducation;
	}
	public EmployeePersonalDetails getPersonalDetail() {
		return personalDetail;
	}
	public void setPersonalDetail(EmployeePersonalDetails personalDetail) {
		this.personalDetail = personalDetail;
	}
	public EmployeeCommunicationDetails getCommunicationDetail() {
		return communicationDetail;
	}
	public void setCommunicationDetail(EmployeeCommunicationDetails communicationDetail) {
		this.communicationDetail = communicationDetail;
	}
	public List<EmployeeWorkDetails> getWorkDetail() {
		return workDetail;
	}
	public void setWorkDetail(List<EmployeeWorkDetails> workDetail) {
		this.workDetail = workDetail;
	}
	public List<EmployeeQualificationDetails> getQualification() {
		return qualification;
	}
	public void setQualification(List<EmployeeQualificationDetails> qualification) {
		this.qualification = qualification;
	}
	public List<EmployeeWorkHistoryModel> getWorkHistory() {
		return workHistory;
	}
	public void setWorkHistory(List<EmployeeWorkHistoryModel> workHistory) {
		this.workHistory = workHistory;
	}
	public List<EmployeeWorkScheduleModel> getWorkSchedule() {
		return workSchedule;
	}
	public void setWorkSchedule(List<EmployeeWorkScheduleModel> workSchedule) {
		this.workSchedule = workSchedule;
	}
	public List<EmployeeContinuousEducationModel> getContinuousEducation() {
		return continuousEducation;
	}
	public void setContinuousEducation(List<EmployeeContinuousEducationModel> continuousEducation) {
		this.continuousEducation = continuousEducation;
	}
}
