package com.histo.staffmanagementportal.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class FloatingHolidayFilter {

    private Integer employeeId;
    private Integer floatingHolidayId;
    private Integer year;
}
