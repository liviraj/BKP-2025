package com.histo.staffmanagementportal.model;

public enum RoleEnum {

	ADMINISTRATOR("Administrator"),
	EMPLOYEE("Employee"),
	HUMAN_RESOURCE("Human Resource"),
	SECTION_SUPERVISOR("Section Supervisor");
	
private String value;
	
	public String getValue() {
		return value;
	}

	RoleEnum(String value) {
		this.value = value;
	}
}
