package com.histo.staffmanagementportal.model;

public class EmployeeLastLeaveDetails {

	private LastLeaveAvailed lastLeaveAvailed;
	private LeaveDetails sickLeaveDetails;
	private String lastLeaveFromDate;
	private String lastLeaveToDate;
    private LeaveDetails vacationLeaveDetails;
	
	
	public EmployeeLastLeaveDetails() {
	
	}

	public EmployeeLastLeaveDetails(LastLeaveAvailed lastLeaveAvailed, LeaveDetails sickLeaveDetails,LeaveDetails vacationLeaveDetails) {
		super();
		this.vacationLeaveDetails = vacationLeaveDetails;
		this.lastLeaveAvailed = lastLeaveAvailed;
		this.sickLeaveDetails = sickLeaveDetails;	
	}

	public String getLastLeaveFromDate() {
		return lastLeaveFromDate;
	}

	public void setLastLeaveFromDate(String lastLeaveFromDate) {
		this.lastLeaveFromDate = lastLeaveFromDate;
	}

	public String getLastLeaveToDate() {
		return lastLeaveToDate;
	}

	public void setLastLeaveToDate(String lastLeaveToDate) {
		this.lastLeaveToDate = lastLeaveToDate;
	}

	public LastLeaveAvailed getLastLeaveAvailed() {
		return lastLeaveAvailed;
	}
	public void setLastLeaveAvailed(LastLeaveAvailed lastLeaveAvailed) {
		this.lastLeaveAvailed = lastLeaveAvailed;
	}

	public LeaveDetails getSickLeaveDetails() {
		return sickLeaveDetails;
	}

	public void setSickLeaveDetails(LeaveDetails sickLeaveDetails) {
		this.sickLeaveDetails = sickLeaveDetails;
	}

	public LeaveDetails getVacationLeaveDetails() {
		return vacationLeaveDetails;
	}

	public void setVacationLeaveDetails(LeaveDetails vacationLeaveDetails) {
		this.vacationLeaveDetails = vacationLeaveDetails;
	}
	
 }
