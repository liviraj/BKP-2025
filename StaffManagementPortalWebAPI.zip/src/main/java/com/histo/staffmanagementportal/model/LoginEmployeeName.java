package com.histo.staffmanagementportal.model;

public class LoginEmployeeName{

	private Integer employeeId;
	private Integer loginId;
	private String empName;
	private Integer locationId;
	private String employmentStatus;
	
	public LoginEmployeeName() {
		super();
	}

	public LoginEmployeeName(Integer employeeId, Integer loginId, String empName, Integer locationId, String employmentStatus ) {
		super();
		this.employeeId = employeeId;
		this.loginId = loginId;
		this.empName = empName;
		this.locationId = locationId;
		this.employmentStatus = employmentStatus;
	}

	public String getEmploymentStatus() {
		return employmentStatus;
	}

	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public Integer getLoginId() {
		return loginId;
	}

	public void setLoginId(Integer loginId) {
		this.loginId = loginId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Integer getLocationId() {
		return locationId;
	}

	public void setLocationId(Integer locationId) {
		this.locationId = locationId;
	}

}
