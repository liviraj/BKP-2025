package com.histo.staffmanagementportal.model;

import lombok.Data;

@Data
public class MyRequestEmailParams {

    String employeeId;
    String employeeName;
    String requestType;
    String requestDate;
    String description;
    String requestedBy;
    String reviewedBy;
    String reviewedOn;
    String modifiedBy;
    String modifiedDate;
    String status;
    String comments;
    String emailId;
    String createdByEmailId;
    String reviewerEmailID;
    Integer locationId;
    String requestAction;
    String section;
}
