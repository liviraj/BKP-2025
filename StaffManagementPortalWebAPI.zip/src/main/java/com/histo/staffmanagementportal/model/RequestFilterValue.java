package com.histo.staffmanagementportal.model;

import lombok.Data;

@Data
public class RequestFilterValue{

    private String status;
    private Integer requestTypeId;
    private Integer employeeId;
    private Integer locationId;
}
