package com.histo.staffmanagementportal.model;

public enum LeaveTypeEnum {

	VACATION("Vacation"),
	PRIVILEGELEAVE("Privilege Leave"),
	CASUALLEAVE("Casual Leave"),
	SICKLEAVE("Sick Leave"),
	ALL("All");
	
	private String value;
	
	public String getValue() {
		return value;
	}

	LeaveTypeEnum(String value) {
		this.value = value;
	}
	
	public static LeaveTypeEnum getEnumFromString(String text) {
        for (LeaveTypeEnum leaveType : LeaveTypeEnum.values()) {
            if (leaveType.value.equalsIgnoreCase(text)) {
                return leaveType;
            }
        }
        return null;
    }
}
