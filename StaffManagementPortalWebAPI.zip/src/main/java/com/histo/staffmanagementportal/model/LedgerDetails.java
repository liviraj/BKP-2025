package com.histo.staffmanagementportal.model;

public class LedgerDetails {

    private String locationId;
    private String leaveType;
    private Integer updatedBy;

    public LedgerDetails(String locationId, String leaveType, Integer updatedBy) {
		super();
		this.locationId = locationId;
		this.leaveType = leaveType;
		this.updatedBy = updatedBy;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}
    public LedgerDetails() {
    }

    public String getLocationId() {
        return locationId;
    }

    public void setLocationId(String locationId) {
        this.locationId = locationId;
    }

    public String getLeaveType() {
        return leaveType;
    }

    public void setLeaveType(String leaveType) {
        this.leaveType = leaveType;
    }
}
