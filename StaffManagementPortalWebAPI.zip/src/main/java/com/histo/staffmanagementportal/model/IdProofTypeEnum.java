package com.histo.staffmanagementportal.model;

public enum IdProofTypeEnum {

	PAN("P"),
	SSN("S"),
	DL("D");
private String value;
	
	public String getValue() {
		return value;
	}

	IdProofTypeEnum(String value) {
		this.value = value;
	}
}
