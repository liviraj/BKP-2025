package com.histo.staffmanagementportal.model;

public enum LeaveStatusEnum {

	TO_BE_APPROVED("T"),
	APPROVED_STATUS("A"),    
	REJECTED_STATUS("R"),
	TO_BE_CANCELLED("TC"),
	CANCELLED_STATUS("C"),
	T("To be Approved"),
	A("Approved"),    
	R("Rejected"),
	TC("To be Cancelled"),
	C("Cancelled");
	
	private String value;
	
	public String getValue() {
		return value;
	}

	LeaveStatusEnum(String value) {
		this.value = value;
	}
	
	public static String getEnumValueFromString(String text) {
		for (LeaveStatusEnum status : LeaveStatusEnum.values()) {
			if (status.value.equalsIgnoreCase( text)) {
				return LeaveStatusEnum.valueOf(text).getValue();
			}

		}
		return null;
	}
}

