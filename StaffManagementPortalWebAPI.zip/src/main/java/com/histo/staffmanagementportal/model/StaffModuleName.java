package com.histo.staffmanagementportal.model;

public enum StaffModuleName {

    QUALIFICATION("EmployeeQualification"),
    WORKHISTORY("EmployeeWorkHistory"),
    COMPLIANCE("EmployeeCompliance"),
    TRAINING("EmployeeTraining"),
    HRDOCUMENT("EmployeeDocument"),
    CONTINOUSEDUCATION("EmployeeContinousEducation"),
    HOLIDAY("HolidayModule"),
    LEAVEMANAGEMENT("LeaveManagement");

    private String value;

    public String getValue() {
        return value;
    }

    StaffModuleName(String value) {
        this.value = value;
    }
}
