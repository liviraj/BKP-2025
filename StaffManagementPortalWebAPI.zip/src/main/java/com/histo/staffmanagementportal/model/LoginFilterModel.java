package com.histo.staffmanagementportal.model;

import io.swagger.annotations.ApiModelProperty;

public class LoginFilterModel {

	@ApiModelProperty(example = "Existing")
	private String mappingStatus;
	
	private Integer employeeId;
	private Integer loginId;
	private Integer role;
	
	private Integer location;
	@ApiModelProperty(example = "Active")
	private String status;
	
	public LoginFilterModel() {
		super();
	}


	public LoginFilterModel(String mappingStatus, Integer employeeId, Integer role, Integer location, String status, Integer loginId) {
		this.mappingStatus = mappingStatus;
		this.employeeId = employeeId;
		this.role = role;
		this.location = location;
		this.status = status;
		this.loginId = loginId;
	}
	public Integer getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = Integer.valueOf (loginId);
	}


	public String getMappingStatus() {
		return mappingStatus;
	}

	public void setMappingStatus(String mappingStatus) {
		this.mappingStatus = mappingStatus;
	}

	

	public Integer getRole() {
		return role;
	}

	public void setRole(Integer role) {
		this.role = role;
	}

	public Integer getLocation() {
		return location;
	}

	public void setLocation(Integer location) {
		this.location = location;
	}


	public Integer getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}

	
}
