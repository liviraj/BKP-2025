package com.histo.staffmanagementportal.model;

public record GradeName(Integer gradeId,String gradeName){

}
