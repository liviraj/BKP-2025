package com.histo.staffmanagementportal.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ComplianceEmailModel {

     Integer employeeID;
     String employeeName;
     String compliance;
     String compliancePeriod;
     String displayName;
     String expirydate;
     String emailId;
     Integer id;

}
