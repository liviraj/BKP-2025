package com.histo.staffmanagementportal.model;

public class LedgerEmailModel {

	public Integer employeeId;
	public Integer updatedBy;
	public String updatedOn;
	public String entryDate;
	public Double creditDays;
	public Double debitDays;
	public Double balance;
	public String ledgerAction;
	public String employeeName;
	
	public LedgerEmailModel(Integer employeeId, Integer updatedBy, String updatedOn, String entryDate,
			Double creditDays, Double debitDays, Double balance, String ledgerAction) {
		super();
		this.employeeId = employeeId;
		this.updatedBy = updatedBy;
		this.updatedOn = updatedOn;
		this.entryDate = entryDate;
		this.creditDays = creditDays;
		this.debitDays = debitDays;
		this.balance = balance;
		this.ledgerAction = ledgerAction;
	}
	
	
	public String getEmployeeName() {
		return employeeName;
	}


	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}


	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public Integer getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(String updatedOn) {
		this.updatedOn = updatedOn;
	}
	public String getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}
	public Double getCreditDays() {
		return creditDays;
	}
	public void setCreditDays(Double creditDays) {
		this.creditDays = creditDays;
	}
	public Double getDebitDays() {
		return debitDays;
	}
	public void setDebitDays(Double debitDays) {
		this.debitDays = debitDays;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	public String getLedgerAction() {
		return ledgerAction;
	}
	public void setLedgerAction(String ledgerAction) {
		this.ledgerAction = ledgerAction;
	}
	@Override
	public String toString() {
		return "LedgerEmailModel [employeeId=" + employeeId + ", updatedBy=" + updatedBy + ", updatedOn=" + updatedOn
				+ ", entryDate=" + entryDate + ", creditDays=" + creditDays + ", debitDays=" + debitDays + ", balance="
				+ balance + ", ledgerAction=" + ledgerAction + "]";
	}

}
