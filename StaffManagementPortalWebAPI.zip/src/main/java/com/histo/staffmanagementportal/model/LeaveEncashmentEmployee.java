package com.histo.staffmanagementportal.model;

public class LeaveEncashmentEmployee {

	private Integer leaveLedgerId;
	private Integer employeeId;
	private Double balanceDays;
	
	public LeaveEncashmentEmployee() {
		super();
	}

	public Integer getLeaveLedgerId() {
		return leaveLedgerId;
	}

	public void setLeaveLedgerId(Integer leaveLedgerId) {
		this.leaveLedgerId = leaveLedgerId;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public Double getBalanceDays() {
		return balanceDays;
	}

	public void setBalanceDays(Double balanceDays) {
		this.balanceDays = balanceDays;
	}
	
}
