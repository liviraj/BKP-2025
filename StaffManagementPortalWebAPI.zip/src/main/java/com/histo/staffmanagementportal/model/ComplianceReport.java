package com.histo.staffmanagementportal.model;

public class ComplianceReport {

	private String employeeName;
	private String doj;
	private String designation;
	private String I9DocumentDate;
	private String I9ExpiryDate;
	private String I9IsValid;
	private String every3YearsNYStateClinicalLicense;
	private String oneTimeEmployeeTraining;
	private String everyYearCompetencyAssessmentTest;
	private String thirdMonthCompetencyAssessmentTest;
	private String sixthMonthCompetencyAssessmentTest;
	private String continuingEducationCreditinMin;
	private String everyYearHIPPAPatientConfidentiality;
	private String everyYearBiohazardRiskAssessment;
	private String everyYearBloodbornPathogensTraining;
	private String every3YearsDotTraining;
	private String everyYearSupervisorPerformanceReview;
	private String continuingEducation;
	private Integer every3YearsNYStateClinicalLicenseIsValid;
	private Integer oneTimeEmployeeTrainingIsValid;
	private Integer everyYearCompetencyAssessmentTestIsValid;
	private Integer thirdMonthCompetencyAssessmentTestIsValid;
	private Integer sixthMonthCompetencyAssessmentTestIsValid;
	private Integer continuingEducationCreditinMinIsValid;
	private Integer everyYearHIPPAPatientConfidentialityIsValid;
	private Integer everyYearBiohazardRiskAssessmentIsValid;
	private Integer everyYearBloodbornPathogensTrainingIsValid;
	private Integer every3YearsDotTrainingIsValid;
	private Integer everyYearSupervisorPerformanceReviewIsValid;
	private Integer continuingEducationIsValid;
	private String every3YearsNYStateClinicalLicenseExp;
	private String oneTimeEmployeeTrainingExp;
	private String everyYearCompetencyAssessmentTestExp;
	private String thirdMonthCompetencyAssessmentTestExp;
	private String sixthMonthCompetencyAssessmentTestExp;
	private String continuingEducationCreditinMinExp;
	private String everyYearHIPPAPatientConfidentialityExp;
	private String everyYearBiohazardRiskAssessmentExp;
	private String everyYearBloodbornPathogensTrainingExp;
	private String every3YearsDotTrainingExp;
	private String everyYearSupervisorPerformanceReviewExp;
	private String continuingEducationExp;
	
	public ComplianceReport() {
		super();
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getDoj() {
		return doj;
	}
	public void setDoj(String doj) {
		this.doj = doj;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getI9DocumentDate() {
		return I9DocumentDate;
	}
	public void setI9DocumentDate(String i9DocumentDate) {
		I9DocumentDate = i9DocumentDate;
	}
	public String getI9ExpiryDate() {
		return I9ExpiryDate;
	}
	public void setI9ExpiryDate(String i9ExpiryDate) {
		I9ExpiryDate = i9ExpiryDate;
	}
	public String getI9IsValid() {
		return I9IsValid;
	}
	public void setI9IsValid(String i9IsValid) {
		I9IsValid = i9IsValid;
	}
	public String getEvery3YearsNYStateClinicalLicense() {
		return every3YearsNYStateClinicalLicense;
	}
	public void setEvery3YearsNYStateClinicalLicense(String every3YearsNYStateClinicalLicense) {
		this.every3YearsNYStateClinicalLicense = every3YearsNYStateClinicalLicense;
	}
	public String getOneTimeEmployeeTraining() {
		return oneTimeEmployeeTraining;
	}
	public void setOneTimeEmployeeTraining(String oneTimeEmployeeTraining) {
		this.oneTimeEmployeeTraining = oneTimeEmployeeTraining;
	}
	public String getEveryYearCompetencyAssessmentTest() {
		return everyYearCompetencyAssessmentTest;
	}
	public void setEveryYearCompetencyAssessmentTest(String everyYearCompetencyAssessmentTest) {
		this.everyYearCompetencyAssessmentTest = everyYearCompetencyAssessmentTest;
	}
	public String getThirdMonthCompetencyAssessmentTest() {
		return thirdMonthCompetencyAssessmentTest;
	}
	public void setThirdMonthCompetencyAssessmentTest(String thirdMonthCompetencyAssessmentTest) {
		this.thirdMonthCompetencyAssessmentTest = thirdMonthCompetencyAssessmentTest;
	}
	public String getSixthMonthCompetencyAssessmentTest() {
		return sixthMonthCompetencyAssessmentTest;
	}
	public void setSixthMonthCompetencyAssessmentTest(String sixthMonthCompetencyAssessmentTest) {
		this.sixthMonthCompetencyAssessmentTest = sixthMonthCompetencyAssessmentTest;
	}
	public String getContinuingEducationCreditinMin() {
		return continuingEducationCreditinMin;
	}
	public void setContinuingEducationCreditinMin(String continuingEducationCreditinMin) {
		this.continuingEducationCreditinMin = continuingEducationCreditinMin;
	}
	public String getEveryYearHIPPAPatientConfidentiality() {
		return everyYearHIPPAPatientConfidentiality;
	}
	public void setEveryYearHIPPAPatientConfidentiality(String everyYearHIPPAPatientConfidentiality) {
		this.everyYearHIPPAPatientConfidentiality = everyYearHIPPAPatientConfidentiality;
	}
	public String getEveryYearBiohazardRiskAssessment() {
		return everyYearBiohazardRiskAssessment;
	}
	public void setEveryYearBiohazardRiskAssessment(String everyYearBiohazardRiskAssessment) {
		this.everyYearBiohazardRiskAssessment = everyYearBiohazardRiskAssessment;
	}
	public String getEveryYearBloodbornPathogensTraining() {
		return everyYearBloodbornPathogensTraining;
	}
	public void setEveryYearBloodbornPathogensTraining(String everyYearBloodbornPathogensTraining) {
		this.everyYearBloodbornPathogensTraining = everyYearBloodbornPathogensTraining;
	}
	public String getEvery3YearsDotTraining() {
		return every3YearsDotTraining;
	}
	public void setEvery3YearsDotTraining(String every3YearsDotTraining) {
		this.every3YearsDotTraining = every3YearsDotTraining;
	}
	public String getEveryYearSupervisorPerformanceReview() {
		return everyYearSupervisorPerformanceReview;
	}
	public void setEveryYearSupervisorPerformanceReview(String everyYearSupervisorPerformanceReview) {
		this.everyYearSupervisorPerformanceReview = everyYearSupervisorPerformanceReview;
	}
	public String getContinuingEducation() {
		return continuingEducation;
	}
	public void setContinuingEducation(String continuingEducation) {
		this.continuingEducation = continuingEducation;
	}
	public Integer getEvery3YearsNYStateClinicalLicenseIsValid() {
		return every3YearsNYStateClinicalLicenseIsValid;
	}
	public void setEvery3YearsNYStateClinicalLicenseIsValid(Integer every3YearsNYStateClinicalLicenseIsValid) {
		this.every3YearsNYStateClinicalLicenseIsValid = every3YearsNYStateClinicalLicenseIsValid;
	}
	public Integer getOneTimeEmployeeTrainingIsValid() {
		return oneTimeEmployeeTrainingIsValid;
	}
	public void setOneTimeEmployeeTrainingIsValid(Integer oneTimeEmployeeTrainingIsValid) {
		this.oneTimeEmployeeTrainingIsValid = oneTimeEmployeeTrainingIsValid;
	}
	public Integer getEveryYearCompetencyAssessmentTestIsValid() {
		return everyYearCompetencyAssessmentTestIsValid;
	}
	public void setEveryYearCompetencyAssessmentTestIsValid(Integer everyYearCompetencyAssessmentTestIsValid) {
		this.everyYearCompetencyAssessmentTestIsValid = everyYearCompetencyAssessmentTestIsValid;
	}
	public Integer getThirdMonthCompetencyAssessmentTestIsValid() {
		return thirdMonthCompetencyAssessmentTestIsValid;
	}
	public void setThirdMonthCompetencyAssessmentTestIsValid(Integer thirdMonthCompetencyAssessmentTestIsValid) {
		this.thirdMonthCompetencyAssessmentTestIsValid = thirdMonthCompetencyAssessmentTestIsValid;
	}
	public Integer getSixthMonthCompetencyAssessmentTestIsValid() {
		return sixthMonthCompetencyAssessmentTestIsValid;
	}
	public void setSixthMonthCompetencyAssessmentTestIsValid(Integer sixthMonthCompetencyAssessmentTestIsValid) {
		this.sixthMonthCompetencyAssessmentTestIsValid = sixthMonthCompetencyAssessmentTestIsValid;
	}
	public Integer getContinuingEducationCreditinMinIsValid() {
		return continuingEducationCreditinMinIsValid;
	}
	public void setContinuingEducationCreditinMinIsValid(Integer continuingEducationCreditinMinIsValid) {
		this.continuingEducationCreditinMinIsValid = continuingEducationCreditinMinIsValid;
	}
	public Integer getEveryYearHIPPAPatientConfidentialityIsValid() {
		return everyYearHIPPAPatientConfidentialityIsValid;
	}
	public void setEveryYearHIPPAPatientConfidentialityIsValid(Integer everyYearHIPPAPatientConfidentialityIsValid) {
		this.everyYearHIPPAPatientConfidentialityIsValid = everyYearHIPPAPatientConfidentialityIsValid;
	}
	public Integer getEveryYearBiohazardRiskAssessmentIsValid() {
		return everyYearBiohazardRiskAssessmentIsValid;
	}
	public void setEveryYearBiohazardRiskAssessmentIsValid(Integer everyYearBiohazardRiskAssessmentIsValid) {
		this.everyYearBiohazardRiskAssessmentIsValid = everyYearBiohazardRiskAssessmentIsValid;
	}
	public Integer getEveryYearBloodbornPathogensTrainingIsValid() {
		return everyYearBloodbornPathogensTrainingIsValid;
	}
	public void setEveryYearBloodbornPathogensTrainingIsValid(Integer everyYearBloodbornPathogensTrainingIsValid) {
		this.everyYearBloodbornPathogensTrainingIsValid = everyYearBloodbornPathogensTrainingIsValid;
	}
	public Integer getEvery3YearsDotTrainingIsValid() {
		return every3YearsDotTrainingIsValid;
	}
	public void setEvery3YearsDotTrainingIsValid(Integer every3YearsDotTrainingIsValid) {
		this.every3YearsDotTrainingIsValid = every3YearsDotTrainingIsValid;
	}
	public Integer getEveryYearSupervisorPerformanceReviewIsValid() {
		return everyYearSupervisorPerformanceReviewIsValid;
	}
	public void setEveryYearSupervisorPerformanceReviewIsValid(Integer everyYearSupervisorPerformanceReviewIsValid) {
		this.everyYearSupervisorPerformanceReviewIsValid = everyYearSupervisorPerformanceReviewIsValid;
	}
	public Integer getContinuingEducationIsValid() {
		return continuingEducationIsValid;
	}
	public void setContinuingEducationIsValid(Integer continuingEducationIsValid) {
		this.continuingEducationIsValid = continuingEducationIsValid;
	}
	public String getEvery3YearsNYStateClinicalLicenseExp() {
		return every3YearsNYStateClinicalLicenseExp;
	}
	public void setEvery3YearsNYStateClinicalLicenseExp(String every3YearsNYStateClinicalLicenseExp) {
		this.every3YearsNYStateClinicalLicenseExp = every3YearsNYStateClinicalLicenseExp;
	}
	public String getOneTimeEmployeeTrainingExp() {
		return oneTimeEmployeeTrainingExp;
	}
	public void setOneTimeEmployeeTrainingExp(String oneTimeEmployeeTrainingExp) {
		this.oneTimeEmployeeTrainingExp = oneTimeEmployeeTrainingExp;
	}
	public String getEveryYearCompetencyAssessmentTestExp() {
		return everyYearCompetencyAssessmentTestExp;
	}
	public void setEveryYearCompetencyAssessmentTestExp(String everyYearCompetencyAssessmentTestExp) {
		this.everyYearCompetencyAssessmentTestExp = everyYearCompetencyAssessmentTestExp;
	}
	public String getThirdMonthCompetencyAssessmentTestExp() {
		return thirdMonthCompetencyAssessmentTestExp;
	}
	public void setThirdMonthCompetencyAssessmentTestExp(String thirdMonthCompetencyAssessmentTestExp) {
		this.thirdMonthCompetencyAssessmentTestExp = thirdMonthCompetencyAssessmentTestExp;
	}
	public String getSixthMonthCompetencyAssessmentTestExp() {
		return sixthMonthCompetencyAssessmentTestExp;
	}
	public void setSixthMonthCompetencyAssessmentTestExp(String sixthMonthCompetencyAssessmentTestExp) {
		this.sixthMonthCompetencyAssessmentTestExp = sixthMonthCompetencyAssessmentTestExp;
	}
	public String getContinuingEducationCreditinMinExp() {
		return continuingEducationCreditinMinExp;
	}
	public void setContinuingEducationCreditinMinExp(String continuingEducationCreditinMinExp) {
		this.continuingEducationCreditinMinExp = continuingEducationCreditinMinExp;
	}
	public String getEveryYearHIPPAPatientConfidentialityExp() {
		return everyYearHIPPAPatientConfidentialityExp;
	}
	public void setEveryYearHIPPAPatientConfidentialityExp(String everyYearHIPPAPatientConfidentialityExp) {
		this.everyYearHIPPAPatientConfidentialityExp = everyYearHIPPAPatientConfidentialityExp;
	}
	public String getEveryYearBiohazardRiskAssessmentExp() {
		return everyYearBiohazardRiskAssessmentExp;
	}
	public void setEveryYearBiohazardRiskAssessmentExp(String everyYearBiohazardRiskAssessmentExp) {
		this.everyYearBiohazardRiskAssessmentExp = everyYearBiohazardRiskAssessmentExp;
	}
	public String getEveryYearBloodbornPathogensTrainingExp() {
		return everyYearBloodbornPathogensTrainingExp;
	}
	public void setEveryYearBloodbornPathogensTrainingExp(String everyYearBloodbornPathogensTrainingExp) {
		this.everyYearBloodbornPathogensTrainingExp = everyYearBloodbornPathogensTrainingExp;
	}
	public String getEvery3YearsDotTrainingExp() {
		return every3YearsDotTrainingExp;
	}
	public void setEvery3YearsDotTrainingExp(String every3YearsDotTrainingExp) {
		this.every3YearsDotTrainingExp = every3YearsDotTrainingExp;
	}
	public String getEveryYearSupervisorPerformanceReviewExp() {
		return everyYearSupervisorPerformanceReviewExp;
	}
	public void setEveryYearSupervisorPerformanceReviewExp(String everyYearSupervisorPerformanceReviewExp) {
		this.everyYearSupervisorPerformanceReviewExp = everyYearSupervisorPerformanceReviewExp;
	}
	public String getContinuingEducationExp() {
		return continuingEducationExp;
	}
	public void setContinuingEducationExp(String continuingEducationExp) {
		this.continuingEducationExp = continuingEducationExp;
	}


}
