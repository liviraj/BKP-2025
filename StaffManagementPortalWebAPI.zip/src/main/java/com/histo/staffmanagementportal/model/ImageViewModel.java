package com.histo.staffmanagementportal.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ImageViewModel {
    private String documentName;
    private byte[] documentBinary;

}
