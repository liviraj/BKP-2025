package com.histo.staffmanagementportal.model;

import com.histo.staffmanagementportal.dto.EmployeeDTO;
import com.histo.staffmanagementportal.dto.EmployeeWorkDTO;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class EmployeeRequestWrapper {
    private EmployeeDTO employee;
    private EmployeeWorkDTO workDto;
}