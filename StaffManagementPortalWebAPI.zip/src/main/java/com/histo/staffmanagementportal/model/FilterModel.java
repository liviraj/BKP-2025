package com.histo.staffmanagementportal.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class FilterModel {

    Integer locationId;
    Integer employeeId;
    Integer year;
    Integer holidayId;
    @ApiModelProperty(value = "Only for holiday Master Name list fetch API.")
    String status; // Only for holiday name list fetch
    @ApiModelProperty(value = "Only for Payroll filter API")
    String payRollMonth; // Only for payroll fetch

}
