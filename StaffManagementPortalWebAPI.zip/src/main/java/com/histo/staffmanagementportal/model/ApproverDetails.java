package com.histo.staffmanagementportal.model;

public class ApproverDetails {

	private String emailIdType;
	private String emailId;
	private String userName;
	private Integer employeeId;
	
	public ApproverDetails() {
		super();
	}
	public String getEmailIdType() {
		return emailIdType;
	}
	public void setEmailIdType(String emailIdType) {
		this.emailIdType = emailIdType;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

}
