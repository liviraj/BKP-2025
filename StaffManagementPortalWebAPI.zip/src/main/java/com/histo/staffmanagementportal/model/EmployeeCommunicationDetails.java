package com.histo.staffmanagementportal.model;

public class EmployeeCommunicationDetails {
	
	private String address1;
	private String phoneno;		
	private String emergencyContactName;
	private String emergencyContactRelation;
	private String emergencyContactNumber;
	private String alternateContactNumber;
	private String mobileNo;
	private String emailID;
	private String emergencyAddress;
	
	public EmployeeCommunicationDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
    public EmployeeCommunicationDetails(String address1, String alternateContactNumber,
            String emailID, String emergencyContactName, String emergencyContactNumber,
            String emergencyContactRelation,  String phoneno,String mobileNo,String emergencyAddress) {
		this.address1 = address1;
		this.phoneno = phoneno;
		this.emergencyContactName = emergencyContactName;
		this.emergencyContactRelation = emergencyContactRelation;
		this.emergencyContactNumber = emergencyContactNumber;
		this.alternateContactNumber = alternateContactNumber;
		this.mobileNo = mobileNo;
		this.emailID = emailID;
		this.emergencyAddress = emergencyAddress;
	}
	
	public String getEmergencyAddress() {
		return emergencyAddress;
	}

	public void setEmergencyAddress(String emergencyAddress) {
		this.emergencyAddress = emergencyAddress;
	}

	public String getAlternateContactNumber() {
		return alternateContactNumber;
	}

	public void setAlternateContactNumber(String alternateContactNumber) {
		this.alternateContactNumber = alternateContactNumber;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public String getEmergencyContactName() {
		return emergencyContactName;
	}
	public void setEmergencyContactName(String emergencyContactName) {
		this.emergencyContactName = emergencyContactName;
	}
	public String getEmergencyContactRelation() {
		return emergencyContactRelation;
	}
	public void setEmergencyContactRelation(String emergencyContactRelation) {
		this.emergencyContactRelation = emergencyContactRelation;
	}
	public String getEmergencyContactNumber() {
		return emergencyContactNumber;
	}
	public void setEmergencyContactNumber(String emergencyContactNumber) {
		this.emergencyContactNumber = emergencyContactNumber;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	
}
