package com.histo.staffmanagementportal.model;

import com.azure.core.annotation.Get;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class ApproverEmailDetails {
    private Integer empId;
    private Integer assignedToEmpId;
    private String employeeName;
    private String requestType;
    private String description;
    private String assignedTo;
    private String assigneeComments;
    private String requestStatus;
    private String emailId;
    private String cc;
    private String bcc;
    private Integer locationId;
    private String section;
    private String reviewedBy;
}
