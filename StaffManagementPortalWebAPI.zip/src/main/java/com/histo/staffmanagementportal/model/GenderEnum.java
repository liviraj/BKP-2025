package com.histo.staffmanagementportal.model;

public enum GenderEnum {

	MALE("M"),
	FEMALE("F");
    private String value;
	
	public String getValue() {
		return value;
	}

	GenderEnum(String value) {
		this.value = value;
	}
	
}
