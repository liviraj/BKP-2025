package com.histo.staffmanagementportal.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class EmployeeResponseForComplianceExpiry {
    private Integer employeeID;
    private String employeeName;
    private String emailId;
    private String ccEmailId;
    private String subject;
    private List<ComplianceData> data;

    @Getter
    @Setter
    @NoArgsConstructor
    public static class ComplianceData {
        private String compliance;
        private String compliancePeriod;
        private String displayName;
        private String expirydate;
    }
}
