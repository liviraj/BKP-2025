package com.histo.staffmanagementportal.model;

public interface DepartmentName {

	 Integer getDepartmentId();
	 String getDepartmentName();
	 Integer getSortOrder();
	
	
}
