package com.histo.staffmanagementportal.model;

public record LastLeaveAvailed(String date,String status ) {
}
