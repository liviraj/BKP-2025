package com.histo.staffmanagementportal.model;

public record EnumViewModel(String type, String value) {

}
