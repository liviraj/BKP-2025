package com.histo.staffmanagementportal.model;

public class EmployeeTypeModel {

	private Integer employeeTypeId;
	private String employeeType;
	private String employeeTypeCode;
	
	public EmployeeTypeModel() {
		super();
	}
	
	public EmployeeTypeModel(Integer employeeTypeId, String employeeType, String employeeTypeCode) {
		super();
		this.employeeTypeId = employeeTypeId;
		this.employeeType = employeeType;
		this.employeeTypeCode = employeeTypeCode;
	}

	public Integer getEmployeeTypeId() {
		return employeeTypeId;
	}

	public void setEmployeeTypeId(Integer employeeTypeId) {
		this.employeeTypeId = employeeTypeId;
	}

	public String getEmployeeType() {
		return employeeType;
	}
	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}
	public String getEmployeeTypeCode() {
		return employeeTypeCode;
	}
	public void setEmployeeTypeCode(String employeeTypeCode) {
		this.employeeTypeCode = employeeTypeCode;
	}
	
	
	
}
