package com.histo.staffmanagementportal.model;

import java.util.List;

public record CancelRequestModel(List<Integer> leaveRequestDetailId,String cancelRequestComments,String payRollStartDate,String payRollEndDate
		,String cancelRequestedOn,Integer cancelRequestedBy) {

}
