package com.histo.staffmanagementportal.model;

public enum RequestStatus {

    OPEN("Open"),
    INPROGRESS("InProgress"),
    DONE("Done"),
    REJECT("Reject");

    private String value;

    public String getValue() {
        return value;
    }
    RequestStatus(String value) {
        this.value = value;
    }
}
