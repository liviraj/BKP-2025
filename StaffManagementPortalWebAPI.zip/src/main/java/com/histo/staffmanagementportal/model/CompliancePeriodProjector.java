package com.histo.staffmanagementportal.model;

public interface CompliancePeriodProjector {

	Integer getCompliancePeriodId();
	String getCompliancePeriod();
}
