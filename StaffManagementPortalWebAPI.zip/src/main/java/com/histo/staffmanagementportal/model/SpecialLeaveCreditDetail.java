package com.histo.staffmanagementportal.model;

public class SpecialLeaveCreditDetail {

	String employeeName;
	String entryDate;
	double sickLeaveBalance;
	double casualLeaveBalance;
	double sickLeaveCredit;
	double casualLeaveCredit;
	
	public SpecialLeaveCreditDetail() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SpecialLeaveCreditDetail(String employeeName, String entryDate, double sickLeaveBalance,
			double casualLeaveBalance, double sickLeaveCredit, double casualLeaveCredit) {
		super();
		this.employeeName = employeeName;
		this.entryDate = entryDate;
		this.sickLeaveBalance = sickLeaveBalance;
		this.casualLeaveBalance = casualLeaveBalance;
		this.sickLeaveCredit = sickLeaveCredit;
		this.casualLeaveCredit = casualLeaveCredit;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}

	public double getSickLeaveBalance() {
		return sickLeaveBalance;
	}

	public void setSickLeaveBalance(double sickLeaveBalance) {
		this.sickLeaveBalance = sickLeaveBalance;
	}

	public double getCasualLeaveBalance() {
		return casualLeaveBalance;
	}

	public void setCasualLeaveBalance(double casualLeaveBalance) {
		this.casualLeaveBalance = casualLeaveBalance;
	}

	public double getSickLeaveCredit() {
		return sickLeaveCredit;
	}

	public void setSickLeaveCredit(double sickLeaveCredit) {
		this.sickLeaveCredit = sickLeaveCredit;
	}

	public double getCasualLeaveCredit() {
		return casualLeaveCredit;
	}

	public void setCasualLeaveCredit(double casualLeaveCredit) {
		this.casualLeaveCredit = casualLeaveCredit;
	}
	
	
}
