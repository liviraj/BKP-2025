package com.histo.staffmanagementportal.model;

public class LCResponse  {

	private String entryDate;
	private String creditDays;
	private String balanceDays;
	private String employeeName;
	private Integer employeeId;
	
	public LCResponse() {
		super();
	}
	public LCResponse(String entryDate, String creditDays, String balanceDays, String employeeName,
			Integer employeeId) {
		super();
		this.entryDate = entryDate;
		this.creditDays = creditDays;
		this.balanceDays = balanceDays;
		this.employeeName = employeeName;
		this.employeeId = employeeId;
	}
	public String getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}
	public String getCreditDays() {
		return creditDays;
	}
	public void setCreditDays(String creditDays) {
		this.creditDays = creditDays;
	}
	public String getBalanceDays() {
		return balanceDays;
	}
	public void setBalanceDays(String balanceDays) {
		this.balanceDays = balanceDays;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

}
