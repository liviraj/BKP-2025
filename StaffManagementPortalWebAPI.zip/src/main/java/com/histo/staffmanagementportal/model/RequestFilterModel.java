package com.histo.staffmanagementportal.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RequestFilterModel {

    private Integer requestTypeId;
    private Integer requestStatusId;
    private Integer locationId;
    private Integer employeeId;
    private String fromDate;
    private String toDate;
}
