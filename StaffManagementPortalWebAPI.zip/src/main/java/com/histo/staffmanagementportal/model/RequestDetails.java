package com.histo.staffmanagementportal.model;

import com.azure.core.annotation.Get;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RequestDetails {

    private String empId;
    private String employeeName;
    private String assigneeImageName;
    private String requestType;
    private String locationId;
    private String description;
    private byte[] assigneeImageBinary;
    private String requestId;
    private String modifiedDate;
    private String modifiedBy;
    private String status;
    private String statusId;
    private String assignedTo;
    private String eventDescription;
    private Integer autoId;
    private String requestDate;
    private String approvedBy;
    private String approvedOn;
    private Integer assignedToEmpId;

}