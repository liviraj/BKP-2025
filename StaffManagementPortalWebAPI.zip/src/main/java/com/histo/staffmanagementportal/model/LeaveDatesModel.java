package com.histo.staffmanagementportal.model;

import java.time.Instant;
import java.util.List;

public record LeaveDatesModel(double noOfDaysApplied,List<Instant> workDays) {

}
