package com.histo.staffmanagementportal.model;

public class ComplianceCertificateInfo {

	private Integer employeeId;
	private String expiryDate;
	private String complianceCategory;
	private String isNoExpiry;

	public ComplianceCertificateInfo() {
		super();
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getComplianceCategory() {
		return complianceCategory;
	}
	public void setComplianceCategory(String complianceCategory) {
		this.complianceCategory = complianceCategory;
	}
	public String getIsNoExpiry() {
		return isNoExpiry;
	}

	public void setIsNoExpiry(String noExpiry) {
		isNoExpiry = noExpiry;
	}
	
}
