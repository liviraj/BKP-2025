package com.histo.staffmanagementportal.model;

import java.time.Instant;

public class LeaveHistoryDetail {

	public String remarks;
	public String days;
	public String daysApproved;
	public String leavePeriod;
	public String status;
	public String statusChar;
	public Integer leaveId;
	public String leavesAvailed;
	public Instant leaveFrom;
	public Integer typeOfLeave;
	public String leaveType;

	public LeaveHistoryDetail() {
		super();
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getDays() {
		return days;
	}

	public void setDays(String days) {
		this.days = days;
	}

	public String getDaysApproved() {
		return daysApproved;
	}

	public void setDaysApproved(String daysApproved) {
		this.daysApproved = daysApproved;
	}

	public String getLeavePeriod() {
		return leavePeriod;
	}

	public void setLeavePeriod(String leavePeriod) {
		this.leavePeriod = leavePeriod;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusChar() {
		return statusChar;
	}

	public void setStatusChar(String statusChar) {
		this.statusChar = statusChar;
	}

	public Integer getLeaveId() {
		return leaveId;
	}

	public void setLeaveId(Integer leaveId) {
		this.leaveId = leaveId;
	}

	public String getLeavesAvailed() {
		return leavesAvailed;
	}

	public void setLeavesAvailed(String leavesAvailed) {
		this.leavesAvailed = leavesAvailed;
	}

	public Instant getLeaveFrom() {
		return leaveFrom;
	}

	public void setLeaveFrom(Instant leaveFrom) {
		this.leaveFrom = leaveFrom;
	}

	public Integer getTypeOfLeave() {
		return typeOfLeave;
	}

	public void setTypeOfLeave(Integer typeOfLeave) {
		this.typeOfLeave = typeOfLeave;
	}

	public String getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

	@Override
	public String toString() {
		return "LeaveHistoryDetail [remarks=" + remarks + ", days=" + days + ", daysApproved=" + daysApproved
				+ ", leavePeriod=" + leavePeriod + ", status=" + status + ", statusChar=" + statusChar + ", leaveId="
				+ leaveId + ", leavesAvailed=" + leavesAvailed + ", leaveFrom=" + leaveFrom + ", typeOfLeave="
				+ typeOfLeave + ", leaveType=" + leaveType + "]";
	}
	
	
}
