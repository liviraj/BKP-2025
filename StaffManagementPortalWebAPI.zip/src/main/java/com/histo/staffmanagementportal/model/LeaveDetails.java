package com.histo.staffmanagementportal.model;

public record LeaveDetails(Double totalDebit,Double balance) {

}
