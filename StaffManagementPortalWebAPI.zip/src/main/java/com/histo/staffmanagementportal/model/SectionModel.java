package com.histo.staffmanagementportal.model;

import java.util.List;

public class SectionModel {
	private Integer departmentId;
	private String departmentName;
	private List<Integer> locationId;
	private Integer sortOrder;
	
	public SectionModel() {
		super();
	}
	public SectionModel(Integer departmentId, String departmentName, List<Integer> locationId,Integer sortOrder) {
		super();
		this.departmentId = departmentId;
		this.departmentName = departmentName;
		this.locationId = locationId;
		this.sortOrder = sortOrder;
	}
	
	public Integer getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public List<Integer> getLocationId() {
		return locationId;
	}
	public void setLocationId(List<Integer> locationId) {
		this.locationId = locationId;
	}
	public Integer getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(Integer sortOrder) {
		this.sortOrder = sortOrder;
	}
	
}
