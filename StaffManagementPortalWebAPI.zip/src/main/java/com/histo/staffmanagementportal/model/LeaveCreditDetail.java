package com.histo.staffmanagementportal.model;


public class LeaveCreditDetail {

	private String employeeName;
	private Integer employeeId;
	private String doj;
	private String confirmationDate;
	private String relievingDate;
	private String employmentStatus;
	private boolean isBreakInEmployment;
	private Integer joinedFrom;
	
	public LeaveCreditDetail() {
		super();
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getDoj() {
		return doj;
	}
	public void setDoj(String doj) {
		this.doj = doj;
	}
	public String getConfirmationDate() {
		return confirmationDate;
	}
	public void setConfirmationDate(String confirmationDate) {
		this.confirmationDate = confirmationDate;
	}
	public String getRelievingDate() {
		return relievingDate;
	}
	public void setRelievingDate(String relievingDate) {
		this.relievingDate = relievingDate;
	}
	public String getEmploymentStatus() {
		return employmentStatus;
	}
	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}
	public boolean isBreakInEmployment() {
		return isBreakInEmployment;
	}
	public void setBreakInEmployment(boolean isBreakInEmployment) {
		this.isBreakInEmployment = isBreakInEmployment;
	}
	public Integer getJoinedFrom() {
		return joinedFrom;
	}
	public void setJoinedFrom(Integer joinedFrom) {
		this.joinedFrom = joinedFrom;
	}
	
}
