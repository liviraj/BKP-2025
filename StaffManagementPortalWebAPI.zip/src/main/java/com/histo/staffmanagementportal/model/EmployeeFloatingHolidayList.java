package com.histo.staffmanagementportal.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@NoArgsConstructor
@ToString
public class EmployeeFloatingHolidayList {

        private Integer employeeId;
        private String employeeName;
        private Integer holidayDetailId;
        private String holidayName;
        private String startDate;
        private String endDate;
        private String isOptional;
        private Integer locationID;
        private Integer holidayId;
        private String departmentName;
        private String employeeCode;

}
