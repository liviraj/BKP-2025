package com.histo.staffmanagementportal.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeComplianceModel  {

	private Integer employeeComplianceId;
	private Integer employeeId;
	private String createdBy;
	private String complianceCategory;
	private String compliancePeriod;
	private String complianceDate;
	private String description;
	private String documentName;
	private String expiryDate;
	private Boolean isValid;
	
}
