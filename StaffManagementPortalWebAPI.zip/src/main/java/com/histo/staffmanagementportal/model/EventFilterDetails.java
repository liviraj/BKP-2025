package com.histo.staffmanagementportal.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EventFilterDetails{
        private Integer employeeId;
        private String employeeName;
        private String employeeType;
        private String employeeTypeValue;
        private String isDefault;
}
