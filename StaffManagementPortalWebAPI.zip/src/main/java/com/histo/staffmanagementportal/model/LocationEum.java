package com.histo.staffmanagementportal.model;

public enum LocationEum {

	All(0),
	INDIA(1),
	USA(2);

	private Integer value;

	public Integer getValue() {
		return value;
	}

	LocationEum(Integer value) {
		this.value = value;
	}

	public static LocationEum getEnumFromString(String text) {
		for (LocationEum location : LocationEum.values()) {
			if (location.value.equals( Integer.parseInt(text))) {
				return location;
			}

		}
		return null;
	}
}
