package com.histo.staffmanagementportal.model;

public class EmployeeName {

	private Integer employeeId;
	private String empName;
	private Integer locationId;
	private String employmentStatus;
	private String sortOrder;
	private String roleName;
	private Integer supervisorId;
	private String employeeType;

	public EmployeeName() {
		super();
	}
	public EmployeeName(Integer employeeId, String employeeName,Integer locationId,String employmentStatus,String sortOrder, String roleName, Integer supervisorId) {
		this.employeeId = employeeId;
		this.empName = employeeName;
		this.locationId = locationId;
		this.employmentStatus = employmentStatus;
		this.sortOrder = sortOrder;
	    this.roleName = roleName;
	    this.supervisorId = supervisorId;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String employeeName) {
		this.empName = employeeName;
	}
	public Integer getLocationId() {
		return locationId;
	}
	public void setLocationId(Integer locationId) {
		this.locationId = locationId;
	}
	public String getEmploymentStatus() {
		return employmentStatus;
	}
	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}
	public String getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public Integer getSupervisorId() {
		return supervisorId;
	}
	public void setSupervisorId(Integer supervisorId) {
		this.supervisorId = supervisorId;
	}
	public String getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}

}
