package com.histo.staffmanagementportal.model;

public class EmployeeSearchModel {

	private String departmentId;
	private String designationId;
	private String employeeId;
	private String locationId;
	private String employeeType;
	private String employeeStatus;
	private String clinicalHandler;
	public EmployeeSearchModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EmployeeSearchModel(String departmentId, String designationId, String employeeId, String locationId,
			String employeeType, String employeeStatus,String clinicalHandler) {
		this.departmentId = departmentId;
		this.designationId = designationId;
		this.employeeId = employeeId;
		this.locationId = locationId;
		this.employeeType = employeeType;
		this.employeeStatus = employeeStatus;
		this.clinicalHandler = clinicalHandler;
	}
	public String getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}
	public String getDesignationId() {
		return designationId;
	}
	public void setDesignationId(String designationId) {
		this.designationId = designationId;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public String getEmployeeType() {
		return employeeType;
	}
	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}
	public String getEmployeeStatus() {
		return employeeStatus;
	}
	public void setEmployeeStatus(String employeeStatus) {
		this.employeeStatus = employeeStatus;
	}
	public String getClinicalHandler() {
		return clinicalHandler;
	}
	public void setClinicalHandler(String clinicalHandler) {
		this.clinicalHandler = clinicalHandler;
	}
}
