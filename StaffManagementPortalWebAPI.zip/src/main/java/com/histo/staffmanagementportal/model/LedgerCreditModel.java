package com.histo.staffmanagementportal.model;

public class LedgerCreditModel {

	private Double creditDays;
	private Integer employeeId;
	private String comments;
	private Integer creditAddedBy;
	private String creditAddedOn;
	private String entryDate;
	private String leaveType;

	private String locationId;
	
	public LedgerCreditModel() {
		super();
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public String getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}

	public String getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

	public Double getCreditDays() {
		return creditDays;
	}
	public void setCreditDays(Double creditDays) {
		this.creditDays = creditDays;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public Integer getCreditAddedBy() {
		return creditAddedBy;
	}
	public void setCreditAddedBy(Integer creditAddedBy) {
		this.creditAddedBy = creditAddedBy;
	}
	public String getCreditAddedOn() {
		return creditAddedOn;
	}
	public void setCreditAddedOn(String creditAddedOn) {
		this.creditAddedOn = creditAddedOn;
	}
	
	
}
