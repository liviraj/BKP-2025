package com.histo.staffmanagementportal.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ComplianceReportFilter {

	private String filter;
	private Integer year;
	private String employeeId;
	private Integer designationId;
	private String doj;
    private Integer supervisorEmpId;
	private List<Integer> empId;

}
