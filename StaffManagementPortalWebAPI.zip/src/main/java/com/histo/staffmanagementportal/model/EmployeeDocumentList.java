package com.histo.staffmanagementportal.model;

public class EmployeeDocumentList {

	private Integer documentId;
	private Integer employeeId;
	private String documentDate;
	private String documentType;
	private String description;
	private String documentName;
	private String uploadedBy;
	private String uploadedOn;
	private String expiryDate;
	
	public EmployeeDocumentList() {
		super();
	}
	
	public EmployeeDocumentList(Integer documentId, Integer employeeId, String documentDate, String documentType,
			String description, String documentName, String uploadedBy, String uploadedOn, String expiryDate) {
		super();
		this.documentId = documentId;
		this.employeeId = employeeId;
		this.documentDate = documentDate;
		this.documentType = documentType;
		this.description = description;
		this.documentName = documentName;
		this.uploadedBy = uploadedBy;
		this.uploadedOn = uploadedOn;
		this.expiryDate = expiryDate;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Integer getDocumentId() {
		return documentId;
	}
	public void setDocumentId(Integer documentId) {
		this.documentId = documentId;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getDocumentDate() {
		return documentDate;
	}
	public void setDocumentDate(String documentDate) {
		this.documentDate = documentDate;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getUploadedBy() {
		return uploadedBy;
	}
	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}
	public String getUploadedOn() {
		return uploadedOn;
	}
	public void setUploadedOn(String uploadedOn) {
		this.uploadedOn = uploadedOn;
	}
	
}
