package com.histo.staffmanagementportal.model;

public class DesignationName {

	private Integer designationId;
	private String designationName;
	
	public DesignationName() {
		super();
	}
	public DesignationName(Integer designationId, String designationName) {
		this.designationId = designationId;
		this.designationName = designationName;
	}
	public Integer getDesignationId() {
		return designationId;
	}
	public void setDesignationId(Integer designationId) {
		this.designationId = designationId;
	}
	public String getDesignationName() {
		return designationName;
	}
	public void setDesignationName(String designationName) {
		this.designationName = designationName;
	}
}
