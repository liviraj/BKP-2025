package com.histo.staffmanagementportal.model;

import java.util.List;

public class LeaveRequestDetails {

	private List<Integer> leaveRequestDetailId;
	private Integer requestId;
	private Integer approvedBy;
	private String approverComments;
	private String status;
	private String approvedOn;
	
	public LeaveRequestDetails() {
		super();
	}
	
	public String getApprovedOn() {
		return approvedOn;
	}

	public void setApprovedOn(String approvedOn) {
		this.approvedOn = approvedOn;
	}

	public Integer getRequestId() {
		return requestId;
	}
	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}

	public List<Integer> getLeaveRequestDetailId() {
		return leaveRequestDetailId;
	}
	public void setLeaveRequestDetailId(List<Integer> leaveRequestDetailId) {
		this.leaveRequestDetailId = leaveRequestDetailId;
	}
	public Integer getApprovedBy() {
		return approvedBy;
	}
	public void setApprovedBy(Integer approvedBy) {
		this.approvedBy = approvedBy;
	}
	public String getApproverComments() {
		return approverComments;
	}
	public void setApproverComments(String approverComments) {
		this.approverComments = approverComments;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
