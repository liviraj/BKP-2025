package com.histo.staffmanagementportal.model;

public record DeleteDetails(Integer modifiedBy , String modifiedDate, Integer id, Boolean isExists,Integer locationId) {
}
