package com.histo.staffmanagementportal.model;

public enum EmployeeTypeEnum {

	ALL("All"),
	FULL_TIME_EMPLOYEE("Full Time Employee"),
	PART_TIME_EMPLOYEE("Part Time Employee"),
	FULL_TIME_EMPLOYEE_CODE("E"),
	PART_TIME_EMPLOYEE_CODE("PTE");

	private String value;
	
	public String getValue() {
		return value;
	}

	EmployeeTypeEnum(String value) {
		this.value = value;
	}
	
}
