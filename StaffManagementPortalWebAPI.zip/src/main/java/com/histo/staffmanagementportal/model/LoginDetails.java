package com.histo.staffmanagementportal.model;

public class LoginDetails {
	private String employeeName;
	private String employeeCode;
	private String location;
	private String loginid;
	private Integer employeeId;
	private String employmentStatus;
	private String rolename;
	private String emailId;
	
	public LoginDetails() {
		super();
	}
	
	public LoginDetails(String employeeName, String employeeCode, String location, String loginid, Integer employeeId,
			String employmentStatus, String rolename, String emailId) {
		super();
		this.employeeName = employeeName;
		this.employeeCode = employeeCode;
		this.location = location;
		this.loginid = loginid;
		this.employeeId = employeeId;
		this.employmentStatus = employmentStatus;
		this.rolename = rolename;
		this.emailId = emailId;
	}

	public String getEmailId() {
		return emailId;
	}
	
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeCode() {
		return employeeCode;
	}
	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getLoginid() {
		return loginid;
	}
	public void setLoginid(String loginid) {
		this.loginid = loginid;
	}
	public String getEmploymentStatus() {
		return employmentStatus;
	}
	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}
	
	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getRolename() {
		return rolename;
	}
	public void setRolename(String rolename) {
		this.rolename = rolename;
	}
}
