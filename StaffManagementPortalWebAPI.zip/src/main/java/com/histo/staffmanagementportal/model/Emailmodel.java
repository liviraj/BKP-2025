package com.histo.staffmanagementportal.model;

public class Emailmodel {

	private String[] cc;
	private String[] bcc;
	private String[] emailId;
	
	public Emailmodel() {
		super();
	}

	public String[] getCc() {
		return cc;
	}

	public void setCc(String[] cc) {
		this.cc = cc;
	}

	public String[] getBcc() {
		return bcc;
	}

	public void setBcc(String[] bcc) {
		this.bcc = bcc;
	}

	public String[] getEmailId() {
		return emailId;
	}

	public void setEmailId(String[] emailId) {
		this.emailId = emailId;
	}
	
}
