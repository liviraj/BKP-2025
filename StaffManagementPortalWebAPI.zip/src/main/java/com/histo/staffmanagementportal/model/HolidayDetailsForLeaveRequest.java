package com.histo.staffmanagementportal.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class HolidayDetailsForLeaveRequest {

    private String holidayName;
    private String holidayDate;
    private String startDate;
    private String endDate;
    private Boolean isOptional;
    private Boolean isEmployeeFloating;

}
