package com.histo.staffmanagementportal.model;

import lombok.Data;

@Data
public class AttendanceFilter {

    private String fromDate;
    private String toDate;
    private String locationId;
    private String employeeId;
    private String employeetype;
}
