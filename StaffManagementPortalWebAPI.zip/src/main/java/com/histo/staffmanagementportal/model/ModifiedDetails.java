package com.histo.staffmanagementportal.model;

public record ModifiedDetails(Integer modifiedBy,String modifiedDate) {

}
