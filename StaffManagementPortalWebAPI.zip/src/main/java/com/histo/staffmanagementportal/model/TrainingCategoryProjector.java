package com.histo.staffmanagementportal.model;

public interface TrainingCategoryProjector{
	Integer getTrainingCategoryId();
	String getTrainingCategory();
}
