package com.histo.staffmanagementportal.model;

import java.util.List;

public class ApproveOrRejectLeaveDetails {

	private String employeeName;
	private List<LeaveDetailsRecord> leaveDetailsRecord;
	
	public ApproveOrRejectLeaveDetails() {
		super();
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public List<LeaveDetailsRecord> getLeaveDetailsRecord() {
		return leaveDetailsRecord;
	}
	public void setLeaveDetailsRecord(List<LeaveDetailsRecord> leaveDetailsRecord) {
		this.leaveDetailsRecord = leaveDetailsRecord;
	}

}
