package com.histo.staffmanagementportal.model;


public class EmailContent {
	
	private Integer employeeID;
	private String employeeName;
	 private String doj;
	 private String department;
	 private Integer leaveRequestId;
	 private double sickLeaveBalance;
	 private double vacationLeaveBalance;
	 private double casualLeaveBalance;
	 private String currentDate;
	
	public EmailContent() {
		super();
	}

	public Integer getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(Integer employeeID) {
		this.employeeID = employeeID;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Integer getLeaveRequestId() {
		return leaveRequestId;
	}

	public double getSickLeaveBalance() {
		return sickLeaveBalance;
	}

	public void setSickLeaveBalance(double sickLeaveBalance) {
		this.sickLeaveBalance = sickLeaveBalance;
	}

	public double getVacationLeaveBalance() {
		return vacationLeaveBalance;
	}

	public void setVacationLeaveBalance(double vacationLeaveBalance) {
		this.vacationLeaveBalance = vacationLeaveBalance;
	}

	public void setLeaveRequestId(Integer leaveRequestId) {
		this.leaveRequestId = leaveRequestId;
	}

	public String getDoj() {
		return doj;
	}

	public void setDoj(String doj) {
		this.doj = doj;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public double getCasualLeaveBalance() {
		return casualLeaveBalance;
	}

	public void setCasualLeaveBalance(double casualLeaveBalance) {
		this.casualLeaveBalance = casualLeaveBalance;
	}

	public String getCurrentDate() {
		return currentDate;
	}

	public void setCurrentDate(String currentDate) {
		this.currentDate = currentDate;
	}
}
