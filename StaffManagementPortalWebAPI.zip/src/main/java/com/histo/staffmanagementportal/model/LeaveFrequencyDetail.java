package com.histo.staffmanagementportal.model;

public class LeaveFrequencyDetail {
	
	public String period;	
	public double vacationLeaveTaken;
	public String leavePeriod;
	public double sickLeavesTaken;	
	public double casualLeavesTaken;
	public String location;
	
	public LeaveFrequencyDetail() {
		super();
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public double getVacationLeaveTaken() {
		return vacationLeaveTaken;
	}

	public void setVacationLeaveTaken(double vacationLeaveTaken) {
		this.vacationLeaveTaken = vacationLeaveTaken;
	}

	public String getLeavePeriod() {
		return leavePeriod;
	}

	public void setLeavePeriod(String leavePeriod) {
		this.leavePeriod = leavePeriod;
	}

	public double getSickLeavesTaken() {
		return sickLeavesTaken;
	}

	public void setSickLeavesTaken(double sickLeavesTaken) {
		this.sickLeavesTaken = sickLeavesTaken;
	}

	public double getCasualLeavesTaken() {
		return casualLeavesTaken;
	}

	public void setCasualLeavesTaken(double casualLeavesTaken) {
		this.casualLeavesTaken = casualLeavesTaken;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "LeaveFrequencyDetail [period=" + period + ", vacationLeaveTaken=" + vacationLeaveTaken
				+ ", leavePeriod=" + leavePeriod + ", sickLeavesTaken=" + sickLeavesTaken + ", casualLeavesTaken="
				+ casualLeavesTaken + ", location=" + location + "]";
	}
	
}
