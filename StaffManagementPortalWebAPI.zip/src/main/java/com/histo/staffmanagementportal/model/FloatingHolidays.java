package com.histo.staffmanagementportal.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class FloatingHolidays {

    private Integer holidayDetailId;
    private String holidayName;
    private Integer employeeHolidayId;
    private Integer isUsed;
    private Boolean isDisabled;

}
