package com.histo.staffmanagementportal.model;

public class EmployeeQualificationDetails {
	
	private Integer qualificationId;
	private String qualification;
	private String institution;
	private String courseEndDate;
	public EmployeeQualificationDetails() {
		super();
		
	}
	public EmployeeQualificationDetails(Integer qualificationId, String qualification, String institution,
			String courseEndDate) {
		this.qualificationId = qualificationId;
		this.qualification = qualification;
		this.institution = institution;
		this.courseEndDate = courseEndDate;
	}
	
	public Integer getQualificationId() {
		return qualificationId;
	}
	public void setQualificationId(Integer qualificationId) {
		this.qualificationId = qualificationId;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getInstitution() {
		return institution;
	}
	public void setInstitution(String institution) {
		this.institution = institution;
	}
	public String getCourseEndDate() {
		return courseEndDate==null?"":courseEndDate;
	}
	public void setCourseEndDate(String courseEndDate) {
		this.courseEndDate = courseEndDate;
	}
	@Override
	public String toString() {
		return "EmployeeQualificationDetails [qualificationId=" + qualificationId + ", qualification=" + qualification
				+ ", institution=" + institution + ", courseEndDate=" + courseEndDate + "]";
	}	
	
}
