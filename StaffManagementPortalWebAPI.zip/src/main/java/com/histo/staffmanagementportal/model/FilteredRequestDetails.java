package com.histo.staffmanagementportal.model;

import lombok.Data;

@Data
public class  FilteredRequestDetails {

    private Integer employeeId;
    private Integer requestId;
    private String employeeName;
    private String createdDate;
    private String description;
    private String request;
    private String requestStatus;
    private String reviewedBy;
    private String reviewedOn;
    private String imageName;
    private String comments;

}
