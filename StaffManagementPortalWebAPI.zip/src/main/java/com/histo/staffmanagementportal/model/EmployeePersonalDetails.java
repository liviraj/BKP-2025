package com.histo.staffmanagementportal.model;

public class EmployeePersonalDetails {

	private Integer employeeId;
    private String employeeName;
    private String gender;
    private String dob;
    private String maritalstatus;
    private String employeeCode;
    private String passportNo;
	
	public EmployeePersonalDetails() {
		super();
	}
	
	public EmployeePersonalDetails(Integer employeeId, String employeeName,String dob,
			String maritalstatus, String employeeCode,String gender,  String passportNo) {
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.gender = gender;
		this.dob = dob;
		this.maritalstatus = maritalstatus;
		this.employeeCode = employeeCode;
		this.passportNo = passportNo;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getMaritalstatus() {
		return maritalstatus;
	}
	public void setMaritalstatus(String maritalstatus) {
		this.maritalstatus = maritalstatus;
	}
	public String getEmployeeCode() {
		return employeeCode;
	}
	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}
	public String getPassportNo() {
		return passportNo;
	}
	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}
    
    
}
