package com.histo.staffmanagementportal.model;

import java.time.Instant;

public class EmployeeWorkScheduleModel {
	private Instant fromDate;
	private String workDays;
	private Instant toDate;
	private Integer activity;
	private Character recordStatus;
	private Double totalhrsperday;

	public EmployeeWorkScheduleModel() {
		super();
	}

	public EmployeeWorkScheduleModel(Instant fromDate,  String workDays,Instant toDate, Integer activity,
			Character recordStatus, Double totalhrsperday) {
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.workDays = workDays;
		this.activity = activity;
		this.recordStatus = recordStatus;
		this.totalhrsperday = totalhrsperday;
	}

	public String getFromDate() {
		return fromDate==null?"":fromDate.toString();
	}

	public void setFromDate(Instant fromDate) {
		this.fromDate = fromDate;
	}

	public String getWorkDays() {
		return workDays;
	}

	public void setWorkDays(String workDays) {
		this.workDays = workDays;
	}

	public String getToDate() {
		return toDate==null?"":toDate.toString();
	}

	public void setToDate(Instant toDate) {
		this.toDate = toDate;
	}

	public Integer getActivity() {
		return activity;
	}

	public void setActivity(Integer activity) {
		this.activity = activity;
	}

	public Character getRecordStatus() {
		return recordStatus;
	}

	public void setRecordStatus(Character recordStatus) {
		this.recordStatus = recordStatus;
	}

	public Double getTotalhrsperday() {
		return totalhrsperday;
	}

	public void setTotalhrsperday(Double totalhrsperday) {
		this.totalhrsperday = totalhrsperday;
	}

}
