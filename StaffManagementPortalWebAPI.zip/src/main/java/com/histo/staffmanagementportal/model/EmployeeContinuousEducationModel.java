package com.histo.staffmanagementportal.model;

public class EmployeeContinuousEducationModel {
	
	private Integer continousEducationId;
	private String courseDuration;
	private String courseName;
	private String conductedBy;
	private String courseCategory;

	public EmployeeContinuousEducationModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EmployeeContinuousEducationModel(Integer continousEducationId, String courseDuration, String courseName,
			String conductedBy, String courseCategory) {
		this.continousEducationId = continousEducationId;
		this.courseDuration = courseDuration;
		this.courseName = courseName;
		this.conductedBy = conductedBy;
		this.courseCategory = courseCategory;
	}
	public Integer getContinousEducationId() {
		return continousEducationId;
	}
	public void setContinousEducationId(Integer continousEducationId) {
		this.continousEducationId = continousEducationId;
	}
	public String getCourseDuration() {
		return courseDuration;
	}

	public void setCourseDuration(String courseDuration) {
		this.courseDuration = courseDuration;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getConductedBy() {
		return conductedBy;
	}

	public void setConductedBy(String conductedBy) {
		this.conductedBy = conductedBy;
	}

	public String getCourseCategory() {
		return courseCategory;
	}

	public void setCourseCategory(String courseCategory) {
		this.courseCategory = courseCategory;
	}
}
