package com.histo.staffmanagementportal.model;

public class EmployeeWorkHistoryModel {
	
	private Integer employeeWorkHistoryId;
	 private String employerName;
	private String designation;
	private String dateOfJoin;
	private String relievingDate;
	private String reportingTo;
	
	public EmployeeWorkHistoryModel() {
		super();
	}

	public EmployeeWorkHistoryModel(Integer workHistoryId, String employerName, String designation, String dateofJoin,
			String relievingDate,String reportingTo) {
		this.employeeWorkHistoryId = workHistoryId;
		this.employerName = employerName;
		this.designation = designation;
		this.dateOfJoin = dateofJoin;
		this.relievingDate = relievingDate;
		this.reportingTo = reportingTo;
	}

	public String getReportingTo() {
		return reportingTo;
	}

	public void setReportingTo(String reportingTo) {
		this.reportingTo = reportingTo;
	}

	public Integer getEmployeeWorkHistoryId() {
		return employeeWorkHistoryId;
	}

	public void setEmployeeWorkHistoryId(Integer workHistoryId) {
		this.employeeWorkHistoryId = workHistoryId;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public void setDateOfJoin(String dateofJoin) {
		this.dateOfJoin = dateofJoin;
	}

	public void setRelievingDate(String relievingDate) {
		this.relievingDate = relievingDate;
	}

	public String getDateOfJoin() {
		return dateOfJoin;
	}

	public String getRelievingDate() {
		return relievingDate;
	}
	
}
