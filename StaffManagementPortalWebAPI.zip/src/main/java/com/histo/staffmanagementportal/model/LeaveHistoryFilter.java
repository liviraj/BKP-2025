package com.histo.staffmanagementportal.model;

public class LeaveHistoryFilter {

	private Integer locationId;
	private Integer employeeId;
	private String fromDate;
	private String toDate;
	private String status;
	private String leaveType;
	private Integer supervisorEmployeeId;
	
	public LeaveHistoryFilter() {
		super();
	}

	public Integer getSupervisorEmployeeId() {
		return supervisorEmployeeId;
	}

	public void setSupervisorEmployeeId(Integer supervisorEmployeeId) {
		this.supervisorEmployeeId = supervisorEmployeeId;
	}

	public String getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

	public Integer getLocationId() {
		return locationId;
	}

	public void setLocationId(Integer locationId) {
		this.locationId = locationId;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "LeaveHistoryFilter [locationId=" + locationId + ", employeeId=" + employeeId + ", fromDate=" + fromDate
				+ ", toDate=" + toDate + ", status=" + status + "]";
	}
	
	
	
}
