package com.histo.staffmanagementportal.model;

import java.time.Instant;

import com.fasterxml.jackson.annotation.JsonFormat;

public class PayRollDetails {

	private PayRollPeriod usPayRoll;
	private PayRollPeriod indiaPayRoll;

	public PayRollPeriod getUsPayRoll() {
		return usPayRoll;
	}

	public void setUsPayRoll(PayRollPeriod usPayRoll) {
		this.usPayRoll = usPayRoll;
	}

	public PayRollPeriod getIndiaPayRoll() {
		return indiaPayRoll;
	}

	public void setIndiaPayRoll(PayRollPeriod indiaPayRoll) {
		this.indiaPayRoll = indiaPayRoll;
	}

	public record PayRollDates(@JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss", timezone = "UTC")Instant startDate,
							   @JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss", timezone = "UTC")Instant endDate,
							   @JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss", timezone = "UTC")Instant payRollEndDate) {}
	
	public record PayRollPeriod(PayRollDates current,PayRollDates previous, PayRollDates next) {

		}
}
 


