package com.histo.staffmanagementportal.model;

public class LedgerUpdateModel {
	
	private String updatedBy;
	private String updateEmail;
	private String employeeName;
	
	public LedgerUpdateModel() {
		super();
	
	}
	
	
	public String getEmployeeName() {
		return employeeName;
	}


	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}


	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getUpdateEmail() {
		return updateEmail;
	}
	public void setUpdateEmail(String updateEmail) {
		this.updateEmail = updateEmail;
	}
}
