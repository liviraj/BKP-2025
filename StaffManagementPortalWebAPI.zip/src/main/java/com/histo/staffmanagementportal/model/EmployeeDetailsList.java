package com.histo.staffmanagementportal.model;

public class EmployeeDetailsList {

	 private Integer employeeId;
	 private String employeeCode;
	 private String employeeName;
	 private String doj;
	 private String designation;
	 private String department;
	 private String location;
	 private String employeeType;
	 private String employeeStatus;
	 private Boolean clinicalHandler;
	 
	public EmployeeDetailsList() {
		super();
	}

	public EmployeeDetailsList(Integer employeeId, String employeeCode, String employeeName, String doj,
			String designation, String department, String location, String employeeType, String employeeStatus,
			Boolean clinicalHandler) {
		this.employeeId = employeeId;
		this.employeeCode = employeeCode;
		this.employeeName = employeeName;
		this.doj = doj;
		this.designation = designation;
		this.department = department;
		this.location = location;
		this.employeeType = employeeType;
		this.employeeStatus = employeeStatus;
		this.clinicalHandler = clinicalHandler;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeCode() {
		return employeeCode;
	}

	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getDoj() {
		return doj;
	}

	public void setDoj(String doj) {
		this.doj = doj;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}

	public String getEmployeeStatus() {
		return employeeStatus;
	}

	public void setEmployeeStatus(String employeeStatus) {
		this.employeeStatus = employeeStatus;
	}

	public Boolean getClinicalHandler() {
		return clinicalHandler;
	}

	public void setClinicalHandler(Boolean clinicalHandler) {
		this.clinicalHandler = clinicalHandler;
	}
}
