package com.histo.staffmanagementportal.model;

public class EmployeeTrainingDetails{
	
		private Integer employeeTrainingId;
		private String trainingCategory;
		private String purpose;
		private String trainingFrom;
		private String trainingTo;
		
		public EmployeeTrainingDetails() {
			super();
		}
		public Integer getEmployeeTrainingId() {
			return employeeTrainingId;
		}
		public void setEmployeeTrainingId(Integer employeeTrainingId) {
			this.employeeTrainingId = employeeTrainingId;
		}
		public String getTrainingCategory() {
			return trainingCategory;
		}
		public void setTrainingCategory(String trainingCategory) {
			this.trainingCategory = trainingCategory;
		}
		public String getPurpose() {
			return purpose;
		}
		public void setPurpose(String purpose) {
			this.purpose = purpose;
		}
		public String getTrainingFrom() {
			return trainingFrom;
		}
		public void setTrainingFrom(String trainingFrom) {
			this.trainingFrom = trainingFrom;
		}
		public String getTrainingTo() {
			return trainingTo;
		}
		public void setTrainingTo(String trainingTo) {
			this.trainingTo = trainingTo;
		}
		@Override
		public String toString() {
			return "EmployeeTrainingDetails [employeeTrainingId=" + employeeTrainingId + ", trainingCategory="
					+ trainingCategory + ", purpose=" + purpose + ", trainingFrom=" + trainingFrom + ", trainingTo="
					+ trainingTo + "]";
		} 
		

}
