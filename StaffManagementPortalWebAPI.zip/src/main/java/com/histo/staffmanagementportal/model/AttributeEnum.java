package com.histo.staffmanagementportal.model;

public enum AttributeEnum {

	INDIA_HR("IndiaHR"),
	INDIA_ADMIN("IndiaAdmin"),
	US_HR("USHR"),
	US_ADMIN("USAdmin"),
	INDIA_REQUEST_APPROVER("IndiaRequestApproverCC");

private String value;
	
	public String getValue() {
		return value;
	}

	AttributeEnum(String value) {
		this.value = value;
	}
}
