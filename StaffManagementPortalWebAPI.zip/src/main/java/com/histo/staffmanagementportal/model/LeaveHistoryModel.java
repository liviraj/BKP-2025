package com.histo.staffmanagementportal.model;

public class LeaveHistoryModel {

	private Integer leaveRequestId;
	private String leaveDate;
	private String fullOrHalfDay;
	private String reviewedOn;
	private String reviewedBy;
	private String approvalStatus;
	private String leaveType;
	private String approverComments;
	private String shortAppComments;
	private String paidOrLossOfPay;
	private String fromDate;
	private String toDate;
	private String remarks;
	private String leaveFromForH;
	private String leaveToForH;
	
	public LeaveHistoryModel() {
	}

	public Integer getLeaveRequestId() {
		return leaveRequestId;
	}

	public void setLeaveRequestId(Integer leaveRequestId) {
		this.leaveRequestId = leaveRequestId;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getLeaveFromForH() {
		return leaveFromForH;
	}

	public void setLeaveFromForH(String leaveFromForH) {
		this.leaveFromForH = leaveFromForH;
	}

	public String getLeaveToForH() {
		return leaveToForH;
	}

	public void setLeaveToForH(String leaveToForH) {
		this.leaveToForH = leaveToForH;
	}

	public String getLeaveDate() {
		return leaveDate;
	}

	public void setLeaveDate(String leaveDate) {
		this.leaveDate = leaveDate;
	}

	public String getFullOrHalfDay() {
		return fullOrHalfDay;
	}

	public void setFullOrHalfDay(String fullOrHalfDay) {
		this.fullOrHalfDay = fullOrHalfDay;
	}

	public String getReviewedOn() {
		return reviewedOn;
	}

	public void setReviewedOn(String reviewedOn) {
		this.reviewedOn = reviewedOn;
	}

	public String getReviewedBy() {
		return reviewedBy;
	}

	public void setReviewedBy(String reviewedBy) {
		this.reviewedBy = reviewedBy;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public String getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

	public String getApproverComments() {
		return approverComments;
	}

	public void setApproverComments(String approverComments) {
		this.approverComments = approverComments;
	}

	public String getShortAppComments() {
		return shortAppComments;
	}

	public void setShortAppComments(String shortAppComments) {
		this.shortAppComments = shortAppComments;
	}

	public String getPaidOrLossOfPay() {
		return paidOrLossOfPay;
	}

	public void setPaidOrLossOfPay(String paidOrLossOfPay) {
		this.paidOrLossOfPay = paidOrLossOfPay;
	}

}
