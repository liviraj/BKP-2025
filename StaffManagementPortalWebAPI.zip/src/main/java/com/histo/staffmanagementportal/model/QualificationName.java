package com.histo.staffmanagementportal.model;

public class QualificationName {

	private Integer qualificationId;
	private String qualificationName;
	
	public QualificationName() {
		super();
	}
	public Integer getQualificationId() {
		return qualificationId;
	}
	public void setQualificationId(Integer qualificationId) {
		this.qualificationId = qualificationId;
	}
	public String getQualificationName() {
		return qualificationName;
	}
	public void setQualificationName(String qualificationName) {
		this.qualificationName = qualificationName;
	}

	
	
}
