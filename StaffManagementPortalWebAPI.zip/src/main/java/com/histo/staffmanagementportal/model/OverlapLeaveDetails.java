package com.histo.staffmanagementportal.model;

import lombok.*;

import java.time.Instant;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class OverlapLeaveDetails {

    private Instant leaveDate;
    private String	fullOrHalfDay;
    private Integer typeOfLeave;

}
