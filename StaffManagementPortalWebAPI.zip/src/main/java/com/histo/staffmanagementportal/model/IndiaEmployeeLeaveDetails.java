package com.histo.staffmanagementportal.model;

public class IndiaEmployeeLeaveDetails extends EmployeeLastLeaveDetails{

    private LeaveDetails casualLeaveDetails;
    
	public IndiaEmployeeLeaveDetails() {
		super();
	}

	public IndiaEmployeeLeaveDetails( LastLeaveAvailed lastLeaveAvailed, LeaveDetails sickLeaveDetails
			,LeaveDetails vacationLeaveDetails, LeaveDetails casualLeaveDetails) {
		super(lastLeaveAvailed,sickLeaveDetails,vacationLeaveDetails);
		this.casualLeaveDetails = casualLeaveDetails;
	}

	public LeaveDetails getCasualLeaveDetails() {
		return casualLeaveDetails;
	}

	public void setCasualLeaveDetails(LeaveDetails casualLeaveDetails) {
		this.casualLeaveDetails = casualLeaveDetails;
	}
    
    
}
