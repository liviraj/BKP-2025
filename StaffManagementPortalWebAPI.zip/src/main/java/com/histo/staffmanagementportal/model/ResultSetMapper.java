package com.histo.staffmanagementportal.model;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

public class ResultSetMapper implements RowMapper<Object> {
	private static final Logger logger = LogManager.getLogger(ResultSetMapper.class);
	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		List<String> columnNames = new ArrayList<>();
		Map<String, String> reports = new HashMap<>();
		ResultSetMetaData rsmd = rs.getMetaData();
		int columnCount = rsmd.getColumnCount();
		for (int i = 1; i <= columnCount; i++) {
			String columnName = rsmd.getColumnName(i);
			columnNames.add(columnName);
		}
		columnNames.stream().forEach(column -> {
			try {
				reports.put(column,rs.getString(column));
			} catch (SQLException e) {
				logger.error("ResultSetMapper {}",e);
			}
		});
		return reports;
	}

}
