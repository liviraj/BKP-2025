package com.histo.staffmanagementportal.model;

public record LeaveDetailsRecord(Integer leaveRequestDetailsId,String date,String leavePeriod,String status,String approvalStatus) {

}
