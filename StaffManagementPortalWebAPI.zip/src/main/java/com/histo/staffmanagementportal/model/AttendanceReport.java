package com.histo.staffmanagementportal.model;

import lombok.Data;

import java.util.List;

@Data
public class AttendanceReport {

    Object attendanceAndLeaveReportsDate;
    List<Object> attendanceReports;
}
