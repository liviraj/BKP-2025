package com.histo.staffmanagementportal.model;

public class RoleNames {

	private Integer roleId;
	private String roleName;
	public RoleNames() {
		super();
	}
	public RoleNames(Integer roleId, String roleName) {
		this.roleId = roleId;
		this.roleName = roleName;
	}
	public Integer getId() {
		return roleId;
	}
	public void setId(Integer roleId) {
		this.roleId = roleId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	
	
}
