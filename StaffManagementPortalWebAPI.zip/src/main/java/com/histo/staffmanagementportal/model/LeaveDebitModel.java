package com.histo.staffmanagementportal.model;

import java.time.Instant;

public class LeaveDebitModel {

	 private Integer employeeId; 
	 private Instant entryDate; 
	 private Double debitDays;  
	 private String comments ;  
	 private Integer leaveTypeId;
	 private Integer leaveEnteredBy;
	 private boolean isLossofPay;
	 private String approvedOn;
	
	public LeaveDebitModel() {
		super();
	}

	public String getApprovedOn() {
		return approvedOn;
	}

	public void setApprovedOn(String approvedOn) {
		this.approvedOn = approvedOn;
	}

	public void setLossofPay(boolean isLossofPay) {
		this.isLossofPay = isLossofPay;
	}

	public Integer getLeaveEnteredBy() {
		return leaveEnteredBy;
	}

	public boolean getIsLossofPay() {
		return isLossofPay;
	}

	public void setIsLossofPay(boolean isLossofPay) {
		this.isLossofPay = isLossofPay;
	}

	public void setLeaveEnteredBy(Integer leaveEnteredBy) {
		this.leaveEnteredBy = leaveEnteredBy;
	}

	public Integer getLeaveTypeId() {
		return leaveTypeId;
	}

	public void setLeaveTypeId(Integer leaveTypeId) {
		this.leaveTypeId = leaveTypeId;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public Instant getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(Instant entryDate) {
		this.entryDate = entryDate;
	}

	public Double getDebitDays() {
		return debitDays;
	}

	public void setDebitDays(Double debitDays) {
		this.debitDays = debitDays;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}
	@Override
	public String toString() {
		return "LeaveDebitModel [employeeId=" + employeeId + ", entryDate=" + entryDate + ", debitDays=" + debitDays
				+ ", comments=" + comments + ", leaveTypeId=" + leaveTypeId
				+ "]";
	}

}
