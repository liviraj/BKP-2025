package com.histo.staffmanagementportal.model;

public class EmailLeaveRequestDetail {

	public String section;
	public String leaveFrom;
	public String leaveType;
	public String purpose;
	public String remarks;
	public double noOfDaysRequested;
	public double noOfDaysRejected;
	public double noOfDaysApproved;
	public String dayOfJoining;
	public double sickLeaveBalance;
	public double casualLeaveBalance;
	public double vacationLeaveBalance;
	public String requestedDate;
	public String employeeName;
	public String reviewerName;
	public Integer requestId;
	public double noOfDaysCancelled;
	public String status;
	
	public EmailLeaveRequestDetail() {
	
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public double getNoOfDaysCancelled() {
		return noOfDaysCancelled;
	}

	public void setNoOfDaysCancelled(double noOfDaysCancelled) {
		this.noOfDaysCancelled = noOfDaysCancelled;
	}

	public Integer getRequestId() {
		return requestId;
	}

	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}

	public String getReviewerName() {
		return reviewerName;
	}

	public void setReviewerName(String reviewerName) {
		this.reviewerName = reviewerName;
	}

	public double getNoOfDaysRejected() {
		return noOfDaysRejected;
	}

	public void setNoOfDaysRejected(double noOfDaysRejected) {
		this.noOfDaysRejected = noOfDaysRejected;
	}

	public double getNoOfDaysApproved() {
		return noOfDaysApproved;
	}

	public void setNoOfDaysApproved(double noOfDaysApproved) {
		this.noOfDaysApproved = noOfDaysApproved;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getRequestedDate() {
		return requestedDate;
	}

	public void setRequestedDate(String requestedDate) {
		this.requestedDate = requestedDate;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public String getLeaveFrom() {
		return leaveFrom;
	}

	public void setLeaveFrom(String leaveFrom) {
		this.leaveFrom = leaveFrom;
	}

	public String getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public double getNoOfDaysRequested() {
		return noOfDaysRequested;
	}

	public void setNoOfDaysRequested(double noOfDaysApplied) {
		this.noOfDaysRequested = noOfDaysApplied;
	}

	public String getDayOfJoining() {
		return dayOfJoining;
	}

	public void setDayOfJoining(String dayOfJoining) {
		this.dayOfJoining = dayOfJoining;
	}

	public double getSickLeaveBalance() {
		return sickLeaveBalance;
	}

	public void setSickLeaveBalance(double sickLeaveBalance) {
		this.sickLeaveBalance = sickLeaveBalance;
	}

	public double getCasualLeaveBalance() {
		return casualLeaveBalance;
	}

	public void setCasualLeaveBalance(double casualLeaveBalance) {
		this.casualLeaveBalance = casualLeaveBalance;
	}

	public double getVacationLeaveBalance() {
		return vacationLeaveBalance;
	}

	public void setVacationLeaveBalance(double vacationLeaveBalance) {
		this.vacationLeaveBalance = vacationLeaveBalance;
	}
		 
}
