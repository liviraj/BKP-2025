package com.histo.staffmanagementportal.model;

public class LocationFilter {

	private Integer locationId;
	private String locationCountry;
	
	public LocationFilter() {
		super();
	}
	public LocationFilter(Integer locationId, String locationName) {
		this.locationId = locationId;
		this.locationCountry = locationName;
	}
	public Integer getLocationId() {
		return locationId;
	}
	public void setLocationId(Integer locationId) {
		this.locationId = locationId;
	}
	public String getLocationCountry() {
		return locationCountry;
	}
	public void setLocationCountry(String locationName) {
		this.locationCountry = locationName;
	}
	
}
