package com.histo.staffmanagementportal.model;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.histo.staffmanagementportal.exception.ExceptionBean;

@Component("response")
@JsonFilter("EmployeeResponseFilter")
public class ResponseModel {
	private boolean status;
    private ExceptionBean information;
    private Object data;
    private String message;
    private EmailContent emailContent;
    private EmailLeaveRequestDetail emailLeaveRequestDetail;
    
	public ResponseModel() {
		super();
	}

	public EmailLeaveRequestDetail getEmailLeaveRequestDetail() {
		return emailLeaveRequestDetail;
	}

	public void setEmailLeaveRequestDetail(EmailLeaveRequestDetail emailLeaveRequestDetail) {
		this.emailLeaveRequestDetail = emailLeaveRequestDetail;
	}

	public Object getData() {
		return data;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public EmailContent getEmailContent() {
		return emailContent;
	}

	public void setEmailContent(EmailContent emailContent) {
		this.emailContent = emailContent;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public boolean isStatus() {
		return status;
	}
	
	public void setStatus(boolean status) {
		this.status = status;
	}

	public ExceptionBean getInformation() {
		return information;
	}
	public void setInformation(ExceptionBean information) {
		this.information = information;
	}    
    
}
