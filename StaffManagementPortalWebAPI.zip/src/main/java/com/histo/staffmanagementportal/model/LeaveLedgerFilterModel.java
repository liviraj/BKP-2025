package com.histo.staffmanagementportal.model;

public class LeaveLedgerFilterModel {
    private Integer locationId;
    private Integer employeeId;
    private String employmentStatus;
    private String fromDate;
    private String toDate;
    private String leaveType;
    private String year;

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

	public Integer getLocationId() {
        return locationId;
    }

    public void setLocationId(Integer locationId) {
        this.locationId = locationId;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmploymentStatus() {
        return employmentStatus;
    }

    public void setEmploymentStatus(String employmentStatus) {
        this.employmentStatus = employmentStatus;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    @Override
    public String toString() {
        return "LeaveLedgerFilterModel{" +
                "locationId=" + locationId +
                ", employeeId=" + employeeId +
                ", statusId=" + employmentStatus +
                ", fromDate=" + fromDate +
                ", toDate=" + toDate +
                '}';
    }
}
