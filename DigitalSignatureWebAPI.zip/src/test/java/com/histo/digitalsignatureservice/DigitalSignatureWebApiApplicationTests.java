package com.histo.digitalsignatureservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalSignatureWebApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
