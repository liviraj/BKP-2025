package com.histo.digitalsignatureservice.configuration;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:application.properties")
@Getter
@Setter
@ToString
public class PropertyConfiguration {
    @Value("${adobe.code}")
    private String adobeCode;
    @Value("${api_access_point}")
    private String apiAccessPoint;
    @Value("${refresh_token}")
    private String refreshToken;
    @Value("${client_id}")
    private String clientId;
    @Value("${client_secret}")
    private String clientSecret;
	@Value("${esign.wait.seconds.three-mb}")
	private Integer threeMbSeconds;
	@Value("${esign.wait.seconds.two-mb}")
	private Integer twoMbSeconds;
	@Value("${esign.wait.seconds.one-mb}")
	private Integer oneMbSeconds;
	@Value("${esign.wait.seconds.half-mb}")
	private Integer halfMbSeconds;
	@Value("${esign.wait.seconds.one-fourth-mb}")
	private Integer oneFourthMbSeconds;
	@Value("${esign.wait.seconds.below.one-fourth-mb}")
	private Integer belowOneFourthSeconds;
	@Value("${esign.wait.seconds.default}")
	private Integer defaultSeconds;
	@Value("${esign.call-singin-url.retry.in-milleseconds}")
	private int reTryInterval;
	@Value("${esign.call-siginin-url.max-retry}")
	private int maxRetryCount;

}
