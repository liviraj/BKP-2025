package com.histo.digitalsignatureservice.configuration;

import io.swagger.v3.oas.models.OpenAPI;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import io.swagger.v3.oas.models.servers.Server;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.info.Info;

import java.util.List;

@Configuration
public class OpenAPISwagger3Config {
    @Bean
    public OpenAPI myOpenAPI() {
        Contact contact = new Contact();
        contact.setEmail("support@histogenetics.com");
        contact.setName("Histogenetics");
        contact.setUrl("https://www.histogenetics.com");

        License mitLicense = new License().name("MIT License").url("https://choosealicense.com/licenses/mit/");

        Info info = new Info()
                .title("Digital Signature API")
                .version("1.0.0")
                .contact(contact)
                .description("This API exposes endpoints to sign the PDF doc.").termsOfService("https://www.histogenetics.com")
                .license(mitLicense);

        return new OpenAPI().info(info);
    }
}
