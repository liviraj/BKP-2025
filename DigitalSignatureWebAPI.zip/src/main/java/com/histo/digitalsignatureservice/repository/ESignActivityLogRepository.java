package com.histo.digitalsignatureservice.repository;

import com.histo.digitalsignatureservice.entity.ESignActivityLog;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ESignActivityLogRepository extends JpaRepository<ESignActivityLog, Long> {
}