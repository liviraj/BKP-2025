package com.histo.digitalsignatureservice.filter;

import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import com.histo.digitalsignatureservice.model.response.DownloadResponse;
import com.histo.digitalsignatureservice.model.response.ErrorResponse;
import com.histo.digitalsignatureservice.model.response.UploadResponse;
import org.springframework.http.converter.json.MappingJacksonValue;

public class ResponseFilter {
    public static MappingJacksonValue responseUploadFilter(UploadResponse response, String[] fields) {
        SimpleBeanPropertyFilter propertyFilter = SimpleBeanPropertyFilter.filterOutAllExcept(fields);
        FilterProvider filterProvider = new SimpleFilterProvider().addFilter("UploadResponse", propertyFilter);
        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(response);
        mappingJacksonValue.setFilters(filterProvider);
        return mappingJacksonValue;
    }

    /*TODO: Need to handle error response. Create one method and one class and return the MappingJacksonValue
        Status, code, Message
     */
    public static MappingJacksonValue responseErrorFilter(ErrorResponse errorResponse, String[] fields) {
        SimpleBeanPropertyFilter propertyFilter = SimpleBeanPropertyFilter.filterOutAllExcept(fields);
        FilterProvider filterProvider = new SimpleFilterProvider().addFilter("UploadResponse", propertyFilter);
        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(errorResponse);
        mappingJacksonValue.setFilters(filterProvider);
        return mappingJacksonValue;
    }

    public static MappingJacksonValue responseDownloadErrorFilter(ErrorResponse errorResponse, String[] fields) {
        SimpleBeanPropertyFilter propertyFilter = SimpleBeanPropertyFilter.filterOutAllExcept(fields);
        FilterProvider filterProvider = new SimpleFilterProvider().addFilter("DownloadResponse", propertyFilter);
        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(errorResponse);
        mappingJacksonValue.setFilters(filterProvider);
        return mappingJacksonValue;
    }

    public static MappingJacksonValue responseDownloadURLFilter(DownloadResponse response, String[] fields) {
        SimpleBeanPropertyFilter propertyFilter = SimpleBeanPropertyFilter.filterOutAllExcept(fields);
        FilterProvider filterProvider = new SimpleFilterProvider().addFilter("UploadResponse", propertyFilter);
        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(response);
        mappingJacksonValue.setFilters(filterProvider);
        return mappingJacksonValue;
    }
}
