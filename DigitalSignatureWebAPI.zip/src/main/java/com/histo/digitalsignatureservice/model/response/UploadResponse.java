package com.histo.digitalsignatureservice.model.response;

import com.histo.digitalsignatureservice.adoberesmodel.AggrementResponse;
import com.histo.digitalsignatureservice.adoberesmodel.RootSigninUrl;
import com.histo.digitalsignatureservice.adoberesmodel.TransientDocumentResponse;
import lombok.Getter;


public class UploadResponse {
    private boolean status;
    private TransientDocumentResponse transientDocumentResponse;
    private AggrementResponse aggrementResponse;
    private RootSigninUrl rootSigninUrl;

    public UploadResponse(boolean status, TransientDocumentResponse transientDocumentResponse, AggrementResponse aggrementResponse, RootSigninUrl rootSigninUrl) {
        this.status = status;
        this.transientDocumentResponse = transientDocumentResponse;
        this.aggrementResponse = aggrementResponse;
        this.rootSigninUrl = rootSigninUrl;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public void setTransientDocumentResponse(TransientDocumentResponse transientDocumentResponse) {
        this.transientDocumentResponse = transientDocumentResponse;
    }

    public void setAggrementResponse(AggrementResponse aggrementResponse) {
        this.aggrementResponse = aggrementResponse;
    }

    public void setRootSigninUrl(RootSigninUrl rootSigninUrl) {
        this.rootSigninUrl = rootSigninUrl;
    }

	public boolean isStatus() {
		return status;
	}

	public TransientDocumentResponse getTransientDocumentResponse() {
		return transientDocumentResponse;
	}

	public AggrementResponse getAggrementResponse() {
		return aggrementResponse;
	}

	public RootSigninUrl getRootSigninUrl() {
		return rootSigninUrl;
	}
    
    
}
