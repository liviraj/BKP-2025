package com.histo.digitalsignatureservice.adoberesmodel;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import lombok.Getter;

@Getter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)

public class SigningUrl {
    private String email;
    private String esignUrl;

    public void setEmail(String email) {
        this.email = email;
    }

    public void setEsignUrl(String esignUrl) {
        this.esignUrl = esignUrl;
    }

	public String getEmail() {
		return email;
	}

	public String getEsignUrl() {
		return esignUrl;
	}
    
    
}
