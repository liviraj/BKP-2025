package com.histo.digitalsignatureservice.adoberesmodel;



import java.util.ArrayList;


public class RootSigninUrl {
    private ArrayList<SigningUrlSetInfo> signingUrlSetInfos;

    public void setSigningUrlSetInfos(ArrayList<SigningUrlSetInfo> signingUrlSetInfos) {
        this.signingUrlSetInfos = signingUrlSetInfos;
    }

	public ArrayList<SigningUrlSetInfo> getSigningUrlSetInfos() {
		return signingUrlSetInfos;
	}
    
    
}
