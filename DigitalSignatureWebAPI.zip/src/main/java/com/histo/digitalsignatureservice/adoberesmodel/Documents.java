package com.histo.digitalsignatureservice.adoberesmodel;

import java.util.List;

public class Documents {
    private List<Document> documents;

	public List<Document> getDocuments() {
		return documents;
	}

	public void setDocuments(List<Document> documents) {
		this.documents = documents;
	}
    
    
}
