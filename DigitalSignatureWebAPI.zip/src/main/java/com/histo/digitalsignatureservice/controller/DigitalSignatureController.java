package com.histo.digitalsignatureservice.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.histo.digitalsignatureservice.model.request.UploadDocument;
import com.histo.digitalsignatureservice.service.AdobeDigitalSignature;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;


@RestController
@RequestMapping("/digitalSignature")
public class DigitalSignatureController {
    @Autowired
    AdobeDigitalSignature adobeDigitalSignature;


    @GetMapping("/downloadFile")
    public ResponseEntity<Object> getDocument(@RequestParam("agreementId") String agreementId) throws IOException
            // https://stackoverflow.com/questions/73071773/how-to-fix-java-lang-classnotfoundexception-org-springframework-boot-configurat
            , JSONException {
        return adobeDigitalSignature.downloadDocument(agreementId);

    }

    /*
    for docInfoJson below information required.
    agreement name, role, email, filename, isNotificaitonRequired, if yes, get notificationEmail
     */
    @PostMapping(value = "/uploadFile", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    public ResponseEntity<Object> uploadFile(@RequestPart("docInfoJson") String docInfoJson
            , @RequestParam("file") MultipartFile file) throws JSONException, IOException, InterruptedException { // To Choose multiple file -  List<MultipartFile> file
        UploadDocument uploadDocument = new ObjectMapper().readValue(docInfoJson, UploadDocument.class);
        return adobeDigitalSignature.uploadDocument(file, uploadDocument);
    }
}

