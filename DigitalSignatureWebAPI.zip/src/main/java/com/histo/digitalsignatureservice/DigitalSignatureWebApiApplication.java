package com.histo.digitalsignatureservice;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@OpenAPIDefinition(servers = {@Server(url = "/", description = "Default Server URL")})
@OpenAPIDefinition(
        servers = {
                @Server(url = "https://histoasgqc01.histogenetics.com:9180/DigitalSignatureWebAPI", description = "UAT Server"),
                @Server(url = "https://10.201.23.69:9180/DigitalSignatureWebAPI", description = "UAT Server in IP"),
                @Server(url = "http://localhost:8080", description = "Local Server"),
                @Server(url = "http://localhost:9001", description = "Local Server"),
                @Server(url = "http://10.202.21.33:8080", description = "Local Server"),
                @Server(url = "http://10.201.23.163:8080", description = "Dev Server"),
                @Server(url = "http://10.201.100.32:8080", description = "India Dev Server"),
                @Server(url = "https://histojavag01.histogenetics.com:9180/DigitalSignatureWebAPI", description = "PROD Server"),
                @Server(url = "http://histojavag01:9180/DigitalSignatureWebAPI", description = "PROD Server without http"),
                @Server(url = "https://histojavag01.histogenetics.com:8446/DigitalSignatureWebAPI", description = "PROD Server"),
                @Server(url = "http://histojavag01:8446/DigitalSignatureWebAPI", description = "PROD Server without http")
        }
)
@SpringBootApplication
public class DigitalSignatureWebApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(DigitalSignatureWebApiApplication.class, args);
    }

}
