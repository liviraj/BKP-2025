package com.histo.digitalsignatureservice.adobereqmodel;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class AgreementRequest {
    private List<FileInfo> fileInfos;
    private String name;
    private String sendType;
    private List<ParticipantSetsInfo> participantSetsInfo;
    private String signatureType;
    private ExternalId externalId;
    private String state;
    //private String expirationTime;
    private EmailOption emailOption;
    private SecurityOption securityOption;

    public AgreementRequest(List<FileInfo> fileInfos, String name, String sendType, List<ParticipantSetsInfo> participantSetsInfo, String signatureType, ExternalId externalId, String state) {
        this.fileInfos = fileInfos;
        this.name = name;
        this.sendType = sendType;
        this.participantSetsInfo = participantSetsInfo;
        this.signatureType = signatureType;
        this.externalId = externalId;
        this.state = state;
        //this.expirationTime = Instant.now().toString();
        this.emailOption = new EmailOption();
    }

    public AgreementRequest(List<FileInfo> fileInfos, String name, String sendType, List<ParticipantSetsInfo> participantSetsInfo, String signatureType, ExternalId externalId, String state
            , SecurityOption securityOption) {
        this.fileInfos = fileInfos;
        this.name = name;
        this.sendType = sendType;
        this.participantSetsInfo = participantSetsInfo;
        this.signatureType = signatureType;
        this.externalId = externalId;
        this.state = state;
        //this.expirationTime = Instant.now().toString();
        this.emailOption = new EmailOption();
        this.securityOption = securityOption;
    }
}
