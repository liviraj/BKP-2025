package com.histo.digitalsignatureservice.adobereqmodel;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class SecurityOption {
    private String openPassword;
    private ContentProtectionPreference contentProtectionPreference;
}
