package com.histo.digitalsignatureservice.adobereqmodel;



public class SendOptions {
    private String completionEmails;
    private String inFlightEmails;
    private String initEmails;
    public SendOptions() {
        completionEmails= "NONE";
        inFlightEmails= "NONE";
        initEmails= "NONE";
    }
	public String getCompletionEmails() {
		return completionEmails;
	}
	public void setCompletionEmails(String completionEmails) {
		this.completionEmails = completionEmails;
	}
	public String getInFlightEmails() {
		return inFlightEmails;
	}
	public void setInFlightEmails(String inFlightEmails) {
		this.inFlightEmails = inFlightEmails;
	}
	public String getInitEmails() {
		return initEmails;
	}
	public void setInitEmails(String initEmails) {
		this.initEmails = initEmails;
	}
    
    
}
