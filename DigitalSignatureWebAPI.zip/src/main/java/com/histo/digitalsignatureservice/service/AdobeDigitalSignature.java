package com.histo.digitalsignatureservice.service;

import com.google.gson.Gson;
import com.histo.digitalsignatureservice.adobereqmodel.*;
import com.histo.digitalsignatureservice.adoberesmodel.*;
import com.histo.digitalsignatureservice.configuration.PropertyConfiguration;
import com.histo.digitalsignatureservice.connection.ConnectionURLParams;
import com.histo.digitalsignatureservice.entity.ESignActivityLog;
import com.histo.digitalsignatureservice.filter.ResponseFilter;
import com.histo.digitalsignatureservice.model.request.UploadDocument;
import com.histo.digitalsignatureservice.model.response.DownloadResponse;
import com.histo.digitalsignatureservice.model.response.ErrorResponse;
import com.histo.digitalsignatureservice.model.response.UploadResponse;
import com.histo.digitalsignatureservice.repository.ESignActivityLogRepository;
import okhttp3.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Service
public class AdobeDigitalSignature {
    private static final Logger LOGGER = LogManager.getLogger(AdobeDigitalSignature.class);
    private final PropertyConfiguration propertyConfiguration;
    private final AdobeInitializer adobeInitializer;
    private MappingJacksonValue mappingJacksonValue;
    private static final String EVENT_TYPE = "ACTION_COMPLETED";
    private static final String EVENT_TYPE_HOSTED = "ACTION_COMPLETED_HOSTED";

    private final ESignActivityLogRepository eSignActivityLogRepository;

    public AdobeDigitalSignature(PropertyConfiguration propertyConfiguration, AdobeInitializer adobeInitializer, ESignActivityLogRepository eSignActivityLogRepository) {
        this.propertyConfiguration = propertyConfiguration;
        this.adobeInitializer = adobeInitializer;
        this.eSignActivityLogRepository = eSignActivityLogRepository;
    }

    /*
    1. First call the adobe service to get the access token
    2. Call the transient enpoint to upload the document
    3. Call the agreement service to get the agreement id
    4. Call the signingurl to get the url and send to caller
     */
    public synchronized ResponseEntity<Object> uploadDocument(MultipartFile file, UploadDocument uploadDocument) throws IOException, JSONException, InterruptedException {
        Response response = null;
        String aggrementId = null;
        try {
            RequestBody requestBody;
            Request request;

            String jsonString;

            LOGGER.info("E-Sign process start...");
            response = adobeInitializer.getAccessToken();

            if (response.code() != 200 && response.code() != 201) {
                LOGGER.debug("uploadDocument() Error. Exception in getAccessToken method : Message {}. URL: {}", response.message());
                ErrorResponse errorResponse = new ErrorResponse(response.code(), "Exception in getAccessToken method : Message :" + response.message());
                mappingJacksonValue = ResponseFilter.responseErrorFilter(errorResponse, new String[]{"status", "uploadResponse"});

                insertEsignActivityLog(file, uploadDocument, response.message(), String.valueOf(response.code()), "");

                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.valueOf(response.code()));
            }

            LOGGER.info("Access token get successfully.");

            jsonString = response.body().string();
            TokenModel tokenModel = new Gson().fromJson(jsonString, TokenModel.class);
            ConnectionURLParams connectionURLParams = new ConnectionURLParams();

            String url = connectionURLParams.getURLuploadDocument(propertyConfiguration.getApiAccessPoint());

            OkHttpClient client = new OkHttpClient.Builder().connectTimeout(60, TimeUnit.SECONDS)
                    .readTimeout(60, TimeUnit.SECONDS)
                    .writeTimeout(60, TimeUnit.SECONDS)
                    .build();
            //Call the transient document service
            requestBody = new MultipartBody.Builder().setType(MultipartBody.FORM)
                    .addFormDataPart("File", file.getOriginalFilename(), RequestBody.create(file.getBytes(), MediaType.parse("application/pdf")))
                    .build();

            request = new Request.Builder().url(url).addHeader("Content-Type", "multipart/form-data")
                    .addHeader("Authorization", "Bearer " + tokenModel.getAccess_token())
                    .addHeader("Accept", "application/json, text/javascript, */*")
                    .post(requestBody).build();
            response = client.newCall(request).execute();

            if (response.code() != 200 && response.code() != 201) {
                LOGGER.debug("uploadDocument() Error. Exception in getURLuploadDocument method : Message : {}. URL: {}", response.message(), request.url());
                ErrorResponse errorResponse = new ErrorResponse(response.code(), "Exception in getURLuploadDocument method : Message :" + response.message());
                mappingJacksonValue = ResponseFilter.responseErrorFilter(errorResponse, new String[]{"status", "uploadResponse"});

                insertEsignActivityLog(file, uploadDocument, response.message(), String.valueOf(response.code()), "");

                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.valueOf(response.code()));
            }
            LOGGER.info("Docment uploaded successfully. Doc name: {}. Doc upload URL: {}", file.getOriginalFilename(), request.url());

            jsonString = response.body().string();
            TransientDocumentResponse transientDocumentResponse = new Gson().fromJson(jsonString, TransientDocumentResponse.class);
            //Call the Agreement service
            AgreementRequest agreementRequest = constructAgreementRequest(transientDocumentResponse.getTransientDocumentId(), uploadDocument);
            String json = new Gson().toJson(agreementRequest);
            requestBody = RequestBody.create(json, MediaType.parse("application/json"));
            request = new Request.Builder().url(new ConnectionURLParams().getURLAgreementDocument(propertyConfiguration.getApiAccessPoint()))
                    .method("POST", requestBody).addHeader("Content-Type", "application/json")
                    .addHeader("Authorization", "Bearer " + tokenModel.getAccess_token())
                    .addHeader("Accept", "application/json")
                    .build();
            response = client.newCall(request).execute();

            if (response.code() != 200 && response.code() != 201) {
                LOGGER.debug("uploadDocument() Error. Exception in getURLuploadDocument method : Message : {}. URL: {}", response.message(), request.url());
                ErrorResponse errorResponse = new ErrorResponse(response.code(), "Exception in getURLAgreementDocument method : Message :" + response.message());
                mappingJacksonValue = ResponseFilter.responseErrorFilter(errorResponse, new String[]{"status", "uploadResponse"});

                insertEsignActivityLog(file, uploadDocument, response.message(), String.valueOf(response.code()), "");

                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.valueOf(response.code()));
            }

            jsonString = response.body().string();
            AggrementResponse aggrementResponse = new Gson().fromJson(jsonString, AggrementResponse.class);
            aggrementId = aggrementResponse.getId();
            LOGGER.info("Agreement created Successfully. URL: {}.Agreement Id: {}.", request.url(), aggrementResponse.getId());
            //Call the signingurl
            LOGGER.info("******Time*****:" + getMilliSecondBaseOnFile(file));
            LOGGER.info("****** Size *****:" + file.getSize());
            wait(getMilliSecondBaseOnFile(file));
            request = new Request.Builder().url(new ConnectionURLParams().getURLSigningUrls(propertyConfiguration.getApiAccessPoint(), aggrementResponse.getId()))
                    .method("GET", null)
                    .addHeader("Authorization", "Bearer " + tokenModel.getAccess_token())
                    .addHeader("Accept", "application/json")
                    .build();
            response = client.newCall(request).execute();

            if (response.code() != 200 && response.code() != 201) {
                // call sing in URL using functional interface
                response = executeWithRetry(() -> getSignInURL(file, aggrementResponse, tokenModel.getAccess_token()), propertyConfiguration);

                if (response.code() != 200 && response.code() != 201) {
                    LOGGER.debug("uploadDocument() Error. Exception in getURLuploadDocument method : Message : {}. URL: {}",
                            response.message(), request.url());
                    ErrorResponse errorResponse = new ErrorResponse(response.code(),
                            "Exception in getURLSigningUrls method : Message :" + response.message());
                    mappingJacksonValue = ResponseFilter.responseErrorFilter(errorResponse, new String[]{"status", "uploadResponse"});

                    insertEsignActivityLog(file, uploadDocument, response.message(), String.valueOf(response.code()), "");

                    return new ResponseEntity<>(mappingJacksonValue, HttpStatus.valueOf(response.code()));
                }
            }

            LOGGER.info("Sign URL called successfully. URL: {}", request.url());

            jsonString = response.body().string();
            RootSigninUrl rootSigninUrl = new Gson().fromJson(jsonString, RootSigninUrl.class);
            UploadResponse uploadResponse = new UploadResponse(true, transientDocumentResponse, aggrementResponse, rootSigninUrl);
            mappingJacksonValue = ResponseFilter.responseUploadFilter(uploadResponse, new String[]{"status", "uploadResponse"});

            insertEsignActivityLog(file, uploadDocument, response.message(), String.valueOf(response.code()), aggrementResponse.getId());

            LOGGER.info("E-Sign process end...");
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error("Error uploadDocument() - {}", e);
            insertEsignActivityLog(file, uploadDocument, e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), aggrementId);
            Thread.currentThread().interrupt();
            return new ResponseEntity<>("Something Went Wrong", HttpStatus.CONFLICT);
        }
    }

    private Response executeWithRetry(RetryableOperation operation, PropertyConfiguration config) {
        int attempt = 0;
        Response response = null;

        while (attempt < config.getMaxRetryCount()) {
            try {
                attempt++;
                LOGGER.info("Attempt {}", attempt);

                // Execute the operation
                response = operation.execute();

                if (response.code() == 200 || response.code() == 201) {
                    break;
                } else {
                    if (attempt >= config.getMaxRetryCount()) {
                        LOGGER.info("Max retries reached.");
                        break;
                    }
                    Thread.sleep(config.getReTryInterval());
                }
            } catch (Exception e) {
                LOGGER.info("Task failed on attempt {}: {}", attempt, e.getMessage());

                if (attempt >= config.getMaxRetryCount()) {
                    LOGGER.info("Max retries reached.");
                    break;
                }

                try {
                    Thread.sleep(config.getReTryInterval());
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt(); // Restore interrupted state
                    LOGGER.error("Exception: {}", e);
                }
            }
        }
        return response;
    }

    private synchronized Response getSignInURL(MultipartFile file, AggrementResponse aggrementResponse, String accessToken) throws InterruptedException, IOException {
        Response response = null;
        RequestBody requestBody;
        Request request;
        Thread.sleep(getMilliSecondBaseOnFile(file));
        OkHttpClient client = new OkHttpClient.Builder().connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .build();
        request = new Request.Builder().url(new ConnectionURLParams().getURLSigningUrls(propertyConfiguration.getApiAccessPoint(), aggrementResponse.getId()))
                .method("GET", null)
                .addHeader("Authorization", "Bearer " + accessToken)
                .addHeader("Accept", "application/json")
                .build();
        response = client.newCall(request).execute();
        return response;
    }

    private long getMilliSecondBaseOnFile(MultipartFile file) {
        long fileSize = file.getSize();

        long threeMB = 3500000;
        long twoMB = 2100000;
        long oneMB = 1100000;
        long halfMB = 550000;
        long oneFourthMb = 400000;

        if (threeMB <= fileSize) {
            return propertyConfiguration.getThreeMbSeconds(); // milliseconds
        } else if (twoMB <= fileSize) {
            return propertyConfiguration.getTwoMbSeconds();
        } else if (oneMB <= fileSize) {
            return propertyConfiguration.getOneMbSeconds();
        } else if (halfMB <= fileSize) {
            return propertyConfiguration.getHalfMbSeconds();
        } else if (oneFourthMb <= fileSize) {
            return propertyConfiguration.getOneFourthMbSeconds();
        } else {
            return propertyConfiguration.getDefaultSeconds(); // Default milliseconds
        }

    }

    public synchronized ResponseEntity<Object> downloadDocument(String agreementId) throws IOException, JSONException {
        try {
            LOGGER.info("Document download process start...");
            RequestBody requestBody;
            Request request;
            Response response;
            String jsonString;
            OkHttpClient client = new OkHttpClient();
            response = adobeInitializer.getAccessToken();
            jsonString = response.body().string();
            TokenModel tokenModel = new Gson().fromJson(jsonString, TokenModel.class);
            //Call events api to check signature completed or not. event type should be "ACTION_COMPLETED_HOSTED"
            request = new Request.Builder().url(new ConnectionURLParams().getURLEvents(propertyConfiguration.getApiAccessPoint(), agreementId))
                    .method("GET", null)
                    .addHeader("Authorization", "Bearer " + tokenModel.getAccess_token())
                    .addHeader("Accept", "*/*")
                    .build();
            response = client.newCall(request).execute();

            if (response.code() != 200 && response.code() != 201) {
                LOGGER.debug("downloadDocument() Error. Exception in getting url : Message : {}. URL: {}", response.message(), request.url());
                ErrorResponse errorResponse = new ErrorResponse(response.code(), "Exception in getting url : Message :" + response.message());
                mappingJacksonValue = ResponseFilter.responseErrorFilter(errorResponse, new String[]{"status", "downloadResponse"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.valueOf(response.code()));
            }
            LOGGER.info("Call events api to check signature completed successfully");

            jsonString = response.body().string();
            Events events = new Gson().fromJson(jsonString, Events.class);
            boolean isSigned = false;
            for (Event event : events.getEvents()) {
                if (event.getType().equals(EVENT_TYPE) || event.getType().equals(EVENT_TYPE_HOSTED)) {
                    isSigned = true;
                    break;
                }
            }
            if (!isSigned) {
                LOGGER.info("downloadDocument() Error. The document is not signed yet. Please try to sign again and try");
                ErrorResponse errorResponse = new ErrorResponse(HttpStatus.CONFLICT.value(), "The document is not signed yet. Please try to sign again and try");
                mappingJacksonValue = ResponseFilter.responseDownloadErrorFilter(errorResponse, new String[]{"status", "downloadResponse"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
            }
            request = new Request.Builder().url(new ConnectionURLParams().getURLDocument(propertyConfiguration.getApiAccessPoint(), agreementId))
                    .method("GET", null)
                    .addHeader("Authorization", "Bearer " + tokenModel.getAccess_token())
                    .addHeader("Accept", "*/*")
                    .build();
            response = client.newCall(request).execute();
            jsonString = response.body().string();
            JSONObject jsonObject = new JSONObject(jsonString);
            DownloadResponse downloadResponse = new DownloadResponse(jsonObject.getString("url"));
            mappingJacksonValue = ResponseFilter.responseDownloadURLFilter(downloadResponse, new String[]{"status", "downloadResponse"});
            LOGGER.info("Document download process end.");
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);

        } catch (Exception e) {
            LOGGER.error("Error downloadDocument() - {}", e);
            return null;
        }
    }

    public String getDocument() throws IOException, JSONException {
        OkHttpClient client = new OkHttpClient();
        Request request;
        Response response;
        String jsonString;
        request = new Request.Builder().url("https://api.na4.adobesign.com/api/rest/v6/agreements/CBJCHBCAABAA1Movi8JuEuRFNa5mmMz42pXEboJ6FOcN/combinedDocument/url")
                .method("GET", null)
                .addHeader("Authorization", "Bearer " + "3AAABLblqZhA4Qzq1CGIQtgg5FZJN2rT35NSor25GU_n78DEiLlZtYM6ehHWWC2FUkwQXYZ-2HBZAtXuHfUuYdiVtZGQuryVM")
                .addHeader("Accept", "*/*")
                .build();
        response = client.newCall(request).execute();

        jsonString = response.body().string();
        JSONObject jsonObject = new JSONObject(jsonString);
        return jsonObject.getString("url");
    }

    private AgreementRequest constructAgreementRequest(String transientDocumentId, UploadDocument uploadDocument) {
        List<FileInfo> fileInfos = new ArrayList<>();
        FileInfo fileInfo = new FileInfo(transientDocumentId);
        fileInfos.add(fileInfo);
        List<MemberInfo> memberInfos = new ArrayList<>();
        MemberInfo memberInfo = new MemberInfo(uploadDocument.getEmail());
        memberInfos.add(memberInfo);
        List<ParticipantSetsInfo> participantSetsInfos = new ArrayList<>();
        ParticipantSetsInfo participantSetsInfo = new ParticipantSetsInfo(memberInfos, 1, uploadDocument.getRole());
        participantSetsInfos.add(participantSetsInfo);
        ExternalId externalId = new ExternalId("NA2Account_2");

        AgreementRequest agreementRequest;
        if (uploadDocument.isPasswordRequired()) {
            ContentProtectionPreference contentProtectionPreference = new ContentProtectionPreference();
            SecurityOption securityOption = new SecurityOption(uploadDocument.getPdfPassword(), contentProtectionPreference);
            agreementRequest = new AgreementRequest(fileInfos, uploadDocument.getAgreementName(), "REGULAR_SEND", participantSetsInfos, "ESIGN", externalId, "IN_PROCESS", securityOption);
        } else {
            agreementRequest = new AgreementRequest(fileInfos, uploadDocument.getAgreementName(), "REGULAR_SEND", participantSetsInfos, "ESIGN", externalId, "IN_PROCESS");
        }
        return agreementRequest;
    }

    private void insertEsignActivityLog(MultipartFile file, UploadDocument uploadDocument, String remarks, String status, String aggrementId) {
        ESignActivityLog eSignActivityLog = new ESignActivityLog();
        eSignActivityLog.setRemarks(remarks);
        eSignActivityLog.setApplicationId(uploadDocument.getApplicationId());
        eSignActivityLog.setFileName(file.getOriginalFilename());
        eSignActivityLog.setStatus(status);
        eSignActivityLog.setSampleId(uploadDocument.getSampleId());
        eSignActivityLog.setLoginUserId(uploadDocument.getLoginUserId());
        eSignActivityLog.setRequestDate(new Date());
        eSignActivityLog.setAgreementId(aggrementId);

        eSignActivityLogRepository.save(eSignActivityLog);
    }
}


