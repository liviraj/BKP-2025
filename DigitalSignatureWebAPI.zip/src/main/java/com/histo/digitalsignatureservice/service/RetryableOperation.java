package com.histo.digitalsignatureservice.service;

import okhttp3.Response;

@FunctionalInterface
public interface RetryableOperation {
    Response execute() throws Exception;
}
