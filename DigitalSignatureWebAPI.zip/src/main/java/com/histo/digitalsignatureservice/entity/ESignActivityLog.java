package com.histo.digitalsignatureservice.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Entity
@Table(name = "ESignActivityLog")
@NoArgsConstructor
@Getter
@Setter
@ToString
public class ESignActivityLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ESignActivityLogId")
    private Long eSignActivityLogId;

    @Column(name = "ApplicationId")
    private Integer applicationId;

    @Column(name = "AgreementId", length = 255)
    private String agreementId;

    @Column(name = "FileName", length = 255)
    private String fileName;

    @Column(name = "SampleId")
    private Long sampleId;

    @Column(name = "Status", length = 255)
    private String status;

    @Column(name = "Remarks", columnDefinition = "VARCHAR(MAX)")
    private String remarks;

    @Column(name = "RequestDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date requestDate;

    @Column(name = "LoginUserId")
    private Long loginUserId;
}