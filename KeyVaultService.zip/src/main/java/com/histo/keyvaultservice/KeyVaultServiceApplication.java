package com.histo.keyvaultservice;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@OpenAPIDefinition(
        servers = {
                @Server(url = "https://webapiuat.histogenetics.com:8765/VaultService", description = "UAT Server API Gateway"),
                @Server(url = "https://webapiuat:8800/VaultService", description = "UAT Server native"),
                @Server(url = "http://localhost:8765/VaultService", description = "local Server"),
                @Server(url = "http://localhost:8800/VaultService", description = "local Native Server"),
                @Server(url = "https://javawebag01.histogenetics.com:8765/VaultService", description = "PROD Server API Gateway"),
                @Server(url = "https://javawebag01:8800/VaultService", description = "PROD Server Native"),
                @Server(url = "http://10.201.100.32:8765/VaultService", description = "Local IP API Gateway Server Native"),
                @Server(url = "http://10.201.100.32:8800/VaultService", description = "Local IP Server Native"),
                @Server(url = "http://10.201.23.163:8765/VaultService", description = "Local IP API Gateway Server Native"),
                @Server(url = "http://10.201.23.163:8800/VaultService", description = "Local IP Server Native"),
        }
)
public class KeyVaultServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(KeyVaultServiceApplication.class, args);
    }
}
