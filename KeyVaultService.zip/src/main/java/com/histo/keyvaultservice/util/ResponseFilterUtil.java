package com.histo.keyvaultservice.util;

import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import com.histo.keyvaultservice.model.ResponseModel;
import org.springframework.http.converter.json.MappingJacksonValue;

public class ResponseFilterUtil {
    private ResponseFilterUtil() {
    }

    public static MappingJacksonValue responseFilter(ResponseModel response, String[] fields) {
        SimpleBeanPropertyFilter propertyFilter = SimpleBeanPropertyFilter.filterOutAllExcept(fields);
        FilterProvider filterProvider = new SimpleFilterProvider().addFilter("ResponseModel", propertyFilter);
        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(response);
        mappingJacksonValue.setFilters(filterProvider);
        return mappingJacksonValue;
    }
}