package com.histo.keyvaultservice.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "DataProtectorAPIConsumers")
@Getter
@Setter
@ToString
public class DataProtectorAPIConsumer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ConsumerID", nullable = false)
    private Integer id;

    @Size(max = 100)
    @NotNull
    @Column(name = "LoginName", nullable = false, length = 100)
    private String loginName;

    @Size(max = 100)
    @NotNull
    @Column(name = "Password", nullable = false, length = 100)
    private String password;
}
