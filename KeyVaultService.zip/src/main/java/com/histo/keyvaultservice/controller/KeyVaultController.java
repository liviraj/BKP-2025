package com.histo.keyvaultservice.controller;

import com.histo.keyvaultservice.model.ConsumersModel;
import com.histo.keyvaultservice.service.JWTTokenHandlerService;
import com.histo.keyvaultservice.service.KeyVaultService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/keyvault")
public class KeyVaultController {
    private static final Logger LOGGER = LogManager.getLogger(KeyVaultController.class);

    private final KeyVaultService keyVaultService;
    private final JWTTokenHandlerService jwtTokenHandlerService;

    public KeyVaultController(KeyVaultService keyVaultService, JWTTokenHandlerService jwtTokenHandlerService) {
        this.keyVaultService = keyVaultService;
        this.jwtTokenHandlerService = jwtTokenHandlerService;
    }

    @GetMapping("/secret")
    public ResponseEntity<Object> getSecretByKey(@RequestHeader("Authorization") String token, @RequestParam("key") String key) {
        ResponseEntity<Object> responseEntity = jwtTokenHandlerService.validateToken(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return keyVaultService.getSecretByKey(key);
        }
        return responseEntity;
    }

    // @PostMapping("/secret")
    public ResponseEntity<Object> insertSecret(@RequestBody Map<String, String> secretData) {
        return keyVaultService.insertSecret(secretData);
    }

    @PostMapping("/generateJwt")
    public ResponseEntity<Object> generateJwt(@RequestBody ConsumersModel consumersModel) {
        LOGGER.info("/generateJwt API call. Method: {}. Request Body: {}", HttpMethod.POST, consumersModel.getLoginName());
        return jwtTokenHandlerService.generateJWTToken(consumersModel);
    }
}
