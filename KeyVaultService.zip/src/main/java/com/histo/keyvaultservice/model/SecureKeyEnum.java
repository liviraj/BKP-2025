package com.histo.keyvaultservice.model;

public enum SecureKeyEnum {
    HistoSDBPHISecureKey
}
