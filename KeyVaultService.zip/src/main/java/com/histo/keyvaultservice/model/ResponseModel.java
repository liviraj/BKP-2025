package com.histo.keyvaultservice.model;

import com.fasterxml.jackson.annotation.JsonFilter;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@JsonFilter("ResponseModel")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class ResponseModel {

    private boolean status;
    private InfoResponseModel information;
    private String responseMessage;
    private String encryptData;
    private String decryptData;
    private String jwtToken;
    private String loginName;
    private Integer secKeyId;
    private String fileExtension;
}
