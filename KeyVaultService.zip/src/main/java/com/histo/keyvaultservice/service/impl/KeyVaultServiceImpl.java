package com.histo.keyvaultservice.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.histo.keyvaultservice.config.PropConfig;
import com.histo.keyvaultservice.model.KeyVaultSecret;
import com.histo.keyvaultservice.model.SecureKeyEnum;
import com.histo.keyvaultservice.service.KeyVaultService;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

@Service
public class KeyVaultServiceImpl implements KeyVaultService {
    private static final Logger LOGGER = LogManager.getLogger(KeyVaultServiceImpl.class);

    private final PropConfig propConfig;

    public KeyVaultServiceImpl(PropConfig propConfig) {
        this.propConfig = propConfig;
    }

    @Override
    public ResponseEntity<Object> getSecretByKey(String key) {
        try {
            if (!existsInEnum(key)) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Can't find secret for given key");
            }

            // Convert Enum Name to Corresponding Field Name in PropConfig
            String fieldName = convertEnumToFieldName(SecureKeyEnum.valueOf(key));

            // Use Reflection to Get the Field Value from PropConfig
            Field field = PropConfig.class.getDeclaredField(fieldName);
            field.setAccessible(true);
            String secretKey = (String) field.get(propConfig);

            KeyVaultSecret keyVaultSecret = new KeyVaultSecret();
            keyVaultSecret.setKey(key);
            keyVaultSecret.setSecret(secretKey);
            return ResponseEntity.status(HttpStatus.OK).body(keyVaultSecret);
        } catch (Exception e) {
            LOGGER.error("Error retrieving secret by key", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Something Went Wrong");
        }
    }

    private String convertEnumToFieldName(SecureKeyEnum keyEnum) {
        switch (keyEnum) {
            case HistoSDBPHISecureKey:
                return "histosDBSecureKey";  // Match the exact field name in PropConfig
            default:
                throw new IllegalArgumentException("Unsupported key: " + keyEnum);
        }
    }

    private boolean existsInEnum(String key) {
        try {
            SecureKeyEnum.valueOf(key);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    @Override
    public ResponseEntity<Object> insertSecret(Map<String, String> secretData) {
        /*String url = propConfig.getVautBaseUrl() + "/v1/secret/data/KeyVaultService";
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("data", secretData);

        try {
            HttpHeaders headers = new org.springframework.http.HttpHeaders();
            headers.add("X-Vault-Token", vaultToken);

            HttpEntity<Map<String, Object>> entity =
                    new HttpEntity<>(requestBody, headers);

            restTemplate.postForEntity(url, entity, String.class);

            return new ResponseEntity<>("Secret added successfully", HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>("Failed to add secret", HttpStatus.INTERNAL_SERVER_ERROR);
        }*/
        return null;
    }
}
