package com.histo.keyvaultservice.service;

import com.histo.keyvaultservice.model.ConsumersModel;
import org.springframework.http.ResponseEntity;

public interface JWTTokenHandlerService {
    public ResponseEntity<Object> generateJWTToken(ConsumersModel consumersModel);
    public ResponseEntity<Object> validateToken(String token);
}
