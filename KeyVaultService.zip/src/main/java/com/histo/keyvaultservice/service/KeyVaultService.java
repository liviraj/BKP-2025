package com.histo.keyvaultservice.service;

import com.histo.keyvaultservice.model.KeyVaultSecret;
import org.springframework.http.ResponseEntity;

import java.util.Map;

public interface KeyVaultService {
    public ResponseEntity<Object> getSecretByKey(String key);
    public ResponseEntity<Object> insertSecret(Map<String, String> secretData);
}
