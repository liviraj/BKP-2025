package com.histo.rawdatadeletion.interfaces.impl;

import com.histo.rawdatadeletion.interfaces.FileMover;

public class FileOperationController implements FileMover {
    @Override
    public void transferFolder() {

    }

    @Override
    public void deleteFolder() {

    }
}
