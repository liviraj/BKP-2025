package com.histo.rawdatadeletion.interfaces;

import com.histo.rawdatadeletion.model.CredentialInformation;

import java.io.IOException;

public interface FileMover {



    public void transferFolder();
    public void deleteFolder() throws IOException;
}
