package com.histo.rawdatadeletion.interfaces.impl;

import com.histo.rawdatadeletion.interfaces.FileMover;

public class PacbioFileMover implements FileMover{
//    public PacbioFileMover(ArgsModel argsModel) {
//        super(argsModel);
//
//    }

    @Override
    public void transferFolder() {

    }

    @Override
    public void deleteFolder() {

    }
}
