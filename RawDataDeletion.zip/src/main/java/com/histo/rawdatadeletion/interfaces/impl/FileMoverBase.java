package com.histo.rawdatadeletion.interfaces.impl;

import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import com.histo.rawdatadeletion.config.SMBAuthSetup;
import de.slackspace.openkeepass.KeePassDatabase;
import de.slackspace.openkeepass.domain.Entry;
import de.slackspace.openkeepass.domain.KeePassFile;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;

public class FileMoverBase {
    private static final Logger LOGGER = LogManager.getLogger(FileMoverBase.class.getName());
    private final String SMB_DOMAIN_NAME = "histogenetics.com";

    public FileMoverBase() {
    }

    public DiskShare getClientCredentials(String serverName, String shareName) {
        DiskShare diskShare;
        KeePassFile database = KeePassDatabase
                .getInstance(SMBAuthSetup.keepassFilePath)
                .openDatabase(SMBAuthSetup.keepassPassword);
        Entry entry = database.getEntryByTitle("NASDrive");


        SMBClient client = new SMBClient();
        try {
            Connection connection = client.connect(serverName);
            AuthenticationContext authContextSource = new AuthenticationContext(entry.getUsername(), entry.getPassword().toCharArray(), SMB_DOMAIN_NAME);
            Session session = connection.authenticate(authContextSource);
            diskShare = (DiskShare) session.connectShare(shareName);
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
        return diskShare;
    }
}
