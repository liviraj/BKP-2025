package com.histo.rawdatadeletion.interfaces.impl;

import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.smbj.common.SmbPath;
import com.hierynomus.smbj.share.DiskShare;
import com.histo.rawdatadeletion.connection.controller.ConnectionController;
import com.histo.rawdatadeletion.interfaces.FileMover;
import com.histo.rawdatadeletion.model.DataDeletionLogModels;
import com.histo.rawdatadeletion.model.IlluminaFastQFileErrorModel;
import com.histo.rawdatadeletion.model.IlluminaFastqFilesLocation;
import com.histo.rawdatadeletion.model.IlluminaRawDataDeletionLogUpdateDTO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

public class IlluminaFileMover implements FileMover {
    private static final Logger LOGGER = LogManager.getLogger(IlluminaFileMover.class);
    private ConnectionController connectionController;
    private FileMoverBase fileMoverBase;
    private static final String DOMAIN_NAME = ".histogenetics.com";

    public IlluminaFileMover() {
        fileMoverBase = new FileMoverBase();
        connectionController = new ConnectionController();
    }

    private List<DataDeletionLogModels> getIlluminaRawDataDeletionLogs() {
        //Call the service
        return connectionController.getIlluminaRawDataDeletionLogs();
    }

    private boolean isFastqFilesAvailable(String fileLocation, DiskShare diskShare) {
        fileLocation = fileLocation.replace("\\", "/");
        if (!fileLocation.endsWith("/")) {
            fileLocation = fileLocation + "/";
        }
        try {
            String fastqFullPath = diskShare.getSmbPath().toUncPath().concat("\\").concat(fileLocation);
            boolean isSourceDirExist = diskShare.folderExists(fileLocation);
            if (isSourceDirExist) {
                List<String> files = diskShare.list(fileLocation).stream().filter(fileInfo -> !fileInfo.getFileName().equals(".") && !fileInfo.getFileName().equals(".."))
                        .map(FileIdBothDirectoryInformation::getFileName).collect(Collectors.toList());
                int fileCount = 0;
                if (files.size() >= 2) {
                    for (String file : files) {
                        if (file.contains(".fastq.gz")) {
                            fileCount++;
                        }
                    }
                    if (fileCount >= 2) {
                        return true;
                    } else {
                        LOGGER.error("Mising files and gz file count is " + fileCount + " in path " + fastqFullPath.replace("/", "\\"));
                        return false;
                    }
                } else {
                    LOGGER.error("Source Directory " + fastqFullPath.replace("/", "\\") + " files mising " + files);
                    return false;
                }
            } else {
                LOGGER.error("Source Directory not exists " + fastqFullPath.replace("/", "\\"));
                return false;
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            throw new RuntimeException(e);
        }
    }

    @Override
    public void transferFolder() {

    }

    @Override
    public void deleteFolder() throws IOException {
        DiskShare diskShare = null;
        try {
            List<DataDeletionLogModels> dataDeletionLogModelsList = getIlluminaRawDataDeletionLogs();
            if (dataDeletionLogModelsList.size() > 0) {
                for (DataDeletionLogModels dataDeletionLogModels : dataDeletionLogModelsList) {
                    String sourceBasePath = dataDeletionLogModels.getRawDataPath().replace("\\", "/");
                    List<String> sourcePathSplit = Arrays.stream(sourceBasePath.split("/"))
                            .filter(path -> !path.equalsIgnoreCase(""))
                            .collect(Collectors.toList());
                    String serverName = sourcePathSplit.get(0);
                    String shareName = sourcePathSplit.get(1);

                    sourceBasePath = sourceBasePath.replace("\\", "/");
                    if (!sourceBasePath.contains(DOMAIN_NAME)) {
                        if (serverName.contains(DOMAIN_NAME)) {
                            serverName = serverName.replace(DOMAIN_NAME, "");
                        }
                        sourceBasePath = sourceBasePath.replace(serverName, serverName.concat(DOMAIN_NAME));
                    }
                    if (!serverName.contains(DOMAIN_NAME)) {
                        serverName = serverName.concat(DOMAIN_NAME);
                    }

                    if (diskShare == null) {
                        diskShare = fileMoverBase.getClientCredentials(serverName, shareName);
                    }
                    String smbHostNameSource = diskShare.getSmbPath().getHostname();
                    if (!serverName.equalsIgnoreCase(smbHostNameSource)) {
                        diskShare.close();
                        diskShare = fileMoverBase.getClientCredentials(serverName, shareName);
                    }

                    SmbPath smbPath = diskShare.getSmbPath();

                    if (sourceBasePath.contains(smbPath.toUncPath().replace("\\", "/"))) {

                        sourceBasePath = sourceBasePath
                                .replace(smbPath.toUncPath().replace("\\", "/"), "");

                    }
                    if (sourceBasePath.startsWith("/")) {
                        sourceBasePath = sourceBasePath.replaceFirst("/", "");
                    }

                    boolean isSourceDirExist = diskShare.folderExists(sourceBasePath);
                    String rawDataPath = dataDeletionLogModels.getRawDataPath();
                    String[] splits = rawDataPath.split("\\\\");
                    if (!isSourceDirExist || splits.length < 9) {
                        if (splits.length < 9) {
                            LOGGER.info("Raw data path corrupted and the path is " + dataDeletionLogModels.getRawDataPath());
                        } else {
                            LOGGER.info("Raw data file not available in the path " + dataDeletionLogModels.getRawDataPath());
                        }

                        IlluminaRawDataDeletionLogUpdateDTO illuminaRawDataDeletionLogUpdateDTO = new IlluminaRawDataDeletionLogUpdateDTO();
                        illuminaRawDataDeletionLogUpdateDTO.setExperimentID(dataDeletionLogModels.getExperimentID());
                        illuminaRawDataDeletionLogUpdateDTO.setIsParsedAlready(1);
                        illuminaRawDataDeletionLogUpdateDTO.setIsRawDataAvailable(0);
                        illuminaRawDataDeletionLogUpdateDTO.setExperimentGUIID(dataDeletionLogModels.getExperimentGUID());
                        new ConnectionController().updateIlluminaRawDataDeletionLogs(illuminaRawDataDeletionLogUpdateDTO);
                        continue;
                    }
                    AtomicBoolean isAllFastqFileAvailable = new AtomicBoolean(true);
                    AtomicInteger counter = new AtomicInteger();
                    List<IlluminaFastqFilesLocation> illuminaFastqFilesLocationList = new ConnectionController()
                            .getIlluminaFileLocationLogs(dataDeletionLogModels.getExperimentID());
                    if (illuminaFastqFilesLocationList == null) {
                        LOGGER.error("getIlluminaFileLocationLogs returned null for experiment ID " + dataDeletionLogModels.getExperimentID());
                        continue;
                    }
                    DiskShare fastQFileDiskShare = null;
                    for (IlluminaFastqFilesLocation illuminaFastqFilesLocation : illuminaFastqFilesLocationList) {
                        String fastQBasePath = illuminaFastqFilesLocation.getFileLocation().replace("\\", "/");
                        // String fastQBasePath = "\\\\prodnas01-10.histogenetics.com\\APP_Test\\source\\illumina\\NovaSeqOutput\\PreProcessed\\2022\\11\\A00933\\NS111422_1\\ATBT111722KIR_0100";

                        List<String> fastQPathSplit = Arrays.stream(fastQBasePath.split("/"))
                                .filter(path -> !path.equalsIgnoreCase(""))
                                .collect(Collectors.toList());
                        String fastQServerName = fastQPathSplit.get(0);
                        String fastQShareName = fastQPathSplit.get(1);

                        if (!fastQServerName.toLowerCase().endsWith(DOMAIN_NAME)) {
                            fastQServerName += DOMAIN_NAME;
                        }

                        if (fastQFileDiskShare == null) {
                            fastQFileDiskShare = fileMoverBase.getClientCredentials(fastQServerName, fastQShareName);
                        }
                        String smbHostName = fastQFileDiskShare.getSmbPath().getHostname();
                        if (!fastQServerName.equalsIgnoreCase(smbHostName)) {
                            fastQFileDiskShare.close();
                            fastQFileDiskShare = fileMoverBase.getClientCredentials(fastQServerName, fastQShareName);
                        }


                         String fastQSmbPath = fastQBasePath.replace("//", "").replace(fastQPathSplit.get(0) + "/", "")
                                .replace(fastQPathSplit.get(1) + "/", "");

                        /*if (!fastQBasePath.contains(DOMAIN_NAME)) {
                            if (fastQServerName.contains(DOMAIN_NAME)) {
                                fastQServerName = fastQServerName.replace(DOMAIN_NAME, "");
                            }
                            fastQBasePath = fastQBasePath.replace(fastQServerName, fastQServerName.concat(DOMAIN_NAME));
                        }
                        fastQBasePath = fastQBasePath.replace("\\", "/");
                        if (fastQBasePath.contains(diskShare.getSmbPath().toUncPath().replace("\\", "/"))) {
                            fastQBasePath = fastQBasePath.replace(diskShare.getSmbPath().toUncPath().replace("\\", "/"), "");
                        }*/
                        /*if (fastQBasePath.startsWith("/")) {
                            fastQBasePath = fastQBasePath.replaceFirst("/", "");
                        }*/

                        if (!isFastqFilesAvailable(fastQSmbPath, fastQFileDiskShare)) {
                            isAllFastqFileAvailable.set(false);
                            IlluminaFastqFilesLocation missingFatq = illuminaFastqFilesLocation;
                            LOGGER.error("fileLocation " + illuminaFastqFilesLocation.getFileLocation() + " expected fastq not available");
                            IlluminaFastQFileErrorModel illuminaFastQFileErrorModel = new IlluminaFastQFileErrorModel();
                            illuminaFastQFileErrorModel.setFastQFilePath(missingFatq.getFileLocation());
                            illuminaFastQFileErrorModel.setSampleID(missingFatq.getSampleID());
                            illuminaFastQFileErrorModel.setRawDataDeletionLogID(dataDeletionLogModels.getAutoID());
                            new ConnectionController().postIlluminaErrorFastQLog(illuminaFastQFileErrorModel);
                        }
                        counter.incrementAndGet();
                    }
                    IlluminaRawDataDeletionLogUpdateDTO illuminaRawDataDeletionLogUpdateDTO = new IlluminaRawDataDeletionLogUpdateDTO();
                    illuminaRawDataDeletionLogUpdateDTO.setExperimentID(dataDeletionLogModels.getExperimentID());
                    illuminaRawDataDeletionLogUpdateDTO.setIsParsedAlready(1);
                    illuminaRawDataDeletionLogUpdateDTO.setExperimentGUIID(dataDeletionLogModels.getExperimentGUID());
                    illuminaRawDataDeletionLogUpdateDTO.setIsRawDataAvailable(1);
                    Date date = new Date();
                    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
                    String strDate = formatter.format(date);
                    illuminaRawDataDeletionLogUpdateDTO.setPhysicalDeletionDate(strDate);
                    if (isAllFastqFileAvailable.get()) {
                        LOGGER.info("All the expected Fastq files are available. Raw data is ready for deletion");
                        //delete the raw data file. In case failed to delete, should be handled in the code
                        boolean isFolderExists = diskShare.folderExists(sourceBasePath);
                        try {
                            if (isFolderExists) {
                                //Delete the Raw file
                                LOGGER.info("Start deleting raw data and the path is " + dataDeletionLogModels.getRawDataPath());
                                long start = System.currentTimeMillis();
                                // diskShare.close();
                                deleteSmbFolder(sourceBasePath, diskShare);
                                long end = System.currentTimeMillis();
                                long elapsedTime = (end - start) / 1000;
                                LOGGER.info("Total time taken to delete raw data is " + elapsedTime + " sec");
                                LOGGER.info("End deleting raw data and the path is " + dataDeletionLogModels.getRawDataPath());
                            } else {
                                LOGGER.info("Raw data file not found");
                            }
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                        //Call put service to update IsPhysicallyDeleted	PhysicalDeletionDate	IsFastQFileAvailableforAllSamples, isParsedAlready;
                        illuminaRawDataDeletionLogUpdateDTO.setIsFastQFileAvailableforAllSamples(1);
                        illuminaRawDataDeletionLogUpdateDTO.setIsPhysicallyDeleted(1);
                        new ConnectionController().updateIlluminaRawDataDeletionLogs(illuminaRawDataDeletionLogUpdateDTO);

                    } else {
                        LOGGER.error("Fastq missing raw data location " + dataDeletionLogModels.getRawDataPath());
                        illuminaRawDataDeletionLogUpdateDTO.setIsFastQFileAvailableforAllSamples(0);
                        illuminaRawDataDeletionLogUpdateDTO.setIsPhysicallyDeleted(0);
                        new ConnectionController().updateIlluminaRawDataDeletionLogs(illuminaRawDataDeletionLogUpdateDTO);
                    }

                }
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            System.out.println(e.getMessage());
        }
    }

    private void deleteSmbFolder(String deletePath, DiskShare diskShare) {
        diskShare.rmdir(deletePath, true);
    }
}
