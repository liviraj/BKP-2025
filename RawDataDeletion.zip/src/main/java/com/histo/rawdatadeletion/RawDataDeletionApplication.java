package com.histo.rawdatadeletion;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.histo.rawdatadeletion.connection.controller.ConnectionController;
import com.histo.rawdatadeletion.factory.FileMoveMainFactory;
import com.histo.rawdatadeletion.interfaces.FileMover;
import com.histo.rawdatadeletion.model.ArgsModel;
import de.slackspace.openkeepass.KeePassDatabase;
import de.slackspace.openkeepass.domain.Entry;
import de.slackspace.openkeepass.domain.KeePassFile;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/*
Pass params such as
--Illumina/Pacbio (enum)
--Clinical or Non Clinical
--NeedToDelete
--SourceLocation
--DestinationLocation
--SourceLocationUserName
--SourceLocationPassword
--DestinationLocationUserName
--DestinationLocationPassword
 */
@SpringBootApplication
@EnableScheduling
public class RawDataDeletionApplication implements ApplicationRunner  {
	private static final Logger LOGGER = LogManager.getLogger(RawDataDeletionApplication.class);
	public static void main(String[] args) {
		LoggerContext ctx = (LoggerContext) LogManager.getContext(false);
		ctx.reconfigure();
		SpringApplication.run(RawDataDeletionApplication.class, args);
	}

	@Override
	   public void run(ApplicationArguments arguments) throws Exception {
		ArgsModel argsModel;
		ConnectionController con = new ConnectionController();
		String[] argsList = arguments.getSourceArgs();
		if(argsList[0].equals("--help") || argsList.length == 0) {
			LOGGER.info("Below parameters are mandatory\n ");
			LOGGER.info("--Illumina/Pacbio (enum)\n" +
					"--Clinical or Non Clinical\n" +
					"--NeedToDelete\n" +
					"--SourceServer\n" +
					"--DestinationServer");
			return;
		}
		argsList[0] = argsList[0].replaceAll("[{}]", "");
		argsList = argsList[0].split(",");
		Map<String, String> mapModel = Arrays.asList(argsList).stream().map(arg -> arg.split(":"))
				.filter(arg -> arg.length == 2)
				.collect(Collectors.toMap(arg -> arg[0].trim(), arg -> arg[1].trim()));
		ObjectMapper mapper = new ObjectMapper();
		argsModel = mapper.convertValue(mapModel, ArgsModel.class);
		FileMoveMainFactory fileMoveMainFactory = new FileMoveMainFactory();
		FileMover fileMover = fileMoveMainFactory.CreateFileMover(argsModel);
		if(argsModel.isNeedtoDelete()) {
			fileMover.deleteFolder();
		} else {
			fileMover.transferFolder();
		}
	   }
	 
	 // the below have excecute in cmd
	 // mvn spring-boot:run -Dspring-boot.run.arguments=--argValue=argument1
}
