package com.histo.rawdatadeletion.factory;

import com.histo.rawdatadeletion.interfaces.FileMover;
import com.histo.rawdatadeletion.interfaces.impl.IlluminaFileMover;
import com.histo.rawdatadeletion.interfaces.impl.PacbioFileMover;
import com.histo.rawdatadeletion.model.ArgsModel;
import com.histo.rawdatadeletion.model.MachineName;

public class FileMoveMainFactory {
    public FileMover CreateFileMover(ArgsModel argsModel) {
        if(argsModel.getMachineName() == MachineName.Illumina) {
            //Illumina pipeline
            return new IlluminaFileMover();
        } else if(argsModel.getMachineName() == MachineName.PacBio) {
            //Pacbio Pipeline
            return new PacbioFileMover();
        }
        return null;
    }
}
