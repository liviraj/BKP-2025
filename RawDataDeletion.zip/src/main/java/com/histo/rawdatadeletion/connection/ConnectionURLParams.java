package com.histo.rawdatadeletion.connection;

import com.histo.rawdatadeletion.config.ConnectionURLSetup;

import java.math.BigInteger;

public class ConnectionURLParams {
    public String getIlluminaRawDataDeletionLogsURL() {
        return ConnectionURLSetup.pacbioServiceURL + "/illuminaRawDataDeletionLogs";
    }
    public String getIlluminaInsertErrorLogURL() {
        return ConnectionURLSetup.pacbioServiceURL + "/illuminaRawDataDeletionLogs/insertFastQErrorLog";
    }

    public String getServerCredentialURL(String serverName) {
        return  ConnectionURLSetup.pacbioServiceURL + "/rawDataServerCredentials/" + serverName;
    }
    public String getIlluminaRawDataLocationURL(BigInteger experimentID) {
        return  ConnectionURLSetup.pacbioServiceURL + "/illuminaRawDataDeletionLogs/" + experimentID;
    }
}
