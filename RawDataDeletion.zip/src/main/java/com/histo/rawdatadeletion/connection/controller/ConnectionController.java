package com.histo.rawdatadeletion.connection.controller;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import com.histo.rawdatadeletion.connection.ConnectionIntermittent;
import com.histo.rawdatadeletion.model.*;
import okhttp3.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.lang.reflect.Type;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ConnectionController {
    private static final Logger LOGGER = LogManager.getLogger(ConnectionController.class);
    public CredentialInformation getCredentialInformation(String serverName) {
        try {
            ConnectionIntermittent connection = new ConnectionIntermittent();
            Response response = connection.getCredentialInfo(serverName);
            if (response.code() != 200) {
                LOGGER.debug(response);
                return null;
            }
            Gson gson = new GsonBuilder().setDateFormat("yyyy-mm-dd'T'HH:mm:ss.SSSZ").create();
            String jsonString = response.body().string();
            Type credentialInfo = new TypeToken<CredentialInformation>() {
            }.getType();
            JsonElement jsonElement = new JsonParser().parse(jsonString);
            JsonArray  jsonArray = jsonElement.getAsJsonObject().getAsJsonArray("serverCredentials");
            if(jsonArray.size() > 0) {
                JsonObject jsonObject = jsonArray.get(0).getAsJsonObject();
                String expectedJSON = new Gson().toJson(jsonObject);
                CredentialInformation credentialInformation = gson.fromJson(expectedJSON, credentialInfo);
                return credentialInformation;
            }

            return null;

        } catch (Exception e) {
            LOGGER.error(e);
            e.printStackTrace();
        }
        return null;
    }

    public List<DataDeletionLogModels> getIlluminaRawDataDeletionLogs() {
        try {
            ConnectionIntermittent connection = new ConnectionIntermittent();
            Response response = connection.getIlluminaRawDataDeletionLogs();
            if (response.code() != 200) {
                LOGGER.debug(response);
                return null;
            }
            Gson gson = new GsonBuilder().setDateFormat("yyyy-mm-dd'T'HH:mm:ss.SSSZ").create();
            String jsonString = response.body().string();
            Type dataDeletionType = new TypeToken<ArrayList<DataDeletionLogModels>>() {
            }.getType();
            JsonElement jsonElement = new JsonParser().parse(jsonString);
            JsonArray  jsonArray = jsonElement.getAsJsonObject().getAsJsonArray("dataDeletionLogModels");
            if(jsonArray.size() > 0) {
                String expectedJSON = new Gson().toJson(jsonArray);
                List<DataDeletionLogModels> dataDeletionLogModelsList = gson.fromJson(expectedJSON, dataDeletionType);
                return dataDeletionLogModelsList;
            }
            return null;

        } catch (Exception e) {
            LOGGER.error(e);
            e.printStackTrace();
        }
        return null;
    }

    public List<IlluminaFastqFilesLocation> getIlluminaFileLocationLogs(BigInteger experimentID) {
        try {
            ConnectionIntermittent connection = new ConnectionIntermittent();
            Response response = connection.getIlluminaFileLocation(experimentID);
            if (response.code() != 200) {
                LOGGER.debug(response);
                return null;
            }
            Gson gson = new GsonBuilder().setDateFormat("yyyy-mm-dd'T'HH:mm:ss.SSSZ").create();
            String jsonString = Objects.requireNonNull(response.body()).string();
            Type dataDeletionType = new TypeToken<ArrayList<IlluminaFastqFilesLocation>>() {
            }.getType();
            JsonElement jsonElement = new JsonParser().parse(jsonString);
            JsonArray  jsonArray = jsonElement.getAsJsonObject().getAsJsonArray("fastQFilePathForAnExperimentDTOs");
            if(jsonArray.size() > 0) {
                String expectedJSON = new Gson().toJson(jsonArray);
                return gson.fromJson(expectedJSON, dataDeletionType);
            }
            return null;

        } catch (Exception e) {
            LOGGER.error(e);
            e.printStackTrace();
        }
        return null;
    }

    public String postIlluminaErrorFastQLog(IlluminaFastQFileErrorModel illuminaFastQFileErrorModel) {
        try {
            ConnectionIntermittent connection = new ConnectionIntermittent();
            Response response = connection.getIlluminaInsertErrorLogs(illuminaFastQFileErrorModel);
            if (response.code() != 200) {
                LOGGER.debug(response);
                return null;
            }
            return Objects.requireNonNull(response.body()).string();
        } catch (Exception e) {
            LOGGER.error(e);
            e.printStackTrace();
        }
        return null;
    }

    public String updateIlluminaRawDataDeletionLogs(IlluminaRawDataDeletionLogUpdateDTO illuminaRawDataDeletionLogUpdateDTO) {
        try {
            ConnectionIntermittent connection = new ConnectionIntermittent();
            Response response = connection.updateIlluminaRawDataDeletionLogs(illuminaRawDataDeletionLogUpdateDTO);
            if (response.code() != 200) {
                LOGGER.debug(response);
                return null;
            }
            return Objects.requireNonNull(response.body()).string();
        } catch (Exception e) {
            LOGGER.error(e);
            e.printStackTrace();
        }
        return null;
    }
}
