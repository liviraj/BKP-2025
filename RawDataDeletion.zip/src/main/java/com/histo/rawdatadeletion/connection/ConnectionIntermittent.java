package com.histo.rawdatadeletion.connection;

import com.google.gson.Gson;
import com.histo.rawdatadeletion.model.IlluminaFastQFileErrorModel;
import com.histo.rawdatadeletion.model.IlluminaRawDataDeletionLogUpdateDTO;
import okhttp3.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.net.ssl.*;
import java.io.IOException;
import java.math.BigInteger;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.concurrent.TimeUnit;

public class ConnectionIntermittent {
    private static final Logger LOGGER = LogManager.getLogger(ConnectionIntermittent.class);

    public Response getCredentialInfo(String serverName) {

        OkHttpClient client = ConnectionIntermittent.getUnsafeOkHttpClient();

        Request request = new Request.Builder()
                .url(new ConnectionURLParams().getServerCredentialURL(serverName)).method("GET", null)
                .build();
        try {
            LOGGER.info("Get Credential URL: {}", request.url());
            Response response = client.newCall(request).execute();
            return response;
        } catch (IOException e) {
            LOGGER.error(e);
            e.printStackTrace();
        }
        return null;
    }

    public Response getIlluminaFileLocation(BigInteger experimentID) {

        OkHttpClient client = ConnectionIntermittent.getUnsafeOkHttpClient();

        Request request = new Request.Builder()
                .url(new ConnectionURLParams().getIlluminaRawDataLocationURL(experimentID)).method("GET", null)
                .build();
        try {
            LOGGER.info("Get Illumina Log URL: {}", request.url());
            return client.newCall(request).execute();
        } catch (IOException e) {
            LOGGER.error(e);
            e.printStackTrace();
        }
        return null;
    }

    public Response getIlluminaRawDataDeletionLogs() {

        OkHttpClient client = ConnectionIntermittent.getUnsafeOkHttpClient();

        Request request = new Request.Builder()
                .url(new ConnectionURLParams().getIlluminaRawDataDeletionLogsURL()).method("GET", null)
                .build();
        try {
            LOGGER.info("Get IlluminaRawDataDeletionLogs URL: {}", request.url());
            Response response = client.newCall(request).execute();
            return response;
        } catch (IOException e) {
            LOGGER.error(e);
            e.printStackTrace();
        }
        return null;
    }

    public Response getIlluminaInsertErrorLogs(IlluminaFastQFileErrorModel illuminaFastQFileErrorModel) {

        OkHttpClient client = ConnectionIntermittent.getUnsafeOkHttpClient();
        String json = new Gson().toJson(illuminaFastQFileErrorModel);
        RequestBody body = RequestBody.create(json, MediaType.parse("application/json"));
        Request request = new Request.Builder()
                .url(new ConnectionURLParams().getIlluminaInsertErrorLogURL()).method("POST", body)
                .build();
        try {
            LOGGER.info("Get IlluminaInsertErrorLogs URL: {}", request.url());
            Response response = client.newCall(request).execute();
            return response;
        } catch (IOException e) {
            LOGGER.error(e);
            e.printStackTrace();
        }
        return null;
    }


    public Response updateIlluminaRawDataDeletionLogs(IlluminaRawDataDeletionLogUpdateDTO illuminaRawDataDeletionLogUpdateDTO) {

        OkHttpClient client = ConnectionIntermittent.getUnsafeOkHttpClient();
        String json = new Gson().toJson(illuminaRawDataDeletionLogUpdateDTO);
        RequestBody body = RequestBody.create(json, MediaType.parse("application/json"));
        Request request = new Request.Builder()
                .url(new ConnectionURLParams().getIlluminaRawDataDeletionLogsURL()).method("PUT", body)
                .build();
        try {
            LOGGER.info("Get update IlluminaRawDataDeletionLogs URL: {}", request.url());
            Response response = client.newCall(request).execute();
            return response;
        } catch (IOException e) {
            LOGGER.error(e);
            e.printStackTrace();
        }
        return null;
    }    private static OkHttpClient getUnsafeOkHttpClient() {
        try {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
                @Override
                public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType)
                        throws CertificateException {
                }

                @Override
                public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType)
                        throws CertificateException {
                }

                @Override
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }
            } };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            return new OkHttpClient.Builder().connectTimeout(60, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).sslSocketFactory(sslSocketFactory, (X509TrustManager) trustAllCerts[0])
                    .hostnameVerifier(new HostnameVerifier() {
                        @Override
                        public boolean verify(String hostname, SSLSession session) {
                            return true;
                        }
                    }).build();

        } catch (Exception e) {
            LOGGER.error(e);
            throw new RuntimeException(e);
        }
    }
}
