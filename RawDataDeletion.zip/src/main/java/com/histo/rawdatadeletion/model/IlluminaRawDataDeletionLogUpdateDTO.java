package com.histo.rawdatadeletion.model;

import java.math.BigInteger;

public class IlluminaRawDataDeletionLogUpdateDTO {
    private BigInteger experimentID;
    private int isPhysicallyDeleted;
    private String physicalDeletionDate;
    private int isFastQFileAvailableforAllSamples;
    private int isParsedAlready;

    public int getIsParsedAlready() {
        return isParsedAlready;
    }

    public void setIsParsedAlready(int isParsedAlready) {
        this.isParsedAlready = isParsedAlready;
    }

    private String experimentGUIID;

    private int isRawDataAvailable;

    public int getIsRawDataAvailable() {
        return isRawDataAvailable;
    }

    public void setIsRawDataAvailable(int isRawDataAvailable) {
        this.isRawDataAvailable = isRawDataAvailable;
    }

    public String getExperimentGUIID() {
        return experimentGUIID;
    }

    public void setExperimentGUIID(String experimentGUIID) {
        this.experimentGUIID = experimentGUIID;
    }



    public int getIsPhysicallyDeleted() {
        return isPhysicallyDeleted;
    }

    public void setIsPhysicallyDeleted(int isPhysicallyDeleted) {
        this.isPhysicallyDeleted = isPhysicallyDeleted;
    }

    public int getIsFastQFileAvailableforAllSamples() {
        return isFastQFileAvailableforAllSamples;
    }

    public void setIsFastQFileAvailableforAllSamples(int isFastQFileAvailableforAllSamples) {
        this.isFastQFileAvailableforAllSamples = isFastQFileAvailableforAllSamples;
    }

    public BigInteger getExperimentID() {
        return experimentID;
    }

    public void setExperimentID(BigInteger experimentID) {
        this.experimentID = experimentID;
    }



    public String getPhysicalDeletionDate() {
        return physicalDeletionDate;
    }

    public void setPhysicalDeletionDate(String physicalDeletionDate) {
        this.physicalDeletionDate = physicalDeletionDate;
    }
}
