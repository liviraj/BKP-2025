package com.histo.rawdatadeletion.model;

public enum ClinicalType {
    NonClinical,
    Clinical
}
