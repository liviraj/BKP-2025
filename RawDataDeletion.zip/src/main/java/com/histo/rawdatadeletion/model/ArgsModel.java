package com.histo.rawdatadeletion.model;



public class ArgsModel {
    private MachineName machineName;
    private boolean needtoDelete;
    // private String sourceServer;
    // private String destinationServer;

//    public String getSourceServer() {
//        return sourceServer;
//    }
//
//    public void setSourceServer(String sourceServer) {
//        this.sourceServer = sourceServer;
//    }

//    public String getDestinationServer() {
//        return destinationServer;
//    }
//
//    public void setDestinationServer(String destinationServer) {
//        this.destinationServer = destinationServer;
//    }

    public MachineName getMachineName() {
        return machineName;
    }

    public void setMachineName(MachineName machineName) {
        this.machineName = machineName;
    }


    public boolean isNeedtoDelete() {
        return needtoDelete;
    }

    public void setNeedtoDelete(boolean needtoDelete) {
        this.needtoDelete = needtoDelete;
    }




}
