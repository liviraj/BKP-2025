package com.histo.rawdatadeletion.model;

public enum MachineName {
    Illumina,
    PacBio
}