package com.histo.rawdatadeletion.model;

public class IlluminaFastQFileErrorModel {
    private Integer rawDataDeletionLogID;
    private String sampleID;
    private String fastQFilePath;

    public IlluminaFastQFileErrorModel() {

    }

    public Integer getRawDataDeletionLogID() {
        return rawDataDeletionLogID;
    }

    public void setRawDataDeletionLogID(Integer rawDataDeletionLogID) {
        this.rawDataDeletionLogID = rawDataDeletionLogID;
    }

    public String getSampleID() {
        return sampleID;
    }

    public void setSampleID(String sampleID) {
        this.sampleID = sampleID;
    }

    public String getFastQFilePath() {
        return fastQFilePath;
    }

    public void setFastQFilePath(String fastQFilePath) {
        this.fastQFilePath = fastQFilePath;
    }
}
