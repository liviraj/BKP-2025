package com.histo.rawdatadeletion.model;

import java.math.BigInteger;

public class DataDeletionLogModels {
    private int autoID;
    private String deletionDate;
    private int histoSUserID;
    private BigInteger experimentID;
    private String experimentName;
    private String experimentGUID;
    private String rawDataPath;
    private String physicalDeletionDate;
    private boolean isFastQFileAvailableforAllSamples;
    private boolean isPhysicallyDeleted;

    public int getAutoID() {
        return autoID;
    }

    public void setAutoID(int autoID) {
        this.autoID = autoID;
    }

    public String getDeletionDate() {
        return deletionDate;
    }

    public void setDeletionDate(String deletionDate) {
        this.deletionDate = deletionDate;
    }

    public int getHistoSUserID() {
        return histoSUserID;
    }

    public void setHistoSUserID(int histoSUserID) {
        this.histoSUserID = histoSUserID;
    }

    public BigInteger getExperimentID() {
        return experimentID;
    }

    public void setExperimentID(BigInteger experimentID) {
        this.experimentID = experimentID;
    }

    public String getExperimentName() {
        return experimentName;
    }

    public void setExperimentName(String experimentName) {
        this.experimentName = experimentName;
    }

    public String getExperimentGUID() {
        return experimentGUID;
    }

    public void setExperimentGUID(String experimentGUIID) {
        this.experimentGUID = experimentGUIID;
    }

    public String getRawDataPath() {
        return rawDataPath;
    }

    public void setRawDataPath(String rawDataPath) {
        this.rawDataPath = rawDataPath;
    }

    public String getPhysicalDeletionDate() {
        return physicalDeletionDate;
    }

    public void setPhysicalDeletionDate(String physicalDeletionDate) {
        this.physicalDeletionDate = physicalDeletionDate;
    }

    public boolean isFastQFileAvailableforAllSamples() {
        return isFastQFileAvailableforAllSamples;
    }

    public void setFastQFileAvailableforAllSamples(boolean fastQFileAvailableforAllSamples) {
        isFastQFileAvailableforAllSamples = fastQFileAvailableforAllSamples;
    }

    public boolean isPhysicallyDeleted() {
        return isPhysicallyDeleted;
    }

    public void setPhysicallyDeleted(boolean physicallyDeleted) {
        isPhysicallyDeleted = physicallyDeleted;
    }
}
