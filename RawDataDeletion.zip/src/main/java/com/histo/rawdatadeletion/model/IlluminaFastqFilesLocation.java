package com.histo.rawdatadeletion.model;

public class IlluminaFastqFilesLocation {
    private String nGSExperimentName;
    private String sampleID;
    private String plateName;
    private String fileLocation;

    public String getnGSExperimentName() {
        return nGSExperimentName;
    }

    public void setnGSExperimentName(String nGSExperimentName) {
        this.nGSExperimentName = nGSExperimentName;
    }

    public String getSampleID() {
        return sampleID;
    }

    public void setSampleID(String sampleID) {
        this.sampleID = sampleID;
    }

    public String getPlateName() {
        return plateName;
    }

    public void setPlateName(String plateName) {
        this.plateName = plateName;
    }

    public String getFileLocation() {
        return fileLocation;
    }

    public void setFileLocation(String fileLocation) {
        this.fileLocation = fileLocation;
    }
}
