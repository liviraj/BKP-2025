package com.histo.rawdatadeletion.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:application.properties")
public class SMBAuthSetup {
    @Value("${KeePassFilePath}")
    public static String keepassFilePath;
    @Value("${KeePassPassword}")
    public static String keepassPassword;
    @Value("${KeePassFilePath}")
    public void setKeepassFilePath(String keepassFilePath) {
        this.keepassFilePath = keepassFilePath;
    }
    @Value("${KeePassPassword}")
    public void  setKeepassPassword(String keepassPassword) {
        this.keepassPassword = keepassPassword;
    }
}
