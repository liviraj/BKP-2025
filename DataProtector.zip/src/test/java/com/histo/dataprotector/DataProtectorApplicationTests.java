package com.histo.dataprotector;

import com.histo.dataprotector.util.CryptoUtils;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataProtectorApplicationTests {

	@Test
	void contextLoads() {
		CryptoUtils cryptoUtils = CryptoUtils.getInstance();
		String randomSecurePassword = cryptoUtils.generateRandomSecurePassword(30);
		System.out.println("The secure password is" + randomSecurePassword);
	}

}
