package com.histo.dataprotector.model;

public class ReturnModel {
    private String message;
    private String discription;
    private boolean status;
    private Object data;

    public ReturnModel() {
    }

    public ReturnModel(boolean status,String message, String discription , Object data) {
        this.message = message;
        this.discription = discription;
        this.status = status;
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDiscription() {
        return discription;
    }

    public void setDiscription(String discription) {
        this.discription = discription;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ReturnModel{" +
                "message='" + message + '\'' +
                ", discription='" + discription + '\'' +
                ", status=" + status +
                ", data=" + data +
                '}';
    }
}
