package com.histo.dataprotector.model;

import com.fasterxml.jackson.annotation.JsonFilter;

@JsonFilter("DataProtectorResponseModel")
public class DataProtectorResponse {

    private boolean status;
    private InfoResponseModel information;
    private String responseMessage;
    private String encryptData;
    private String decryptData;
    private String jwtToken;
    private String loginName;
    private Integer secKeyId;
    private String fileExtension;

    public DataProtectorResponse() {
        super();
    }

    public String getFileExtension() {
        return fileExtension;
    }

    public void setFileExtension(String fileExtension) {
        this.fileExtension = fileExtension;
    }

    public Integer getSecKeyId() {
        return secKeyId;
    }

    public void setSecKeyId(Integer secKeyId) {
        this.secKeyId = secKeyId;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public InfoResponseModel getInformation() {
        return information;
    }

    public void setInformation(InfoResponseModel information) {
        this.information = information;
    }

    public String getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }

    public String getDecryptData() {
        return decryptData;
    }

    public void setDecryptData(String decryptData) {
        this.decryptData = decryptData;
    }

    public String getEncryptData() {
        return encryptData;
    }

    public void setEncryptData(String encryptData) {
        this.encryptData = encryptData;
    }

    public String getJwtToken() {
        return jwtToken;
    }

    public void setJwtToken(String jwtToken) {
        this.jwtToken = jwtToken;
    }
}
