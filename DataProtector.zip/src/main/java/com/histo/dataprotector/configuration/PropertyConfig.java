package com.histo.dataprotector.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:application.properties")
public class PropertyConfig {
    @Value("${aes.tag.length.bit}")
    private int aesTagLengthBit;
    @Value("${aes.iv.length.byte}")
    private int aesIVLength;
    @Value("${aes.salt.length.byte}")
    private int aesSaltLength;
    @Value("${aes.encrypt.algorithm}")
    private String aesEncryptAlgorithm;

    @Value("${keepass.filepath}")
    private String keePassFilePath;
    @Value("${keepass.master.password}")
    private String keyPassPassword;
    @Value("${keepass.dataProtector.entry.username}")
    private String dataProtectorUsername;

    @Value("${jwt.secret}")
    private String jwtSecret;
    @Value("${jwt.expiryinminutes}")
    private int jwtExpiry;
    @Value("${dataprotector.seckey.valid.in.month}")
    private int dataprotectorSecKeyValidInMonth;

    public String getDataProtectorUsername() {
        return dataProtectorUsername;
    }

    public void setDataProtectorUsername(String dataProtectorUsername) {
        this.dataProtectorUsername = dataProtectorUsername;
    }

    public int getDataprotectorSecKeyValidInMonth() {
        return dataprotectorSecKeyValidInMonth;
    }

    public void setDataprotectorSecKeyValidInMonth(int dataprotectorSecKeyValidInMonth) {
        this.dataprotectorSecKeyValidInMonth = dataprotectorSecKeyValidInMonth;
    }

    public int getJwtExpiry() {
        return jwtExpiry;
    }

    public void setJwtExpiry(int jwtExpiry) {
        this.jwtExpiry = jwtExpiry;
    }

    public String getJwtSecret() {
        return jwtSecret;
    }

    public void setJwtSecret(String jwtSecret) {
        this.jwtSecret = jwtSecret;
    }

    public String getKeePassFilePath() {
        return keePassFilePath;
    }

    public void setKeePassFilePath(String keePassFilePath) {
        this.keePassFilePath = keePassFilePath;
    }

    public String getKeyPassPassword() {
        return keyPassPassword;
    }

    public void setKeyPassPassword(String keyPassPassword) {
        this.keyPassPassword = keyPassPassword;
    }

    public int getAesTagLengthBit() {
        return aesTagLengthBit;
    }

    public void setAesTagLengthBit(int aesTagLengthBit) {
        this.aesTagLengthBit = aesTagLengthBit;
    }

    public int getAesIVLength() {
        return aesIVLength;
    }

    public void setAesIVLength(int aesIVLength) {
        this.aesIVLength = aesIVLength;
    }

    public int getAesSaltLength() {
        return aesSaltLength;
    }

    public void setAesSaltLength(int aesSaltLength) {
        this.aesSaltLength = aesSaltLength;
    }

    public String getAesEncryptAlgorithm() {
        return aesEncryptAlgorithm;
    }

    public void setAesEncryptAlgorithm(String aesEncryptAlgorithm) {
        this.aesEncryptAlgorithm = aesEncryptAlgorithm;
    }

    @Override
    public String toString() {
        return "PropertyConfig{" +
                "aesTagLengthBit=" + aesTagLengthBit +
                ", aesIVLength=" + aesIVLength +
                ", aesSaltLength=" + aesSaltLength +
                ", aesEncryptAlgorithm='" + aesEncryptAlgorithm + '\'' +
                ", keePassFilePath='" + keePassFilePath + '\'' +
                ", keyPassPassword='" + keyPassPassword + '\'' +
                ", dataProtectorUsername='" + dataProtectorUsername + '\'' +
                ", jwtSecret='" + jwtSecret + '\'' +
                ", jwtExpiry=" + jwtExpiry +
                ", dataprotectorSecKeyValidInMonth=" + dataprotectorSecKeyValidInMonth +
                '}';
    }
}
