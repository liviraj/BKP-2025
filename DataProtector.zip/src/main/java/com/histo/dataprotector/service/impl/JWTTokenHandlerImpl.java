package com.histo.dataprotector.service.impl;

import com.histo.dataprotector.configuration.PropertyConfig;
import com.histo.dataprotector.entity.DataProtectorAPIConsumer;
import com.histo.dataprotector.model.DataProtectorAPIConsumersModel;
import com.histo.dataprotector.model.DataProtectorResponse;
import com.histo.dataprotector.model.InfoResponseModel;
import com.histo.dataprotector.repository.DataProtectorAPIConsumerRepository;
import com.histo.dataprotector.service.JWTTokenHandlerService;
import com.histo.dataprotector.util.ResponseFilterUtil;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.stereotype.Service;

import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.Date;
import java.util.UUID;
import java.util.function.Function;

@Service
public class JWTTokenHandlerImpl implements JWTTokenHandlerService {
    private static final Logger LOGGER = LogManager.getLogger(JWTTokenHandlerImpl.class);
    private static final String STATUS = "status";
    MappingJacksonValue mappingJacksonValue;
    private final DataProtectorResponse response;
    private final PropertyConfig propertyConfig;
    private DataProtectorAPIConsumerRepository dataProtectorAPIConsumerRepository;
    private JWTTokenHandlerImpl(PropertyConfig propertyConfig
        , DataProtectorAPIConsumerRepository dataProtectorAPIConsumerRepository) {
        super();
        response = new DataProtectorResponse();
        this.propertyConfig = propertyConfig;
        this.dataProtectorAPIConsumerRepository = dataProtectorAPIConsumerRepository;
    }

    /* Generate JWT Token using HS256 */
    @Override
    public ResponseEntity<Object> generateJWTToken(DataProtectorAPIConsumersModel consumersModel) {
        try {
            DataProtectorAPIConsumer findAPIConsumerByLoginNameAndPassword = dataProtectorAPIConsumerRepository.findByLoginNameAndPassword(consumersModel.getLoginName(), consumersModel.getPassword());
            if (findAPIConsumerByLoginNameAndPassword == null) {
                response.setStatus(false);
                response.setInformation(new InfoResponseModel(new Date(), "Invalid Credentials", "Please check your credentials and try again"));
                mappingJacksonValue = ResponseFilterUtil.responseFilter(response, new String[]{STATUS, "information"});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.UNAUTHORIZED);
            }
            Instant now = Instant.now();
            Key hmacKey = new SecretKeySpec(Base64.getDecoder().decode(propertyConfig.getJwtSecret()),
                    SignatureAlgorithm.HS256.getJcaName());
            String token = Jwts.builder()
                    .claim("loginName", consumersModel.getLoginName())
                    .setSubject(consumersModel.getLoginName())
                    .setId(UUID.randomUUID().toString())
                    .setIssuedAt(Date.from(now))
                    .setExpiration(Date.from(now.plus(propertyConfig.getJwtExpiry(), ChronoUnit.MINUTES)))
                    .signWith(hmacKey)
                    .compact();
            response.setJwtToken(token);
            response.setStatus(true);
            mappingJacksonValue = ResponseFilterUtil.responseFilter(response, new String[]{STATUS, "jwtToken"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error("generateJWTToken() Error: {}", e);
            return failedResponse("Failed", "Failed to generate JWT Token", HttpStatus.CONFLICT);
        }

    }

    private ResponseEntity<Object> failedResponse(String message, String description, HttpStatus httpStatus) {
        response.setStatus(false);
        response.setInformation(new InfoResponseModel(new Date(), message, description));
        mappingJacksonValue = ResponseFilterUtil.responseFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, httpStatus);
    }

    //validate token
    @Override
    public ResponseEntity<Object> validateToken(String token) {
        try {
            if (isTokenExpired(token)) {
                response.setStatus(false);
                response.setInformation(new InfoResponseModel(new Date(), "Token Expired", "JWT token is expired!"));
                mappingJacksonValue = ResponseFilterUtil.responseFilter(response, new String[]{"information", STATUS});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.UNAUTHORIZED);
            }
            final String loginName = getLoginNameFromToken(token);
            DataProtectorAPIConsumer byLoginName = dataProtectorAPIConsumerRepository.findByLoginName(loginName);
            if (byLoginName == null || !loginName.equals(byLoginName.getLoginName())) {
                response.setStatus(false);
                response.setInformation(new InfoResponseModel(new Date(), "In-valid Token", "In-valid token. Authorization is failed."));
                mappingJacksonValue = ResponseFilterUtil.responseFilter(response, new String[]{"information", STATUS});
                return new ResponseEntity<>(mappingJacksonValue, HttpStatus.UNAUTHORIZED);
            }
            return new ResponseEntity<>(loginName, HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error("validateToken() Error: {}", e);
            if (e.getMessage().toLowerCase().contains("expired")) {
                return failedResponse("Token Expired", "JWT token is expired!", HttpStatus.UNAUTHORIZED);
            }
            return failedResponse("Invalid Token", "In-valid token. Authorization is failed.", HttpStatus.UNAUTHORIZED);
        }
    }

    //check if the token has expired
    private Boolean isTokenExpired(String token) {
        final Date expiration = getExpirationDateFromToken(token);
        return expiration.before(new Date());
    }

    //retrieve expiration date from jwt token
    public Date getExpirationDateFromToken(String token) {
        return getClaimFromToken(token, Claims::getExpiration);
    }

    //retrieve username from jwt token
    public String getLoginNameFromToken(String token) {
        Claims claims = getAllClaimsFromToken(token);
        return claims.get("loginName", String.class);
    }

    public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = getAllClaimsFromToken(token);
        return claimsResolver.apply(claims);
    }

    //for retrieving any information from token we will need the secret key
    private Claims getAllClaimsFromToken(String token) {
        Key hmacKey = new SecretKeySpec(Base64.getDecoder().decode(propertyConfig.getJwtSecret()),
                SignatureAlgorithm.HS256.getJcaName());
        return Jwts.parserBuilder().setSigningKey(hmacKey).build().parseClaimsJws(token).getBody();
    }
}
