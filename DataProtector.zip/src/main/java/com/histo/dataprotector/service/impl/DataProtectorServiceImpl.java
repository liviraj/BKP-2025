package com.histo.dataprotector.service.impl;

import com.histo.dataprotector.configuration.PropertyConfig;
import com.histo.dataprotector.entity.DataProtectorAPIConsumer;
import com.histo.dataprotector.entity.SecKey;
import com.histo.dataprotector.model.DataProtectorResponse;
import com.histo.dataprotector.model.InfoResponseModel;
import com.histo.dataprotector.model.ReturnModel;
import com.histo.dataprotector.repository.DataProtectorAPIConsumerRepository;
import com.histo.dataprotector.repository.SecKeyRepository;
import com.histo.dataprotector.service.DataProtectorService;
import com.histo.dataprotector.util.CryptoUtils;
import com.histo.dataprotector.util.DataProtectorUtil;
import com.histo.dataprotector.util.KeePassManagar;
import com.histo.dataprotector.util.ResponseFilterUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.Date;
import java.util.Optional;

@Service
public class DataProtectorServiceImpl implements DataProtectorService {

    private static final Logger LOGGER = LogManager.getLogger(DataProtectorServiceImpl.class);
    private static final String STATUS = "status";
    MappingJacksonValue mappingJacksonValue;
    private final DataProtectorResponse response;
    private final PropertyConfig propertyConfig;
    private final KeePassManagar keePassManagar = KeePassManagar.getInstance();
    private final CryptoUtils cryptoUtils = CryptoUtils.getInstance();

    private SecKeyRepository secKeyRepository;
    private DataProtectorAPIConsumerRepository dataProtectorAPIConsumerRepository;

    private DataProtectorServiceImpl(PropertyConfig propertyConfig
            , SecKeyRepository secKeyRepository
            , DataProtectorAPIConsumerRepository dataProtectorAPIConsumerRepository) {
        super();
        response = new DataProtectorResponse();
        this.propertyConfig = propertyConfig;
        this.secKeyRepository = secKeyRepository;
        this.dataProtectorAPIConsumerRepository = dataProtectorAPIConsumerRepository;
    }

    @Override
    public ResponseEntity<Object> encryptFile(MultipartFile file, String loginName) {
        try {

            ReturnModel returnModel = new ReturnModel();
            SecKey secKeyByConsumerID = secKeyRepository.findByConsumerID_LoginNameAndIsCurrent(loginName, true);
            if (secKeyByConsumerID == null) {
                returnModel = addSecKeys(loginName);
                if (!returnModel.isStatus()) {
                    return responseFalseValidation(returnModel.getMessage(), returnModel.getDiscription());
                }
            } else {
                returnModel.setData(secKeyByConsumerID.getId());
            }
            boolean isSecKeyValid = secKeyByConsumerID.getValidTo().isAfter(Instant.now());
            if (!isSecKeyValid) {
                secKeyByConsumerID.setCurrent(false);
                secKeyRepository.save(secKeyByConsumerID);
                returnModel = addSecKeys(loginName);
                if (!returnModel.isStatus()) {
                    return responseFalseValidation(returnModel.getMessage(), returnModel.getDiscription());
                }
            }
            LOGGER.info("Consumer: {}. Encryption start", loginName);
            secKeyByConsumerID = secKeyRepository.findById((Integer) returnModel.getData()).get();
            byte[] salt = cryptoUtils.getRandomNonce(propertyConfig.getAesSaltLength());
            byte[] iv = cryptoUtils.getRandomNonce(propertyConfig.getAesIVLength());
            SecretKey aesKeyFromPassword = cryptoUtils.getAESKeyFromPassword(
                    decryptString(secKeyByConsumerID.getSecKey()).toCharArray(), salt);
            Cipher cipher = Cipher.getInstance(propertyConfig.getAesEncryptAlgorithm());
            cipher.init(Cipher.ENCRYPT_MODE, aesKeyFromPassword, new GCMParameterSpec(propertyConfig.getAesTagLengthBit(), iv));
            byte[] cipherText = cipher.doFinal(file.getBytes());
            byte[] cipherTextWithIvSalt = ByteBuffer.allocate(iv.length + salt.length + cipherText.length)
                    .put(iv)
                    .put(salt)
                    .put(cipherText)
                    .array();

            String encryptedData = Base64.getEncoder().encodeToString(cipherTextWithIvSalt);
            String fileExtension = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".") + 1);
            // string representation, base64, send this string to other for decryption.
            response.setEncryptData(encryptedData);
            response.setStatus(true);
            response.setSecKeyId(secKeyByConsumerID.getId());
            response.setFileExtension(fileExtension);
            mappingJacksonValue = ResponseFilterUtil.responseFilter(response, new String[]{STATUS, "encryptData", "secKeyId", "fileExtension"});

            LOGGER.info("Consumer : {}, SecKeyId: {}", loginName, secKeyByConsumerID.getId());
            LOGGER.info("Encryption end");
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error("encryptFile() Error: {}", e);
            return failedResponse("Encryption failed and exception", e.getMessage() + "\n" + e.getStackTrace());
        }
    }

    @Override
    public ResponseEntity<Object> decryptFile(MultipartFile file, String loginName, Integer secKeyId) {

        try {
            Optional<SecKey> secKeyByConsumerID = secKeyRepository.findById(secKeyId);
            if (!secKeyByConsumerID.isPresent()) {
                return responseFalseValidation("Not Found", "Not Found Secret Key Id");
            }
            DataProtectorAPIConsumer consumerByLoginName = dataProtectorAPIConsumerRepository.findByLoginName(loginName);
            if (!secKeyByConsumerID.get().getConsumerID().getLoginName().equals(consumerByLoginName.getLoginName())) {
                return responseFalseValidation("SecKey Mismatch", "Seckey consumer and given JWT token consumer is mismatch");
            }
            LOGGER.info("Consumer: {}. Decryption start", loginName);
            byte[] decode = Base64.getDecoder().decode(file.getBytes());
            ByteBuffer bb = ByteBuffer.wrap(decode);
            byte[] iv = new byte[propertyConfig.getAesIVLength()];
            bb.get(iv);
            byte[] salt = new byte[propertyConfig.getAesSaltLength()];
            bb.get(salt);
            byte[] cipherText = new byte[bb.remaining()];
            bb.get(cipherText);
            // get back the aes key from the same password and salt
            SecretKey aesKeyFromPassword = cryptoUtils.getAESKeyFromPassword(
                    decryptString(secKeyByConsumerID.get().getSecKey()).toCharArray(), salt);
            Cipher cipher = Cipher.getInstance(propertyConfig.getAesEncryptAlgorithm());
            cipher.init(Cipher.DECRYPT_MODE, aesKeyFromPassword, new GCMParameterSpec(propertyConfig.getAesTagLengthBit(), iv));
            byte[] plainText = cipher.doFinal(cipherText);
            String decryptData = Base64.getEncoder().encodeToString(plainText);
            LOGGER.info("Consumer : {}, SecKeyId: {}", loginName, secKeyId);
            LOGGER.info("Decryption end");
            response.setDecryptData(decryptData);
            response.setStatus(true);
            mappingJacksonValue = ResponseFilterUtil.responseFilter(response, new String[]{STATUS, "decryptData"});
            return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error("decryptFile() Error: {}", e);
            return failedResponse("Decryption failed and exception.", e.getMessage() + "\n" + e.getStackTrace());
        }
    }

    private ReturnModel addSecKeys(String loginName) {
        try {
            DataProtectorAPIConsumer consumerByLoginName = dataProtectorAPIConsumerRepository.findByLoginName(loginName);
            if (consumerByLoginName == null) {
                return new ReturnModel(false, "Not Found", "Invalid Consumer", null);
            }
            SecKey currentSecKey = secKeyRepository.findByConsumerID_LoginNameAndIsCurrent(loginName, true);
            if (currentSecKey != null) {
                return new ReturnModel(false, "Record Exist", "Record already present", null);
            }

            SecKey secKey = new SecKey();
            secKey.setSecKey(encryptString(DataProtectorUtil.generateRandomPassword()));
            secKey.setConsumerID(consumerByLoginName);
            secKey.setCurrent(true);
            secKey.setValidFrom(Instant.now());
            secKey.setValidTo(secKey.getValidFrom().plus(propertyConfig.getDataprotectorSecKeyValidInMonth() * 30, ChronoUnit.DAYS));

            SecKey savedSecKey = secKeyRepository.save(secKey);
            return new ReturnModel(true, "Saved Successfully", "Security key added successfully", savedSecKey.getId());
        } catch (Exception e) {
            return new ReturnModel(false, "Error", "Failed to save", e);
        }
    }

    private String encryptString(String toEncryptString) throws NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, InvalidAlgorithmParameterException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        byte[] salt = cryptoUtils.getRandomNonce(propertyConfig.getAesSaltLength());
        byte[] iv = cryptoUtils.getRandomNonce(propertyConfig.getAesIVLength());
        SecretKey aesKeyFromPassword = cryptoUtils.getAESKeyFromPassword(keePassManagar.getEncryptionSecureCode(propertyConfig).toCharArray(), salt);
        Cipher cipher = Cipher.getInstance(propertyConfig.getAesEncryptAlgorithm());
        cipher.init(Cipher.ENCRYPT_MODE, aesKeyFromPassword, new GCMParameterSpec(propertyConfig.getAesTagLengthBit(), iv));
        byte[] cipherText = cipher.doFinal(toEncryptString.getBytes());
        byte[] cipherTextWithIvSalt = ByteBuffer.allocate(iv.length + salt.length + cipherText.length)
                .put(iv)
                .put(salt)
                .put(cipherText)
                .array();

        String encryptedData = Base64.getEncoder().encodeToString(cipherTextWithIvSalt);
        return encryptedData;
    }

    private String decryptString(String toDecryptString) throws NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, InvalidAlgorithmParameterException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException {
        byte[] decode = Base64.getDecoder().decode(toDecryptString.getBytes());
        ByteBuffer bb = ByteBuffer.wrap(decode);
        byte[] iv = new byte[propertyConfig.getAesIVLength()];
        bb.get(iv);
        byte[] salt = new byte[propertyConfig.getAesSaltLength()];
        bb.get(salt);
        byte[] cipherText = new byte[bb.remaining()];
        bb.get(cipherText);
        // get back the aes key from the same password and salt
        SecretKey aesKeyFromPassword = cryptoUtils.getAESKeyFromPassword(keePassManagar.getEncryptionSecureCode(propertyConfig).toCharArray(), salt);
        Cipher cipher = Cipher.getInstance(propertyConfig.getAesEncryptAlgorithm());
        cipher.init(Cipher.DECRYPT_MODE, aesKeyFromPassword, new GCMParameterSpec(propertyConfig.getAesTagLengthBit(), iv));
        byte[] plainText = cipher.doFinal(cipherText);
        String decryptData = new String(plainText, "US-ASCII");
        return decryptData;
    }

    private ResponseEntity<Object> failedResponse(String message, String description) {
        response.setStatus(false);
        response.setInformation(new InfoResponseModel(new Date(), message, description));
        mappingJacksonValue = ResponseFilterUtil.responseFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }

    private ResponseEntity<Object> responseFalseValidation(String mesage, String description) {
        response.setStatus(false);
        response.setInformation(new InfoResponseModel(new Date(), mesage, description));
        mappingJacksonValue = ResponseFilterUtil.responseFilter(response, new String[]{STATUS, "information"});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.BAD_REQUEST);
    }

    private ResponseEntity<Object> catchException(Exception e) {
        LOGGER.error("Error :{}", e);
        response.setStatus(false);
        response.setInformation(new InfoResponseModel(new Date(), "Error", "Something went wrong. Please try again."));
        mappingJacksonValue = ResponseFilterUtil.responseFilter(response, new String[]{"information", STATUS});
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CONFLICT);
    }
}
