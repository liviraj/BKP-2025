package com.histo.dataprotector.service;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

public interface DataProtectorService {
    public ResponseEntity<Object> encryptFile(MultipartFile file, String loginName);
    public ResponseEntity<Object> decryptFile(MultipartFile file, String loginName, Integer secKeyId);
}
