package com.histo.dataprotector.service;

import com.histo.dataprotector.model.DataProtectorAPIConsumersModel;
import org.springframework.http.ResponseEntity;

public interface JWTTokenHandlerService {
    public ResponseEntity<Object> generateJWTToken(DataProtectorAPIConsumersModel consumersModel);
    public ResponseEntity<Object> validateToken(String token);
}
