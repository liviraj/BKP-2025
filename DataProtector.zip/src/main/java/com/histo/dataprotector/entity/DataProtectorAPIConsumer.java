package com.histo.dataprotector.entity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "DataProtectorAPIConsumers")
public class DataProtectorAPIConsumer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ConsumerID", nullable = false)
    private Integer id;

    @Size(max = 100)
    @NotNull
    @Column(name = "LoginName", nullable = false, length = 100)
    private String loginName;

    @Size(max = 100)
    @NotNull
    @Column(name = "Password", nullable = false, length = 100)
    private String password;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "DataProtectorAPIConsumer{" +
                "id=" + id +
                ", loginName='" + loginName + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}