package com.histo.dataprotector.entity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.Instant;

@Entity
@Table(name = "SecKeys")
public class SecKey {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SecKeyID", nullable = false)
    private Integer id;

    @Size(max = 255)
    @Column(name = "SecKey")
    private String secKey;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "ConsumerID", nullable = false)
    private DataProtectorAPIConsumer consumerID;

    @NotNull
    @Column(name = "ValidFrom", nullable = false)
    private Instant validFrom;

    @NotNull
    @Column(name = "ValidTo", nullable = false)
    private Instant validTo;

    @NotNull
    @Column(name = "IsCurrent", nullable = false)
    private Boolean isCurrent = false;

    public SecKey() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSecKey() {
        return secKey;
    }

    public void setSecKey(String secKey) {
        this.secKey = secKey;
    }

    public DataProtectorAPIConsumer getConsumerID() {
        return consumerID;
    }

    public void setConsumerID(DataProtectorAPIConsumer consumerID) {
        this.consumerID = consumerID;
    }

    public Instant getValidFrom() {
        return validFrom;
    }

    public void setValidFrom(Instant validFrom) {
        this.validFrom = validFrom;
    }

    public Instant getValidTo() {
        return validTo;
    }

    public void setValidTo(Instant validTo) {
        this.validTo = validTo;
    }

    public Boolean getCurrent() {
        return isCurrent;
    }

    public void setCurrent(Boolean current) {
        isCurrent = current;
    }

    @Override
    public String toString() {
        return "SecKey{" +
                "id=" + id +
                ", secKey='" + secKey + '\'' +
                ", consumerID=" + consumerID +
                ", validFrom=" + validFrom +
                ", validTo=" + validTo +
                ", isCurrent=" + isCurrent +
                '}';
    }
}