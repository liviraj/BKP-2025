package com.histo.dataprotector.util;


import com.histo.dataprotector.configuration.PropertyConfig;
import de.slackspace.openkeepass.KeePassDatabase;
import de.slackspace.openkeepass.domain.Entry;
import de.slackspace.openkeepass.domain.KeePassFile;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class KeePassManagar {
    private static final Logger logger = LogManager.getLogger(KeePassManagar.class);
    private static volatile KeePassManagar instance;
    private static Object mutex = new Object();

    public KeePassManagar() {
    }

    public static KeePassManagar getInstance() {
        KeePassManagar result = instance;
        if (result == null) {
            synchronized (mutex) {
                result = instance;
                if (result == null)
                    instance = result = new KeePassManagar();
            }
        }
        return result;
    }
    public String getEncryptionSecureCode(PropertyConfig propertyConfig) {
        try {
            logger.info("Reading from KeePass and the key is " + propertyConfig.getDataProtectorUsername());
            KeePassFile database = KeePassDatabase
                    .getInstance(propertyConfig.getKeePassFilePath())
                    .openDatabase(propertyConfig.getKeyPassPassword());
            Entry entry = database.getEntryByTitle(propertyConfig.getDataProtectorUsername());
            if(entry != null) {
                if (entry.getPassword() != null && !entry.getPassword().isEmpty()) {
                    return entry.getPassword();
                }
            }
        } catch (Exception ex) {
            logger.error(ex.getStackTrace());
        }
        return null;
    }
}
