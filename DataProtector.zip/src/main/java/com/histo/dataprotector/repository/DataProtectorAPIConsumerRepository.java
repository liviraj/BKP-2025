package com.histo.dataprotector.repository;

import com.histo.dataprotector.entity.DataProtectorAPIConsumer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DataProtectorAPIConsumerRepository extends JpaRepository<DataProtectorAPIConsumer, Integer> {
    public DataProtectorAPIConsumer findByLoginName(String loginName);

    public DataProtectorAPIConsumer findByLoginNameAndPassword(String loginName, String password);

}