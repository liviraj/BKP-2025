package com.histo.dataprotector.repository;

import com.histo.dataprotector.entity.SecKey;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SecKeyRepository extends JpaRepository<SecKey, Integer> {
    public SecKey findByConsumerID_LoginNameAndIsCurrent(String loginName, Boolean isCurrent);
}