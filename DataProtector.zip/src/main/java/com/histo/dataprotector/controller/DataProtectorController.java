package com.histo.dataprotector.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.histo.dataprotector.model.DataProtectorAPIConsumersModel;
import com.histo.dataprotector.service.DataProtectorService;
import com.histo.dataprotector.service.JWTTokenHandlerService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/dataProtector")
public class DataProtectorController {
    private static final Logger LOGGER = LogManager.getLogger(DataProtectorController.class);
    private DataProtectorService dataProtectorService;
    private JWTTokenHandlerService jwtTokenHandlerService;
    private ObjectMapper objectMapper;

    private DataProtectorController(DataProtectorService dataProtectorService, JWTTokenHandlerService jwtTokenHandlerService, ObjectMapper objectMapper) {
        this.dataProtectorService = dataProtectorService;
        this.jwtTokenHandlerService = jwtTokenHandlerService;
        this.objectMapper = objectMapper;
    }

    @PostMapping("/encryptFile")
    public ResponseEntity<Object> encryptFile(@RequestParam("file") MultipartFile file, @RequestHeader("Authorization") String token) throws IOException {
        LOGGER.info("/encryptFile API call started. Method: {}. Token: {}", HttpMethod.POST, token);
        ResponseEntity<Object> responseEntity = jwtTokenHandlerService.validateToken(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            String loginName = objectMapper.convertValue(responseEntity.getBody(), String.class);
            return dataProtectorService.encryptFile(file, loginName);
        }
        LOGGER.info("/encryptFile API call end");
        return responseEntity;
    }

    @PostMapping("/decryptFile")
    public ResponseEntity<Object> decryptFile(@RequestParam("file") MultipartFile file, @RequestHeader("Authorization") String token, @RequestHeader("SecKeyId") Integer secKeyId) {
        LOGGER.info("/decryptFile API call started. Method: {}. Token: {}", HttpMethod.POST, token);
        ResponseEntity<Object> responseEntity = jwtTokenHandlerService.validateToken(token);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            String loginName = objectMapper.convertValue(responseEntity.getBody(), String.class);
            return dataProtectorService.decryptFile(file, loginName, secKeyId);
        }
        LOGGER.info("/decryptFile API call end");
        return responseEntity;
    }

    @PostMapping("/generateJwt")
    public ResponseEntity<Object> generateJwt(@RequestBody DataProtectorAPIConsumersModel consumersModel) {
        LOGGER.info("/generateJwt API call. Method: {}. Request Body: {}", HttpMethod.POST, consumersModel);
        return jwtTokenHandlerService.generateJWTToken(consumersModel);
    }
}

