package com.histo.pacbiofiledata;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.histo.pacbiofiledata.implementation.FileCopyOrMoveService;
import com.histo.pacbiofiledata.implementation.FileDeleteService;
import com.histo.pacbiofiledata.model.ActionType;
import com.histo.pacbiofiledata.model.FileDataArguments;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.LoggerContext;

import java.lang.reflect.Field;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public class PacbioFileDataOrganizer {
    public static void main(String args[]) {
        System.setProperty("log_file", System.getProperty("user.home"));
        LoggerContext ctx = (LoggerContext) LogManager.getContext(false);
        ctx.reconfigure();
        final Logger LOGGER = LogManager.getLogger(PacbioFileDataOrganizer.class.getName());
        int argLength = args.length;

        if (argLength == 0) {
            LOGGER.error("Invalid parameters " + argLength);
            return;
        }
			/*
				COPY, MOVE, DELETE action example arguments
				COPY - Arguments:
				{"sourceServer":"histonas2.histogenetics.com","destinationServer":"histonas2.histogenetics.com","sourceShare":"PBVol3","destinationShare":"PBVol3","sourceDirectory":"Test/PacbioFileDataOrganizer/SourceLocation/","destinationDirectory":"Test/PacbioFileDataOrganizer/DestinationLocation/","sourceUsername":"admin","sourcePassword":"H1st0.@dm1n!","destinationUsername":"admin","destinationPassword":"H1st0.@dm1n!","copyDataNumberOfDaysBack":1,"statusViewerId":0,"fileSizeInMB":100,"PDFPath":"","actionType":"COPY"}

				MOVE - Arguments:
				{"sourceServer":"histonas2.histogenetics.com","destinationServer":"histonas2.histogenetics.com","sourceShare":"PBVol3","destinationShare":"PBVol3","sourceDirectory":"Test/PacbioFileDataOrganizer/SourceLocation/","destinationDirectory":"Test/PacbioFileDataOrganizer/DestinationLocation/","sourceUserName":"admin","sourcePassword":"H1st0.@dm1n!","destinationUsername":"admin","destinationPassword":"H1st0.@dm1n!","copyDataNumberOfDaysBack":1,"statusViewerId":0,"fileSizeInMB":100,"PDFPath":"","actionType":"MOVE"}

				DELETE - Arguments:
				{"deleteServer":"histonas2.histogenetics.com","deleteShare":"PBVol3","deleteLocation":"Test/PacbioFileDataOrganizer/DestinationLocation/","deleteUserName":"cloudsync","deletePassword":"H1st0.Cloud","deleteDataNumberOfDaysBack":60,"statusViewerId":0,"fileSizeInMB":100,"PDFPath":"","actionType":"DELETE"}

			*/

        try {
            FileDataArguments arguments = null;
            LOGGER.info("PacbioFileDataOrganizer Arguments: {}", Arrays.toString(args));
            String argsString = Arrays.toString(args);
            argsString = argsString.replaceAll("[\\{\\}\\[\\]]", "");
            args = argsString.split(",");
            LOGGER.info("args all: {}", Arrays.toString(args));
            arguments = new FileDataArguments();
            setValuesFromArgsArray(arguments, args);

            if (arguments.getActionType().equals(String.valueOf(ActionType.DELETE))) {
                FileDeleteService.deleteFileOrFolderByPath(arguments);
            } else {
                String decodeSourcetDir = URLDecoder.decode(arguments.getSourceDirectory(), StandardCharsets.UTF_8.name());
                arguments.setSourceDirectory(decodeSourcetDir);
                String decodeDestDir = URLDecoder.decode(arguments.getDestinationDirectory(), StandardCharsets.UTF_8.name());
                arguments.setDestinationDirectory(decodeDestDir);
                FileCopyOrMoveService.fileDataOrganizerActions(arguments);
            }

        } catch (Exception e) {
            LOGGER.error("Error :" + e.getMessage());
        }
    }

    public static void setValuesFromArgsArray(Object obj, String[] args) {
        Class<?> clazz = obj.getClass();
        for (String arg : args) {
            String[] keyValue = arg.split(":");
            if (keyValue.length == 2) {
                String key = keyValue[0].trim().replace("\"", "");
                String value = keyValue[1].trim().replace("\"", "");
                try {
                    Field field = clazz.getDeclaredField(key);
                    field.setAccessible(true);
                    setFieldValue(field, obj, value, key);
                } catch (NoSuchFieldException | IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private static void setFieldValue(Field field, Object obj, String value, String key) throws IllegalAccessException {
        if (field.getType().equals(Integer.class) || key.equals("statusViewerId") || key.equals("runId") || key.equals("userId")) {
            field.set(obj, Integer.valueOf(value));
        } else if (field.getType().equals(String.class)) {
            field.set(obj, value);
        } else if (field.getType().equals(Boolean.class)) {
            field.set(obj, Boolean.valueOf(value));
        } else if (field.getType().equals(Double.class)) {
            field.set(obj, Double.valueOf(value));
        }
    }
}
