package com.histo.pacbiofiledata.util;

import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.smbj.common.SmbPath;
import com.hierynomus.smbj.share.DiskShare;
import com.histo.pacbiofiledata.implementation.FileCopyOrMoveService;
import com.histo.pacbiofiledata.model.WGSErrorLogInput;
import com.histo.pacbiofiledata.model.WGSRunType;
import com.histo.pacbiofiledata.process.ConnectionIntermittent;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class PacbioUtil {
    private static final Logger logger = LogManager.getLogger(PacbioUtil.class);
    private static final ConnectionIntermittent connectionIntermittent = new ConnectionIntermittent();

    public static void deleteSourcePath(DiskShare diskShare, int wgsStatusViewerId, int deleteDataNumberOfDaysBack, String deletePath) {
        try {
            SmbPath sourceSmbPath = diskShare.getSmbPath();
            String fullPath = sourceSmbPath.toUncPath().concat("\\").concat(deletePath);
            fullPath = fullPath.replace("/", "\\");

            deletePath = deletePath.replace("\\", "/");

            String RAWorCCSData = getWGSRunTypeByStatusViewerId(wgsStatusViewerId);
            int typeId = 0;
            if (!StringUtils.isBlank(RAWorCCSData)) {
                typeId = Integer.parseInt(RAWorCCSData);
            }

            if (typeId == WGSRunType.RawData.value) {
                logger.info("Delete SourcePath is disabled due to Raw data :" + fullPath);
            } else if (typeId == WGSRunType.CCSData.value || typeId == WGSRunType.Unknown.value) {
                logger.info("SourcePath is ready to delete." + fullPath);
                connectionIntermittent.insertWGSErrorLogCall(
                        new WGSErrorLogInput(0, wgsStatusViewerId, "SourcePath is ready to delete." + fullPath,
                                "PacBioFileDataOrganizer"));
                logger.info("Delete started...");

                List<FileIdBothDirectoryInformation> listOfFiles = diskShare.list(deletePath.concat("/"));
                listOfFiles.removeIf(file -> file.getFileName().equals(".") || file.getFileName().equals(".."));
                for (FileIdBothDirectoryInformation file : listOfFiles) {
                    if (file.getFileName().equals(".") || file.getFileName().equals("..")) {
                        continue;
                    }
                    Date creationDate = diskShare.getFileInformation(deletePath.concat("/").concat(file.getFileName())).getBasicInformation().getCreationTime().toDate();
                    if (!isFileValidToDelete(creationDate, deleteDataNumberOfDaysBack)) {
                        logger.info("deleteSourcePath() info. File is not valid to delete. The creation time is not greater than delete no of days back. File:{}"
                                , fullPath.concat("\\").concat(file.getFileName()));
                        continue;
                    }
                    deletePath = deletePath.concat("/").concat(file.getFileName());
                    deletePath = deletePath.replace("//","/");
                    deletePath = deletePath.replace("\\","/");

                    // delete the file
                    FileCopyOrMoveService.deleteSmbFile(diskShare, deletePath);
                }
                logger.info("Deleted Successfully.");
                connectionIntermittent.insertWGSErrorLogCall(
                        new WGSErrorLogInput(0, wgsStatusViewerId, "SourcePath Path Deleted Successfully.",
                                "PacBioFileDataOrganizer"));
            } else {
                logger.info("Delete not works due to RunType is not RawData or CCSData. " + RAWorCCSData);
            }
        } catch (Exception e) {
            logger.error("Error :" + e.getMessage());
            connectionIntermittent.insertWGSErrorLogCall(
                    new WGSErrorLogInput(0, wgsStatusViewerId, e.getMessage(),
                            "PacBioFileDataOrganizer"));
        }

    }

    public static String getWGSRunTypeByStatusViewerId(int id) {
        String RawOrCCCData;
        ConnectionIntermittent connection = new ConnectionIntermittent();
        try {
            RawOrCCCData = connection.getWGSRunTypeApi(id);
            logger.info("Result after called getWGSRunTypeByStatusViewerId service :" + RawOrCCCData);

        } catch (Exception e) {
            logger.error("Error in getWGSRunTypeByStatusViewerId method :" + e.getMessage());
            RawOrCCCData = "Error";
        }
        return RawOrCCCData;
    }

    public static boolean isFileValidToDelete(Date creationDate, int deleteDataNumberOfDaysBack) {
        Date currentDate = new Date();

        long diffInMilliSeconds = Math.abs(currentDate.getTime() - creationDate.getTime());
        long diff = TimeUnit.DAYS.convert(diffInMilliSeconds, TimeUnit.MILLISECONDS);
        return diff >= deleteDataNumberOfDaysBack;
    }
}
