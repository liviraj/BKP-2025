package com.histo.pacbiofiledata.config;

import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import com.histo.pacbiofiledata.model.ActionType;
import com.histo.pacbiofiledata.model.FileDataArguments;

import java.io.IOException;

public class DiskShareConfig {
    private DiskShare sourceDiskShare;
    private DiskShare desDiskShare;
    private DiskShare deleteDiskShare;
    private static final String SMB_DOMAIN_NAME = "histogenetics.com";

    public DiskShareConfig(FileDataArguments arguments) {

        try {
            if (arguments.getActionType().equals(ActionType.DELETE.toString())) {
                SMBClient clientDelete = new SMBClient();
                Connection connectionDelete = clientDelete.connect(arguments.getDeleteServer());
                AuthenticationContext authContextDelete = new AuthenticationContext(arguments.getDeleteUserName(), arguments.getDeletePassword().toCharArray()
                        , SMB_DOMAIN_NAME);
                Session sessionDelete = connectionDelete.authenticate(authContextDelete);
                this.deleteDiskShare = (DiskShare) sessionDelete.connectShare(arguments.getDeleteShare());
            } else if (arguments.getActionType().equals(ActionType.MOVE.toString()) || arguments.getActionType().equals(ActionType.COPY.toString())){
                SMBClient clientSource = new SMBClient();
                Connection connectionSource = clientSource.connect(arguments.getSourceServer());
                AuthenticationContext authContextSource = new AuthenticationContext(arguments.getSourceUsername(), arguments.getSourcePassword().toCharArray()
                        , SMB_DOMAIN_NAME);
                Session sessionSource = connectionSource.authenticate(authContextSource);
                this.sourceDiskShare = (DiskShare) sessionSource.connectShare(arguments.getSourceShare());

                SMBClient clientDestination = new SMBClient();
                Connection connectionDestination = clientDestination.connect(arguments.getDestinationServer());
                AuthenticationContext authContextDestination = new AuthenticationContext(arguments.getDestinationUsername(), arguments.getDestinationPassword().toCharArray()
                        , SMB_DOMAIN_NAME);
                Session sessionDest = connectionDestination.authenticate(authContextDestination);
                this.desDiskShare = (DiskShare) sessionDest.connectShare(arguments.getDestinationShare());
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public DiskShare getSourceDiskShare() {
        return sourceDiskShare;
    }

    public void setSourceDiskShare(DiskShare sourceDiskShare) {
        this.sourceDiskShare = sourceDiskShare;
    }

    public DiskShare getDesDiskShare() {
        return desDiskShare;
    }

    public void setDesDiskShare(DiskShare desDiskShare) {
        this.desDiskShare = desDiskShare;
    }

    public DiskShare getDeleteDiskShare() {
        return deleteDiskShare;
    }

    public void setDeleteDiskShare(DiskShare deleteDiskShare) {
        this.deleteDiskShare = deleteDiskShare;
    }

    @Override
    public String toString() {
        return "DiskShareConfig{" +
                "sourceDiskShare=" + sourceDiskShare +
                ", desDiskShare=" + desDiskShare +
                ", deleteDiskShare=" + deleteDiskShare +
                '}';
    }
}
