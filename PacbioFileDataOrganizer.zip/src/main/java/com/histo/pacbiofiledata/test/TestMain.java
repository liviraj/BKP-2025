package com.histo.pacbiofiledata.test;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

public class TestMain {
    public static void main(String[] args) throws UnsupportedEncodingException {
        String encodedURL = "%2F%2FHistoNAS2.histogenetics.com%2FVolume1Backup%2FHistoNAS1Backup%2FClientSample%2FClemson+University%2Fruns%2FCIDER-seq_DGC48-77%2Fraw_data%2F";

        String decodedURL = URLDecoder.decode(encodedURL, StandardCharsets.UTF_8.name());

        String decodeDecodedURL = URLDecoder.decode(decodedURL, StandardCharsets.UTF_8.name());

        System.out.println(decodedURL+":::::"+decodeDecodedURL);
    }
}
