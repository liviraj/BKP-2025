package com.histo.pacbiofiledata.process;

import com.google.gson.Gson;
import com.histo.pacbiofiledata.model.*;
import okhttp3.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.net.ssl.*;
import java.io.IOException;
import java.security.cert.X509Certificate;
import java.util.Objects;

public class ConnectionIntermittent {
    private static final Logger logger = LogManager.getLogger(ConnectionIntermittent.class);

    public Response updateLocalTransferStatus(LocalTransferIdStatus localTransferIdStatus) {
        String json = new Gson().toJson(localTransferIdStatus);
        logger.info("updateLocalTransferStatus calling url is " + ConnectionURLParams.getWGSLocalTransferStatus());
        logger.info("body " + json);
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(json, mediaType);
//		RequestBody body = RequestBody.create(
//			      MediaType.parse("application/json"), json);
        OkHttpClient client = ConnectionIntermittent.getUnsafeOkHttpClient();
        Request request = new Request.Builder()
                .url(ConnectionURLParams.getWGSLocalTransferStatus())
                .method("POST", body)
                .addHeader("Content-Type", "application/json")
                .addHeader("Accept", "text/plain")
                .build();
        try {
            return client.newCall(request).execute();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;

    }

    public String getWGSRunTypeApi(int wgsStatusViewerId) {
        OkHttpClient client = ConnectionIntermittent.getUnsafeOkHttpClient();
        Request request = new Request.Builder()
                .url(ConnectionURLParams.getWGSRunType() + wgsStatusViewerId)
                .method("GET", null)
                .addHeader("Accept", "text/plain")
                .build();
        try {
            Response response = client.newCall(request).execute();
            return Objects.requireNonNull(response.body()).string();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return "Error";
        }

    }

    private static OkHttpClient getUnsafeOkHttpClient() {
        try {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        public void checkClientTrusted(java.security.cert.X509Certificate[] chain,
                                                       String authType) {
                        }

                        public void checkServerTrusted(java.security.cert.X509Certificate[] chain,
                                                       String authType) {
                        }

                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return new X509Certificate[0];
                        }
                    }
            };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            return new OkHttpClient.Builder()
                    .sslSocketFactory(sslSocketFactory, (X509TrustManager) trustAllCerts[0])
                    .hostnameVerifier((hostname, session) -> true).build();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public Response insertPacBioDataCall(PacBioDataModel pacBioData) {
        String json = new Gson().toJson(pacBioData);
        return callRequest(json, "insertPacBioDataCall", "POST", ConnectionURLParams.insertPacBioDataUrl());
    }

    public Response updateRawDataTransferStatusCall(RawDataTransferModel rawDataTransfer) {
        String json = new Gson().toJson(rawDataTransfer);
        return callRequest(json, "updateRawDataTransferStatusCall", "PUT", ConnectionURLParams.updateRawDataTransferStatusUrl());
    }

    public Response insertWGSErrorLogCall(WGSErrorLogInput errorLog) {
        String json = new Gson().toJson(errorLog);
        return callRequest(json, "insertWGSErrorLogCall", "POST", ConnectionURLParams.insertWGSErrorLogUrl());
    }

    public Response insertLogDetailCall(LogDetailModel logDetail) {
        String json = new Gson().toJson(logDetail);
        return callRequest(json, "insertLogDetailCall", "POST", ConnectionURLParams.insertLogDetailUrl());
    }

    private Response callRequest(String json, String requestName, String requestType, String url) {
        logger.info("{} url is {}", requestName, url);
        logger.info("body " + json);
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(json, mediaType);
        OkHttpClient client = ConnectionIntermittent.getUnsafeOkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .method(requestType, body)
                .addHeader("Content-Type", "application/json")
                .addHeader("Accept", "text/plain")
                .build();
        try {
            Response response = client.newCall(request).execute();
            return response;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

}
