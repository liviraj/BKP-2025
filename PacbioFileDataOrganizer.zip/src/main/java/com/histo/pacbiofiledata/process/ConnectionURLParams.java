package com.histo.pacbiofiledata.process;

public class ConnectionURLParams {
    //PacbioMiscellaneousWebService URL Details
    // private final static String PacbioBaseURL = "https://javawebag01.histogenetics.com:8765/WholeGenomeSequencing/wgs/";
    private final static String PacbioBaseURL = "https://webapiuat.histogenetics.com:8765/WholeGenomeSequencing/wgs/";
    // private final static String PacbioBaseURL = "http://histoasgqc:8080/PacbioMiscellaneousWebService/wgs/";
    // private final static String PacbioBaseURL = "http://localhost:8102/wgs/";

    public static String getWGSLocalTransferStatus() {
        return PacbioBaseURL + "wgsLocalTransferStatus";
    }

    public static String getWGSRunType() {
        return PacbioBaseURL + "WGSRunType/";
    }

    public static String insertPacBioDataUrl() {
        return PacbioBaseURL + "pacBioJobData";
    }
    public static String updateRawDataTransferStatusUrl() {
        return PacbioBaseURL + "rawDataTransferStatus";
    }
    public static String insertWGSErrorLogUrl() {
        return PacbioBaseURL + "errorLog";
    }
    public static String insertLogDetailUrl() {
        return PacbioBaseURL + "logDetail";
    }

}
