package com.histo.pacbiofiledata.serviceinterface;

import com.histo.pacbiofiledata.model.FileDataArguments;

public interface FileCopyToDestFolderRepository {
	String FileCopyToDestFolder(FileDataArguments fileDataArguments);

}
