package com.histo.pacbiofiledata.model;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

public class FileDataArguments {
    private String sourceServer;
    private String destinationServer;
    private String sourceShare;
    private String destinationShare;
    private String sourceDirectory;
    private String destinationDirectory;
    private String sourceUsername;
    private String sourcePassword;
    private String destinationUsername;
    private String destinationPassword;
    private int copyDataNumberOfDaysBack = 365;
    private int statusViewerId = 0; //if status !=0 then just copy the folder not deleted(WGS)
    private int fileSizeInMB;
    private String pdfPath;
    private String actionType;
    private String deleteServer;
    private String deleteShare;
    private String deleteLocation;
    private String deleteUserName;
    private String deletePassword;
    private int deleteDataNumberOfDaysBack = 60;

    public String getSourceServer() {
        return sourceServer;
    }

    public void setSourceServer(String sourceServer) {
        this.sourceServer = sourceServer;
    }

    public String getDestinationServer() {
        return destinationServer;
    }

    public void setDestinationServer(String destinationServer) {
        this.destinationServer = destinationServer;
    }

    public String getSourceShare() {
        return sourceShare;
    }

    public void setSourceShare(String sourceShare) {
        this.sourceShare = sourceShare;
    }

    public String getDestinationShare() {
        return destinationShare;
    }

    public void setDestinationShare(String destinationShare) {
        this.destinationShare = destinationShare;
    }

    public String getSourceDirectory() {
        return sourceDirectory;
    }

    public void setSourceDirectory(String sourceDirectory) {
        try {
            this.sourceDirectory = URLDecoder.decode(sourceDirectory, StandardCharsets.UTF_8.name());
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
    }

    public String getDestinationDirectory() {
        return destinationDirectory;
    }

    public void setDestinationDirectory(String destinationDirectory) {
        try {
            this.destinationDirectory = URLDecoder.decode(destinationDirectory, StandardCharsets.UTF_8.name());
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
    }

    public String getSourceUsername() {
        return sourceUsername;
    }

    public void setSourceUsername(String sourceUsername) {
        this.sourceUsername = sourceUsername;
    }

    public String getSourcePassword() {
        return sourcePassword;
    }

    public void setSourcePassword(String sourcePassword) {
        this.sourcePassword = sourcePassword;
    }

    public String getDestinationUsername() {
        return destinationUsername;
    }

    public void setDestinationUsername(String destinationUsername) {
        this.destinationUsername = destinationUsername;
    }

    public String getDestinationPassword() {
        return destinationPassword;
    }

    public void setDestinationPassword(String destinationPassword) {
        this.destinationPassword = destinationPassword;
    }

    public int getCopyDataNumberOfDaysBack() {
        return copyDataNumberOfDaysBack;
    }

    public void setCopyDataNumberOfDaysBack(int copyDataNumberOfDaysBack) {
        this.copyDataNumberOfDaysBack = copyDataNumberOfDaysBack;
    }

    public int getStatusViewerId() {
        return statusViewerId;
    }

    public void setStatusViewerId(int statusViewerId) {
        this.statusViewerId = statusViewerId;
    }

    public int getFileSizeInMB() {
        return fileSizeInMB;
    }

    public void setFileSizeInMB(int fileSizeInMB) {
        this.fileSizeInMB = fileSizeInMB;
    }

    public String getPdfPath() {
        return pdfPath;
    }

    public void setPdfPath(String pdfPath) {
        this.pdfPath = pdfPath;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public String getDeleteServer() {
        return deleteServer;
    }

    public void setDeleteServer(String deleteServer) {
        this.deleteServer = deleteServer;
    }

    public String getDeleteShare() {
        return deleteShare;
    }

    public void setDeleteShare(String deleteShare) {
        this.deleteShare = deleteShare;
    }

    public String getDeleteLocation() {
        return deleteLocation;
    }

    public void setDeleteLocation(String deleteLocation) {
        try {
            this.deleteLocation = URLDecoder.decode(deleteLocation, StandardCharsets.UTF_8.name());
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
    }

    public String getDeleteUserName() {
        return deleteUserName;
    }

    public void setDeleteUserName(String deleteUserName) {
        this.deleteUserName = deleteUserName;
    }

    public String getDeletePassword() {
        return deletePassword;
    }

    public void setDeletePassword(String deletePassword) {
        this.deletePassword = deletePassword;
    }

    public int getDeleteDataNumberOfDaysBack() {
        return deleteDataNumberOfDaysBack;
    }

    public void setDeleteDataNumberOfDaysBack(int deleteDataNumberOfDaysBack) {
        this.deleteDataNumberOfDaysBack = deleteDataNumberOfDaysBack;
    }

    @Override
    public String toString() {
        return "FileDataArguments{" +
                "sourceServer='" + sourceServer + '\'' +
                ", destinationServer='" + destinationServer + '\'' +
                ", sourceShare='" + sourceShare + '\'' +
                ", destinationShare='" + destinationShare + '\'' +
                ", sourceLocation='" + sourceDirectory + '\'' +
                ", destinationLocation='" + destinationDirectory + '\'' +
                ", sourceUsername='" + sourceUsername + '\'' +
                ", sourcePassword='" + sourcePassword + '\'' +
                ", destinationUsername='" + destinationUsername + '\'' +
                ", destinationPassword='" + destinationPassword + '\'' +
                ", copyDataNumberOfDaysBack=" + copyDataNumberOfDaysBack +
                ", statusViewerId=" + statusViewerId +
                ", fileSizeInMB=" + fileSizeInMB +
                ", PDFPath='" + pdfPath + '\'' +
                ", actionType='" + actionType + '\'' +
                ", deleteServer='" + deleteServer + '\'' +
                ", deleteShare='" + deleteShare + '\'' +
                ", deleteLocation='" + deleteLocation + '\'' +
                ", deleteUserName='" + deleteUserName + '\'' +
                ", deletePassword='" + deletePassword + '\'' +
                ", deleteDataNumberOfDaysBack=" + deleteDataNumberOfDaysBack +
                '}';
    }
}
