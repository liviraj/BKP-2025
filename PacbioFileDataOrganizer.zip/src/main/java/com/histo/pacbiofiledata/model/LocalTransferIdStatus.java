package com.histo.pacbiofiledata.model;

public class LocalTransferIdStatus {
	private int wgsStatusViewerId;
	private int status;
	private String sourcePath;
	private int uploadTypeId;
	private String failureReason;
	
	public int getWgsStatusViewerId() {
		return wgsStatusViewerId;
	}
	public void setWgsStatusViewerId(int wgsStatusViewerId) {
		this.wgsStatusViewerId = wgsStatusViewerId;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getSourcePath() {
		return sourcePath;
	}
	public void setSourcePath(String sourcePath) {
		this.sourcePath = sourcePath;
	}
	public int getUploadTypeId() {
		return uploadTypeId;
	}
	public void setUploadTypeId(int uploadTypeId) {
		this.uploadTypeId = uploadTypeId;
	}
	public String getFailureReason() {
		return failureReason;
	}
	public void setFailureReason(String failureReason) {
		this.failureReason = failureReason;
	}
	
	
}
