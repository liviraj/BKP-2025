package com.histo.pacbiofiledata.model;

public enum ActionType {
    COPY, MOVE, DELETE

}
