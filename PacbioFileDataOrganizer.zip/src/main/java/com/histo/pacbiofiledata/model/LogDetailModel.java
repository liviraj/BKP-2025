package com.histo.pacbiofiledata.model;

public class LogDetailModel {
    private Integer logDetailId;
    private String actionType;
    private String sourceLocation;
    private String destinationLocation;
    private String deleteLocation;
    private String status;
    private String program;

    public LogDetailModel() {
    }

    public LogDetailModel(String actionType, String sourceLocation, String destinationLocation, String deleteLocation, String status, String program) {
        this.actionType = actionType;
        this.sourceLocation = sourceLocation;
        this.destinationLocation = destinationLocation;
        this.deleteLocation = deleteLocation;
        this.status = status;
        this.program = program;
    }

    public Integer getLogDetailId() {
        return logDetailId;
    }

    public void setLogDetailId(Integer logDetailId) {
        this.logDetailId = logDetailId;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public String getSourceLocation() {
        return sourceLocation;
    }

    public void setSourceLocation(String sourceLocation) {
        this.sourceLocation = sourceLocation;
    }

    public String getDestinationLocation() {
        return destinationLocation;
    }

    public void setDestinationLocation(String destinationLocation) {
        this.destinationLocation = destinationLocation;
    }

    public String getDeleteLocation() {
        return deleteLocation;
    }

    public void setDeleteLocation(String deleteLocation) {
        this.deleteLocation = deleteLocation;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }

    @Override
    public String toString() {
        return "LogDetail{" +
                "logDetailId=" + logDetailId +
                ", actionType='" + actionType + '\'' +
                ", sourceLocation='" + sourceLocation + '\'' +
                ", destinationLocation='" + destinationLocation + '\'' +
                ", deleteLocation='" + deleteLocation + '\'' +
                ", status='" + status + '\'' +
                ", program='" + program + '\'' +
                '}';
    }
}
