package com.histo.pacbiofiledata.model;

public class PacBioDataModel {
    private String dataLocationOld;
    private String jobID;
    private String dataLocation;
    private Integer isVerified;
    private String failedReason;

    public PacBioDataModel() {
    }

    public PacBioDataModel(String dataLocationOld, String jobID, String dataLocation, Integer isVerified, String failedReason) {
        this.dataLocationOld = dataLocationOld;
        this.jobID = jobID;
        this.dataLocation = dataLocation;
        this.isVerified = isVerified;
        this.failedReason = failedReason;
    }

    public String getDataLocationOld() {
        return dataLocationOld;
    }

    public void setDataLocationOld(String dataLocationOld) {
        this.dataLocationOld = dataLocationOld;
    }

    public String getJobID() {
        return jobID;
    }

    public void setJobID(String jobID) {
        this.jobID = jobID;
    }

    public String getDataLocation() {
        return dataLocation;
    }

    public void setDataLocation(String dataLocation) {
        this.dataLocation = dataLocation;
    }

    public Integer getIsVerified() {
        return isVerified;
    }

    public void setIsVerified(Integer isVerified) {
        this.isVerified = isVerified;
    }

    public String getFailedReason() {
        return failedReason;
    }

    public void setFailedReason(String failedReason) {
        this.failedReason = failedReason;
    }

    @Override
    public String toString() {
        return "PacBioDataModel{" +
                "dataLocationOld='" + dataLocationOld + '\'' +
                ", jobID='" + jobID + '\'' +
                ", dataLocation='" + dataLocation + '\'' +
                ", isVerified=" + isVerified +
                ", failedReason='" + failedReason + '\'' +
                '}';
    }
}
