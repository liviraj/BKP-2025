package com.histo.pacbiofiledata.model;

public class RawDataTransferModel {
    private int wgsStatusViewerId;
    private int status;

    public RawDataTransferModel() {
    }

    public RawDataTransferModel(int wgsStatusViewerId, int status) {
        this.wgsStatusViewerId = wgsStatusViewerId;
        this.status = status;
    }

    public int getWgsStatusViewerId() {
        return wgsStatusViewerId;
    }

    public void setWgsStatusViewerId(int wgsStatusViewerId) {
        this.wgsStatusViewerId = wgsStatusViewerId;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "RawDataTransferModel{" +
                "wgsStatusViewerId=" + wgsStatusViewerId +
                ", status=" + status +
                '}';
    }
}
