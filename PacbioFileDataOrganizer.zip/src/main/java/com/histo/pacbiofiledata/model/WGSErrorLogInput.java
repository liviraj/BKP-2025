package com.histo.pacbiofiledata.model;

public class WGSErrorLogInput {
	private int wgsRunId;
	private int wgsStatusViewerId;
	private String logInfo;
	private String programName;

	public WGSErrorLogInput(int wgsRunId, int wgsStatusViewerId, String logInfo, String programName) {
		this.wgsRunId = wgsRunId;
		this.wgsStatusViewerId = wgsStatusViewerId;
		this.logInfo = logInfo;
		this.programName = programName;
	}

	public int getWgsRunId() {
		return wgsRunId;
	}
	public void setWgsRunId(int wGSRunID) {
		wgsRunId = wGSRunID;
	}
	public int getWgsStatusViewerId() {
		return wgsStatusViewerId;
	}
	public void setWgsStatusViewerId(int wGSStatusViewerID) {
		wgsStatusViewerId = wGSStatusViewerID;
	}
	public String getLogInfo() {
		return logInfo;
	}
	public void setLogInfo(String logInfo) {
		this.logInfo = logInfo;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	

}
