package com.histo.pacbiofiledata.model;

public enum WGSRunType {
	Unknown(0), RawData(1), CCSData(2);

	public Integer value;

	WGSRunType(int typeId) {
		this.value = typeId;
	}

	public static WGSRunType getValue(int val) {
		switch (val) {
		case 1:
			return WGSRunType.RawData;
		case 2:
			return WGSRunType.CCSData;
		default:
			return WGSRunType.Unknown; // Keep an default or error enum handy
		}
	}

}
