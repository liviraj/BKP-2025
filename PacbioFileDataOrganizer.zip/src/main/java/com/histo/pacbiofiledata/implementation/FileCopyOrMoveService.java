package com.histo.pacbiofiledata.implementation;

import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.fileinformation.FileAllInformation;
import com.hierynomus.msfscc.fileinformation.FileDirectoryQueryableInformation;
import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.mssmb2.SMBApiException;
import com.hierynomus.smbj.common.SmbPath;
import com.hierynomus.smbj.share.DiskShare;
import com.hierynomus.smbj.share.File;
import com.histo.pacbiofiledata.config.DiskShareConfig;
import com.histo.pacbiofiledata.model.*;
import com.histo.pacbiofiledata.process.ConnectionIntermittent;
import com.histo.pacbiofiledata.serviceinterface.FileCopyToDestFolderRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.net.MalformedURLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.stream.Collectors;

//@Service
public class FileCopyOrMoveService implements FileCopyToDestFolderRepository {

    private static final Logger logger = LogManager.getLogger(FileCopyOrMoveService.class);
    private static final ConnectionIntermittent connectionIntermittent = new ConnectionIntermittent();

    public FileCopyOrMoveService() {
    }

    @Override
    public String FileCopyToDestFolder(FileDataArguments fileDataArguments) {
        String result;
        try {
            result = fileDataOrganizerActions(fileDataArguments);
        } catch (IOException e) {
            e.printStackTrace();
            result = e.getMessage();
        }
        return result;
    }

    public static String fileDataOrganizerActions(FileDataArguments fileDataArguments) throws MalformedURLException {
        try {
            long startTime = System.currentTimeMillis();
            DiskShareConfig diskShareConfig = new DiskShareConfig(fileDataArguments);

            SmbPath sourceSmbPath = diskShareConfig.getSourceDiskShare().getSmbPath();
            String sourceParentPath = sourceSmbPath.toUncPath().concat("\\").concat(fileDataArguments.getSourceDirectory());
            sourceParentPath = sourceParentPath.replace("/", "\\");
            SmbPath destinationSmbPath = diskShareConfig.getDesDiskShare().getSmbPath();
            String destinationParentPath = destinationSmbPath.toUncPath().concat("\\").concat(fileDataArguments.getDestinationDirectory());
            destinationParentPath = destinationParentPath.replace("/", "\\");

            if (!fileDataArguments.getSourceDirectory().endsWith("/")) {
                fileDataArguments.setSourceDirectory(fileDataArguments.getSourceDirectory().concat("/"));
            }
            if (!fileDataArguments.getDestinationDirectory().endsWith("/")) {
                fileDataArguments.setDestinationDirectory(fileDataArguments.getDestinationDirectory().concat("/"));
            }
            boolean isSourceFolderExist = diskShareConfig.getSourceDiskShare().folderExists(fileDataArguments.getSourceDirectory().replace("\\", "/"));
            if (!isSourceFolderExist) {
                logger.error("Failed: Invalid Source Folder -> {}", sourceParentPath);
                if (fileDataArguments.getStatusViewerId() != 0) {
                    WGSErrorLogInput errorLog = new WGSErrorLogInput(0, fileDataArguments.getStatusViewerId()
                            , "Failed: Invalid Source Folder -> " + sourceParentPath, "PacBioFileDataOrganizer");
                    connectionIntermittent.insertWGSErrorLogCall(errorLog);
                } else {
                    FileCopyOrMoveService.doLoggingDetails(fileDataArguments);
                }
                return "Failed";
            }

            boolean isDestinationFolderExist = diskShareConfig.getDesDiskShare().folderExists(fileDataArguments.getDestinationDirectory().replace("\\", "/"));
            if (!isDestinationFolderExist && fileDataArguments.getStatusViewerId() == 0) {
                logger.error("Failed: Invalid Destination Folder -> " + destinationParentPath);
                if (fileDataArguments.getStatusViewerId() != 0) {
                    WGSErrorLogInput errorLog = new WGSErrorLogInput(0, fileDataArguments.getStatusViewerId()
                            , "Failed: Invalid Destination Folder -> " + destinationParentPath, "PacBioFileDataOrganizer");
                    connectionIntermittent.insertWGSErrorLogCall(errorLog);
                } else {
                    FileCopyOrMoveService.doLoggingDetails(fileDataArguments);
                }
                return "Failed";
            }
            FileAllInformation sourceFileInformation = diskShareConfig.getSourceDiskShare().getFileInformation(fileDataArguments.getSourceDirectory().replace("\\", "/"));
            boolean isSourceDirectory = sourceFileInformation.getStandardInformation().isDirectory();
            if (!isSourceDirectory) {
                logger.info("Failed: Its a file not a directory : {}", sourceParentPath);
                return "Failed";
            }

            if (fileDataArguments.getStatusViewerId() != 0) {
                WGSFileCopyService.wgsFileOrFolderCopy(fileDataArguments, diskShareConfig);
                long endTime = System.currentTimeMillis();
                logger.info("Total time taken for transfer (in secs): " + (endTime - startTime) / 1000.0);
                return "Success";
            } else {
                return FileCopyOrMoveService.copyAndMoveBasedOnDate(fileDataArguments, diskShareConfig);
            }

        } catch (Exception e) {
            FileCopyOrMoveService.errorLog(fileDataArguments, e, logger);
            return "Failure";
        }
    }

    private static String copyAndMoveBasedOnDate(FileDataArguments fileDataArguments, DiskShareConfig diskShareConfig) throws IOException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        LocalDate todayDate = LocalDate.now();
        // LocalDate todayDate = LocalDate.of(2023, 12, 1);
        LocalDate startDate = todayDate.minusDays(fileDataArguments.getCopyDataNumberOfDaysBack());

        List<FileIdBothDirectoryInformation> directoryInformationList = diskShareConfig.getSourceDiskShare().list(fileDataArguments.getSourceDirectory());
        directoryInformationList.removeIf(directoryInformation -> directoryInformation.getFileName().equals(".") || directoryInformation.getFileName().equals(".."));
        List<FileIdBothDirectoryInformation> fileList = diskShareConfig.getSourceDiskShare().list(fileDataArguments.getSourceDirectory())
                .stream().filter(fileIdBothDirectoryInformation ->
                        {
                            logger.info("Path: {}", fileIdBothDirectoryInformation.getFileName());
                            logger.info("Creation Time: {}", LocalDate.parse(sdf.format(
                                    fileIdBothDirectoryInformation.getCreationTime().toDate()
                            )));
                            return LocalDate.parse(sdf.format(
                                    fileIdBothDirectoryInformation.getCreationTime().toDate()
                            )).isBefore(startDate);
                        }
                ).sorted(Comparator.comparing(FileDirectoryQueryableInformation::getFileName)).collect(Collectors.toList());
        fileList.removeIf(file -> file.getFileName().equals(".") || file.getFileName().equals(".."));
        if (fileList.size() == 0) {
            logger.error("Failed: Source folder is Empty or No data to copy in given period");
            return "Failed";
        }
        for (FileIdBothDirectoryInformation f : fileList) {
            if (f.getFileName().equals(".") || f.getFileName().equals("..")) {
                continue;
            }

            String sourcePath = fileDataArguments.getSourceDirectory().concat("/").concat(f.getFileName());
            sourcePath = sourcePath.replace("//", "/");
            String desPath = fileDataArguments.getDestinationDirectory().concat("/").concat(f.getFileName());
            desPath = desPath.replace("//", "/");
            long sourceFolderSize = getFileOrFolderSize(diskShareConfig.getSourceDiskShare(), sourcePath);
            long diskSpaceFree = diskShareConfig.getSourceDiskShare().getShareInformation().getTotalSpace();
            if (diskSpaceFree > sourceFolderSize) {
                long destFolderSizeIfExist = 0;
                boolean isDestinationFileOrFolderExist = false;
                if (!f.getFileName().contains(".")) {
                    boolean destPathExist = diskShareConfig.getDesDiskShare().folderExists(desPath);
                    if (!destPathExist) {
                        diskShareConfig.getDesDiskShare().mkdir(desPath);
                    } else {
                        isDestinationFileOrFolderExist = true;
                        destFolderSizeIfExist = getFileOrFolderSize(diskShareConfig.getDesDiskShare(), desPath);
                        continue;
                    }
                } else {
                    boolean isDestFileExist = diskShareConfig.getDesDiskShare().folderExists(desPath);
                    if (isDestFileExist) {
                        isDestinationFileOrFolderExist = true;
                        destFolderSizeIfExist = getFileOrFolderSize(diskShareConfig.getDesDiskShare(), desPath);
                        continue;
                    }
                }
                if (isDestinationFileOrFolderExist) {
                    if (sourceFolderSize != destFolderSizeIfExist) {
                        logger.error("Destination folder/file already exist and file sizes are different between source(" + sourceFolderSize + ") and destination(" + destFolderSizeIfExist + ") path.");
                        continue; //skip other operations
                    }
                }
                String sourceParentPath = diskShareConfig.getSourceDiskShare().getSmbPath().toUncPath().concat("\\") + fileDataArguments.getSourceDirectory().concat("/").concat(f.getFileName());
                sourceParentPath = sourceParentPath.replace("//", "/");
                sourceParentPath = sourceParentPath.replace("/", "\\");
                logger.info(sourceParentPath + " -> Copying..");
                WGSFileCopyService.doSmbFileCopy(sourcePath, desPath, diskShareConfig.getSourceDiskShare(), diskShareConfig.getDesDiskShare());
                logger.info(sourceParentPath + " -> Copied");
                long destFolderSizeAfterCopied = getFileOrFolderSize(diskShareConfig.getDesDiskShare(), desPath);
                logger.info("Source and Destination file sizes are : " + sourceFolderSize + " "
                        + destFolderSizeAfterCopied);

                if (sourceFolderSize == destFolderSizeAfterCopied) {
                    // delete only happen for move operation
                    if (fileDataArguments.getActionType().equals(String.valueOf(ActionType.COPY))) {
                        continue;
                    }
                    logger.info("File sizes are same : Ready to delete...");
                    try {
                        //f.delete();
                        deleteSmbFile(diskShareConfig.getSourceDiskShare(), sourcePath);
                        logger.info(sourceParentPath + " -> Deleted Successfully.");

                        //insert the data to table
                        String destPath = fileDataArguments.getDestinationServer().concat("\\").concat(fileDataArguments.getDestinationShare()).concat("\\")
                                .concat(fileDataArguments.getDestinationDirectory());
                        PacBioDataModel pacBioData = new PacBioDataModel(sourceParentPath,
                                f.getFileName().replace("/", ""), destPath.replace("/", "\\"), 1, "");
                        connectionIntermittent.insertPacBioDataCall(pacBioData);

                    } catch (Exception e) {
                        logger.error("Exception: File copied but issue in deleting : {}", e.getMessage());
                    }
                } else {
                    logger.error("Failed: Folder sizes are different : Folder not deleted.");
                }
            } else {
                logger.error("Failed: No Disk Space to copy");
            }
        }
        return "Success";
    }

    private static void doLoggingDetails(FileDataArguments fileDataArguments) {
        String sourcePath = "\\\\" + fileDataArguments.getSourceServer().concat("\\").concat(fileDataArguments.getSourceShare()).concat("\\")
                .concat(fileDataArguments.getSourceDirectory());
        String destPath = "\\\\" + fileDataArguments.getDestinationServer().concat("\\").concat(fileDataArguments.getDestinationShare()).concat("\\")
                .concat(fileDataArguments.getDestinationDirectory());

        LogDetailModel logDetail = new LogDetailModel(fileDataArguments.getActionType()
                , sourcePath.replace("/", "\\")
                , destPath.replace("/", "\\")
                , fileDataArguments.getDeleteLocation()
                , "Failed"
                , "PacbioFileDataOrganizer"
        );
        connectionIntermittent.insertLogDetailCall(logDetail);
    }

    public static void errorLog(FileDataArguments fileDataArguments, Exception e, Logger logger) {
        String errorMsg;
        if (e.getMessage().contains("account is currently locked out")) {
            errorMsg = "Exception: Account is locked due to You have tried to access with wrong user name for multiple times. Please try after 30 minus from now.";
            logger.error(errorMsg);

        } else if (e.getMessage().contains("unknown user name or bad password")) {
            errorMsg = "Exception: Please check UserName/Password/HostName you have tried :"
                    + fileDataArguments.getSourceUsername() + " or " + fileDataArguments.getDestinationUsername();
            logger.error(errorMsg);
        } else {
            logger.error(e.getMessage());
        }
    }

    public static long getFileOrFolderSize(DiskShare share, String directoryPath) throws SMBApiException {
        long totalSize = 0;
        directoryPath = directoryPath.replace(share.getSmbPath().toUncPath(), "");
        directoryPath = directoryPath.replace("\\", "/");
        boolean isDirectory = share.getFileInformation(directoryPath).getStandardInformation().isDirectory();
        if (!isDirectory) {
            File file = share.openFile(directoryPath, EnumSet.of(
                            AccessMask.GENERIC_READ)
                    , null
                    , SMB2ShareAccess.ALL
                    , SMB2CreateDisposition.FILE_OPEN
                    , null);
            totalSize += file.getFileInformation().getStandardInformation().getEndOfFile();
            file.closeSilently();
            return totalSize;
        }
        for (FileIdBothDirectoryInformation fileInfo : share.list(directoryPath)) {
            String fileName = fileInfo.getFileName();
            if (fileName.equals(".") || fileName.equals("..")) {
                continue;
            }

            String filePath = directoryPath + "/" + fileName;
            if (!fileInfo.getFileName().contains(".")) {
                totalSize += getFileOrFolderSize(share, filePath);
            } else {
                File file = share.openFile(filePath, EnumSet.of(
                                AccessMask.GENERIC_READ)
                        , null
                        , SMB2ShareAccess.ALL
                        , SMB2CreateDisposition.FILE_OPEN
                        , null);
                totalSize += file.getFileInformation().getStandardInformation().getEndOfFile();
                file.closeSilently();
            }
        }
        return totalSize;
    }

    public static void deleteSmbFile(DiskShare diskShare, String deletePath) {
        boolean isDirectory = diskShare.getFileInformation(deletePath).getStandardInformation().isDirectory();
        if (isDirectory) {
            diskShare.rmdir(deletePath, true);
        } else {
            diskShare.rm(deletePath);
        }
    }
}
