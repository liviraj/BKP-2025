package com.histo.pacbiofiledata.implementation;

import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.common.SmbPath;
import com.hierynomus.smbj.share.DiskShare;
import com.histo.pacbiofiledata.config.DiskShareConfig;
import com.histo.pacbiofiledata.model.ActionType;
import com.histo.pacbiofiledata.model.FileDataArguments;
import com.histo.pacbiofiledata.model.LocalTransferIdStatus;
import com.histo.pacbiofiledata.model.WGSErrorLogInput;
import com.histo.pacbiofiledata.process.ConnectionIntermittent;
import com.histo.pacbiofiledata.util.PacbioUtil;
import okhttp3.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class WGSFileCopyService {
    private static final Logger logger = LogManager.getLogger(WGSFileCopyService.class);
    private static final ConnectionIntermittent connectionIntermittent = new ConnectionIntermittent();

    public static void wgsFileOrFolderCopy(FileDataArguments fileDataArguments, DiskShareConfig diskShareConfig) {
        SmbPath sourceSmbPath = diskShareConfig.getSourceDiskShare().getSmbPath();
        String sourceParentPath = sourceSmbPath.toUncPath().concat("\\").concat(fileDataArguments.getSourceDirectory());
        sourceParentPath = sourceParentPath.replace("/", "\\");
        SmbPath destinationSmbPath = diskShareConfig.getDesDiskShare().getSmbPath();
        String destinationParentPath = destinationSmbPath.toUncPath().concat("\\").concat(fileDataArguments.getDestinationDirectory());
        destinationParentPath = destinationParentPath.replace("/", "\\");
        try {
            logger.info("WGS file copy2 ...");
            logger.info("Source : {}", sourceParentPath);
            logger.info("dest : {}", destinationParentPath);
            WGSErrorLogInput errorLog = new WGSErrorLogInput(0, fileDataArguments.getStatusViewerId(), "Copy process started",
                    "PacBioFileDataOrganizer");
            connectionIntermittent.insertWGSErrorLogCall(errorLog);
            pacBioServiceTransferStatusUpdate(setStatusDetails(fileDataArguments.getStatusViewerId(), 2,
                    destinationParentPath, ""));

           // find the source directory folder size(skip files)
            List<FileIdBothDirectoryInformation> sourceDirectoryInformationList = diskShareConfig.getSourceDiskShare().list(fileDataArguments.getSourceDirectory());
            sourceDirectoryInformationList.removeIf(directoryInformation -> directoryInformation.getFileName().equals(".") || directoryInformation.getFileName().equals(".."));
            sourceDirectoryInformationList.removeIf(file -> diskShareConfig.getSourceDiskShare()
                    .fileExists(fileDataArguments.getSourceDirectory()
                            .concat(file.getFileName())));
            long sourceFolderSize = 0;
            for (FileIdBothDirectoryInformation directoryInfo : sourceDirectoryInformationList) {
                sourceFolderSize +=  FileCopyOrMoveService.getFileOrFolderSize(diskShareConfig.getSourceDiskShare()
                        , fileDataArguments.getSourceDirectory().concat(directoryInfo.getFileName()).concat("/"));
            }

            long diskSpaceFree = diskShareConfig.getSourceDiskShare().getShareInformation().getFreeSpace();
            if (diskSpaceFree > sourceFolderSize) {
                boolean isDestinationExist = diskShareConfig.getDesDiskShare().folderExists(fileDataArguments.getDestinationDirectory().replace("\\", "/"));
                if (!isDestinationExist) {
                    // create not existing path in destination location
                    List<String> destinationSplit = Arrays.stream(fileDataArguments.getDestinationDirectory().replace("\\", "/").split("/"))
                            .filter(path -> !path.equalsIgnoreCase(""))
                            .collect(Collectors.toList());
                    String destShareRunPath = "";
                    for (String path : destinationSplit) {
                        destShareRunPath = destShareRunPath.concat(path).concat("/");
                        boolean isDestPathExist = diskShareConfig.getDesDiskShare().folderExists(destShareRunPath);
                        if (!isDestPathExist) {
                            diskShareConfig.getDesDiskShare().mkdir(destShareRunPath);
                        }
                    }
                } else {
                    if (sourceFolderSize == FileCopyOrMoveService
                            .getFileOrFolderSize(diskShareConfig.getDesDiskShare(), fileDataArguments.getDestinationDirectory())) {
                        logger.info("Destination Already Exit with All data");
                        // delete only happen for move operation
//							if (fileMoveArguments.getActionType().equals(String.valueOf(ActionType.MOVE.getAction()))) {
//								deleteSourcePath(sourceDir,fileMoveArguments.getStatusViewerId());
//							}
                        pacBioServiceTransferStatusUpdate(setStatusDetails(fileDataArguments.getStatusViewerId(), 3,
                                destinationParentPath, ""));
                        connectionIntermittent.insertWGSErrorLogCall(
                                new WGSErrorLogInput(0, fileDataArguments.getStatusViewerId(), "Destination Already Exit with All data",
                                        "PacBioFileDataOrganizer"));

                        return;
                    }
                }

                for (FileIdBothDirectoryInformation directoryInfo : sourceDirectoryInformationList) {
                    String sourcePath = fileDataArguments.getSourceDirectory().concat(directoryInfo.getFileName()).concat("/");
                    boolean isFile = diskShareConfig.getDesDiskShare().fileExists(fileDataArguments.getDestinationDirectory().concat(directoryInfo.getFileName()));
                    String destinationPath = null;
                    if (isFile) {
                        destinationPath = fileDataArguments.getDestinationDirectory().concat(directoryInfo.getFileName());
                    } else {
                        destinationPath = fileDataArguments.getDestinationDirectory().concat(directoryInfo.getFileName()).concat("/");
                    }

                    if (!fileDataArguments.getDestinationDirectory().contains("ccs_data")) {
                        destinationPath = fileDataArguments.getDestinationDirectory().concat(directoryInfo.getFileName()).concat("/");
                    }

                    boolean destPathExist = diskShareConfig.getDesDiskShare().folderExists(destinationPath);
                    if (!destPathExist) {
                        diskShareConfig.getDesDiskShare().mkdir(destinationPath);
                    }
                    // copy file/folder source to destination
                    doSmbFileCopy(sourcePath
                            , destinationPath
                            , diskShareConfig.getSourceDiskShare()
                            , diskShareConfig.getDesDiskShare());
                }

                logger.info("Completed");
                long destinationFolderSize = FileCopyOrMoveService.getFileOrFolderSize(diskShareConfig.getDesDiskShare(), fileDataArguments.getDestinationDirectory());
                if (sourceFolderSize == destinationFolderSize) {
                    // delete only happen for move operation
                    if (fileDataArguments.getActionType().equals(String.valueOf(ActionType.MOVE))) {
                        PacbioUtil.deleteSourcePath(diskShareConfig.getSourceDiskShare(), fileDataArguments.getStatusViewerId()
                                , fileDataArguments.getCopyDataNumberOfDaysBack(), fileDataArguments.getSourceDirectory());
                    }
                } else {
                    logger.info("SourcePAth(" + sourceFolderSize + ") and DestinationPath(" + destinationFolderSize + ") file size not same to delete.");
                    connectionIntermittent.insertWGSErrorLogCall(
                            new WGSErrorLogInput(0, fileDataArguments.getStatusViewerId(), "SourcePAth(" + sourceFolderSize + ") and DestinationPath(" + destinationFolderSize + ") file size not same to delete.",
                                    "PacBioFileDataOrganizer"));
                }
                pacBioServiceTransferStatusUpdate(
                        setStatusDetails(fileDataArguments.getStatusViewerId(), 3, destinationParentPath, ""));
                connectionIntermittent.insertWGSErrorLogCall(
                        new WGSErrorLogInput(0, fileDataArguments.getStatusViewerId(), "Copied successfully.",
                                "PacBioFileDataOrganizer"));
            } else {
                logger.error("No Disk Space");
                pacBioServiceTransferStatusUpdate(
                        setStatusDetails(fileDataArguments.getStatusViewerId(), 4, destinationParentPath, ""));
                connectionIntermittent.insertWGSErrorLogCall(
                        new WGSErrorLogInput(0, fileDataArguments.getStatusViewerId(), "No Disk Space",
                                "PacBioFileDataOrganizer"));
            }
        } catch (Exception e) {
            logger.error("Error :" + e.getMessage());
            pacBioServiceTransferStatusUpdate(
                    setStatusDetails(fileDataArguments.getStatusViewerId(), 4, destinationParentPath, ""));
            connectionIntermittent.insertWGSErrorLogCall(
                    new WGSErrorLogInput(0, fileDataArguments.getStatusViewerId(), e.getMessage(),
                            "PacBioFileDataOrganizer"));

        }

    }

    public static void doSmbFileCopy(String sourcePath, String destinationPath, DiskShare sourceShare, DiskShare destinationShare) throws IOException {
        sourcePath = sourcePath.replace(sourceShare.getSmbPath().toUncPath(), "");
        destinationPath = destinationPath.replace(destinationShare.getSmbPath().toUncPath(), "");
        sourcePath = sourcePath.replace("\\", "/");
        destinationPath = destinationPath.replace("\\", "/");

        boolean isDirectory = sourceShare.getFileInformation(sourcePath).getStandardInformation().isDirectory();
        if (isDirectory) {
            List<FileIdBothDirectoryInformation> fileList = sourceShare.list(sourcePath + "/");
            fileList.removeIf(file -> file.getFileName().equals(".") || file.getFileName().equals(".."));
            for (FileIdBothDirectoryInformation fileInfo : fileList) {
                String fileName = fileInfo.getFileName();
                if (fileName.equals(".") || fileName.equals("..")) {
                    continue;
                }

                String sourceFilePath;
                String destinationFilePath;
                if (sourceShare.fileExists(sourcePath.concat("/").concat(fileName))) {
                    sourceFilePath = sourcePath + "/" + fileName;
                    destinationFilePath = destinationPath + "/" + fileName;
                } else {
                    sourceFilePath = sourcePath + "/" + fileName + "/";
                    destinationFilePath = destinationPath + "/" + fileName + "/";
                    fileName += "/"; // Adding '/' in directory
                }


                if (fileName.endsWith("/") || fileName.endsWith("\\")) {
                    // It is a directory
                    String[] desNestedDirectory = destinationFilePath.split("/");
                    String currentDirectory = "";
                    for (String directory : desNestedDirectory) {
                        currentDirectory += directory + "/";
                        if (!destinationShare.folderExists(currentDirectory)) {
                            destinationShare.mkdir(currentDirectory);
                        }
                    }
                    // destinationShare.mkdir(destinationFilePath);
                    doSmbFileCopy(sourceFilePath, destinationFilePath, sourceShare, destinationShare);
                } else {
                    // It is a file
                    try (InputStream inputStream = sourceShare.openFile(sourceFilePath, EnumSet.of(AccessMask.GENERIC_READ)
                            , null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null).getInputStream();
                         OutputStream outputStream = destinationShare.openFile(destinationFilePath, EnumSet.of(AccessMask.GENERIC_WRITE)
                                 , null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_CREATE, null).getOutputStream()) {
                        byte[] buffer = new byte[4096];
                        int bytesRead;
                        while ((bytesRead = inputStream.read(buffer)) != -1) {
                            outputStream.write(buffer, 0, bytesRead);
                        }
                    }
                }
            }
        } else {
            // It is a file
            try (InputStream inputStream = sourceShare.openFile(sourcePath, EnumSet.of(AccessMask.GENERIC_READ)
                    , null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null).getInputStream();
                 OutputStream outputStream = destinationShare.openFile(destinationPath, EnumSet.of(AccessMask.GENERIC_WRITE)
                         , null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_CREATE, null).getOutputStream()) {
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                }
            }
        }

    }

    public static LocalTransferIdStatus setStatusDetails(int statusViewerId, int status, String sourcePath,
                                                         String failureReason) {
        LocalTransferIdStatus statusDetails = new LocalTransferIdStatus();
        statusDetails.setWgsStatusViewerId(statusViewerId);
        statusDetails.setStatus(status);
        statusDetails.setSourcePath(sourcePath);
        statusDetails.setUploadTypeId(1);
        statusDetails.setFailureReason(failureReason);
        return statusDetails;
    }

    public static void pacBioServiceTransferStatusUpdate(LocalTransferIdStatus statusDetails) {
        String result;
        ConnectionIntermittent connection = new ConnectionIntermittent();
        try {
            Response response = connection.updateLocalTransferStatus(statusDetails);
            if (response.code() != 200) {
                logger.error("Not able to connect LocalTransferStatus service. Response code :" + response.code());
                return;
            }
            result = Objects.requireNonNull(response.body()).string();
            logger.info("Result after called LocalTransferStatusUpdate service :" + result);

        } catch (Exception e) {
            // TODO Auto-generated catch block
            logger.error("Error in PacBioServiceTransferStatusUpdate method :" + e.getMessage());
        }
    }

}
