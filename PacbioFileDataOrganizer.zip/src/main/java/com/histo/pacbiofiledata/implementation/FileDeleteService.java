package com.histo.pacbiofiledata.implementation;

import com.hierynomus.smbj.common.SmbPath;
import com.histo.pacbiofiledata.config.DiskShareConfig;
import com.histo.pacbiofiledata.model.FileDataArguments;
import com.histo.pacbiofiledata.model.LogDetailModel;
import com.histo.pacbiofiledata.model.WGSErrorLogInput;
import com.histo.pacbiofiledata.process.ConnectionIntermittent;
import com.histo.pacbiofiledata.util.PacbioUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class FileDeleteService {
    private static final Logger logger = LogManager.getLogger(FileCopyOrMoveService.class);
    private static final ConnectionIntermittent connectionIntermittent = new ConnectionIntermittent();

    public static void deleteFileOrFolderByPath(FileDataArguments fileDataArguments) {
        try {
            DiskShareConfig diskShareConfig = new DiskShareConfig(fileDataArguments);

            SmbPath deleteSmbPath = diskShareConfig.getDeleteDiskShare().getSmbPath();
            String deleteParentPath = deleteSmbPath.toUncPath().concat("\\").concat(fileDataArguments.getDeleteLocation());
            deleteParentPath = deleteParentPath.replace("/", "\\");

            boolean isDeleteFolderExist = diskShareConfig.getDeleteDiskShare().folderExists(fileDataArguments.getDeleteLocation().replace("\\", "/"));
            if (!isDeleteFolderExist) {
                logger.error("Failed: Invalid Delete Folder -> " + deleteParentPath);
                if (fileDataArguments.getStatusViewerId() != 0) {
                    WGSErrorLogInput errorLog = new WGSErrorLogInput(0, fileDataArguments.getStatusViewerId()
                            , "Failed: Invalid Delete Folder -> " + deleteParentPath, "PacBioFileDataOrganizer");
                    connectionIntermittent.insertWGSErrorLogCall(errorLog);
                } else if (fileDataArguments.getStatusViewerId() == 0) {
                    LogDetailModel logDetail = new LogDetailModel(fileDataArguments.getActionType()
                            , fileDataArguments.getSourceDirectory()
                            , fileDataArguments.getDestinationDirectory()
                            , fileDataArguments.getDeleteLocation()
                            , "Failed"
                            , "PacbioFileDataOrganizer"
                    );
                    connectionIntermittent.insertLogDetailCall(logDetail);
                }
                return;
            }
            PacbioUtil.deleteSourcePath(diskShareConfig.getDeleteDiskShare(), 0, fileDataArguments.getDeleteDataNumberOfDaysBack(), fileDataArguments.getDeleteLocation());

        } catch (Exception e) {
            FileCopyOrMoveService.errorLog(fileDataArguments, e, logger);
        }
    }

}
